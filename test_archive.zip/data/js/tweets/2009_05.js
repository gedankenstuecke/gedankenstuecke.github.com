Grailbird.data.tweets_2009_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 3, 12 ],
      "id_str" : "22828618",
      "id" : 22828618
    }, {
      "name" : "David Bradley",
      "screen_name" : "sciencebase",
      "indices" : [ 17, 29 ],
      "id_str" : "6612402",
      "id" : 6612402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1981179625",
  "text" : "RT @Argent23: RT @sciencebase please retweet if you are a scientwist to be added http:\/\/tr.im\/juhg",
  "id" : 1981179625,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1981640392",
  "text" : "Yeah, mein langes Wochenende geht gleich bis Donnerstag!",
  "id" : 1981640392,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1982139422",
  "geo" : { },
  "id_str" : "1982180185",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Das kenne ich. Die Laborm\u00E4use halten sich da auch nicht dran.",
  "id" : 1982180185,
  "in_reply_to_status_id" : 1982139422,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1982289689",
  "text" : "Grillen! http:\/\/twitpic.com\/6cg2a",
  "id" : 1982289689,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me yeah",
      "screen_name" : "meyeah",
      "indices" : [ 0, 7 ],
      "id_str" : "153145129",
      "id" : 153145129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1982297352",
  "geo" : { },
  "id_str" : "1982625448",
  "in_reply_to_user_id" : 14651021,
  "text" : "@Meyeah im Salat! ;)",
  "id" : 1982625448,
  "in_reply_to_status_id" : 1982297352,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Pfeffermynzia",
  "in_reply_to_user_id_str" : "14651021",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1982386111",
  "geo" : { },
  "id_str" : "1982637060",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex danke, haben wir! http:\/\/twitpic.com\/6cjxl",
  "id" : 1982637060,
  "in_reply_to_status_id" : 1982386111,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 86, 94 ]
    }, {
      "text" : "wundw",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1978645514",
  "text" : "Neuer W&W-Post von Philipp: Gro\u00DFe R\u00FCben machen nicht immer Freunde http:\/\/tr.im\/mV2Qm #science #wundw #wissenschaft",
  "id" : 1978645514,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1978636177",
  "geo" : { },
  "id_str" : "1979186285",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ja, leider ist Deutschland immer noch kein laizistischer Staat...",
  "id" : 1979186285,
  "in_reply_to_status_id" : 1978636177,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1979195768",
  "text" : "@cptMarco D\u00FCrften sie eigentlich nicht, weil ist ja Pfingsten. Aber mit einem Trick geht es irgendwie: Zum sofortigen Verzehr ist erlaubt.",
  "id" : 1979195768,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1979200365",
  "text" : "@cptMarco Also kriegste die Br\u00F6tchen ohne T\u00FCte verkauft, dass aber ausreichend T\u00FCten zum mitnehmen im Laden liegen ist reiner Zufall ;)",
  "id" : 1979200365,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1979241284",
  "text" : "@cptMarco Ja, aber die Gesetze dazu sind halt Unsinn. Genauso wie das Tanzverbot z.B. an Karfreitag",
  "id" : 1979241284,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1979392052",
  "text" : "@cptMarco Ja, zurecht. Wer gl\u00E4ubig ist wird ja nicht gezwungen zu tanzen oder einzukaufen. Warum d\u00FCrfen die anderen aber auch nicht?",
  "id" : 1979392052,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1979471074",
  "geo" : { },
  "id_str" : "1979624403",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Wir verbieten ja auch nicht Freitags Fleisch zu essen oder allgemein Schweinefleisch zu essen mit R\u00FCcksicht auf Muslime...",
  "id" : 1979624403,
  "in_reply_to_status_id" : 1979471074,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1979654681",
  "text" : "Neuer Blogpost: Wieso es NICHT doof ist der Piratenpartei seine Stimme zu geben http:\/\/tr.im\/mWNr #piraten",
  "id" : 1979654681,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1979655989",
  "geo" : { },
  "id_str" : "1979709818",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Japs, und wenn man dann nochmal \u00FCberlegt wie sich das mit H\u00FCten in und au\u00DFerhalb von Gottesh\u00E4usern verh\u00E4lt wird man verr\u00FCckt.",
  "id" : 1979709818,
  "in_reply_to_status_id" : 1979655989,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Steinborn",
      "screen_name" : "BigBen666",
      "indices" : [ 3, 13 ],
      "id_str" : "288332310",
      "id" : 288332310
    }, {
      "name" : "Atheist QOTD",
      "screen_name" : "AtheistQOTD",
      "indices" : [ 18, 30 ],
      "id_str" : "9033762",
      "id" : 9033762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1979739438",
  "text" : "RT @BigBen666: RT @AtheistQOTD: \"The invisible and the non-existent look very much alike.\" Huang Po",
  "id" : 1979739438,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1979715981",
  "geo" : { },
  "id_str" : "1979740215",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog In einem Jahr erst?",
  "id" : 1979740215,
  "in_reply_to_status_id" : 1979715981,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1979995930",
  "text" : "Unter Windows was anderes zu machen als Spiele zu schaden erzeugt starke Schmerzen",
  "id" : 1979995930,
  "created_at" : "2009-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1969238464",
  "text" : "An einem solchen Morgen w\u00FCnschte ich der Hund k\u00F6nnte sich selbst Gassi f\u00FChren.",
  "id" : 1969238464,
  "created_at" : "2009-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 3, 15 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1969309514",
  "text" : "RT @okomuenster: Der Mann auf Listenplatz 2 der Piratenpartei kommt aus M\u00FCnster. Heute in der MZ und hier: http:\/\/arm.in\/3t5",
  "id" : 1969309514,
  "created_at" : "2009-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1969811122",
  "geo" : { },
  "id_str" : "1969848519",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Vorsicht, Briefbombe oder Anthrax ;)",
  "id" : 1969848519,
  "in_reply_to_status_id" : 1969811122,
  "created_at" : "2009-05-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1970075882",
  "geo" : { },
  "id_str" : "1970309278",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Ah, cool!",
  "id" : 1970309278,
  "in_reply_to_status_id" : 1970075882,
  "created_at" : "2009-05-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 128, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1972214031",
  "text" : "Call Of Duty - World At War ist zwar der xte WWII-Shooter, aber ein sehr gut gemachter. Vor allem der Coop-Modus ist sehr nett. #fb",
  "id" : 1972214031,
  "created_at" : "2009-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Killerspiele",
      "indices" : [ 26, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1974298875",
  "text" : "Jetzt so ne Runde zocken! #Killerspiele  http:\/\/twitpic.com\/6a2qw",
  "id" : 1974298875,
  "created_at" : "2009-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Killerspiele",
      "indices" : [ 6, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1975655963",
  "text" : "Genug #Killerspiele gespielt f\u00FCr diesen Abend.",
  "id" : 1975655963,
  "created_at" : "2009-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1957882262",
  "text" : "Ey, dass diese Renter sich sogar noch an der Fleischtheke vordr\u00E4ngeln wollen. Wer dem Tod davonl\u00E4uft hat halt nie Zeit...",
  "id" : 1957882262,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1958104139",
  "geo" : { },
  "id_str" : "1958175014",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ Piraten! :)",
  "id" : 1958175014,
  "in_reply_to_status_id" : 1958104139,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1958185141",
  "geo" : { },
  "id_str" : "1958529711",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ Das h\u00E4ngt wohl nicht unwesentlich von der Wahlbeteiligung ab ;)",
  "id" : 1958529711,
  "in_reply_to_status_id" : 1958185141,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1958534585",
  "text" : "Jetzt so nen Kaffee um nochmal wach zu werden!",
  "id" : 1958534585,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1958548502",
  "geo" : { },
  "id_str" : "1958572628",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ Ja, dann m\u00FCsste man das mal ausrechnen.  Habe ich aber noch nicht gemacht :)",
  "id" : 1958572628,
  "in_reply_to_status_id" : 1958548502,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 3, 10 ],
      "id_str" : "24357838",
      "id" : 24357838
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 12, 28 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1958574548",
  "text" : "RT @laune_: @gedankenstuecke Ja denke ich auch... Wie viele Stimmen brauchen die eig. ungef\u00E4hr um die 5% H\u00FCrde zu knacken?",
  "id" : 1958574548,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 3, 10 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1958578581",
  "text" : "RT @laune_ Wie viele Stimmen brauchen die eig. ungef\u00E4hr um die 5% H\u00FCrde zu knacken? (die #Piraten )",
  "id" : 1958578581,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 3, 11 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1958585166",
  "text" : "RT @insideX: Es gibt einen sehr guten Grund die Piraten zu w\u00E4hlen. Mit jeder Stimme die wir bekommen, fragen sich die anderen warum.",
  "id" : 1958585166,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1958773134",
  "text" : "Heute k\u00F6nnte ich den ganzen Tag retweeten. Hilfe!",
  "id" : 1958773134,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deutsche Buskampagne",
      "screen_name" : "buskampagne_de",
      "indices" : [ 3, 18 ],
      "id_str" : "42866752",
      "id" : 42866752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1958857396",
  "text" : "RT @buskampagne_de: Ein christliches Missionsteam will uns die gesamte Tour \u00FCber mit einem Reisebus \u201Ebegleiten\u201C. Wir sind gespannt[...]",
  "id" : 1958857396,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1959559624",
  "text" : "Hallo Sonne, danke dass ich wegen dir nicht mehr erkennen kann was auf meinem Monitor passiert.",
  "id" : 1959559624,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1959610657",
  "geo" : { },
  "id_str" : "1959624294",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ne, die Rollos runtermachen.",
  "id" : 1959624294,
  "in_reply_to_status_id" : 1959610657,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1959699564",
  "geo" : { },
  "id_str" : "1959731169",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Japs, aber es funktioniert.",
  "id" : 1959731169,
  "in_reply_to_status_id" : 1959699564,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RYKS GULIKERS",
      "screen_name" : "wick0r",
      "indices" : [ 0, 7 ],
      "id_str" : "4276829361",
      "id" : 4276829361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1959784329",
  "text" : "@Wick0r Kommt drauf an mit was f\u00FCr Leuten du so rumh\u00E4ngst ;) Auf der re:publica waren die Dinger schon recht praktisch.",
  "id" : 1959784329,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1959822878",
  "geo" : { },
  "id_str" : "1959852499",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ist halt nicht die Linux-Bastel-L\u00F6sung :D",
  "id" : 1959852499,
  "in_reply_to_status_id" : 1959822878,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1960706095",
  "text" : "Hund versucht sich weiterhin unter dem Sofa vor der Sonne zu verstecken. Klappt nicht.",
  "id" : 1960706095,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1960787975",
  "text" : "http:\/\/twitpic.com\/66pft - Twitterfon in Black",
  "id" : 1960787975,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1960793664",
  "text" : "http:\/\/twitpic.com\/66phb - Twitterfon in Plain",
  "id" : 1960793664,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 57, 70 ]
    }, {
      "text" : "wundw",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1961010375",
  "text" : "Neuer W&W-Post: Crossing Over http:\/\/tr.im\/mNVB #science #wissenschaft #wundw",
  "id" : 1961010375,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denny",
      "screen_name" : "dc79",
      "indices" : [ 3, 8 ],
      "id_str" : "15468731",
      "id" : 15468731
    }, {
      "name" : "Pottblog",
      "screen_name" : "Pottblog",
      "indices" : [ 13, 22 ],
      "id_str" : "5769802",
      "id" : 5769802
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Silvana",
      "indices" : [ 34, 42 ]
    }, {
      "text" : "Koch",
      "indices" : [ 43, 48 ]
    }, {
      "text" : "Mehrin",
      "indices" : [ 49, 56 ]
    }, {
      "text" : "FDP",
      "indices" : [ 57, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1961236172",
  "text" : "RT @dc79: RT @pottblog Anwalt von #Silvana #Koch #Mehrin #FDP- droht Ruhrbaronen wg. http:\/\/tr.im\/mO5D",
  "id" : 1961236172,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 0, 12 ],
      "id_str" : "428633",
      "id" : 428633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1961223929",
  "geo" : { },
  "id_str" : "1961238967",
  "in_reply_to_user_id" : 428633,
  "text" : "@kwerfeldein Es gibt auch nichts nutzloseres als Wasserzeichen",
  "id" : 1961238967,
  "in_reply_to_status_id" : 1961223929,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "kwerfeldein",
  "in_reply_to_user_id_str" : "428633",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1961407389",
  "text" : "Er spielt den T\u00FCrstopper, aber in die falsche Richtung!  http:\/\/twitpic.com\/66trs",
  "id" : 1961407389,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1963176328",
  "text" : "Was ich am Macbook ja so praktisch finde ist wie schnell Man mal auf LAN zu seinen Freunden fahren kann um zusammen ne Runde zu zocken.",
  "id" : 1963176328,
  "created_at" : "2009-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950837851",
  "geo" : { },
  "id_str" : "1950861691",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Naja wenn ich tags\u00FCber mal 2 Stunden nicht reinschaue bin ich schon bei 200+ neuen Tweets und damit \u00FCber dem API-Limit ;)",
  "id" : 1950861691,
  "in_reply_to_status_id" : 1950837851,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950937968",
  "geo" : { },
  "id_str" : "1950968723",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Ich meine nicht das Refresh-Limit. Aber auch das Abrufen der letzten Tweets ist begrenzt. Auf die letzten 200 Tweets.",
  "id" : 1950968723,
  "in_reply_to_status_id" : 1950937968,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950937968",
  "geo" : { },
  "id_str" : "1950977936",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex An mehr als die letzten 200 Tweets der Timeline kommt man nicht ran :(",
  "id" : 1950977936,
  "in_reply_to_status_id" : 1950937968,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1951054973",
  "geo" : { },
  "id_str" : "1951112936",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Ich glaube mehr holen kann Twitterfon auch, aber ohne Tricks kann man nur die letzten 200 abgreifen. :)",
  "id" : 1951112936,
  "in_reply_to_status_id" : 1951054973,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1951102499",
  "geo" : { },
  "id_str" : "1951116335",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ok, damit ist das Thema ja echt durch. Kann ich das Paper von der Verblog-Liste l\u00F6schen ;)",
  "id" : 1951116335,
  "in_reply_to_status_id" : 1951102499,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 55, 61 ]
    }, {
      "text" : "science",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "prlit",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "Wissenschaft",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1951503294",
  "text" : "Neuer W&W-Post: Der Gesang der V\u00F6gel http:\/\/tr.im\/mIw2 #wundw #science #prlit #Wissenschaft",
  "id" : 1951503294,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1951754211",
  "geo" : { },
  "id_str" : "1951811446",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Ich glaube das sind da alles nicht so WLAN-User ;)",
  "id" : 1951811446,
  "in_reply_to_status_id" : 1951754211,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gruenen",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1952082132",
  "text" : "Eigentlich muss man nur im Bio-Grundkurs aufgepasst haben um die #gruenen- nicht mehr w\u00E4hlen zu k\u00F6nnen.",
  "id" : 1952082132,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1944856193",
  "text" : "Morgen!",
  "id" : 1944856193,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1945237695",
  "text" : "Lade gerade die Fotos vom Infostand der #Piraten gestern hoch. Sollte mir auch angew\u00F6hnen in der Uni die Fotouploads laufen zu lassen.",
  "id" : 1945237695,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1945307103",
  "text" : "Neuer Blogpost: Infostand der #Piraten http:\/\/tr.im\/mE2j",
  "id" : 1945307103,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Hissting",
      "screen_name" : "ahissting",
      "indices" : [ 0, 10 ],
      "id_str" : "22149779",
      "id" : 22149779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1858346620",
  "geo" : { },
  "id_str" : "1945372934",
  "in_reply_to_user_id" : 22149779,
  "text" : "@ahissting Hier nochmal ein Link f\u00FCr dich: http:\/\/tr.im\/mE4X :)",
  "id" : 1945372934,
  "in_reply_to_status_id" : 1858346620,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahissting",
  "in_reply_to_user_id_str" : "22149779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1945738450",
  "text" : "@cptMarco Die ich gemailt habe sind alle. War nicht so fleissig mit der Kamera ;)",
  "id" : 1945738450,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly #IsraelHHMG \uD83C\uDDEE\uD83C\uDDF1",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1945840193",
  "geo" : { },
  "id_str" : "1945852779",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Zu viel Waschpulver was sich festsetzt? ;)",
  "id" : 1945852779,
  "in_reply_to_status_id" : 1945840193,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1945930109",
  "text" : "Wolfram Alpha sagt \u201Cno known major notable events\u201D f\u00FCr meinen Geburtstag. Ich will mich irgendwo beschweren!",
  "id" : 1945930109,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1945933458",
  "text" : "@houellebeck Die Seite sieht nach back in the days of 1997 aus. Und wo findest du \u00FCberhaupt so einen Mist? Und will ich das Wissen? ;)",
  "id" : 1945933458,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1946017831",
  "text" : "Sehr cooles Cover von Dylans Masters of War, gespielt von Pearl Jam.  \u266B http:\/\/blip.fm\/~76jnw",
  "id" : 1946017831,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1946013109",
  "geo" : { },
  "id_str" : "1946027538",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod 150k ist glaube ich das n\u00E4chste Ziel, damit es die erfolgreichste ePetition bislang wird.",
  "id" : 1946027538,
  "in_reply_to_status_id" : 1946013109,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1946096857",
  "geo" : { },
  "id_str" : "1946141917",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Oderich sollte also mal schnell was gro\u00DFartiges leisten",
  "id" : 1946141917,
  "in_reply_to_status_id" : 1946096857,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1946133641",
  "geo" : { },
  "id_str" : "1946144364",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich meine irgendwo sowas \u00FCber die ePetition gelesen zu haben. Leider keine Quelle mehr vorhanden",
  "id" : 1946144364,
  "in_reply_to_status_id" : 1946133641,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1946766503",
  "text" : "Es ist immer ganz schlecht das Schreiben von Artikeln f\u00FCr das Mittagessen zu unterbrechen. Wo war ich noch gleich?",
  "id" : 1946766503,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "science",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 81, 94 ]
    }, {
      "text" : "PRLit",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1946833021",
  "text" : "Neuer W&W-Post: Wie Trypanosoma sich versteckt http:\/\/tr.im\/mF9V #wundw #science #wissenschaft #PRLit",
  "id" : 1946833021,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "muensterana",
      "screen_name" : "muensterana",
      "indices" : [ 0, 12 ],
      "id_str" : "26782616",
      "id" : 26782616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1947704853",
  "geo" : { },
  "id_str" : "1948333962",
  "in_reply_to_user_id" : 26782616,
  "text" : "@muensterana Danke f\u00FCrs verbreiten :)",
  "id" : 1948333962,
  "in_reply_to_status_id" : 1947704853,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "muensterana",
  "in_reply_to_user_id_str" : "26782616",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1948357619",
  "text" : "Gibt es eigentlich auch Krankenh\u00E4user die nicht in jedem Zimmer das Kruzifix h\u00E4ngen haben? \u00C4rzte behandeln Menschen, keine \u00FCbernat. Wesen...",
  "id" : 1948357619,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1948418932",
  "geo" : { },
  "id_str" : "1948450518",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich glaube sogar im UKM h\u00E4ngen die Dinger auf den Zimmern.",
  "id" : 1948450518,
  "in_reply_to_status_id" : 1948418932,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1948487593",
  "geo" : { },
  "id_str" : "1948517340",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Gut, im M\u00FCnsterland kannste nicht auf die Stra\u00DFe spucken ohne nen CDUler zu treffen. ;)",
  "id" : 1948517340,
  "in_reply_to_status_id" : 1948487593,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1948534588",
  "text" : "Und nochmal Pearl Jam, diesmal mit dem letzten Kuss. \u266B http:\/\/blip.fm\/~770pu",
  "id" : 1948534588,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Schwehn",
      "screen_name" : "jschwehn",
      "indices" : [ 0, 9 ],
      "id_str" : "777527",
      "id" : 777527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1948615489",
  "geo" : { },
  "id_str" : "1948713481",
  "in_reply_to_user_id" : 777527,
  "text" : "@jschwehn Dann sollten sie die Kruzifixe aber lieber vor die Blutbank h\u00E4ngen ;)",
  "id" : 1948713481,
  "in_reply_to_status_id" : 1948615489,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "jschwehn",
  "in_reply_to_user_id_str" : "777527",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1948716382",
  "geo" : { },
  "id_str" : "1948753790",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu \u201CPolitik ohne Wahlen w\u00E4re wunderbar\u201D, da w\u00E4re wirklich jemand zu gerne Diktator...",
  "id" : 1948753790,
  "in_reply_to_status_id" : 1948716382,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1948716382",
  "geo" : { },
  "id_str" : "1948760850",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Aber man stelle sich die Reihe vor: Stalin, Hitler, Castro und Wiefelsp\u00FCtz. Mit dem Namen wird das nix!",
  "id" : 1948760850,
  "in_reply_to_status_id" : 1948716382,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david rieber",
      "screen_name" : "knipsr",
      "indices" : [ 0, 7 ],
      "id_str" : "25478691",
      "id" : 25478691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1949278281",
  "geo" : { },
  "id_str" : "1950003552",
  "in_reply_to_user_id" : 25478691,
  "text" : "@knipsr jau",
  "id" : 1950003552,
  "in_reply_to_status_id" : 1949278281,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "knipsr",
  "in_reply_to_user_id_str" : "25478691",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david rieber",
      "screen_name" : "knipsr",
      "indices" : [ 0, 7 ],
      "id_str" : "25478691",
      "id" : 25478691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950029526",
  "geo" : { },
  "id_str" : "1950246256",
  "in_reply_to_user_id" : 25478691,
  "text" : "@knipsr Ja, aber werden die Dinger f\u00FCr andersgl\u00E4ubige rausgeh\u00E4ngt? ;)",
  "id" : 1950246256,
  "in_reply_to_status_id" : 1950029526,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "knipsr",
  "in_reply_to_user_id_str" : "25478691",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950039996",
  "geo" : { },
  "id_str" : "1950249235",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Ne, aber w\u00E4re auch egal weil ich Linus bin und davon eh nix h\u00E4tte.",
  "id" : 1950249235,
  "in_reply_to_status_id" : 1950039996,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nSonic",
      "screen_name" : "bnSonic",
      "indices" : [ 0, 8 ],
      "id_str" : "17022259",
      "id" : 17022259
    }, {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 9, 16 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950411632",
  "geo" : { },
  "id_str" : "1950424216",
  "in_reply_to_user_id" : 17022259,
  "text" : "@bnSonic @thopex TwitterFon Pro ftw! ;)",
  "id" : 1950424216,
  "in_reply_to_status_id" : 1950411632,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "bnSonic",
  "in_reply_to_user_id_str" : "17022259",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950541521",
  "geo" : { },
  "id_str" : "1950550850",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Twitterfon merkt sich die Scrollposition nicht? Du meinst dass er zum \u201Clast unread\u201D scrollt sobald er refresht findest du doof?",
  "id" : 1950550850,
  "in_reply_to_status_id" : 1950541521,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950541521",
  "geo" : { },
  "id_str" : "1950565664",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Daf\u00FCr kannst du bei TwitterFon doch in den Settings \u201CAuto scroll\u201D auf \u201Cnone\u201D stellen??",
  "id" : 1950565664,
  "in_reply_to_status_id" : 1950541521,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950668712",
  "geo" : { },
  "id_str" : "1950701194",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Ahso, das nutze ich gar nicht. Hab es auf \u201Clast unread\u201D weil mir das reicht. Ich kann eh nicht alle Tweets lesen ;)",
  "id" : 1950701194,
  "in_reply_to_status_id" : 1950668712,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1950668712",
  "geo" : { },
  "id_str" : "1950710897",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Bzw. entweder lese ich in einem Rutsch alles durch oder halt nur die letzten X weil bei 200 Tweets alle zu lesen ist too much.",
  "id" : 1950710897,
  "in_reply_to_status_id" : 1950668712,
  "created_at" : "2009-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anhoerung",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1934009999",
  "geo" : { },
  "id_str" : "1934017412",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX w\u00FCrde #anhoerung empfehlen. Umlaute machen Tags kaputt.",
  "id" : 1934017412,
  "in_reply_to_status_id" : 1934009999,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1934028710",
  "geo" : { },
  "id_str" : "1934055272",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX Twitterfon kann es auch seh ich gerade. Aber ist dass allgemein gefixt oder Clientabh\u00E4ngig?",
  "id" : 1934055272,
  "in_reply_to_status_id" : 1934028710,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "muenster",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1934165224",
  "text" : "Jetzt live vom Infostand der #piraten #muenster  http:\/\/twitpic.com\/61mbm",
  "id" : 1934165224,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1934234316",
  "geo" : { },
  "id_str" : "1934262651",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih komm doch zur Mensa am Aasee zu den Piraten :)",
  "id" : 1934262651,
  "in_reply_to_status_id" : 1934234316,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1935384086",
  "text" : "Wieder da vom #Piraten stand. War sehr cool. Und einige Unterschriften haben wir auch bekommen. Die genaue Zahl gibt\u2019s sp\u00E4ter.",
  "id" : 1935384086,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1935490112",
  "text" : "Grrr. noch 2 coole Paper \u00FCber die ich am liebsten sofort bloggen w\u00FCrde. Doch keine Zeit daf\u00FCr heute...",
  "id" : 1935490112,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1935633283",
  "geo" : { },
  "id_str" : "1935657393",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Gegen Zensur sein aber den npd-Account sperren lassen wollen?",
  "id" : 1935657393,
  "in_reply_to_status_id" : 1935633283,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "muensterana",
      "screen_name" : "muensterana",
      "indices" : [ 0, 12 ],
      "id_str" : "26782616",
      "id" : 26782616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1936262180",
  "geo" : { },
  "id_str" : "1936369562",
  "in_reply_to_user_id" : 26782616,
  "text" : "@muensterana ich hoffe es hat dir gefallen bei uns!",
  "id" : 1936369562,
  "in_reply_to_status_id" : 1936262180,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "muensterana",
  "in_reply_to_user_id_str" : "26782616",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    }, {
      "name" : "German Psycho",
      "screen_name" : "germanpsycho",
      "indices" : [ 12, 25 ],
      "id_str" : "14972477",
      "id" : 14972477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1935667823",
  "geo" : { },
  "id_str" : "1936392108",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz @germanpsycho Naja, das sehe ich anders: Es ist eine (noch?) legale Partei. Und die muss sich auch \u00E4u\u00DFern d\u00FCrfen.",
  "id" : 1936392108,
  "in_reply_to_status_id" : 1935667823,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    }, {
      "name" : "German Psycho",
      "screen_name" : "germanpsycho",
      "indices" : [ 12, 25 ],
      "id_str" : "14972477",
      "id" : 14972477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1935667823",
  "geo" : { },
  "id_str" : "1936401331",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz @germanpsycho Wir k\u00F6nnen doch nicht nur f\u00FCr Meinungsfreiheit k\u00E4mpfen solange es um unsere Meinung geht.",
  "id" : 1936401331,
  "in_reply_to_status_id" : 1935667823,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1936410455",
  "text" : "@cptMarco Viel Erfolg meine Piraten. Ich Feier daf\u00FCr beim Geburtstag meiner Oma f\u00FCr euch mit!",
  "id" : 1936410455,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Warndorf",
      "screen_name" : "Frau_Elise",
      "indices" : [ 0, 11 ],
      "id_str" : "21445012",
      "id" : 21445012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1936192621",
  "geo" : { },
  "id_str" : "1936431299",
  "in_reply_to_user_id" : 21445012,
  "text" : "@Frau_Elise Word!!",
  "id" : 1936431299,
  "in_reply_to_status_id" : 1936192621,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Elise",
  "in_reply_to_user_id_str" : "21445012",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "German Psycho",
      "screen_name" : "germanpsycho",
      "indices" : [ 0, 13 ],
      "id_str" : "14972477",
      "id" : 14972477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1936414049",
  "geo" : { },
  "id_str" : "1936469507",
  "in_reply_to_user_id" : 14972477,
  "text" : "@germanpsycho sie m\u00FCssen der NPD ja auch nicht folgen. Es zwingt sie niemand.",
  "id" : 1936469507,
  "in_reply_to_status_id" : 1936414049,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanpsycho",
  "in_reply_to_user_id_str" : "14972477",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "German Psycho",
      "screen_name" : "germanpsycho",
      "indices" : [ 0, 13 ],
      "id_str" : "14972477",
      "id" : 14972477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1936484731",
  "geo" : { },
  "id_str" : "1936511272",
  "in_reply_to_user_id" : 14972477,
  "text" : "@germanpsycho stimmt. Aber Blocken mit der Intention der Sperre geht dr\u00FCber hinaus.",
  "id" : 1936511272,
  "in_reply_to_status_id" : 1936484731,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanpsycho",
  "in_reply_to_user_id_str" : "14972477",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1936658798",
  "text" : "iPhone-Akku sagt noch 1%. Damit ist nun vorbei mit twitter bis heute Abend. Oh und auch mit aller anderer Erreichbarkeit. 12 h und Ende...",
  "id" : 1936658798,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1937941975",
  "geo" : { },
  "id_str" : "1939217933",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Cool, kannte ich noch gar nicht. Danke f\u00FCr den Link :)",
  "id" : 1939217933,
  "in_reply_to_status_id" : 1937941975,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1939220811",
  "text" : "@cptMarco Und habt ihr gut aufgeh\u00E4ngt? :)",
  "id" : 1939220811,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1939255473",
  "text" : "Wieder zuhause. Endlich wieder Strom f\u00FCrs iPhone und Zugang zum Netz. ;)",
  "id" : 1939255473,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1939411787",
  "text" : "Neuer Blogpost: Zu sp\u00E4t.... http:\/\/tr.im\/mAYR",
  "id" : 1939411787,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Resul Y\u0131ld\u0131z",
      "screen_name" : "ZResu",
      "indices" : [ 0, 6 ],
      "id_str" : "3318712270",
      "id" : 3318712270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1939528293",
  "text" : "@zresU Da bin ich ja ganz froh ausnahmsweise mal recht zu haben ;)",
  "id" : 1939528293,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Resul Y\u0131ld\u0131z",
      "screen_name" : "ZResu",
      "indices" : [ 0, 6 ],
      "id_str" : "3318712270",
      "id" : 3318712270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1932627855",
  "text" : "@zresU Ich w\u00FCrde in den ersten Tagen kaputt gehen. Bin ans sp\u00E4te aufstehen und sp\u00E4te schlafen aklimatisiert.",
  "id" : 1932627855,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 67, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1932706023",
  "text" : "Echter Student: Kaum aufgestanden k\u00F6nnte ich schon wieder ins Bett #fb",
  "id" : 1932706023,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1932733549",
  "geo" : { },
  "id_str" : "1932928821",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Ich w\u00FCrde sagen jeder mit iPhone oder vergleichbarem Smartphone ;)",
  "id" : 1932928821,
  "in_reply_to_status_id" : 1932733549,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 13, 21 ]
    }, {
      "text" : "muenster",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "fb",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1933649700",
  "text" : "\u00DCbrigens die #Piraten haben heute von 11:30 bis 14:00 Uhr einen Infostand vor der Mensa am Aasee in #muenster ! #fb",
  "id" : 1933649700,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1933752102",
  "text" : "Mathemathik ist Kunst.  Und jetzt h\u00F6ren wir Mozarts \u201E2. Koordinate in B\u201C.",
  "id" : 1933752102,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1933970719",
  "geo" : { },
  "id_str" : "1933991328",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz daf\u00FCr kann ich dann nicht mehr so bequem r\u00FCberlaufen ;)",
  "id" : 1933991328,
  "in_reply_to_status_id" : 1933970719,
  "created_at" : "2009-05-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1921753921",
  "text" : "Was tun wenn B\u00FCcher verboten sind? Awesome! http:\/\/tr.im\/mp9x",
  "id" : 1921753921,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Resul Y\u0131ld\u0131z",
      "screen_name" : "ZResu",
      "indices" : [ 0, 6 ],
      "id_str" : "3318712270",
      "id" : 3318712270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1921909230",
  "text" : "@zresU Nur weil man Molek\u00FCle riechen kann verr\u00E4t das doch recht wenig \u00FCber die Atome in dem Molek\u00FCl. Die m\u00FCsste man auch schon riechen",
  "id" : 1921909230,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 11, 18 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1921920898",
  "geo" : { },
  "id_str" : "1921945331",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @JoergR \/b\/ ? ;)",
  "id" : 1921945331,
  "in_reply_to_status_id" : 1921920898,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1921946613",
  "text" : "@adatiabooks Oeh, was genau meinst du?",
  "id" : 1921946613,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Resul Y\u0131ld\u0131z",
      "screen_name" : "ZResu",
      "indices" : [ 0, 6 ],
      "id_str" : "3318712270",
      "id" : 3318712270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1922005000",
  "text" : "@zresU http:\/\/tr.im\/mpmx Ist schon irgendwie Optisch oder? :)",
  "id" : 1922005000,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Weschta",
      "screen_name" : "ThomasWe",
      "indices" : [ 0, 9 ],
      "id_str" : "18760008",
      "id" : 18760008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1921997788",
  "geo" : { },
  "id_str" : "1922014342",
  "in_reply_to_user_id" : 18760008,
  "text" : "@ThomasWe F\u00FCr 1 bzw. 2 RAW-Files :D",
  "id" : 1922014342,
  "in_reply_to_status_id" : 1921997788,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ThomasWe",
  "in_reply_to_user_id_str" : "18760008",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Resul Y\u0131ld\u0131z",
      "screen_name" : "ZResu",
      "indices" : [ 0, 6 ],
      "id_str" : "3318712270",
      "id" : 3318712270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1922036928",
  "text" : "@zresU Teilrecht reicht mir erstmal ;)",
  "id" : 1922036928,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Weschta",
      "screen_name" : "ThomasWe",
      "indices" : [ 0, 9 ],
      "id_str" : "18760008",
      "id" : 18760008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1922029910",
  "geo" : { },
  "id_str" : "1922039131",
  "in_reply_to_user_id" : 18760008,
  "text" : "@ThomasWe Das hat dann fast schon was von Polaroid. Ziehst die CF aus der Karte und sch\u00FCttelst sie ein wenig ;)",
  "id" : 1922039131,
  "in_reply_to_status_id" : 1922029910,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ThomasWe",
  "in_reply_to_user_id_str" : "18760008",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1922123917",
  "text" : "Habe ich schonmal erw\u00E4hnt wie sehr ich Bahnfanren hasse? So 2-3 Mio. mal erst w\u00FCrde ich vermuten.",
  "id" : 1922123917,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1922269336",
  "geo" : { },
  "id_str" : "1922340022",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Das kenn ich aus dem Botanikpraktikum noch :)",
  "id" : 1922340022,
  "in_reply_to_status_id" : 1922269336,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1922405227",
  "geo" : { },
  "id_str" : "1922412621",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Pfui. Piraten sollst du w\u00E4hlen :)",
  "id" : 1922412621,
  "in_reply_to_status_id" : 1922405227,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1922597325",
  "text" : "Nicht nur das Nature jetzt doppelt geliefert wird. Jetzt sind die Liefertermine auch fucked up...",
  "id" : 1922597325,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1922638785",
  "text" : "So, gerade das EU-Programm der Piraten im Bezug auf Gentechnik mal etwas \u00FCberarbeitet.",
  "id" : 1922638785,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1922687355",
  "geo" : { },
  "id_str" : "1922813546",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog deshalb hatte ich gestern wohl auch 30 neue, alte Feedeintr\u00E4ge von dir",
  "id" : 1922813546,
  "in_reply_to_status_id" : 1922687355,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1922853467",
  "geo" : { },
  "id_str" : "1922911714",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Na beim bestimmen durfte das so manches mal herangezogen werden. Ich habe es gehasst :D",
  "id" : 1922911714,
  "in_reply_to_status_id" : 1922853467,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1922865661",
  "geo" : { },
  "id_str" : "1922917772",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Unter http:\/\/tr.im\/mq2G findest du das EU-Wahlprogramm. Allerdings ist davon nur das Rot unterlegte schon beschlossen.",
  "id" : 1922917772,
  "in_reply_to_status_id" : 1922865661,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    }, {
      "name" : "Tobias Maier",
      "screen_name" : "weitergen",
      "indices" : [ 70, 80 ],
      "id_str" : "14717573",
      "id" : 14717573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1922865661",
  "geo" : { },
  "id_str" : "1922921145",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Die anderen Punkte sind offen zur Diskussion. Siehe auch in @weitergen 's Blog :)",
  "id" : 1922921145,
  "in_reply_to_status_id" : 1922865661,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 63, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1924177101",
  "text" : "B\u00E4h, bin heute elendig kaputt. Kopf f\u00FChlt sich nach Matsche an #fb",
  "id" : 1924177101,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    }, {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 8, 22 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1924182025",
  "text" : "@JoergR @astrodicticum Bei mir gehen die SB auch nicht mehr.",
  "id" : 1924182025,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1924361338",
  "text" : "wtf? last.fm-App erzeugt 98% CPU-Auslastung?",
  "id" : 1924361338,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1925057362",
  "text" : "Die \u00DCberschrift ist ja so #fail Von \u201Cwollen\u201D kann da ja wenig Rede sein... http:\/\/tr.im\/mrEW",
  "id" : 1925057362,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1925100948",
  "geo" : { },
  "id_str" : "1925390109",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja, da will man auch unbedingt aufgeschnitten werden und so.",
  "id" : 1925390109,
  "in_reply_to_status_id" : 1925100948,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zensursula",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1925416775",
  "text" : "Wenn ich jedes Mal nur einen Cent kriegen w\u00FCrde von die #Zensursula vom rechtsfreien Raum \u201CInternet\u201D redet...",
  "id" : 1925416775,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denny",
      "screen_name" : "dc79",
      "indices" : [ 0, 5 ],
      "id_str" : "15468731",
      "id" : 15468731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1925427161",
  "geo" : { },
  "id_str" : "1925443266",
  "in_reply_to_user_id" : 15468731,
  "text" : "@dc79 Meinst du sie wird nach Provision f\u00FCr Unfug reden bezahlt? Das w\u00E4re so ziemlich mein Traum.",
  "id" : 1925443266,
  "in_reply_to_status_id" : 1925427161,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "dc79",
  "in_reply_to_user_id_str" : "15468731",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1925442510",
  "geo" : { },
  "id_str" : "1925453391",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Wer das behauptet sollte einfach mit Gesetzestexten und Urteilen zu Tode gesteinigt werden die das Gegenteil beweisen.",
  "id" : 1925453391,
  "in_reply_to_status_id" : 1925442510,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1925453707",
  "geo" : { },
  "id_str" : "1925457929",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod So hoch kann Peter Maffay nur leider nicht spucken ;)",
  "id" : 1925457929,
  "in_reply_to_status_id" : 1925453707,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1925481573",
  "geo" : { },
  "id_str" : "1925622030",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Wie war das mit der Kl\u00FCgere gibt nach?",
  "id" : 1925622030,
  "in_reply_to_status_id" : 1925481573,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1925666401",
  "geo" : { },
  "id_str" : "1925788826",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Und ist vor allem deshalb an der Macht",
  "id" : 1925788826,
  "in_reply_to_status_id" : 1925666401,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "netzpolitik",
      "screen_name" : "netzpolitik",
      "indices" : [ 3, 15 ],
      "id_str" : "9655032",
      "id" : 9655032
    }, {
      "name" : "Mathias Richel",
      "screen_name" : "mathiasrichel",
      "indices" : [ 20, 34 ],
      "id_str" : "5899392",
      "id" : 5899392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zensursula",
      "indices" : [ 47, 58 ]
    }, {
      "text" : "zensursula",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1926950885",
  "text" : "RT @netzpolitik: RT @mathiasrichel SpOn stellt #zensursula und #zensursula liest sich \u00E4u\u00DFerst nerv\u00F6s: http:\/\/bit.ly\/jY0wd",
  "id" : 1926950885,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Fricke",
      "screen_name" : "JacobFricke",
      "indices" : [ 0, 12 ],
      "id_str" : "855001460",
      "id" : 855001460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1927102550",
  "text" : "@jacobfricke Men\u00FCleiste w\u00FCrde ich sagen",
  "id" : 1927102550,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1927355062",
  "text" : "Der Hund findet es total witzig seinen Ball unter das Sofa zu schieben und dann zu jammern bis ihn jemand rausfischt. Wer spielt mit wem?",
  "id" : 1927355062,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1927375524",
  "geo" : { },
  "id_str" : "1927444314",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Ja, zumindest in manchen Bereichen. Jetzt ist er beleidigt weil ich keine Lust mehr habe.",
  "id" : 1927444314,
  "in_reply_to_status_id" : 1927375524,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1927709682",
  "text" : "Neuer W&W-Post: Verr\u00FCckte Neuzug\u00E4nge http:\/\/tr.im\/mtzk",
  "id" : 1927709682,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 13, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1928022814",
  "text" : "So jetzt mal #gn8 von mir. Muss morgen verh\u00E4ltnism\u00E4ssig fr\u00FCh raus. um 5:45 schon...",
  "id" : 1928022814,
  "created_at" : "2009-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1912871507",
  "geo" : { },
  "id_str" : "1912886745",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Ja, Google d\u00FCrfte dabei weiterhelfen. Da ich nicht betroffen bin hab ich das nie ausf\u00FChrlicher verfolgt.",
  "id" : 1912886745,
  "in_reply_to_status_id" : 1912871507,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1912878909",
  "geo" : { },
  "id_str" : "1912918863",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Alt gedr\u00FCckt halten beim Startvorgang?",
  "id" : 1912918863,
  "in_reply_to_status_id" : 1912878909,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1912878909",
  "geo" : { },
  "id_str" : "1912946981",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Gelogen, das ist nur f\u00FCr BootCamp, C beim Boot dr\u00FCcken",
  "id" : 1912946981,
  "in_reply_to_status_id" : 1912878909,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1913050393",
  "text" : "Immer dieses Problem wenn der Akku fast leer ist und man nicht weiss ob er den Abend noch \u00FCbersteht. Risiko oder doofes halbladen?",
  "id" : 1913050393,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1913843874",
  "geo" : { },
  "id_str" : "1913960595",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz F\u00FCr SLRs sind Manuals auch Quatsch ;) Und nichts zu danken!",
  "id" : 1913960595,
  "in_reply_to_status_id" : 1913843874,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1914345377",
  "geo" : { },
  "id_str" : "1915180786",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz cool. Ich hab ihn noch nicht eingesteckt :)",
  "id" : 1915180786,
  "in_reply_to_status_id" : 1914345377,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1915830822",
  "text" : "Wieder da vom Piratenstammtisch.",
  "id" : 1915830822,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1916099835",
  "text" : "Ich glaube morgen nehme ich mir mal das Gentechnik-Programm der #piraten vor und formuliere dass auf nicht-doof um.",
  "id" : 1916099835,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei NRW",
      "screen_name" : "PiratenNRW",
      "indices" : [ 0, 11 ],
      "id_str" : "36646869",
      "id" : 36646869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1916280328",
  "geo" : { },
  "id_str" : "1916368228",
  "in_reply_to_user_id" : 36646869,
  "text" : "@PiratenNRW Der Stammtisch war gut. Und vor allem sehr gut besucht. Au\u00DFerdem wurde der Infostand f\u00FCr Mittwoch geplant.",
  "id" : 1916368228,
  "in_reply_to_status_id" : 1916280328,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "PiratenNRW",
  "in_reply_to_user_id_str" : "36646869",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Resul Y\u0131ld\u0131z",
      "screen_name" : "ZResu",
      "indices" : [ 0, 6 ],
      "id_str" : "3318712270",
      "id" : 3318712270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1916402214",
  "text" : "@zresU W\u00FCrdest du Molek\u00FCle nicht gerne sehen k\u00F6nnen anstatt nur riechen? ;)",
  "id" : 1916402214,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 73, 81 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 82, 95 ]
    }, {
      "text" : "wundw",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1910206738",
  "text" : "Neuer W&W-Post von Philipp: Der Kulli und die Armbrust http:\/\/tr.im\/mj7K #science #wissenschaft #wundw",
  "id" : 1910206738,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "towelday",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1910624292",
  "text" : "http:\/\/twitpic.com\/5wu0x - Feiert den #towelday gut. Ich weiss genau wo meins ist.",
  "id" : 1910624292,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1910673646",
  "text" : "@eXpSpAwN Obi-Wan war doch Terrorist, dann passt es doch ganz gut zusammen ;)",
  "id" : 1910673646,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "muenster",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1910735389",
  "text" : "Nochmal zur Erinnerung: Heute Abend um 19:00 der Stammtisch der #piraten in #muenster in der Blechtrommel.",
  "id" : 1910735389,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1910829014",
  "geo" : { },
  "id_str" : "1910855048",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Klar, auf dem Weg durch die Galaxis",
  "id" : 1910855048,
  "in_reply_to_status_id" : 1910829014,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1910872612",
  "geo" : { },
  "id_str" : "1910883086",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Daf\u00FCr hab ich doch das Handtuch! ;)",
  "id" : 1910883086,
  "in_reply_to_status_id" : 1910872612,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1910934121",
  "text" : "Hilfe, ich glaube der bierologie.org Feed ist kaputt. Und Philipp und ich wissen nicht woran es pl\u00F6tzlich liegt.",
  "id" : 1910934121,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1910895186",
  "geo" : { },
  "id_str" : "1910960836",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod V\u00F6llig richtig!",
  "id" : 1910960836,
  "in_reply_to_status_id" : 1910895186,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1911067088",
  "text" : "Aha, nun geht der Feed wieder und ich weiss genau gar nicht wieso. Magie pur",
  "id" : 1911067088,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1911312176",
  "text" : "Die #Piraten und die Gentechnik - Bislang nur Allgemeinpl\u00E4tze: http:\/\/tr.im\/mjS6",
  "id" : 1911312176,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Fricke",
      "screen_name" : "JacobFricke",
      "indices" : [ 0, 12 ],
      "id_str" : "855001460",
      "id" : 855001460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1911436758",
  "text" : "@jacobfricke Einfach einen Absatz einf\u00FCgen hinter dem Bild? so mit &lt;\/br&gt;?",
  "id" : 1911436758,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Fricke",
      "screen_name" : "JacobFricke",
      "indices" : [ 0, 12 ],
      "id_str" : "855001460",
      "id" : 855001460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1911449391",
  "text" : "@jacobfricke Mh, also bei mir macht er das mit Wordpress nicht sondern schiebt dann brav den Text nach unten. Andere Formatierungen genutzt?",
  "id" : 1911449391,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1911461953",
  "text" : "Ich weiss, ich bin dreist: Hat wer DOI 10.1111\/j.1460-9568.2009.06782.x ? ;)",
  "id" : 1911461953,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fatih Demir",
      "screen_name" : "kabalak",
      "indices" : [ 0, 8 ],
      "id_str" : "15673002",
      "id" : 15673002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1896461569",
  "geo" : { },
  "id_str" : "1911533881",
  "in_reply_to_user_id" : 15673002,
  "text" : "@kabalak Hoi, das Paper w\u00E4re bei bastian@gedankenstuecke.de ganz gut aufgehoben :)",
  "id" : 1911533881,
  "in_reply_to_status_id" : 1896461569,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "kabalak",
  "in_reply_to_user_id_str" : "15673002",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1911528535",
  "geo" : { },
  "id_str" : "1911534602",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina super, danke :)",
  "id" : 1911534602,
  "in_reply_to_status_id" : 1911528535,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fatih Demir",
      "screen_name" : "kabalak",
      "indices" : [ 0, 8 ],
      "id_str" : "15673002",
      "id" : 15673002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1911539189",
  "geo" : { },
  "id_str" : "1911558895",
  "in_reply_to_user_id" : 15673002,
  "text" : "@kabalak Danke danke :)",
  "id" : 1911558895,
  "in_reply_to_status_id" : 1911539189,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "kabalak",
  "in_reply_to_user_id_str" : "15673002",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1911543049",
  "geo" : { },
  "id_str" : "1911559161",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina An euch beide :)",
  "id" : 1911559161,
  "in_reply_to_status_id" : 1911543049,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1911610066",
  "geo" : { },
  "id_str" : "1911619689",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ich habs auch schon wieder :)",
  "id" : 1911619689,
  "in_reply_to_status_id" : 1911610066,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00B2",
      "screen_name" : "dontcare",
      "indices" : [ 0, 9 ],
      "id_str" : "14969791",
      "id" : 14969791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1911611835",
  "geo" : { },
  "id_str" : "1911621295",
  "in_reply_to_user_id" : 14969791,
  "text" : "@dontcare Okay, aber ich glaube dass ist genau das was Wordpress standardm\u00E4ssig macht wenn man Enter dr\u00FCckt?",
  "id" : 1911621295,
  "in_reply_to_status_id" : 1911611835,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "dontcare",
  "in_reply_to_user_id_str" : "14969791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00B2",
      "screen_name" : "dontcare",
      "indices" : [ 0, 9 ],
      "id_str" : "14969791",
      "id" : 14969791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1911642089",
  "geo" : { },
  "id_str" : "1911742838",
  "in_reply_to_user_id" : 14969791,
  "text" : "@dontcare Stimmt. Aber bei manchen Gelegenheiten macht er es trotzdem. Oder war das S9Y? *verwirrt*",
  "id" : 1911742838,
  "in_reply_to_status_id" : 1911642089,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "dontcare",
  "in_reply_to_user_id_str" : "14969791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1911829891",
  "text" : "Bei diesem Wetter ist mit dem Zug fahren m\u00FCssen eine Strafe. Gut das ich mein Handtuch dabeihabe. Gegen K\u00F6rpers\u00E4fte und Ger\u00FCche.",
  "id" : 1911829891,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "towelday",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1911859816",
  "geo" : { },
  "id_str" : "1911972455",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Dabei habe ich es wegen des #towelday aber das zeigt einem direkt wieder wie verdammt praktisch so ein Handtuch ist",
  "id" : 1911972455,
  "in_reply_to_status_id" : 1911859816,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1911974472",
  "text" : "Die NPG hat es immer noch nicht gecheckt.. wieder 2 Ausgaben der Nature im Briefkasten",
  "id" : 1911974472,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1912050306",
  "text" : "Ach Kinder, ist es denn so schwer einen DOI oder einen Link zum Paper unter Artikel zu setzen? Wir sind doch nun im 21. Jahrhundert...",
  "id" : 1912050306,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1912081588",
  "text" : "Will nicht mal jemand aus MS mir die doppelte Nature abnehmen? Das verschicken ist immer so l\u00E4stig ;)",
  "id" : 1912081588,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bosse von Hazeltree",
      "screen_name" : "bosse08",
      "indices" : [ 0, 8 ],
      "id_str" : "42025349",
      "id" : 42025349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1912144646",
  "geo" : { },
  "id_str" : "1912158242",
  "in_reply_to_user_id" : 42025349,
  "text" : "@bosse08 Hey, der Anblick kommt mir doch nur zu bekannt vor. Ist das etwa bei mir zuhause gemacht? ;)",
  "id" : 1912158242,
  "in_reply_to_status_id" : 1912144646,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "bosse08",
  "in_reply_to_user_id_str" : "42025349",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1912695938",
  "geo" : { },
  "id_str" : "1912743153",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Ja, bei den alten Plastik-Macbooks ist diese Stelle beliebt um kaputt zu gehen.",
  "id" : 1912743153,
  "in_reply_to_status_id" : 1912695938,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 3, 15 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Scientology",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1912788474",
  "text" : "RT @gillyberlin: RT @bildm8: \"Scientology droht Aufl\u00F6sung\" http:\/\/tr.im\/mkS9 #Scientology frankreich",
  "id" : 1912788474,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1912796728",
  "geo" : { },
  "id_str" : "1912834730",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu So weit ich weiss l\u00E4sst Apple das aber unter erweiterter Garantie beheben weil es ein Produktionsfehler ist.",
  "id" : 1912834730,
  "in_reply_to_status_id" : 1912796728,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 66, 79 ]
    }, {
      "text" : "wundw",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1912873096",
  "text" : "Neuer W&W-Post: Nicht du schon wieder! http:\/\/tr.im\/mkVM #science #wissenschaft #wundw",
  "id" : 1912873096,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3wordsaftersex",
      "indices" : [ 16, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1912877993",
  "text" : "Ich geh offline #3wordsaftersex",
  "id" : 1912877993,
  "created_at" : "2009-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1901516400",
  "geo" : { },
  "id_str" : "1901527130",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Hi Henry!",
  "id" : 1901527130,
  "in_reply_to_status_id" : 1901516400,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 3, 15 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1901558310",
  "text" : "RT @gillyberlin: Ein Bild f\u00FCr die m\u00E4nnlichen Kaffee Junkies unter euch: http:\/\/twitpic.com\/5u5xn",
  "id" : 1901558310,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Fricke",
      "screen_name" : "JacobFricke",
      "indices" : [ 3, 15 ],
      "id_str" : "855001460",
      "id" : 855001460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1902322315",
  "text" : "RT @jacobfricke: \"das Internet macht Menschen nicht d\u00FCmmer, es macht Dummheit nur sichtbarer\" ist f\u00FCr mich bereits jetzt der satz des tages",
  "id" : 1902322315,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1902423919",
  "text" : "Ist zuf\u00E4llig jemand online der Zugriff auf DOI 10.1002\/anie.200900071  hat?",
  "id" : 1902423919,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 81, 94 ]
    }, {
      "text" : "wund",
      "indices" : [ 95, 100 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1902989322",
  "text" : "Neuer W&W-Post: Calciumnachweis \u00FCber Goldnanopartikel http:\/\/tr.im\/mgce #science #wissenschaft #wund #wissenschaft",
  "id" : 1902989322,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 22, 32 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1902989367",
  "geo" : { },
  "id_str" : "1902992470",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Danke, aber @Fischblog hat mir schon geholfen und verbloggt ist das Paper auch schon :)",
  "id" : 1902992470,
  "in_reply_to_status_id" : 1902989367,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1903005920",
  "geo" : { },
  "id_str" : "1903014374",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Jau, wurde ja auch mal langsam wieder Zeit f\u00FCr etwas Content :)",
  "id" : 1903014374,
  "in_reply_to_status_id" : 1903005920,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1904298523",
  "text" : "Habt ihr euch auch schon alle ein Handtuch rausgesucht f\u00FCr morgen?",
  "id" : 1904298523,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "towel_day",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1904361778",
  "geo" : { },
  "id_str" : "1904370620",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Ne, f\u00FCr den Towel Day http:\/\/tr.im\/mgKD #towel_day",
  "id" : 1904370620,
  "in_reply_to_status_id" : 1904361778,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "towel_day",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1904383436",
  "geo" : { },
  "id_str" : "1904393044",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Ich seh schon, bei Twitter sind sehr wenig Leute mit dem #towel_day vertraut http:\/\/tr.im\/mgKD",
  "id" : 1904393044,
  "in_reply_to_status_id" : 1904383436,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1904401121",
  "geo" : { },
  "id_str" : "1904468233",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Na dann kannst du ja nun beruhigt morgen das Handtuch mitf\u00FChren ;)",
  "id" : 1904468233,
  "in_reply_to_status_id" : 1904401121,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 3, 11 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1904724546",
  "text" : "RT @Cohnina: Altes, vllt. auch kaputtes Handy daheim? Dann ab in den n\u00E4chsten o2-Shop  http:\/\/tr.im\/mgSQ",
  "id" : 1904724546,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RYKS GULIKERS",
      "screen_name" : "wick0r",
      "indices" : [ 0, 7 ],
      "id_str" : "4276829361",
      "id" : 4276829361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1904991168",
  "text" : "@Wick0r Ich finde KF &lt;&lt; L4D",
  "id" : 1904991168,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 116, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1905003710",
  "text" : "Habe nun mal dieses selektive Twitter-Facebook-App installiert. Mal ein bisschen weniger Spam f\u00FCr die Facebook-User #fb",
  "id" : 1905003710,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RYKS GULIKERS",
      "screen_name" : "wick0r",
      "indices" : [ 0, 7 ],
      "id_str" : "4276829361",
      "id" : 4276829361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1905106253",
  "text" : "@Wick0r Finde es recht lahm und es endet im zweifel im Wegrennen ;)",
  "id" : 1905106253,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RYKS GULIKERS",
      "screen_name" : "wick0r",
      "indices" : [ 0, 7 ],
      "id_str" : "4276829361",
      "id" : 4276829361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1905379004",
  "text" : "@Wick0r Ja die Perks sind ganz nett. Aber so billig ist es auch nicht im Vergleich zu L4D",
  "id" : 1905379004,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RYKS GULIKERS",
      "screen_name" : "wick0r",
      "indices" : [ 0, 7 ],
      "id_str" : "4276829361",
      "id" : 4276829361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1905430664",
  "text" : "@Wick0r \u00DCber Polen bekommt man L4D f\u00FCr 17\u20AC ;)",
  "id" : 1905430664,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RYKS GULIKERS",
      "screen_name" : "wick0r",
      "indices" : [ 0, 7 ],
      "id_str" : "4276829361",
      "id" : 4276829361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1905531177",
  "text" : "@Wick0r ok :)",
  "id" : 1905531177,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1905750670",
  "geo" : { },
  "id_str" : "1905784139",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays ja das kenne ich auch nur zu gut *Kraul*",
  "id" : 1905784139,
  "in_reply_to_status_id" : 1905750670,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1901521164",
  "text" : "Ich bin wieder wach. Und wieder gesundet wenn man von ein bisschen Halsschmerzen absieht.",
  "id" : 1901521164,
  "created_at" : "2009-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1893524818",
  "text" : "Verdammt, ich werde wirklich zu alt f\u00FCr diese Saufgelage!",
  "id" : 1893524818,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schmolk",
      "screen_name" : "anouphagos",
      "indices" : [ 0, 11 ],
      "id_str" : "368317316",
      "id" : 368317316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1893578396",
  "text" : "@anouphagos Zumindest nimmt die Zeit zu die ich brauche um danach wieder halbwegs fit zu werden.",
  "id" : 1893578396,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saufgelage",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1893560700",
  "geo" : { },
  "id_str" : "1893581817",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Das w\u00FCrde zwar funktionieren, der Idee kann ich gerade aber ganz wenig abgewinnen ;) #saufgelage",
  "id" : 1893581817,
  "in_reply_to_status_id" : 1893560700,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1894424208",
  "text" : "Langsam w\u00E4re es mal Zeit feste Nahrung auszutesten. Aber so richtig \u00FCberzeugt bin ich noch nicht.",
  "id" : 1894424208,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1895826535",
  "text" : "Sch\u00F6ne Gr\u00FC\u00DFe von Svenja! http:\/\/twitpic.com\/5sd48",
  "id" : 1895826535,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1895863782",
  "geo" : { },
  "id_str" : "1896159734",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu daf\u00FCr haben sie den B\u00E4ren \u00FCberall  http:\/\/twitpic.com\/5shqk",
  "id" : 1896159734,
  "in_reply_to_status_id" : 1895863782,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1895914693",
  "geo" : { },
  "id_str" : "1896163386",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Das war eine Live-Twitter-Demo :)",
  "id" : 1896163386,
  "in_reply_to_status_id" : 1895914693,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1896204015",
  "geo" : { },
  "id_str" : "1896246856",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ja, die tollen Features von Twitter.",
  "id" : 1896246856,
  "in_reply_to_status_id" : 1896204015,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1896299666",
  "geo" : { },
  "id_str" : "1896449919",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ja, 140 Zeichen \u00F6ffentlich in die Welt zu senden!",
  "id" : 1896449919,
  "in_reply_to_status_id" : 1896299666,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1897438242",
  "text" : "Ab ins Bett! Immer noch verkatern!",
  "id" : 1897438242,
  "created_at" : "2009-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilario Schrozberg",
      "screen_name" : "schrozberg",
      "indices" : [ 3, 14 ],
      "id_str" : "37653383",
      "id" : 37653383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1880662736",
  "text" : "RT @schrozberg: Die Uni Kiel verlangt von kranken Studenten genaue Angaben zur Krankheit vom Arzt http:\/\/bit.ly\/SFs0U",
  "id" : 1880662736,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Fricke",
      "screen_name" : "JacobFricke",
      "indices" : [ 0, 12 ],
      "id_str" : "855001460",
      "id" : 855001460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1880698670",
  "text" : "@jacobfricke Es gibt sicher aber auch Sachverhalte die sich trotz Beschr\u00E4nkung aufs Wesentliche nicht in 140 Zeichen komprimieren lassen.",
  "id" : 1880698670,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1880695159",
  "geo" : { },
  "id_str" : "1880711282",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em N\u00E4chsten Mittwoch gerne ;)",
  "id" : 1880711282,
  "in_reply_to_status_id" : 1880695159,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nSonic",
      "screen_name" : "bnSonic",
      "indices" : [ 0, 8 ],
      "id_str" : "17022259",
      "id" : 17022259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1880779255",
  "geo" : { },
  "id_str" : "1880814692",
  "in_reply_to_user_id" : 17022259,
  "text" : "@bnSonic \"Kiffen macht dumm und gleichg\u00FCltig, was sagste dazu?\" - \"wei\u00DF nicht, mir doch egal!\" ;)",
  "id" : 1880814692,
  "in_reply_to_status_id" : 1880779255,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "bnSonic",
  "in_reply_to_user_id_str" : "17022259",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ameninderkirche",
      "indices" : [ 119, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1880882695",
  "text" : "Wieso \u00FCberrascht es eigentlich wirklich manche dass das kommende iPhone anstatt mit 16 mit 32 GB Speicher kommen wird? #ameninderkirche",
  "id" : 1880882695,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei NRW",
      "screen_name" : "PiratenNRW",
      "indices" : [ 0, 11 ],
      "id_str" : "36646869",
      "id" : 36646869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1880975945",
  "geo" : { },
  "id_str" : "1881033562",
  "in_reply_to_user_id" : 36646869,
  "text" : "@PiratenNRW Mensa am Aasee? Irgendwie dachte ich wir h\u00E4tten uns auf den Ring geeinigt?",
  "id" : 1881033562,
  "in_reply_to_status_id" : 1880975945,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "PiratenNRW",
  "in_reply_to_user_id_str" : "36646869",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1881093904",
  "geo" : { },
  "id_str" : "1881104793",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod 512 kb sind mehr als genug f\u00FCr jedermann... ;)",
  "id" : 1881104793,
  "in_reply_to_status_id" : 1881093904,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1881133403",
  "geo" : { },
  "id_str" : "1881152929",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Stimmt, \u201CTraue nie einem Zitat das du nicht selbst gef\u00E4lscht hast\u201D oder so? ;)",
  "id" : 1881152929,
  "in_reply_to_status_id" : 1881133403,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 10, 17 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1881192009",
  "geo" : { },
  "id_str" : "1881210504",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion @skl8em und mich kannst du sonst ja auch Montag beim Stammtisch der Piratenpartei treffen ;)",
  "id" : 1881210504,
  "in_reply_to_status_id" : 1881192009,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1881336009",
  "geo" : { },
  "id_str" : "1881494003",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ist auch besser so, dann ergeben sie meist mehr Sinn.",
  "id" : 1881494003,
  "in_reply_to_status_id" : 1881336009,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1880176056",
  "geo" : { },
  "id_str" : "1881534924",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Musik aus MySpace einbinden f\u00FCr Fotonauts w\u00E4re f\u00FCr meinen Zweck ideal.",
  "id" : 1881534924,
  "in_reply_to_status_id" : 1880176056,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1881574190",
  "text" : "Geiles Mashup aus Queen & Slayer: Queen will Slay You http:\/\/tr.im\/m5G1",
  "id" : 1881574190,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1881611976",
  "geo" : { },
  "id_str" : "1881644673",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em ja hab ich,Wikipedia in nur englisch ist schade und dass keine Sounds gehen halt noch mehr.Da kann ich besser mit Soundslides nutzen",
  "id" : 1881644673,
  "in_reply_to_status_id" : 1881611976,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    }, {
      "name" : "Fotonauts",
      "screen_name" : "fotonauts",
      "indices" : [ 8, 18 ],
      "id_str" : "13092532",
      "id" : 13092532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1881677191",
  "geo" : { },
  "id_str" : "1882562839",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em @fotonauts Ok, thanks for the reply! I will give that a try!",
  "id" : 1882562839,
  "in_reply_to_status_id" : 1881677191,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fotonauts",
      "screen_name" : "fotonauts",
      "indices" : [ 0, 10 ],
      "id_str" : "13092532",
      "id" : 13092532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1881778519",
  "geo" : { },
  "id_str" : "1882850237",
  "in_reply_to_user_id" : 13092532,
  "text" : "@fotonauts Are there any plans for including audio-features into fotonauts? Slideshows incl. Audio rock!",
  "id" : 1882850237,
  "in_reply_to_status_id" : 1881778519,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "fotonauts",
  "in_reply_to_user_id_str" : "13092532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1882956366",
  "text" : "Mein gr\u00F6\u00DFter Kritikpunkt an Twitterfon Pro wurde endlich behoben: Das sauh\u00E4ssliche Icon ist endlich ersetzt worden!",
  "id" : 1882956366,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1882984942",
  "geo" : { },
  "id_str" : "1883078417",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Das ist gefixt mit dem Update sobald es durch ist. Der Fehler 1001 kommt an kaputter Zeichencodierung. Umlaute produzieren das",
  "id" : 1883078417,
  "in_reply_to_status_id" : 1882984942,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1883044092",
  "geo" : { },
  "id_str" : "1883084467",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Noch nicht im App-Store, aber die Betatester haben die 1.5.1 schon als Adhoc bekommen. Da wurde das ge\u00E4ndert und Fehler behoben.",
  "id" : 1883084467,
  "in_reply_to_status_id" : 1883044092,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1882984942",
  "geo" : { },
  "id_str" : "1883093124",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium afaik ist der Rotationsfehler aber auch behoben, sowohl in der kostenlosen als auch Pro. Nun noch auf Apples OK warten ;)",
  "id" : 1883093124,
  "in_reply_to_status_id" : 1882984942,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1883262461",
  "geo" : { },
  "id_str" : "1883341666",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Japs. Ich bin einfach gro\u00DFer Fanboy von TwitterFon und muss daf\u00FCr einfach werben :)",
  "id" : 1883341666,
  "in_reply_to_status_id" : 1883262461,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "briefwahl",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1883383389",
  "text" : "Gerade schon mein Kreuz f\u00FCr die Piratenpartei gemacht! #briefwahl",
  "id" : 1883383389,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fotonauts",
      "screen_name" : "fotonauts",
      "indices" : [ 0, 10 ],
      "id_str" : "13092532",
      "id" : 13092532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1883674194",
  "geo" : { },
  "id_str" : "1884009341",
  "in_reply_to_user_id" : 13092532,
  "text" : "@fotonauts Features incl. Last.fm, Myspace or even YouTube would be great.",
  "id" : 1884009341,
  "in_reply_to_status_id" : 1883674194,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "fotonauts",
  "in_reply_to_user_id_str" : "13092532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1883731133",
  "geo" : { },
  "id_str" : "1884016463",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Die Pro-Variante kann ich auch nur empfehlen ;)",
  "id" : 1884016463,
  "in_reply_to_status_id" : 1883731133,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1884004738",
  "geo" : { },
  "id_str" : "1884031210",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Halt so wie du f\u00FCr Tweetie :)",
  "id" : 1884031210,
  "in_reply_to_status_id" : 1884004738,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1884049074",
  "geo" : { },
  "id_str" : "1884116514",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Ja, Tweetie zeigt nicht die Anzahl neuer Tweets, Replies & DMs an und das Quer-Keyboard ist nicht dynamisch.",
  "id" : 1884116514,
  "in_reply_to_status_id" : 1884049074,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1884049074",
  "geo" : { },
  "id_str" : "1884150059",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Daf\u00FCr unterst\u00FCtzt es mehr Bilder-Services als Twitterfon. Bin Insgesamt aber viel zufriedener mit Twitterfon.",
  "id" : 1884150059,
  "in_reply_to_status_id" : 1884049074,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1884054285",
  "geo" : { },
  "id_str" : "1884154840",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Raff ich nicht. Oder kurz: ???",
  "id" : 1884154840,
  "in_reply_to_status_id" : 1884054285,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1884273879",
  "geo" : { },
  "id_str" : "1884358817",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ah nun ist der Groschen gefallen",
  "id" : 1884358817,
  "in_reply_to_status_id" : 1884273879,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u043Enasterium",
      "screen_name" : "monasterium",
      "indices" : [ 0, 12 ],
      "id_str" : "15126396",
      "id" : 15126396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1884231688",
  "geo" : { },
  "id_str" : "1884363696",
  "in_reply_to_user_id" : 15126396,
  "text" : "@monasterium Kein Problem :) Viel Spa\u00DF damit!",
  "id" : 1884363696,
  "in_reply_to_status_id" : 1884231688,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monasterium",
  "in_reply_to_user_id_str" : "15126396",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1884382651",
  "text" : "Wird morgen beim Grundgesetz lesen nochmal explizit auf Artikel 20, Absatz 4 eingegangen?",
  "id" : 1884382651,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei NRW",
      "screen_name" : "PiratenNRW",
      "indices" : [ 3, 14 ],
      "id_str" : "36646869",
      "id" : 36646869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piratenpartei",
      "indices" : [ 24, 38 ]
    }, {
      "text" : "taz",
      "indices" : [ 39, 43 ]
    }, {
      "text" : "faz",
      "indices" : [ 44, 48 ]
    }, {
      "text" : "jugendschutzprogramm",
      "indices" : [ 53, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1884433906",
  "text" : "RT @PiratenNRW: SKANDAL #piratenpartei #taz #faz auf #jugendschutzprogramm.de gesperrt - bild.de als unbedenklich eingestuft",
  "id" : 1884433906,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1884449774",
  "geo" : { },
  "id_str" : "1884479546",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja, denn wer den Pfennig nicht ehrt... Aus der Kategorie Mark-Sprichw\u00F6rter",
  "id" : 1884479546,
  "in_reply_to_status_id" : 1884449774,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1886013836",
  "text" : "Chaos-Kochen  http:\/\/twitpic.com\/5poas",
  "id" : 1886013836,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1886036082",
  "text" : "Selbstgemachte Ravioli mit Salatfuellung  http:\/\/twitpic.com\/5poin",
  "id" : 1886036082,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Das Fr\u00E4ulein K.",
      "screen_name" : "Katzenbaer",
      "indices" : [ 0, 11 ],
      "id_str" : "19500091",
      "id" : 19500091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1886086480",
  "geo" : { },
  "id_str" : "1886254792",
  "in_reply_to_user_id" : 19500091,
  "text" : "@Katzenbaer keine Ahnung, ist ein online gefundenes Rezept. Wird die Generalprobe",
  "id" : 1886254792,
  "in_reply_to_status_id" : 1886086480,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Katzenbaer",
  "in_reply_to_user_id_str" : "19500091",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1886179322",
  "geo" : { },
  "id_str" : "1886262002",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em ne, die sind f\u00FCr den Salat den es als Vorspeise gibt :)",
  "id" : 1886262002,
  "in_reply_to_status_id" : 1886179322,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1886995062",
  "text" : "Andere Twitterfon Pro Beta-User hier die mit 1.5.1 noch den Twitpic Error 1001 haben?",
  "id" : 1886995062,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1887232721",
  "text" : "Twitpic Test \u00FC\u00E4\u00F6 http:\/\/twitpic.com\/5pzyf",
  "id" : 1887232721,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1887246337",
  "text" : "Strange, nun hat es funktioniert.",
  "id" : 1887246337,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1880114284",
  "geo" : { },
  "id_str" : "1880147508",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion pl0gbar war sehr cool.",
  "id" : 1880147508,
  "in_reply_to_status_id" : 1880114284,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1880148389",
  "geo" : { },
  "id_str" : "1880162154",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ach so geeky auch nicht, aber du wolltest mir noch den Link zu dieser Photo-Site schicken. Gibt es da eigentlich Audiofeatures?",
  "id" : 1880162154,
  "in_reply_to_status_id" : 1880148389,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1880176056",
  "geo" : { },
  "id_str" : "1880199364",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Fotonauts sieht ganz nett aus, bin auf den Invite gespannt.",
  "id" : 1880199364,
  "in_reply_to_status_id" : 1880176056,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1880481029",
  "text" : "verk\u00FCmmert durch twitter wohl die f\u00E4higkeit sich ausf\u00FChrlich zu etwas zu \u00E4u\u00DFern?",
  "id" : 1880481029,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1880506357",
  "geo" : { },
  "id_str" : "1880571189",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ok",
  "id" : 1880571189,
  "in_reply_to_status_id" : 1880506357,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1880576909",
  "text" : "@NicoleRensmann und sorgt daf\u00FCr das wir l\u00E4ngere Texte nicht mehr lesen k\u00F6nnen weil unsere Aufmerksamkeitsspanne 140 Zeichen lang ist ;)",
  "id" : 1880576909,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1880661287",
  "text" : "\u201EAber da man sich dem Abitur heute nur noch durch Selbstmord enziehen kann, gibt es scheinbar genug dumme Studenten ohne R\u00FCckgrat.\u201C",
  "id" : 1880661287,
  "created_at" : "2009-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1868963408",
  "text" : "Guten Morgen zusammen!",
  "id" : 1868963408,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "muenster",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1869183483",
  "text" : "Wir schaut es eigentlich aus mit der #pl0gbar in #muenster heut Abend? Teilnehmer?",
  "id" : 1869183483,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1869247299",
  "geo" : { },
  "id_str" : "1869265078",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Cool :)",
  "id" : 1869265078,
  "in_reply_to_status_id" : 1869247299,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1869481220",
  "geo" : { },
  "id_str" : "1869506286",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih H\u00F6rt sich gut an!",
  "id" : 1869506286,
  "in_reply_to_status_id" : 1869481220,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zensursula",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1869714354",
  "text" : "Neuer Blogpost: Wenn einer eine Umfrage macht http:\/\/tr.im\/lYtR #zensursula",
  "id" : 1869714354,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1871348352",
  "text" : "Was freu ich mich auf das Landscape-Keyboard in Mail!",
  "id" : 1871348352,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1871654988",
  "text" : "@einerblog Das ist mir alles zu umst\u00E4ndlich, da qu\u00E4le ich mich lieber auf dem kleinen Keyboard ;)",
  "id" : 1871654988,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1872298935",
  "text" : "Gerade Ani Difranco wiederentdeckt. Bin wieder begeistert. \u266B http:\/\/blip.fm\/~6r1ko",
  "id" : 1872298935,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1872564794",
  "text" : "Sehr cooles Video, auch wenn es schon alt ist f\u00FCr Webverh\u00E4ltnisse (2007): http:\/\/tr.im\/m0pn",
  "id" : 1872564794,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1872587611",
  "text" : "2 \u00E4ltere Damen stehen seit fast 2 Stunden unter meinem Fenster und quatschen sehr laut. \u201Cdieses Dingens.wie hiess es gleich?Menschenrechte?\u201D",
  "id" : 1872587611,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1872657446",
  "text" : "Ich glaube mir ist gerade das Dock abgeschmiert. Wie kann ich es fixen?",
  "id" : 1872657446,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1872670727",
  "geo" : { },
  "id_str" : "1872692518",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih den habe ich schon gekillt. Kein Erfolg. Nichtmal Abmelden oder neustarten geht mehr. Force Quit.",
  "id" : 1872692518,
  "in_reply_to_status_id" : 1872670727,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Dahdah @ \uD83C\uDDEA\uD83C\uDDF8",
      "screen_name" : "parasight",
      "indices" : [ 0, 10 ],
      "id_str" : "14157781",
      "id" : 14157781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1872693086",
  "geo" : { },
  "id_str" : "1872724860",
  "in_reply_to_user_id" : 14157781,
  "text" : "@parasight Ah, guter Tipp. F\u00FCrs n\u00E4chste Mal :)",
  "id" : 1872724860,
  "in_reply_to_status_id" : 1872693086,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "parasight",
  "in_reply_to_user_id_str" : "14157781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1872826119",
  "geo" : { },
  "id_str" : "1872832286",
  "in_reply_to_user_id" : 25670334,
  "text" : "@IIINaDL Ja genau an dem. :)",
  "id" : 1872832286,
  "in_reply_to_status_id" : 1872826119,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "safarbillus",
  "in_reply_to_user_id_str" : "25670334",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1873020228",
  "geo" : { },
  "id_str" : "1873049618",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Ja, ich wollte mich gleich auf den Weg machen!",
  "id" : 1873049618,
  "in_reply_to_status_id" : 1873020228,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1873222536",
  "geo" : { },
  "id_str" : "1873382379",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ne das hat nicht gereicht. Den Finder habe ich tapfer weggeschossen",
  "id" : 1873382379,
  "in_reply_to_status_id" : 1873222536,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1873455283",
  "geo" : { },
  "id_str" : "1873482270",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz schade! Dann halt beim n\u00E4chsten mal.",
  "id" : 1873482270,
  "in_reply_to_status_id" : 1873455283,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1873497421",
  "geo" : { },
  "id_str" : "1873601092",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Oha, geht es nach Neuseeland? ;)",
  "id" : 1873601092,
  "in_reply_to_status_id" : 1873497421,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1873858214",
  "geo" : { },
  "id_str" : "1876273181",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz H\u00F6rt sich trotzdem gar nicht schlecht an :)",
  "id" : 1876273181,
  "in_reply_to_status_id" : 1873858214,
  "created_at" : "2009-05-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiia Tentakel",
      "screen_name" : "TiiaAurora",
      "indices" : [ 0, 11 ],
      "id_str" : "16183565",
      "id" : 16183565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1856586243",
  "geo" : { },
  "id_str" : "1856681747",
  "in_reply_to_user_id" : 16183565,
  "text" : "@TiiaAurora den Skill habe ich auch. Der Hund hat heute Nacht quer \u00FCber meinen Beinen geschlafen!",
  "id" : 1856681747,
  "in_reply_to_status_id" : 1856586243,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "TiiaAurora",
  "in_reply_to_user_id_str" : "16183565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1856843967",
  "text" : "M\u00E4del vor mir beschwert sich dr\u00FCber dass die Nummerierung der Vorlesungsthemen nicht mehr Stimmt. Ergebnisse des Studentenpisa wundern nicht",
  "id" : 1856843967,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1857247278",
  "text" : "In den \u00F6den Vorlesungen freu ich mich immer \u00FCbers iPhone.",
  "id" : 1857247278,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Hissting",
      "screen_name" : "ahissting",
      "indices" : [ 0, 10 ],
      "id_str" : "22149779",
      "id" : 22149779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1857589521",
  "geo" : { },
  "id_str" : "1857611969",
  "in_reply_to_user_id" : 22149779,
  "text" : "@ahissting Und wieviel % davon Wissen \u00FCberhaupt was gentechnisch ver\u00E4nderte Lebensmittel sind?",
  "id" : 1857611969,
  "in_reply_to_status_id" : 1857589521,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahissting",
  "in_reply_to_user_id_str" : "22149779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Hissting",
      "screen_name" : "ahissting",
      "indices" : [ 0, 10 ],
      "id_str" : "22149779",
      "id" : 22149779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1857589521",
  "geo" : { },
  "id_str" : "1857616288",
  "in_reply_to_user_id" : 22149779,
  "text" : "@ahissting und 50% sind gegen Eingriffe in dir nat. Sch\u00F6pfung. Die 50% sollen dann bitte auf der Stelle alle Medikamente abgeben...",
  "id" : 1857616288,
  "in_reply_to_status_id" : 1857589521,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahissting",
  "in_reply_to_user_id_str" : "22149779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 3, 17 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CDU",
      "indices" : [ 19, 23 ]
    }, {
      "text" : "ifng",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "karlsruhe",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1857617528",
  "text" : "RT @Piratenpartei: #CDU- stellt Ultimatum f\u00FCr \u201CIntel Friday Night Game\u201D-Verbot: http:\/\/bit.ly\/yOymb  #ifng #karlsruhe",
  "id" : 1857617528,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Fricke",
      "screen_name" : "JacobFricke",
      "indices" : [ 0, 12 ],
      "id_str" : "855001460",
      "id" : 855001460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1857662565",
  "text" : "@jacobfricke Ger\u00FCchte streuen f\u00FCr Anf\u00E4nger :)",
  "id" : 1857662565,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Fricke",
      "screen_name" : "JacobFricke",
      "indices" : [ 68, 80 ],
      "id_str" : "855001460",
      "id" : 855001460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1857696635",
  "text" : "David Hasselhoff ist tot. Betrunken am Burger erstickt! Plz RT (via @jacobfricke )",
  "id" : 1857696635,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1857867289",
  "text" : "@eXpSpAwN Ich glaube nicht, vielleicht werden dann erst noch b\u00F6se Filme und andere Medien verboten....",
  "id" : 1857867289,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "science",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1857946911",
  "text" : "Neuer W&W-Post: Wissenschaft & Medien II - Aus ethischen Gr\u00FCnden... http:\/\/tr.im\/lRAH #wundw #science #wissenschaft",
  "id" : 1857946911,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1857948513",
  "text" : "@eXpSpAwN Den Gefallen werden die uns glaube ich nie machen. Auch wenn es w\u00FCnschenswert ist.",
  "id" : 1857948513,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Hissting",
      "screen_name" : "ahissting",
      "indices" : [ 0, 10 ],
      "id_str" : "22149779",
      "id" : 22149779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1857962468",
  "geo" : { },
  "id_str" : "1857983315",
  "in_reply_to_user_id" : 22149779,
  "text" : "@ahissting Gibt es da Zahlen\/Umfragen zu?In welchem Ma\u00DFe das Wissen zur gr\u00FCnen Gentechnik steigt und die Akzeptanz sinkt?Belehrung erw\u00FCnscht",
  "id" : 1857983315,
  "in_reply_to_status_id" : 1857962468,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahissting",
  "in_reply_to_user_id_str" : "22149779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CDU",
      "indices" : [ 89, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1857991503",
  "geo" : { },
  "id_str" : "1858006116",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Leider klappt das offensichtlich mit der Wahl ja auch wenn man scheisse ist. Die #CDU- zehrt halt von der Renterbasis.",
  "id" : 1858006116,
  "in_reply_to_status_id" : 1857991503,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1857991503",
  "geo" : { },
  "id_str" : "1858007760",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod B\u00F6se gesagt: Fr\u00FCher NSDAP jetzt CDU ;)",
  "id" : 1858007760,
  "in_reply_to_status_id" : 1857991503,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Hissting",
      "screen_name" : "ahissting",
      "indices" : [ 0, 10 ],
      "id_str" : "22149779",
      "id" : 22149779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1858010548",
  "geo" : { },
  "id_str" : "1858032777",
  "in_reply_to_user_id" : 22149779,
  "text" : "@ahissting Das ist mal eine coole Kampagne!",
  "id" : 1858032777,
  "in_reply_to_status_id" : 1858010548,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahissting",
  "in_reply_to_user_id_str" : "22149779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1858031296",
  "geo" : { },
  "id_str" : "1858034438",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Meinst die Sterben nicht so bald aus? ;)",
  "id" : 1858034438,
  "in_reply_to_status_id" : 1858031296,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1858038561",
  "geo" : { },
  "id_str" : "1858061476",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Der Name, und die NSDAP hatte mehr W\u00E4hler :P",
  "id" : 1858061476,
  "in_reply_to_status_id" : 1858038561,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1858067091",
  "geo" : { },
  "id_str" : "1858119513",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja, aber auch die wird nicht unendlich ausgedehnt werden. ;)",
  "id" : 1858119513,
  "in_reply_to_status_id" : 1858067091,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cdu",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1858081713",
  "geo" : { },
  "id_str" : "1858129220",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod F\u00FCr die #cdu- war halt fr\u00FCher alles besser ;)",
  "id" : 1858129220,
  "in_reply_to_status_id" : 1858081713,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Hissting",
      "screen_name" : "ahissting",
      "indices" : [ 0, 10 ],
      "id_str" : "22149779",
      "id" : 22149779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1858247014",
  "geo" : { },
  "id_str" : "1858312862",
  "in_reply_to_user_id" : 22149779,
  "text" : "@ahissting Ok, werde ich suchen. Danke. Das d\u00FCrfte dir gefallen: http:\/\/tr.im\/lRRD :)",
  "id" : 1858312862,
  "in_reply_to_status_id" : 1858247014,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahissting",
  "in_reply_to_user_id_str" : "22149779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 44, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1858321752",
  "text" : "Neuer W&W-Post: Fossilien http:\/\/tr.im\/lRRQ #wundw",
  "id" : 1858321752,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1858364120",
  "text" : "Mit Offlinern diskutieren ist so anstrengend. Fragen bl\u00F6d nach Quellen und man kann keinen Link zur Untermauerung schicken.",
  "id" : 1858364120,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 3, 15 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1859449212",
  "text" : "RT @houellebeck: Und da wir dabei sind: alternatives StarWars Ende im Hillbilly-Style: http:\/\/pown.it\/wiipown.php?uid=3299",
  "id" : 1859449212,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1860754733",
  "text" : "Hund mit dem Schlauch waschen ist Krieg!",
  "id" : 1860754733,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1856362125",
  "text" : "Morgen! *g\u00E4hn*",
  "id" : 1856362125,
  "created_at" : "2009-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joachim Mueller-Jung",
      "screen_name" : "MuellerJung",
      "indices" : [ 3, 15 ],
      "id_str" : "18729349",
      "id" : 18729349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1845040983",
  "text" : "RT @MuellerJung: Luxusthema Wissenschaft? Ganz schlechtes Signal:Neues Krisenopfer - SZ stellt Wissensmagazin ein. http:\/\/arm.in\/398",
  "id" : 1845040983,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Fricke",
      "screen_name" : "JacobFricke",
      "indices" : [ 0, 12 ],
      "id_str" : "855001460",
      "id" : 855001460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1845312245",
  "text" : "@jacobfricke Aber wenn der Trend so weiter geht dann gibt\u2019s bald gar keine Wissenschaft mehr in den Medien",
  "id" : 1845312245,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1845298272",
  "geo" : { },
  "id_str" : "1845314668",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Das w\u00FCrde ich aber nicht den Myers h\u00F6ren lassen. Sonst jagt er seine Horden zu ihm ;)",
  "id" : 1845314668,
  "in_reply_to_status_id" : 1845298272,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 11, 20 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1845334385",
  "geo" : { },
  "id_str" : "1845346012",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Argent23 Die Invasion droht immer, \u00FCberall und jeder Zeit :)",
  "id" : 1845346012,
  "in_reply_to_status_id" : 1845334385,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1845350642",
  "text" : "RT @Fischblog: Ist ein T-Shirt mit der Aufschrift \"Gaskammern - es kommt drauf an wen man reinsteckt\" schon strafbar?",
  "id" : 1845350642,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau_Biene",
      "screen_name" : "Frau_Biene",
      "indices" : [ 16, 27 ],
      "id_str" : "20837429",
      "id" : 20837429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1845446340",
  "text" : "@NicoleRensmann @Frau_Biene So untragbar finde ich das gar nicht muss ich sagen. Viel mehr dass die Dinger in den USA noch in Gebrauch sind.",
  "id" : 1845446340,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1845583201",
  "geo" : { },
  "id_str" : "1845593745",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Ich hab zumindest nichts anderweitiges geh\u00F6rt und wollte wohl eigentlich da sein.",
  "id" : 1845593745,
  "in_reply_to_status_id" : 1845583201,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1846008263",
  "geo" : { },
  "id_str" : "1846021196",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Bei dem Film auch kein Wunder wenn man einschl\u00E4ft. Aber meine Freundin hat mich auch damit begl\u00FCckt ;)",
  "id" : 1846021196,
  "in_reply_to_status_id" : 1846008263,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1846177741",
  "text" : "Wenn jemand \u00FCber #fail bescheid weiss dann wohl er: http:\/\/tr.im\/lKIK",
  "id" : 1846177741,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceBlogs",
      "screen_name" : "ScienceBlogs_de",
      "indices" : [ 0, 16 ],
      "id_str" : "15072786",
      "id" : 15072786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1846654435",
  "geo" : { },
  "id_str" : "1846695329",
  "in_reply_to_user_id" : 15072786,
  "text" : "@ScienceBlogs_de Die Werbung ganz rechts finde ich immer noch nicht ideal positioniert. Bei 1200px Breite im Browser(ff) muss ich scrollen.",
  "id" : 1846695329,
  "in_reply_to_status_id" : 1846654435,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ScienceBlogs_de",
  "in_reply_to_user_id_str" : "15072786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1846909812",
  "geo" : { },
  "id_str" : "1847054243",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ach f\u00FCr die ganz arge Langeweile ist \/b\/ ideal ;)",
  "id" : 1847054243,
  "in_reply_to_status_id" : 1846909812,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1847116258",
  "geo" : { },
  "id_str" : "1847426602",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Screenshot aus Bob Dylans Video zu Subterrean Homesick Blues und er h\u00E4lt gerade die Karte mit FAIL hoch.",
  "id" : 1847426602,
  "in_reply_to_status_id" : 1847116258,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1847443187",
  "text" : "Und nochmal 2 Unterst\u00FCtzer f\u00FCr die NRW-Piraten gefunden. M\u00FChsam ern\u00E4hrt sich...",
  "id" : 1847443187,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1849263060",
  "text" : "Also das ist ja schon ein bisschen peinlich oder? http:\/\/tr.im\/lMTn",
  "id" : 1849263060,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Spiegler",
      "screen_name" : "andreasspiegler",
      "indices" : [ 0, 16 ],
      "id_str" : "14395111",
      "id" : 14395111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1849360556",
  "geo" : { },
  "id_str" : "1849417847",
  "in_reply_to_user_id" : 14395111,
  "text" : "@andreasspiegler Und ich dachte immer das literweise Cola trinken unglaublich gesund w\u00E4re?! Ich bin schockiert! ;)",
  "id" : 1849417847,
  "in_reply_to_status_id" : 1849360556,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "andreasspiegler",
  "in_reply_to_user_id_str" : "14395111",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rozana Renger",
      "screen_name" : "Rozana",
      "indices" : [ 0, 7 ],
      "id_str" : "6085542",
      "id" : 6085542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1851309060",
  "geo" : { },
  "id_str" : "1851345253",
  "in_reply_to_user_id" : 6085542,
  "text" : "@Rozana Lange Haare sind immer Super! :)",
  "id" : 1851345253,
  "in_reply_to_status_id" : 1851309060,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Rozana",
  "in_reply_to_user_id_str" : "6085542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pascal",
      "screen_name" : "augensound",
      "indices" : [ 0, 11 ],
      "id_str" : "18762141",
      "id" : 18762141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1851370920",
  "geo" : { },
  "id_str" : "1851399259",
  "in_reply_to_user_id" : 18762141,
  "text" : "@augensound geiles Foto! Wirklich zum Knutschen :)",
  "id" : 1851399259,
  "in_reply_to_status_id" : 1851370920,
  "created_at" : "2009-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "augensound",
  "in_reply_to_user_id_str" : "18762141",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1833540200",
  "text" : "@houellebeck Epic! :)",
  "id" : 1833540200,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1833650483",
  "geo" : { },
  "id_str" : "1833662038",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Was kostet die Pro denn nun?",
  "id" : 1833662038,
  "in_reply_to_status_id" : 1833650483,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    }, {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 59, 66 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1833681929",
  "geo" : { },
  "id_str" : "1833689920",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Wenn du das Programm offen hast klick mal oben auf @compod zwischen refresh und neuen tweet schreiben. Dann kommst du ins Acc-Men\u00FC",
  "id" : 1833689920,
  "in_reply_to_status_id" : 1833681929,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1833701362",
  "geo" : { },
  "id_str" : "1833717583",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Stimmt, irgendwo steht das aber im \u201CHandbuch\u201D :)",
  "id" : 1833717583,
  "in_reply_to_status_id" : 1833701362,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1833737088",
  "geo" : { },
  "id_str" : "1833790618",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Dann hab ich es vielleicht in den Beta-Anleitungen irgendwo gelesen. Auf jedenfall weisst du nun wo es ist :)",
  "id" : 1833790618,
  "in_reply_to_status_id" : 1833737088,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1833798599",
  "geo" : { },
  "id_str" : "1833807413",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Und was denkst du bislang dr\u00FCber? :)",
  "id" : 1833807413,
  "in_reply_to_status_id" : 1833798599,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1834137594",
  "geo" : { },
  "id_str" : "1834147172",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Liste der Links und Tags? Die vorher da verlinkt war wo jetzt die Favorite-Funktion ist?",
  "id" : 1834147172,
  "in_reply_to_status_id" : 1834137594,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wissenschaft",
      "indices" : [ 68, 81 ]
    }, {
      "text" : "science",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "wundw",
      "indices" : [ 91, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1834173833",
  "text" : "Neuer W&W-Post: Open Access Teil 6 - Eine Vision? http:\/\/tr.im\/lDvA #wissenschaft #science #wundw",
  "id" : 1834173833,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1834201661",
  "geo" : { },
  "id_str" : "1834222269",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Okay, also ich vermisse das gar nicht muss ich sagen. Finde das klicken im Tweet viel angenehmer weil schneller.",
  "id" : 1834222269,
  "in_reply_to_status_id" : 1834201661,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1834252889",
  "text" : "Laufe nun mit Werbung rum.  http:\/\/twitpic.com\/5f31c",
  "id" : 1834252889,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1834410947",
  "geo" : { },
  "id_str" : "1834423839",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Viele Unis mit Abos machen aber den gr\u00F6\u00DFten Haufen ;)",
  "id" : 1834423839,
  "in_reply_to_status_id" : 1834410947,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al from Hell",
      "screen_name" : "AlFromHell",
      "indices" : [ 0, 11 ],
      "id_str" : "192547961",
      "id" : 192547961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1834427185",
  "text" : "@alfromhell Das ist doch auch genau der Eindruck den alle von Blogs, Foren, Mailinglists und Newsgroups haben. Warum sollte das hier nicht?",
  "id" : 1834427185,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1834430288",
  "geo" : { },
  "id_str" : "1834448178",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Naja der Knopf war auch nicht viel gr\u00F6\u00DFer den man dr\u00FCcken musste. Und dazu war es halt ein Klick mehr. Mach die Schrift gr\u00F6\u00DFer?",
  "id" : 1834448178,
  "in_reply_to_status_id" : 1834430288,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1834492824",
  "text" : "Neuer Blogpost: Plakate kleben http:\/\/tr.im\/lDL8",
  "id" : 1834492824,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al from Hell",
      "screen_name" : "AlFromHell",
      "indices" : [ 0, 11 ],
      "id_str" : "192547961",
      "id" : 192547961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1834495386",
  "text" : "@alfromhell Ich find ja auch Twitter total doof. Dieses ganze Social Zeug ist \u00E4tzend. Brauch kein Mensch! ;)",
  "id" : 1834495386,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1834473899",
  "geo" : { },
  "id_str" : "1834496753",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Stimmt, aber die Gefahr die Abos zu verlieren wenn man so nen Mist macht mag denen zu gro\u00DF sein.",
  "id" : 1834496753,
  "in_reply_to_status_id" : 1834473899,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1834542281",
  "text" : "@houellebeck Der n\u00E4chste Stammtisch ist f\u00FCr den 25. um 19:00 in der Blechtrommel geplant.",
  "id" : 1834542281,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beatrice Lugger",
      "screen_name" : "BLugger",
      "indices" : [ 0, 8 ],
      "id_str" : "14699615",
      "id" : 14699615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1834531928",
  "geo" : { },
  "id_str" : "1834560171",
  "in_reply_to_user_id" : 14699615,
  "text" : "@Blugger Das sind doch schon ganz ordentliche Summen.",
  "id" : 1834560171,
  "in_reply_to_status_id" : 1834531928,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "BLugger",
  "in_reply_to_user_id_str" : "14699615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DailyAtheist",
      "screen_name" : "DailyAtheist",
      "indices" : [ 3, 16 ],
      "id_str" : "20831583",
      "id" : 20831583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1834672303",
  "text" : "RT @DailyAtheist: I only worship Santa Claus... He's the only mythological figure who leaves evidence! ~ Esiah Zakite",
  "id" : 1834672303,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1834653315",
  "geo" : { },
  "id_str" : "1834675646",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod wie gesagt; mal die Schrift auf gro\u00DF gestellt? ;)",
  "id" : 1834675646,
  "in_reply_to_status_id" : 1834653315,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1835506992",
  "text" : "Guitar Pro sieht in der Mac-Version ja mal richtig Kacke aus. Sogar im Vergleich zur Win-Version die keine Sch\u00F6nheit ist.",
  "id" : 1835506992,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1836330908",
  "text" : "Grandioser Musiker, der war in M\u00FCnster und ich hab es verpasst. Bl\u00F6de Sache: http:\/\/www.myspace.com\/mrknutur",
  "id" : 1836330908,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1837155075",
  "text" : "Neuer W&W-Post: \u00D6sterreich bleibt doch beim CERN http:\/\/tr.im\/lFAU #wundw",
  "id" : 1837155075,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 103, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1837188339",
  "text" : "Bierologie.org endlich unter Creative Commons lizensiert. Unser Open Access-Beitrag: http:\/\/tr.im\/lFGr #wundw",
  "id" : 1837188339,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1837426182",
  "text" : "Neuer Blogpost: Deutschlands Urlaubsfotos 2009 - Ein Fotowettbewerb http:\/\/tr.im\/lFQ9",
  "id" : 1837426182,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1838807895",
  "text" : "Noch 2 Unterst\u00FCtzer-Stimmen f\u00FCr die #Piraten+ gesammelt!",
  "id" : 1838807895,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1839028038",
  "geo" : { },
  "id_str" : "1839273749",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Dirty Dancing?",
  "id" : 1839273749,
  "in_reply_to_status_id" : 1839028038,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1839348680",
  "text" : "Neuer Blogpost von Dominik: Ein paar Gedanken (auch zur anstehenden Wahl): http:\/\/tr.im\/lH2B",
  "id" : 1839348680,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1840028507",
  "text" : "Ein Geschlecht einer Spezies als Gattung zu bezeichnen ist wohl Taxonomie-Fail!",
  "id" : 1840028507,
  "created_at" : "2009-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1829163434",
  "text" : "http:\/\/twitpic.com\/5dwqa - Andere Saiten aufziehen ist eine bl\u00F6de Aufgabe. Aber der Klang lohnt sich",
  "id" : 1829163434,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1829172403",
  "text" : "Wieso kann ich eigentlich schon wieder nicht per Twitterfon twitpicen?",
  "id" : 1829172403,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 22, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1829299696",
  "text" : "Ich geh nun schlafen! #gn8",
  "id" : 1829299696,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1824587879",
  "text" : "Gro\u00DFartiges GIF: http:\/\/tr.im\/lzmF",
  "id" : 1824587879,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1824723243",
  "text" : "Zecken entfernen beim Hund ist immer ein Kampf. Wieso sollte er mich auch mit einem Pinzette an seinem Fell rumziehen lassen?",
  "id" : 1824723243,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1824755777",
  "geo" : { },
  "id_str" : "1824760039",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Ja das bekommt er auch regelm\u00E4ssig aufgetragen. Allerdings ist das halt kein 100%iger Schutz so das Handarbeit \u00FCbrig bleibt. :)",
  "id" : 1824760039,
  "in_reply_to_status_id" : 1824755777,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1824796272",
  "geo" : { },
  "id_str" : "1824813180",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ja, DM mir mal deine Email-Adresse",
  "id" : 1824813180,
  "in_reply_to_status_id" : 1824796272,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1824796272",
  "geo" : { },
  "id_str" : "1824823292",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ah, Impressum gefunden. Solltest Mail haben. \u00DCbrigens sind DOI-Angaben einfacher :)",
  "id" : 1824823292,
  "in_reply_to_status_id" : 1824796272,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1824815276",
  "geo" : { },
  "id_str" : "1824833741",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Ja das ist schon toll. Manchmal \u00FCberlege ich ob ich mir das nicht auch mal ins Fell reiben sollte ;)",
  "id" : 1824833741,
  "in_reply_to_status_id" : 1824815276,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1824864800",
  "geo" : { },
  "id_str" : "1824906828",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ah, naja ging ja auch per Google fast genauso schnell wie per DOI, \u00C4rgerlich ist es wenn man in Google nur gar nix findet.",
  "id" : 1824906828,
  "in_reply_to_status_id" : 1824864800,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1824874203",
  "geo" : { },
  "id_str" : "1824908225",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Sei froh das Philipp und ich uns zur\u00FCckgehalten haben ;)",
  "id" : 1824908225,
  "in_reply_to_status_id" : 1824874203,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1829137836",
  "text" : "Wieder da vom Plakate kleben f\u00FCr die #piraten+",
  "id" : 1829137836,
  "created_at" : "2009-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1815153661",
  "text" : "Jetzt schon wieder vor dem Rechner zum Fotos bearbeiten.",
  "id" : 1815153661,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1815228407",
  "text" : "Wenn ich jetzt sage das Wolfram Alpha total cool ist kann ich es nicht mehr benutzen weil alle es ausprobieren wollen. Oder?",
  "id" : 1815228407,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1815336506",
  "text" : "DSL 2000 saugt um Fotos in Originalgr\u00F6\u00DFe zu flickr zu exportieren. Sollte mich besser auf den Campus mit deren WLAN setzen...",
  "id" : 1815336506,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1815461876",
  "geo" : { },
  "id_str" : "1815476538",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent 1Password! Zumindest wenn du auch einen Mac hast auf den du synchen kannst :)",
  "id" : 1815476538,
  "in_reply_to_status_id" : 1815461876,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1815489825",
  "text" : "Der Hund wufft einen Sonnenschirm an!",
  "id" : 1815489825,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1815506797",
  "geo" : { },
  "id_str" : "1815512538",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Kauf dir einen Mac. Dann sind alle Probleme gel\u00F6st!",
  "id" : 1815512538,
  "in_reply_to_status_id" : 1815506797,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1815590226",
  "geo" : { },
  "id_str" : "1815611837",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ich w\u00FCrd sagen WA ist einfach noch extrem Beta. Vor allem die bereits erfassten Datens\u00E4tze sind einfach noch zu gering.",
  "id" : 1815611837,
  "in_reply_to_status_id" : 1815590226,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1815694807",
  "text" : "Wenn ich gerade schon flickr zuspamme warum dann nicht auch Twitpic!  http:\/\/twitpic.com\/5a1sp",
  "id" : 1815694807,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1815818666",
  "text" : "Neuer Blogpost: Fotos von Pater Maldun http:\/\/tr.im\/lw1k",
  "id" : 1815818666,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karim Tubin",
      "screen_name" : "Bappsack",
      "indices" : [ 0, 9 ],
      "id_str" : "103840513",
      "id" : 103840513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1816581420",
  "text" : "@Bappsack du solltest mal meinen Kamerakoffer sehen, draufstellen und dann schnell dicht machen.",
  "id" : 1816581420,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1817626709",
  "text" : "Wie zur H\u00F6lle kommt TimeMachine darauf nun ein 28 GB gro\u00DFes Backup erstellen zu m\u00FCssen? Bis 8 GB h\u00E4tte ich es aufgrund der Fotos verstanden.",
  "id" : 1817626709,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1817867857",
  "text" : "Gleich wird es ungesund: Pommes zu Mittag-\/Abendessen. Und danach dann die Magenschmerzen!",
  "id" : 1817867857,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1817951119",
  "text" : "Ich finde es mittlerweile unglaublich anstrengend ewig lange am St\u00FCck Bildbearbeitung zu machen. Vor allem f\u00FCr die Augen die M\u00FCde werden.",
  "id" : 1817951119,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitzeichner",
      "screen_name" : "Mitzeichner",
      "indices" : [ 0, 12 ],
      "id_str" : "37667542",
      "id" : 37667542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1817899211",
  "geo" : { },
  "id_str" : "1817964203",
  "in_reply_to_user_id" : 37667542,
  "text" : "@Mitzeichner Was ist das denn f\u00FCr ein Symbolbild? Besoffen Rennspiele spielen wird verboten? ;)",
  "id" : 1817964203,
  "in_reply_to_status_id" : 1817899211,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Mitzeichner",
  "in_reply_to_user_id_str" : "37667542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Esc",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "unfollow",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1819181612",
  "text" : "Alles scheint den bl\u00F6den #Esc zu schauen. Es gibt auf Twitter kein entkommen. Oder alle #unfollow ?",
  "id" : 1819181612,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "me yeah",
      "screen_name" : "meyeah",
      "indices" : [ 0, 7 ],
      "id_str" : "153145129",
      "id" : 153145129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1819186940",
  "geo" : { },
  "id_str" : "1819230208",
  "in_reply_to_user_id" : 14651021,
  "text" : "@Meyeah @Causa_Motiva einfach Twitter zu und gut ist :)",
  "id" : 1819230208,
  "in_reply_to_status_id" : 1819186940,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Pfeffermynzia",
  "in_reply_to_user_id_str" : "14651021",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1819367360",
  "geo" : { },
  "id_str" : "1819448409",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Der Eurovision Song Contest http:\/\/tr.im\/lxu2",
  "id" : 1819448409,
  "in_reply_to_status_id" : 1819367360,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1819508416",
  "text" : "Neuer W&W-Post: WolframAlpha ist sich nicht so sicher http:\/\/tr.im\/lxvB",
  "id" : 1819508416,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1820452192",
  "text" : "Wieso folgen mir immer mehr dumme oder dreiste Menschen die mit nutzloser Naturheilkunde anderen das Geld aus der Tasche ziehen wollen?",
  "id" : 1820452192,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1820549410",
  "text" : "75-j\u00E4hriger verbrennt sich in seinem Auto. Ist \u201EAbwrackpr\u00E4mie\u201C zu zynisch? http:\/\/bit.ly\/LApim",
  "id" : 1820549410,
  "created_at" : "2009-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1804139656",
  "text" : "Ah, Valve hat es \u00FCber Nacht hinbekommen \u201EKilling Floor\u201C zu ver\u00F6ffentlichen.",
  "id" : 1804139656,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1804165435",
  "text" : "Es sollte mir zu denken geben dass der Hund alle meine Socken essen will.",
  "id" : 1804165435,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Das Fr\u00E4ulein K.",
      "screen_name" : "Katzenbaer",
      "indices" : [ 0, 11 ],
      "id_str" : "19500091",
      "id" : 19500091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1804197338",
  "geo" : { },
  "id_str" : "1804305135",
  "in_reply_to_user_id" : 19500091,
  "text" : "@Katzenbaer Das ist auf jedenfall besser :)",
  "id" : 1804305135,
  "in_reply_to_status_id" : 1804197338,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Katzenbaer",
  "in_reply_to_user_id_str" : "19500091",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edzard Ernst",
      "screen_name" : "EdzardErnst",
      "indices" : [ 3, 15 ],
      "id_str" : "26992475",
      "id" : 26992475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1804317765",
  "text" : "RT @EdzardErnst: the 1st homeopathic medicine allowed to make therapeutic claims was just licenced in the uk [...]- no evidence,of course",
  "id" : 1804317765,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit Eicker",
      "screen_name" : "eicker",
      "indices" : [ 3, 10 ],
      "id_str" : "7950992",
      "id" : 7950992
    }, {
      "name" : "Kiva",
      "screen_name" : "Kiva",
      "indices" : [ 40, 45 ],
      "id_str" : "15433693",
      "id" : 15433693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1804372245",
  "text" : "RT @Eicker: Kiva is on Twitter finally: @Kiva has been used by someone else before. &#8211; Follow, Act, Help! (Please retweet.)",
  "id" : 1804372245,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1804799661",
  "text" : "Hund h\u00F6rt Frauchens Stimme aus den Lautsprechern des Telefons und dreht fast durch.",
  "id" : 1804799661,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 116, 129 ]
    }, {
      "text" : "wundw",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1806647337",
  "text" : "Neuer W&W-Post: Gesunder Alkohol? http:\/\/tr.im\/lrha Endlich ein Eintrag der fast mit dem Namen zu tun hat! #science #wissenschaft #wundw",
  "id" : 1806647337,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1806838221",
  "text" : "@JoergR Ich bin total gespannt darauf, der Screencast sah schon sehr cool aus.",
  "id" : 1806838221,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1807562285",
  "geo" : { },
  "id_str" : "1807609193",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Hab ein altes Windows Mobile-Smartphone von o2 was aber keinen Lock hat. Leider fehlt die R\u00FCckabdeckung. ;)",
  "id" : 1807609193,
  "in_reply_to_status_id" : 1807562285,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1807610477",
  "geo" : { },
  "id_str" : "1807619749",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Vergiss Twitter nicht ;)",
  "id" : 1807619749,
  "in_reply_to_status_id" : 1807610477,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1807674948",
  "text" : "Gleich geht es hier hin: http:\/\/tr.im\/lrWO",
  "id" : 1807674948,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1808125029",
  "text" : "Menge zahlender G\u00E4ste bislang: ~0",
  "id" : 1808125029,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1809904619",
  "text" : "Je sp\u00E4ter der Abend desto besser die Musik? Nicht zwingend.",
  "id" : 1809904619,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1809916946",
  "geo" : { },
  "id_str" : "1810003343",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Also hier hat mir die erste Band bislang am besten gefallen.",
  "id" : 1810003343,
  "in_reply_to_status_id" : 1809916946,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly #IsraelHHMG \uD83C\uDDEE\uD83C\uDDF1",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1810007950",
  "geo" : { },
  "id_str" : "1810031258",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin und wenn du denkst schlimmer gehts nicht mehr...",
  "id" : 1810031258,
  "in_reply_to_status_id" : 1810007950,
  "created_at" : "2009-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1796939907",
  "text" : "Ein Webcomic ganz nach meinem Geschmack: http:\/\/tr.im\/llMQ",
  "id" : 1796939907,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1797020236",
  "text" : "Neuer W&W-Post von Philipp: Die Psychologie hinter dem Kreationismus http:\/\/tr.im\/llPW",
  "id" : 1797020236,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1798540192",
  "text" : "Ich hab Angst Tweets ausversehen doppelt loszuschicken bei der Performance gerade.",
  "id" : 1798540192,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dizzy Dolittle",
      "screen_name" : "DizzyDolittle",
      "indices" : [ 0, 14 ],
      "id_str" : "38860831",
      "id" : 38860831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1798676490",
  "geo" : { },
  "id_str" : "1798706412",
  "in_reply_to_user_id" : 38860831,
  "text" : "@DizzyDolittle Immerhin geht es jetzt \u00FCberhaupt wieder. Ist schonmal ein wenig Fortschritt",
  "id" : 1798706412,
  "in_reply_to_status_id" : 1798676490,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "DizzyDolittle",
  "in_reply_to_user_id_str" : "38860831",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1798782632",
  "text" : "Gibt\u2019s hier eigentlich Leute die in einer der Buskampagnen-St\u00E4dte wohnen und w\u00E4hrend der Bus da ist einen Schlafplatz f\u00FCr mich h\u00E4tten?",
  "id" : 1798782632,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1799125358",
  "text" : "Ich sag nun #gn8",
  "id" : 1799125358,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1792650658",
  "text" : "Manchmal ist die Uni einfach zu epic Fail. Studieren sollte einfach nicht Kindergarten sein. http:\/\/tinyurl.com\/pxv3c9",
  "id" : 1792650658,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1792744749",
  "text" : "@JoergR Ja. Das ist total bescheuert. Muss mich nun per Terminalserver zu den Windowsrechnern der Uni verbinden f\u00FCr die Screenshots...",
  "id" : 1792744749,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1792805087",
  "geo" : { },
  "id_str" : "1792849440",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Ja, aber ich hab doch einen Mac? ;)",
  "id" : 1792849440,
  "in_reply_to_status_id" : 1792805087,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1793007464",
  "text" : "Hab den gro\u00DFartigen Uni-Report gerade fertig gemacht. Gr\u00F6\u00DFtes Problem: MS-Terminalserver unter MacOS ;)",
  "id" : 1793007464,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1793177485",
  "text" : "Kann man seinen Hund eigentlich Lassie-fair erziehen?",
  "id" : 1793177485,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1793737263",
  "text" : "Gerade die Briefwahlunterlagen beantragt, bevor ich das verpenne.",
  "id" : 1793737263,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1793741869",
  "text" : "Ich hab da \u00FCbrigens noch ein paar Nature-Ausgaben doppelt. Interessenten?",
  "id" : 1793741869,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1793750216",
  "text" : "@JoergR Ich kann dir noch die letzten beiden Ausgaben anbieten. Schick mir einfach eine Mail oder DM mit der Adresse :)",
  "id" : 1793750216,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1793763783",
  "geo" : { },
  "id_str" : "1793871984",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Nee, aber der Verlag ist wohl zu bl\u00F6d das mit den Aboverl\u00E4ngerungen hinzukriegen.",
  "id" : 1793871984,
  "in_reply_to_status_id" : 1793763783,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TillaPe",
      "screen_name" : "TillaPe",
      "indices" : [ 0, 8 ],
      "id_str" : "14623695",
      "id" : 14623695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1794822303",
  "geo" : { },
  "id_str" : "1795026865",
  "in_reply_to_user_id" : 14623695,
  "text" : "@TillaPe \u201CSie\u201D? ;)",
  "id" : 1795026865,
  "in_reply_to_status_id" : 1794822303,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "TillaPe",
  "in_reply_to_user_id_str" : "14623695",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1795414005",
  "text" : "@houellebeck Bald wirst du zensiert, wegen Verbreitung terroristischer Inhalte!",
  "id" : 1795414005,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1795469825",
  "text" : "@houellebeck Na was denn sonst? ;)",
  "id" : 1795469825,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1795527766",
  "geo" : { },
  "id_str" : "1795557268",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Viel Spa\u00DF beim Date :)",
  "id" : 1795557268,
  "in_reply_to_status_id" : 1795527766,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1795856702",
  "text" : "Bin heute tr\u00E4ge. Kaum getwittert und noch weniger gebloggt.",
  "id" : 1795856702,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1796404552",
  "text" : "Ich glaube die Rentner bilden die Berufsgruppe die am st\u00E4rksten gestresst ist. Nie Zeit & St\u00E4ndig was zu meckern...",
  "id" : 1796404552,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piraten",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1796469161",
  "text" : "Gibt\u2019s hier eigentlich noch M\u00FCnsteraner #Piraten die etwas hiervon gebrauchen k\u00F6nnten? http:\/\/tr.im\/llv5",
  "id" : 1796469161,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Besimo",
      "screen_name" : "Besimo",
      "indices" : [ 0, 7 ],
      "id_str" : "15787781",
      "id" : 15787781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1796604542",
  "geo" : { },
  "id_str" : "1796694113",
  "in_reply_to_user_id" : 15787781,
  "text" : "@Besimo Bei Canon: Ja!",
  "id" : 1796694113,
  "in_reply_to_status_id" : 1796604542,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "Besimo",
  "in_reply_to_user_id_str" : "15787781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1796890043",
  "text" : "@cptMarco Und wie gro\u00DF d\u00FCrfte es so sein? ;)",
  "id" : 1796890043,
  "created_at" : "2009-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1777585728",
  "geo" : { },
  "id_str" : "1782020275",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Punkhunde?! Pics or it didn't happen!",
  "id" : 1782020275,
  "in_reply_to_status_id" : 1777585728,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1782072518",
  "geo" : { },
  "id_str" : "1782129696",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Mit dem einen Gramm kannste auch die Habil machen oder? ;)",
  "id" : 1782129696,
  "in_reply_to_status_id" : 1782072518,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1782057537",
  "geo" : { },
  "id_str" : "1782131891",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ok. Kannst ja verbloggen ;)",
  "id" : 1782131891,
  "in_reply_to_status_id" : 1782057537,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1782151353",
  "text" : "Der Mathe-Dozent tut mir leid. 99% der Bio-Studenten hier sind dumm genug zu glauben dass sie Statistik nicht brauchen. In Korea vielleicht.",
  "id" : 1782151353,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1782742627",
  "text" : "Neuer W&W-Post: \u00D6sterreich steigt beim CERN aus http:\/\/tr.im\/ldm8",
  "id" : 1782742627,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1782823763",
  "geo" : { },
  "id_str" : "1782839144",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Oder Elsevier nicht f\u00FCr das passende Journal bezahlen konnten :D",
  "id" : 1782839144,
  "in_reply_to_status_id" : 1782823763,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1782848489",
  "geo" : { },
  "id_str" : "1782858078",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ach gibt doch Biologen ohne Ende in der Medizin. Als ob Mediziner richtige Forschung k\u00F6nnten :D",
  "id" : 1782858078,
  "in_reply_to_status_id" : 1782848489,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1782886545",
  "text" : "Wahrscheinlichkeitsb\u00E4ume find ich ja total knuffig. Und Leute die an dem Konzept schon scheitern auch.",
  "id" : 1782886545,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1782914604",
  "geo" : { },
  "id_str" : "1782980261",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Versuchs doch bei der pl0gbar und den Tweetups. Sonst gibt es ja auch heute Abend einen Termin :)",
  "id" : 1782980261,
  "in_reply_to_status_id" : 1782914604,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1782985059",
  "geo" : { },
  "id_str" : "1783006460",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Heut Abend ist Stammtisch der Piraten in der Blechtrommel, ab 19:00 Uhr",
  "id" : 1783006460,
  "in_reply_to_status_id" : 1782985059,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1783009409",
  "text" : "@eXpSpAwN Oha, bist du nun im Web 2.0 angekommen? :)",
  "id" : 1783009409,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1783015427",
  "geo" : { },
  "id_str" : "1783095906",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Schade, aber wird bestimmt nochmal vorkommen :)",
  "id" : 1783095906,
  "in_reply_to_status_id" : 1783015427,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1783096673",
  "text" : "@eXpSpAwN Na ist doch gar nicht so schlimm oder? :)",
  "id" : 1783096673,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1783109999",
  "text" : "Installiere 10.5.7. Bei Windows w\u00E4re das der Zeitpunkt gl\u00E4ubig zu werden und zu beten. Zu Bill Gates oder so.",
  "id" : 1783109999,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1783160814",
  "text" : "@eXpSpAwN Die kann nat\u00FCrlich niemand ausschliessen. Wobei zumindest das unmoralisch werden durch Facebook & Twitter ist ja quatsch ;)",
  "id" : 1783160814,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Piratenpartei",
      "indices" : [ 57, 71 ]
    }, {
      "text" : "Zensursula",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1783162515",
  "text" : "Gibt es eigentlich irgendwo einen Pagepeel zu den Themen #Piratenpartei und #Zensursula ?",
  "id" : 1783162515,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1783520552",
  "text" : "Paypal, Click&Buy und vor allem iTunes sind Schuld daran wenn ich mich pleite kaufe!",
  "id" : 1783520552,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 0, 10 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1783462835",
  "geo" : { },
  "id_str" : "1783522686",
  "in_reply_to_user_id" : 1024351,
  "text" : "@Labuschin viel Erfolg!",
  "id" : 1783522686,
  "in_reply_to_status_id" : 1783462835,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "Labuschin",
  "in_reply_to_user_id_str" : "1024351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1785361719",
  "text" : "Neuer Blogpost: Wenn man nur will... http:\/\/tr.im\/lfi3",
  "id" : 1785361719,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1785495911",
  "text" : "Hier ihr M\u00FCnsteraner Mac-User und Naturwissenschafts-Studenten: Bekommt ihr momentan Zugriff auf die Terminalserver?",
  "id" : 1785495911,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1785585742",
  "text" : "Ist es eigentlich von Twitter klug die Downtime um 12 Uhr mittags f\u00FCr deren Zeitzone zu machen? Wie sollen man dann ihr Lunch tweeten?",
  "id" : 1785585742,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1785656754",
  "text" : "Neuer Blogpost: Furby IRL http:\/\/tr.im\/lfuY",
  "id" : 1785656754,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1786029981",
  "text" : "Neuer W&W-Post: Ein Leben lang... http:\/\/tr.im\/lfLt",
  "id" : 1786029981,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1786148782",
  "text" : "Ich mach mich nun auf den Weg zum Piratenstammtisch in der Blechtrommel.",
  "id" : 1786148782,
  "created_at" : "2009-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1776789155",
  "text" : "@danishkirel Die neuste Firefox-Beta hat noch mehr Funktionen f\u00FCr Multitouch :)",
  "id" : 1776789155,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1776831912",
  "geo" : { },
  "id_str" : "1776842630",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ Stimmt, weil man Paintball vor allem alleine in seinem Keller spielt um Amokl\u00E4ufe vorzubereiten.",
  "id" : 1776842630,
  "in_reply_to_status_id" : 1776831912,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1776883002",
  "text" : "@danishkirel Ich finde Safari bis heute ganz grausig. Au\u00DFerdem liebe ich alle meine FF-Addons die ich so t\u00E4glich benutze.",
  "id" : 1776883002,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1776985313",
  "text" : "@danishkirel Apple sollte mal die Addon-Menge von Firefox klauen. Dann w\u00FCrde ich wohl wechseln ;)",
  "id" : 1776985313,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1777200408",
  "geo" : { },
  "id_str" : "1777232710",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Sehr cooler Film. Ich fand ihn sehr unterhaltsam :)",
  "id" : 1777232710,
  "in_reply_to_status_id" : 1777200408,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Thielecke",
      "screen_name" : "mthie",
      "indices" : [ 0, 6 ],
      "id_str" : "3253641",
      "id" : 3253641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1777320191",
  "geo" : { },
  "id_str" : "1777346872",
  "in_reply_to_user_id" : 3253641,
  "text" : "@mthie Alles Auto-Zur\u00FCckfollower?",
  "id" : 1777346872,
  "in_reply_to_status_id" : 1777320191,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "mthie",
  "in_reply_to_user_id_str" : "3253641",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1777426484",
  "text" : "Menschen die ihren Hunden bunte Kleidchen anziehen sollte man entm\u00FCndigen. Und der Hund sollte die Vormundschaft bekommen!",
  "id" : 1777426484,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Senger",
      "screen_name" : "rhineduck",
      "indices" : [ 0, 10 ],
      "id_str" : "21312796",
      "id" : 21312796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1777492822",
  "geo" : { },
  "id_str" : "1777506997",
  "in_reply_to_user_id" : 21312796,
  "text" : "@rhineduck Ich habe da das umgekehrte Problem. Siezen f\u00E4llt mir schwer.",
  "id" : 1777506997,
  "in_reply_to_status_id" : 1777492822,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "rhineduck",
  "in_reply_to_user_id_str" : "21312796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bologna",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "wundw",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1771162605",
  "text" : "Neuer W&W-Post: Bologna vs Bolognese Teil 7 - Professor schmeisst seinen Job http:\/\/tr.im\/l6yI #bologna #wundw",
  "id" : 1771162605,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1771174434",
  "text" : "\u201CEines dieser Themen war eben die Sexuelle Revolution, die sehr schnell mehrere Sto\u00DFrichtungen entfaltete\u201D Was soll man dazu sagen?",
  "id" : 1771174434,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1771234378",
  "geo" : { },
  "id_str" : "1771652662",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Gute M\u00F6glichkeit",
  "id" : 1771652662,
  "in_reply_to_status_id" : 1771234378,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 11, 18 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1771918370",
  "geo" : { },
  "id_str" : "1771942833",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @JoergR Und bei manchen Papern bin ich mir nichtmal sicher ob die \u00FCberhaupt die 140 Zeichen im Reviewprozess benutzen...",
  "id" : 1771942833,
  "in_reply_to_status_id" : 1771918370,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "science",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "wundw",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1772226558",
  "text" : "Neuer W&W-Post von Philipp: Wissenschaft in den Medien - Schweinegrippe auf vern\u00FCnftige Art http:\/\/tr.im\/l7jZ #PRLit #science #wundw",
  "id" : 1772226558,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1772271358",
  "text" : "Gibt es eigentlich ein WP-Plugin was automatisch ein Header-Bild in den Beitrag einf\u00FCgt je nach Kategorie in der gepostet wird?",
  "id" : 1772271358,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly #IsraelHHMG \uD83C\uDDEE\uD83C\uDDF1",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1772508524",
  "geo" : { },
  "id_str" : "1772510334",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Und, welche Konsistenz hat der Kot? ;)",
  "id" : 1772510334,
  "in_reply_to_status_id" : 1772508524,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1773969752",
  "text" : "So gef\u00E4hrlich sieht der Hund gar nicht aus!",
  "id" : 1773969752,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1773986221",
  "text" : "Und mit Twitpic macht es Sinn:  http:\/\/twitpic.com\/51bkx",
  "id" : 1773986221,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1774325527",
  "geo" : { },
  "id_str" : "1774420591",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 das k\u00F6nnte es sein! Wobei das Tier sieht schon gerupft aus",
  "id" : 1774420591,
  "in_reply_to_status_id" : 1774325527,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1774577621",
  "text" : "@JoergR \u201EDie Freak-Parteien\u201C",
  "id" : 1774577621,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1775795041",
  "text" : "Ich will einen ordentlichen Serverbrowser f\u00FCr L4D...",
  "id" : 1775795041,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1775819843",
  "text" : "Grandiose iPhone-App-Idee, nie mehr gegen Laternenpfosten laufen: http:\/\/tr.im\/l9PD",
  "id" : 1775819843,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilona S",
      "screen_name" : "mazoe28",
      "indices" : [ 0, 8 ],
      "id_str" : "18527855",
      "id" : 18527855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1775917300",
  "geo" : { },
  "id_str" : "1775947748",
  "in_reply_to_user_id" : 18527855,
  "text" : "@Mazoe28 Ich hab von Sigma 10 mm und 20 mm Festbrennweiten. Bin mit Sigma auch sehr zufrieden :)",
  "id" : 1775947748,
  "in_reply_to_status_id" : 1775917300,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "mazoe28",
  "in_reply_to_user_id_str" : "18527855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1775954740",
  "geo" : { },
  "id_str" : "1775985991",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva C-was? :)",
  "id" : 1775985991,
  "in_reply_to_status_id" : 1775954740,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1776003955",
  "geo" : { },
  "id_str" : "1776102431",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Klaut SpOn jetzt Textideen? ;)",
  "id" : 1776102431,
  "in_reply_to_status_id" : 1776003955,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ilona S",
      "screen_name" : "mazoe28",
      "indices" : [ 0, 8 ],
      "id_str" : "18527855",
      "id" : 18527855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1776014548",
  "geo" : { },
  "id_str" : "1776105109",
  "in_reply_to_user_id" : 18527855,
  "text" : "@Mazoe28 Vor allem f\u00FCr den Preis kann man da \u00FCberhaupt nicht meckern :)",
  "id" : 1776105109,
  "in_reply_to_status_id" : 1776014548,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "mazoe28",
  "in_reply_to_user_id_str" : "18527855",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1776775301",
  "geo" : { },
  "id_str" : "1776783856",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ Kinderpornokopiererm\u00F6rder!",
  "id" : 1776783856,
  "in_reply_to_status_id" : 1776775301,
  "created_at" : "2009-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1760555701",
  "text" : "Jetzt mit Dad ins UKM. Viel zu fr\u00FCh an morgen f\u00FCr Krankenh\u00E4user!",
  "id" : 1760555701,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1761458405",
  "text" : "Schilddr\u00FCsenunterfunktion",
  "id" : 1761458405,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1761475776",
  "geo" : { },
  "id_str" : "1761610626",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum Ne, mein Dad. Zusammen mit partieller \u00DCberfunktion == Chirurgische Entfernung",
  "id" : 1761610626,
  "in_reply_to_status_id" : 1761475776,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1761608119",
  "geo" : { },
  "id_str" : "1761612548",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Das lief schon, im April letzten Jahres wurden so gut wie alle Einhandmesser verboten...",
  "id" : 1761612548,
  "in_reply_to_status_id" : 1761608119,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1761849198",
  "text" : "Sehr cooler Blogpost bei Pharyngula: http:\/\/tr.im\/l0Ws",
  "id" : 1761849198,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1761863969",
  "text" : "\u00C4rgerlich wenn man Paper liest weil der Titel cool klingt aber mehr auch eigentlich nicht dabei zu holen ist.",
  "id" : 1761863969,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1761879682",
  "geo" : { },
  "id_str" : "1761939598",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Davon hab ich aber jetzt gerade nichts cooles zum Bloggen :D",
  "id" : 1761939598,
  "in_reply_to_status_id" : 1761879682,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1761947053",
  "geo" : { },
  "id_str" : "1761957829",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum Ach es gibt schlimmeres. Immerhin weiss man nun woher die ganzen Symptome kommen und kann was unternehmen.",
  "id" : 1761957829,
  "in_reply_to_status_id" : 1761947053,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1761962043",
  "geo" : { },
  "id_str" : "1761973804",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum Danke! Erstmal muss nun ein OP-Termin gefunden werden.",
  "id" : 1761973804,
  "in_reply_to_status_id" : 1761962043,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1761998538",
  "text" : "\u00DCbrigens, hier noch die letzten beiden Fotosets zu den Konzerten am Samstag: http:\/\/tr.im\/l133 & http:\/\/tr.im\/l135",
  "id" : 1761998538,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1762302695",
  "text" : "Neuer Blogpost: And Yet It Moves http:\/\/tr.im\/l1hK",
  "id" : 1762302695,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1762391020",
  "text" : "Obvious Science is obvious? http:\/\/dx.doi.org\/10.1016\/j.jesp.2008.12.009",
  "id" : 1762391020,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Nugent",
      "screen_name" : "micknugent",
      "indices" : [ 3, 14 ],
      "id_str" : "27151738",
      "id" : 27151738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1763494540",
  "text" : "RT @micknugent: \"People say we need religion when what they really mean is we need police.\" - HL Mencken",
  "id" : 1763494540,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wissenschaft",
      "indices" : [ 96, 109 ]
    }, {
      "text" : "wundw",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "science",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "PRLit",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1763656482",
  "text" : "Endlich ein neuer W&W-Post: Der erste Eindruck - Online gegen das echte Leben http:\/\/tr.im\/l2eN #wissenschaft #wundw #science #PRLit",
  "id" : 1763656482,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1763618509",
  "geo" : { },
  "id_str" : "1763666676",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ich kenn da ein paar Leute aus L\u00FCnen, die sollte ich mal fragen ;)",
  "id" : 1763666676,
  "in_reply_to_status_id" : 1763618509,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1763691023",
  "text" : "@houellebeck Super Vorlage f\u00FCr einen sexistischen Spruch w\u00FCrde ich sagen ;)",
  "id" : 1763691023,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1763740769",
  "text" : "@houellebeck W\u00FCrde ich dir auch nie unterstellen :)",
  "id" : 1763740769,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1764822632",
  "text" : "Auf auf zur Leiterrunde!",
  "id" : 1764822632,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1765834024",
  "text" : "Kein allgemeines Sommerlager dieses Jahr :( Zu wenige Anmeldungen.",
  "id" : 1765834024,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1766784695",
  "geo" : { },
  "id_str" : "1766812771",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em stimmt das so mathematisch gesehen? ;)",
  "id" : 1766812771,
  "in_reply_to_status_id" : 1766784695,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1766849275",
  "geo" : { },
  "id_str" : "1766901438",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Na ihr Mathematiker habt doch jede Menge R\u00E4ume. So als Menge beispielsweise ;)",
  "id" : 1766901438,
  "in_reply_to_status_id" : 1766849275,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 3, 16 ],
      "id_str" : "15803034",
      "id" : 15803034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1767186628",
  "text" : "RT @mendeley_com: New blog post: Mendeley Desktop v0.6.5 released http:\/\/bit.ly\/8AbIx",
  "id" : 1767186628,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gn8",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1767271290",
  "text" : "Nun ins Bett! #gn8",
  "id" : 1767271290,
  "created_at" : "2009-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1756066502",
  "text" : "Mh seitdem ich das Flickr-Plugin registriert habe zerlegt es mir die Tags beim Upload aus Lightroom zu Flickr. Fixes?",
  "id" : 1756066502,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1756207854",
  "geo" : { },
  "id_str" : "1756229888",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Wieso unglaublich? Weil es so ehrlich ist? ;)",
  "id" : 1756229888,
  "in_reply_to_status_id" : 1756207854,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 0, 13 ],
      "id_str" : "15803034",
      "id" : 15803034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1756257218",
  "geo" : { },
  "id_str" : "1756280264",
  "in_reply_to_user_id" : 15803034,
  "text" : "@mendeley_com Well done! I always wanted to learn lockpicking. Maybe i'll have to be locked out first :)",
  "id" : 1756280264,
  "in_reply_to_status_id" : 1756257218,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mendeley_com",
  "in_reply_to_user_id_str" : "15803034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1756430563",
  "text" : "Das Letzte Foto wird hochgeladen. Und dann kann ich endlich wieder das Netz benutzen.",
  "id" : 1756430563,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1756434395",
  "geo" : { },
  "id_str" : "1756482634",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Als ob der Schmierige Sack Fragen beantworten k\u00F6nnte...",
  "id" : 1756482634,
  "in_reply_to_status_id" : 1756434395,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1756519440",
  "geo" : { },
  "id_str" : "1756547554",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Standardantworten sind was tolles.",
  "id" : 1756547554,
  "in_reply_to_status_id" : 1756519440,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1756555013",
  "text" : "Irgendwie ist Twitterfon Pro heute buggy wie nichts gutes :(",
  "id" : 1756555013,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1756701123",
  "geo" : { },
  "id_str" : "1756716046",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em hey, gibt schlimmeres: Ost-Westfalen zum Beispiel ;)",
  "id" : 1756716046,
  "in_reply_to_status_id" : 1756701123,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1756955266",
  "geo" : { },
  "id_str" : "1756964644",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Ich freu mich auf den Stammtisch am Mittwoch :)",
  "id" : 1756964644,
  "in_reply_to_status_id" : 1756955266,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1752940829",
  "text" : "Mein Hund wollte eigentlich ein Schlabrador werden.",
  "id" : 1752940829,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1753185831",
  "text" : "7 GB Fotos importieren. Gut dass es dauert",
  "id" : 1753185831,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1753422615",
  "text" : "Sch\u00F6n das TimeMachine gleich alle Fotos gesichert hat. Werd gleich mal ausmisten.",
  "id" : 1753422615,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1753568621",
  "text" : "Neuer Blogpost von Dominik: Star Trek 11 http:\/\/tr.im\/kXrW",
  "id" : 1753568621,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1754007685",
  "text" : "Ich kenn da eine Webseite die gerade nicht funktioniert. Und leider ist es eine von meinen!",
  "id" : 1754007685,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1754026807",
  "text" : "Und nun geht die Seite wieder. Nur die Pingzeiten sind noch unterirdisch",
  "id" : 1754026807,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1754032879",
  "text" : "Gerade gro\u00DFz\u00FCgig an den Entwickler des Flickr-Plugins f\u00FCr Lightroom gespendet. Dieses Limit von 10 Fotos hat dann doch gest\u00F6rt ;)",
  "id" : 1754032879,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1754068969",
  "text" : "So sehr ich das fotografieren von Konzerten auch mag und die Fotos dann zum ersten mal auf einem gro\u00DFen Display zu sehen: sortieren stinkt.",
  "id" : 1754068969,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1754285477",
  "text" : "Bei dem Wetter w\u00FCrde ich ja gerne drau\u00DFen die Bilder bearbeiten. Aber dann wird das MacBook zum Schminkspiegel.",
  "id" : 1754285477,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1754359763",
  "geo" : { },
  "id_str" : "1754368464",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Nana, bitte nicht die Anf\u00FChrungszeichen vergessen. Geistes\u201Cwissenschaftler\u201D ;)",
  "id" : 1754368464,
  "in_reply_to_status_id" : 1754359763,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1754467189",
  "text" : "Die Fotos der ersten Band des gestrigen Abends sind online: http:\/\/tr.im\/kXXl",
  "id" : 1754467189,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1754522283",
  "text" : "Und hier die Fotos von \u201CDead Head Down\u201D: http:\/\/tr.im\/kXYK",
  "id" : 1754522283,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr\u00E9 Berg\u00E9r",
      "screen_name" : "flashvipe",
      "indices" : [ 0, 10 ],
      "id_str" : "19152599",
      "id" : 19152599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1754548929",
  "geo" : { },
  "id_str" : "1754560119",
  "in_reply_to_user_id" : 19152599,
  "text" : "@flashvipe Danke. Und ja laut war es. Und ich hab geschickterweise mal wieder die Ohrenst\u00F6psel irgendwo verlegt. Aber man gew\u00F6hnt sich dran.",
  "id" : 1754560119,
  "in_reply_to_status_id" : 1754548929,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "flashvipe",
  "in_reply_to_user_id_str" : "19152599",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr\u00E9 Berg\u00E9r",
      "screen_name" : "flashvipe",
      "indices" : [ 0, 10 ],
      "id_str" : "19152599",
      "id" : 19152599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1754624735",
  "geo" : { },
  "id_str" : "1754839289",
  "in_reply_to_user_id" : 19152599,
  "text" : "@flashvipe Coole Fotos, so gro\u00DF ist es hier nie :)",
  "id" : 1754839289,
  "in_reply_to_status_id" : 1754624735,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "flashvipe",
  "in_reply_to_user_id_str" : "19152599",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1755903325",
  "text" : "Und noch mehr Fotos: Path Of Golconda http:\/\/tr.im\/kYBF",
  "id" : 1755903325,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 0, 13 ],
      "id_str" : "15803034",
      "id" : 15803034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1755903197",
  "geo" : { },
  "id_str" : "1755906477",
  "in_reply_to_user_id" : 15803034,
  "text" : "@mendeley_com He will charge you a lot for about 5 minutes of work ;)",
  "id" : 1755906477,
  "in_reply_to_status_id" : 1755903197,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mendeley_com",
  "in_reply_to_user_id_str" : "15803034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team Mendeley",
      "screen_name" : "mendeley_com",
      "indices" : [ 0, 13 ],
      "id_str" : "15803034",
      "id" : 15803034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1755934020",
  "geo" : { },
  "id_str" : "1755970162",
  "in_reply_to_user_id" : 15803034,
  "text" : "@mendeley_com Thats about the amount of money i guessed. Learning lockpicking has the big advantage of saving those pounds in future.",
  "id" : 1755970162,
  "in_reply_to_status_id" : 1755934020,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mendeley_com",
  "in_reply_to_user_id_str" : "15803034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 3, 12 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1755972504",
  "text" : "RT @Argent23: Sowas kann man nicht erfinden: Slogan der Katholischen Frauengemeinschaft Deutschlands? \"Eine Gemeinschaft die tr\u00E4gt\"",
  "id" : 1755972504,
  "created_at" : "2009-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1744881967",
  "text" : "Sollte nicht zum aufstehen schon christlich-radikale Propaganda lesen. Verdirbt den Tag. L\u00E4sst einen aber wach werden.",
  "id" : 1744881967,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1745321698",
  "text" : "So geht denn nun Twitpic via Twitterfon wieder?  http:\/\/twitpic.com\/4u51r",
  "id" : 1745321698,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "autsch",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1745329588",
  "text" : "Das Letzte Foto zeigt wieso man beim \"Hol-Das-St\u00F6ckchen-Spiel\" den Finger nicht in einer Schlaufe der Schleppleine haben sollte. #autsch",
  "id" : 1745329588,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1745339591",
  "text" : "Also die npg kriegt das mit dem Abo nicht hin. Oder der deutsche Vertrieb... http:\/\/twitpic.com\/4u573",
  "id" : 1745339591,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1746216727",
  "text" : "Wenn 2 Kerle zu IKEA fahren: Inkl. 2 Stunden Fahrt in 2 1\/2 Stunden wieder zuhause angekommen. Nur noch nicht aufgebaut.",
  "id" : 1746216727,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1746366735",
  "text" : "Wieso m\u00FCssen jetzt schon wieder seit fast 10 Minuten die Glocke hier l\u00E4uten wie bescheuert? Komme doch so gar nich zum Podcasts h\u00F6ren!",
  "id" : 1746366735,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1746631684",
  "text" : "Leute die \u00FCber Fu\u00DFball twittern als g\u00E4be es kein morgen m\u00FCssen mir schon verdammt gute Gr\u00FCnde nennen um nicht unfollowt zu werden.",
  "id" : 1746631684,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1746685914",
  "text" : "Jemand hier der noch eine Nature von letzter Woche gebrauchen k\u00F6nnte? ;)",
  "id" : 1746685914,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik",
      "screen_name" : "p9y",
      "indices" : [ 0, 4 ],
      "id_str" : "18424055",
      "id" : 18424055
    }, {
      "name" : "julia stern",
      "screen_name" : "juliastern",
      "indices" : [ 9, 20 ],
      "id_str" : "160630990",
      "id" : 160630990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1746772048",
  "geo" : { },
  "id_str" : "1746788343",
  "in_reply_to_user_id" : 18424055,
  "text" : "@p9y Und @juliastern sollte man eh nicht RTn ;)",
  "id" : 1746788343,
  "in_reply_to_status_id" : 1746772048,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "p9y",
  "in_reply_to_user_id_str" : "18424055",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik",
      "screen_name" : "p9y",
      "indices" : [ 0, 4 ],
      "id_str" : "18424055",
      "id" : 18424055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1746811208",
  "geo" : { },
  "id_str" : "1746859684",
  "in_reply_to_user_id" : 18424055,
  "text" : "@p9y So w\u00FCrd ich das nicht sehen ;)",
  "id" : 1746859684,
  "in_reply_to_status_id" : 1746811208,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "p9y",
  "in_reply_to_user_id_str" : "18424055",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "julia stern",
      "screen_name" : "juliastern",
      "indices" : [ 0, 11 ],
      "id_str" : "160630990",
      "id" : 160630990
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unfollow",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1746861032",
  "text" : "@juliastern Aus dem gleichen Grund wie #unfollow SPAM",
  "id" : 1746861032,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "julia stern",
      "screen_name" : "juliastern",
      "indices" : [ 0, 11 ],
      "id_str" : "160630990",
      "id" : 160630990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1746881633",
  "text" : "@juliastern Wenn ich Werbung will mach ich Adblock aus und TV an...",
  "id" : 1746881633,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "julia stern",
      "screen_name" : "juliastern",
      "indices" : [ 0, 11 ],
      "id_str" : "160630990",
      "id" : 160630990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1746943402",
  "text" : "@juliastern Ich follow dir nicht. Und so interessant k\u00F6nnen Tweets von Menschen die Werbung in ihrer Timeline zulassen nicht sein.",
  "id" : 1746943402,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1747159212",
  "text" : "So viel Ignoranz muss ein Fake sein. Oder nicht? Mittlerweile bin ich mir bei unseren Politikern nicht mehr so sicher... http:\/\/tr.im\/kUPt",
  "id" : 1747159212,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Schmidt",
      "screen_name" : "marcoschmidt",
      "indices" : [ 0, 13 ],
      "id_str" : "14472926",
      "id" : 14472926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1747143811",
  "geo" : { },
  "id_str" : "1747182520",
  "in_reply_to_user_id" : 14472926,
  "text" : "@marcoschmidt Twitter ist ja auch recht komplex. :D",
  "id" : 1747182520,
  "in_reply_to_status_id" : 1747143811,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "marcoschmidt",
  "in_reply_to_user_id_str" : "14472926",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1747461174",
  "geo" : { },
  "id_str" : "1748081558",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em ja, nachdem ich die restlichen Antworten gesehen hab bin ich sicher das es kein Fake ist...",
  "id" : 1748081558,
  "in_reply_to_status_id" : 1747461174,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1748088383",
  "text" : "Warum zur H\u00F6lle riecht meine Kamera so derbe nach Zaziki!? Naja, solange sie noch funktioniert..",
  "id" : 1748088383,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1748100009",
  "geo" : { },
  "id_str" : "1748611397",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich kann mir auch nicht Vorstellen welche Art W\u00E4hler soetwas gutfinden sollen.",
  "id" : 1748611397,
  "in_reply_to_status_id" : 1748100009,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "julia stern",
      "screen_name" : "juliastern",
      "indices" : [ 0, 11 ],
      "id_str" : "160630990",
      "id" : 160630990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1748614535",
  "text" : "@juliastern Das ist das sch\u00F6ne an Twitter: Niemand muss es lesen!",
  "id" : 1748614535,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Reineke",
      "screen_name" : "larsreineke",
      "indices" : [ 3, 15 ],
      "id_str" : "6338182",
      "id" : 6338182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1748618848",
  "text" : "RT @larsreineke: Gucke \"Der Untergang\". Magda Goebbels mit ihren 6 singenden Kindern erinnert mich an irgendwen.",
  "id" : 1748618848,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Claverie",
      "screen_name" : "Skl8em",
      "indices" : [ 0, 7 ],
      "id_str" : "13823092",
      "id" : 13823092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1748990225",
  "geo" : { },
  "id_str" : "1749344458",
  "in_reply_to_user_id" : 13823092,
  "text" : "@Skl8em Den Typen gibt es in der Tat. Hatte mehr auf Hack des Accounts getippt bei so einer Antwort...",
  "id" : 1749344458,
  "in_reply_to_status_id" : 1748990225,
  "created_at" : "2009-05-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "Skl8em",
  "in_reply_to_user_id_str" : "13823092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1739870932",
  "text" : "Jetzt ist erstmal Zeit f\u00FCr Abendessen sagt mein Bauchgef\u00FChl.",
  "id" : 1739870932,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1739855434",
  "geo" : { },
  "id_str" : "1739875943",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Das h\u00F6rt sich super an. Da l\u00E4sst sich doch bestimmt was von verbloggen!",
  "id" : 1739875943,
  "in_reply_to_status_id" : 1739855434,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nSonic",
      "screen_name" : "bnSonic",
      "indices" : [ 0, 8 ],
      "id_str" : "17022259",
      "id" : 17022259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1739875347",
  "geo" : { },
  "id_str" : "1739884326",
  "in_reply_to_user_id" : 17022259,
  "text" : "@bnSonic Du sitzt zu viel vor dem Rechner. FTP l\u00E4sst sich glaub ich auch nicht zur Wahl aufstellen :)",
  "id" : 1739884326,
  "in_reply_to_status_id" : 1739875347,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "bnSonic",
  "in_reply_to_user_id_str" : "17022259",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1739907306",
  "geo" : { },
  "id_str" : "1739934606",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ach bei bei mir steht in n\u00E4chster Zeit erstmal keine Arbeit an. Aber mir fehlen ehrlich gesagt die DOIs :P",
  "id" : 1739934606,
  "in_reply_to_status_id" : 1739907306,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1739978776",
  "geo" : { },
  "id_str" : "1739990529",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Naja, selbst wenn nicht: Direkte Links sind besser als suchen lassen. Egal mit welchem Tool :)",
  "id" : 1739990529,
  "in_reply_to_status_id" : 1739978776,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1740280603",
  "text" : "Gibt es eigentlich einen Dienst der magpie-User automatisch unfollowt?",
  "id" : 1740280603,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiia Tentakel",
      "screen_name" : "TiiaAurora",
      "indices" : [ 0, 11 ],
      "id_str" : "16183565",
      "id" : 16183565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1740395838",
  "geo" : { },
  "id_str" : "1740469051",
  "in_reply_to_user_id" : 16183565,
  "text" : "@TiiaAurora Vielleicht bietet Magpie das bald selbst gg. Bezahlung an ;)",
  "id" : 1740469051,
  "in_reply_to_status_id" : 1740395838,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "TiiaAurora",
  "in_reply_to_user_id_str" : "16183565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan W.",
      "screen_name" : "LortusX",
      "indices" : [ 0, 8 ],
      "id_str" : "47303962",
      "id" : 47303962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1740458969",
  "geo" : { },
  "id_str" : "1740932253",
  "in_reply_to_user_id" : 17556659,
  "text" : "@LortusX und wie oft hast du getwittert? ;)",
  "id" : 1740932253,
  "in_reply_to_status_id" : 1740458969,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteWoh",
  "in_reply_to_user_id_str" : "17556659",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1740938533",
  "text" : "Weiter Dexter Season 3 schauen.",
  "id" : 1740938533,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan W.",
      "screen_name" : "LortusX",
      "indices" : [ 0, 8 ],
      "id_str" : "47303962",
      "id" : 47303962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1740946578",
  "geo" : { },
  "id_str" : "1740983167",
  "in_reply_to_user_id" : 17556659,
  "text" : "@LortusX Mag sein. Aber da dann gleich alle Mitglieder das gleiche raushauen st\u00F6rt es.",
  "id" : 1740983167,
  "in_reply_to_status_id" : 1740946578,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteWoh",
  "in_reply_to_user_id_str" : "17556659",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan W.",
      "screen_name" : "LortusX",
      "indices" : [ 0, 8 ],
      "id_str" : "47303962",
      "id" : 47303962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1741000317",
  "geo" : { },
  "id_str" : "1741039803",
  "in_reply_to_user_id" : 17556659,
  "text" : "@LortusX 3 Tage die ich Twitter nicht benutzen kann weil andere billig was verdienen wollen? ;)",
  "id" : 1741039803,
  "in_reply_to_status_id" : 1741000317,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteWoh",
  "in_reply_to_user_id_str" : "17556659",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei NRW",
      "screen_name" : "PiratenNRW",
      "indices" : [ 0, 11 ],
      "id_str" : "36646869",
      "id" : 36646869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1735528450",
  "geo" : { },
  "id_str" : "1735588268",
  "in_reply_to_user_id" : 36646869,
  "text" : "@PiratenNRW Meiner ist hoffentlich auch dabei! ;)",
  "id" : 1735588268,
  "in_reply_to_status_id" : 1735528450,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "PiratenNRW",
  "in_reply_to_user_id_str" : "36646869",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1735615761",
  "text" : "Neuer W&W-Post: Wissenschaft im Web 2.0 http:\/\/tr.im\/kOja",
  "id" : 1735615761,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piratenpartei NRW",
      "screen_name" : "PiratenNRW",
      "indices" : [ 0, 11 ],
      "id_str" : "36646869",
      "id" : 36646869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1735612256",
  "geo" : { },
  "id_str" : "1735635866",
  "in_reply_to_user_id" : 36646869,
  "text" : "@PiratenNRW Ich bin schon dabei \u00DCberzeugungsarbeit zu leisten. Ist nur nicht so einfach abseits von \u00FCberzeugten Internetusern :)",
  "id" : 1735635866,
  "in_reply_to_status_id" : 1735612256,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "PiratenNRW",
  "in_reply_to_user_id_str" : "36646869",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1735782308",
  "text" : "Neuer Blogpost: TwitterFon Pro http:\/\/tr.im\/kOq1",
  "id" : 1735782308,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1735846424",
  "text" : "@houellebeck Das Bild symbolisiert doch einfach wie epic fail die DNS-Sperren sind. :)",
  "id" : 1735846424,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1735876115",
  "geo" : { },
  "id_str" : "1735882036",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Seit gestern Nacht. Zumindest hab ich da die Mail bekommen mit der finalen Version und dem Hinweis dass es nun im Review-Prozess ist",
  "id" : 1735882036,
  "in_reply_to_status_id" : 1735876115,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1735913766",
  "geo" : { },
  "id_str" : "1735959130",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Mit der Zeit d\u00FCrftest du recht haben. Aber ich hoffe die App-Store-Angestellten lernen einfach mit der Zeit.",
  "id" : 1735959130,
  "in_reply_to_status_id" : 1735913766,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1736034231",
  "text" : "Ich hab doch glatt den 2000ten Blogeintrag bei mir verpennt. Nun ist zu sp\u00E4t.",
  "id" : 1736034231,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1736232898",
  "geo" : { },
  "id_str" : "1736243572",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Moment war Indy nicht fuckin' Professor? :D",
  "id" : 1736243572,
  "in_reply_to_status_id" : 1736232898,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1736274508",
  "text" : "Guten Morgen \u00FCbrigens ;) \u266B http:\/\/blip.fm\/~5udrj",
  "id" : 1736274508,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1736265066",
  "geo" : { },
  "id_str" : "1736281588",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Aber gut, wenn Tom Hanks sich intellektueller f\u00FChlen will. Professor und Nazis verpr\u00FCgeln gleichzeitig kann nur einer :P",
  "id" : 1736281588,
  "in_reply_to_status_id" : 1736265066,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1736286325",
  "text" : "Because a vision softly creeping... \u266B http:\/\/blip.fm\/~5uduf",
  "id" : 1736286325,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1736312440",
  "text" : "Und ab in die 70er ;) \u266B http:\/\/blip.fm\/~5ue0r",
  "id" : 1736312440,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arlecchino",
      "screen_name" : "escamoteur",
      "indices" : [ 0, 11 ],
      "id_str" : "3016965976",
      "id" : 3016965976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1736314758",
  "geo" : { },
  "id_str" : "1736319027",
  "in_reply_to_user_id" : 21885713,
  "text" : "@escamoteur damit das Telefon nicht alle x Minuten Mails pullen muss und dabei vielleicht unn\u00F6tig Akkuleistung verschenkt?",
  "id" : 1736319027,
  "in_reply_to_status_id" : 1736314758,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "TomBennettMagic",
  "in_reply_to_user_id_str" : "21885713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arlecchino",
      "screen_name" : "escamoteur",
      "indices" : [ 0, 11 ],
      "id_str" : "3016965976",
      "id" : 3016965976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1736324319",
  "geo" : { },
  "id_str" : "1736336782",
  "in_reply_to_user_id" : 21885713,
  "text" : "@escamoteur nein. Wenn du st\u00E4ndig pullst muss jedesmal eine Verbindung hergestellt werden zum \u00FCberpr\u00FCfen",
  "id" : 1736336782,
  "in_reply_to_status_id" : 1736324319,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "TomBennettMagic",
  "in_reply_to_user_id_str" : "21885713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1736340095",
  "geo" : { },
  "id_str" : "1736362112",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Stimmt. Niemand will Ton Hanks verg\u00F6ttern",
  "id" : 1736362112,
  "in_reply_to_status_id" : 1736340095,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arlecchino",
      "screen_name" : "escamoteur",
      "indices" : [ 0, 11 ],
      "id_str" : "3016965976",
      "id" : 3016965976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1736356114",
  "geo" : { },
  "id_str" : "1736561289",
  "in_reply_to_user_id" : 21885713,
  "text" : "@escamoteur Weniger! Weil es nicht immer Verbindungen macht",
  "id" : 1736561289,
  "in_reply_to_status_id" : 1736356114,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "TomBennettMagic",
  "in_reply_to_user_id_str" : "21885713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arlecchino",
      "screen_name" : "escamoteur",
      "indices" : [ 0, 11 ],
      "id_str" : "3016965976",
      "id" : 3016965976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1736384268",
  "geo" : { },
  "id_str" : "1736564269",
  "in_reply_to_user_id" : 21885713,
  "text" : "@escamoteur ja technisch in etwa",
  "id" : 1736564269,
  "in_reply_to_status_id" : 1736384268,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "TomBennettMagic",
  "in_reply_to_user_id_str" : "21885713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arlecchino",
      "screen_name" : "escamoteur",
      "indices" : [ 0, 11 ],
      "id_str" : "3016965976",
      "id" : 3016965976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1736587112",
  "geo" : { },
  "id_str" : "1736778115",
  "in_reply_to_user_id" : 21885713,
  "text" : "@escamoteur Ist schon cool. H\u00E4tte gerne Push f\u00FCr alles :)",
  "id" : 1736778115,
  "in_reply_to_status_id" : 1736587112,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "TomBennettMagic",
  "in_reply_to_user_id_str" : "21885713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DonDahlmann",
      "screen_name" : "DonDahlmann",
      "indices" : [ 3, 15 ],
      "id_str" : "1151281",
      "id" : 1151281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1737629526",
  "text" : "RT @DonDahlmann: New blog post: Noch mal in Ruhe, f\u00FCr alle Politiker http:\/\/www.dondahlmann.de\/?p=251",
  "id" : 1737629526,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1737635561",
  "geo" : { },
  "id_str" : "1737655966",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ich kenne nur wenige Poster die nicht h\u00E4sslich sind. Und das auch zu echt coolen Themen und Ergebnissen. Ich glaube das muss so.",
  "id" : 1737655966,
  "in_reply_to_status_id" : 1737635561,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1737686494",
  "geo" : { },
  "id_str" : "1737835770",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ich glaube das liegt daran dass Wissenschaftler in der Beziehung Jack Of All Trades sein wollen.",
  "id" : 1737835770,
  "in_reply_to_status_id" : 1737686494,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1737850444",
  "text" : "Twitpic Error 1001: Invalid Username or Password. WTF?",
  "id" : 1737850444,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1737859734",
  "geo" : { },
  "id_str" : "1737935248",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Okay, aber gestern ging es ja auch noch. Allerdings hab ich gestern noch die GM-Version drauf gehabt und nicht die Final.",
  "id" : 1737935248,
  "in_reply_to_status_id" : 1737859734,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1737945746",
  "text" : "Neuer W&W-Post von Philipp: B\u00FCcher & noch mehr B\u00FCcher II http:\/\/tr.im\/kPPD #wundw",
  "id" : 1737945746,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1737953472",
  "text" : "Und weil es so sch\u00F6n ist direkt noch ein W&W-Post: Ein kleines Jubil\u00E4um http:\/\/tr.im\/kPQ0 #wundw",
  "id" : 1737953472,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1737986977",
  "geo" : { },
  "id_str" : "1738020909",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Haha, deren Webseite ist auch der Hit. In der Kurzbeschreibung direkt das Sternzeichen und Aszendent dabei :P",
  "id" : 1738020909,
  "in_reply_to_status_id" : 1737986977,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denny",
      "screen_name" : "dc79",
      "indices" : [ 3, 8 ],
      "id_str" : "15468731",
      "id" : 15468731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "guttenberg",
      "indices" : [ 111, 122 ]
    }, {
      "text" : "zensursula",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1738124396",
  "text" : "RT @dc79: Guttenberg sieht nicht nur so aus wie Lothar Matth\u00E4us, er scheint auch noch seinen Verstand zu haben #guttenberg #zensursula",
  "id" : 1738124396,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1738181109",
  "geo" : { },
  "id_str" : "1738261345",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich glaube dagegen kann man nicht klagen oder? Soldaten sind M\u00F6rder ging ja auch nicht ;)",
  "id" : 1738261345,
  "in_reply_to_status_id" : 1738181109,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Myers",
      "screen_name" : "MyersMyers",
      "indices" : [ 0, 11 ],
      "id_str" : "87874574",
      "id" : 87874574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1739806541",
  "text" : "@myersmyers Na nicht die Vollidioten w\u00E4hlen die den Mist jetzt verbocken sondern wen anders ;)",
  "id" : 1739806541,
  "created_at" : "2009-05-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 73, 82 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1727859695",
  "geo" : { },
  "id_str" : "1728064086",
  "in_reply_to_user_id" : 16066326,
  "text" : "Also ich bin auch echter Pirat. 100%Zustimmung. http:\/\/bit.ly\/3njLa\n via @cyberfux",
  "id" : 1728064086,
  "in_reply_to_status_id" : 1727859695,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1728696915",
  "geo" : { },
  "id_str" : "1728717058",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex ein Fall f\u00FCr gratis SMS? ;)",
  "id" : 1728717058,
  "in_reply_to_status_id" : 1728696915,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1728758687",
  "geo" : { },
  "id_str" : "1728790519",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Ah sch\u00F6n! Viel Spa\u00DF damit. Die Kurzgeschichte der letzten Seite kann ich besonders empfehlen :)",
  "id" : 1728790519,
  "in_reply_to_status_id" : 1728758687,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1728798400",
  "text" : "Der Hund plus Pusteblumen plus Wind = jede Menge Spa\u00DF!",
  "id" : 1728798400,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1728802795",
  "geo" : { },
  "id_str" : "1729334627",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex geht mir \u00E4hnlich. Wof\u00FCr gibt es Mail ;)",
  "id" : 1729334627,
  "in_reply_to_status_id" : 1728802795,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 0, 9 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1728858074",
  "geo" : { },
  "id_str" : "1729340495",
  "in_reply_to_user_id" : 16066326,
  "text" : "@cyberfux Oh das ging ausnahmsweise. Heute war er nichtmal Baden!",
  "id" : 1729340495,
  "in_reply_to_status_id" : 1728858074,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1728945094",
  "geo" : { },
  "id_str" : "1729351900",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Dann nat\u00FCrlich auch ihm viel Spa\u00DF :)",
  "id" : 1729351900,
  "in_reply_to_status_id" : 1728945094,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 0, 9 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1729351095",
  "geo" : { },
  "id_str" : "1729357295",
  "in_reply_to_user_id" : 16066326,
  "text" : "@cyberfux Puh, mein einer ist noch nichtmal ordentlich erzogen. Da will ich mir gar nicht 5 auf einmal vorstellen m\u00FCssen ;)",
  "id" : 1729357295,
  "in_reply_to_status_id" : 1729351095,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 0, 9 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1729422180",
  "geo" : { },
  "id_str" : "1729443304",
  "in_reply_to_user_id" : 16066326,
  "text" : "@cyberfux Na gut, dann will ich mir 5 auf einmal noch viel weniger vorstellen :)",
  "id" : 1729443304,
  "in_reply_to_status_id" : 1729422180,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 0, 9 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1729448190",
  "geo" : { },
  "id_str" : "1729474964",
  "in_reply_to_user_id" : 16066326,
  "text" : "@cyberfux Das kann ich mir lebhaft vorstellen. Aber das ist ja auch das sch\u00F6ne daran.",
  "id" : 1729474964,
  "in_reply_to_status_id" : 1729448190,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 0, 9 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1729486261",
  "geo" : { },
  "id_str" : "1729508795",
  "in_reply_to_user_id" : 16066326,
  "text" : "@cyberfux Daran mangelt es mir leider :)",
  "id" : 1729508795,
  "in_reply_to_status_id" : 1729486261,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 0, 9 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1729520741",
  "geo" : { },
  "id_str" : "1729566198",
  "in_reply_to_user_id" : 16066326,
  "text" : "@cyberfux Das ist verdammt cool",
  "id" : 1729566198,
  "in_reply_to_status_id" : 1729520741,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 0, 9 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1729622165",
  "geo" : { },
  "id_str" : "1729689477",
  "in_reply_to_user_id" : 16066326,
  "text" : "@cyberfux Das kommt mir bekannt vor. Hier liegt gerade wer unter dem Schreibtisch auf meinen F\u00FC\u00DFen ;)",
  "id" : 1729689477,
  "in_reply_to_status_id" : 1729622165,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1729911022",
  "text" : "Gerade jemand anwesend der zuf\u00E4llig 10.1073\/pnas.0811717106  rumfliegen hat?",
  "id" : 1729911022,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1729972801",
  "text" : "Hat sich erledigt, VPN war einfach noch nicht ordentlich angemeldet.",
  "id" : 1729972801,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1730205037",
  "text" : "Ich muss bescheuert sein mir CSI anzusehen. Wissenschaft != Magie",
  "id" : 1730205037,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1730785015",
  "text" : "\u201EHendrik Hey - Wissenschaftsjournalist\u201C, der ist kein Journalist und mit Wissenschaft hat der auch nix am Hut. Sollte mich auch so nennen...",
  "id" : 1730785015,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwischenrufer",
      "screen_name" : "Zwischenrufer",
      "indices" : [ 0, 14 ],
      "id_str" : "16046470",
      "id" : 16046470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fallhoehe",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1730805361",
  "geo" : { },
  "id_str" : "1730845687",
  "in_reply_to_user_id" : 16046470,
  "text" : "@Zwischenrufer Naja, ich glaube du verkl\u00E4rst das. Wenn du heute noch in der Grundschule w\u00E4rst w\u00FCrdest du Galileo gut finden. #fallhoehe",
  "id" : 1730845687,
  "in_reply_to_status_id" : 1730805361,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Zwischenrufer",
  "in_reply_to_user_id_str" : "16046470",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwischenrufer",
      "screen_name" : "Zwischenrufer",
      "indices" : [ 0, 14 ],
      "id_str" : "16046470",
      "id" : 16046470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1730805361",
  "geo" : { },
  "id_str" : "1730861117",
  "in_reply_to_user_id" : 16046470,
  "text" : "@Zwischenrufer Von der Qualit\u00E4t der \u201EFakten\u201C her tut sich das glaube ich nichts.",
  "id" : 1730861117,
  "in_reply_to_status_id" : 1730805361,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Zwischenrufer",
  "in_reply_to_user_id_str" : "16046470",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwischenrufer",
      "screen_name" : "Zwischenrufer",
      "indices" : [ 0, 14 ],
      "id_str" : "16046470",
      "id" : 16046470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1730959423",
  "geo" : { },
  "id_str" : "1731013101",
  "in_reply_to_user_id" : 16046470,
  "text" : "@Zwischenrufer Ja. Ich hab es als Kind auch gern geschaut. Aber auch die Maus und L\u00F6wenzahn\/Pusteblume. Und die waren spannend und korrekt",
  "id" : 1731013101,
  "in_reply_to_status_id" : 1730959423,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Zwischenrufer",
  "in_reply_to_user_id_str" : "16046470",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1724802770",
  "text" : "Sich im Schlaf auf die eigenen Extremit\u00E4ten legen macht das aufwachen noch anstrengender..",
  "id" : 1724802770,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Friedrich",
      "screen_name" : "slith76",
      "indices" : [ 0, 8 ],
      "id_str" : "5803222",
      "id" : 5803222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1725304496",
  "geo" : { },
  "id_str" : "1725312074",
  "in_reply_to_user_id" : 5803222,
  "text" : "@slith76 ich f\u00E4nde es noch Super wenn man direkt aus der Mail followen k\u00F6nnte.",
  "id" : 1725312074,
  "in_reply_to_status_id" : 1725304496,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "slith76",
  "in_reply_to_user_id_str" : "5803222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1725609278",
  "text" : "\u201Cvon wissenschaftlicher Seite [...] erwiesenen hohen Unsicherheit der Kondome hinsichtlich der Aidsvorbeugung\u201D http:\/\/tinyurl.com\/condomfail",
  "id" : 1725609278,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1725622542",
  "text" : "Bin ich eigentlich der Einzige der Pubmed unbeschreiblich unintuitiv und h\u00E4sslich findet?",
  "id" : 1725622542,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1725637733",
  "geo" : { },
  "id_str" : "1725666384",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Da kann man echt besser googlen oder Wikilinks abgrasen ;)",
  "id" : 1725666384,
  "in_reply_to_status_id" : 1725637733,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1725732343",
  "geo" : { },
  "id_str" : "1725744989",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 und wieso findest du das Gut?!",
  "id" : 1725744989,
  "in_reply_to_status_id" : 1725732343,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1725757506",
  "text" : "Kaffee!! http:\/\/twitpic.com\/4plqp",
  "id" : 1725757506,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1725791962",
  "geo" : { },
  "id_str" : "1726071935",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 ja die kenne ich. Aber die normale Suche ist einfach ein Witz",
  "id" : 1726071935,
  "in_reply_to_status_id" : 1725791962,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "muensterana",
      "screen_name" : "muensterana",
      "indices" : [ 0, 12 ],
      "id_str" : "26782616",
      "id" : 26782616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1725793431",
  "geo" : { },
  "id_str" : "1726076394",
  "in_reply_to_user_id" : 26782616,
  "text" : "@muensterana Wir waren zu faul dem Tisch aus der Schutzh\u00FClle zu befreien. Daher der Stuhl :)",
  "id" : 1726076394,
  "in_reply_to_status_id" : 1725793431,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "muensterana",
  "in_reply_to_user_id_str" : "26782616",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1726161905",
  "text" : "Neuer W&W-Post von Philipp - Kiste auf, Kiste zu: http:\/\/tr.im\/kJ0l",
  "id" : 1726161905,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1726259956",
  "text" : "Uh, Paper die online so gar nicht zu kriegen sind, nichtmal gegen Bezahlung, finde ich suspekt.",
  "id" : 1726259956,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1726268783",
  "geo" : { },
  "id_str" : "1726290567",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Sehr benutzerfreundlich halt. da kann ich ja fast besser via :site per google suchen, das ist k\u00FCrzer :D",
  "id" : 1726290567,
  "in_reply_to_status_id" : 1726268783,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1726325242",
  "text" : "@JoergR Ne, einfach nur was von 1992. Da hat sich wohl niemand die M\u00FChe gemacht das mal zu digitalisieren. Dann halt kein Blogeintrag.",
  "id" : 1726325242,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1726391378",
  "geo" : { },
  "id_str" : "1726397232",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Jo, in meinem Fall hab ich auch schlussendlich gefunden was ich will. Ist nur leider nicht intuitiv. Und verf\u00FCgbar war es nicht ;)",
  "id" : 1726397232,
  "in_reply_to_status_id" : 1726391378,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Munger",
      "screen_name" : "davemunger",
      "indices" : [ 0, 11 ],
      "id_str" : "17449143",
      "id" : 17449143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1726799847",
  "geo" : { },
  "id_str" : "1726816366",
  "in_reply_to_user_id" : 17449143,
  "text" : "@davemunger Oh great! Maybe you should say this somewhere on the website. Or use checkboxes for clarification. Thanks anyway. :)",
  "id" : 1726816366,
  "in_reply_to_status_id" : 1726799847,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "davemunger",
  "in_reply_to_user_id_str" : "17449143",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1726858038",
  "text" : "Bei dem Wetter werd ich doch noch eine ausgedehnte Runde mit dem Hund drehen.",
  "id" : 1726858038,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1727494041",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Das kenn ich irgendwie. Da frage ich mich immer wof\u00FCr man dann \u00FCberhaupt so ein Ger\u00E4t besitzt :)",
  "id" : 1727494041,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1727531927",
  "geo" : { },
  "id_str" : "1727552068",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Oder findet es nicht in der Handtasche oder h\u00F6rt es in den Untiefen der selbigen nicht. :)",
  "id" : 1727552068,
  "in_reply_to_status_id" : 1727531927,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Munger",
      "screen_name" : "davemunger",
      "indices" : [ 0, 11 ],
      "id_str" : "17449143",
      "id" : 17449143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1727525725",
  "geo" : { },
  "id_str" : "1727560896",
  "in_reply_to_user_id" : 17449143,
  "text" : "@davemunger Hiding error bars can make bad research look good ;)",
  "id" : 1727560896,
  "in_reply_to_status_id" : 1727525725,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "davemunger",
  "in_reply_to_user_id_str" : "17449143",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Munger",
      "screen_name" : "davemunger",
      "indices" : [ 0, 11 ],
      "id_str" : "17449143",
      "id" : 17449143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1727624044",
  "geo" : { },
  "id_str" : "1727690499",
  "in_reply_to_user_id" : 17449143,
  "text" : "@davemunger You're right and your post shows this. The problem is many ppl either never learn those things or forget it because it's math.",
  "id" : 1727690499,
  "in_reply_to_status_id" : 1727624044,
  "created_at" : "2009-05-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "davemunger",
  "in_reply_to_user_id_str" : "17449143",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1714613381",
  "text" : "Guten morgen, jetzt wird erstmal gefr\u00FChst\u00FCckt!",
  "id" : 1714613381,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save_the_wolves",
      "screen_name" : "Save_the_wolves",
      "indices" : [ 0, 16 ],
      "id_str" : "24501743",
      "id" : 24501743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1714663287",
  "geo" : { },
  "id_str" : "1714672548",
  "in_reply_to_user_id" : 24501743,
  "text" : "@Save_the_wolves Cute! :)",
  "id" : 1714672548,
  "in_reply_to_status_id" : 1714663287,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Save_the_wolves",
  "in_reply_to_user_id_str" : "24501743",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1715186861",
  "text" : "Mittwochs Morgens. Gro\u00DFeinkauf im Aldi. Horror!",
  "id" : 1715186861,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1715189919",
  "geo" : { },
  "id_str" : "1715191676",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Uh, das kenn ich. War immer mein Job als Praktikant ;)",
  "id" : 1715191676,
  "in_reply_to_status_id" : 1715189919,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "piraten",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "muenster",
      "indices" : [ 106, 115 ]
    }, {
      "text" : "ms",
      "indices" : [ 116, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1715239821",
  "text" : "Kommenden Mittwoch ist Stammtisch der M\u00FCnsteraner Piraten in der Blechtrommel: http:\/\/tr.im\/kCxX #piraten #muenster #ms",
  "id" : 1715239821,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1715251970",
  "text" : "Ich glaube ich sollte nur noch \u00FCber den UniVPN online gehen.Ist auf jedenfall schneller als es f\u00FCr jedes Paper was ich lesen will zu starten",
  "id" : 1715251970,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1715254736",
  "geo" : { },
  "id_str" : "1715280234",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Okay, bei uns kam halt jede Woche der Lieferant direkt vor das Institut, musste nur mit den Dingern runterfahren vors Geb\u00E4ude ;)",
  "id" : 1715280234,
  "in_reply_to_status_id" : 1715254736,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1715258362",
  "geo" : { },
  "id_str" : "1715282325",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Hier nicht, nervt aber andauernd das an und auszustellen weil alle Verbindungen dabei abbrechen.",
  "id" : 1715282325,
  "in_reply_to_status_id" : 1715258362,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1715283331",
  "text" : "@cptMarco Ausgezeichnet :)",
  "id" : 1715283331,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1715286033",
  "text" : "DOI 10.1177\/0278364908100924 ist sehr cool. Wird nachher verbloggt :)",
  "id" : 1715286033,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arlecchino",
      "screen_name" : "escamoteur",
      "indices" : [ 0, 11 ],
      "id_str" : "3016965976",
      "id" : 3016965976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1715443342",
  "geo" : { },
  "id_str" : "1715457253",
  "in_reply_to_user_id" : 21885713,
  "text" : "@escamoteur Wissenschaft ist das \u00DCberpr\u00FCfen von Thesen. Wenn man etwas widerlegt hat muss man seine Thesen eben \u00E4ndern. Keine Dogmen glauben",
  "id" : 1715457253,
  "in_reply_to_status_id" : 1715443342,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "TomBennettMagic",
  "in_reply_to_user_id_str" : "21885713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PRLit",
      "indices" : [ 61, 67 ]
    }, {
      "text" : "science",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 77, 90 ]
    }, {
      "text" : "wundw",
      "indices" : [ 91, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1715659357",
  "text" : "Neuer W&W-Post - Bakterien als Nanoroboter http:\/\/tr.im\/kCTq #PRLit #science #wissenschaft #wundw",
  "id" : 1715659357,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "verwirrt",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1715856262",
  "text" : "Podcasts die per Skype aufgenommen wurden und in denen man zwischendurch die Sounds f\u00FCr neue Textnachrichten h\u00F6rt sind doof. #verwirrt",
  "id" : 1715856262,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1716314316",
  "text" : "Auto-DM an neue Follower ist unfreundlich hoch 3.",
  "id" : 1716314316,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monk",
      "screen_name" : "monkdeutschland",
      "indices" : [ 0, 16 ],
      "id_str" : "37810574",
      "id" : 37810574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1716322095",
  "geo" : { },
  "id_str" : "1716345238",
  "in_reply_to_user_id" : 37810574,
  "text" : "@monkdeutschland Im richtigen Leben h\u00E4lt mir auch keiner ein Tonband unter die Nase um mich zu begr\u00FC\u00DFen.",
  "id" : 1716345238,
  "in_reply_to_status_id" : 1716322095,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "monkdeutschland",
  "in_reply_to_user_id_str" : "37810574",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1718144178",
  "text" : "Jetzt ne Stunde schlafen. Und dann ins Bett! Heute ist M\u00FCde sein angesagt.",
  "id" : 1718144178,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cyberfux",
      "screen_name" : "cyberfux",
      "indices" : [ 0, 9 ],
      "id_str" : "16066326",
      "id" : 16066326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1718164437",
  "geo" : { },
  "id_str" : "1718230053",
  "in_reply_to_user_id" : 16066326,
  "text" : "@cyberfux CAPSLOCK? ;)",
  "id" : 1718230053,
  "in_reply_to_status_id" : 1718164437,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "cyberfux",
  "in_reply_to_user_id_str" : "16066326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1718267845",
  "geo" : { },
  "id_str" : "1718411834",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion nur gegen was? ;)",
  "id" : 1718411834,
  "in_reply_to_status_id" : 1718267845,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1718701307",
  "text" : "Nom nom nom! http:\/\/twitpic.com\/4o3jt",
  "id" : 1718701307,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1718875198",
  "geo" : { },
  "id_str" : "1718908053",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Und was war es?",
  "id" : 1718908053,
  "in_reply_to_status_id" : 1718875198,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1718930149",
  "geo" : { },
  "id_str" : "1719210946",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ruccola mit Mozarella und Balsamico",
  "id" : 1719210946,
  "in_reply_to_status_id" : 1718930149,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1718968060",
  "geo" : { },
  "id_str" : "1719216345",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion ich glaube aber nicht das ich sowas habe!",
  "id" : 1719216345,
  "in_reply_to_status_id" : 1718968060,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1719274990",
  "geo" : { },
  "id_str" : "1719692570",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion ne m\u00FCde war ich vor dem essen :)",
  "id" : 1719692570,
  "in_reply_to_status_id" : 1719274990,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1720073686",
  "text" : "WTF?! Die Stadt Essen zieht in Sachen Atheistbus den Schwanz ein? Ganz sch\u00F6n traurig wie wenig s\u00E4kular dieser Staat doch ist...",
  "id" : 1720073686,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1720181320",
  "text" : "Neuer Blogpost: Den Schwanz einziehen... http:\/\/tr.im\/kG3v",
  "id" : 1720181320,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1720191720",
  "geo" : { },
  "id_str" : "1720196273",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Das betrifft hoffentlich nicht meine\/unsere ;)",
  "id" : 1720196273,
  "in_reply_to_status_id" : 1720191720,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1719274990",
  "geo" : { },
  "id_str" : "1720320736",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Seit dem essen bin ich auch wieder erstaunlich wach ;)",
  "id" : 1720320736,
  "in_reply_to_status_id" : 1719274990,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1720342226",
  "text" : "Fauler Katzencontent!! http:\/\/twitpic.com\/4ogmd",
  "id" : 1720342226,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1720434421",
  "geo" : { },
  "id_str" : "1720447686",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch dann ist ja gut :)",
  "id" : 1720447686,
  "in_reply_to_status_id" : 1720434421,
  "created_at" : "2009-05-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1709803450",
  "text" : "@JoergR Stimmt, aber auch ohne ist es ein Hit :)",
  "id" : 1709803450,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1704527906",
  "text" : "Ich und verschlafen. Wie untypisch!",
  "id" : 1704527906,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1704646951",
  "text" : "Wer kam eigentlich in die Idee in so ziemlich alles Cranberry zu packen? Der T\u00E4ter widert mich an!",
  "id" : 1704646951,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1704654659",
  "geo" : { },
  "id_str" : "1704666831",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Ich halte von diesem ganzen Trendobst meist recht wenig. Grapefruit *schauder*",
  "id" : 1704666831,
  "in_reply_to_status_id" : 1704654659,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1704655086",
  "geo" : { },
  "id_str" : "1704668186",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Mein Essen soll aber lecker sein und nicht in! Und mein Shampoo soll meine Haare s\u00E4ubern und nicht fruchtig sein.",
  "id" : 1704668186,
  "in_reply_to_status_id" : 1704655086,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liliana Demir \uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "Cohnina",
      "indices" : [ 0, 8 ],
      "id_str" : "15438679",
      "id" : 15438679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1704708800",
  "geo" : { },
  "id_str" : "1704756493",
  "in_reply_to_user_id" : 15438679,
  "text" : "@Cohnina Ich muss sagen das Shampoo hab ich auch einfach gar nicht gegessen ;)",
  "id" : 1704756493,
  "in_reply_to_status_id" : 1704708800,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Cohnina",
  "in_reply_to_user_id_str" : "15438679",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prlit",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "science",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "wissenschaft",
      "indices" : [ 87, 100 ]
    }, {
      "text" : "wundw",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1704846635",
  "text" : "Neuer W&W-Post: Riesige, phylogenetische Stammb\u00E4ume: http:\/\/tr.im\/kw23 #prlit #science #wissenschaft #wundw",
  "id" : 1704846635,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1704848578",
  "text" : "@JoergR Ne, die sind ganz trendlos fleischig :)",
  "id" : 1704848578,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1704995104",
  "text" : "Schade das Eventbox die faved Eintr\u00E4ge von GoogleReader nicht als extra Kategorie anzeigt.",
  "id" : 1704995104,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1705014743",
  "text" : "Wie wahr! http:\/\/tr.im\/kwbr",
  "id" : 1705014743,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes Kleske",
      "screen_name" : "jkleske",
      "indices" : [ 0, 8 ],
      "id_str" : "623453",
      "id" : 623453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1705085337",
  "geo" : { },
  "id_str" : "1705109262",
  "in_reply_to_user_id" : 623453,
  "text" : "@jkleske Wenn du schon Dropbox-User sein solltest zieh es einfach in den Public-Ordner und kopier den Link. :)",
  "id" : 1705109262,
  "in_reply_to_status_id" : 1705085337,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "jkleske",
  "in_reply_to_user_id_str" : "623453",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1705289053",
  "text" : "Schon wieder ein Trails-Update. Ist immer besser geworden.",
  "id" : 1705289053,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1705571103",
  "text" : "Wow, alle ToDos f\u00FCr heute erledigt. Da k\u00F6nnte ich glatt doch noch etwas mehr bloggen.",
  "id" : 1705571103,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1705686186",
  "text" : "Bin irgendwie recht gelangweilt von den Ger\u00FCchten wer jetzt Twitter kauft oder auch nicht.",
  "id" : 1705686186,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly \uD83D\uDC11\uD83C\uDDEA\uD83C\uDDFA\uD83D\uDC08",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1705694589",
  "geo" : { },
  "id_str" : "1705703795",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin solange Twitter funktioniert ist mir das auch recht egal ;)",
  "id" : 1705703795,
  "in_reply_to_status_id" : 1705694589,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matze",
      "screen_name" : "matfi",
      "indices" : [ 0, 6 ],
      "id_str" : "18354829",
      "id" : 18354829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1705989246",
  "geo" : { },
  "id_str" : "1706053843",
  "in_reply_to_user_id" : 18354829,
  "text" : "@matfi Truecrypt hat den Vorteil universeller zu sein was die OS angeht.",
  "id" : 1706053843,
  "in_reply_to_status_id" : 1705989246,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "matfi",
  "in_reply_to_user_id_str" : "18354829",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1706058909",
  "text" : "Blogpost: Linksh\u00E4nder haben verloren http:\/\/tr.im\/kwZ1",
  "id" : 1706058909,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 53, 67 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1706313052",
  "text" : "Neues bei W&W: Ein Freiflug ins All zu gewinnen, bei @astrodicticum :P",
  "id" : 1706313052,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1706316864",
  "text" : "Oh und der Link dazu w\u00E4re auch nicht verkehrt gewesen: http:\/\/tr.im\/kxaV #wundw",
  "id" : 1706316864,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1707207062",
  "text" : "Ich w\u00FCrde f\u00FCr Twitter ja wohl 140 $ zahlen ;)",
  "id" : 1707207062,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 3, 11 ],
      "id_str" : "14857351",
      "id" : 14857351
    }, {
      "name" : "Sergio",
      "screen_name" : "Function",
      "indices" : [ 16, 25 ],
      "id_str" : "760418900571934721",
      "id" : 760418900571934721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1707319494",
  "text" : "RT @insideX: RT @function http:\/\/twitpic.com\/4klsv - Ursula von Ulbricht",
  "id" : 1707319494,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gilly #IsraelHHMG \uD83C\uDDEE\uD83C\uDDF1",
      "screen_name" : "GillyBerlin",
      "indices" : [ 0, 12 ],
      "id_str" : "15055852",
      "id" : 15055852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1707420709",
  "geo" : { },
  "id_str" : "1707472941",
  "in_reply_to_user_id" : 15055852,
  "text" : "@gillyberlin Experten f\u00FCr Steuererh\u00F6hungen... If you only have a hammer everything looks like a nail...",
  "id" : 1707472941,
  "in_reply_to_status_id" : 1707420709,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "GillyBerlin",
  "in_reply_to_user_id_str" : "15055852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1707746200",
  "text" : "Cooles iPhone-WP :) http:\/\/twitpic.com\/4lvow",
  "id" : 1707746200,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mjam",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1708325282",
  "text" : "Gerade ein wenig Salat in mich eingeschoben. #mjam",
  "id" : 1708325282,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1708419114",
  "text" : "Fange nun mal an Dexter zu schauen. Mal sehen was diese Staffel so bereith\u00E4lt.",
  "id" : 1708419114,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1708564901",
  "text" : "@JoergR Die dritte Staffel :)",
  "id" : 1708564901,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1708654751",
  "text" : "@JoergR Okay, bin aber auch mittlerweile bei Folge 5 oder so :)",
  "id" : 1708654751,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1709022059",
  "geo" : { },
  "id_str" : "1709204898",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 sagt mir gerade nichts. Welchen Spruch meinst du? :)",
  "id" : 1709204898,
  "in_reply_to_status_id" : 1709022059,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1709227223",
  "text" : "@JoergR Ja das Tempo ist langsam ok. Bin gespannt ob es wieder einen vorhersehbaren Twist geben wird ;)",
  "id" : 1709227223,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1709702327",
  "text" : "@JoergR indeed! Der Spruch kam gerade! W\u00E4re was f\u00FCr ein Shirt ;)",
  "id" : 1709702327,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1709722695",
  "text" : "@rajue da m\u00F6chte ich wohl mit :)",
  "id" : 1709722695,
  "created_at" : "2009-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1696343714",
  "geo" : { },
  "id_str" : "1696366386",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ach, es bleibt doch noch trocken Brot und Wasser ;)",
  "id" : 1696366386,
  "in_reply_to_status_id" : 1696343714,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1696471090",
  "text" : "Zu lange unbequem vor dem Rechner gesessen. Bin nun von Nackenschmerzen geplagt! Deshalb nun drau\u00DFen.",
  "id" : 1696471090,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1696493929",
  "geo" : { },
  "id_str" : "1696527929",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion na dann ist doch alles gut!",
  "id" : 1696527929,
  "in_reply_to_status_id" : 1696493929,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1696890267",
  "geo" : { },
  "id_str" : "1697418388",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu ist ne Frage f\u00FCr 9live",
  "id" : 1697418388,
  "in_reply_to_status_id" : 1696890267,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1697476969",
  "text" : "Wer Hundeleckerlis und Fishermens Friend in der gleichen Jackentasche verstaut sollte vor dem in den Mund legen schauen was er erwischt hat!",
  "id" : 1697476969,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1697738243",
  "text" : "@JoergR Ich hab mich brav selbst belohnt f\u00FCr gute Mitarbeit bei der Hundeerziehung. Nicht schlimm, die Leckerlis sind ok. Aber unerwartet ;)",
  "id" : 1697738243,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1697553811",
  "geo" : { },
  "id_str" : "1697746504",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 ja, er hat Gl\u00FCck gehabt :)",
  "id" : 1697746504,
  "in_reply_to_status_id" : 1697553811,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1698737082",
  "text" : "Oh! Schon wieder eine neue TwitterFon Pro-Beta!",
  "id" : 1698737082,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1698825621",
  "text" : "To drunk to drive?? W\u00E4re doch passend zum Autofahren.",
  "id" : 1698825621,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy",
      "screen_name" : "MichaelBielitza",
      "indices" : [ 0, 16 ],
      "id_str" : "661523",
      "id" : 661523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1698801101",
  "geo" : { },
  "id_str" : "1698831894",
  "in_reply_to_user_id" : 661523,
  "text" : "@MichaelBielitza Mein letzter Tweet war an dich adressiert ;)",
  "id" : 1698831894,
  "in_reply_to_status_id" : 1698801101,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "MichaelBielitza",
  "in_reply_to_user_id_str" : "661523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1698850145",
  "text" : "Ah! Wenn man die Multi-Account-Funktion bei Twitterfon ausschaltet kriegt man den Reloadbutton zur\u00FCck. Aber das Shake wurde auch verbessert.",
  "id" : 1698850145,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1699105351",
  "text" : "Das hatte ich schon vermutet :)",
  "id" : 1699105351,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billy",
      "screen_name" : "MichaelBielitza",
      "indices" : [ 0, 16 ],
      "id_str" : "661523",
      "id" : 661523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1698849794",
  "geo" : { },
  "id_str" : "1699106733",
  "in_reply_to_user_id" : 661523,
  "text" : "@MichaelBielitza Das hatte ich schon vermutet :)",
  "id" : 1699106733,
  "in_reply_to_status_id" : 1698849794,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "MichaelBielitza",
  "in_reply_to_user_id_str" : "661523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1699157540",
  "text" : "Gerade ist Twitterfon Pro buggy. Oder ich m\u00FCsste das iPhone mal Rebooten. Werde es mal testen.",
  "id" : 1699157540,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1699348335",
  "text" : "Ich br\u00E4uchte gerade mal eine Test-DM!",
  "id" : 1699348335,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1699362910",
  "text" : "Danke! Erledigt!",
  "id" : 1699362910,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1699373108",
  "text" : "Ich wollte schauen ob TwitterFons Beta nun endlich mit DMs richtig klar kommt. :)",
  "id" : 1699373108,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raphael",
      "screen_name" : "jakewalk",
      "indices" : [ 0, 9 ],
      "id_str" : "192883458",
      "id" : 192883458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1699431378",
  "geo" : { },
  "id_str" : "1699479187",
  "in_reply_to_user_id" : 22470881,
  "text" : "@jakewalk haste mal ne Mark? ;)",
  "id" : 1699479187,
  "in_reply_to_status_id" : 1699431378,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "pheraph",
  "in_reply_to_user_id_str" : "22470881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raphael",
      "screen_name" : "jakewalk",
      "indices" : [ 0, 9 ],
      "id_str" : "192883458",
      "id" : 192883458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1699544630",
  "geo" : { },
  "id_str" : "1699667164",
  "in_reply_to_user_id" : 22470881,
  "text" : "@jakewalk dann wohl wahrscheinlicher f\u00FCr den Zigarettenautomaten :)",
  "id" : 1699667164,
  "in_reply_to_status_id" : 1699544630,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "pheraph",
  "in_reply_to_user_id_str" : "22470881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "users",
      "screen_name" : "users",
      "indices" : [ 28, 34 ],
      "id_str" : "14555995",
      "id" : 14555995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1699731536",
  "text" : "Festgestellt: die fehlenden @users in meinen Replies waren nicht meine Schuld sondern ein Bug in Twitterfon.",
  "id" : 1699731536,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1693944005",
  "text" : "Cool, heute Nacht ist das erste Update f\u00FCr die Twitterfon-Betas gekommen.",
  "id" : 1693944005,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694031974",
  "geo" : { },
  "id_str" : "1694073632",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion get a Mac ;)",
  "id" : 1694073632,
  "in_reply_to_status_id" : 1694031974,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nSonic",
      "screen_name" : "bnSonic",
      "indices" : [ 0, 8 ],
      "id_str" : "17022259",
      "id" : 17022259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694091688",
  "geo" : { },
  "id_str" : "1694097077",
  "in_reply_to_user_id" : 17022259,
  "text" : "@bnSonic *Hand heb*",
  "id" : 1694097077,
  "in_reply_to_status_id" : 1694091688,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "bnSonic",
  "in_reply_to_user_id_str" : "17022259",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694170928",
  "geo" : { },
  "id_str" : "1694340209",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion leider gerade nicht.",
  "id" : 1694340209,
  "in_reply_to_status_id" : 1694170928,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694312166",
  "geo" : { },
  "id_str" : "1694342716",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee ich bin nicht \u00FCberzeugt ;)",
  "id" : 1694342716,
  "in_reply_to_status_id" : 1694312166,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694376547",
  "geo" : { },
  "id_str" : "1694389183",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee Bin halt kein Member der Church Of Tweetie! :D",
  "id" : 1694389183,
  "in_reply_to_status_id" : 1694376547,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1694413335",
  "text" : "Hab es geschafft, Californication Season 2 ist durchgeschaut. Knaller!",
  "id" : 1694413335,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694436964",
  "geo" : { },
  "id_str" : "1694442343",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry David Duchovny v\u00F6gelt sich durch LA um seine Freundin zur\u00FCckzukriegen? ;)",
  "id" : 1694442343,
  "in_reply_to_status_id" : 1694436964,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694444545",
  "geo" : { },
  "id_str" : "1694454402",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Schlimm das du mir sowas zutraust ;)",
  "id" : 1694454402,
  "in_reply_to_status_id" : 1694444545,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694475363",
  "geo" : { },
  "id_str" : "1694498806",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Das einzige gute Dogma was ich kenne ist der Film ;)",
  "id" : 1694498806,
  "in_reply_to_status_id" : 1694475363,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694497985",
  "geo" : { },
  "id_str" : "1694500521",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt Wenn die Packstation mir eine DM schicken w\u00FCrde das neue Pakete vorliegen w\u00E4re das nett ;)",
  "id" : 1694500521,
  "in_reply_to_status_id" : 1694497985,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694477607",
  "geo" : { },
  "id_str" : "1694502952",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Californication kann ich aber nur empfehlen. Eine sehr nette Story und die Dichte an Popkultur-Zitaten ist unendlich hoch.",
  "id" : 1694502952,
  "in_reply_to_status_id" : 1694477607,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Scheloske",
      "screen_name" : "Werkstatt",
      "indices" : [ 0, 10 ],
      "id_str" : "14350184",
      "id" : 14350184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694511324",
  "geo" : { },
  "id_str" : "1694515369",
  "in_reply_to_user_id" : 14350184,
  "text" : "@Werkstatt Ne ist leider nicht so konzipiert. Sollte man aber hinzuf\u00FCgen, dann w\u00E4re es ein nettes Tool.",
  "id" : 1694515369,
  "in_reply_to_status_id" : 1694511324,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Werkstatt",
  "in_reply_to_user_id_str" : "14350184",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1694588025",
  "text" : "http:\/\/twitpic.com\/4jcjp - Super Symbol-Foto was da benutzt wird bei SpOn...",
  "id" : 1694588025,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1694587016",
  "geo" : { },
  "id_str" : "1694686789",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Absolut, die lohnen sich auch immer.",
  "id" : 1694686789,
  "in_reply_to_status_id" : 1694587016,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ResearchBlogging.org",
      "screen_name" : "ResearchBlogs",
      "indices" : [ 0, 14 ],
      "id_str" : "18032441",
      "id" : 18032441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1694834201",
  "in_reply_to_user_id" : 18032441,
  "text" : "@ResearchBlogs Please, make it possible to see English and german entries at the same time. Having to choose sucks!",
  "id" : 1694834201,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ResearchBlogs",
  "in_reply_to_user_id_str" : "18032441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1694894090",
  "text" : "Hilfe! Wer hat Zugriff auf DOI 10.1111\/j.1096-0031.2009.00255.x ?",
  "id" : 1694894090,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1694902159",
  "text" : "Und wenn ich schon dabei bin: DOI 10.1002\/14651858.CD000368.pub3",
  "id" : 1694902159,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grummel",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1694945776",
  "text" : "Das sind die Augenblicke in denen ich noch mehr OA will als sonst. #grummel",
  "id" : 1694945776,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1694970562",
  "text" : "@JoergR Das ist nett. Vielen dank auch nochmal hier :)",
  "id" : 1694970562,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1694985866",
  "text" : "@JoergR Ne, Twitter == Fernleihe 2.0 :)",
  "id" : 1694985866,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1695009584",
  "text" : "Der Hund ringt zwischen mir und dem Laptop. Ich glaube er will Lapdog werden..",
  "id" : 1695009584,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1695045826",
  "text" : "Die Petitionsserver des Bundestages gehen gerade ganz \u00FCbel in die Knie.",
  "id" : 1695045826,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1695219822",
  "geo" : { },
  "id_str" : "1695678633",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Haste das Paper nun schon? :)",
  "id" : 1695678633,
  "in_reply_to_status_id" : 1695219822,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1695754917",
  "text" : "Neuer Blogpost: Petition gegen DNS-Sperren - http:\/\/tr.im\/kqom",
  "id" : 1695754917,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1695754405",
  "geo" : { },
  "id_str" : "1695760076",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ja bei mir heute wohl auch nichts mit dem verbloggen. Der Hund will meine Zeit ;)",
  "id" : 1695760076,
  "in_reply_to_status_id" : 1695754405,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1695888725",
  "geo" : { },
  "id_str" : "1695903539",
  "in_reply_to_user_id" : 14946149,
  "text" : "@andreasklinger Beziehungsstatus \u201CIt's complicated\u201D oder wieso? ;)",
  "id" : 1695903539,
  "in_reply_to_status_id" : 1695888725,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "andreasklinger",
  "in_reply_to_user_id_str" : "14946149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1695926598",
  "geo" : { },
  "id_str" : "1696010412",
  "in_reply_to_user_id" : 14946149,
  "text" : "@andreasklinger Na dann steht der virtuellen Freundschaft doch nichts im Wege ;)",
  "id" : 1696010412,
  "in_reply_to_status_id" : 1695926598,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "andreasklinger",
  "in_reply_to_user_id_str" : "14946149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1696069995",
  "text" : "Danke dass du die 10 Seiten des Papers auf dem Fussboden verteilt hast lieber Drucker. Danke f\u00FCr die Seitenzahlen Layouter!",
  "id" : 1696069995,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1695754405",
  "geo" : { },
  "id_str" : "1696345699",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Hab das Paper gerade gelesen, lohnt sich auf jedenfall. Sowohl in Sachen Evolution sehr cool als auch in BioInformatik-Sicht :)",
  "id" : 1696345699,
  "in_reply_to_status_id" : 1695754405,
  "created_at" : "2009-05-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1687969884",
  "geo" : { },
  "id_str" : "1688004301",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Bitte sehr  http:\/\/twitpic.com\/4hkg4",
  "id" : 1688004301,
  "in_reply_to_status_id" : 1687969884,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688053359",
  "geo" : { },
  "id_str" : "1688215820",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Es gibt auch die alten Farben!",
  "id" : 1688215820,
  "in_reply_to_status_id" : 1688053359,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    }, {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 14, 29 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "replyflut",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688113818",
  "geo" : { },
  "id_str" : "1688219994",
  "in_reply_to_user_id" : 14711791,
  "text" : "@Zielpublikum @unimatrixZxero Tausend dank. #replyflut :)",
  "id" : 1688219994,
  "in_reply_to_status_id" : 1688113818,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1688345711",
  "text" : "Oh Nein! Galileo \u00FCber die Schweinegrippe. Eigentlich ein Fall f\u00FCr Galileo Mystery!!",
  "id" : 1688345711,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688323585",
  "geo" : { },
  "id_str" : "1688349408",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod da hast du auch ganz ungeheim recht!",
  "id" : 1688349408,
  "in_reply_to_status_id" : 1688323585,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688410742",
  "geo" : { },
  "id_str" : "1688561250",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Du wirst eh bei Tweetie bleiben ;)",
  "id" : 1688561250,
  "in_reply_to_status_id" : 1688410742,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688594712",
  "geo" : { },
  "id_str" : "1688624122",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod push f\u00FCr Twitter finde ich glaube ich \u00FCberfl\u00FCssig. Jeden Tweet pushen w\u00E4re Overkill und die Anzahl neuer ist nur bedingt hilfreich.",
  "id" : 1688624122,
  "in_reply_to_status_id" : 1688594712,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688709567",
  "geo" : { },
  "id_str" : "1688738182",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ok, f\u00FCr DMs und vielleicht auch replies ganz spannend. :)",
  "id" : 1688738182,
  "in_reply_to_status_id" : 1688709567,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Fischer",
      "screen_name" : "phomac",
      "indices" : [ 0, 7 ],
      "id_str" : "15147217",
      "id" : 15147217
    }, {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 24, 31 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688699611",
  "geo" : { },
  "id_str" : "1688746119",
  "in_reply_to_user_id" : 15147217,
  "text" : "@phomac Der Einwand von @ComPod ist aber ganz gut: Replies und DMs",
  "id" : 1688746119,
  "in_reply_to_status_id" : 1688699611,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "phomac",
  "in_reply_to_user_id_str" : "15147217",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688858194",
  "geo" : { },
  "id_str" : "1688908265",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee noch nicht! Angeblich soll das irgendwann zwischen Mac und iPhone-Tweetie gehen.",
  "id" : 1688908265,
  "in_reply_to_status_id" : 1688858194,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688937953",
  "geo" : { },
  "id_str" : "1688956704",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee laut dem Entwickler w\u00FCrde sich das \u00E4ndern sobald man synchronisieren k\u00F6nnte. Ich bin gespannt ob Twitter das einfach einf\u00FChren wird",
  "id" : 1688956704,
  "in_reply_to_status_id" : 1688937953,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1688973368",
  "geo" : { },
  "id_str" : "1689033040",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee Ich finde Eventbox besser ;)",
  "id" : 1689033040,
  "in_reply_to_status_id" : 1688973368,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1689088507",
  "geo" : { },
  "id_str" : "1689153134",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee bei mir ist es genau umgekehrt.",
  "id" : 1689153134,
  "in_reply_to_status_id" : 1689088507,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1689398923",
  "text" : "Dies ist ein Belangloser 5001. Tweet!",
  "id" : 1689398923,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1689316846",
  "geo" : { },
  "id_str" : "1689405250",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Lass mich erstmal deinen Content h\u00F6ren ;)",
  "id" : 1689405250,
  "in_reply_to_status_id" : 1689316846,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1689483092",
  "geo" : { },
  "id_str" : "1689530766",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ich dachte iTunes macht das von selbst? ;)",
  "id" : 1689530766,
  "in_reply_to_status_id" : 1689483092,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tv",
      "indices" : [ 47, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1689536091",
  "text" : "Nun wird entspannt Inspector Barnaby geschaut. #tv",
  "id" : 1689536091,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1689579097",
  "geo" : { },
  "id_str" : "1689590718",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod bei iTunes w\u00FCrde ich eigentlich opt-out vermuten",
  "id" : 1689590718,
  "in_reply_to_status_id" : 1689579097,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1689621971",
  "geo" : { },
  "id_str" : "1689784278",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Tja, geht mir nicht anders. Daf\u00FCr jeden Monat gut Zahlen ;)",
  "id" : 1689784278,
  "in_reply_to_status_id" : 1689621971,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1689858500",
  "text" : "Ich leg dann mal das iPhone beiseite f\u00FCr heute!",
  "id" : 1689858500,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1685367101",
  "text" : "Cool, ich darf das neue Twitterfon betatesten!",
  "id" : 1685367101,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1685433480",
  "text" : "Also das Landscape-Feature von TwitterFon Pro ist schonmal sehr praktisch. Gleich mal die Themes ausprobieren.",
  "id" : 1685433480,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1685433553",
  "text" : "Also das Landscape-Feature von TwitterFon Pro ist schonmal sehr praktisch. Gleich mal die Themes ausprobieren.",
  "id" : 1685433553,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitterFon",
      "screen_name" : "TwitterFon",
      "indices" : [ 0, 11 ],
      "id_str" : "15613175",
      "id" : 15613175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1685474533",
  "in_reply_to_user_id" : 15613175,
  "text" : "@TwitterFon ist there no option to reload in the pro-App to refresh without shaking?",
  "id" : 1685474533,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "TwitterFon",
  "in_reply_to_user_id_str" : "15613175",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitterFon",
      "screen_name" : "TwitterFon",
      "indices" : [ 0, 11 ],
      "id_str" : "15613175",
      "id" : 15613175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1685486137",
  "in_reply_to_user_id" : 15613175,
  "text" : "@twitterfon  http:\/\/twitpic.com\/4gw24",
  "id" : 1685486137,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "TwitterFon",
  "in_reply_to_user_id_str" : "15613175",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 3, 18 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1685554200",
  "text" : "RT @andreasklinger: stackoverflow at its best: http:\/\/cli.gs\/eUHNQ0 love it :)",
  "id" : 1685554200,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1685865470",
  "text" : "Eine Runde Left4Dead am morgen, vertreibt Zombies und Sorgen!",
  "id" : 1685865470,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1686113396",
  "text" : "Also ich finde die iTunes-Funktion des DJs mit den Wahlen durch iPhone-User nett. Vermutlich noch toller wenn alle G\u00E4ste abstimmen k\u00F6nnen.",
  "id" : 1686113396,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer | DMs are open",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1686141399",
  "geo" : { },
  "id_str" : "1686149955",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Ich freue mich \u00FCber das Landscape-Keyboard! Vermisse aber den Reload-Button.",
  "id" : 1686149955,
  "in_reply_to_status_id" : 1686141399,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1686182675",
  "text" : "Der Hund kann zwar mittlerweile auf 3 Beinen pinkeln. Ist dabei aber auch zielsicher genug immer seine eigenen Pfoten zu treffen.",
  "id" : 1686182675,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1686190789",
  "geo" : { },
  "id_str" : "1686195683",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Ne, ich aktualisiere bei shake-to-reload immer ausversehen beim laufen ;)",
  "id" : 1686195683,
  "in_reply_to_status_id" : 1686190789,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luca Hammer | DMs are open",
      "screen_name" : "luca",
      "indices" : [ 0, 5 ],
      "id_str" : "11985982",
      "id" : 11985982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1686212535",
  "geo" : { },
  "id_str" : "1686273830",
  "in_reply_to_user_id" : 11985982,
  "text" : "@Luca Naja im laufen Twitter lesen geht ganz gut. Nur nicht wenn andauernd die Zeile dank Refresh verschoben wird ;)",
  "id" : 1686273830,
  "in_reply_to_status_id" : 1686212535,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "luca",
  "in_reply_to_user_id_str" : "11985982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1686274549",
  "text" : "Und weiter Californication",
  "id" : 1686274549,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1686810634",
  "text" : "Twitterfon Pro &gt; Tweetie",
  "id" : 1686810634,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1686846639",
  "geo" : { },
  "id_str" : "1687645418",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee Keyboard rotiert per Beschleunigungssensoren. ;) aber das ganze look & feel sagt mir einfach mehr zu. Multi-Accounts gehen nun auch",
  "id" : 1687645418,
  "in_reply_to_status_id" : 1686846639,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1687737828",
  "geo" : { },
  "id_str" : "1687794861",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee die Hubbles sind f\u00FCr DM Super aber sonst total unpraktisch weil Platzverschwendung.",
  "id" : 1687794861,
  "in_reply_to_status_id" : 1687737828,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Test",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1687859996",
  "text" : "Mag mir mal jemand ein reply senden? #Test",
  "id" : 1687859996,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    }, {
      "name" : "T. Smith",
      "screen_name" : "tilmar",
      "indices" : [ 8, 15 ],
      "id_str" : "2163562470",
      "id" : 2163562470
    }, {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 16, 23 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1687871855",
  "text" : "@JoergR @TilMar @thopex Danke! Das nennt man Service. Hab mich nun f\u00FCr Silver als TwitterFon-Theme entschieden! :)",
  "id" : 1687871855,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    }, {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 8, 17 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1687874777",
  "geo" : { },
  "id_str" : "1687912712",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ @monimays auch euch beiden noch vielen Dank :)",
  "id" : 1687912712,
  "in_reply_to_status_id" : 1687874777,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1687898107",
  "geo" : { },
  "id_str" : "1687919578",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex ist in manchen Bereichen etwas buggy aber sonst sehr sch\u00F6n :)",
  "id" : 1687919578,
  "in_reply_to_status_id" : 1687898107,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1687921344",
  "geo" : { },
  "id_str" : "1687949673",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ ich hab geschaut wie welche Themes @-Replies in der normalen Timeline highlighten.",
  "id" : 1687949673,
  "in_reply_to_status_id" : 1687921344,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 0, 8 ],
      "id_str" : "14317484",
      "id" : 14317484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1687941817",
  "geo" : { },
  "id_str" : "1687958040",
  "in_reply_to_user_id" : 14317484,
  "text" : "@philbee Achso. Ja das ist f\u00FCr mich auch der gro\u00DFe Vorteil von Twitterfon. Zusammen Mit der farblichen Markierung.",
  "id" : 1687958040,
  "in_reply_to_status_id" : 1687941817,
  "created_at" : "2009-05-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "philbee",
  "in_reply_to_user_id_str" : "14317484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1677373889",
  "text" : "Moin moin",
  "id" : 1677373889,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1677479401",
  "text" : "Dawkins TED-Talk zum Fr\u00FChst\u00FCck!",
  "id" : 1677479401,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1677968862",
  "text" : "@JoergR gibt es Studentenrabatt? ;)",
  "id" : 1677968862,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitterFon",
      "screen_name" : "TwitterFon",
      "indices" : [ 21, 32 ],
      "id_str" : "15613175",
      "id" : 15613175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1677985813",
  "text" : "Ich bin ja total auf @twitterfon pro gespannt.",
  "id" : 1677985813,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1677993802",
  "text" : "@JoergR dann bin ich gespannt weil ganz so g\u00FCnstig ist das f\u00FCr arme Studenten nicht ;)",
  "id" : 1677993802,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1678301406",
  "text" : "Heute Abend mal Crank2 schauen",
  "id" : 1678301406,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1678462262",
  "text" : "Neuer W&W-Post: Hier was zu lachen f\u00FCr die Biologen und andere Wissenschaftler - Tanzender Papagei: http:\/\/tr.im\/khR7",
  "id" : 1678462262,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1678871349",
  "geo" : { },
  "id_str" : "1679192108",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Wer w\u00FCrde sich denn auch nicht \u00FCber einen Rabatt freuen? ;)",
  "id" : 1679192108,
  "in_reply_to_status_id" : 1678871349,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1680269106",
  "text" : "Gib mir Wurst!! http:\/\/twitpic.com\/4f2gz",
  "id" : 1680269106,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1681437394",
  "text" : "Was spielen wir? http:\/\/twitpic.com\/4fisk",
  "id" : 1681437394,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1681445478",
  "geo" : { },
  "id_str" : "1681561907",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu ja. Und kleiner Tipp: Die Damen sind die zweitschlechtesten Karten im Spiel! ;)",
  "id" : 1681561907,
  "in_reply_to_status_id" : 1681445478,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johannes Kleske",
      "screen_name" : "jkleske",
      "indices" : [ 3, 11 ],
      "id_str" : "623453",
      "id" : 623453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Klischees",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1681565379",
  "text" : "RT @jkleske: Die M\u00E4dels gehen aufs Klo, die Jungs gehen twittern. #Klischees",
  "id" : 1681565379,
  "created_at" : "2009-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1668162737",
  "text" : "Heut ist mal ein echt fauler Tag!",
  "id" : 1668162737,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1668381441",
  "text" : "Heut gibt es Kaffee und Kuchen anstatt Fleisch und Bier!",
  "id" : 1668381441,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1668634610",
  "text" : "Hab ich schonmal erw\u00E4hnt wie grausam ich Depeche Mode finde?",
  "id" : 1668634610,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1668719531",
  "text" : "@JoergR Ja ganz grausam dieses Zeug. Verstehe nicht wie man darauf abfahren kann. Oder warum die immer noch CDs produzieren...",
  "id" : 1668719531,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "muensterana",
      "screen_name" : "muensterana",
      "indices" : [ 0, 12 ],
      "id_str" : "26782616",
      "id" : 26782616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1668768169",
  "geo" : { },
  "id_str" : "1668785397",
  "in_reply_to_user_id" : 26782616,
  "text" : "@muensterana Meine Vermutung ist dass Depeche Mode so ein Frauen-Ph\u00E4nomen sind. Kenne keine m\u00E4nnlichen Fans.",
  "id" : 1668785397,
  "in_reply_to_status_id" : 1668768169,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "muensterana",
  "in_reply_to_user_id_str" : "26782616",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1668967634",
  "text" : "Lecker!  http:\/\/twitpic.com\/4bz25",
  "id" : 1668967634,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1670249735",
  "text" : "Ok ok, heute Abend wird doch nochmal gegrillt.",
  "id" : 1670249735,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1670665390",
  "geo" : { },
  "id_str" : "1670955636",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Lad mich ma ein mitzukommen ;)",
  "id" : 1670955636,
  "in_reply_to_status_id" : 1670665390,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1671045828",
  "text" : "Letzten Monat 777 Tweets geschrieben.",
  "id" : 1671045828,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1671752090",
  "text" : "Jetzt: Californication! \u201CWhip it up Moody! One girl, two cocks! Ultimate showdown!\u201D",
  "id" : 1671752090,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gunnar Lott",
      "screen_name" : "HerrKaliban",
      "indices" : [ 0, 12 ],
      "id_str" : "16945253",
      "id" : 16945253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1671766983",
  "geo" : { },
  "id_str" : "1671777858",
  "in_reply_to_user_id" : 16945253,
  "text" : "@HerrKaliban Ich w\u00FCrd ja sagen: Left 4 Dead!",
  "id" : 1671777858,
  "in_reply_to_status_id" : 1671766983,
  "created_at" : "2009-05-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrKaliban",
  "in_reply_to_user_id_str" : "16945253",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]