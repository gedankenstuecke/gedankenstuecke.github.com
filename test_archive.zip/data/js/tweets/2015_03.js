Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583023454804451328",
  "geo" : { },
  "id_str" : "583024123636514817",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich was macht die Magisterarbeit denn? :)",
  "id" : 583024123636514817,
  "in_reply_to_status_id" : 583023454804451328,
  "created_at" : "2015-03-31 21:52:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583023454804451328",
  "geo" : { },
  "id_str" : "583024075859193857",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Okay, damit haben wir noch ein kleines Zeitfenster bis ich wieder das Land verlasse :D",
  "id" : 583024075859193857,
  "in_reply_to_status_id" : 583023454804451328,
  "created_at" : "2015-03-31 21:52:26 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583021028395368450",
  "geo" : { },
  "id_str" : "583023234767036416",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich well played. Welche Termine\/Tage gingen bei dir noch mal prinzipiell nur schlecht?",
  "id" : 583023234767036416,
  "in_reply_to_status_id" : 583021028395368450,
  "created_at" : "2015-03-31 21:49:05 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583020094005092352",
  "geo" : { },
  "id_str" : "583020384649392128",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich I\u2019m heading out again tomorrow, but will be back at 20th of April (insert obvious joke here).",
  "id" : 583020384649392128,
  "in_reply_to_status_id" : 583020094005092352,
  "created_at" : "2015-03-31 21:37:46 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583018662245883904",
  "geo" : { },
  "id_str" : "583019025845862400",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich I guess by now we really have to go through all cuts in one evening. :D",
  "id" : 583019025845862400,
  "in_reply_to_status_id" : 583018662245883904,
  "created_at" : "2015-03-31 21:32:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/1xxGhXUyNJ",
      "expanded_url" : "https:\/\/instagram.com\/p\/06D6QkBwre\/",
      "display_url" : "instagram.com\/p\/06D6QkBwre\/"
    } ]
  },
  "geo" : { },
  "id_str" : "583018340802830336",
  "text" : "It's too bad she won't live. https:\/\/t.co\/1xxGhXUyNJ",
  "id" : 583018340802830336,
  "created_at" : "2015-03-31 21:29:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583013252285771778",
  "geo" : { },
  "id_str" : "583017682318020609",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @gedankenabfall daf\u00FCr fahr ich ja gerne raus. :)",
  "id" : 583017682318020609,
  "in_reply_to_status_id" : 583013252285771778,
  "created_at" : "2015-03-31 21:27:02 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583010598390276097",
  "geo" : { },
  "id_str" : "583010884181692416",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @gedankenabfall Kein Buch, spiele zur Zeit Red Queen-Hypothesis gegen mich selbst. ;-)",
  "id" : 583010884181692416,
  "in_reply_to_status_id" : 583010598390276097,
  "created_at" : "2015-03-31 21:00:01 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 16, 23 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583009821340884994",
  "geo" : { },
  "id_str" : "583010110131277824",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall @ewyler 07.04. w\u00FCrde bei mir passen, wenn auch noch ohne Unterkunft.",
  "id" : 583010110131277824,
  "in_reply_to_status_id" : 583009821340884994,
  "created_at" : "2015-03-31 20:56:56 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583009635457769472",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @gedankenabfall Irgendwer von euch wollte das ich bald mal nach Berlin komme, oder?",
  "id" : 583009635457769472,
  "created_at" : "2015-03-31 20:55:03 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/EBXXK70I5K",
      "expanded_url" : "http:\/\/germanitlaw.com\/?p=1040",
      "display_url" : "germanitlaw.com\/?p=1040"
    } ]
  },
  "in_reply_to_status_id_str" : "582952405454716928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08383100310702, 8.24080429462414 ]
  },
  "id_str" : "582952971299917824",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @wilbanks found it: http:\/\/t.co\/EBXXK70I5K",
  "id" : 582952971299917824,
  "in_reply_to_status_id" : 582952405454716928,
  "created_at" : "2015-03-31 17:09:53 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582951561237774336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08381736827153, 8.240847753556734 ]
  },
  "id_str" : "582952292065906688",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @wilbanks wasn\u2019t that overthrown by a higher court by now? But I agree in principle.",
  "id" : 582952292065906688,
  "in_reply_to_status_id" : 582951561237774336,
  "created_at" : "2015-03-31 17:07:11 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 9, 18 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582940593845760000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08384557912538, 8.240749203033564 ]
  },
  "id_str" : "582941135334727681",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish @wilbanks well, only the being called rogue part is missing for me!",
  "id" : 582941135334727681,
  "in_reply_to_status_id" : 582940593845760000,
  "created_at" : "2015-03-31 16:22:51 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582938064378597376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08396667238647, 8.240758443365248 ]
  },
  "id_str" : "582938759357968384",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @wilbanks the license isn\u2019t ideal, I agree. Makes reuse in openSNP not easy already.",
  "id" : 582938759357968384,
  "in_reply_to_status_id" : 582938064378597376,
  "created_at" : "2015-03-31 16:13:25 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582924536238100480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08381676465734, 8.240882086847687 ]
  },
  "id_str" : "582935905436082176",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks yeah, we would like to be called rogue too! :D",
  "id" : 582935905436082176,
  "in_reply_to_status_id" : 582924536238100480,
  "created_at" : "2015-03-31 16:02:04 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 108, 117 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/OFshwSbNHp",
      "expanded_url" : "http:\/\/m.jme.bmj.com\/content\/early\/2015\/03\/30\/medethics-2015-102663.full?view=full&uritype=cgi",
      "display_url" : "m.jme.bmj.com\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08383608210683, 8.240849421284697 ]
  },
  "id_str" : "582935559359893506",
  "text" : "My weird publications: \u00ABResearch led by participants: a new social contract for a new kind of research\u00BB \/cc @wilbanks http:\/\/t.co\/OFshwSbNHp",
  "id" : 582935559359893506,
  "created_at" : "2015-03-31 16:00:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582833967876972544",
  "geo" : { },
  "id_str" : "582834444836433920",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson oh, I remember that, another software painful to use :D",
  "id" : 582834444836433920,
  "in_reply_to_status_id" : 582833967876972544,
  "created_at" : "2015-03-31 09:18:54 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 47, 60 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582827900262576128",
  "geo" : { },
  "id_str" : "582831595117260800",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch I don\u2019t think so, what about you, @PhilippBayer?",
  "id" : 582831595117260800,
  "in_reply_to_status_id" : 582827900262576128,
  "created_at" : "2015-03-31 09:07:35 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582638546894356480",
  "geo" : { },
  "id_str" : "582638719343157248",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me that\u2019s all too punny!",
  "id" : 582638719343157248,
  "in_reply_to_status_id" : 582638546894356480,
  "created_at" : "2015-03-30 20:21:10 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582635118298312706",
  "geo" : { },
  "id_str" : "582635441767247872",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me not even sure if the pun would be on young earth creationism or on CG Jung. :p",
  "id" : 582635441767247872,
  "in_reply_to_status_id" : 582635118298312706,
  "created_at" : "2015-03-30 20:08:08 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582633464383578112",
  "geo" : { },
  "id_str" : "582634253713846272",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me just with even less data for grand claims.",
  "id" : 582634253713846272,
  "in_reply_to_status_id" : 582633464383578112,
  "created_at" : "2015-03-30 20:03:25 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582633045301170176",
  "text" : "\u00AB[EvoPsych] is a branch of academic life that consists entirely, as far as I can see, of making up what would seem to be plausible stories\u00BB",
  "id" : 582633045301170176,
  "created_at" : "2015-03-30 19:58:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 41, 54 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/ZJAgwV3HHn",
      "expanded_url" : "https:\/\/evolution-institute.org\/article\/the-spandrels-of-san-marco-revisited-an-interview-with-richard-c-lewontin\/",
      "display_url" : "evolution-institute.org\/article\/the-sp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582632906440503297",
  "text" : "The Spandrels Of San Marco Revisited \/cc @PhilippBayer https:\/\/t.co\/ZJAgwV3HHn",
  "id" : 582632906440503297,
  "created_at" : "2015-03-30 19:58:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/jfVsExuLDf",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/parallels\/2015\/03\/25\/393557932\/a-couple-spends-their-millions-to-save-migrants-in-the-mediterranean",
      "display_url" : "npr.org\/blogs\/parallel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582302833527144448",
  "text" : "Couple Spends Millions To Save Migrants In The Mediterranean http:\/\/t.co\/jfVsExuLDf",
  "id" : 582302833527144448,
  "created_at" : "2015-03-29 22:06:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/09Fwzf9fNT",
      "expanded_url" : "https:\/\/instagram.com\/p\/00hr5ohwrW\/",
      "display_url" : "instagram.com\/p\/00hr5ohwrW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "582239397162192896",
  "text" : "Why it took me so long to get home #latergram https:\/\/t.co\/09Fwzf9fNT",
  "id" : 582239397162192896,
  "created_at" : "2015-03-29 17:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "582010451887726592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04512405395865, 8.560821533209262 ]
  },
  "id_str" : "582104554977804289",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish can't wait for it. :-)",
  "id" : 582104554977804289,
  "in_reply_to_status_id" : 582010451887726592,
  "created_at" : "2015-03-29 08:58:35 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 45, 53 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61895533394102, -122.3941135394212 ]
  },
  "id_str" : "581954009340243968",
  "text" : "Goodbye SF and thanks for the lovely hosting @punkish. Hope we\u2019ll meet in Europe soon.",
  "id" : 581954009340243968,
  "created_at" : "2015-03-28 23:00:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581942678444736512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61870348430888, -122.3931362552057 ]
  },
  "id_str" : "581943429980037120",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but I\u2019m happy to provide some funny pictures of myself for your next deck ;)",
  "id" : 581943429980037120,
  "in_reply_to_status_id" : 581942678444736512,
  "created_at" : "2015-03-28 22:18:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581941934094225408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61865692229103, -122.3931731860316 ]
  },
  "id_str" : "581942192312205313",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, the ETH deck. I usually don't include myself on the team-slide when giving the talk. ;)",
  "id" : 581942192312205313,
  "in_reply_to_status_id" : 581941934094225408,
  "created_at" : "2015-03-28 22:13:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 14, 25 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581941571085561856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61865692229103, -122.3931731860316 ]
  },
  "id_str" : "581941756523991040",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @openSNPorg neato, which slide deck did you go with? :D",
  "id" : 581941756523991040,
  "in_reply_to_status_id" : 581941571085561856,
  "created_at" : "2015-03-28 22:11:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 111, 120 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61854991415355, -122.3934488374413 ]
  },
  "id_str" : "581932741643530240",
  "text" : "8 year-old to his friend of same age at SFO: \u00ABWanna hear something really scary? Copyright Infringement!\u00BB  \/cc @Senficon",
  "id" : 581932741643530240,
  "created_at" : "2015-03-28 21:35:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581928609301995520",
  "text" : "RT @DanGraur: We used to be \"customers\" at gas stations and grocery stores; now we are \"guests.\" The \"disneyfication\" of language. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/uqwzavAYW1",
        "expanded_url" : "http:\/\/nyti.ms\/1yjO5fv",
        "display_url" : "nyti.ms\/1yjO5fv"
      } ]
    },
    "geo" : { },
    "id_str" : "581825218601201664",
    "text" : "We used to be \"customers\" at gas stations and grocery stores; now we are \"guests.\" The \"disneyfication\" of language. http:\/\/t.co\/uqwzavAYW1",
    "id" : 581825218601201664,
    "created_at" : "2015-03-28 14:28:36 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 581928609301995520,
  "created_at" : "2015-03-28 21:19:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61869320112133, -122.393452086772 ]
  },
  "id_str" : "581925368237543424",
  "text" : "\u00ABAny chance that there\u2019s a strike today?\u00BB \u2014 \u00ABNo, sorry mate. You will have to go home today.\u00BB",
  "id" : 581925368237543424,
  "created_at" : "2015-03-28 21:06:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hendry",
      "screen_name" : "EcoEvoEvoEco",
      "indices" : [ 3, 16 ],
      "id_str" : "2387414858",
      "id" : 2387414858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/zKOmbzgj4M",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC2572075\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581842076720975872",
  "text" : "RT @EcoEvoEvoEco: Shocked by difference in words 4 male vs female recommendation letters for faculty positions: http:\/\/t.co\/zKOmbzgj4M http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EcoEvoEvoEco\/status\/580594532535898112\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/QNL3NPokuv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CA6vpngWYAAwoqh.jpg",
        "id_str" : "580594531491536896",
        "id" : 580594531491536896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA6vpngWYAAwoqh.jpg",
        "sizes" : [ {
          "h" : 328,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/QNL3NPokuv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/zKOmbzgj4M",
        "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC2572075\/",
        "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580594532535898112",
    "text" : "Shocked by difference in words 4 male vs female recommendation letters for faculty positions: http:\/\/t.co\/zKOmbzgj4M http:\/\/t.co\/QNL3NPokuv",
    "id" : 580594532535898112,
    "created_at" : "2015-03-25 04:58:18 +0000",
    "user" : {
      "name" : "Andrew Hendry",
      "screen_name" : "EcoEvoEvoEco",
      "protected" : false,
      "id_str" : "2387414858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444153849662550017\/R6KsGRDf_normal.jpeg",
      "id" : 2387414858,
      "verified" : false
    }
  },
  "id" : 581842076720975872,
  "created_at" : "2015-03-28 15:35:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/1ulHS2EpiV",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/eH1nXoAoVvw\/map-of-all-the-locations-in-to.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.796627, -122.422075 ]
  },
  "id_str" : "581838516029497344",
  "text" : "Map of all the locations in Tom Waits'\u00A0songs http:\/\/t.co\/1ulHS2EpiV",
  "id" : 581838516029497344,
  "created_at" : "2015-03-28 15:21:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/gw040bdwJy",
      "expanded_url" : "https:\/\/instagram.com\/p\/0xjNgbhwrf\/",
      "display_url" : "instagram.com\/p\/0xjNgbhwrf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "581820797104222208",
  "text" : "Golden Gate https:\/\/t.co\/gw040bdwJy",
  "id" : 581820797104222208,
  "created_at" : "2015-03-28 14:11:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581752315889205248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7959987661222, -122.4169391860463 ]
  },
  "id_str" : "581816402610262017",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch thanks!",
  "id" : 581816402610262017,
  "in_reply_to_status_id" : 581752315889205248,
  "created_at" : "2015-03-28 13:53:34 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/vg9SwCsljY",
      "expanded_url" : "https:\/\/instagram.com\/p\/0wtPSKBwgy\/",
      "display_url" : "instagram.com\/p\/0wtPSKBwgy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "581701849394315264",
  "text" : "A symbol of how much I've given into touristic peer pressure since my last visit to SF. https:\/\/t.co\/vg9SwCsljY",
  "id" : 581701849394315264,
  "created_at" : "2015-03-28 06:18:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "canned valley",
      "screen_name" : "binaricorn",
      "indices" : [ 0, 11 ],
      "id_str" : "18158426",
      "id" : 18158426
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 86, 99 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 100, 112 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581658568262336512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78551848357944, -122.4149983124696 ]
  },
  "id_str" : "581661484758994944",
  "in_reply_to_user_id" : 18158426,
  "text" : "@binaricorn thanks for notice. We are still running it but the server is crashed atm. @PhilippBayer @helgerausch could one of you reboot?",
  "id" : 581661484758994944,
  "in_reply_to_status_id" : 581658568262336512,
  "created_at" : "2015-03-28 03:37:59 +0000",
  "in_reply_to_screen_name" : "binaricorn",
  "in_reply_to_user_id_str" : "18158426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/581607235404460032\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/Ol38knc8Su",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBJIsrVU8AAICw1.png",
      "id_str" : "581607234267836416",
      "id" : 581607234267836416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBJIsrVU8AAICw1.png",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/Ol38knc8Su"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85653295829969, -122.4798796522808 ]
  },
  "id_str" : "581607235404460032",
  "text" : "I\u2019ve been walking too! http:\/\/t.co\/Ol38knc8Su",
  "id" : 581607235404460032,
  "created_at" : "2015-03-28 00:02:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85653504012465, -122.4799105355533 ]
  },
  "id_str" : "581603666613772288",
  "text" : "\u00ABI\u2019ll go for a \u2018Total Domination IPA\u2019.\u00BB \u2014 \u00ABI\u2019ll pass. As a German you can\u2019t try this again\u2026\u00BB",
  "id" : 581603666613772288,
  "created_at" : "2015-03-27 23:48:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/sPnb1rCa34",
      "expanded_url" : "https:\/\/instagram.com\/p\/0wAOzsBwqb\/",
      "display_url" : "instagram.com\/p\/0wAOzsBwqb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "581602875991789568",
  "text" : "My new exit strategy if Academia doesn't work out. https:\/\/t.co\/sPnb1rCa34",
  "id" : 581602875991789568,
  "created_at" : "2015-03-27 23:45:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/egtYgsXiaG",
      "expanded_url" : "https:\/\/instagram.com\/p\/0v3cZ6hwq6\/",
      "display_url" : "instagram.com\/p\/0v3cZ6hwq6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "581583552334172160",
  "text" : "Walking https:\/\/t.co\/egtYgsXiaG",
  "id" : 581583552334172160,
  "created_at" : "2015-03-27 22:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581519138801229824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7925832141661, -122.4042001077493 ]
  },
  "id_str" : "581519391130566656",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish win-win-win ;-)",
  "id" : 581519391130566656,
  "in_reply_to_status_id" : 581519138801229824,
  "created_at" : "2015-03-27 18:13:21 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581515971288047617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79249147454075, -122.4041234496482 ]
  },
  "id_str" : "581518831903965184",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish I really would love to. It\u2019s a lovely neighborhood!",
  "id" : 581518831903965184,
  "in_reply_to_status_id" : 581515971288047617,
  "created_at" : "2015-03-27 18:11:08 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/CR1UNkRNDx",
      "expanded_url" : "https:\/\/instagram.com\/p\/0vYKWrBwjt\/",
      "display_url" : "instagram.com\/p\/0vYKWrBwjt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "581514762061766656",
  "text" : "\/\u02CCd\u0292\u028Ck.st\u0259.p\u0259\u02C8z\u026A\u0283.\u0259n\/ https:\/\/t.co\/CR1UNkRNDx",
  "id" : 581514762061766656,
  "created_at" : "2015-03-27 17:54:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581464620944216064",
  "geo" : { },
  "id_str" : "581466950523490304",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay. :-)",
  "id" : 581466950523490304,
  "in_reply_to_status_id" : 581464620944216064,
  "created_at" : "2015-03-27 14:44:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581458795961925632",
  "geo" : { },
  "id_str" : "581461639624429568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if you need them in another format let me know, i should have them all with me.",
  "id" : 581461639624429568,
  "in_reply_to_status_id" : 581458795961925632,
  "created_at" : "2015-03-27 14:23:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/jPQBoD1YwF",
      "expanded_url" : "http:\/\/www.slideshare.net\/mobile\/gedankenstuecke",
      "display_url" : "slideshare.net\/mobile\/gedanke\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "581456047283445760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79607794970247, -122.4169134301149 ]
  },
  "id_str" : "581456264456052736",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if you still need a deck, try one of those: http:\/\/t.co\/jPQBoD1YwF",
  "id" : 581456264456052736,
  "in_reply_to_status_id" : 581456047283445760,
  "created_at" : "2015-03-27 14:02:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581410106509795328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79607794970247, -122.4169134301149 ]
  },
  "id_str" : "581455846279802880",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sorry. Was still asleep. 7am here now.",
  "id" : 581455846279802880,
  "in_reply_to_status_id" : 581410106509795328,
  "created_at" : "2015-03-27 14:00:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 65, 73 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581355827866443776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79602281526958, -122.416745564126 ]
  },
  "id_str" : "581357007220793344",
  "in_reply_to_user_id" : 15322269,
  "text" : "You hand them a small genome and they take your whole apartment! @punkish",
  "id" : 581357007220793344,
  "in_reply_to_status_id" : 581355827866443776,
  "created_at" : "2015-03-27 07:28:06 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 10, 19 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581274790415220736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78049159578826, -122.4082717194952 ]
  },
  "id_str" : "581276651214008320",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @eramirez with recommendations of both of you I\u2019m now so curious I might go tomorrow!",
  "id" : 581276651214008320,
  "in_reply_to_status_id" : 581274790415220736,
  "created_at" : "2015-03-27 02:08:47 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581258311372165121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.89105622353351, -122.1325990392768 ]
  },
  "id_str" : "581258787203452928",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yeah, me too if I don\u2019t have personal recommendations. :)",
  "id" : 581258787203452928,
  "in_reply_to_status_id" : 581258311372165121,
  "created_at" : "2015-03-27 00:57:48 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581256685836079104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.89605412043949, -122.1061723807531 ]
  },
  "id_str" : "581258125380087809",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez anything in downtown?",
  "id" : 581258125380087809,
  "in_reply_to_status_id" : 581256685836079104,
  "created_at" : "2015-03-27 00:55:11 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.91211402563945, -122.0656469283256 ]
  },
  "id_str" : "581251635671740417",
  "text" : "Okay, San Francisco, which vegetarian non-Burger restaurant can you recommend?",
  "id" : 581251635671740417,
  "created_at" : "2015-03-27 00:29:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581239191297744896",
  "geo" : { },
  "id_str" : "581240216138092544",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk I\u2019m so glad that your perseverance is paying off!",
  "id" : 581240216138092544,
  "in_reply_to_status_id" : 581239191297744896,
  "created_at" : "2015-03-26 23:44:01 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 0, 8 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581237814983057409",
  "geo" : { },
  "id_str" : "581238480350494721",
  "in_reply_to_user_id" : 32340834,
  "text" : "@glyn_dk Wow, well done. Congratulations!",
  "id" : 581238480350494721,
  "in_reply_to_status_id" : 581237814983057409,
  "created_at" : "2015-03-26 23:37:07 +0000",
  "in_reply_to_screen_name" : "glyn_dk",
  "in_reply_to_user_id_str" : "32340834",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ZOfnIAy3nM",
      "expanded_url" : "http:\/\/www.madore.org\/~david\/weblog\/d.2015-03-20.2284.html#d.2015-03-20.2284",
      "display_url" : "madore.org\/~david\/weblog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581237281064771584",
  "text" : "\u00ABThe only possible answer to the word \u201Celeemosynary\u201D is \u201Cgo home, English, you're drunk!\u201D.\u00BB http:\/\/t.co\/ZOfnIAy3nM",
  "id" : 581237281064771584,
  "created_at" : "2015-03-26 23:32:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/baSXFSnQT9",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1004140",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581228745312190464",
  "text" : "Speeding Up Ecological and Evolutionary Computations in R http:\/\/t.co\/baSXFSnQT9",
  "id" : 581228745312190464,
  "created_at" : "2015-03-26 22:58:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/IuHyuh3NQh",
      "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2015\/03\/30\/a-loss-for-words?mbid=rss",
      "display_url" : "newyorker.com\/magazine\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581226365032108032",
  "text" : "a loss for words \u2013 can a dying language be saved? http:\/\/t.co\/IuHyuh3NQh",
  "id" : 581226365032108032,
  "created_at" : "2015-03-26 22:48:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581175081600225280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.91235982939718, -122.0657777368996 ]
  },
  "id_str" : "581175127435427840",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch thx :)",
  "id" : 581175127435427840,
  "in_reply_to_status_id" : 581175081600225280,
  "created_at" : "2015-03-26 19:25:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581174150498246657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.91235982939718, -122.0657777368996 ]
  },
  "id_str" : "581174977908486144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch uh, I don\u2019t know. But well spotted. :-)",
  "id" : 581174977908486144,
  "in_reply_to_status_id" : 581174150498246657,
  "created_at" : "2015-03-26 19:24:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JGI2015",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/3ogRDzGpuj",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/03\/26\/ngs-all-a-dream-everyone-has-to-go-back-to-using-staden\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/03\/26\/ngs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581165637122142208",
  "text" : "Bad news ahead for everyone at #JGI2015: NGS all a dream, everyone has to go back to using Staden https:\/\/t.co\/3ogRDzGpuj",
  "id" : 581165637122142208,
  "created_at" : "2015-03-26 18:47:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aakaash Israni",
      "screen_name" : "44K445H",
      "indices" : [ 3, 11 ],
      "id_str" : "1016141222",
      "id" : 1016141222
    }, {
      "name" : "Pitchfork",
      "screen_name" : "pitchfork",
      "indices" : [ 51, 61 ],
      "id_str" : "14089195",
      "id" : 14089195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/5tbmdD4l4A",
      "expanded_url" : "http:\/\/ift.tt\/1ETyeJh",
      "display_url" : "ift.tt\/1ETyeJh"
    } ]
  },
  "geo" : { },
  "id_str" : "581146598249394176",
  "text" : "RT @44K445H: the unbearable whiteness of indie via @pitchfork http:\/\/t.co\/5tbmdD4l4A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pitchfork",
        "screen_name" : "pitchfork",
        "indices" : [ 38, 48 ],
        "id_str" : "14089195",
        "id" : 14089195
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/5tbmdD4l4A",
        "expanded_url" : "http:\/\/ift.tt\/1ETyeJh",
        "display_url" : "ift.tt\/1ETyeJh"
      } ]
    },
    "geo" : { },
    "id_str" : "581143343800803328",
    "text" : "the unbearable whiteness of indie via @pitchfork http:\/\/t.co\/5tbmdD4l4A",
    "id" : 581143343800803328,
    "created_at" : "2015-03-26 17:19:04 +0000",
    "user" : {
      "name" : "Aakaash Israni",
      "screen_name" : "44K445H",
      "protected" : false,
      "id_str" : "1016141222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484225581736005632\/j4VdAapN_normal.jpeg",
      "id" : 1016141222,
      "verified" : false
    }
  },
  "id" : 581146598249394176,
  "created_at" : "2015-03-26 17:32:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "indices" : [ 3, 15 ],
      "id_str" : "561297215",
      "id" : 561297215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581129946254331904",
  "text" : "RT @jrossibarra: Political stats fact of the day: if you randomly choose a president, you\u2019ll get a Roosevelt with about a 5% FDR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580489013913620480",
    "text" : "Political stats fact of the day: if you randomly choose a president, you\u2019ll get a Roosevelt with about a 5% FDR",
    "id" : 580489013913620480,
    "created_at" : "2015-03-24 21:59:00 +0000",
    "user" : {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "protected" : false,
      "id_str" : "561297215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656691317519466496\/tJ966bzU_normal.png",
      "id" : 561297215,
      "verified" : false
    }
  },
  "id" : 581129946254331904,
  "created_at" : "2015-03-26 16:25:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581125072762597377",
  "geo" : { },
  "id_str" : "581125542893633537",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr aye, same here.",
  "id" : 581125542893633537,
  "in_reply_to_status_id" : 581125072762597377,
  "created_at" : "2015-03-26 16:08:20 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581124561116246016",
  "geo" : { },
  "id_str" : "581124859847000064",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish in a way it is. The device contains a huge laser after all.",
  "id" : 581124859847000064,
  "in_reply_to_status_id" : 581124561116246016,
  "created_at" : "2015-03-26 16:05:38 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581123524347187201",
  "geo" : { },
  "id_str" : "581124590065225728",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr same here, but what about the sharing of incidental findings?",
  "id" : 581124590065225728,
  "in_reply_to_status_id" : 581123524347187201,
  "created_at" : "2015-03-26 16:04:33 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Y4sIQJhAJH",
      "expanded_url" : "https:\/\/instagram.com\/p\/0smlTYBwtC\/",
      "display_url" : "instagram.com\/p\/0smlTYBwtC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "581124260837658624",
  "text" : "I totally didn't cry when seeing this. I just had some long reads in my eyes. https:\/\/t.co\/Y4sIQJhAJH",
  "id" : 581124260837658624,
  "created_at" : "2015-03-26 16:03:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/n2NH9AcAYA",
      "expanded_url" : "http:\/\/www.technologyreview.com\/news\/536096\/genome-study-predicts-dna-of-the-whole-of-iceland\/",
      "display_url" : "technologyreview.com\/news\/536096\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581120922762924032",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr What\u2019s your take on this: http:\/\/t.co\/n2NH9AcAYA :-)",
  "id" : 581120922762924032,
  "created_at" : "2015-03-26 15:49:59 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/n2NH9AcAYA",
      "expanded_url" : "http:\/\/www.technologyreview.com\/news\/536096\/genome-study-predicts-dna-of-the-whole-of-iceland\/",
      "display_url" : "technologyreview.com\/news\/536096\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581120873790214145",
  "text" : "\u00ABWe could save these people from dying prematurely, but we are not, because we as a society haven\u2019t agreed on that\u00BB http:\/\/t.co\/n2NH9AcAYA",
  "id" : 581120873790214145,
  "created_at" : "2015-03-26 15:49:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.93137802965038, -122.0226779734197 ]
  },
  "id_str" : "580929696726138880",
  "text" : "\u00ABWe generate nano-scale explosions. Does sound like fun?!\u00BB",
  "id" : 580929696726138880,
  "created_at" : "2015-03-26 03:10:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JGI2015",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.91233243532987, -122.0656150973755 ]
  },
  "id_str" : "580833865679290370",
  "text" : "One of the definitions of irony: Having a rep of Science talk about the reproducibility crisis and publication bias. #JGI2015",
  "id" : 580833865679290370,
  "created_at" : "2015-03-25 20:49:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 83, 99 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/oENJRJ12a7",
      "expanded_url" : "http:\/\/creativecommons.org\/weblog\/entry\/45228?utm_campaign=sm&utm_medium=twitter&utm_source=twitter1",
      "display_url" : "creativecommons.org\/weblog\/entry\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580784321755103232",
  "text" : "RT @wilbanks: \"A designer and a roomful of lawyers get to work\u201D - the story of the @creativecommons logo http:\/\/t.co\/oENJRJ12a7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Creative Commons",
        "screen_name" : "creativecommons",
        "indices" : [ 69, 85 ],
        "id_str" : "17462723",
        "id" : 17462723
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/oENJRJ12a7",
        "expanded_url" : "http:\/\/creativecommons.org\/weblog\/entry\/45228?utm_campaign=sm&utm_medium=twitter&utm_source=twitter1",
        "display_url" : "creativecommons.org\/weblog\/entry\/4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580774912857632768",
    "text" : "\"A designer and a roomful of lawyers get to work\u201D - the story of the @creativecommons logo http:\/\/t.co\/oENJRJ12a7",
    "id" : 580774912857632768,
    "created_at" : "2015-03-25 16:55:04 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 580784321755103232,
  "created_at" : "2015-03-25 17:32:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophien Kamoun",
      "screen_name" : "KamounLab",
      "indices" : [ 3, 13 ],
      "id_str" : "49270737",
      "id" : 49270737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JGI2015",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/PhZ54OxROd",
      "expanded_url" : "http:\/\/www.wsj.com\/articles\/SB10000872396390444840104577551433143153716",
      "display_url" : "wsj.com\/articles\/SB100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580778526216863744",
  "text" : "RT @KamounLab: #JGI2015 Joan Bennett on increasingomics http:\/\/t.co\/PhZ54OxROd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JGI2015",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/PhZ54OxROd",
        "expanded_url" : "http:\/\/www.wsj.com\/articles\/SB10000872396390444840104577551433143153716",
        "display_url" : "wsj.com\/articles\/SB100\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580777627415228416",
    "text" : "#JGI2015 Joan Bennett on increasingomics http:\/\/t.co\/PhZ54OxROd",
    "id" : 580777627415228416,
    "created_at" : "2015-03-25 17:05:51 +0000",
    "user" : {
      "name" : "Sophien Kamoun",
      "screen_name" : "KamounLab",
      "protected" : false,
      "id_str" : "49270737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456793334954995712\/pbkCp1au_normal.jpeg",
      "id" : 49270737,
      "verified" : false
    }
  },
  "id" : 580778526216863744,
  "created_at" : "2015-03-25 17:09:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack A Gilbert",
      "screen_name" : "gilbertjacka",
      "indices" : [ 36, 49 ],
      "id_str" : "223529798",
      "id" : 223529798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jgi2015",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580765063260164096",
  "text" : "Great kick-off talk this morning by @gilbertjacka. Who said overselling the microbiome couldn\u2019t be fun! #jgi2015",
  "id" : 580765063260164096,
  "created_at" : "2015-03-25 16:15:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 78, 90 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 91, 104 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 105, 114 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/rCiX7Rv5lw",
      "expanded_url" : "http:\/\/futurezone.at\/science\/facebook-fuer-gen-exhibitionisten\/121.260.117",
      "display_url" : "futurezone.at\/science\/facebo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580734809762177024",
  "text" : "Never gets old: \u00ABFacebook f\u00FCr Gen-Exhibitionisten\u00BB http:\/\/t.co\/rCiX7Rv5lw \/cc @helgerausch @PhilippBayer @Senficon",
  "id" : 580734809762177024,
  "created_at" : "2015-03-25 14:15:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 101, 114 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/HuxfM5dbkX",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0118738#sec002",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580404020512219136",
  "text" : "The Red Queen Race between Parasitic Chytrids and Their Host,Planktothrix http:\/\/t.co\/HuxfM5dbkX \/cc @PhilippBayer",
  "id" : 580404020512219136,
  "created_at" : "2015-03-24 16:21:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580387098517176320",
  "geo" : { },
  "id_str" : "580389339785396225",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish just keep trying until you develop Stockholm\u2019s.",
  "id" : 580389339785396225,
  "in_reply_to_status_id" : 580387098517176320,
  "created_at" : "2015-03-24 15:22:56 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/EdQ7VrDckA",
      "expanded_url" : "http:\/\/usermeeting.jgi.doe.gov\/2015-agenda\/",
      "display_url" : "usermeeting.jgi.doe.gov\/2015-agenda\/"
    } ]
  },
  "in_reply_to_status_id_str" : "580370430118076416",
  "geo" : { },
  "id_str" : "580370505032568833",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube http:\/\/t.co\/EdQ7VrDckA :)",
  "id" : 580370505032568833,
  "in_reply_to_status_id" : 580370430118076416,
  "created_at" : "2015-03-24 14:08:05 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580362719620022272",
  "text" : "\u00ABWow, your PI found someone brave or stupid enough to try lichen genomics.\u00BB People here know how to cheer me up.",
  "id" : 580362719620022272,
  "created_at" : "2015-03-24 13:37:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.9142069113246, -122.065769791428 ]
  },
  "id_str" : "580247786647646208",
  "text" : "I\u2019ve been in California for a little over 24 hours and already 3 people offered me places to crash at in Berlin. Something\u2019s off.",
  "id" : 580247786647646208,
  "created_at" : "2015-03-24 06:00:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/xFREUoZ66Q",
      "expanded_url" : "http:\/\/toddharris.net\/blog\/2015\/03\/23\/its-time-to-reboot-bioinformatics-education\/",
      "display_url" : "toddharris.net\/blog\/2015\/03\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580097964598648832",
  "text" : "It\u2019s time to reboot bioinformatics education: \u00ABCast off your Excel shackles\u00BB I couldn\u2019t agree more. http:\/\/t.co\/xFREUoZ66Q",
  "id" : 580097964598648832,
  "created_at" : "2015-03-23 20:05:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ql8VSTKbnb",
      "expanded_url" : "http:\/\/genome.jgi-psf.org\/pages\/fungi-1000-projects.jsf",
      "display_url" : "genome.jgi-psf.org\/pages\/fungi-10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580056951515586560",
  "text" : "The 100 Fungal Genomes Project really shows how undersampled the Lecanoromycetes are: 3\/76 families covered so far http:\/\/t.co\/ql8VSTKbnb",
  "id" : 580056951515586560,
  "created_at" : "2015-03-23 17:22:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "punkish",
      "indices" : [ 0, 8 ],
      "id_str" : "15322269",
      "id" : 15322269
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 9, 18 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580026657680990208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.90460312250035, -122.0636295555203 ]
  },
  "id_str" : "580029565503954944",
  "in_reply_to_user_id" : 15322269,
  "text" : "@punkish @madprime well, there are exceptions to the rule ;)",
  "id" : 580029565503954944,
  "in_reply_to_status_id" : 580026657680990208,
  "created_at" : "2015-03-23 15:33:19 +0000",
  "in_reply_to_screen_name" : "punkish",
  "in_reply_to_user_id_str" : "15322269",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580024155413827584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.90151351322653, -122.0644008892359 ]
  },
  "id_str" : "580025351784542208",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime maybe I suffer from a systemic sampling bias, but from my experience virtually all kids are at least somewhat ;-)",
  "id" : 580025351784542208,
  "in_reply_to_status_id" : 580024155413827584,
  "created_at" : "2015-03-23 15:16:34 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "580021434564665344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.9022556585002, -122.0646856605101 ]
  },
  "id_str" : "580023180829421568",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime I\u2019m somewhat confident that parenting can be seen as an extreme form of exercise.",
  "id" : 580023180829421568,
  "in_reply_to_status_id" : 580021434564665344,
  "created_at" : "2015-03-23 15:07:57 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/AXaL5Mn97i",
      "expanded_url" : "https:\/\/instagram.com\/p\/0kxafrBwtR\/",
      "display_url" : "instagram.com\/p\/0kxafrBwtR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "580022179108155392",
  "text" : "Lost in the hills https:\/\/t.co\/AXaL5Mn97i",
  "id" : 580022179108155392,
  "created_at" : "2015-03-23 15:03:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joint Genome Inst.",
      "screen_name" : "doe_jgi",
      "indices" : [ 29, 37 ],
      "id_str" : "20750406",
      "id" : 20750406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.90232425099012, -122.0647733465413 ]
  },
  "id_str" : "580020448487845888",
  "text" : "Anyone from here also at the @doe_jgi Fungal Genomics \/ User Meeting?",
  "id" : 580020448487845888,
  "created_at" : "2015-03-23 14:57:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 3, 10 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icanhazpdf",
      "indices" : [ 71, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/xUn8FiaSuy",
      "expanded_url" : "http:\/\/www.ala.org\/acrl\/sites\/ala.org.acrl\/files\/content\/conferences\/confsandpreconfs\/2015\/Gardner.pdf",
      "display_url" : "ala.org\/acrl\/sites\/ala\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580019556850126849",
  "text" : "RT @McDawg: Bypassing Interlibrary Loan Via Twitter: An Exploration of #icanhazpdf Requests http:\/\/t.co\/xUn8FiaSuy (PDF) http:\/\/t.co\/nHmZ0t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/McDawg\/status\/579299934807203840\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/nHmZ0tXpo0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAoWOG2WUAEJQpX.png",
        "id_str" : "579299933683077121",
        "id" : 579299933683077121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAoWOG2WUAEJQpX.png",
        "sizes" : [ {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 807
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/nHmZ0tXpo0"
      } ],
      "hashtags" : [ {
        "text" : "icanhazpdf",
        "indices" : [ 59, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/xUn8FiaSuy",
        "expanded_url" : "http:\/\/www.ala.org\/acrl\/sites\/ala.org.acrl\/files\/content\/conferences\/confsandpreconfs\/2015\/Gardner.pdf",
        "display_url" : "ala.org\/acrl\/sites\/ala\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "579299934807203840",
    "text" : "Bypassing Interlibrary Loan Via Twitter: An Exploration of #icanhazpdf Requests http:\/\/t.co\/xUn8FiaSuy (PDF) http:\/\/t.co\/nHmZ0tXpo0",
    "id" : 579299934807203840,
    "created_at" : "2015-03-21 15:14:01 +0000",
    "user" : {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "protected" : false,
      "id_str" : "12432262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708707066026860544\/LnGGYNw1_normal.jpg",
      "id" : 12432262,
      "verified" : false
    }
  },
  "id" : 580019556850126849,
  "created_at" : "2015-03-23 14:53:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karyn MeltzSteinberg",
      "screen_name" : "KMS_Meltzy",
      "indices" : [ 3, 14 ],
      "id_str" : "1425644274",
      "id" : 1425644274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/zbrbW5VS6c",
      "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/03\/23\/each-bioinformatician-to-have-their-own-personal-short-read-aligner-by-2016\/",
      "display_url" : "thescienceweb.wordpress.com\/2015\/03\/23\/eac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580011375793061890",
  "text" : "RT @KMS_Meltzy: \"those who identify themselves as \u201Cbioinformagicians\u201D have been excluded...from life in general\" https:\/\/t.co\/zbrbW5VS6c vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Science Web",
        "screen_name" : "TheScienceWeb",
        "indices" : [ 125, 139 ],
        "id_str" : "2315551122",
        "id" : 2315551122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/zbrbW5VS6c",
        "expanded_url" : "https:\/\/thescienceweb.wordpress.com\/2015\/03\/23\/each-bioinformatician-to-have-their-own-personal-short-read-aligner-by-2016\/",
        "display_url" : "thescienceweb.wordpress.com\/2015\/03\/23\/eac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580005858404225024",
    "text" : "\"those who identify themselves as \u201Cbioinformagicians\u201D have been excluded...from life in general\" https:\/\/t.co\/zbrbW5VS6c via @TheScienceWeb",
    "id" : 580005858404225024,
    "created_at" : "2015-03-23 13:59:07 +0000",
    "user" : {
      "name" : "Karyn MeltzSteinberg",
      "screen_name" : "KMS_Meltzy",
      "protected" : false,
      "id_str" : "1425644274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753988827065311232\/X0IHveuE_normal.jpg",
      "id" : 1425644274,
      "verified" : false
    }
  },
  "id" : 580011375793061890,
  "created_at" : "2015-03-23 14:21:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579990516969955328",
  "geo" : { },
  "id_str" : "580003082618212352",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Somehow I became a \u2018responsible adult\u2019, I didn\u2019t even have to go through the extended security check this time. ;-)",
  "id" : 580003082618212352,
  "in_reply_to_status_id" : 579990516969955328,
  "created_at" : "2015-03-23 13:48:05 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579810101747281920",
  "text" : "When did I go from \u2018that was a long intercontinental flight \u2026 now really want a smoke\u2019 to \u2018\u2026 now I really want to run 5k\u2019?",
  "id" : 579810101747281920,
  "created_at" : "2015-03-23 01:01:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/RK45xtHUnP",
      "expanded_url" : "http:\/\/infoscience.epfl.ch\/record\/205089\/files\/EPFL_TH6515.pdf",
      "display_url" : "infoscience.epfl.ch\/record\/205089\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579792200730431488",
  "text" : "Also incl. openSNP: When Others Impinge upon Your Privacy: Interdependent Risks and Protection in a Connected World http:\/\/t.co\/RK45xtHUnP",
  "id" : 579792200730431488,
  "created_at" : "2015-03-22 23:50:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 81, 94 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 95, 107 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 108, 117 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/uVE4qL6NoT",
      "expanded_url" : "http:\/\/infoscience.epfl.ch\/record\/206773\/files\/main.pdf",
      "display_url" : "infoscience.epfl.ch\/record\/206773\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "579791988402233344",
  "text" : "Quant. Genomic Privacy via Inference Attack with High-Order SNV Correlations \/cc @PhilippBayer @helgerausch @wilbanks http:\/\/t.co\/uVE4qL6NoT",
  "id" : 579791988402233344,
  "created_at" : "2015-03-22 23:49:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579789582260109312",
  "geo" : { },
  "id_str" : "579790183702245376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer stuck in Bernkastel forever? :D",
  "id" : 579790183702245376,
  "in_reply_to_status_id" : 579789582260109312,
  "created_at" : "2015-03-22 23:42:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Tincq",
      "screen_name" : "btincq",
      "indices" : [ 0, 7 ],
      "id_str" : "57441737",
      "id" : 57441737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579580945021423616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61884548239188, -122.4039089308329 ]
  },
  "id_str" : "579762674466197505",
  "in_reply_to_user_id" : 57441737,
  "text" : "@btincq ah, okay. Thanks in any case :)",
  "id" : 579762674466197505,
  "in_reply_to_status_id" : 579580945021423616,
  "created_at" : "2015-03-22 21:52:47 +0000",
  "in_reply_to_screen_name" : "btincq",
  "in_reply_to_user_id_str" : "57441737",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579731548410404865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61884548239188, -122.4039089308329 ]
  },
  "id_str" : "579762630241488897",
  "in_reply_to_user_id" : 296385063,
  "text" : "@jsheetprojects cool, danke!",
  "id" : 579762630241488897,
  "in_reply_to_status_id" : 579731548410404865,
  "created_at" : "2015-03-22 21:52:37 +0000",
  "in_reply_to_screen_name" : "bytenumbers",
  "in_reply_to_user_id_str" : "296385063",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Tincq",
      "screen_name" : "btincq",
      "indices" : [ 0, 7 ],
      "id_str" : "57441737",
      "id" : 57441737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579565908038914048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04725673872294, 8.565547619481375 ]
  },
  "id_str" : "579566352282869760",
  "in_reply_to_user_id" : 57441737,
  "text" : "@btincq any chance of getting photos for the complete article? :-)",
  "id" : 579566352282869760,
  "in_reply_to_status_id" : 579565908038914048,
  "created_at" : "2015-03-22 08:52:40 +0000",
  "in_reply_to_screen_name" : "btincq",
  "in_reply_to_user_id_str" : "57441737",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/Btfk8vTTn3",
      "expanded_url" : "https:\/\/instagram.com\/p\/0ha5nVhwmt\/",
      "display_url" : "instagram.com\/p\/0ha5nVhwmt\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.048891392, 8.571611319 ]
  },
  "id_str" : "579550458714460160",
  "text" : "LH454: FRA \u2708\uFE0F SFO @ Frankfurt Airport https:\/\/t.co\/Btfk8vTTn3",
  "id" : 579550458714460160,
  "created_at" : "2015-03-22 07:49:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Jim Procter",
      "screen_name" : "foreveremain",
      "indices" : [ 10, 23 ],
      "id_str" : "216356099",
      "id" : 216356099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579359437577707520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09937494764657, 8.62134978734209 ]
  },
  "id_str" : "579360962257489920",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @foreveremain agree. It\u2019s a shame that intl law makes it so difficult though.",
  "id" : 579360962257489920,
  "in_reply_to_status_id" : 579359437577707520,
  "created_at" : "2015-03-21 19:16:32 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "579340252151681025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09938741690132, 8.621362954027644 ]
  },
  "id_str" : "579342140989407234",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, I noticed that it\u2019s the same we read the book on. ;)",
  "id" : 579342140989407234,
  "in_reply_to_status_id" : 579340252151681025,
  "created_at" : "2015-03-21 18:01:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/h9d1RCD9gX",
      "expanded_url" : "https:\/\/instagram.com\/p\/0dxLlEhwnY\/",
      "display_url" : "instagram.com\/p\/0dxLlEhwnY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "579036505659830273",
  "text" : "Flehe https:\/\/t.co\/h9d1RCD9gX",
  "id" : 579036505659830273,
  "created_at" : "2015-03-20 21:47:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/qLfgvQo9IM",
      "expanded_url" : "https:\/\/instagram.com\/p\/0dOf36hwmU\/",
      "display_url" : "instagram.com\/p\/0dOf36hwmU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "578960235588657152",
  "text" : "Takeoff https:\/\/t.co\/qLfgvQo9IM",
  "id" : 578960235588657152,
  "created_at" : "2015-03-20 16:44:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578957581659537409",
  "geo" : { },
  "id_str" : "578958359283531776",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze close but no cigar ;-)",
  "id" : 578958359283531776,
  "in_reply_to_status_id" : 578957581659537409,
  "created_at" : "2015-03-20 16:36:44 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/5PxuKDDBL7",
      "expanded_url" : "https:\/\/instagram.com\/p\/0dJeHEBwtS\/",
      "display_url" : "instagram.com\/p\/0dJeHEBwtS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "578949180472844288",
  "text" : "Volmerswerth https:\/\/t.co\/5PxuKDDBL7",
  "id" : 578949180472844288,
  "created_at" : "2015-03-20 16:00:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 15, 23 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    }, {
      "name" : "Frederic",
      "screen_name" : "fredebibs",
      "indices" : [ 24, 34 ],
      "id_str" : "27210534",
      "id" : 27210534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578883641905909760",
  "geo" : { },
  "id_str" : "578884089866022912",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson @PeroMHC @fredebibs iirc there\u2019s also a min length-requirement per match-region? so \u201Cexon\u201D need be x nt long?",
  "id" : 578884089866022912,
  "in_reply_to_status_id" : 578883641905909760,
  "created_at" : "2015-03-20 11:41:36 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 9, 23 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Frederic",
      "screen_name" : "fredebibs",
      "indices" : [ 24, 34 ],
      "id_str" : "27210534",
      "id" : 27210534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578882464099262464",
  "geo" : { },
  "id_str" : "578883045891182593",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC @BioMickWatson @fredebibs as in \u201Cyou need 66 matches over a valid read pair\u201D or for an individual read?",
  "id" : 578883045891182593,
  "in_reply_to_status_id" : 578882464099262464,
  "created_at" : "2015-03-20 11:37:27 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578881079475585025",
  "geo" : { },
  "id_str" : "578881476420362240",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC I know. Just evaluating different assemblers I managed to \u2018convert\u2019 a single MiSeq data set into ~1 TB of \u2018raw\u2019 data\u2026",
  "id" : 578881476420362240,
  "in_reply_to_status_id" : 578881079475585025,
  "created_at" : "2015-03-20 11:31:13 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578880560065544192",
  "geo" : { },
  "id_str" : "578880918959554560",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC because who doesn\u2019t like to use at least twice the space!",
  "id" : 578880918959554560,
  "in_reply_to_status_id" : 578880560065544192,
  "created_at" : "2015-03-20 11:29:00 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 3, 11 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578880804719357952",
  "text" : "RT @PeroMHC: #1 current pet-peeve: When the 1st thing an assembler does is copy the entire friggin' dataset into its preferred format..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "578880560065544192",
    "text" : "#1 current pet-peeve: When the 1st thing an assembler does is copy the entire friggin' dataset into its preferred format..",
    "id" : 578880560065544192,
    "created_at" : "2015-03-20 11:27:35 +0000",
    "user" : {
      "name" : "Matt MacManes",
      "screen_name" : "macmanes",
      "protected" : false,
      "id_str" : "11824072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658589856499503104\/7aezWZpc_normal.jpg",
      "id" : 11824072,
      "verified" : false
    }
  },
  "id" : 578880804719357952,
  "created_at" : "2015-03-20 11:28:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 9, 23 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Frederic",
      "screen_name" : "fredebibs",
      "indices" : [ 24, 34 ],
      "id_str" : "27210534",
      "id" : 27210534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578879073994309632",
  "geo" : { },
  "id_str" : "578880372823441408",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC @BioMickWatson @fredebibs thx as well!",
  "id" : 578880372823441408,
  "in_reply_to_status_id" : 578879073994309632,
  "created_at" : "2015-03-20 11:26:50 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frederic",
      "screen_name" : "fredebibs",
      "indices" : [ 0, 10 ],
      "id_str" : "27210534",
      "id" : 27210534
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 11, 25 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578879250859700224",
  "geo" : { },
  "id_str" : "578880335926149120",
  "in_reply_to_user_id" : 27210534,
  "text" : "@fredebibs @BioMickWatson Thanks :)",
  "id" : 578880335926149120,
  "in_reply_to_status_id" : 578879250859700224,
  "created_at" : "2015-03-20 11:26:41 +0000",
  "in_reply_to_screen_name" : "fredebibs",
  "in_reply_to_user_id_str" : "27210534",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578876466605244416",
  "geo" : { },
  "id_str" : "578876941396275200",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson sounds about right, especially when applying it to non-human data\u2026",
  "id" : 578876941396275200,
  "in_reply_to_status_id" : 578876466605244416,
  "created_at" : "2015-03-20 11:13:12 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578874874615218177",
  "geo" : { },
  "id_str" : "578875693641179137",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson getting the STAR parameters can be tricky. Did you have a look at the supplementary of the paper? Some examples there.",
  "id" : 578875693641179137,
  "in_reply_to_status_id" : 578874874615218177,
  "created_at" : "2015-03-20 11:08:15 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 61, 74 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/kRdY44pTiU",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/1sZOjBzQjkI\/info%3Adoi%2F10.1371%2Fjournal.pone.0118446",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578660279891935233",
  "text" : "Peer-Selected \u201CBest Papers\u201D\u2014Are They Really That \u201CGood\u201D? \/cc @PhilippBayer  http:\/\/t.co\/kRdY44pTiU",
  "id" : 578660279891935233,
  "created_at" : "2015-03-19 20:52:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Holthaus",
      "screen_name" : "EricHolthaus",
      "indices" : [ 3, 16 ],
      "id_str" : "290180065",
      "id" : 290180065
    }, {
      "name" : "nature",
      "screen_name" : "nature",
      "indices" : [ 27, 34 ],
      "id_str" : "487833518",
      "id" : 487833518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578551780839141377",
  "text" : "RT @EricHolthaus: Op-ed in @nature says academics\u2014including climate scientists\u2014must resist the urge to travel by plane. http:\/\/t.co\/pwfrp4y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nature",
        "screen_name" : "nature",
        "indices" : [ 9, 16 ],
        "id_str" : "487833518",
        "id" : 487833518
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/pwfrp4yfir",
        "expanded_url" : "http:\/\/www.nature.com\/news\/a-clean-green-science-machine-1.17125",
        "display_url" : "nature.com\/news\/a-clean-g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578551233226534912",
    "text" : "Op-ed in @nature says academics\u2014including climate scientists\u2014must resist the urge to travel by plane. http:\/\/t.co\/pwfrp4yfir",
    "id" : 578551233226534912,
    "created_at" : "2015-03-19 13:38:57 +0000",
    "user" : {
      "name" : "Eric Holthaus",
      "screen_name" : "EricHolthaus",
      "protected" : false,
      "id_str" : "290180065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884587292387442688\/CZRstbAj_normal.jpg",
      "id" : 290180065,
      "verified" : true
    }
  },
  "id" : 578551780839141377,
  "created_at" : "2015-03-19 13:41:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/ksYdUetL9H",
      "expanded_url" : "http:\/\/www.br.de\/puls\/themen\/netz\/open-snp-plattform-facebook-der-gene-100.html",
      "display_url" : "br.de\/puls\/themen\/ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578549998046044161",
  "text" : "Facebook der Gene \u2013 Der BR \u00FCber openSNP http:\/\/t.co\/ksYdUetL9H",
  "id" : 578549998046044161,
  "created_at" : "2015-03-19 13:34:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578521475746959361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.20753277070344, 6.777355785248496 ]
  },
  "id_str" : "578526035903451136",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez thanks. :)",
  "id" : 578526035903451136,
  "in_reply_to_status_id" : 578521475746959361,
  "created_at" : "2015-03-19 11:58:50 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578518037734801408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.2085592159459, 6.777018865144461 ]
  },
  "id_str" : "578519194083454977",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I didn\u2019t, actually. Have a link to the distribution? Would love to see that. :)",
  "id" : 578519194083454977,
  "in_reply_to_status_id" : 578518037734801408,
  "created_at" : "2015-03-19 11:31:38 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578517361000513536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.20279527021739, 6.780639345110569 ]
  },
  "id_str" : "578517575556009984",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yeah, still subpar of the 15k I would like, but okayish.",
  "id" : 578517575556009984,
  "in_reply_to_status_id" : 578517361000513536,
  "created_at" : "2015-03-19 11:25:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/LjqqpA29ti",
      "expanded_url" : "https:\/\/instagram.com\/p\/0aETOEhwk3\/",
      "display_url" : "instagram.com\/p\/0aETOEhwk3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "578515597950074881",
  "text" : "Roadtripping https:\/\/t.co\/LjqqpA29ti",
  "id" : 578515597950074881,
  "created_at" : "2015-03-19 11:17:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/578512455543971841\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ru4wyuk5R3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAdKAzLWYAA2oUH.png",
      "id_str" : "578512454738665472",
      "id" : 578512454738665472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAdKAzLWYAA2oUH.png",
      "sizes" : [ {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1398
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ru4wyuk5R3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578510931354750976",
  "geo" : { },
  "id_str" : "578512455543971841",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez linear model fit for my daily step count (blue) vs. naive plot of the mean step count (red) :p http:\/\/t.co\/ru4wyuk5R3",
  "id" : 578512455543971841,
  "in_reply_to_status_id" : 578510931354750976,
  "created_at" : "2015-03-19 11:04:52 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    }, {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 12, 19 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578510659111006208",
  "geo" : { },
  "id_str" : "578512138811154432",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke @Bediko no pain, no gain ;-)",
  "id" : 578512138811154432,
  "in_reply_to_status_id" : 578510659111006208,
  "created_at" : "2015-03-19 11:03:36 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/zMBwycz3VA",
      "expanded_url" : "http:\/\/1.bp.blogspot.com\/-Uvu02HO_TwY\/VCo0N3xRtyI\/AAAAAAAACOY\/cQQMq78wksY\/s1600\/Fig4.png",
      "display_url" : "1.bp.blogspot.com\/-Uvu02HO_TwY\/V\u2026"
    }, {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/4IIcIyHbLd",
      "expanded_url" : "http:\/\/daniellakens.blogspot.de\/2014\/09\/what-p-hacking-really-looks-like.html",
      "display_url" : "daniellakens.blogspot.de\/2014\/09\/what-p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "578510931354750976",
  "geo" : { },
  "id_str" : "578511085629755392",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes, it\u2019s the low hanging fruit for each day. Reminds me a bit of http:\/\/t.co\/zMBwycz3VA (src: http:\/\/t.co\/4IIcIyHbLd)",
  "id" : 578511085629755392,
  "in_reply_to_status_id" : 578510931354750976,
  "created_at" : "2015-03-19 10:59:25 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578510237906268160",
  "geo" : { },
  "id_str" : "578510576034414592",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez yes, you can immediately see how a) I\u2019m catching up on sleep on weekends and b) my office is on a hill ;-)",
  "id" : 578510576034414592,
  "in_reply_to_status_id" : 578510237906268160,
  "created_at" : "2015-03-19 10:57:24 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578508582997639169",
  "geo" : { },
  "id_str" : "578508839227650048",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich yep, floors climbed werden ebenfalls erfasst.",
  "id" : 578508839227650048,
  "in_reply_to_status_id" : 578508582997639169,
  "created_at" : "2015-03-19 10:50:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578508230705487872",
  "geo" : { },
  "id_str" : "578508347445501953",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko data driven prototyping :p",
  "id" : 578508347445501953,
  "in_reply_to_status_id" : 578508230705487872,
  "created_at" : "2015-03-19 10:48:32 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 107, 116 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/578508085192486913\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/EApcUAjzF8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAdGCX1WcAA66qP.png",
      "id_str" : "578508083711864832",
      "id" : 578508083711864832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAdGCX1WcAA66qP.png",
      "sizes" : [ {
        "h" : 706,
        "resize" : "fit",
        "w" : 1348
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1348
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/EApcUAjzF8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578508085192486913",
  "text" : "My step count histogram is funny. The red lines are the increments you get achievements at. Seems to work. @eramirez http:\/\/t.co\/EApcUAjzF8",
  "id" : 578508085192486913,
  "created_at" : "2015-03-19 10:47:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578467810294267904",
  "text" : "\u00ABYour submission ID number is 1.\u00BB That\u2019s a first!",
  "id" : 578467810294267904,
  "created_at" : "2015-03-19 08:07:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578351377061052416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.19387829913607, 6.787858978034676 ]
  },
  "id_str" : "578445223749136384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer it\u2019s okay. But if you haven\u2019t read it so far I would start with \u2018The Emperor of all Maladies\u2019.",
  "id" : 578445223749136384,
  "in_reply_to_status_id" : 578351377061052416,
  "created_at" : "2015-03-19 06:37:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578314134162399232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.19364017664989, 6.78797811446147 ]
  },
  "id_str" : "578314485527678976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks for the recommendation. Will read this after finishing p53. Good thing I have 15h flights coming up. ;)",
  "id" : 578314485527678976,
  "in_reply_to_status_id" : 578314134162399232,
  "created_at" : "2015-03-18 21:58:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "578297389020262400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.19402826794661, 6.787848734832731 ]
  },
  "id_str" : "578304890482606080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, I hadn\u2019t seen it! For wool alone it would be worth it, if you haven\u2019t read it so far.",
  "id" : 578304890482606080,
  "in_reply_to_status_id" : 578297389020262400,
  "created_at" : "2015-03-18 21:20:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/TcfC59orRG",
      "expanded_url" : "https:\/\/instagram.com\/p\/0YXiFSBwoF\/",
      "display_url" : "instagram.com\/p\/0YXiFSBwoF\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.963125, 7.610613 ]
  },
  "id_str" : "578276415839297536",
  "text" : "Aloe arborescens @ Botanischer Garten der Westf\u00E4lischen Wilhelms-Universit\u00E4t https:\/\/t.co\/TcfC59orRG",
  "id" : 578276415839297536,
  "created_at" : "2015-03-18 19:26:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/15MBcn_int\/status\/578253362975666177\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/xABKDbEpr2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZeVorUgAIR8zB.jpg",
      "id_str" : "578253327953068034",
      "id" : 578253327953068034,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZeVorUgAIR8zB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com\/xABKDbEpr2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.19374465351726, 6.787768529028416 ]
  },
  "id_str" : "578273107724648448",
  "text" : "Oh, this is why I couldn\u2019t make it home today! http:\/\/t.co\/xABKDbEpr2",
  "id" : 578273107724648448,
  "created_at" : "2015-03-18 19:13:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/9MsvRSieC1",
      "expanded_url" : "http:\/\/www.acgt.me\/blog\/2015\/3\/17\/more-madness-with-mapq-scores-aka-why-bioinformaticians-hate-poor-and-incomplete-software-documentation?utm_content=buffera6d5c&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "acgt.me\/blog\/2015\/3\/17\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578125298157256704",
  "text" : "why bioinformaticians hate poor and incomplete software documentation http:\/\/t.co\/9MsvRSieC1",
  "id" : 578125298157256704,
  "created_at" : "2015-03-18 09:26:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/USeOu5WZ4R",
      "expanded_url" : "http:\/\/nextgenseek.com\/2015\/03\/hisat-a-fast-and-memory-lean-rna-seq-aligner\/",
      "display_url" : "nextgenseek.com\/2015\/03\/hisat-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577871417972170752",
  "text" : "HISAT: A Fast and Memory Lean RNA-seq aligner http:\/\/t.co\/USeOu5WZ4R",
  "id" : 577871417972170752,
  "created_at" : "2015-03-17 16:37:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Whitehead",
      "screen_name" : "Mikey_Whitehead",
      "indices" : [ 0, 16 ],
      "id_str" : "25774136",
      "id" : 25774136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577797446543245313",
  "geo" : { },
  "id_str" : "577800980366016512",
  "in_reply_to_user_id" : 25774136,
  "text" : "@Mikey_Whitehead yes, drop me a mail to bgreshake@gmail.com if you want, then we can discuss it. :)",
  "id" : 577800980366016512,
  "in_reply_to_status_id" : 577797446543245313,
  "created_at" : "2015-03-17 11:57:43 +0000",
  "in_reply_to_screen_name" : "Mikey_Whitehead",
  "in_reply_to_user_id_str" : "25774136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Whitehead",
      "screen_name" : "Mikey_Whitehead",
      "indices" : [ 0, 16 ],
      "id_str" : "25774136",
      "id" : 25774136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577792886261096451",
  "geo" : { },
  "id_str" : "577795895384768512",
  "in_reply_to_user_id" : 25774136,
  "text" : "@Mikey_Whitehead would love to see that. Maybe we can do some advertising for that one. :-)",
  "id" : 577795895384768512,
  "in_reply_to_status_id" : 577792886261096451,
  "created_at" : "2015-03-17 11:37:31 +0000",
  "in_reply_to_screen_name" : "Mikey_Whitehead",
  "in_reply_to_user_id_str" : "25774136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Whitehead",
      "screen_name" : "Mikey_Whitehead",
      "indices" : [ 0, 16 ],
      "id_str" : "25774136",
      "id" : 25774136
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thedress",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577791849030627328",
  "geo" : { },
  "id_str" : "577792259564834816",
  "in_reply_to_user_id" : 25774136,
  "text" : "@Mikey_Whitehead thanks for creating the phenotype! I took the liberty to add #thedress picture inline.",
  "id" : 577792259564834816,
  "in_reply_to_status_id" : 577791849030627328,
  "created_at" : "2015-03-17 11:23:04 +0000",
  "in_reply_to_screen_name" : "Mikey_Whitehead",
  "in_reply_to_user_id_str" : "25774136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 39, 52 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/ZmewLdLSO3",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/philosophy\/natures-library-of-platonic-forms\/",
      "display_url" : "aeon.co\/magazine\/philo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577756031721349120",
  "text" : "Nature\u2019s Library of Platonic Forms \/cc @PhilippBayer http:\/\/t.co\/ZmewLdLSO3",
  "id" : 577756031721349120,
  "created_at" : "2015-03-17 08:59:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/mrs7bUSqiJ",
      "expanded_url" : "http:\/\/loonylabs.org\/2015\/03\/16\/pornography-psychology-erectile-dysfunction-sexual-dysfunction\/",
      "display_url" : "loonylabs.org\/2015\/03\/16\/por\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577754471465410560",
  "text" : "Viewing Sexual Stimuli Associated with Greater Sexual Responsiveness, Not Erectile Dysfunction http:\/\/t.co\/mrs7bUSqiJ",
  "id" : 577754471465410560,
  "created_at" : "2015-03-17 08:52:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/r243I11XpX",
      "expanded_url" : "http:\/\/journals.plos.org\/plosgenetics\/article?id=10.1371\/journal.pgen.1005067",
      "display_url" : "journals.plos.org\/plosgenetics\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577751991406964736",
  "text" : "Hyperdiverse Gene Cluster in Snail Host Conveys Resistance to Human Schistosome Parasites http:\/\/t.co\/r243I11XpX",
  "id" : 577751991406964736,
  "created_at" : "2015-03-17 08:43:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "577741764230045696",
  "geo" : { },
  "id_str" : "577742062285688832",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule ah, that I missed. Guess I was too busy with conference preparations. But it\u2019s nice that it\u2019s now an open project as well. :)",
  "id" : 577742062285688832,
  "in_reply_to_status_id" : 577741764230045696,
  "created_at" : "2015-03-17 08:03:36 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 3, 17 ],
      "id_str" : "48966898",
      "id" : 48966898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577741668486623232",
  "text" : "RT @lexnederbragt: 2 PhD positions: come work with us on graph-based representations of genomes! 1\/2 (bio)informatics http:\/\/t.co\/mCi0HiQly\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/mCi0HiQlyS",
        "expanded_url" : "http:\/\/uio.easycruit.com\/vacancy\/1352825\/64290?iso=no",
        "display_url" : "uio.easycruit.com\/vacancy\/135282\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "577731061465112576",
    "text" : "2 PhD positions: come work with us on graph-based representations of genomes! 1\/2 (bio)informatics http:\/\/t.co\/mCi0HiQlyS Please RT",
    "id" : 577731061465112576,
    "created_at" : "2015-03-17 07:19:53 +0000",
    "user" : {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "protected" : false,
      "id_str" : "48966898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099225219\/DSC01628a_normal.jpg",
      "id" : 48966898,
      "verified" : false
    }
  },
  "id" : 577741668486623232,
  "created_at" : "2015-03-17 08:02:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thedress",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ycZx4zEynN",
      "expanded_url" : "https:\/\/opensnp.org\/phenotypes\/338",
      "display_url" : "opensnp.org\/phenotypes\/338"
    } ]
  },
  "geo" : { },
  "id_str" : "577740579469156352",
  "text" : "Cool, apparently people want to use openSNP to investigate #thedress! https:\/\/t.co\/ycZx4zEynN",
  "id" : 577740579469156352,
  "created_at" : "2015-03-17 07:57:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/09qUROMuyH",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/72",
      "display_url" : "existentialcomics.com\/comic\/72"
    } ]
  },
  "geo" : { },
  "id_str" : "577730395208224768",
  "text" : "going overboard with radical freedom http:\/\/t.co\/09qUROMuyH",
  "id" : 577730395208224768,
  "created_at" : "2015-03-17 07:17:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/cdWlGBcMxN",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/03\/16\/can-games-help-prevent-teen-da.html",
      "display_url" : "boingboing.net\/2015\/03\/16\/can\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577729003743789056",
  "text" : "Can games help prevent teen dating\u00A0violence? http:\/\/t.co\/cdWlGBcMxN",
  "id" : 577729003743789056,
  "created_at" : "2015-03-17 07:11:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577380366765408256",
  "text" : "It\u2019s 2015 and I just had to create a sourceforge account. m)",
  "id" : 577380366765408256,
  "created_at" : "2015-03-16 08:06:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576779008689487872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.96421536529079, 7.627848528734642 ]
  },
  "id_str" : "576779256149180416",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ah, okay. Ich warte noch das meine Farbe endlich wie seine wird. ;)",
  "id" : 576779256149180416,
  "in_reply_to_status_id" : 576779008689487872,
  "created_at" : "2015-03-14 16:17:45 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576778399638749184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.9642383619864, 7.627827043310504 ]
  },
  "id_str" : "576778752253956096",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich moment, Miraculix hat lila-ausgewaschenes Haar? :D",
  "id" : 576778752253956096,
  "in_reply_to_status_id" : 576778399638749184,
  "created_at" : "2015-03-14 16:15:45 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/E9hW2dUypb",
      "expanded_url" : "https:\/\/instagram.com\/p\/0NuIQHBwmv\/",
      "display_url" : "instagram.com\/p\/0NuIQHBwmv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "576777995865604096",
  "text" : "Parasitic https:\/\/t.co\/E9hW2dUypb",
  "id" : 576777995865604096,
  "created_at" : "2015-03-14 16:12:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/ZRRCG9Y5Jq",
      "expanded_url" : "https:\/\/instagram.com\/p\/0M1JbdBwsR\/",
      "display_url" : "instagram.com\/p\/0M1JbdBwsR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "576652688659742721",
  "text" : "Hamamelis mollis https:\/\/t.co\/ZRRCG9Y5Jq",
  "id" : 576652688659742721,
  "created_at" : "2015-03-14 07:54:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 8, 14 ],
      "id_str" : "30868098",
      "id" : 30868098
    }, {
      "name" : "\u03BB",
      "screen_name" : "Lambda_",
      "indices" : [ 15, 23 ],
      "id_str" : "21659638",
      "id" : 21659638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "576362273243078656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.19359720314746, 6.787525304344629 ]
  },
  "id_str" : "576362403585265664",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @dvzrv @Lambda_ Joah, ich hatte jetzt als erstes an dich gedacht weil du am n\u00E4chsten an der Uni bist :D",
  "id" : 576362403585265664,
  "in_reply_to_status_id" : 576362273243078656,
  "created_at" : "2015-03-13 12:41:19 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 72, 78 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576353159767003136",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj hast du zuf\u00E4llig um den 9. bis 12.04. einen Schlafplatz f\u00FCr den @dvzrv \u00FCbrig? Der ist da zur Linux Audio Conference in Mainz. :D",
  "id" : 576353159767003136,
  "created_at" : "2015-03-13 12:04:36 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "indices" : [ 3, 16 ],
      "id_str" : "1891806212",
      "id" : 1891806212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576348125155176448",
  "text" : "RT @AcademicsSay: Two academics walk into a bar. They bring their own drinks, pay $5000, and leave feeling both proud and ashamed. It's a p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "576343972483842048",
    "text" : "Two academics walk into a bar. They bring their own drinks, pay $5000, and leave feeling both proud and ashamed. It's a publishing metaphor.",
    "id" : 576343972483842048,
    "created_at" : "2015-03-13 11:28:05 +0000",
    "user" : {
      "name" : "Shit Academics Say",
      "screen_name" : "AcademicsSay",
      "protected" : false,
      "id_str" : "1891806212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748151916836716546\/Ldn_dhiC_normal.jpg",
      "id" : 1891806212,
      "verified" : false
    }
  },
  "id" : 576348125155176448,
  "created_at" : "2015-03-13 11:44:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/CEhy79rgpR",
      "expanded_url" : "http:\/\/eatreadscience.com\/2015\/03\/12\/wounded-by-love-snails-struck-by-love-darts-have-lower-survival-and-reproductive-rates\/",
      "display_url" : "eatreadscience.com\/2015\/03\/12\/wou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "576339395126681600",
  "text" : "Wounded by love: snails struck by love darts have lower survival and reproductive\u00A0rates http:\/\/t.co\/CEhy79rgpR",
  "id" : 576339395126681600,
  "created_at" : "2015-03-13 11:09:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 83, 96 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/JFsYpFPcxy",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/9nb5qQID4HA\/info%3Adoi%2F10.1371%2Fjournal.pone.0114302",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575753195093389313",
  "text" : "The Evolution of Your Success Lies at the Centre of Your Co-Authorship Network \/cc @PhilippBayer  http:\/\/t.co\/JFsYpFPcxy",
  "id" : 575753195093389313,
  "created_at" : "2015-03-11 20:20:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/98i8ciUSTQ",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0118903",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575751712335597569",
  "text" : "A Wider Pelvis Does Not Increase Locomotor Cost in Humans, with Implications for the Evolution of Childbirth http:\/\/t.co\/98i8ciUSTQ",
  "id" : 575751712335597569,
  "created_at" : "2015-03-11 20:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 39, 48 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/opM8xJT49L",
      "expanded_url" : "https:\/\/medium.com\/@eramirez\/you-should-buy-a-van-7fec0db9b37",
      "display_url" : "medium.com\/@eramirez\/you-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575560123629838336",
  "text" : "\u00ABYou should buy a van.\u00BB Lovely, thanks @eramirez https:\/\/t.co\/opM8xJT49L",
  "id" : 575560123629838336,
  "created_at" : "2015-03-11 07:33:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 3, 12 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/GeyGCa12TN",
      "expanded_url" : "http:\/\/buff.ly\/1Gy3osT",
      "display_url" : "buff.ly\/1Gy3osT"
    } ]
  },
  "geo" : { },
  "id_str" : "574956790984482816",
  "text" : "RT @kbradnam: The Molluskan Zodiac: Molluskan horoscopes for week beginning 9th March 2015 http:\/\/t.co\/GeyGCa12TN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/GeyGCa12TN",
        "expanded_url" : "http:\/\/buff.ly\/1Gy3osT",
        "display_url" : "buff.ly\/1Gy3osT"
      } ]
    },
    "geo" : { },
    "id_str" : "574956598986153984",
    "text" : "The Molluskan Zodiac: Molluskan horoscopes for week beginning 9th March 2015 http:\/\/t.co\/GeyGCa12TN",
    "id" : 574956598986153984,
    "created_at" : "2015-03-09 15:35:10 +0000",
    "user" : {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "protected" : false,
      "id_str" : "17061155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583756306919489538\/D2fFCYq4_normal.jpg",
      "id" : 17061155,
      "verified" : false
    }
  },
  "id" : 574956790984482816,
  "created_at" : "2015-03-09 15:35:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "indices" : [ 3, 18 ],
      "id_str" : "1241258612",
      "id" : 1241258612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IWD2015",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/wCTQXjNR5d",
      "expanded_url" : "http:\/\/bit.ly\/18nuWC6",
      "display_url" : "bit.ly\/18nuWC6"
    } ]
  },
  "geo" : { },
  "id_str" : "574664885587566593",
  "text" : "RT @ConversationUK: You probably haven\u2019t heard of these amazing women scientists \u2013 so pay attention http:\/\/t.co\/wCTQXjNR5d #IWD2015 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ConversationUK\/status\/574658416532058114\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/XO2AAkMcqB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_b_zWrUIAAtAt4.png",
        "id_str" : "573927260261982208",
        "id" : 573927260261982208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_b_zWrUIAAtAt4.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/XO2AAkMcqB"
      } ],
      "hashtags" : [ {
        "text" : "IWD2015",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/wCTQXjNR5d",
        "expanded_url" : "http:\/\/bit.ly\/18nuWC6",
        "display_url" : "bit.ly\/18nuWC6"
      } ]
    },
    "geo" : { },
    "id_str" : "574658416532058114",
    "text" : "You probably haven\u2019t heard of these amazing women scientists \u2013 so pay attention http:\/\/t.co\/wCTQXjNR5d #IWD2015 http:\/\/t.co\/XO2AAkMcqB",
    "id" : 574658416532058114,
    "created_at" : "2015-03-08 19:50:17 +0000",
    "user" : {
      "name" : "The Conversation",
      "screen_name" : "ConversationUK",
      "protected" : false,
      "id_str" : "1241258612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875640793590976512\/IH4VD6Vm_normal.jpg",
      "id" : 1241258612,
      "verified" : true
    }
  },
  "id" : 574664885587566593,
  "created_at" : "2015-03-08 20:16:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 3, 8 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/uTO7DltHc2",
      "expanded_url" : "http:\/\/gu.com\/p\/46e23\/stw",
      "display_url" : "gu.com\/p\/46e23\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "574618159535235074",
  "text" : "RT @PLOS: On the importance of being negative http:\/\/t.co\/uTO7DltHc2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/uTO7DltHc2",
        "expanded_url" : "http:\/\/gu.com\/p\/46e23\/stw",
        "display_url" : "gu.com\/p\/46e23\/stw"
      } ]
    },
    "geo" : { },
    "id_str" : "574617614883778560",
    "text" : "On the importance of being negative http:\/\/t.co\/uTO7DltHc2",
    "id" : 574617614883778560,
    "created_at" : "2015-03-08 17:08:09 +0000",
    "user" : {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "protected" : false,
      "id_str" : "12819112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553318804122370048\/0HTyc2Ot_normal.jpeg",
      "id" : 12819112,
      "verified" : false
    }
  },
  "id" : 574618159535235074,
  "created_at" : "2015-03-08 17:10:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/YavSQ9hgCI",
      "expanded_url" : "https:\/\/instagram.com\/p\/z-VGkYBwuZ\/",
      "display_url" : "instagram.com\/p\/z-VGkYBwuZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "574611897544216576",
  "text" : "FM https:\/\/t.co\/YavSQ9hgCI",
  "id" : 574611897544216576,
  "created_at" : "2015-03-08 16:45:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/574605597125046273\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/y7ApE4n4GN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_lovvtWAAAszi-.jpg",
      "id_str" : "574605596936241152",
      "id" : 574605596936241152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_lovvtWAAAszi-.jpg",
      "sizes" : [ {
        "h" : 891,
        "resize" : "fit",
        "w" : 1188
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 891,
        "resize" : "fit",
        "w" : 1188
      }, {
        "h" : 891,
        "resize" : "fit",
        "w" : 1188
      } ],
      "display_url" : "pic.twitter.com\/y7ApE4n4GN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.19385, 6.788052 ]
  },
  "id_str" : "574605597125046273",
  "text" : "Und ich dachte ich k\u00F6nnte meinen Bart selber handlen\u2026 http:\/\/t.co\/y7ApE4n4GN",
  "id" : 574605597125046273,
  "created_at" : "2015-03-08 16:20:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/LYYx1KYNZC",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0118708",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "574322151089635328",
  "text" : "The Sound and the Fury\u2014Bees Hiss when Expecting Danger http:\/\/t.co\/LYYx1KYNZC",
  "id" : 574322151089635328,
  "created_at" : "2015-03-07 21:34:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sharon begley",
      "screen_name" : "sxbegle",
      "indices" : [ 0, 8 ],
      "id_str" : "346605991",
      "id" : 346605991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573869543866695680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.21806671382041, 6.774671981117478 ]
  },
  "id_str" : "573881156376092672",
  "in_reply_to_user_id" : 346605991,
  "text" : "@sxbegle yes, it\u2019s still going. :-)",
  "id" : 573881156376092672,
  "in_reply_to_status_id" : 573869543866695680,
  "created_at" : "2015-03-06 16:21:44 +0000",
  "in_reply_to_screen_name" : "sxbegle",
  "in_reply_to_user_id_str" : "346605991",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/jWz58coGVC",
      "expanded_url" : "http:\/\/www.talyarkoni.org\/blog\/2015\/03\/05\/now-i-am-become-doi-destroyer-of-gates\/",
      "display_url" : "talyarkoni.org\/blog\/2015\/03\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573764062745661440",
  "text" : "On citing: \u00ABNow I am Become DOI, Destroyer of Gatekeeping Worlds\u00BB http:\/\/t.co\/jWz58coGVC",
  "id" : 573764062745661440,
  "created_at" : "2015-03-06 08:36:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ZNEIybB7jk",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/03\/04\/hundreds-of-skeletons-found-un.html",
      "display_url" : "boingboing.net\/2015\/03\/04\/hun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573513257207619585",
  "text" : "I wonder which king they might end up finding here: Hundreds of skeletons found under\u00A0supermarket http:\/\/t.co\/ZNEIybB7jk",
  "id" : 573513257207619585,
  "created_at" : "2015-03-05 15:59:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Jones",
      "screen_name" : "RichardALJones",
      "indices" : [ 3, 18 ],
      "id_str" : "126294936",
      "id" : 126294936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573400133687218176",
  "text" : "RT @RichardALJones: In related news, planners of Crick Institute shocked to discover St Pancras site is affected by trains\nhttp:\/\/t.co\/sVyb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/sVyb6panDU",
        "expanded_url" : "http:\/\/www.nature.com\/news\/francis-crick-institute-raises-alarm-about-train-line-1.16978",
        "display_url" : "nature.com\/news\/francis-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "573397844842942464",
    "text" : "In related news, planners of Crick Institute shocked to discover St Pancras site is affected by trains\nhttp:\/\/t.co\/sVyb6panDU",
    "id" : 573397844842942464,
    "created_at" : "2015-03-05 08:21:14 +0000",
    "user" : {
      "name" : "Richard Jones",
      "screen_name" : "RichardALJones",
      "protected" : false,
      "id_str" : "126294936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774305617\/RALJones2_normal.jpg",
      "id" : 126294936,
      "verified" : false
    }
  },
  "id" : 573400133687218176,
  "created_at" : "2015-03-05 08:30:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/CUO86vp40x",
      "expanded_url" : "http:\/\/occamstypewriter.org\/boboh\/2015\/03\/03\/psychology-journal-bans-almost-all-of-statistics\/",
      "display_url" : "occamstypewriter.org\/boboh\/2015\/03\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573051664581718016",
  "text" : "\u00ABclaim you\u2019re using fiducial probability. The only person to understand this was R.A. Fisher, but that\u2019s OK.\u00BB http:\/\/t.co\/CUO86vp40x",
  "id" : 573051664581718016,
  "created_at" : "2015-03-04 09:25:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/HQUFycVHXR",
      "expanded_url" : "http:\/\/seqanswers.com\/wiki\/Software\/list",
      "display_url" : "seqanswers.com\/wiki\/Software\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573026348765188096",
  "text" : "Is there a more complete list that includes de-novo (meta)genome assemblers than this? http:\/\/t.co\/HQUFycVHXR",
  "id" : 573026348765188096,
  "created_at" : "2015-03-04 07:45:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Stringer",
      "screen_name" : "jenn_stringer",
      "indices" : [ 3, 17 ],
      "id_str" : "14387163",
      "id" : 14387163
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eli2015",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573016223711154178",
  "text" : "RT @jenn_stringer: I love this one.. \"lecture hasn't changed, sleeping, talking in class, checking FB, hitting on classmates.\" #eli2015 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jenn_stringer\/status\/564898043934552064\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/BQ4jJccLmI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9brutJCYAA0p9t.png",
        "id_str" : "564897990905585664",
        "id" : 564897990905585664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9brutJCYAA0p9t.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 609
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 609
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 609
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 609
        } ],
        "display_url" : "pic.twitter.com\/BQ4jJccLmI"
      } ],
      "hashtags" : [ {
        "text" : "eli2015",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564898043934552064",
    "text" : "I love this one.. \"lecture hasn't changed, sleeping, talking in class, checking FB, hitting on classmates.\" #eli2015 http:\/\/t.co\/BQ4jJccLmI",
    "id" : 564898043934552064,
    "created_at" : "2015-02-09 21:26:03 +0000",
    "user" : {
      "name" : "Jenn Stringer",
      "screen_name" : "jenn_stringer",
      "protected" : false,
      "id_str" : "14387163",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/910687011220025344\/g4W8iWvj_normal.jpg",
      "id" : 14387163,
      "verified" : false
    }
  },
  "id" : 573016223711154178,
  "created_at" : "2015-03-04 07:04:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 60, 68 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/2FtZFmI3r6",
      "expanded_url" : "https:\/\/answers.yahoo.com\/question\/index?qid=20090504023635AApkVCA",
      "display_url" : "answers.yahoo.com\/question\/index\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "573014875087212544",
  "text" : "You say lazy, I say resourceful https:\/\/t.co\/2FtZFmI3r6 \/cc @branleb",
  "id" : 573014875087212544,
  "created_at" : "2015-03-04 06:59:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/JYrj3w1avb",
      "expanded_url" : "http:\/\/forum.biohack.me\/discussion\/753\/why-are-transhumanists-such-dickss\/p1",
      "display_url" : "forum.biohack.me\/discussion\/753\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572766363535736833",
  "text" : "Why are transhumanists such dicks? http:\/\/t.co\/JYrj3w1avb",
  "id" : 572766363535736833,
  "created_at" : "2015-03-03 14:31:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aprica",
      "screen_name" : "aprica",
      "indices" : [ 3, 10 ],
      "id_str" : "13196692",
      "id" : 13196692
    }, {
      "name" : "Roxanne de Bastion",
      "screen_name" : "Roxannemusic",
      "indices" : [ 85, 98 ],
      "id_str" : "55248016",
      "id" : 55248016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/LrExhejsm4",
      "expanded_url" : "http:\/\/www.thegirlsare.com\/2015\/03\/02\/roxanne-de-bastion-female-is-not-a-genre\/",
      "display_url" : "thegirlsare.com\/2015\/03\/02\/rox\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572747293650239488",
  "text" : "RT @aprica: \u201CFemale is not a genre\u201D on sexism in the music industry. by the fabulous @Roxannemusic: http:\/\/t.co\/LrExhejsm4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roxanne de Bastion",
        "screen_name" : "Roxannemusic",
        "indices" : [ 73, 86 ],
        "id_str" : "55248016",
        "id" : 55248016
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/LrExhejsm4",
        "expanded_url" : "http:\/\/www.thegirlsare.com\/2015\/03\/02\/roxanne-de-bastion-female-is-not-a-genre\/",
        "display_url" : "thegirlsare.com\/2015\/03\/02\/rox\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "572733556616785920",
    "text" : "\u201CFemale is not a genre\u201D on sexism in the music industry. by the fabulous @Roxannemusic: http:\/\/t.co\/LrExhejsm4",
    "id" : 572733556616785920,
    "created_at" : "2015-03-03 12:21:35 +0000",
    "user" : {
      "name" : "aprica",
      "screen_name" : "aprica",
      "protected" : false,
      "id_str" : "13196692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2176100652\/IMG_0385-Bearbeitet3_rp122_normal.jpg",
      "id" : 13196692,
      "verified" : false
    }
  },
  "id" : 572747293650239488,
  "created_at" : "2015-03-03 13:16:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/w0U94E9Ys5",
      "expanded_url" : "https:\/\/egtheory.wordpress.com\/2015\/03\/02\/ipd\/",
      "display_url" : "egtheory.wordpress.com\/2015\/03\/02\/ipd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "572731388128071681",
  "text" : "Short history of iterated prisoner\u2019s dilemma\u00A0tournaments https:\/\/t.co\/w0U94E9Ys5",
  "id" : 572731388128071681,
  "created_at" : "2015-03-03 12:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 20, 27 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572693893285875712",
  "text" : "Wowowowow! My first @PacBio data \\o\/",
  "id" : 572693893285875712,
  "created_at" : "2015-03-03 09:43:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yolo",
      "indices" : [ 7, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/Tg2TkrTcCy",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/03\/02\/how-to-yolo-in-latin.html",
      "display_url" : "boingboing.net\/2015\/03\/02\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572688611646283776",
  "text" : "How to #yolo in\u00A0Latin http:\/\/t.co\/Tg2TkrTcCy",
  "id" : 572688611646283776,
  "created_at" : "2015-03-03 09:22:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Wilson",
      "screen_name" : "ecwilson",
      "indices" : [ 0, 9 ],
      "id_str" : "16751157",
      "id" : 16751157
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 10, 21 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572195392340807680",
  "geo" : { },
  "id_str" : "572327219839807488",
  "in_reply_to_user_id" : 16751157,
  "text" : "@ecwilson @opensnporg should work by now, true for you as well? :-)",
  "id" : 572327219839807488,
  "in_reply_to_status_id" : 572195392340807680,
  "created_at" : "2015-03-02 09:26:57 +0000",
  "in_reply_to_screen_name" : "ecwilson",
  "in_reply_to_user_id_str" : "16751157",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/ak9E204PB6",
      "expanded_url" : "http:\/\/www.rogerebert.com\/mzs\/watching-aliens-for-the-first-time-again-with-a-bunch-of-kids",
      "display_url" : "rogerebert.com\/mzs\/watching-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572320793243328512",
  "text" : "On watching \u2018Aliens\u2019 with a bunch of kids http:\/\/t.co\/ak9E204PB6",
  "id" : 572320793243328512,
  "created_at" : "2015-03-02 09:01:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/8TtjVqn3xu",
      "expanded_url" : "https:\/\/lymanmuseum.wordpress.com\/2015\/03\/01\/how-many-people-does-it-take-to-describe-a-new-species\/",
      "display_url" : "lymanmuseum.wordpress.com\/2015\/03\/01\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "572310549427593216",
  "text" : "\u00ABHow many people does it take to describe a new\u00A0species?\u00BB One who uses the sequencer and one who speaks Latin? https:\/\/t.co\/8TtjVqn3xu",
  "id" : 572310549427593216,
  "created_at" : "2015-03-02 08:20:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SBHE7KoAnQ",
      "expanded_url" : "http:\/\/jhhung.github.io\/PEAT\/",
      "display_url" : "jhhung.github.io\/PEAT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "572299965227253760",
  "text" : "Gave PEAT a quick test drive: adapter trimming w\/o the need to specify the adapter seqs a priori. Worked quite well. http:\/\/t.co\/SBHE7KoAnQ",
  "id" : 572299965227253760,
  "created_at" : "2015-03-02 07:38:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999998 ]
  },
  "id_str" : "572164833044504576",
  "text" : "\u00ABMy non-biological son is a carpenter. Make of that what you will.\u00BB",
  "id" : 572164833044504576,
  "created_at" : "2015-03-01 22:41:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572124660697059328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.94593325118786, 7.873965811383217 ]
  },
  "id_str" : "572131728611004419",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor gerne n\u00E4chstes Mal. Hoffentlich nicht wieder erst in ein paar Jahren. ;)",
  "id" : 572131728611004419,
  "in_reply_to_status_id" : 572124660697059328,
  "created_at" : "2015-03-01 20:30:08 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572117050967134208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.44158885141569, 7.451295946446371 ]
  },
  "id_str" : "572122626069565441",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor war, nur diesen Nachmittag.",
  "id" : 572122626069565441,
  "in_reply_to_status_id" : 572117050967134208,
  "created_at" : "2015-03-01 19:53:58 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62341420226621, 7.199758552738414 ]
  },
  "id_str" : "572105101596336129",
  "text" : "\u00ABWo ist unser Bruder?\u00BB \u2014 \u00ABFernsehen.\u00BB \u2014 \u00ABWir haben doch wieder Internet, wieso muss der fernsehen?!\u00BB",
  "id" : 572105101596336129,
  "created_at" : "2015-03-01 18:44:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adina Howe",
      "screen_name" : "teeniedeenie",
      "indices" : [ 3, 16 ],
      "id_str" : "169632361",
      "id" : 169632361
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 96, 108 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Qingpeng QP Zhang",
      "screen_name" : "qingpengzhang",
      "indices" : [ 109, 123 ],
      "id_str" : "1135766430",
      "id" : 1135766430
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 124, 134 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572101894430167041",
  "text" : "RT @teeniedeenie: What kind of questions do you ask when collab\/design an omic seq experiment?  @ctitusbrown @qingpengzhang @biocrusoe http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Titus Brown",
        "screen_name" : "ctitusbrown",
        "indices" : [ 78, 90 ],
        "id_str" : "26616462",
        "id" : 26616462
      }, {
        "name" : "Qingpeng QP Zhang",
        "screen_name" : "qingpengzhang",
        "indices" : [ 91, 105 ],
        "id_str" : "1135766430",
        "id" : 1135766430
      }, {
        "name" : "Michael R. Crusoe",
        "screen_name" : "biocrusoe",
        "indices" : [ 106, 116 ],
        "id_str" : "17645638",
        "id" : 17645638
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/EPKlX9dfcu",
        "expanded_url" : "http:\/\/adina.github.io\/2015\/02\/28\/sequencing-experimental-design\/",
        "display_url" : "adina.github.io\/2015\/02\/28\/seq\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "571762921618841600",
    "text" : "What kind of questions do you ask when collab\/design an omic seq experiment?  @ctitusbrown @qingpengzhang @biocrusoe http:\/\/t.co\/EPKlX9dfcu",
    "id" : 571762921618841600,
    "created_at" : "2015-02-28 20:04:38 +0000",
    "user" : {
      "name" : "Adina Howe",
      "screen_name" : "teeniedeenie",
      "protected" : false,
      "id_str" : "169632361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717451014576730114\/b165K4fR_normal.jpg",
      "id" : 169632361,
      "verified" : false
    }
  },
  "id" : 572101894430167041,
  "created_at" : "2015-03-01 18:31:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/hQmQU3i657",
      "expanded_url" : "https:\/\/instagram.com\/p\/zsdu7uBwo0\/",
      "display_url" : "instagram.com\/p\/zsdu7uBwo0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "572097601669083137",
  "text" : "Ballsy https:\/\/t.co\/hQmQU3i657",
  "id" : 572097601669083137,
  "created_at" : "2015-03-01 18:14:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sixtus \u99AC\u516D \uD83C\uDDEA\uD83C\uDDFA\uD83C\uDDED\uD83C\uDDF0",
      "screen_name" : "sixtus",
      "indices" : [ 0, 7 ],
      "id_str" : "9334352",
      "id" : 9334352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/572009609344499713\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/mJXvDcivny",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_AvtS0W4AENsms.jpg",
      "id_str" : "572009607868112897",
      "id" : 572009607868112897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_AvtS0W4AENsms.jpg",
      "sizes" : [ {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mJXvDcivny"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572003376109654016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62348039637075, 7.199428259475137 ]
  },
  "id_str" : "572009609344499713",
  "in_reply_to_user_id" : 9334352,
  "text" : "@sixtus passend dazu gestern gefunden: http:\/\/t.co\/mJXvDcivny",
  "id" : 572009609344499713,
  "in_reply_to_status_id" : 572003376109654016,
  "created_at" : "2015-03-01 12:24:52 +0000",
  "in_reply_to_screen_name" : "sixtus",
  "in_reply_to_user_id_str" : "9334352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 71, 84 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 85, 97 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 98, 107 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/YqzNkHhBdo",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1472-6947\/15\/12\/",
      "display_url" : "biomedcentral.com\/1472-6947\/15\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571986005424799745",
  "text" : "What openSNP is used for: Pharmacogenomic knowledge representation \/cc @PhilippBayer @helgerausch @senficon  http:\/\/t.co\/YqzNkHhBdo",
  "id" : 571986005424799745,
  "created_at" : "2015-03-01 10:51:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571976531364474880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49873352050779, 7.484687367787436 ]
  },
  "id_str" : "571979935931363328",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju omg, wenn es sich erstmal ausgeforscht hat bin ich arbeitslos!",
  "id" : 571979935931363328,
  "in_reply_to_status_id" : 571976531364474880,
  "created_at" : "2015-03-01 10:26:58 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]