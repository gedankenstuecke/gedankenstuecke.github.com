Grailbird.data.tweets_2017_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gil Wizen",
      "screen_name" : "wizentrop",
      "indices" : [ 3, 13 ],
      "id_str" : "4835399064",
      "id" : 4835399064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925460872708976640",
  "text" : "RT @wizentrop: It's that day of the year when I get to share a photo of my son. Happy Halloween! More about my beautiful bo(tfl)y: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wizentrop\/status\/925380732935172096\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/M6mMYGd1Ya",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNecs7qXkAcX7VV.jpg",
        "id_str" : "925380544191500295",
        "id" : 925380544191500295,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNecs7qXkAcX7VV.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/M6mMYGd1Ya"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/WUzNetZ16C",
        "expanded_url" : "http:\/\/gilwizen.com\/botfly\/",
        "display_url" : "gilwizen.com\/botfly\/"
      } ]
    },
    "geo" : { },
    "id_str" : "925380732935172096",
    "text" : "It's that day of the year when I get to share a photo of my son. Happy Halloween! More about my beautiful bo(tfl)y: https:\/\/t.co\/WUzNetZ16C https:\/\/t.co\/M6mMYGd1Ya",
    "id" : 925380732935172096,
    "created_at" : "2017-10-31 15:15:34 +0000",
    "user" : {
      "name" : "Gil Wizen",
      "screen_name" : "wizentrop",
      "protected" : false,
      "id_str" : "4835399064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816687562081374208\/tsUOfNuh_normal.jpg",
      "id" : 4835399064,
      "verified" : false
    }
  },
  "id" : 925460872708976640,
  "created_at" : "2017-10-31 20:34:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/oCiHGelxe9",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=J7uHye4hU1M",
      "display_url" : "m.youtube.com\/watch?v=J7uHye\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925368189546090496",
  "text" : "All set for a quiet reformation day. \uD83D\uDE09 https:\/\/t.co\/oCiHGelxe9",
  "id" : 925368189546090496,
  "created_at" : "2017-10-31 14:25:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/925336470667366401\/photo\/1",
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/6ZuBgmkc7V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNd0m9QX4AA2ejy.jpg",
      "id_str" : "925336461075013632",
      "id" : 925336461075013632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNd0m9QX4AA2ejy.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/6ZuBgmkc7V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925336470667366401",
  "text" : "Found while cleaning up. The Pirate Party Berlin was overly optimistic with their condom needs. Now they\u2019re over the best before date. \uD83D\uDE02 https:\/\/t.co\/6ZuBgmkc7V",
  "id" : 925336470667366401,
  "created_at" : "2017-10-31 12:19:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Language on the Move",
      "screen_name" : "Lg_on_the_Move",
      "indices" : [ 3, 18 ],
      "id_str" : "78578223",
      "id" : 78578223
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "multilingual",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925327445242404865",
  "text" : "RT @Lg_on_the_Move: New on Language on the Move: Banal cosmopolitanism - or the work that #multilingual \"Welcome\" signs do and don't do\nhtt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lg_on_the_Move\/status\/925308631469277184\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/OsUBxbIxL9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNdbQaKV4AANCvP.jpg",
        "id_str" : "925308585906659328",
        "id" : 925308585906659328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNdbQaKV4AANCvP.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 280
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 280
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 280
        } ],
        "display_url" : "pic.twitter.com\/OsUBxbIxL9"
      } ],
      "hashtags" : [ {
        "text" : "multilingual",
        "indices" : [ 70, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/3YEdjbVqBj",
        "expanded_url" : "http:\/\/www.languageonthemove.com\/banal-cosmopolitanism\/",
        "display_url" : "languageonthemove.com\/banal-cosmopol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925308631469277184",
    "text" : "New on Language on the Move: Banal cosmopolitanism - or the work that #multilingual \"Welcome\" signs do and don't do\nhttps:\/\/t.co\/3YEdjbVqBj https:\/\/t.co\/OsUBxbIxL9",
    "id" : 925308631469277184,
    "created_at" : "2017-10-31 10:29:03 +0000",
    "user" : {
      "name" : "Language on the Move",
      "screen_name" : "Lg_on_the_Move",
      "protected" : false,
      "id_str" : "78578223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673175205\/LotmLogoForEmily_normal.jpg",
      "id" : 78578223,
      "verified" : false
    }
  },
  "id" : 925327445242404865,
  "created_at" : "2017-10-31 11:43:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/925326540963016705\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/080HoFk3MA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNdrlKOXcAAqHXp.jpg",
      "id_str" : "925326534591868928",
      "id" : 925326534591868928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNdrlKOXcAAqHXp.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/080HoFk3MA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11376680318689, 8.753210001053482 ]
  },
  "id_str" : "925326540963016705",
  "text" : "First full month since submitting my thesis: hit my activity goal every single day. \uD83C\uDF89 https:\/\/t.co\/080HoFk3MA",
  "id" : 925326540963016705,
  "created_at" : "2017-10-31 11:40:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/925289437931753472\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/umXxINvCfF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNdJ1ZiW0AAQWot.jpg",
      "id_str" : "925289430184808448",
      "id" : 925289430184808448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNdJ1ZiW0AAQWot.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/umXxINvCfF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925289437931753472",
  "text" : "Back \u2018home\u2019 for a last day! \uD83D\uDD27\uD83D\uDD28 October was a bit busier than it should have been. \uD83D\uDE34 https:\/\/t.co\/umXxINvCfF",
  "id" : 925289437931753472,
  "created_at" : "2017-10-31 09:12:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925074168714027009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394094680446, 8.753024758779214 ]
  },
  "id_str" : "925082739212193793",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim No 13 either. :)",
  "id" : 925082739212193793,
  "in_reply_to_status_id" : 925074168714027009,
  "created_at" : "2017-10-30 19:31:26 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/925038695601917953\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/jtXe4uvEaM",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DNZlyHyXUAAmSpR.jpg",
      "id_str" : "925038685229371392",
      "id" : 925038685229371392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DNZlyHyXUAAmSpR.jpg",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/jtXe4uvEaM"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 8, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925038695601917953",
  "text" : "Leaving #mozfest and London like\u2026 https:\/\/t.co\/jtXe4uvEaM",
  "id" : 925038695601917953,
  "created_at" : "2017-10-30 16:36:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46943919365431, -0.4459614213560205 ]
  },
  "id_str" : "925037607620399104",
  "text" : "TIL: Lufthansa \u2708\uFE0Fs don\u2019t have row 17 because it\u2019s an unlucky number in Brazil and Italy.",
  "id" : 925037607620399104,
  "created_at" : "2017-10-30 16:32:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "F1000Research",
      "screen_name" : "F1000Research",
      "indices" : [ 61, 75 ],
      "id_str" : "59126394",
      "id" : 59126394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/zAoMHxXiXh",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/6-1858\/v1",
      "display_url" : "f1000research.com\/articles\/6-185\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "925034097952649217",
  "text" : "RT @OBF_BOSC: Our report about #BOSC2017 is now available on @F1000Research https:\/\/t.co\/zAoMHxXiXh \uD83C\uDF50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "F1000Research",
        "screen_name" : "F1000Research",
        "indices" : [ 47, 61 ],
        "id_str" : "59126394",
        "id" : 59126394
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 17, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/zAoMHxXiXh",
        "expanded_url" : "https:\/\/f1000research.com\/articles\/6-1858\/v1",
        "display_url" : "f1000research.com\/articles\/6-185\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "925032920720355328",
    "text" : "Our report about #BOSC2017 is now available on @F1000Research https:\/\/t.co\/zAoMHxXiXh \uD83C\uDF50",
    "id" : 925032920720355328,
    "created_at" : "2017-10-30 16:13:29 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 925034097952649217,
  "created_at" : "2017-10-30 16:18:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924941436411408384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50495225151906, -0.08203517388811025 ]
  },
  "id_str" : "924943686840082432",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb I go every time I\u2019m in London \uD83D\uDE0D (including this time, if only to buy some post cards ;))",
  "id" : 924943686840082432,
  "in_reply_to_status_id" : 924941436411408384,
  "created_at" : "2017-10-30 10:18:54 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50491174080337, -0.08205658547873958 ]
  },
  "id_str" : "924920084166008832",
  "text" : "Conflicted: I really, really want to go to Gay\u2019s the Word today. But at the same time I know that the move prohibits buying a single book.",
  "id" : 924920084166008832,
  "created_at" : "2017-10-30 08:45:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924589260174479361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.504902584646, -0.08203869627670722 ]
  },
  "id_str" : "924800928686931968",
  "in_reply_to_user_id" : 14286491,
  "text" : "Day 2 of #MozFest concludes with drinks with friends after co-facilitating three wonderful sessions! \uD83C\uDF89\uD83D\uDE34",
  "id" : 924800928686931968,
  "in_reply_to_status_id" : 924589260174479361,
  "created_at" : "2017-10-30 00:51:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 3, 11 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 21, 37 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFezt",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "924669392121663489",
  "text" : "RT @Seplute: Credit: @gedankenstuecke \uD83D\uDE0E thanks to everyone else who came to our #MozFezt session &amp; contributed so many great ideas !!!! \uD83D\uDC9C #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 8, 24 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MozFezt",
        "indices" : [ 67, 75 ]
      }, {
        "text" : "OpenData",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 144, 167 ],
        "url" : "https:\/\/t.co\/2tTRp7PmtY",
        "expanded_url" : "https:\/\/twitter.com\/pmichelu\/status\/924664326086103041",
        "display_url" : "twitter.com\/pmichelu\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "924667885431160832",
    "text" : "Credit: @gedankenstuecke \uD83D\uDE0E thanks to everyone else who came to our #MozFezt session &amp; contributed so many great ideas !!!! \uD83D\uDC9C #OpenData FTW! https:\/\/t.co\/2tTRp7PmtY",
    "id" : 924667885431160832,
    "created_at" : "2017-10-29 16:02:58 +0000",
    "user" : {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "protected" : false,
      "id_str" : "188833865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733429172165574656\/JFlTQmja_normal.jpg",
      "id" : 188833865,
      "verified" : false
    }
  },
  "id" : 924669392121663489,
  "created_at" : "2017-10-29 16:08:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 56, 72 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/924606094802112513\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ZuGH5YTFBF",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DNTcU4UWAAAzlfC.jpg",
      "id_str" : "924606074791002112",
      "id" : 924606074791002112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DNTcU4UWAAAzlfC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/ZuGH5YTFBF"
    } ],
    "hashtags" : [ {
      "text" : "9thFloor",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "MozFest",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "924616354338082816",
  "text" : "RT @auremoser: Join \"NewNerdcator\" #9thFloor #MozFest w\/@gedankenstuecke S3-907 @ 16:30! https:\/\/t.co\/ZuGH5YTFBF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 41, 57 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/924606094802112513\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/ZuGH5YTFBF",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DNTcU4UWAAAzlfC.jpg",
        "id_str" : "924606074791002112",
        "id" : 924606074791002112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DNTcU4UWAAAzlfC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 270,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/ZuGH5YTFBF"
      } ],
      "hashtags" : [ {
        "text" : "9thFloor",
        "indices" : [ 20, 29 ]
      }, {
        "text" : "MozFest",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "924606094802112513",
    "text" : "Join \"NewNerdcator\" #9thFloor #MozFest w\/@gedankenstuecke S3-907 @ 16:30! https:\/\/t.co\/ZuGH5YTFBF",
    "id" : 924606094802112513,
    "created_at" : "2017-10-29 11:57:26 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 924616354338082816,
  "created_at" : "2017-10-29 12:38:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Emmanuel Roux",
      "screen_name" : "sroux",
      "indices" : [ 0, 6 ],
      "id_str" : "15337959",
      "id" : 15337959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/fOfJ7cJMTz",
      "expanded_url" : "https:\/\/mozilla.github.io\/leadership-training\/",
      "display_url" : "mozilla.github.io\/leadership-tra\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183999443503, 0.00520102484806831 ]
  },
  "id_str" : "924616237237317633",
  "in_reply_to_user_id" : 15337959,
  "text" : "@sroux here\u2019s some information on the open leadership project! https:\/\/t.co\/fOfJ7cJMTz :)",
  "id" : 924616237237317633,
  "created_at" : "2017-10-29 12:37:44 +0000",
  "in_reply_to_screen_name" : "sroux",
  "in_reply_to_user_id_str" : "15337959",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 3, 11 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Seplute\/status\/924314067883479040\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ddCCvGXsl7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNPStpjWsAAY9Mp.jpg",
      "id_str" : "924314030231171072",
      "id" : 924314030231171072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNPStpjWsAAY9Mp.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 2080,
        "resize" : "fit",
        "w" : 1560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/ddCCvGXsl7"
    } ],
    "hashtags" : [ {
      "text" : "Nerdcator",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "MozFest",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "OpenInnovation",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "924589726232915968",
  "text" : "RT @Seplute: It's *important* that you come to our #Nerdcator #MozFest session tomorrow @ #OpenInnovation 4.30 ... \uD83D\uDE0E https:\/\/t.co\/ddCCvGXsl7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Seplute\/status\/924314067883479040\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/ddCCvGXsl7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNPStpjWsAAY9Mp.jpg",
        "id_str" : "924314030231171072",
        "id" : 924314030231171072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNPStpjWsAAY9Mp.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2080,
          "resize" : "fit",
          "w" : 1560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/ddCCvGXsl7"
      } ],
      "hashtags" : [ {
        "text" : "Nerdcator",
        "indices" : [ 38, 48 ]
      }, {
        "text" : "MozFest",
        "indices" : [ 49, 57 ]
      }, {
        "text" : "OpenInnovation",
        "indices" : [ 77, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "924314067883479040",
    "text" : "It's *important* that you come to our #Nerdcator #MozFest session tomorrow @ #OpenInnovation 4.30 ... \uD83D\uDE0E https:\/\/t.co\/ddCCvGXsl7",
    "id" : 924314067883479040,
    "created_at" : "2017-10-28 16:37:01 +0000",
    "user" : {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "protected" : false,
      "id_str" : "188833865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733429172165574656\/JFlTQmja_normal.jpg",
      "id" : 188833865,
      "verified" : false
    }
  },
  "id" : 924589726232915968,
  "created_at" : "2017-10-29 10:52:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 5, 11 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/dwX7S6hVwo",
      "expanded_url" : "https:\/\/guidebook.com\/guide\/114124\/event\/16741411\/",
      "display_url" : "guidebook.com\/guide\/114124\/e\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "924572266708553728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183779332793, 0.005213348170192543 ]
  },
  "id_str" : "924589260174479361",
  "in_reply_to_user_id" : 14286491,
  "text" : "Join @aath0 &amp; me in discussing how research treats minorities. 11am at Sched 1, Floor 9. #MozFest https:\/\/t.co\/dwX7S6hVwo",
  "id" : 924589260174479361,
  "in_reply_to_status_id" : 924572266708553728,
  "created_at" : "2017-10-29 10:50:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Luisa Calvo",
      "screen_name" : "CalvoLuisa",
      "indices" : [ 39, 50 ],
      "id_str" : "499151464",
      "id" : 499151464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924572865818587136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50489561820189, -0.08211639530122505 ]
  },
  "id_str" : "924573510848122881",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann The amazingly talented @CalvoLuisa, who went above and beyond yesterday! \uD83D\uDC4D\uD83D\uDE0D",
  "id" : 924573510848122881,
  "in_reply_to_status_id" : 924572865818587136,
  "created_at" : "2017-10-29 09:47:57 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/924572266708553728\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/xZKS2cBoge",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNS9jCrWAAAMXKS.jpg",
      "id_str" : "924572233229533184",
      "id" : 924572233229533184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNS9jCrWAAAMXKS.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/xZKS2cBoge"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924427683991343104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50492946236248, -0.08204233969245378 ]
  },
  "id_str" : "924572266708553728",
  "in_reply_to_user_id" : 14286491,
  "text" : "The #MozFest parties are always something special. Bringing home an awesome caricature is a first for me. \uD83D\uDE02 https:\/\/t.co\/xZKS2cBoge",
  "id" : 924572266708553728,
  "in_reply_to_status_id" : 924427683991343104,
  "created_at" : "2017-10-29 09:43:00 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sareh",
      "screen_name" : "Sareh88",
      "indices" : [ 0, 8 ],
      "id_str" : "21869925",
      "id" : 21869925
    }, {
      "name" : "Mozilla Festival",
      "screen_name" : "mozillafestival",
      "indices" : [ 9, 25 ],
      "id_str" : "348416778",
      "id" : 348416778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924553437542481920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50494275729579, -0.08203643632920929 ]
  },
  "id_str" : "924566196590014464",
  "in_reply_to_user_id" : 21869925,
  "text" : "@Sareh88 @mozillafestival My biased opinion says \u201Cjoin us for how research treats URM\u201D ;)",
  "id" : 924566196590014464,
  "in_reply_to_status_id" : 924553437542481920,
  "created_at" : "2017-10-29 09:18:53 +0000",
  "in_reply_to_screen_name" : "Sareh88",
  "in_reply_to_user_id_str" : "21869925",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/e1M8vuRyIk",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Ba05V9GFaLD\/",
      "display_url" : "instagram.com\/p\/Ba05V9GFaLD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "924565007668600832",
  "text" : "Skyward https:\/\/t.co\/e1M8vuRyIk",
  "id" : 924565007668600832,
  "created_at" : "2017-10-29 09:14:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924312915318116353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50494310236525, -0.08203661274387003 ]
  },
  "id_str" : "924427683991343104",
  "in_reply_to_user_id" : 14286491,
  "text" : "Day 1 of #MozFest: going home early &amp; celebrating upcoming 8 hours of sleep with other attendees via direct messages. \uD83D\uDE02",
  "id" : 924427683991343104,
  "in_reply_to_status_id" : 924312915318116353,
  "created_at" : "2017-10-29 00:08:29 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 27, 40 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/924312915318116353\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/8c0i3RdmuF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNPRqpUX0AAg7nL.jpg",
      "id_str" : "924312879117094912",
      "id" : 924312879117094912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNPRqpUX0AAg7nL.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/8c0i3RdmuF"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924306440327712769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180910797922, 0.005246243687913391 ]
  },
  "id_str" : "924312915318116353",
  "in_reply_to_user_id" : 14286491,
  "text" : "The upside of down. Model: @RaoOfPhysics  #MozFest https:\/\/t.co\/8c0i3RdmuF",
  "id" : 924312915318116353,
  "in_reply_to_status_id" : 924306440327712769,
  "created_at" : "2017-10-28 16:32:26 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/924306440327712769\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/bM0DDUSSSj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNPLxxtX0AAGSAJ.jpg",
      "id_str" : "924306404558753792",
      "id" : 924306404558753792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNPLxxtX0AAGSAJ.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/bM0DDUSSSj"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924282675640365056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180945587999, 0.005254913148660923 ]
  },
  "id_str" : "924306440327712769",
  "in_reply_to_user_id" : 14286491,
  "text" : "Help me, OAuth-iwan, you are our only hope! #MozFest https:\/\/t.co\/bM0DDUSSSj",
  "id" : 924306440327712769,
  "in_reply_to_status_id" : 924282675640365056,
  "created_at" : "2017-10-28 16:06:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Ainsworth \uD83D\uDD2D",
      "screen_name" : "rachaelevelyn",
      "indices" : [ 46, 60 ],
      "id_str" : "130490305",
      "id" : 130490305
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/924282675640365056\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/WTIjP36pVC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNO2KiCXcAAKu99.jpg",
      "id_str" : "924282640592760832",
      "id" : 924282640592760832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNO2KiCXcAAKu99.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      } ],
      "display_url" : "pic.twitter.com\/WTIjP36pVC"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924263201969229824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50179401280255, 0.005277200466650939 ]
  },
  "id_str" : "924282675640365056",
  "in_reply_to_user_id" : 14286491,
  "text" : "Lots of interest in barriers to open*, run by @rachaelevelyn #MozFest https:\/\/t.co\/WTIjP36pVC",
  "id" : 924282675640365056,
  "in_reply_to_status_id" : 924263201969229824,
  "created_at" : "2017-10-28 14:32:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/924269348403007488\/photo\/1",
      "indices" : [ 150, 173 ],
      "url" : "https:\/\/t.co\/VdpFhpgBll",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNOqEETXkAAU9A2.jpg",
      "id_str" : "924269335392260096",
      "id" : 924269335392260096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNOqEETXkAAU9A2.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1079
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1850,
        "resize" : "fit",
        "w" : 1664
      }, {
        "h" : 1850,
        "resize" : "fit",
        "w" : 1664
      } ],
      "display_url" : "pic.twitter.com\/VdpFhpgBll"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924265670111584257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183085310137, 0.005216971976918605 ]
  },
  "id_str" : "924269348403007488",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest When leaving my old lab one of \u201Emy\u201C students gave this to me. \uD83D\uDE2D a lot when I got it and wear the tiny moss proudly around my neck every day. https:\/\/t.co\/VdpFhpgBll",
  "id" : 924269348403007488,
  "in_reply_to_status_id" : 924265670111584257,
  "created_at" : "2017-10-28 13:39:19 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/cAz34DTJ04",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Capital_%E1%BA%9E",
      "display_url" : "en.wikipedia.org\/wiki\/Capital_%\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "924265911271526400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183949039912, 0.005204240119099809 ]
  },
  "id_str" : "924267034866831360",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab No fancy tricks like that in German. The capital \u00DF is finally part of the German language since June this year! https:\/\/t.co\/cAz34DTJ04",
  "id" : 924267034866831360,
  "in_reply_to_status_id" : 924265911271526400,
  "created_at" : "2017-10-28 13:30:07 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 3, 9 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    }, {
      "name" : "Caroline Alexiou",
      "screen_name" : "_sandtweets",
      "indices" : [ 52, 64 ],
      "id_str" : "338650222",
      "id" : 338650222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "924265715590483973",
  "text" : "RT @aath0: Learning how to draw squirrels? \u2705 Thanks @_sandtweets for the great programming-drawing session at #MozFest !! https:\/\/t.co\/HzoL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caroline Alexiou",
        "screen_name" : "_sandtweets",
        "indices" : [ 41, 53 ],
        "id_str" : "338650222",
        "id" : 338650222
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/aath0\/status\/924264247269445632\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/HzoLX9XTOi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNOlZ_vXkAEBpFP.jpg",
        "id_str" : "924264214566506497",
        "id" : 924264214566506497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNOlZ_vXkAEBpFP.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/HzoLX9XTOi"
      } ],
      "hashtags" : [ {
        "text" : "MozFest",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "924264247269445632",
    "text" : "Learning how to draw squirrels? \u2705 Thanks @_sandtweets for the great programming-drawing session at #MozFest !! https:\/\/t.co\/HzoLX9XTOi",
    "id" : 924264247269445632,
    "created_at" : "2017-10-28 13:19:03 +0000",
    "user" : {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "protected" : false,
      "id_str" : "753358633593925632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918218018500595713\/0-LcTq1y_normal.jpg",
      "id" : 753358633593925632,
      "verified" : false
    }
  },
  "id" : 924265715590483973,
  "created_at" : "2017-10-28 13:24:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924265444852166656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50184300911781, 0.00520133140799225 ]
  },
  "id_str" : "924265632589385729",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab The \u00DF is still used. How else would you tell Ma\u00DFe from Masse? :p",
  "id" : 924265632589385729,
  "in_reply_to_status_id" : 924265444852166656,
  "created_at" : "2017-10-28 13:24:33 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924265104094515201",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183819331303, 0.00520699706985821 ]
  },
  "id_str" : "924265294075498496",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Nah, you\u2019re right. Those would have been the correct quotation marks for German. \uD83D\uDC4D",
  "id" : 924265294075498496,
  "in_reply_to_status_id" : 924265104094515201,
  "created_at" : "2017-10-28 13:23:12 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924264556951670786",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5018324254381, 0.005215083955325968 ]
  },
  "id_str" : "924264650560147457",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab That\u2019s just my handwriting I fear \uD83D\uDE09",
  "id" : 924264650560147457,
  "in_reply_to_status_id" : 924264556951670786,
  "created_at" : "2017-10-28 13:20:39 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Ainsworth \uD83D\uDD2D",
      "screen_name" : "rachaelevelyn",
      "indices" : [ 3, 17 ],
      "id_str" : "130490305",
      "id" : 130490305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenScience",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "924264250092253184",
  "text" : "RT @rachaelevelyn: IN 1 HOUR! Let\u2019s talk barriers, benefits &amp; resources associated w #OpenScience! 9th floor, 902-L1 from 15:15-16:15 #Open\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rachaelevelyn\/status\/924263399952977921\/photo\/1",
        "indices" : [ 145, 168 ],
        "url" : "https:\/\/t.co\/51cIACtlAB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNOkqO5XkAUM4-B.jpg",
        "id_str" : "924263394001260549",
        "id" : 924263394001260549,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNOkqO5XkAUM4-B.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/51cIACtlAB"
      } ],
      "hashtags" : [ {
        "text" : "OpenScience",
        "indices" : [ 70, 82 ]
      }, {
        "text" : "OpenInnovation",
        "indices" : [ 119, 134 ]
      }, {
        "text" : "MozFest",
        "indices" : [ 136, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "924263399952977921",
    "text" : "IN 1 HOUR! Let\u2019s talk barriers, benefits &amp; resources associated w #OpenScience! 9th floor, 902-L1 from 15:15-16:15 #OpenInnovation\uD83D\uDCA1 #MozFest https:\/\/t.co\/51cIACtlAB",
    "id" : 924263399952977921,
    "created_at" : "2017-10-28 13:15:41 +0000",
    "user" : {
      "name" : "Rachael Ainsworth \uD83D\uDD2D",
      "screen_name" : "rachaelevelyn",
      "protected" : false,
      "id_str" : "130490305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894221299584819201\/Vrem-4Gn_normal.jpg",
      "id" : 130490305,
      "verified" : false
    }
  },
  "id" : 924264250092253184,
  "created_at" : "2017-10-28 13:19:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caroline Alexiou",
      "screen_name" : "_sandtweets",
      "indices" : [ 7, 19 ],
      "id_str" : "338650222",
      "id" : 338650222
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/924263201969229824\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/XDUtrEOhgo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNOken4XUAEgcxY.jpg",
      "id_str" : "924263194549506049",
      "id" : 924263194549506049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNOken4XUAEgcxY.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/XDUtrEOhgo"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924256800911843328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183758568275, 0.005206016442656194 ]
  },
  "id_str" : "924263201969229824",
  "in_reply_to_user_id" : 14286491,
  "text" : "Thanks @_sandtweets for the squirrel drawing\/programming lesson this morning! #MozFest https:\/\/t.co\/XDUtrEOhgo",
  "id" : 924263201969229824,
  "in_reply_to_status_id" : 924256800911843328,
  "created_at" : "2017-10-28 13:14:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/924256800911843328\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/pW7Jo4M8P1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNOepJdXUAAT-ME.jpg",
      "id_str" : "924256778291990528",
      "id" : 924256778291990528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNOepJdXUAAT-ME.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pW7Jo4M8P1"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "MozFest",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924216817312325632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50163702390451, 0.004701226303529573 ]
  },
  "id_str" : "924256800911843328",
  "in_reply_to_user_id" : 14286491,
  "text" : "My scheming squirrel is kind of unsure on whether it would rather be a \uD83D\uDC30. #MozFest  #MozFest https:\/\/t.co\/pW7Jo4M8P1",
  "id" : 924256800911843328,
  "in_reply_to_status_id" : 924216817312325632,
  "created_at" : "2017-10-28 12:49:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183563662003, 0.005213848842577196 ]
  },
  "id_str" : "924235920756396037",
  "text" : "Social engineering: Your DNA match is GGTT or CCAA? I\u2019m standing right next to the raffle entry box in the food queue on level 4. #mozfest",
  "id" : 924235920756396037,
  "created_at" : "2017-10-28 11:26:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/924216817312325632\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/bVR4JSzTHG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNN6RmYX0AAkVAg.jpg",
      "id_str" : "924216791320219648",
      "id" : 924216791320219648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNN6RmYX0AAkVAg.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/bVR4JSzTHG"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50173904556618, 0.005189340068542898 ]
  },
  "id_str" : "924216817312325632",
  "text" : "Today I will learn how to draw a squirrel! #MozFest \uD83E\uDD8A\uD83D\uDC96\uD83D\uDC3F https:\/\/t.co\/bVR4JSzTHG",
  "id" : 924216817312325632,
  "created_at" : "2017-10-28 10:10:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/xhQUMyXHFr",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BayNJYkFKgv\/",
      "display_url" : "instagram.com\/p\/BayNJYkFKgv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "924186421254123520",
  "text" : "The #MozFest wake-up call. https:\/\/t.co\/xhQUMyXHFr",
  "id" : 924186421254123520,
  "created_at" : "2017-10-28 08:09:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924178058931785728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183372276644, 0.005215767604523822 ]
  },
  "id_str" : "924184706991747072",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps And I\u2019d have loved to join FORCE, but with the move that just wasn\u2019t possible :(",
  "id" : 924184706991747072,
  "in_reply_to_status_id" : 924178058931785728,
  "created_at" : "2017-10-28 08:02:59 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50488516084349, -0.08204647193723616 ]
  },
  "id_str" : "924053677488394240",
  "text" : "\u00ABThe toothpaste you smeared onto me won\u2019t wash off!\u00BB \u2014 \u00ABThat\u2019s because it\u2019s tattoothpaste!\u00BB",
  "id" : 924053677488394240,
  "created_at" : "2017-10-27 23:22:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DVD",
      "screen_name" : "DVDGC13",
      "indices" : [ 0, 8 ],
      "id_str" : "36380741",
      "id" : 36380741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "924051588313964544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50490480850753, -0.08202671509530804 ]
  },
  "id_str" : "924051726973505537",
  "in_reply_to_user_id" : 36380741,
  "text" : "@DVDGC13 Word! \uD83D\uDC4D",
  "id" : 924051726973505537,
  "in_reply_to_status_id" : 924051588313964544,
  "created_at" : "2017-10-27 23:14:34 +0000",
  "in_reply_to_screen_name" : "DVDGC13",
  "in_reply_to_user_id_str" : "36380741",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50499566645067, -0.08199732971570174 ]
  },
  "id_str" : "924051282586980352",
  "text" : "Day 0 of #MozFest is over for me and I\u2019m already so happily exhausted from meeting so many friends and having so many great conversations \uD83D\uDE0D",
  "id" : 924051282586980352,
  "created_at" : "2017-10-27 23:12:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 12, 21 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923994653925564416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51272583985934, -0.120544816627765 ]
  },
  "id_str" : "924012148484968448",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena @abbycabs Only the DNA stickers on our name tags :)",
  "id" : 924012148484968448,
  "in_reply_to_status_id" : 923994653925564416,
  "created_at" : "2017-10-27 20:37:18 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Festival",
      "screen_name" : "mozillafestival",
      "indices" : [ 0, 16 ],
      "id_str" : "348416778",
      "id" : 348416778
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 17, 26 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Temi Lasade",
      "screen_name" : "temilasade",
      "indices" : [ 27, 38 ],
      "id_str" : "69955843",
      "id" : 69955843
    }, {
      "name" : "Isik Mater",
      "screen_name" : "isik5",
      "indices" : [ 64, 70 ],
      "id_str" : "27599261",
      "id" : 27599261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923999602965139456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51273123532081, -0.1205779607305557 ]
  },
  "id_str" : "924012073843134470",
  "in_reply_to_user_id" : 348416778,
  "text" : "@mozillafestival @abbycabs @temilasade Will definitely do that! @isik5",
  "id" : 924012073843134470,
  "in_reply_to_status_id" : 923999602965139456,
  "created_at" : "2017-10-27 20:37:00 +0000",
  "in_reply_to_screen_name" : "mozillafestival",
  "in_reply_to_user_id_str" : "348416778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isik Mater",
      "screen_name" : "isik5",
      "indices" : [ 3, 9 ],
      "id_str" : "27599261",
      "id" : 27599261
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 45, 61 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/isik5\/status\/923991338340757504\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/D1stxr1THG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNKsyMRXkAA11nu.jpg",
      "id_str" : "923990851851882496",
      "id" : 923990851851882496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNKsyMRXkAA11nu.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/D1stxr1THG"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "923993500869431297",
  "text" : "RT @isik5: I found the other portal #mozfest @gedankenstuecke https:\/\/t.co\/D1stxr1THG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 34, 50 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/isik5\/status\/923991338340757504\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/D1stxr1THG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DNKsyMRXkAA11nu.jpg",
        "id_str" : "923990851851882496",
        "id" : 923990851851882496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNKsyMRXkAA11nu.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/D1stxr1THG"
      } ],
      "hashtags" : [ {
        "text" : "mozfest",
        "indices" : [ 25, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "923991338340757504",
    "text" : "I found the other portal #mozfest @gedankenstuecke https:\/\/t.co\/D1stxr1THG",
    "id" : 923991338340757504,
    "created_at" : "2017-10-27 19:14:36 +0000",
    "user" : {
      "name" : "Isik Mater",
      "screen_name" : "isik5",
      "protected" : false,
      "id_str" : "27599261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797225310454419456\/Ij31-zuI_normal.jpg",
      "id" : 27599261,
      "verified" : true
    }
  },
  "id" : 923993500869431297,
  "created_at" : "2017-10-27 19:23:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 89, 98 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/DuA8Elil3H",
      "expanded_url" : "https:\/\/twitter.com\/isik5\/status\/923990064530644992",
      "display_url" : "twitter.com\/isik5\/status\/9\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50183110344958, 0.005217961616882746 ]
  },
  "id_str" : "923990746734235648",
  "text" : "And here I stumble over my tattoo match. Does that qualify for a raffle ticket? #MozFest @abbycabs https:\/\/t.co\/DuA8Elil3H",
  "id" : 923990746734235648,
  "created_at" : "2017-10-27 19:12:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Gilcher",
      "screen_name" : "Argorak",
      "indices" : [ 0, 8 ],
      "id_str" : "27227212",
      "id" : 27227212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923954249528217601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50169432101464, 0.004869612862354778 ]
  },
  "id_str" : "923976520787546112",
  "in_reply_to_user_id" : 27227212,
  "text" : "@Argorak Stuck at the registration desk to hand out DNA match stickers for now. :)",
  "id" : 923976520787546112,
  "in_reply_to_status_id" : 923954249528217601,
  "created_at" : "2017-10-27 18:15:43 +0000",
  "in_reply_to_screen_name" : "Argorak",
  "in_reply_to_user_id_str" : "27227212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 37, 44 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 45, 55 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/923917666880032768\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/9ewloq6OYv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNJqMmMX4AEKp6F.jpg",
      "id_str" : "923917638207791105",
      "id" : 923917638207791105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNJqMmMX4AEKp6F.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/9ewloq6OYv"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180133749088, 0.005265824945667363 ]
  },
  "id_str" : "923917666880032768",
  "text" : "Getting ready for the New Nerdcator. @sujaik @auremoser #MozFest https:\/\/t.co\/9ewloq6OYv",
  "id" : 923917666880032768,
  "created_at" : "2017-10-27 14:21:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/923905257649983489\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/cHzDklai7a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNJe52fXcAEXexY.jpg",
      "id_str" : "923905221537001473",
      "id" : 923905221537001473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNJe52fXcAEXexY.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/cHzDklai7a"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180052283731, 0.005265202312432592 ]
  },
  "id_str" : "923905257649983489",
  "text" : "Set up my name tag for #MozFest \uD83C\uDF89 https:\/\/t.co\/cHzDklai7a",
  "id" : 923905257649983489,
  "created_at" : "2017-10-27 13:32:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50180723269659, 0.005239853250347352 ]
  },
  "id_str" : "923843238716461056",
  "text" : "Always so thrilled to be at the facilitator session at #MozFest. So so many friendly faces! \uD83D\uDE0D",
  "id" : 923843238716461056,
  "created_at" : "2017-10-27 09:26:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 13, 22 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 23, 28 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 29, 42 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923687510512828416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50489553592803, -0.08204314961079053 ]
  },
  "id_str" : "923690363839307776",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @abbycabs @tpoi @PhilippBayer \uD83D\uDE07",
  "id" : 923690363839307776,
  "in_reply_to_status_id" : 923687510512828416,
  "created_at" : "2017-10-26 23:18:38 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 13, 22 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 23, 28 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 29, 42 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923682351745396736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50488318785236, -0.08211984390614827 ]
  },
  "id_str" : "923687305717649408",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @abbycabs @tpoi @PhilippBayer it\u2019s not the same when you\u2019re not around for hotel room parties!",
  "id" : 923687305717649408,
  "in_reply_to_status_id" : 923682351745396736,
  "created_at" : "2017-10-26 23:06:29 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 16, 29 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923669117957296130",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50494366951978, -0.08203495735193823 ]
  },
  "id_str" : "923669338493775875",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @tpoi @PhilippBayer Yep, wasn\u2019t punched today, so everything\u2019s great! \uD83D\uDE09 looking forward to catch up tomorrow! \uD83D\uDE0D",
  "id" : 923669338493775875,
  "in_reply_to_status_id" : 923669117957296130,
  "created_at" : "2017-10-26 21:55:05 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 10, 15 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 16, 29 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/pNQIdWYWRL",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/923661317550034945",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "923665486382010368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50488844662001, -0.08211738452171186 ]
  },
  "id_str" : "923666042295119873",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @tpoi @PhilippBayer Let\u2019s say it was a bit rough around the edges \uD83D\uDE02 https:\/\/t.co\/pNQIdWYWRL",
  "id" : 923666042295119873,
  "in_reply_to_status_id" : 923665486382010368,
  "created_at" : "2017-10-26 21:42:00 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923661644135370752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50487618858926, -0.08203931713452518 ]
  },
  "id_str" : "923662980822298630",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks that\u2019s what happens with airlines becoming increasingly poor when it comes to in-flight meals!",
  "id" : 923662980822298630,
  "in_reply_to_status_id" : 923661644135370752,
  "created_at" : "2017-10-26 21:29:50 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/923661317550034945\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/42nycyg8TF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNGBEbOXcAETsTj.jpg",
      "id_str" : "923661311615135745",
      "id" : 923661311615135745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNGBEbOXcAETsTj.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/42nycyg8TF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5049139193961, -0.08208609467989127 ]
  },
  "id_str" : "923661317550034945",
  "text" : "Yep, totally so hungry that I\u2019m trying to steal Paddington\u2019s sandwich here. https:\/\/t.co\/42nycyg8TF",
  "id" : 923661317550034945,
  "created_at" : "2017-10-26 21:23:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yuvi Panda",
      "screen_name" : "yuvipanda",
      "indices" : [ 0, 10 ],
      "id_str" : "824065",
      "id" : 824065
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 11, 20 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923653719329193984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50480470076763, -0.08227480823668358 ]
  },
  "id_str" : "923655488184750082",
  "in_reply_to_user_id" : 824065,
  "text" : "@yuvipanda @madprime that\u2019s really cool! \uD83D\uDC4D",
  "id" : 923655488184750082,
  "in_reply_to_status_id" : 923653719329193984,
  "created_at" : "2017-10-26 21:00:03 +0000",
  "in_reply_to_screen_name" : "yuvipanda",
  "in_reply_to_user_id_str" : "824065",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/BI4ACNMQMD",
      "expanded_url" : "https:\/\/twitterlytic.herokuapp.com\/profile\/gedankenstuecke\/",
      "display_url" : "twitterlytic.herokuapp.com\/profile\/gedank\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "923648505230581760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50489990010156, -0.08213275007600297 ]
  },
  "id_str" : "923650265676419072",
  "in_reply_to_user_id" : 14286491,
  "text" : "I still have a good way to go to get a gender-balanced Twitter feed. https:\/\/t.co\/BI4ACNMQMD",
  "id" : 923650265676419072,
  "in_reply_to_status_id" : 923648505230581760,
  "created_at" : "2017-10-26 20:39:18 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 80, 89 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampioningWISreport",
      "indices" : [ 3, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/H97VmCx2Cf",
      "expanded_url" : "https:\/\/twitter.com\/madprime\/status\/923609275410169856",
      "display_url" : "twitter.com\/madprime\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923648505230581760",
  "text" : "My #ChampioningWISreport contribution made you wonder whom you're listening to? @madprime build this to check whom you're following! https:\/\/t.co\/H97VmCx2Cf",
  "id" : 923648505230581760,
  "created_at" : "2017-10-26 20:32:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/SIqunphyUl",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BauYAQ3FIn5\/",
      "display_url" : "instagram.com\/p\/BauYAQ3FIn5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.505149185829, -0.075584744260704 ]
  },
  "id_str" : "923647275359911936",
  "text" : "I will miss London and the ability to quickly hop over for a few days. @ Tower Bridge https:\/\/t.co\/SIqunphyUl",
  "id" : 923647275359911936,
  "created_at" : "2017-10-26 20:27:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    }, {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 11, 22 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 23, 39 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 40, 52 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Frank Norman",
      "screen_name" : "franknorman",
      "indices" : [ 53, 65 ],
      "id_str" : "16084102",
      "id" : 16084102
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 66, 76 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 77, 89 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Samantha Hindle",
      "screen_name" : "HindleSamantha",
      "indices" : [ 90, 105 ],
      "id_str" : "4917922363",
      "id" : 4917922363
    }, {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 106, 115 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    }, {
      "name" : "Teon L Brooks, PhD",
      "screen_name" : "teon_io",
      "indices" : [ 116, 124 ],
      "id_str" : "30960103",
      "id" : 30960103
    }, {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 125, 134 ],
      "id_str" : "297073565",
      "id" : 297073565
    }, {
      "name" : "Tara Vancil",
      "screen_name" : "taravancil",
      "indices" : [ 135, 146 ],
      "id_str" : "2540605710",
      "id" : 2540605710
    }, {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 188, 194 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923607017251655680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50487993301203, -0.0820274075154392 ]
  },
  "id_str" : "923612189134639104",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience @Neurosarda @daniellecrobins @denormalize @franknorman @kirstie_j @chartgerink @HindleSamantha @yoyehudi @teon_io @Monsauce @taravancil Just arrived at the Hilton Tower Bridge. @aath0 and I are searching for some Vietnamese dinner as I type.",
  "id" : 923612189134639104,
  "in_reply_to_status_id" : 923607017251655680,
  "created_at" : "2017-10-26 18:08:00 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923558207309729793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46977685862358, -0.4661445412789156 ]
  },
  "id_str" : "923572868759408640",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Not to Mozfest though \uD83D\uDE09",
  "id" : 923572868759408640,
  "in_reply_to_status_id" : 923558207309729793,
  "created_at" : "2017-10-26 15:31:45 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923553116347355137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47641348191674, -0.4598227422688713 ]
  },
  "id_str" : "923572151222964224",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Let\u2019s hope it passes through customs :D",
  "id" : 923572151222964224,
  "in_reply_to_status_id" : 923553116347355137,
  "created_at" : "2017-10-26 15:28:54 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana #hcsm #OpenAPS",
      "screen_name" : "danamlewis",
      "indices" : [ 102, 113 ],
      "id_str" : "15165858",
      "id" : 15165858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TtPrynlTez",
      "expanded_url" : "https:\/\/blog.openhumans.org\/2017\/10\/25\/why-open-humans-is-an-essential-part-of-my-work-to-change-the-future-of-healthcare-research\/",
      "display_url" : "blog.openhumans.org\/2017\/10\/25\/why\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04656306506674, 8.571621178249748 ]
  },
  "id_str" : "923534768310013953",
  "text" : "Read \u00ABWhy Open Humans is an essential part of my work to change the future of healthcare\u00A0research\u00BB by @danamlewis https:\/\/t.co\/TtPrynlTez",
  "id" : 923534768310013953,
  "created_at" : "2017-10-26 13:00:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Klassen",
      "screen_name" : "KlassenLab",
      "indices" : [ 0, 11 ],
      "id_str" : "1421096077",
      "id" : 1421096077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923529361839575040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04656232737652, 8.571621727668578 ]
  },
  "id_str" : "923530212251459584",
  "in_reply_to_user_id" : 1421096077,
  "text" : "@KlassenLab (positively surprised, as from my experience most people don\u2019t do that)",
  "id" : 923530212251459584,
  "in_reply_to_status_id" : 923529361839575040,
  "created_at" : "2017-10-26 12:42:15 +0000",
  "in_reply_to_screen_name" : "KlassenLab",
  "in_reply_to_user_id_str" : "1421096077",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Klassen",
      "screen_name" : "KlassenLab",
      "indices" : [ 0, 11 ],
      "id_str" : "1421096077",
      "id" : 1421096077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923529361839575040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04656232737652, 8.571621727668578 ]
  },
  "id_str" : "923530137806794752",
  "in_reply_to_user_id" : 1421096077,
  "text" : "@KlassenLab I find the 50% of people being in psychological distress extremely believable. Would just be surprised if so many would go and seek help. :(",
  "id" : 923530137806794752,
  "in_reply_to_status_id" : 923529361839575040,
  "created_at" : "2017-10-26 12:41:57 +0000",
  "in_reply_to_screen_name" : "KlassenLab",
  "in_reply_to_user_id_str" : "1421096077",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Klassen",
      "screen_name" : "KlassenLab",
      "indices" : [ 0, 11 ],
      "id_str" : "1421096077",
      "id" : 1421096077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923526271409311745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04674223061534, 8.571761636332765 ]
  },
  "id_str" : "923528746510012416",
  "in_reply_to_user_id" : 1421096077,
  "text" : "@KlassenLab (Not that this is much better though)",
  "id" : 923528746510012416,
  "in_reply_to_status_id" : 923526271409311745,
  "created_at" : "2017-10-26 12:36:26 +0000",
  "in_reply_to_screen_name" : "KlassenLab",
  "in_reply_to_user_id_str" : "1421096077",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Klassen",
      "screen_name" : "KlassenLab",
      "indices" : [ 0, 11 ],
      "id_str" : "1421096077",
      "id" : 1421096077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923526271409311745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04674223061534, 8.571761636332765 ]
  },
  "id_str" : "923528599948419072",
  "in_reply_to_user_id" : 1421096077,
  "text" : "@KlassenLab It\u2019s 12% in total. 1\/4th of respondents mention mental issues, 45% of those sought help.",
  "id" : 923528599948419072,
  "in_reply_to_status_id" : 923526271409311745,
  "created_at" : "2017-10-26 12:35:51 +0000",
  "in_reply_to_screen_name" : "KlassenLab",
  "in_reply_to_user_id_str" : "1421096077",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mozfest",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396612237449, 8.752950068902738 ]
  },
  "id_str" : "923493711480344576",
  "text" : "Hey #Mozfest friends. Who\u2019s already in London tonight and up for some dinner?",
  "id" : 923493711480344576,
  "created_at" : "2017-10-26 10:17:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SfAM Microbiology",
      "screen_name" : "SfAMtweets",
      "indices" : [ 0, 11 ],
      "id_str" : "54243837",
      "id" : 54243837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923479779239780352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397531260747, 8.753291638576195 ]
  },
  "id_str" : "923493154891993088",
  "in_reply_to_user_id" : 54243837,
  "text" : "@SfAMtweets Apparently ~35 kg of luggage in total when moving from \uD83C\uDDEA\uD83C\uDDFA to \uD83C\uDDFA\uD83C\uDDF8 ;)",
  "id" : 923493154891993088,
  "in_reply_to_status_id" : 923479779239780352,
  "created_at" : "2017-10-26 10:15:00 +0000",
  "in_reply_to_screen_name" : "SfAMtweets",
  "in_reply_to_user_id_str" : "54243837",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/923461274717081601\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/4U9lzzwLJP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNDLIkkX0AA9e3x.jpg",
      "id_str" : "923461271726575616",
      "id" : 923461271726575616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNDLIkkX0AA9e3x.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/4U9lzzwLJP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "923461274717081601",
  "text" : "The important things go in last. \uD83D\uDE02 https:\/\/t.co\/4U9lzzwLJP",
  "id" : 923461274717081601,
  "created_at" : "2017-10-26 08:08:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Brown",
      "screen_name" : "sTeamTraen",
      "indices" : [ 3, 14 ],
      "id_str" : "53410834",
      "id" : 53410834
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 44, 52 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WisdomOfCrowds",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/TfFcERveJv",
      "expanded_url" : "https:\/\/www.nytimes.com\/2017\/10\/23\/upshot\/the-cookie-crumbles-a-retracted-study-points-to-a-larger-truth.html?_r=0",
      "display_url" : "nytimes.com\/2017\/10\/23\/ups\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "923439943195774976",
  "text" : "RT @sTeamTraen: Wansink story finally makes @nytimes: https:\/\/t.co\/TfFcERveJv\n\nHere is the top-rated comment. #WisdomOfCrowds https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 28, 36 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sTeamTraen\/status\/922529914531844096\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/GcCED2JE0j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DM18D-xXUAEO8zO.jpg",
        "id_str" : "922529906512318465",
        "id" : 922529906512318465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DM18D-xXUAEO8zO.jpg",
        "sizes" : [ {
          "h" : 627,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 517
        } ],
        "display_url" : "pic.twitter.com\/GcCED2JE0j"
      } ],
      "hashtags" : [ {
        "text" : "WisdomOfCrowds",
        "indices" : [ 94, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/TfFcERveJv",
        "expanded_url" : "https:\/\/www.nytimes.com\/2017\/10\/23\/upshot\/the-cookie-crumbles-a-retracted-study-points-to-a-larger-truth.html?_r=0",
        "display_url" : "nytimes.com\/2017\/10\/23\/ups\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "922529914531844096",
    "text" : "Wansink story finally makes @nytimes: https:\/\/t.co\/TfFcERveJv\n\nHere is the top-rated comment. #WisdomOfCrowds https:\/\/t.co\/GcCED2JE0j",
    "id" : 922529914531844096,
    "created_at" : "2017-10-23 18:27:26 +0000",
    "user" : {
      "name" : "Nick Brown",
      "screen_name" : "sTeamTraen",
      "protected" : false,
      "id_str" : "53410834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903663911689486336\/L4eTyLpN_normal.jpg",
      "id" : 53410834,
      "verified" : false
    }
  },
  "id" : 923439943195774976,
  "created_at" : "2017-10-26 06:43:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 10, 26 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/2fbAILvxpg",
      "expanded_url" : "https:\/\/www.youcaring.com\/charlotte-987108",
      "display_url" : "youcaring.com\/charlotte-9871\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11382267050206, 8.75337821673941 ]
  },
  "id_str" : "923291732212580353",
  "text" : "My friend @fireantprincess wants to freeze her sperm b4 starting HRT. Health insurance doesn\u2019t cover, help needed: https:\/\/t.co\/2fbAILvxpg",
  "id" : 923291732212580353,
  "created_at" : "2017-10-25 20:54:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Ainsworth \uD83D\uDD2D",
      "screen_name" : "rachaelevelyn",
      "indices" : [ 0, 14 ],
      "id_str" : "130490305",
      "id" : 130490305
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 15, 30 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "922802217299660806",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35922574535697, 8.588183233522425 ]
  },
  "id_str" : "922802643315183617",
  "in_reply_to_user_id" : 130490305,
  "text" : "@rachaelevelyn @MozOpenLeaders Anytime! And looking forward to meet in person!",
  "id" : 922802643315183617,
  "in_reply_to_status_id" : 922802217299660806,
  "created_at" : "2017-10-24 12:31:09 +0000",
  "in_reply_to_screen_name" : "rachaelevelyn",
  "in_reply_to_user_id_str" : "130490305",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Ainsworth \uD83D\uDD2D",
      "screen_name" : "rachaelevelyn",
      "indices" : [ 3, 17 ],
      "id_str" : "130490305",
      "id" : 130490305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenScience",
      "indices" : [ 19, 31 ]
    }, {
      "text" : "OAWeek",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/jcVKBhwL4K",
      "expanded_url" : "https:\/\/twitter.com\/chrislintott\/status\/921670018068234240",
      "display_url" : "twitter.com\/chrislintott\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "922776019202920448",
  "text" : "RT @rachaelevelyn: #OpenScience in astronomy \u2728 #OAWeek https:\/\/t.co\/jcVKBhwL4K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenScience",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "OAWeek",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/jcVKBhwL4K",
        "expanded_url" : "https:\/\/twitter.com\/chrislintott\/status\/921670018068234240",
        "display_url" : "twitter.com\/chrislintott\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "922743806444883968",
    "text" : "#OpenScience in astronomy \u2728 #OAWeek https:\/\/t.co\/jcVKBhwL4K",
    "id" : 922743806444883968,
    "created_at" : "2017-10-24 08:37:21 +0000",
    "user" : {
      "name" : "Rachael Ainsworth \uD83D\uDD2D",
      "screen_name" : "rachaelevelyn",
      "protected" : false,
      "id_str" : "130490305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/894221299584819201\/Vrem-4Gn_normal.jpg",
      "id" : 130490305,
      "verified" : false
    }
  },
  "id" : 922776019202920448,
  "created_at" : "2017-10-24 10:45:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 3, 16 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    }, {
      "name" : "UW Libraries",
      "screen_name" : "uwlibraries",
      "indices" : [ 83, 95 ],
      "id_str" : "34715154",
      "id" : 34715154
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/blueyedgenes\/status\/922564803163385856\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/32ZsA1SXGb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DM2byswUEAEGKyw.jpg",
      "id_str" : "922564793990385665",
      "id" : 922564793990385665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DM2byswUEAEGKyw.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/32ZsA1SXGb"
    } ],
    "hashtags" : [ {
      "text" : "OpenAccessWeek2017",
      "indices" : [ 96, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "922585282804899841",
  "text" : "RT @blueyedgenes: Delighted to have been interviewed about \u201Chow I work openly\u201D for @uwlibraries #OpenAccessWeek2017! https:\/\/t.co\/32ZsA1SXGb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UW Libraries",
        "screen_name" : "uwlibraries",
        "indices" : [ 65, 77 ],
        "id_str" : "34715154",
        "id" : 34715154
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/blueyedgenes\/status\/922564803163385856\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/32ZsA1SXGb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DM2byswUEAEGKyw.jpg",
        "id_str" : "922564793990385665",
        "id" : 922564793990385665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DM2byswUEAEGKyw.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/32ZsA1SXGb"
      } ],
      "hashtags" : [ {
        "text" : "OpenAccessWeek2017",
        "indices" : [ 78, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "922564803163385856",
    "text" : "Delighted to have been interviewed about \u201Chow I work openly\u201D for @uwlibraries #OpenAccessWeek2017! https:\/\/t.co\/32ZsA1SXGb",
    "id" : 922564803163385856,
    "created_at" : "2017-10-23 20:46:04 +0000",
    "user" : {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "protected" : false,
      "id_str" : "760870811494297600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760884999918800896\/WyAaxXFj_normal.jpg",
      "id" : 760870811494297600,
      "verified" : false
    }
  },
  "id" : 922585282804899841,
  "created_at" : "2017-10-23 22:07:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STEM Women",
      "screen_name" : "STEMWomen",
      "indices" : [ 65, 75 ],
      "id_str" : "2313699698",
      "id" : 2313699698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampioningWISreport",
      "indices" : [ 32, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/BrIFSwtTQG",
      "expanded_url" : "https:\/\/twitter.com\/madamscientist\/status\/922552689493495809",
      "display_url" : "twitter.com\/madamscientist\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35940789141848, 8.587909495534655 ]
  },
  "id_str" : "922556947613802496",
  "text" : "Honored that my contribution to #ChampioningWISreport made it to @STEMWomen too! \uD83D\uDE0D https:\/\/t.co\/BrIFSwtTQG",
  "id" : 922556947613802496,
  "created_at" : "2017-10-23 20:14:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/k5Ug8qXCt7",
      "expanded_url" : "https:\/\/twitter.com\/reat_ch\/status\/922542787463131138",
      "display_url" : "twitter.com\/reat_ch\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35901003844127, 8.588007148387186 ]
  },
  "id_str" : "922554584803020800",
  "text" : "If you\u2019re in\/around Basel tomorrow: drop by to discuss everyday genetics. https:\/\/t.co\/k5Ug8qXCt7",
  "id" : 922554584803020800,
  "created_at" : "2017-10-23 20:05:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "922426215520198657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236067708071, 8.62752177449355 ]
  },
  "id_str" : "922445328892219392",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek Well, the data was already collected thanks to the irregular invoicing of our coffee consumption &amp; it would have been a shame to waste it \uD83D\uDE02",
  "id" : 922445328892219392,
  "in_reply_to_status_id" : 922426215520198657,
  "created_at" : "2017-10-23 12:51:19 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Y6eMXPTyKq",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/922394473463779328",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "922394473463779328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723032200349, 8.627516664310244 ]
  },
  "id_str" : "922401885667123202",
  "in_reply_to_user_id" : 14286491,
  "text" : "That makes 2.23 coffee per work day and a total of 861.51 \u20AC spent on coffee. https:\/\/t.co\/Y6eMXPTyKq",
  "id" : 922401885667123202,
  "in_reply_to_status_id" : 922394473463779328,
  "created_at" : "2017-10-23 09:58:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "922396217052721152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723032200349, 8.627516664310244 ]
  },
  "id_str" : "922401623560937472",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin My office is the farthest away to the kitchen. Still I\u2019m #1 on the internal coffee ranking. ;)",
  "id" : 922401623560937472,
  "in_reply_to_status_id" : 922396217052721152,
  "created_at" : "2017-10-23 09:57:39 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/922394473463779328\/photo\/1",
      "indices" : [ 130, 153 ],
      "url" : "https:\/\/t.co\/Kni8zJz6Mh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DM0A4SqWsAI1vbF.jpg",
      "id_str" : "922394465762979842",
      "id" : 922394465762979842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DM0A4SqWsAI1vbF.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 2099,
        "resize" : "fit",
        "w" : 2096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1198
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2045
      } ],
      "display_url" : "pic.twitter.com\/Kni8zJz6Mh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230625337962, 8.627517781157112 ]
  },
  "id_str" : "922394473463779328",
  "text" : "I updated my total in-office coffee consumption for the last time, covering 4 1\/2 years. Red highlight is the PhD writing period. https:\/\/t.co\/Kni8zJz6Mh",
  "id" : 922394473463779328,
  "created_at" : "2017-10-23 09:29:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386614172093, 8.753323157013448 ]
  },
  "id_str" : "922341630237081600",
  "text" : "Put all my life into storage. Now for the last day in my old job, teaching some more Python.",
  "id" : 922341630237081600,
  "created_at" : "2017-10-23 05:59:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "922340542746386434",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384536838764, 8.753255315677704 ]
  },
  "id_str" : "922341407393812480",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Prost \uD83E\uDD42",
  "id" : 922341407393812480,
  "in_reply_to_status_id" : 922340542746386434,
  "created_at" : "2017-10-23 05:58:22 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 0, 7 ],
      "id_str" : "11383092",
      "id" : 11383092
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/921826276335341568\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/FSw21CDzLV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DMr8E8fW4AAfccP.jpg",
      "id_str" : "921826235638013952",
      "id" : 921826235638013952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMr8E8fW4AAfccP.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/FSw21CDzLV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "921823561085485057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402553373966, 8.75336820464586 ]
  },
  "id_str" : "921826276335341568",
  "in_reply_to_user_id" : 11383092,
  "text" : "@cMadan Just turned it on again! https:\/\/t.co\/FSw21CDzLV",
  "id" : 921826276335341568,
  "in_reply_to_status_id" : 921823561085485057,
  "created_at" : "2017-10-21 19:51:25 +0000",
  "in_reply_to_screen_name" : "cMadan",
  "in_reply_to_user_id_str" : "11383092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 0, 7 ],
      "id_str" : "11383092",
      "id" : 11383092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/Xv5JonKoYZ",
      "expanded_url" : "http:\/\/rad1o.badge.events.ccc.de\/",
      "display_url" : "rad1o.badge.events.ccc.de"
    } ]
  },
  "in_reply_to_status_id_str" : "921823561085485057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402995423087, 8.753375099197426 ]
  },
  "id_str" : "921824934929879040",
  "in_reply_to_user_id" : 11383092,
  "text" : "@cMadan Here\u2019s the documentation for it: https:\/\/t.co\/Xv5JonKoYZ :)",
  "id" : 921824934929879040,
  "in_reply_to_status_id" : 921823561085485057,
  "created_at" : "2017-10-21 19:46:05 +0000",
  "in_reply_to_screen_name" : "cMadan",
  "in_reply_to_user_id_str" : "11383092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 0, 7 ],
      "id_str" : "11383092",
      "id" : 11383092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cccamp15",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "921815428640464896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1132396178895, 8.753971030789726 ]
  },
  "id_str" : "921822750712442881",
  "in_reply_to_user_id" : 11383092,
  "text" : "@cMadan That\u2019s the one of the #cccamp15. It has a small screen, you can write your own programs for it and I can communicate w\/ other badges!",
  "id" : 921822750712442881,
  "in_reply_to_status_id" : 921815428640464896,
  "created_at" : "2017-10-21 19:37:25 +0000",
  "in_reply_to_screen_name" : "cMadan",
  "in_reply_to_user_id_str" : "11383092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 0, 7 ],
      "id_str" : "9723702",
      "id" : 9723702
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/921754749665497088\/photo\/1",
      "indices" : [ 148, 171 ],
      "url" : "https:\/\/t.co\/fnTAhZBwjE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DMq7BvSXcAAF6Tm.jpg",
      "id_str" : "921754712298450944",
      "id" : 921754712298450944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMq7BvSXcAAF6Tm.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/fnTAhZBwjE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "921753632638300160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11378615414166, 8.753416498545489 ]
  },
  "id_str" : "921754749665497088",
  "in_reply_to_user_id" : 9723702,
  "text" : "@ansate Moving from Frankfurt to Berkeley means that they (+ all of my books\/instruments, see picture for a selection) will go into storage for now https:\/\/t.co\/fnTAhZBwjE",
  "id" : 921754749665497088,
  "in_reply_to_status_id" : 921753632638300160,
  "created_at" : "2017-10-21 15:07:12 +0000",
  "in_reply_to_screen_name" : "ansate",
  "in_reply_to_user_id_str" : "9723702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "921705794210533378",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388374031532, 8.753320807599232 ]
  },
  "id_str" : "921709294533439489",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Schickste mir mal deine Adresse dann kann ich ihn dir zukommen lassen.",
  "id" : 921709294533439489,
  "in_reply_to_status_id" : 921705794210533378,
  "created_at" : "2017-10-21 12:06:35 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "921703005107388416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11374337319508, 8.753513331770952 ]
  },
  "id_str" : "921709183199784961",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler Thanks! They all look like that with varying stickers to tell them apart \uD83D\uDE02",
  "id" : 921709183199784961,
  "in_reply_to_status_id" : 921703005107388416,
  "created_at" : "2017-10-21 12:06:08 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/921700648860770304\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/VUw9IyddTg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DMqJ0s5X0AAvIEK.jpg",
      "id_str" : "921700612248686592",
      "id" : 921700612248686592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMqJ0s5X0AAvIEK.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/VUw9IyddTg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233166152353, 8.627524332577712 ]
  },
  "id_str" : "921700648860770304",
  "text" : "Cleaning out my office. 4 1\/2 years worth of notes collected during my PhD. https:\/\/t.co\/VUw9IyddTg",
  "id" : 921700648860770304,
  "created_at" : "2017-10-21 11:32:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dani\u00EBl Lakens",
      "screen_name" : "lakens",
      "indices" : [ 3, 10 ],
      "id_str" : "17387342",
      "id" : 17387342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "921682009629646848",
  "text" : "RT @lakens: Brian Wansink retracts a corrected version of a study that he published after retracting the first version of the study. I'm so\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 248, 271 ],
        "url" : "https:\/\/t.co\/CsD1OKrwGL",
        "expanded_url" : "https:\/\/twitter.com\/RetractionWatch\/status\/921404698074247168",
        "display_url" : "twitter.com\/RetractionWatc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "921426231597428736",
    "text" : "Brian Wansink retracts a corrected version of a study that he published after retracting the first version of the study. I'm sorry, but there is a level of sloppiness at which you need to start drawing conclusions about fit you are to do your job. https:\/\/t.co\/CsD1OKrwGL",
    "id" : 921426231597428736,
    "created_at" : "2017-10-20 17:21:47 +0000",
    "user" : {
      "name" : "Dani\u00EBl Lakens",
      "screen_name" : "lakens",
      "protected" : false,
      "id_str" : "17387342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875950390952554496\/G07USELb_normal.jpg",
      "id" : 17387342,
      "verified" : true
    }
  },
  "id" : 921682009629646848,
  "created_at" : "2017-10-21 10:18:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/921667635665932290\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/XgMX3NaZqO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DMpr1F4WkAIAUqR.jpg",
      "id_str" : "921667633606463490",
      "id" : 921667633606463490,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMpr1F4WkAIAUqR.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/XgMX3NaZqO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "921667635665932290",
  "text" : "Time to disassemble the badge collection that grew a bit since moving in. https:\/\/t.co\/XgMX3NaZqO",
  "id" : 921667635665932290,
  "created_at" : "2017-10-21 09:21:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/921260518924537859\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/k9HC9Kvb8x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DMj5jtvXUAAqJ08.jpg",
      "id_str" : "921260515766259712",
      "id" : 921260515766259712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMj5jtvXUAAqJ08.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/k9HC9Kvb8x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "921260518924537859",
  "text" : "When you park next to the biological institutes. https:\/\/t.co\/k9HC9Kvb8x",
  "id" : 921260518924537859,
  "created_at" : "2017-10-20 06:23:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402575069711, 8.753366737774956 ]
  },
  "id_str" : "920786475654008832",
  "text" : "Finally \u201Chome\u201D. Now for some passing out before getting up for teaching in &lt;6 hours.",
  "id" : 920786475654008832,
  "created_at" : "2017-10-18 22:59:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/BpGFjdizvZ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BaZPlVLF26c\/",
      "display_url" : "instagram.com\/p\/BaZPlVLF26c\/"
    } ]
  },
  "geo" : { },
  "id_str" : "920673256985595904",
  "text" : "And hello \uD83C\uDDE8\uD83C\uDDED (well, and \uD83C\uDDE6\uD83C\uDDF9) https:\/\/t.co\/BpGFjdizvZ",
  "id" : 920673256985595904,
  "created_at" : "2017-10-18 15:29:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/4IqI88QPZO",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BaZLvr3FfuW\/",
      "display_url" : "instagram.com\/p\/BaZLvr3FfuW\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0027, 23.81 ]
  },
  "id_str" : "920664819744653313",
  "text" : "Goodbye \uD83C\uDDEC\uD83C\uDDF7 @ Attica https:\/\/t.co\/4IqI88QPZO",
  "id" : 920664819744653313,
  "created_at" : "2017-10-18 14:56:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06050778370169, 23.79649367185663 ]
  },
  "id_str" : "920325445832335360",
  "text" : "My phone\u2019s autocorrect tries to change my mom\u2019s name to DOI. \uD83E\uDD14",
  "id" : 920325445832335360,
  "created_at" : "2017-10-17 16:27:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    }, {
      "name" : "NHBoehm",
      "screen_name" : "NHBoehm",
      "indices" : [ 16, 24 ],
      "id_str" : "12836622",
      "id" : 12836622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "920190073748049921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06381156315156, 23.79970470397894 ]
  },
  "id_str" : "920218347018555392",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor @NHBoehm Leider nein. :(",
  "id" : 920218347018555392,
  "in_reply_to_status_id" : 920190073748049921,
  "created_at" : "2017-10-17 09:22:05 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 0, 10 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Whitaker Lab",
      "screen_name" : "Whitaker_Lab",
      "indices" : [ 11, 24 ],
      "id_str" : "816578659603648512",
      "id" : 816578659603648512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "920193010478043136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06379975199008, 23.79965493201296 ]
  },
  "id_str" : "920194792163856390",
  "in_reply_to_user_id" : 37989702,
  "text" : "@kirstie_j @Whitaker_Lab You\u2019re too kind! \uD83D\uDE0D",
  "id" : 920194792163856390,
  "in_reply_to_status_id" : 920193010478043136,
  "created_at" : "2017-10-17 07:48:29 +0000",
  "in_reply_to_screen_name" : "kirstie_j",
  "in_reply_to_user_id_str" : "37989702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 8, 22 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919816098790477829",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0638066017666, 23.79962882115694 ]
  },
  "id_str" : "919834840102588416",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @BioMickWatson Ask for a guest role in one of the next episodes to present the refutation. \uD83D\uDE02",
  "id" : 919834840102588416,
  "in_reply_to_status_id" : 919816098790477829,
  "created_at" : "2017-10-16 07:58:10 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/s5xoU495X2",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BaR2G51lDc4\/",
      "display_url" : "instagram.com\/p\/BaR2G51lDc4\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.030599603311, 23.793481332214 ]
  },
  "id_str" : "919632077284433921",
  "text" : "\uD83C\uDFEE @ \u03A0\u03B5\u03C5\u03BA\u03B7 https:\/\/t.co\/s5xoU495X2",
  "id" : 919632077284433921,
  "created_at" : "2017-10-15 18:32:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.063792932107, 23.79965885245817 ]
  },
  "id_str" : "919339699424186369",
  "text" : "\uD83C\uDFC3\uD83D\uDE97\uD83D\uDEEB\uD83D\uDEEC\uD83D\uDE97\uD83D\uDE34",
  "id" : 919339699424186369,
  "created_at" : "2017-10-14 23:10:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 11, 19 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919277729417220096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45364264049394, 8.560106833395178 ]
  },
  "id_str" : "919278151481593856",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 @cbahlai \uD83D\uDC4D",
  "id" : 919278151481593856,
  "in_reply_to_status_id" : 919277729417220096,
  "created_at" : "2017-10-14 19:06:05 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919268225778700289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45357042821421, 8.559684222705316 ]
  },
  "id_str" : "919268913367736320",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai The German tests make you solve physics things: You\u2019re traveling 120 km\/h, how many meters will you need to stop your car?",
  "id" : 919268913367736320,
  "in_reply_to_status_id" : 919268225778700289,
  "created_at" : "2017-10-14 18:29:22 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919266270905798656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45369113520482, 8.559653330602274 ]
  },
  "id_str" : "919267804423041024",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai The example Q for CA seemed to be on the level of \u201Ewhen is it okay to run over old people in the street\u201C, correct A: \u201Enever\u201C",
  "id" : 919267804423041024,
  "in_reply_to_status_id" : 919266270905798656,
  "created_at" : "2017-10-14 18:24:58 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919264853583450112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45359372187482, 8.559756764799534 ]
  },
  "id_str" : "919265495601295360",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai I\u2019ll just snobbishly assume that having passed the German tests is a good predictor for the US tests. ;)",
  "id" : 919265495601295360,
  "in_reply_to_status_id" : 919264853583450112,
  "created_at" : "2017-10-14 18:15:47 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919263368007086080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45349712661754, 8.55937881237326 ]
  },
  "id_str" : "919264382466609153",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai Yep, German license. From what I\u2019ve read it doesn\u2019t make a difference for CA.",
  "id" : 919264382466609153,
  "in_reply_to_status_id" : 919263368007086080,
  "created_at" : "2017-10-14 18:11:22 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919257483071418369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45355017153744, 8.559151268077605 ]
  },
  "id_str" : "919262982672146433",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai I think CA will make me do the same! \uD83D\uDE97",
  "id" : 919262982672146433,
  "in_reply_to_status_id" : 919257483071418369,
  "created_at" : "2017-10-14 18:05:48 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 65, 74 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919236522301325312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.45271183603754, 8.561151427594018 ]
  },
  "id_str" : "919256928835993601",
  "in_reply_to_user_id" : 14286491,
  "text" : "Also found out thanks to Swarm: today it\u2019s exactly 5 years since @wilbanks and I met for the first time.",
  "id" : 919256928835993601,
  "in_reply_to_status_id" : 919236522301325312,
  "created_at" : "2017-10-14 17:41:45 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/919236522301325312\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/gk0TmQwptf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DMHIvUsX4AEFjWK.jpg",
      "id_str" : "919236514294521857",
      "id" : 919236514294521857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMHIvUsX4AEFjWK.jpg",
      "sizes" : [ {
        "h" : 294,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/gk0TmQwptf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35941162761797, 8.5880132041837 ]
  },
  "id_str" : "919236522301325312",
  "text" : "Social media made it to Witikon. https:\/\/t.co\/gk0TmQwptf",
  "id" : 919236522301325312,
  "created_at" : "2017-10-14 16:20:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\/Andreas K. Bittner",
      "screen_name" : "qwasi",
      "indices" : [ 0, 6 ],
      "id_str" : "15835452",
      "id" : 15835452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919177782697123840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35907547117001, 8.587435344106296 ]
  },
  "id_str" : "919180568130129924",
  "in_reply_to_user_id" : 15835452,
  "text" : "@qwasi Bestell Beni liebe Gr\u00FC\u00DFe von mir!",
  "id" : 919180568130129924,
  "in_reply_to_status_id" : 919177782697123840,
  "created_at" : "2017-10-14 12:38:19 +0000",
  "in_reply_to_screen_name" : "qwasi",
  "in_reply_to_user_id_str" : "15835452",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iris van Rooij",
      "screen_name" : "IrisVanRooij",
      "indices" : [ 0, 13 ],
      "id_str" : "1194617485",
      "id" : 1194617485
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 14, 22 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 23, 35 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919167768754360321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925450306929, 8.587788227264857 ]
  },
  "id_str" : "919169018417819649",
  "in_reply_to_user_id" : 1194617485,
  "text" : "@IrisVanRooij @o_guest @froggleston Thanks for advertising it! Seems to have struck a nerve :)",
  "id" : 919169018417819649,
  "in_reply_to_status_id" : 919167768754360321,
  "created_at" : "2017-10-14 11:52:25 +0000",
  "in_reply_to_screen_name" : "IrisVanRooij",
  "in_reply_to_user_id_str" : "1194617485",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 9, 21 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919143006481059840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35954209083062, 8.588340536456613 ]
  },
  "id_str" : "919151421613801473",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @froggleston \uD83D\uDE02\uD83D\uDC4D",
  "id" : 919151421613801473,
  "in_reply_to_status_id" : 919143006481059840,
  "created_at" : "2017-10-14 10:42:30 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 9, 21 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919133798641684480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35914242003095, 8.58749363255149 ]
  },
  "id_str" : "919137001076555776",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @froggleston Thanks for the offer. I\u2019ll take these people becoming so agitated as a sign that the article doesn\u2019t fully suck ;)",
  "id" : 919137001076555776,
  "in_reply_to_status_id" : 919133798641684480,
  "created_at" : "2017-10-14 09:45:12 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 13, 21 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919135500279181312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35914242003095, 8.58749363255149 ]
  },
  "id_str" : "919136729050869760",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @o_guest Sure, that should work. Can potentially time it with my PhD defense as I have to fly to Europe for that anyway :)",
  "id" : 919136729050869760,
  "in_reply_to_status_id" : 919135500279181312,
  "created_at" : "2017-10-14 09:44:07 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 13, 21 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mozfest",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919131646984585216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3594649317459, 8.588183687750307 ]
  },
  "id_str" : "919132229904879617",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @o_guest Thanks my friend! (Btw will you make it to #Mozfest this year?)",
  "id" : 919132229904879617,
  "in_reply_to_status_id" : 919131646984585216,
  "created_at" : "2017-10-14 09:26:14 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah vd Westhuizen",
      "screen_name" : "WesthuizenSarah",
      "indices" : [ 0, 16 ],
      "id_str" : "780088844993585153",
      "id" : 780088844993585153
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 17, 25 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919131600495038470",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35944945151283, 8.588162776245786 ]
  },
  "id_str" : "919132060471758848",
  "in_reply_to_user_id" : 780088844993585153,
  "text" : "@WesthuizenSarah @o_guest Thank you for the reaffirmation Sarah!",
  "id" : 919132060471758848,
  "in_reply_to_status_id" : 919131600495038470,
  "created_at" : "2017-10-14 09:25:34 +0000",
  "in_reply_to_screen_name" : "WesthuizenSarah",
  "in_reply_to_user_id_str" : "780088844993585153",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marta Teperek",
      "screen_name" : "martateperek",
      "indices" : [ 0, 13 ],
      "id_str" : "2742098774",
      "id" : 2742098774
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 14, 24 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919101712954163200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35946202627571, 8.588178095150058 ]
  },
  "id_str" : "919129976884154368",
  "in_reply_to_user_id" : 2742098774,
  "text" : "@martateperek @kirstie_j Thank you!",
  "id" : 919129976884154368,
  "in_reply_to_status_id" : 919101712954163200,
  "created_at" : "2017-10-14 09:17:17 +0000",
  "in_reply_to_screen_name" : "martateperek",
  "in_reply_to_user_id_str" : "2742098774",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "919100918100037632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933311592275, 8.587850420636451 ]
  },
  "id_str" : "919129844327370753",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest Thanks, I\u2019m fine. I know you have to endure much worse \uD83D\uDE1E and I can\u2019t even imagine what would have happened had a woman wrote that thing. \uD83D\uDE22",
  "id" : 919129844327370753,
  "in_reply_to_status_id" : 919100918100037632,
  "created_at" : "2017-10-14 09:16:46 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918967605532217347",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.11937614348542, 8.578807823367956 ]
  },
  "id_str" : "919005076349423616",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest Thank you, for being a great teacher! \uD83D\uDC96",
  "id" : 919005076349423616,
  "in_reply_to_status_id" : 918967605532217347,
  "created_at" : "2017-10-14 01:00:59 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Ainsworth \uD83D\uDD2D",
      "screen_name" : "rachaelevelyn",
      "indices" : [ 0, 14 ],
      "id_str" : "130490305",
      "id" : 130490305
    }, {
      "name" : "Digital Science",
      "screen_name" : "digitalsci",
      "indices" : [ 15, 26 ],
      "id_str" : "144972081",
      "id" : 144972081
    }, {
      "name" : "Twitter",
      "screen_name" : "Twitter",
      "indices" : [ 27, 35 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918921626921701376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402874384846, 8.753427994744769 ]
  },
  "id_str" : "918925557139738624",
  "in_reply_to_user_id" : 130490305,
  "text" : "@rachaelevelyn @digitalsci @Twitter That\u2019s a pretty good summary.",
  "id" : 918925557139738624,
  "in_reply_to_status_id" : 918921626921701376,
  "created_at" : "2017-10-13 19:45:00 +0000",
  "in_reply_to_screen_name" : "rachaelevelyn",
  "in_reply_to_user_id_str" : "130490305",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "918912481707352064",
  "text" : "RT @lorrainechu3n: White women terrify me-they are quick to talk \"diversity and inclusion\" in public, but have discounted my concerns in pr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "918910168527753216",
    "text" : "White women terrify me-they are quick to talk \"diversity and inclusion\" in public, but have discounted my concerns in private \/1",
    "id" : 918910168527753216,
    "created_at" : "2017-10-13 18:43:51 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 918912481707352064,
  "created_at" : "2017-10-13 18:53:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Science",
      "screen_name" : "digitalsci",
      "indices" : [ 0, 11 ],
      "id_str" : "144972081",
      "id" : 144972081
    }, {
      "name" : "Twitter",
      "screen_name" : "Twitter",
      "indices" : [ 12, 20 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/aMLXGRawoU",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/917789808126300161",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "918904718981779456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11264959299908, 8.755088011248034 ]
  },
  "id_str" : "918907390577250305",
  "in_reply_to_user_id" : 144972081,
  "text" : "@digitalsci @Twitter Have a look at my replies in general and to https:\/\/t.co\/aMLXGRawoU for a glimpse into the lost souls.",
  "id" : 918907390577250305,
  "in_reply_to_status_id" : 918904718981779456,
  "created_at" : "2017-10-13 18:32:49 +0000",
  "in_reply_to_screen_name" : "digitalsci",
  "in_reply_to_user_id_str" : "144972081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 3, 12 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "OpenEd17",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/L9sGYDkIqI",
      "expanded_url" : "https:\/\/sparcopen.github.io\/opencon-dei-report\/",
      "display_url" : "sparcopen.github.io\/opencon-dei-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918891789125410816",
  "text" : "RT @open_con: Check out the #OpenCon report on organizing diverse, equitable, and inclusive events https:\/\/t.co\/L9sGYDkIqI #OpenEd17",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 14, 22 ]
      }, {
        "text" : "OpenEd17",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/L9sGYDkIqI",
        "expanded_url" : "https:\/\/sparcopen.github.io\/opencon-dei-report\/",
        "display_url" : "sparcopen.github.io\/opencon-dei-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "918876120388268032",
    "text" : "Check out the #OpenCon report on organizing diverse, equitable, and inclusive events https:\/\/t.co\/L9sGYDkIqI #OpenEd17",
    "id" : 918876120388268032,
    "created_at" : "2017-10-13 16:28:33 +0000",
    "user" : {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "protected" : false,
      "id_str" : "2452073258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843937071534424064\/e-PdQw9V_normal.jpg",
      "id" : 2452073258,
      "verified" : false
    }
  },
  "id" : 918891789125410816,
  "created_at" : "2017-10-13 17:30:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "Twitter",
      "indices" : [ 118, 126 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampioningWISreport",
      "indices" : [ 14, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403856505096, 8.753367695394546 ]
  },
  "id_str" : "918888901640708097",
  "text" : "Thanks to the #ChampioningWISreport I had a good reason to report tons of people. Wanna guess how many ToS violations @twitter found?",
  "id" : 918888901640708097,
  "created_at" : "2017-10-13 17:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Valcourt",
      "screen_name" : "jrvalcourt",
      "indices" : [ 3, 14 ],
      "id_str" : "171762328",
      "id" : 171762328
    }, {
      "name" : "Vinome",
      "screen_name" : "MyVinome",
      "indices" : [ 20, 29 ],
      "id_str" : "3153380860",
      "id" : 3153380860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "918850853733269504",
  "text" : "RT @jrvalcourt: Hey @MyVinome, we tried to come up with a satirical genomics startup and accidentally reinvented your business model https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vinome",
        "screen_name" : "MyVinome",
        "indices" : [ 4, 13 ],
        "id_str" : "3153380860",
        "id" : 3153380860
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/us52rw0hSr",
        "expanded_url" : "http:\/\/jcraigvintner.com",
        "display_url" : "jcraigvintner.com"
      } ]
    },
    "geo" : { },
    "id_str" : "918671960229470213",
    "text" : "Hey @MyVinome, we tried to come up with a satirical genomics startup and accidentally reinvented your business model https:\/\/t.co\/us52rw0hSr",
    "id" : 918671960229470213,
    "created_at" : "2017-10-13 02:57:18 +0000",
    "user" : {
      "name" : "James Valcourt",
      "screen_name" : "jrvalcourt",
      "protected" : false,
      "id_str" : "171762328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/895501663179558912\/MGAaLr4Y_normal.jpg",
      "id" : 171762328,
      "verified" : false
    }
  },
  "id" : 918850853733269504,
  "created_at" : "2017-10-13 14:48:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 38, 43 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 48, 55 ],
      "id_str" : "99586343",
      "id" : 99586343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918840791627333632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237102785563, 8.627495283700256 ]
  },
  "id_str" : "918842181175136257",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman any time! and @li5a and @lu_cyP might also have further ideas on whom to get in touch with.",
  "id" : 918842181175136257,
  "in_reply_to_status_id" : 918840791627333632,
  "created_at" : "2017-10-13 14:13:41 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/m40cxRBU3z",
      "expanded_url" : "https:\/\/twitter.com\/itatiVCS\/status\/918834127486496768",
      "display_url" : "twitter.com\/itatiVCS\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723680321089, 8.627502686985007 ]
  },
  "id_str" : "918839795064999936",
  "text" : "Thread! \uD83D\uDC4D https:\/\/t.co\/m40cxRBU3z",
  "id" : 918839795064999936,
  "created_at" : "2017-10-13 14:04:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 14, 23 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 30, 37 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "Martin Ballaschk",
      "screen_name" : "ballaschk",
      "indices" : [ 38, 48 ],
      "id_str" : "29082973",
      "id" : 29082973
    }, {
      "name" : "Henning Krause",
      "screen_name" : "henningkrause",
      "indices" : [ 53, 67 ],
      "id_str" : "21507738",
      "id" : 21507738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918834207966859265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723680321089, 8.627502686985007 ]
  },
  "id_str" : "918839484413808640",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @MsPhelps maybe @ewyler @ballaschk and @henningkrause can help out with some suggestions (or are interested) too!",
  "id" : 918839484413808640,
  "in_reply_to_status_id" : 918834207966859265,
  "created_at" : "2017-10-13 14:02:58 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 54, 60 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/y3XBDWO8Ic",
      "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/918816842625380352",
      "display_url" : "twitter.com\/MozOpenLeaders\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233689946283, 8.627528906966164 ]
  },
  "id_str" : "918817315973685249",
  "text" : "Is research failing underrepresented minorities? Join @aath0 and me at #mozfest in planning some meta-research about research itself. https:\/\/t.co\/y3XBDWO8Ic",
  "id" : 918817315973685249,
  "created_at" : "2017-10-13 12:34:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/fjIBzUCyaA",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/904034322960744448",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "918813620137529345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236575014874, 8.62750682960377 ]
  },
  "id_str" : "918814756366110721",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette It\u2019s hard to set up your spam bots correctly, someone should write a tutorial. I was recently upgraded to Prof level https:\/\/t.co\/fjIBzUCyaA",
  "id" : 918814756366110721,
  "in_reply_to_status_id" : 918813620137529345,
  "created_at" : "2017-10-13 12:24:43 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit Eicker",
      "screen_name" : "eicker",
      "indices" : [ 0, 7 ],
      "id_str" : "7950992",
      "id" : 7950992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/aMLXGRawoU",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/917789808126300161",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "918805892224741376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237198845942, 8.627507687995754 ]
  },
  "id_str" : "918811626471649280",
  "in_reply_to_user_id" : 7950992,
  "text" : "@eicker The replies to this are\u2026 let\u2019s say they are mixed\u2026 ;) https:\/\/t.co\/aMLXGRawoU",
  "id" : 918811626471649280,
  "in_reply_to_status_id" : 918805892224741376,
  "created_at" : "2017-10-13 12:12:17 +0000",
  "in_reply_to_screen_name" : "eicker",
  "in_reply_to_user_id_str" : "7950992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236468174266, 8.627491064924058 ]
  },
  "id_str" : "918805643737423872",
  "text" : "Defending your antifeminist BS by telling a biologist that they can\u2019t ignore biology. \uD83D\uDC0C\uD83D\uDC4F",
  "id" : 918805643737423872,
  "created_at" : "2017-10-13 11:48:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918796922609168385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237771991442, 8.627485222789096 ]
  },
  "id_str" : "918804727235833857",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim you too my friend! \uD83D\uDE02",
  "id" : 918804727235833857,
  "in_reply_to_status_id" : 918796922609168385,
  "created_at" : "2017-10-13 11:44:52 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918731842987192322",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237166307258, 8.627487673578218 ]
  },
  "id_str" : "918802704402706432",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette Was it addressed to \u201EProfessor Domingues, A\u201C? :D",
  "id" : 918802704402706432,
  "in_reply_to_status_id" : 918731842987192322,
  "created_at" : "2017-10-13 11:36:49 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "indices" : [ 3, 14 ],
      "id_str" : "24506246",
      "id" : 24506246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/vXKsalWGPY",
      "expanded_url" : "https:\/\/www.haaretz.com\/opinion\/.premium-1.816944",
      "display_url" : "haaretz.com\/opinion\/.premi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918781968342450177",
  "text" : "RT @haaretzcom: The Hebrew Language Academy should go where its equivalents in Romance languages won't | Opinion\nhttps:\/\/t.co\/vXKsalWGPY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/vXKsalWGPY",
        "expanded_url" : "https:\/\/www.haaretz.com\/opinion\/.premium-1.816944",
        "display_url" : "haaretz.com\/opinion\/.premi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "918725492013981701",
    "text" : "The Hebrew Language Academy should go where its equivalents in Romance languages won't | Opinion\nhttps:\/\/t.co\/vXKsalWGPY",
    "id" : 918725492013981701,
    "created_at" : "2017-10-13 06:30:01 +0000",
    "user" : {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "protected" : false,
      "id_str" : "24506246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669523420774858753\/Q3O8r8FJ_normal.png",
      "id" : 24506246,
      "verified" : true
    }
  },
  "id" : 918781968342450177,
  "created_at" : "2017-10-13 10:14:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/918764952260874240\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/KvKUoQH2wl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DMAb2ZXX0AA4HrM.jpg",
      "id_str" : "918764945319383040",
      "id" : 918764945319383040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DMAb2ZXX0AA4HrM.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/KvKUoQH2wl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918762001689731072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239382834414, 8.62738923797657 ]
  },
  "id_str" : "918764952260874240",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim That sounds familiar. \uD83D\uDE02 https:\/\/t.co\/KvKUoQH2wl",
  "id" : 918764952260874240,
  "in_reply_to_status_id" : 918762001689731072,
  "created_at" : "2017-10-13 09:06:49 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918761665554010112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231621747521, 8.627529554076677 ]
  },
  "id_str" : "918761758839459840",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim around 6h a night of sleep? :)",
  "id" : 918761758839459840,
  "in_reply_to_status_id" : 918761665554010112,
  "created_at" : "2017-10-13 08:54:07 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "indices" : [ 0, 15 ],
      "id_str" : "1639877449",
      "id" : 1639877449
    }, {
      "name" : "Juan Pablo Alperin",
      "screen_name" : "juancommander",
      "indices" : [ 16, 30 ],
      "id_str" : "388503174",
      "id" : 388503174
    }, {
      "name" : "Juan Pablo Alperin",
      "screen_name" : "juancommander",
      "indices" : [ 80, 94 ],
      "id_str" : "388503174",
      "id" : 388503174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918636006672285696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231621747521, 8.627529554076677 ]
  },
  "id_str" : "918761669853052928",
  "in_reply_to_user_id" : 1639877449,
  "text" : "@AsuraEnkhbayar @juancommander Oh, I totally missed that you moved to work with @juancommander! That\u2019s awesome news, congratulations!",
  "id" : 918761669853052928,
  "in_reply_to_status_id" : 918636006672285696,
  "created_at" : "2017-10-13 08:53:46 +0000",
  "in_reply_to_screen_name" : "AsuraEnkhbayar",
  "in_reply_to_user_id_str" : "1639877449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918761121808609280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231621747521, 8.627529554076677 ]
  },
  "id_str" : "918761388146855936",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim yeah, I made a mental note on that! Did you start your data collection? :D",
  "id" : 918761388146855936,
  "in_reply_to_status_id" : 918761121808609280,
  "created_at" : "2017-10-13 08:52:39 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Pablo Alperin",
      "screen_name" : "juancommander",
      "indices" : [ 0, 14 ],
      "id_str" : "388503174",
      "id" : 388503174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918621964020756480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403974022308, 8.753367084187264 ]
  },
  "id_str" : "918624543027138560",
  "in_reply_to_user_id" : 388503174,
  "text" : "@juancommander I lost a good number of those in wallets and the back pockets of notebooks. \uD83D\uDE02",
  "id" : 918624543027138560,
  "in_reply_to_status_id" : 918621964020756480,
  "created_at" : "2017-10-12 23:48:52 +0000",
  "in_reply_to_screen_name" : "juancommander",
  "in_reply_to_user_id_str" : "388503174",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 3, 11 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "PeerJ Preprints",
      "screen_name" : "PeerJPreprints",
      "indices" : [ 72, 87 ],
      "id_str" : "1324542439",
      "id" : 1324542439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "918611567809302528",
  "text" : "RT @dhimmel: Version 2 of our Sci-Hub Coverage Study published today in @PeerJPreprints with major updates. See changelog below! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PeerJ Preprints",
        "screen_name" : "PeerJPreprints",
        "indices" : [ 59, 74 ],
        "id_str" : "1324542439",
        "id" : 1324542439
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dhimmel\/status\/918608558400393217\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/weGnoNIxg3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DL-NVf4XcAUFFV1.jpg",
        "id_str" : "918608249481555973",
        "id" : 918608249481555973,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DL-NVf4XcAUFFV1.jpg",
        "sizes" : [ {
          "h" : 470,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 694
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 694
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 694
        } ],
        "display_url" : "pic.twitter.com\/weGnoNIxg3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/PL7MbheQCW",
        "expanded_url" : "https:\/\/doi.org\/10.7287\/peerj.preprints.3100v2",
        "display_url" : "doi.org\/10.7287\/peerj.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "918608558400393217",
    "text" : "Version 2 of our Sci-Hub Coverage Study published today in @PeerJPreprints with major updates. See changelog below! https:\/\/t.co\/PL7MbheQCW https:\/\/t.co\/weGnoNIxg3",
    "id" : 918608558400393217,
    "created_at" : "2017-10-12 22:45:21 +0000",
    "user" : {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "protected" : false,
      "id_str" : "289107682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761279291053240320\/0xmzeIsg_normal.jpg",
      "id" : 289107682,
      "verified" : false
    }
  },
  "id" : 918611567809302528,
  "created_at" : "2017-10-12 22:57:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/918601135782596609\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/KEKcSuxeWk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DL-G3LVXcAUIvES.jpg",
      "id_str" : "918601131500204037",
      "id" : 918601131500204037,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DL-G3LVXcAUIvES.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/KEKcSuxeWk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "918601135782596609",
  "text" : "It seems no matter which drawer I open, i find one of these. But of course I never have one when I need it. https:\/\/t.co\/KEKcSuxeWk",
  "id" : 918601135782596609,
  "created_at" : "2017-10-12 22:15:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 25, 33 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/918597733824516097\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/ZnfWuuCcVD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DL-Dvk2WAAAkuCb.jpg",
      "id_str" : "918597702375571456",
      "id" : 918597702375571456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DL-Dvk2WAAAkuCb.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/ZnfWuuCcVD"
    } ],
    "hashtags" : [ {
      "text" : "ICG10",
      "indices" : [ 44, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401085779821, 8.753317132961516 ]
  },
  "id_str" : "918597733824516097",
  "text" : "While cleaning up: Found @glyn_dk and me at #ICG10 back when. \uD83D\uDE0A https:\/\/t.co\/ZnfWuuCcVD",
  "id" : 918597733824516097,
  "created_at" : "2017-10-12 22:02:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/Hna39YusV7",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/918588242278207488",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918588726904836096",
  "text" : "And because I have excellent impulse control I totally didn\u2019t just spend 5 hours to turn all matter in the universe into paperclips. https:\/\/t.co\/Hna39YusV7",
  "id" : 918588726904836096,
  "created_at" : "2017-10-12 21:26:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/918588242278207488\/photo\/1",
      "indices" : [ 145, 168 ],
      "url" : "https:\/\/t.co\/5vHrw7ifUh",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DL97IeWWsAA_XKa.jpg",
      "id_str" : "918588234522865664",
      "id" : 918588234522865664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DL97IeWWsAA_XKa.jpg",
      "sizes" : [ {
        "h" : 266,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/5vHrw7ifUh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "918588242278207488",
  "text" : "18 days to \uD83C\uDDEA\uD83C\uDDFA\u2708\uFE0F\uD83C\uDDFA\uD83C\uDDF8. Need to travel to Oxford\/Basel\/London; prepare\/prepare 2 talks &amp; 4 workshops; and disassemble my life here before that. \uD83D\uDE31 https:\/\/t.co\/5vHrw7ifUh",
  "id" : 918588242278207488,
  "created_at" : "2017-10-12 21:24:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 0, 8 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 9, 23 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 24, 36 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 52, 62 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 63, 76 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "oaDOI",
      "screen_name" : "oaDOI_org",
      "indices" : [ 77, 87 ],
      "id_str" : "788193738891759616",
      "id" : 788193738891759616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918492755726360577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235891734811, 8.627516908096581 ]
  },
  "id_str" : "918493817476698114",
  "in_reply_to_user_id" : 289107682,
  "text" : "@dhimmel @natalianorori @chartgerink @Protohedgehog @blahah404 @Mcarthur_Joe @oaDOI_org (downloaded \uD83D\uDE09 \u2013 though i assume for Nature that\u2019s \u00B1 the same). Or focus on newer DOI which are more poorly covered by the hub.",
  "id" : 918493817476698114,
  "in_reply_to_status_id" : 918492755726360577,
  "created_at" : "2017-10-12 15:09:25 +0000",
  "in_reply_to_screen_name" : "dhimmel",
  "in_reply_to_user_id_str" : "289107682",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 0, 14 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 15, 27 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 28, 42 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 43, 53 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 54, 67 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 77, 85 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "oaDOI",
      "screen_name" : "oaDOI_org",
      "indices" : [ 148, 158 ],
      "id_str" : "788193738891759616",
      "id" : 788193738891759616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918485495864348672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235365079351, 8.62752054621531 ]
  },
  "id_str" : "918485964288352256",
  "in_reply_to_user_id" : 258025439,
  "text" : "@natalianorori @chartgerink @Protohedgehog @blahah404 @Mcarthur_Joe I\u2019m sure @dhimmel and I would be more than happy to do the cross-referencing if @oaDOI_org provides us w\/ their CSVs \uD83D\uDE07",
  "id" : 918485964288352256,
  "in_reply_to_status_id" : 918485495864348672,
  "created_at" : "2017-10-12 14:38:13 +0000",
  "in_reply_to_screen_name" : "natalianorori",
  "in_reply_to_user_id_str" : "258025439",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 0, 14 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 15, 27 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 28, 42 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 43, 53 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 72, 80 ],
      "id_str" : "289107682",
      "id" : 289107682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918484535054041088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723565971591, 8.627499719155411 ]
  },
  "id_str" : "918485157774061569",
  "in_reply_to_user_id" : 258025439,
  "text" : "@natalianorori @chartgerink @Protohedgehog @blahah404 see the link that @dhimmel posted for the list of articles of 2017-2013. Still need cross-referencing w\/ oaDOI though to find OA status.",
  "id" : 918485157774061569,
  "in_reply_to_status_id" : 918484535054041088,
  "created_at" : "2017-10-12 14:35:00 +0000",
  "in_reply_to_screen_name" : "natalianorori",
  "in_reply_to_user_id_str" : "258025439",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 0, 8 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 9, 21 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 37, 51 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 52, 62 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918483956055662592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234180216628, 8.627523536242215 ]
  },
  "id_str" : "918484641648128000",
  "in_reply_to_user_id" : 289107682,
  "text" : "@dhimmel @chartgerink @Protohedgehog @natalianorori @blahah404 running them all through the oaAPI would take ages though. Should request access to the data files for that.",
  "id" : 918484641648128000,
  "in_reply_to_status_id" : 918483956055662592,
  "created_at" : "2017-10-12 14:32:57 +0000",
  "in_reply_to_screen_name" : "dhimmel",
  "in_reply_to_user_id_str" : "289107682",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 0, 8 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 9, 21 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 37, 47 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 55, 69 ],
      "id_str" : "258025439",
      "id" : 258025439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/HcvGPl0Egd",
      "expanded_url" : "https:\/\/gist.github.com\/gedankenstuecke\/116866d713f2d9ab183ca4e70333f89f",
      "display_url" : "gist.github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "918483956055662592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234180216628, 8.627523536242215 ]
  },
  "id_str" : "918484509858942977",
  "in_reply_to_user_id" : 289107682,
  "text" : "@dhimmel @chartgerink @Protohedgehog @blahah404 Right. @natalianorori: Here\u2019s a list of just under 4,800 DOI w\/ the respective oaDOI result. https:\/\/t.co\/HcvGPl0Egd",
  "id" : 918484509858942977,
  "in_reply_to_status_id" : 918483956055662592,
  "created_at" : "2017-10-12 14:32:26 +0000",
  "in_reply_to_screen_name" : "dhimmel",
  "in_reply_to_user_id_str" : "289107682",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 0, 8 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 9, 21 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 37, 51 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 52, 62 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918471660776361987",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232358931125, 8.627525668270632 ]
  },
  "id_str" : "918472305893928960",
  "in_reply_to_user_id" : 289107682,
  "text" : "@dhimmel @chartgerink @Protohedgehog @natalianorori @blahah404 but that\u2019s not only the non-OA ones right?",
  "id" : 918472305893928960,
  "in_reply_to_status_id" : 918471660776361987,
  "created_at" : "2017-10-12 13:43:56 +0000",
  "in_reply_to_screen_name" : "dhimmel",
  "in_reply_to_user_id_str" : "289107682",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 13, 27 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 28, 42 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 43, 51 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 52, 62 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918468346240258048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236778300403, 8.627495780517211 ]
  },
  "id_str" : "918469437648523265",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @Protohedgehog @natalianorori @dhimmel @blahah404 yep, and have 234,196 Nature DOI here from my Sci-Hub analyses in any case. So should be quick run for oadoi.",
  "id" : 918469437648523265,
  "in_reply_to_status_id" : 918468346240258048,
  "created_at" : "2017-10-12 13:32:32 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 0, 14 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 15, 29 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 30, 38 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 39, 49 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 50, 62 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918468456000913408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237528626782, 8.627473628034174 ]
  },
  "id_str" : "918468524267442176",
  "in_reply_to_user_id" : 258025439,
  "text" : "@natalianorori @Protohedgehog @dhimmel @blahah404 @chartgerink k, will get back to you asap. :)",
  "id" : 918468524267442176,
  "in_reply_to_status_id" : 918468456000913408,
  "created_at" : "2017-10-12 13:28:55 +0000",
  "in_reply_to_screen_name" : "natalianorori",
  "in_reply_to_user_id_str" : "258025439",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Natalia Norori",
      "screen_name" : "natalianorori",
      "indices" : [ 15, 29 ],
      "id_str" : "258025439",
      "id" : 258025439
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 30, 38 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 39, 49 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 50, 62 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918463928681758721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230958347274, 8.627544252864004 ]
  },
  "id_str" : "918467786673938434",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @natalianorori @dhimmel @blahah404 @chartgerink the journal or the publisher? (can quickly get one)",
  "id" : 918467786673938434,
  "in_reply_to_status_id" : 918463928681758721,
  "created_at" : "2017-10-12 13:25:59 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Molls",
      "screen_name" : "emma_molls",
      "indices" : [ 3, 14 ],
      "id_str" : "520952916",
      "id" : 520952916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/SJfi8uOIZS",
      "expanded_url" : "https:\/\/scholarlykitchen.sspnet.org\/2017\/10\/11\/defining-moment-mean-say-diversity\/",
      "display_url" : "scholarlykitchen.sspnet.org\/2017\/10\/11\/def\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "918247016001626114",
  "text" : "RT @emma_molls: Almost puked on my keyboard https:\/\/t.co\/SJfi8uOIZS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/SJfi8uOIZS",
        "expanded_url" : "https:\/\/scholarlykitchen.sspnet.org\/2017\/10\/11\/defining-moment-mean-say-diversity\/",
        "display_url" : "scholarlykitchen.sspnet.org\/2017\/10\/11\/def\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "918227180869603328",
    "text" : "Almost puked on my keyboard https:\/\/t.co\/SJfi8uOIZS",
    "id" : 918227180869603328,
    "created_at" : "2017-10-11 21:29:54 +0000",
    "user" : {
      "name" : "Emma Molls",
      "screen_name" : "emma_molls",
      "protected" : false,
      "id_str" : "520952916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518155683733069824\/dbBtBpgh_normal.jpeg",
      "id" : 520952916,
      "verified" : false
    }
  },
  "id" : 918247016001626114,
  "created_at" : "2017-10-11 22:48:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 3, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/41gGVKjXbQ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BaH0klBl13M\/",
      "display_url" : "instagram.com\/p\/BaH0klBl13M\/"
    } ]
  },
  "geo" : { },
  "id_str" : "918221317123575814",
  "text" : "\uD83D\uDC2E\uD83C\uDFE1 #latergram https:\/\/t.co\/41gGVKjXbQ",
  "id" : 918221317123575814,
  "created_at" : "2017-10-11 21:06:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karsten Borgwardt",
      "screen_name" : "kmborgwardt",
      "indices" : [ 3, 15 ],
      "id_str" : "1545546103",
      "id" : 1545546103
    }, {
      "name" : "Dominik Grimm",
      "screen_name" : "dg_grimm",
      "indices" : [ 88, 97 ],
      "id_str" : "2869039537",
      "id" : 2869039537
    }, {
      "name" : "Weigel Lab",
      "screen_name" : "PlantEvolution",
      "indices" : [ 98, 113 ],
      "id_str" : "100068931",
      "id" : 100068931
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 114, 130 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/IWfZ0yE8Eh",
      "expanded_url" : "http:\/\/easyGWAS.org",
      "display_url" : "easyGWAS.org"
    } ]
  },
  "geo" : { },
  "id_str" : "918088657134936064",
  "text" : "RT @kmborgwardt: Celebrating &gt;1000 registered users of https:\/\/t.co\/IWfZ0yE8Eh! with @dg_grimm @PlantEvolution @gedankenstuecke @OliverSteg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dominik Grimm",
        "screen_name" : "dg_grimm",
        "indices" : [ 71, 80 ],
        "id_str" : "2869039537",
        "id" : 2869039537
      }, {
        "name" : "Weigel Lab",
        "screen_name" : "PlantEvolution",
        "indices" : [ 81, 96 ],
        "id_str" : "100068931",
        "id" : 100068931
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 97, 113 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Oliver Stegle",
        "screen_name" : "OliverStegle",
        "indices" : [ 114, 127 ],
        "id_str" : "105075809",
        "id" : 105075809
      }, {
        "name" : "Christoph Lippert",
        "screen_name" : "LippertChr",
        "indices" : [ 128, 139 ],
        "id_str" : "2240268936",
        "id" : 2240268936
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/IWfZ0yE8Eh",
        "expanded_url" : "http:\/\/easyGWAS.org",
        "display_url" : "easyGWAS.org"
      }, {
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/pdR6THFByQ",
        "expanded_url" : "https:\/\/twitter.com\/easygwas\/status\/917995942950957056",
        "display_url" : "twitter.com\/easygwas\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "918086042418319360",
    "text" : "Celebrating &gt;1000 registered users of https:\/\/t.co\/IWfZ0yE8Eh! with @dg_grimm @PlantEvolution @gedankenstuecke @OliverStegle @LippertChr https:\/\/t.co\/pdR6THFByQ",
    "id" : 918086042418319360,
    "created_at" : "2017-10-11 12:09:04 +0000",
    "user" : {
      "name" : "Karsten Borgwardt",
      "screen_name" : "kmborgwardt",
      "protected" : false,
      "id_str" : "1545546103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849569935948992512\/XmRJsjb3_normal.jpg",
      "id" : 1545546103,
      "verified" : false
    }
  },
  "id" : 918088657134936064,
  "created_at" : "2017-10-11 12:19:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 135, 141 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampioningWISreport",
      "indices" : [ 103, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "918048137423540224",
  "text" : "RT @gedankenstuecke: \u201EHow Men Can Help Women in STEM: Shut Up,Sit Back &amp; Listen\u201C my contrib to the #ChampioningWISreport is now in @sciam h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scientific American",
        "screen_name" : "sciam",
        "indices" : [ 114, 120 ],
        "id_str" : "14647570",
        "id" : 14647570
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChampioningWISreport",
        "indices" : [ 82, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/rm7yT8GQwC",
        "expanded_url" : "https:\/\/blogs.scientificamerican.com\/voices\/how-men-can-help-women-in-stem-shut-up-sit-back-and-listen\/",
        "display_url" : "blogs.scientificamerican.com\/voices\/how-men\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.17235000927356, 8.627520528991907 ]
    },
    "id_str" : "917789808126300161",
    "text" : "\u201EHow Men Can Help Women in STEM: Shut Up,Sit Back &amp; Listen\u201C my contrib to the #ChampioningWISreport is now in @sciam https:\/\/t.co\/rm7yT8GQwC",
    "id" : 917789808126300161,
    "created_at" : "2017-10-10 16:31:56 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 918048137423540224,
  "created_at" : "2017-10-11 09:38:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Altenhoff",
      "screen_name" : "AdrianAltenhoff",
      "indices" : [ 0, 16 ],
      "id_str" : "945855703",
      "id" : 945855703
    }, {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 17, 27 ],
      "id_str" : "274388734",
      "id" : 274388734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "918026387113545728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230395732736, 8.62754422425284 ]
  },
  "id_str" : "918031756376399872",
  "in_reply_to_user_id" : 945855703,
  "text" : "@AdrianAltenhoff @cdessimoz will do!",
  "id" : 918031756376399872,
  "in_reply_to_status_id" : 918026387113545728,
  "created_at" : "2017-10-11 08:33:21 +0000",
  "in_reply_to_screen_name" : "AdrianAltenhoff",
  "in_reply_to_user_id_str" : "945855703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 3, 12 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917808002253639681",
  "text" : "RT @yoyehudi: \"it is important that unacceptable behaviour should be called out by everyone, not only the targets of it\" \uD83D\uDC4D\uD83D\uDC4D https:\/\/t.co\/Gc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/GcZP7rCPjn",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/917789808126300161",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "917798793390718976",
    "text" : "\"it is important that unacceptable behaviour should be called out by everyone, not only the targets of it\" \uD83D\uDC4D\uD83D\uDC4D https:\/\/t.co\/GcZP7rCPjn",
    "id" : 917798793390718976,
    "created_at" : "2017-10-10 17:07:38 +0000",
    "user" : {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "protected" : false,
      "id_str" : "1073388199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905684496288243712\/tW_i_5Qt_normal.jpg",
      "id" : 1073388199,
      "verified" : false
    }
  },
  "id" : 917808002253639681,
  "created_at" : "2017-10-10 17:44:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 114, 120 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampioningWISreport",
      "indices" : [ 82, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/rm7yT8GQwC",
      "expanded_url" : "https:\/\/blogs.scientificamerican.com\/voices\/how-men-can-help-women-in-stem-shut-up-sit-back-and-listen\/",
      "display_url" : "blogs.scientificamerican.com\/voices\/how-men\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235000927356, 8.627520528991907 ]
  },
  "id_str" : "917789808126300161",
  "text" : "\u201EHow Men Can Help Women in STEM: Shut Up,Sit Back &amp; Listen\u201C my contrib to the #ChampioningWISreport is now in @sciam https:\/\/t.co\/rm7yT8GQwC",
  "id" : 917789808126300161,
  "created_at" : "2017-10-10 16:31:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampioningWISreport",
      "indices" : [ 25, 46 ]
    }, {
      "text" : "AdaLovelaceDay",
      "indices" : [ 75, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917789083358949376",
  "text" : "RT @gedankenstuecke: The #ChampioningWISreport on Women in STEM is out for #AdaLovelaceDay. With a small contribution by me. https:\/\/t.co\/D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChampioningWISreport",
        "indices" : [ 4, 25 ]
      }, {
        "text" : "AdaLovelaceDay",
        "indices" : [ 54, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/DnM4bFPc6q",
        "expanded_url" : "https:\/\/www.digital-science.com\/blog\/news\/championing-success-women-science-technology-engineering-maths-medicine-championingwisreport\/",
        "display_url" : "digital-science.com\/blog\/news\/cham\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.17231597120688, 8.627537341749417 ]
    },
    "id_str" : "917670808495034368",
    "text" : "The #ChampioningWISreport on Women in STEM is out for #AdaLovelaceDay. With a small contribution by me. https:\/\/t.co\/DnM4bFPc6q",
    "id" : 917670808495034368,
    "created_at" : "2017-10-10 08:39:04 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 917789083358949376,
  "created_at" : "2017-10-10 16:29:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 3, 16 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/LdgC6LnQqU",
      "expanded_url" : "https:\/\/redcap.iths.org\/surveys\/?s=84NKNFYXJC&loop=2",
      "display_url" : "redcap.iths.org\/surveys\/?s=84N\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917768906462367744",
  "text" : "RT @blueyedgenes: Have you taken a direct-to-consumer genetic test? Take this UW survey to share your experience: https:\/\/t.co\/LdgC6LnQqU.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/blueyedgenes\/status\/917547176405868544\/photo\/1",
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/vkagcY2rqt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DLvH7_hVoAAcHE7.jpg",
        "id_str" : "917546782577500160",
        "id" : 917546782577500160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DLvH7_hVoAAcHE7.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 435
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 435
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 435
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 435
        } ],
        "display_url" : "pic.twitter.com\/vkagcY2rqt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/LdgC6LnQqU",
        "expanded_url" : "https:\/\/redcap.iths.org\/surveys\/?s=84NKNFYXJC&loop=2",
        "display_url" : "redcap.iths.org\/surveys\/?s=84N\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "917547176405868544",
    "text" : "Have you taken a direct-to-consumer genetic test? Take this UW survey to share your experience: https:\/\/t.co\/LdgC6LnQqU. RTs appreciated! https:\/\/t.co\/vkagcY2rqt",
    "id" : 917547176405868544,
    "created_at" : "2017-10-10 00:27:48 +0000",
    "user" : {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "protected" : false,
      "id_str" : "760870811494297600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760884999918800896\/WyAaxXFj_normal.jpg",
      "id" : 760870811494297600,
      "verified" : false
    }
  },
  "id" : 917768906462367744,
  "created_at" : "2017-10-10 15:08:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 0, 9 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "917726739492757505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235620475744, 8.627495957767545 ]
  },
  "id_str" : "917741219601625090",
  "in_reply_to_user_id" : 1073388199,
  "text" : "@yoyehudi thanks!",
  "id" : 917741219601625090,
  "in_reply_to_status_id" : 917726739492757505,
  "created_at" : "2017-10-10 13:18:52 +0000",
  "in_reply_to_screen_name" : "yoyehudi",
  "in_reply_to_user_id_str" : "1073388199",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 0, 9 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "917724606127108096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233050387473, 8.627512300168451 ]
  },
  "id_str" : "917726428665384960",
  "in_reply_to_user_id" : 1073388199,
  "text" : "@yoyehudi that\u2019s a brilliant idea, this happens to me far too often :(",
  "id" : 917726428665384960,
  "in_reply_to_status_id" : 917724606127108096,
  "created_at" : "2017-10-10 12:20:05 +0000",
  "in_reply_to_screen_name" : "yoyehudi",
  "in_reply_to_user_id_str" : "1073388199",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 50, 59 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampioningWISreport",
      "indices" : [ 84, 105 ]
    }, {
      "text" : "AdaLovelaceDay",
      "indices" : [ 106, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/bqPff2aCf4",
      "expanded_url" : "https:\/\/figshare.com\/articles\/Championing_the_Success_of_Women_in_Science_Technology_Engineering_Maths_and_Medicine\/5463502",
      "display_url" : "figshare.com\/articles\/Champ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "917670808495034368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231597120688, 8.627537341749417 ]
  },
  "id_str" : "917671067732402176",
  "in_reply_to_user_id" : 14286491,
  "text" : "You can find the full (CC BY-licensed!) report on @figshare https:\/\/t.co\/bqPff2aCf4 #ChampioningWISreport #AdaLovelaceDay",
  "id" : 917671067732402176,
  "in_reply_to_status_id" : 917670808495034368,
  "created_at" : "2017-10-10 08:40:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampioningWISreport",
      "indices" : [ 4, 25 ]
    }, {
      "text" : "AdaLovelaceDay",
      "indices" : [ 54, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/DnM4bFPc6q",
      "expanded_url" : "https:\/\/www.digital-science.com\/blog\/news\/championing-success-women-science-technology-engineering-maths-medicine-championingwisreport\/",
      "display_url" : "digital-science.com\/blog\/news\/cham\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231597120688, 8.627537341749417 ]
  },
  "id_str" : "917670808495034368",
  "text" : "The #ChampioningWISreport on Women in STEM is out for #AdaLovelaceDay. With a small contribution by me. https:\/\/t.co\/DnM4bFPc6q",
  "id" : 917670808495034368,
  "created_at" : "2017-10-10 08:39:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    }, {
      "name" : "Nature Genetics",
      "screen_name" : "NatureGenet",
      "indices" : [ 11, 23 ],
      "id_str" : "2980458689",
      "id" : 2980458689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "917612105125085184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391600973194, 8.753256847512805 ]
  },
  "id_str" : "917633894941384704",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds @NatureGenet If money is speech, then money can surely be intellectual contribution? \uD83D\uDE09",
  "id" : 917633894941384704,
  "in_reply_to_status_id" : 917612105125085184,
  "created_at" : "2017-10-10 06:12:24 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "917508183526166530",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403948949583, 8.753367361770728 ]
  },
  "id_str" : "917508606572064769",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley \uD83D\uDCAF tip!",
  "id" : 917508606572064769,
  "in_reply_to_status_id" : 917508183526166530,
  "created_at" : "2017-10-09 21:54:32 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "917507658894204931",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403852346817, 8.753366373152991 ]
  },
  "id_str" : "917507787839754240",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley Now I want a dog and a squirrel as pets \uD83D\uDE02",
  "id" : 917507787839754240,
  "in_reply_to_status_id" : 917507658894204931,
  "created_at" : "2017-10-09 21:51:17 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 5, 16 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/DP3DLBjO3R",
      "expanded_url" : "https:\/\/twitter.com\/FluffSociety\/status\/917359075662409728",
      "display_url" : "twitter.com\/FluffSociety\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403877661098, 8.75336663221544 ]
  },
  "id_str" : "917506590365843456",
  "text" : "Omg, @LouWoodley, did you see this?! https:\/\/t.co\/DP3DLBjO3R",
  "id" : 917506590365843456,
  "created_at" : "2017-10-09 21:46:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle N. Meyer",
      "screen_name" : "MichelleNMeyer",
      "indices" : [ 3, 18 ],
      "id_str" : "59518694",
      "id" : 59518694
    }, {
      "name" : "Genome Magazine",
      "screen_name" : "GenomeMag",
      "indices" : [ 23, 33 ],
      "id_str" : "2253816445",
      "id" : 2253816445
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HuntingtonsDisease",
      "indices" : [ 122, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917465164915642368",
  "text" : "RT @MichelleNMeyer: In @GenomeMag Fall issue I talk @ IRBs, biobanking &amp; solidarity &amp; living w\/reduced penetrance #HuntingtonsDisease allel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Genome Magazine",
        "screen_name" : "GenomeMag",
        "indices" : [ 3, 13 ],
        "id_str" : "2253816445",
        "id" : 2253816445
      }, {
        "name" : "Misha Angrist",
        "screen_name" : "MishaAngrist",
        "indices" : [ 134, 147 ],
        "id_str" : "116877838",
        "id" : 116877838
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MichelleNMeyer\/status\/917445659711512578\/photo\/1",
        "indices" : [ 149, 172 ],
        "url" : "https:\/\/t.co\/ZhkGsA53A4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DLtrdzsUIAElQqC.jpg",
        "id_str" : "917445108936482817",
        "id" : 917445108936482817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DLtrdzsUIAElQqC.jpg",
        "sizes" : [ {
          "h" : 1206,
          "resize" : "fit",
          "w" : 898
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 894
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 1206,
          "resize" : "fit",
          "w" : 898
        } ],
        "display_url" : "pic.twitter.com\/ZhkGsA53A4"
      } ],
      "hashtags" : [ {
        "text" : "HuntingtonsDisease",
        "indices" : [ 102, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "917445659711512578",
    "text" : "In @GenomeMag Fall issue I talk @ IRBs, biobanking &amp; solidarity &amp; living w\/reduced penetrance #HuntingtonsDisease allele. Thx @MishaAngrist! https:\/\/t.co\/ZhkGsA53A4",
    "id" : 917445659711512578,
    "created_at" : "2017-10-09 17:44:25 +0000",
    "user" : {
      "name" : "Michelle N. Meyer",
      "screen_name" : "MichelleNMeyer",
      "protected" : false,
      "id_str" : "59518694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660800998177415168\/uCbNVkPf_normal.jpg",
      "id" : 59518694,
      "verified" : false
    }
  },
  "id" : 917465164915642368,
  "created_at" : "2017-10-09 19:01:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 3, 18 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917449207254081536",
  "text" : "RT @MozOpenLeaders: Looking for a project to contribute to? Join our demo calls this week &amp; see how you can help our mentored projects!\n\nht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/a2sptK4x0x",
        "expanded_url" : "https:\/\/medium.com\/@MozOpenLeaders\/announcing-our-round-4-demos-828976f6ac78",
        "display_url" : "medium.com\/@MozOpenLeader\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "917379125542899715",
    "text" : "Looking for a project to contribute to? Join our demo calls this week &amp; see how you can help our mentored projects!\n\nhttps:\/\/t.co\/a2sptK4x0x",
    "id" : 917379125542899715,
    "created_at" : "2017-10-09 13:20:02 +0000",
    "user" : {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "protected" : false,
      "id_str" : "791070237949034496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842142191032123392\/GS5Ptjrs_normal.jpg",
      "id" : 791070237949034496,
      "verified" : false
    }
  },
  "id" : 917449207254081536,
  "created_at" : "2017-10-09 17:58:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I N T E R L I N K E D",
      "screen_name" : "Ashley_Nova_",
      "indices" : [ 3, 16 ],
      "id_str" : "226934096",
      "id" : 226934096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917433805866262528",
  "text" : "RT @Ashley_Nova_: Academics who tell you to work 50+ hours a week think your time as a PhD student is worth less than \u00A35 a hour. Think abou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "917371032645918720",
    "text" : "Academics who tell you to work 50+ hours a week think your time as a PhD student is worth less than \u00A35 a hour. Think about that.",
    "id" : 917371032645918720,
    "created_at" : "2017-10-09 12:47:52 +0000",
    "user" : {
      "name" : "I N T E R L I N K E D",
      "screen_name" : "Ashley_Nova_",
      "protected" : false,
      "id_str" : "226934096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/909729880857874433\/zVKp6Kh4_normal.jpg",
      "id" : 226934096,
      "verified" : false
    }
  },
  "id" : 917433805866262528,
  "created_at" : "2017-10-09 16:57:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "POOD",
      "screen_name" : "mckellogs",
      "indices" : [ 3, 13 ],
      "id_str" : "898512982380077056",
      "id" : 898512982380077056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917427828421021696",
  "text" : "RT @McKellogs: To my fellow grad students, to my prospective grad students, PLEASE, DO NOT buy into this. For your health, sanity, friends,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/Zub7C5kEZD",
        "expanded_url" : "https:\/\/twitter.com\/igordownunder\/status\/916749458016260097",
        "display_url" : "twitter.com\/igordownunder\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "917158274574815238",
    "text" : "To my fellow grad students, to my prospective grad students, PLEASE, DO NOT buy into this. For your health, sanity, friends, family. Don't. https:\/\/t.co\/Zub7C5kEZD",
    "id" : 917158274574815238,
    "created_at" : "2017-10-08 22:42:27 +0000",
    "user" : {
      "name" : "stephanie mckellop",
      "screen_name" : "mckelldogs",
      "protected" : false,
      "id_str" : "1011480529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927355989724196864\/SmY0aTdO_normal.jpg",
      "id" : 1011480529,
      "verified" : false
    }
  },
  "id" : 917427828421021696,
  "created_at" : "2017-10-09 16:33:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Nunn",
      "screen_name" : "EBNunn",
      "indices" : [ 3, 10 ],
      "id_str" : "332482018",
      "id" : 332482018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/5Y8XkrzYSO",
      "expanded_url" : "https:\/\/twitter.com\/EBNunn\/status\/917346057503281152",
      "display_url" : "twitter.com\/EBNunn\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917386919947972612",
  "text" : "RT @EBNunn: If people know any friendly medical researchers up for a chat about open access send them my way... https:\/\/t.co\/5Y8XkrzYSO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/5Y8XkrzYSO",
        "expanded_url" : "https:\/\/twitter.com\/EBNunn\/status\/917346057503281152",
        "display_url" : "twitter.com\/EBNunn\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "917346166773288961",
    "text" : "If people know any friendly medical researchers up for a chat about open access send them my way... https:\/\/t.co\/5Y8XkrzYSO",
    "id" : 917346166773288961,
    "created_at" : "2017-10-09 11:09:04 +0000",
    "user" : {
      "name" : "Emily Nunn",
      "screen_name" : "EBNunn",
      "protected" : false,
      "id_str" : "332482018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/873081663001042944\/OBQPARPD_normal.jpg",
      "id" : 332482018,
      "verified" : false
    }
  },
  "id" : 917386919947972612,
  "created_at" : "2017-10-09 13:51:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg 'ban Nazis' Wilson",
      "screen_name" : "gvwilson",
      "indices" : [ 3, 12 ],
      "id_str" : "21506708",
      "id" : 21506708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/Hwm8aZ5iYw",
      "expanded_url" : "https:\/\/twitter.com\/MarcosBalter\/status\/916669363721261058",
      "display_url" : "twitter.com\/MarcosBalter\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "917003629017665538",
  "text" : "RT @gvwilson: Data science https:\/\/t.co\/Hwm8aZ5iYw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/Hwm8aZ5iYw",
        "expanded_url" : "https:\/\/twitter.com\/MarcosBalter\/status\/916669363721261058",
        "display_url" : "twitter.com\/MarcosBalter\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "916985586824699904",
    "text" : "Data science https:\/\/t.co\/Hwm8aZ5iYw",
    "id" : 916985586824699904,
    "created_at" : "2017-10-08 11:16:15 +0000",
    "user" : {
      "name" : "Greg Wilson",
      "screen_name" : "gvwilson",
      "protected" : false,
      "id_str" : "21506708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929161487507185665\/wQ99bMQv_normal.jpg",
      "id" : 21506708,
      "verified" : false
    }
  },
  "id" : 917003629017665538,
  "created_at" : "2017-10-08 12:27:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/uxHYiYWtH4",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BZ-pKuFFFOB\/",
      "display_url" : "instagram.com\/p\/BZ-pKuFFFOB\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.2667, 8.58333 ]
  },
  "id_str" : "916929605998600192",
  "text" : "\uD83C\uDF44 explosion \uD83D\uDCA5 @ Horgen, Switzerland https:\/\/t.co\/uxHYiYWtH4",
  "id" : 916929605998600192,
  "created_at" : "2017-10-08 07:33:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/18jBCoMnSX",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BZ9BWHIl0uy\/",
      "display_url" : "instagram.com\/p\/BZ9BWHIl0uy\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.2667, 8.58333 ]
  },
  "id_str" : "916701297457459201",
  "text" : "Lunchtime \uD83D\uDC0C\uD83C\uDF44 @ Horgen, Switzerland https:\/\/t.co\/18jBCoMnSX",
  "id" : 916701297457459201,
  "created_at" : "2017-10-07 16:26:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/GUyvawbI0R",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BZ9Au9ilCD3\/",
      "display_url" : "instagram.com\/p\/BZ9Au9ilCD3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.0, 9.0 ]
  },
  "id_str" : "916699955166724097",
  "text" : "\uD83C\uDF44\uD83C\uDF44\uD83C\uDF44 @ Canton of Z\u00FCrich https:\/\/t.co\/GUyvawbI0R",
  "id" : 916699955166724097,
  "created_at" : "2017-10-07 16:21:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 0, 11 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916689236698337281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36753171867628, 8.545386490249028 ]
  },
  "id_str" : "916698997242454017",
  "in_reply_to_user_id" : 4657994587,
  "text" : "@Neurosarda Me too!",
  "id" : 916698997242454017,
  "in_reply_to_status_id" : 916689236698337281,
  "created_at" : "2017-10-07 16:17:27 +0000",
  "in_reply_to_screen_name" : "Neurosarda",
  "in_reply_to_user_id_str" : "4657994587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinh Tran",
      "screen_name" : "trvinh_",
      "indices" : [ 0, 8 ],
      "id_str" : "888863514491850752",
      "id" : 888863514491850752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916572219677007872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933026945711, 8.587707325363668 ]
  },
  "id_str" : "916572978132979712",
  "in_reply_to_user_id" : 888863514491850752,
  "text" : "@trvinh_ You did all of the heavy lifting though! \uD83D\uDC4D\uD83C\uDFCB\uFE0F\u200D\u2640\uFE0F",
  "id" : 916572978132979712,
  "in_reply_to_status_id" : 916572219677007872,
  "created_at" : "2017-10-07 07:56:41 +0000",
  "in_reply_to_screen_name" : "trvinh_",
  "in_reply_to_user_id_str" : "888863514491850752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinh Tran",
      "screen_name" : "trvinh_",
      "indices" : [ 5, 13 ],
      "id_str" : "888863514491850752",
      "id" : 888863514491850752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/PfGF22kvLy",
      "expanded_url" : "https:\/\/github.com\/ropensci\/taxize\/pull\/634",
      "display_url" : "github.com\/ropensci\/taxiz\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35944568954911, 8.588102833331163 ]
  },
  "id_str" : "916569912851812353",
  "text" : "\uD83C\uDF89 to @trvinh_ for his first contribution to an open source package! \uD83C\uDF7E https:\/\/t.co\/PfGF22kvLy",
  "id" : 916569912851812353,
  "created_at" : "2017-10-07 07:44:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy McIntosh",
      "screen_name" : "ar0mcintosh",
      "indices" : [ 0, 12 ],
      "id_str" : "1584137959",
      "id" : 1584137959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916409568401383424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35932901162069, 8.58770950695052 ]
  },
  "id_str" : "916423821841829888",
  "in_reply_to_user_id" : 1584137959,
  "text" : "@ar0mcintosh Thanks!",
  "id" : 916423821841829888,
  "in_reply_to_status_id" : 916409568401383424,
  "created_at" : "2017-10-06 22:04:00 +0000",
  "in_reply_to_screen_name" : "ar0mcintosh",
  "in_reply_to_user_id_str" : "1584137959",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "916407994979540992",
  "text" : "RT @gedankenstuecke: In case it\u2019s useful to anyone: I collected some lessons learned &amp; tips that helped me during my PhD writing process. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/yaO3MkZaEC",
        "expanded_url" : "http:\/\/ruleofthirds.de\/phd-survival-guide\/",
        "display_url" : "ruleofthirds.de\/phd-survival-g\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 47.35930025008694, 8.588179895277202 ]
    },
    "id_str" : "916215464480690176",
    "text" : "In case it\u2019s useful to anyone: I collected some lessons learned &amp; tips that helped me during my PhD writing process. https:\/\/t.co\/yaO3MkZaEC",
    "id" : 916215464480690176,
    "created_at" : "2017-10-06 08:16:03 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 916407994979540992,
  "created_at" : "2017-10-06 21:01:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "indices" : [ 0, 9 ],
      "id_str" : "176841064",
      "id" : 176841064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916386516355645442",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35932578379987, 8.587725161275213 ]
  },
  "id_str" : "916386684090056706",
  "in_reply_to_user_id" : 176841064,
  "text" : "@BeckPitt Awesome, let\u2019s do that! \uD83D\uDC83\uD83D\uDD7A",
  "id" : 916386684090056706,
  "in_reply_to_status_id" : 916386516355645442,
  "created_at" : "2017-10-06 19:36:25 +0000",
  "in_reply_to_screen_name" : "BeckPitt",
  "in_reply_to_user_id_str" : "176841064",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roderic Page",
      "screen_name" : "rdmpage",
      "indices" : [ 3, 11 ],
      "id_str" : "14568034",
      "id" : 14568034
    }, {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 64, 73 ],
      "id_str" : "103004948",
      "id" : 103004948
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 74, 83 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TDWG17",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/wuhrq4WbPk",
      "expanded_url" : "https:\/\/scotttalks.info\/tdwg17",
      "display_url" : "scotttalks.info\/tdwg17"
    } ]
  },
  "geo" : { },
  "id_str" : "916382023060807680",
  "text" : "RT @rdmpage: The Taxonomic and Biodiversity Software Stack in R @sckottie @rOpenSci . https:\/\/t.co\/wuhrq4WbPk #TDWG17",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "scott",
        "screen_name" : "sckottie",
        "indices" : [ 51, 60 ],
        "id_str" : "103004948",
        "id" : 103004948
      }, {
        "name" : "rOpenSci",
        "screen_name" : "rOpenSci",
        "indices" : [ 61, 70 ],
        "id_str" : "342250615",
        "id" : 342250615
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TDWG17",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/wuhrq4WbPk",
        "expanded_url" : "https:\/\/scotttalks.info\/tdwg17",
        "display_url" : "scotttalks.info\/tdwg17"
      } ]
    },
    "geo" : { },
    "id_str" : "916330721068961792",
    "text" : "The Taxonomic and Biodiversity Software Stack in R @sckottie @rOpenSci . https:\/\/t.co\/wuhrq4WbPk #TDWG17",
    "id" : 916330721068961792,
    "created_at" : "2017-10-06 15:54:03 +0000",
    "user" : {
      "name" : "Roderic Page",
      "screen_name" : "rdmpage",
      "protected" : false,
      "id_str" : "14568034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413219696738328576\/NqWGhi5W_normal.jpeg",
      "id" : 14568034,
      "verified" : false
    }
  },
  "id" : 916382023060807680,
  "created_at" : "2017-10-06 19:17:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "indices" : [ 0, 9 ],
      "id_str" : "176841064",
      "id" : 176841064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916337900018655239",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933817924003, 8.587851419105197 ]
  },
  "id_str" : "916348939258990592",
  "in_reply_to_user_id" : 176841064,
  "text" : "@BeckPitt You\u2019re there?! Will we go dancing?",
  "id" : 916348939258990592,
  "in_reply_to_status_id" : 916337900018655239,
  "created_at" : "2017-10-06 17:06:26 +0000",
  "in_reply_to_screen_name" : "BeckPitt",
  "in_reply_to_user_id_str" : "176841064",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916325191533375488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931751425028, 8.587759792903475 ]
  },
  "id_str" : "916326773595492352",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 thanks!",
  "id" : 916326773595492352,
  "in_reply_to_status_id" : 916325191533375488,
  "created_at" : "2017-10-06 15:38:22 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beck Pitt",
      "screen_name" : "BeckPitt",
      "indices" : [ 0, 9 ],
      "id_str" : "176841064",
      "id" : 176841064
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916324587612327937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931750965754, 8.58775979622966 ]
  },
  "id_str" : "916326754192642050",
  "in_reply_to_user_id" : 176841064,
  "text" : "@BeckPitt thanks, still 24 days to get rid of all my stuff here and go to #mozfest! \uD83D\uDE0D",
  "id" : 916326754192642050,
  "in_reply_to_status_id" : 916324587612327937,
  "created_at" : "2017-10-06 15:38:17 +0000",
  "in_reply_to_screen_name" : "BeckPitt",
  "in_reply_to_user_id_str" : "176841064",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931177461821, 8.58776394427562 ]
  },
  "id_str" : "916324193251352577",
  "text" : "Health Insurance \u2714\uFE0E\nOne-way flights FRA \u2708\uFE0FSFO \u2714\uFE0E",
  "id" : 916324193251352577,
  "created_at" : "2017-10-06 15:28:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 3, 11 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/PAAp9q4QRW",
      "expanded_url" : "https:\/\/twitter.com\/antiSMASH_dev\/status\/916225943655546880",
      "display_url" : "twitter.com\/antiSMASH_dev\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "916230282260484098",
  "text" : "RT @kaiblin: Pretty excited about fast mode. Find all the clusters on your bacterial genome in ~30 seconds. https:\/\/t.co\/PAAp9q4QRW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/PAAp9q4QRW",
        "expanded_url" : "https:\/\/twitter.com\/antiSMASH_dev\/status\/916225943655546880",
        "display_url" : "twitter.com\/antiSMASH_dev\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "916226141656141824",
    "text" : "Pretty excited about fast mode. Find all the clusters on your bacterial genome in ~30 seconds. https:\/\/t.co\/PAAp9q4QRW",
    "id" : 916226141656141824,
    "created_at" : "2017-10-06 08:58:29 +0000",
    "user" : {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "protected" : false,
      "id_str" : "124202458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629590097\/kai_portrait_normal.jpg",
      "id" : 124202458,
      "verified" : false
    }
  },
  "id" : 916230282260484098,
  "created_at" : "2017-10-06 09:14:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/yaO3MkZaEC",
      "expanded_url" : "http:\/\/ruleofthirds.de\/phd-survival-guide\/",
      "display_url" : "ruleofthirds.de\/phd-survival-g\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35930025008694, 8.588179895277202 ]
  },
  "id_str" : "916215464480690176",
  "text" : "In case it\u2019s useful to anyone: I collected some lessons learned &amp; tips that helped me during my PhD writing process. https:\/\/t.co\/yaO3MkZaEC",
  "id" : 916215464480690176,
  "created_at" : "2017-10-06 08:16:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Seiver",
      "screen_name" : "tweetotaler",
      "indices" : [ 0, 12 ],
      "id_str" : "29891068",
      "id" : 29891068
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 13, 27 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "BIDS",
      "screen_name" : "UCBIDS",
      "indices" : [ 28, 35 ],
      "id_str" : "2713589684",
      "id" : 2713589684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916101763555459072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35913183661687, 8.588013474408026 ]
  },
  "id_str" : "916195960690282496",
  "in_reply_to_user_id" : 29891068,
  "text" : "@tweetotaler @OpenHumansOrg @UCBIDS Thanks! Only with a small set of people. Will have to drop by after the move! And we can finally have our burgers once I arrive!",
  "id" : 916195960690282496,
  "in_reply_to_status_id" : 916101763555459072,
  "created_at" : "2017-10-06 06:58:33 +0000",
  "in_reply_to_screen_name" : "tweetotaler",
  "in_reply_to_user_id_str" : "29891068",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916075654462017537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933757004422, 8.587851082449056 ]
  },
  "id_str" : "916077370280501248",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u201CCoalition for Responsible Sharing\u201D already sounds like the Ministry of Plenty. \uD83D\uDE02",
  "id" : 916077370280501248,
  "in_reply_to_status_id" : 916075654462017537,
  "created_at" : "2017-10-05 23:07:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Eo6Z3kvdjj",
      "expanded_url" : "https:\/\/twitter.com\/Richvn\/status\/915963104743297034",
      "display_url" : "twitter.com\/Richvn\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3594205441262, 8.588092201904537 ]
  },
  "id_str" : "916075654462017537",
  "text" : "If you hate corporations this one will be for you, no matter what happens. \uD83D\uDE0E\uD83C\uDF7F\uD83C\uDF7F\uD83C\uDF7F https:\/\/t.co\/Eo6Z3kvdjj",
  "id" : 916075654462017537,
  "created_at" : "2017-10-05 23:00:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernhard Mittermaier",
      "screen_name" : "BMittermaier",
      "indices" : [ 0, 13 ],
      "id_str" : "152791124",
      "id" : 152791124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915985952849514496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.5255135084023, 8.885544659578134 ]
  },
  "id_str" : "916003973882052613",
  "in_reply_to_user_id" : 152791124,
  "text" : "@BMittermaier Titled as given in the tweet. Ran by some US company, saying their client wants to be revealed after the survey to get unbiased answers \uD83D\uDE02",
  "id" : 916003973882052613,
  "in_reply_to_status_id" : 915985952849514496,
  "created_at" : "2017-10-05 18:15:40 +0000",
  "in_reply_to_screen_name" : "BMittermaier",
  "in_reply_to_user_id_str" : "152791124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 0, 6 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/yquiCTUplw",
      "expanded_url" : "http:\/\/www.baremagazine.org\/wp-content\/uploads\/2014\/06\/tumblr_lmqz8fznPZ1qzado8o1_5003.gif",
      "display_url" : "baremagazine.org\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "915941208576405504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233605504562, 8.627525583125799 ]
  },
  "id_str" : "915941540056444928",
  "in_reply_to_user_id" : 753358633593925632,
  "text" : "@aath0 or rather https:\/\/t.co\/yquiCTUplw",
  "id" : 915941540056444928,
  "in_reply_to_status_id" : 915941208576405504,
  "created_at" : "2017-10-05 14:07:35 +0000",
  "in_reply_to_screen_name" : "aath0",
  "in_reply_to_user_id_str" : "753358633593925632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 9, 17 ],
      "id_str" : "748130881",
      "id" : 748130881
    }, {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 18, 29 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915931087297220608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234493212183, 8.627540425647915 ]
  },
  "id_str" : "915934065051799552",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @rantleb @alibi_rage ok, alles klar.",
  "id" : 915934065051799552,
  "in_reply_to_status_id" : 915931087297220608,
  "created_at" : "2017-10-05 13:37:52 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17228388216735, 8.627547926833955 ]
  },
  "id_str" : "915933746813075457",
  "text" : "Elsevier trying to remain anonymous during their \u201EScholarly Research Survey\u201C is hilarious. The first 2 Q make clear which evil is behind it.",
  "id" : 915933746813075457,
  "created_at" : "2017-10-05 13:36:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 9, 17 ],
      "id_str" : "748130881",
      "id" : 748130881
    }, {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 18, 29 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915928736960311297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232787138326, 8.62751059400672 ]
  },
  "id_str" : "915930930585460736",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @rantleb @alibi_rage wann muss sie denn reingelassen werden?",
  "id" : 915930930585460736,
  "in_reply_to_status_id" : 915928736960311297,
  "created_at" : "2017-10-05 13:25:25 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 0, 8 ],
      "id_str" : "748130881",
      "id" : 748130881
    }, {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 9, 17 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915916021223043072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237568322688, 8.627483911627591 ]
  },
  "id_str" : "915928166316855296",
  "in_reply_to_user_id" : 748130881,
  "text" : "@rantleb @ny_borg Bin auch nur bis zum 14. Zuhause.",
  "id" : 915928166316855296,
  "in_reply_to_status_id" : 915916021223043072,
  "created_at" : "2017-10-05 13:14:26 +0000",
  "in_reply_to_screen_name" : "rantleb",
  "in_reply_to_user_id_str" : "748130881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 0, 6 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915923128685080576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234619456938, 8.62752496989472 ]
  },
  "id_str" : "915926903361605634",
  "in_reply_to_user_id" : 753358633593925632,
  "text" : "@aath0 well, someone\u2019s parents made me eat so much &amp; fast that my body couldn\u2019t keep track in converting it to fat. \uD83D\uDE02",
  "id" : 915926903361605634,
  "in_reply_to_status_id" : 915923128685080576,
  "created_at" : "2017-10-05 13:09:25 +0000",
  "in_reply_to_screen_name" : "aath0",
  "in_reply_to_user_id_str" : "753358633593925632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/xMoDxQWib9",
      "expanded_url" : "https:\/\/twitter.com\/LGBTSTEM\/status\/915892473431515137",
      "display_url" : "twitter.com\/LGBTSTEM\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235703939588, 8.62751888550516 ]
  },
  "id_str" : "915908241875439616",
  "text" : "Go if you have a chance. It was a wonderful experience this year! https:\/\/t.co\/xMoDxQWib9",
  "id" : 915908241875439616,
  "created_at" : "2017-10-05 11:55:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915856273526190080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230038835114, 8.627522009419916 ]
  },
  "id_str" : "915864221744812032",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin spot on, spending a week in Athens correlates with not working, walking a lot and still gaining weight \uD83D\uDE02",
  "id" : 915864221744812032,
  "in_reply_to_status_id" : 915856273526190080,
  "created_at" : "2017-10-05 09:00:21 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 35, 44 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "915843562536886272",
  "text" : "RT @gedankenstuecke: As I promised @eramirez: I compared the activity data to the productivity data during my thesis writing. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ernesto Ramirez",
        "screen_name" : "eramirez",
        "indices" : [ 14, 23 ],
        "id_str" : "21135674",
        "id" : 21135674
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/915714159836319745\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/CB17hqRKXv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DLVFK6zW0AIbcNu.jpg",
        "id_str" : "915714153125433346",
        "id" : 915714153125433346,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DLVFK6zW0AIbcNu.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 424
        } ],
        "display_url" : "pic.twitter.com\/CB17hqRKXv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "910619529151156224",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11404318722849, 8.75336396180621 ]
    },
    "id_str" : "915714159836319745",
    "in_reply_to_user_id" : 14286491,
    "text" : "As I promised @eramirez: I compared the activity data to the productivity data during my thesis writing. https:\/\/t.co\/CB17hqRKXv",
    "id" : 915714159836319745,
    "in_reply_to_status_id" : 910619529151156224,
    "created_at" : "2017-10-04 23:04:03 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 915843562536886272,
  "created_at" : "2017-10-05 07:38:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915809309036081152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236829616157, 8.627507335152757 ]
  },
  "id_str" : "915840219634642944",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin Yes, that\u2019s the time end of July where the hours worked stay up but the step counts rise :)",
  "id" : 915840219634642944,
  "in_reply_to_status_id" : 915809309036081152,
  "created_at" : "2017-10-05 07:24:58 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farah Z Khan \uD83D\uDC53\u270F\uFE0F \uD83D\uDCD3",
      "screen_name" : "farahzk03",
      "indices" : [ 0, 10 ],
      "id_str" : "1138409204",
      "id" : 1138409204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915767191558950912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236829616157, 8.627507335152757 ]
  },
  "id_str" : "915840108191993856",
  "in_reply_to_user_id" : 1138409204,
  "text" : "@farahzk03 Thanks! :)",
  "id" : 915840108191993856,
  "in_reply_to_status_id" : 915767191558950912,
  "created_at" : "2017-10-05 07:24:31 +0000",
  "in_reply_to_screen_name" : "farahzk03",
  "in_reply_to_user_id_str" : "1138409204",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Agaricus",
      "screen_name" : "agaricus",
      "indices" : [ 10, 19 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "quantifiedself",
      "screen_name" : "quantifiedself",
      "indices" : [ 20, 35 ],
      "id_str" : "35056570",
      "id" : 35056570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915716049923842049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402016339565, 8.753336180934308 ]
  },
  "id_str" : "915717391207804928",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @agaricus @quantifiedself Thanks to both! Found another app that put all the Aria data into HealthKit, so could easily export a single file! \uD83D\uDE0D",
  "id" : 915717391207804928,
  "in_reply_to_status_id" : 915716049923842049,
  "created_at" : "2017-10-04 23:16:53 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915714751400861696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11387494918011, 8.753275870282259 ]
  },
  "id_str" : "915715831375548418",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Btw: the QS Access exporter for HealthKit is great \uD83D\uDC4D",
  "id" : 915715831375548418,
  "in_reply_to_status_id" : 915714751400861696,
  "created_at" : "2017-10-04 23:10:42 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915714751400861696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388763790029, 8.753497162841962 ]
  },
  "id_str" : "915715199797284865",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Yes, just getting back to the regular walking feels exhausting these days!",
  "id" : 915715199797284865,
  "in_reply_to_status_id" : 915714751400861696,
  "created_at" : "2017-10-04 23:08:11 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/jyIcpuxp8K",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/915714159836319745",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "915714159836319745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404318722849, 8.75336396180621 ]
  },
  "id_str" : "915714469359210497",
  "in_reply_to_user_id" : 14286491,
  "text" : "Bonus points for those who figure out where the joint weight + step increase in early July come from. \uD83D\uDE02 https:\/\/t.co\/jyIcpuxp8K",
  "id" : 915714469359210497,
  "in_reply_to_status_id" : 915714159836319745,
  "created_at" : "2017-10-04 23:05:17 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 14, 23 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/915714159836319745\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/CB17hqRKXv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DLVFK6zW0AIbcNu.jpg",
      "id_str" : "915714153125433346",
      "id" : 915714153125433346,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DLVFK6zW0AIbcNu.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 424
      } ],
      "display_url" : "pic.twitter.com\/CB17hqRKXv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "910619529151156224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404318722849, 8.75336396180621 ]
  },
  "id_str" : "915714159836319745",
  "in_reply_to_user_id" : 14286491,
  "text" : "As I promised @eramirez: I compared the activity data to the productivity data during my thesis writing. https:\/\/t.co\/CB17hqRKXv",
  "id" : 915714159836319745,
  "in_reply_to_status_id" : 910619529151156224,
  "created_at" : "2017-10-04 23:04:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/tbH2HrrrJb",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BZ1X0VNFHfO\/",
      "display_url" : "instagram.com\/p\/BZ1X0VNFHfO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "915624815326896128",
  "text" : "Time to move on \uD83C\uDF05 https:\/\/t.co\/tbH2HrrrJb",
  "id" : 915624815326896128,
  "created_at" : "2017-10-04 17:09:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 0, 5 ],
      "id_str" : "9377892",
      "id" : 9377892
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 6, 14 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Auriel Fournier",
      "screen_name" : "RallidaeRule",
      "indices" : [ 15, 28 ],
      "id_str" : "70784139",
      "id" : 70784139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915280679759486977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11377822273472, 8.753466035805598 ]
  },
  "id_str" : "915283942080696326",
  "in_reply_to_user_id" : 9377892,
  "text" : "@tpoi @mbeisen @RallidaeRule \uD83D\uDE4F I was nearly kicked out of my undergrad biology program for failing math &amp; computer science too often.",
  "id" : 915283942080696326,
  "in_reply_to_status_id" : 915280679759486977,
  "created_at" : "2017-10-03 18:34:31 +0000",
  "in_reply_to_screen_name" : "tpoi",
  "in_reply_to_user_id_str" : "9377892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 0, 9 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915227311825457152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404116840197, 8.753366975668948 ]
  },
  "id_str" : "915244007495733249",
  "in_reply_to_user_id" : 1073388199,
  "text" : "@yoyehudi I had the same thoughts! \uD83D\uDE02",
  "id" : 915244007495733249,
  "in_reply_to_status_id" : 915227311825457152,
  "created_at" : "2017-10-03 15:55:50 +0000",
  "in_reply_to_screen_name" : "yoyehudi",
  "in_reply_to_user_id_str" : "1073388199",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/IDqoASgrzZ",
      "expanded_url" : "https:\/\/twitter.com\/m_cordellier\/status\/915170215771721730",
      "display_url" : "twitter.com\/m_cordellier\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388832509243, 8.753250271738022 ]
  },
  "id_str" : "915217030026006529",
  "text" : "Thread. Read about how the thinking of some German scientists hasn\u2019t changed since the 1930s\u2026 \uD83D\uDE25 https:\/\/t.co\/IDqoASgrzZ",
  "id" : 915217030026006529,
  "created_at" : "2017-10-03 14:08:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "indices" : [ 0, 10 ],
      "id_str" : "14937469",
      "id" : 14937469
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 11, 25 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915183155845500928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393113041441, 8.753237527925734 ]
  },
  "id_str" : "915187626717696005",
  "in_reply_to_user_id" : 14937469,
  "text" : "@v_i_o_l_a @OpenHumansOrg Sehr sch\u00F6n! :)",
  "id" : 915187626717696005,
  "in_reply_to_status_id" : 915183155845500928,
  "created_at" : "2017-10-03 12:11:48 +0000",
  "in_reply_to_screen_name" : "v_i_o_l_a",
  "in_reply_to_user_id_str" : "14937469",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "indices" : [ 0, 10 ],
      "id_str" : "14937469",
      "id" : 14937469
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 11, 25 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915178561362890752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402248773716, 8.753418252658923 ]
  },
  "id_str" : "915180937838768128",
  "in_reply_to_user_id" : 14937469,
  "text" : "@v_i_o_l_a @OpenHumansOrg Ja, das muss 2010 gewesen sein! Lang lang ist\u2019s her! Habt ihr dieses Jahr wieder Pl\u00E4ne f\u00FCr die OA Woche? :)",
  "id" : 915180937838768128,
  "in_reply_to_status_id" : 915178561362890752,
  "created_at" : "2017-10-03 11:45:13 +0000",
  "in_reply_to_screen_name" : "v_i_o_l_a",
  "in_reply_to_user_id_str" : "14937469",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401880802123, 8.753412233870794 ]
  },
  "id_str" : "915176063633903616",
  "text" : "Packed what felt like a million books and 2 huge sacks of clothes. \uD83D\uDE34",
  "id" : 915176063633903616,
  "created_at" : "2017-10-03 11:25:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Yonatan Zunger)))",
      "screen_name" : "yonatanzunger",
      "indices" : [ 3, 17 ],
      "id_str" : "240569603",
      "id" : 240569603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "915130065154912256",
  "text" : "RT @yonatanzunger: I worked on policy issues at G+ and YT for years. It was *painfully* obvious that Twitter never took them seriously. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9Wq9uWOrgy",
        "expanded_url" : "https:\/\/twitter.com\/biz\/status\/914329739988541440",
        "display_url" : "twitter.com\/biz\/status\/914\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "914605545490857984",
    "text" : "I worked on policy issues at G+ and YT for years. It was *painfully* obvious that Twitter never took them seriously. https:\/\/t.co\/9Wq9uWOrgy",
    "id" : 914605545490857984,
    "created_at" : "2017-10-01 21:38:49 +0000",
    "user" : {
      "name" : "(((Yonatan Zunger)))",
      "screen_name" : "yonatanzunger",
      "protected" : false,
      "id_str" : "240569603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517547093842333697\/IGqR-Gv-_normal.jpeg",
      "id" : 240569603,
      "verified" : false
    }
  },
  "id" : 915130065154912256,
  "created_at" : "2017-10-03 08:23:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/914972227422113792\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/2uttXv2XCj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DLKiZCWXkAAFCdQ.jpg",
      "id_str" : "914972225320751104",
      "id" : 914972225320751104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DLKiZCWXkAAFCdQ.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/2uttXv2XCj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "914972227422113792",
  "text" : "I\u2019m not messing around when someone says \u2018teeth brushing party\u2019. https:\/\/t.co\/2uttXv2XCj",
  "id" : 914972227422113792,
  "created_at" : "2017-10-02 21:55:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 9, 17 ],
      "id_str" : "748130881",
      "id" : 748130881
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 18, 27 ],
      "id_str" : "819601236",
      "id" : 819601236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914850984777719808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404109317868, 8.753364242199085 ]
  },
  "id_str" : "914899646903980033",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @rantleb @Ragetina Ja, ist angekommen",
  "id" : 914899646903980033,
  "in_reply_to_status_id" : 914850984777719808,
  "created_at" : "2017-10-02 17:07:28 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914788546287939585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230516254575, 8.627541602814832 ]
  },
  "id_str" : "914788729839063040",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp there\u2019s diversity though, only two of them are called Michael.",
  "id" : 914788729839063040,
  "in_reply_to_status_id" : 914788546287939585,
  "created_at" : "2017-10-02 09:46:43 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236937439846, 8.627479832102189 ]
  },
  "id_str" : "914788208210272256",
  "text" : "This year\u2019s Nobel Prize in Medicine goes to\u2026 \u2026three more white dudes. Surprise.",
  "id" : 914788208210272256,
  "created_at" : "2017-10-02 09:44:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914597708320641024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404518949518, 8.753368764783854 ]
  },
  "id_str" : "914598610494517250",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics Hell yes! It\u2019s not like I\u2019ll need much tempting \uD83D\uDE02",
  "id" : 914598610494517250,
  "in_reply_to_status_id" : 914597708320641024,
  "created_at" : "2017-10-01 21:11:15 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914592962721583106",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405403067145, 8.753415816497782 ]
  },
  "id_str" : "914596103487619074",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics We totally need to make time to have some together again! \uD83D\uDE0D",
  "id" : 914596103487619074,
  "in_reply_to_status_id" : 914592962721583106,
  "created_at" : "2017-10-01 21:01:18 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Holdgraf",
      "screen_name" : "choldgraf",
      "indices" : [ 0, 10 ],
      "id_str" : "88273299",
      "id" : 88273299
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 11, 18 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914102151290523648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11382986084752, 8.753445462535417 ]
  },
  "id_str" : "914567288073986048",
  "in_reply_to_user_id" : 88273299,
  "text" : "@choldgraf @mrgunn Too late for the poll. I always do as I want to take responsibility for my comments. But mileage may vary (cf. all the other replies ;-))",
  "id" : 914567288073986048,
  "in_reply_to_status_id" : 914102151290523648,
  "created_at" : "2017-10-01 19:06:47 +0000",
  "in_reply_to_screen_name" : "choldgraf",
  "in_reply_to_user_id_str" : "88273299",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/b5Frc6Xgrb",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BZtxeVWFiv-\/",
      "display_url" : "instagram.com\/p\/BZtxeVWFiv-\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1081, 8.68222 ]
  },
  "id_str" : "914555337260355584",
  "text" : "Saying goodbyes \uD83C\uDF06 @ Eiserner Steg https:\/\/t.co\/b5Frc6Xgrb",
  "id" : 914555337260355584,
  "created_at" : "2017-10-01 18:19:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10813294145434, 8.663661060581893 ]
  },
  "id_str" : "914553906264408065",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics I followed your lead today and had a double dose of Dosa. You were terribly missed though!",
  "id" : 914553906264408065,
  "created_at" : "2017-10-01 18:13:37 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914510754317062145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404274195161, 8.753365421016335 ]
  },
  "id_str" : "914514219357343749",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay Meiner ging unzerschnitten in die Tonne. Hab schon genug Zeug was mit r\u00FCber muss :)",
  "id" : 914514219357343749,
  "in_reply_to_status_id" : 914510754317062145,
  "created_at" : "2017-10-01 15:35:55 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914509728004411392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11376084354026, 8.753310459752468 ]
  },
  "id_str" : "914510313197899777",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay Ich war verwundert das meiner den letzten Umzug \u00FCberlebt hat \uD83D\uDE02",
  "id" : 914510313197899777,
  "in_reply_to_status_id" : 914509728004411392,
  "created_at" : "2017-10-01 15:20:24 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914496573895213056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404112371276, 8.753363551828613 ]
  },
  "id_str" : "914504906928779265",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay Zu sp\u00E4t gekommen, zu sp\u00E4t gegangen \uD83D\uDE09",
  "id" : 914504906928779265,
  "in_reply_to_status_id" : 914496573895213056,
  "created_at" : "2017-10-01 14:58:55 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/914496430936608768\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/fWTjK5sCwE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DLDxn-CXcAEkAmg.jpg",
      "id_str" : "914496393326325761",
      "id" : 914496393326325761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DLDxn-CXcAEkAmg.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/fWTjK5sCwE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "914487133456478209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399251887564, 8.75334103308119 ]
  },
  "id_str" : "914496430936608768",
  "in_reply_to_user_id" : 14286491,
  "text" : "Some ancient history found on the bottom of the pile. \uD83D\uDE02 \uD83D\uDDD1 https:\/\/t.co\/fWTjK5sCwE",
  "id" : 914496430936608768,
  "in_reply_to_status_id" : 914487133456478209,
  "created_at" : "2017-10-01 14:25:14 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "914487133456478209",
  "text" : "Cleaning my desk for the move. The stratigraphic layers unearthed my high school diploma, a copy of my Master\u2019s thesis and bills from 2010.",
  "id" : 914487133456478209,
  "created_at" : "2017-10-01 13:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]