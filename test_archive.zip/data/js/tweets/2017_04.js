Grailbird.data.tweets_2017_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.67916625372057, -79.6115112272614 ]
  },
  "id_str" : "858789386066034689",
  "text" : "Who\u2019ll be stuck for a night ORD for a night because of a ridiculous delay? \uD83D\uDE2D",
  "id" : 858789386066034689,
  "created_at" : "2017-04-30 21:05:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scholarly Commons",
      "screen_name" : "ScholrlyCommons",
      "indices" : [ 3, 19 ],
      "id_str" : "856957674793033728",
      "id" : 856957674793033728
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 78, 94 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/d1EuFjFSVv",
      "expanded_url" : "http:\/\/scholarlycommons.org",
      "display_url" : "scholarlycommons.org"
    } ]
  },
  "geo" : { },
  "id_str" : "858728210942627840",
  "text" : "RT @ScholrlyCommons: Just launced the https:\/\/t.co\/d1EuFjFSVv website here at @creativecommons #ccsummit in Toronto. Have a look. @force11r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Creative Commons",
        "screen_name" : "creativecommons",
        "indices" : [ 57, 73 ],
        "id_str" : "17462723",
        "id" : 17462723
      }, {
        "name" : "Force11.org",
        "screen_name" : "force11rescomm",
        "indices" : [ 109, 124 ],
        "id_str" : "720754110",
        "id" : 720754110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScholrlyCommons\/status\/858720143748288513\/photo\/1",
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/Qw39qKvFep",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-rEQR3XgAAraON.jpg",
        "id_str" : "858714462920081408",
        "id" : 858714462920081408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-rEQR3XgAAraON.jpg",
        "sizes" : [ {
          "h" : 279,
          "resize" : "fit",
          "w" : 279
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 279
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 279
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 279
        } ],
        "display_url" : "pic.twitter.com\/Qw39qKvFep"
      } ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/d1EuFjFSVv",
        "expanded_url" : "http:\/\/scholarlycommons.org",
        "display_url" : "scholarlycommons.org"
      } ]
    },
    "geo" : { },
    "id_str" : "858720143748288513",
    "text" : "Just launced the https:\/\/t.co\/d1EuFjFSVv website here at @creativecommons #ccsummit in Toronto. Have a look. @force11rescomm https:\/\/t.co\/Qw39qKvFep",
    "id" : 858720143748288513,
    "created_at" : "2017-04-30 16:30:11 +0000",
    "user" : {
      "name" : "Scholarly Commons",
      "screen_name" : "ScholrlyCommons",
      "protected" : false,
      "id_str" : "856957674793033728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/857714500123992064\/MpkT3Bb9_normal.jpg",
      "id" : 856957674793033728,
      "verified" : false
    }
  },
  "id" : 858728210942627840,
  "created_at" : "2017-04-30 17:02:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 8, 17 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 18, 31 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/c5H73Vk3Q6",
      "expanded_url" : "https:\/\/twitter.com\/CCCol\/status\/858374593299574785",
      "display_url" : "twitter.com\/CCCol\/status\/8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "858724559444377603",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64292047486955, -79.38404178018573 ]
  },
  "id_str" : "858724852177547264",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg @MsPhelps @jeroenbosman https:\/\/t.co\/c5H73Vk3Q6",
  "id" : 858724852177547264,
  "in_reply_to_status_id" : 858724559444377603,
  "created_at" : "2017-04-30 16:48:53 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 5, 14 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 19, 32 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858723787021352961\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/M4xnTn3whe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-rMr7xV0AAf5rZ.jpg",
      "id_str" : "858723734118584320",
      "id" : 858723734118584320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-rMr7xV0AAf5rZ.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/M4xnTn3whe"
    } ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64290433399229, -79.38399842873828 ]
  },
  "id_str" : "858723787021352961",
  "text" : "Hear @MsPhelps and @jeroenbosman talk about the scholarly commons, live on air at #ccsummit https:\/\/t.co\/M4xnTn3whe",
  "id" : 858723787021352961,
  "created_at" : "2017-04-30 16:44:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/JnUo43jh54",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/h3ntRaMO1VVcI\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/h3ntRaMO\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "858432187301060608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64308034746946, -79.38378226945693 ]
  },
  "id_str" : "858434084795797505",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg I hear you https:\/\/t.co\/JnUo43jh54 :D",
  "id" : 858434084795797505,
  "in_reply_to_status_id" : 858432187301060608,
  "created_at" : "2017-04-29 21:33:29 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858431498650890240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64309645865661, -79.38380985827237 ]
  },
  "id_str" : "858432019537199104",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg George, not John :)",
  "id" : 858432019537199104,
  "in_reply_to_status_id" : 858431498650890240,
  "created_at" : "2017-04-29 21:25:17 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 3, 16 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 97, 106 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/858414472750301185\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/sFQ8E8IO56",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-mzZ3pVYAAL6Ku.jpg",
      "id_str" : "858414461006209024",
      "id" : 858414461006209024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-mzZ3pVYAAL6Ku.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/sFQ8E8IO56"
    } ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "858420335351394304",
  "text" : "RT @jeroenbosman: Come play open science according to your own rules #ccsummit parkdale room now @MsPhelps https:\/\/t.co\/sFQ8E8IO56",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bi\u24D0nca Kramer",
        "screen_name" : "MsPhelps",
        "indices" : [ 79, 88 ],
        "id_str" : "22963112",
        "id" : 22963112
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/858414472750301185\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/sFQ8E8IO56",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-mzZ3pVYAAL6Ku.jpg",
        "id_str" : "858414461006209024",
        "id" : 858414461006209024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-mzZ3pVYAAL6Ku.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/sFQ8E8IO56"
      } ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 51, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "858414472750301185",
    "text" : "Come play open science according to your own rules #ccsummit parkdale room now @MsPhelps https:\/\/t.co\/sFQ8E8IO56",
    "id" : 858414472750301185,
    "created_at" : "2017-04-29 20:15:33 +0000",
    "user" : {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "protected" : false,
      "id_str" : "9104202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853627325715558401\/_66XunIl_normal.jpg",
      "id" : 9104202,
      "verified" : false
    }
  },
  "id" : 858420335351394304,
  "created_at" : "2017-04-29 20:38:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsty Franks",
      "screen_name" : "kirstyrachel",
      "indices" : [ 3, 16 ],
      "id_str" : "223478876",
      "id" : 223478876
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 60, 69 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 108, 124 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "858420283908161536",
  "text" : "RT @kirstyrachel: Collaborative academic publishing game by @MsPhelps as part of the scholarly commons talk @creativecommons #ccsummit - I'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bi\u24D0nca Kramer",
        "screen_name" : "MsPhelps",
        "indices" : [ 42, 51 ],
        "id_str" : "22963112",
        "id" : 22963112
      }, {
        "name" : "Creative Commons",
        "screen_name" : "creativecommons",
        "indices" : [ 90, 106 ],
        "id_str" : "17462723",
        "id" : 17462723
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kirstyrachel\/status\/858391067254804480\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/wQywaqNeT2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-meHvJUwAAoCgY.jpg",
        "id_str" : "858391059742638080",
        "id" : 858391059742638080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-meHvJUwAAoCgY.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/wQywaqNeT2"
      } ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "858391067254804480",
    "text" : "Collaborative academic publishing game by @MsPhelps as part of the scholarly commons talk @creativecommons #ccsummit - I'm out already! https:\/\/t.co\/wQywaqNeT2",
    "id" : 858391067254804480,
    "created_at" : "2017-04-29 18:42:33 +0000",
    "user" : {
      "name" : "Kirsty Franks",
      "screen_name" : "kirstyrachel",
      "protected" : false,
      "id_str" : "223478876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541614422934831104\/jETVbzqK_normal.jpeg",
      "id" : 223478876,
      "verified" : false
    }
  },
  "id" : 858420283908161536,
  "created_at" : "2017-04-29 20:38:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 3, 15 ],
      "id_str" : "19826509",
      "id" : 19826509
    }, {
      "name" : "John McMurtrie",
      "screen_name" : "McMurtrieSF",
      "indices" : [ 127, 139 ],
      "id_str" : "140313110",
      "id" : 140313110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/OGfOsIqVaP",
      "expanded_url" : "http:\/\/bit.ly\/2qftBrK",
      "display_url" : "bit.ly\/2qftBrK"
    } ]
  },
  "geo" : { },
  "id_str" : "858411775049572352",
  "text" : "RT @openculture: The First 100 Days of Fascist Germany: A New Online Project from Emory University https:\/\/t.co\/OGfOsIqVaP via @McMurtrieSF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John McMurtrie",
        "screen_name" : "McMurtrieSF",
        "indices" : [ 110, 122 ],
        "id_str" : "140313110",
        "id" : 140313110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/openculture\/status\/858405592691466240\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/Fu9GQi9WaK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-mrU1GVYAAr8o4.jpg",
        "id_str" : "858405578330169344",
        "id" : 858405578330169344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-mrU1GVYAAr8o4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/Fu9GQi9WaK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/OGfOsIqVaP",
        "expanded_url" : "http:\/\/bit.ly\/2qftBrK",
        "display_url" : "bit.ly\/2qftBrK"
      } ]
    },
    "geo" : { },
    "id_str" : "858405592691466240",
    "text" : "The First 100 Days of Fascist Germany: A New Online Project from Emory University https:\/\/t.co\/OGfOsIqVaP via @McMurtrieSF https:\/\/t.co\/Fu9GQi9WaK",
    "id" : 858405592691466240,
    "created_at" : "2017-04-29 19:40:16 +0000",
    "user" : {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "protected" : false,
      "id_str" : "19826509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851645340830715904\/jrs1gcNM_normal.jpg",
      "id" : 19826509,
      "verified" : false
    }
  },
  "id" : 858411775049572352,
  "created_at" : "2017-04-29 20:04:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Force11.org",
      "screen_name" : "force11rescomm",
      "indices" : [ 122, 137 ],
      "id_str" : "720754110",
      "id" : 720754110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/aekGgpEAtK",
      "expanded_url" : "http:\/\/sched.co\/AF1D",
      "display_url" : "sched.co\/AF1D"
    } ]
  },
  "geo" : { },
  "id_str" : "858385754128625664",
  "text" : "RT @MsPhelps: #ccsummit Come and join us for a simulation and discussion on the scholarly commons https:\/\/t.co\/aekGgpEAtK @force11rescomm h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Force11.org",
        "screen_name" : "force11rescomm",
        "indices" : [ 108, 123 ],
        "id_str" : "720754110",
        "id" : 720754110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MsPhelps\/status\/858385473751973889\/photo\/1",
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/RY66CRRyNi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-mYxM-U0AAuKKf.jpg",
        "id_str" : "858385175054438400",
        "id" : 858385175054438400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-mYxM-U0AAuKKf.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/RY66CRRyNi"
      } ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/aekGgpEAtK",
        "expanded_url" : "http:\/\/sched.co\/AF1D",
        "display_url" : "sched.co\/AF1D"
      } ]
    },
    "geo" : { },
    "id_str" : "858385473751973889",
    "text" : "#ccsummit Come and join us for a simulation and discussion on the scholarly commons https:\/\/t.co\/aekGgpEAtK @force11rescomm https:\/\/t.co\/RY66CRRyNi",
    "id" : 858385473751973889,
    "created_at" : "2017-04-29 18:20:19 +0000",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 858385754128625664,
  "created_at" : "2017-04-29 18:21:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.642854136088, -79.38396868840732 ]
  },
  "id_str" : "858385705353052160",
  "text" : "Pleasantly surprised that fighting fascism and smashing capitalism are talked about much more than I expected at #ccsummit",
  "id" : 858385705353052160,
  "created_at" : "2017-04-29 18:21:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1928, the appellant drank a bottle of ginger-beer",
      "screen_name" : "Cyn_K",
      "indices" : [ 0, 6 ],
      "id_str" : "26436421",
      "id" : 26436421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858384257106014208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64287759650806, -79.38400579365897 ]
  },
  "id_str" : "858384625017729024",
  "in_reply_to_user_id" : 26436421,
  "text" : "@Cyn_K I literally tear up every time I hear it, so be warned before watching it. #ccsummit",
  "id" : 858384625017729024,
  "in_reply_to_status_id" : 858384257106014208,
  "created_at" : "2017-04-29 18:16:57 +0000",
  "in_reply_to_screen_name" : "Cyn_K",
  "in_reply_to_user_id_str" : "26436421",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "indices" : [ 3, 17 ],
      "id_str" : "39835900",
      "id" : 39835900
    }, {
      "name" : "women in general",
      "screen_name" : "sarahjeong",
      "indices" : [ 108, 119 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "858383458971897857",
  "text" : "RT @thatpsychprof: \u201CIt sounds like a tall order. But fighting fascism is always a tall order\u201D The brilliant @sarahjeong keynoting at the #c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "women in general",
        "screen_name" : "sarahjeong",
        "indices" : [ 89, 100 ],
        "id_str" : "47509268",
        "id" : 47509268
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "858383288125325318",
    "text" : "\u201CIt sounds like a tall order. But fighting fascism is always a tall order\u201D The brilliant @sarahjeong keynoting at the #ccsummit",
    "id" : 858383288125325318,
    "created_at" : "2017-04-29 18:11:38 +0000",
    "user" : {
      "name" : "Rajiv Jhangiani",
      "screen_name" : "thatpsychprof",
      "protected" : false,
      "id_str" : "39835900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872284509772800001\/95j6qDNs_normal.jpg",
      "id" : 39835900,
      "verified" : false
    }
  },
  "id" : 858383458971897857,
  "created_at" : "2017-04-29 18:12:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/QIubCMkVZY",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=5PI1xwT2-74",
      "display_url" : "m.youtube.com\/watch?v=5PI1xw\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64287638329411, -79.38399409770945 ]
  },
  "id_str" : "858383385575571456",
  "text" : "See the whole speech by Ursula K. Le Guin here: https:\/\/t.co\/QIubCMkVZY #ccsummit",
  "id" : 858383385575571456,
  "created_at" : "2017-04-29 18:12:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "women in general",
      "screen_name" : "sarahjeong",
      "indices" : [ 90, 101 ],
      "id_str" : "47509268",
      "id" : 47509268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "858382175225425922",
  "text" : "RT @yystvns: \"we are being eaten alive by capitalism metastitized into a social cancer\" - @sarahjeong at #ccsummit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "women in general",
        "screen_name" : "sarahjeong",
        "indices" : [ 77, 88 ],
        "id_str" : "47509268",
        "id" : 47509268
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "858381994140598272",
    "text" : "\"we are being eaten alive by capitalism metastitized into a social cancer\" - @sarahjeong at #ccsummit",
    "id" : 858381994140598272,
    "created_at" : "2017-04-29 18:06:30 +0000",
    "user" : {
      "name" : "yuan y. stevens",
      "screen_name" : "ystvns",
      "protected" : false,
      "id_str" : "2957665720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930198010428116992\/0Gt_JkDu_normal.jpg",
      "id" : 2957665720,
      "verified" : false
    }
  },
  "id" : 858382175225425922,
  "created_at" : "2017-04-29 18:07:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858379093909397506\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/HWSvyIytkg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-mTOdyXsAALbmU.jpg",
      "id_str" : "858379080714137600",
      "id" : 858379080714137600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-mTOdyXsAALbmU.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/HWSvyIytkg"
    } ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858377979004682240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64286529889175, -79.38396689813445 ]
  },
  "id_str" : "858379093909397506",
  "in_reply_to_user_id" : 14286491,
  "text" : "The Pizzagate Venn Diagram #ccsummit https:\/\/t.co\/HWSvyIytkg",
  "id" : 858379093909397506,
  "in_reply_to_status_id" : 858377979004682240,
  "created_at" : "2017-04-29 17:54:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858377979004682240\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/2uQX44V1oO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-mSNViUIAA8NiJ.jpg",
      "id_str" : "858377961807814656",
      "id" : 858377961807814656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-mSNViUIAA8NiJ.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/2uQX44V1oO"
    } ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64287808553643, -79.38402445490811 ]
  },
  "id_str" : "858377979004682240",
  "text" : "A taxonomy of internet propaganda. #ccsummit https:\/\/t.co\/2uQX44V1oO",
  "id" : 858377979004682240,
  "created_at" : "2017-04-29 17:50:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/5rxzGHKtlD",
      "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/858376524982046720",
      "display_url" : "twitter.com\/abbycabs\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64287808553643, -79.38402445490811 ]
  },
  "id_str" : "858376972271058945",
  "text" : "It\u2019s fake news all the way down. https:\/\/t.co\/5rxzGHKtlD",
  "id" : 858376972271058945,
  "created_at" : "2017-04-29 17:46:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freyja",
      "screen_name" : "vdtree",
      "indices" : [ 3, 10 ],
      "id_str" : "191009178",
      "id" : 191009178
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 74, 85 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vdtree\/status\/858334944069857282\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/auQkdjWAID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-lrFCuW0AIONHs.jpg",
      "id_str" : "858334938365612034",
      "id" : 858334938365612034,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-lrFCuW0AIONHs.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/auQkdjWAID"
    } ],
    "hashtags" : [ {
      "text" : "Diversity",
      "indices" : [ 43, 53 ]
    }, {
      "text" : "ccsummit",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "858335226812145664",
  "text" : "RT @vdtree: So good to have this aspect of #Diversity acknowledged thanks @ashedryden #ccsummit https:\/\/t.co\/auQkdjWAID",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ashe dryden",
        "screen_name" : "ashedryden",
        "indices" : [ 62, 73 ],
        "id_str" : "9510922",
        "id" : 9510922
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vdtree\/status\/858334944069857282\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/auQkdjWAID",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-lrFCuW0AIONHs.jpg",
        "id_str" : "858334938365612034",
        "id" : 858334938365612034,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-lrFCuW0AIONHs.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/auQkdjWAID"
      } ],
      "hashtags" : [ {
        "text" : "Diversity",
        "indices" : [ 31, 41 ]
      }, {
        "text" : "ccsummit",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "858334944069857282",
    "text" : "So good to have this aspect of #Diversity acknowledged thanks @ashedryden #ccsummit https:\/\/t.co\/auQkdjWAID",
    "id" : 858334944069857282,
    "created_at" : "2017-04-29 14:59:32 +0000",
    "user" : {
      "name" : "Freyja",
      "screen_name" : "vdtree",
      "protected" : false,
      "id_str" : "191009178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672386728435544064\/ba4-onQz_normal.jpg",
      "id" : 191009178,
      "verified" : false
    }
  },
  "id" : 858335226812145664,
  "created_at" : "2017-04-29 15:00:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    }, {
      "name" : "The New Inquiry",
      "screen_name" : "thenewinquiry",
      "indices" : [ 93, 107 ],
      "id_str" : "633062329",
      "id" : 633062329
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 113, 124 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "858334359438462976",
  "text" : "RT @lorrainechu3n: shout-out to the white collar crime risk zones predictive policing app by @thenewinquiry from @ashedryden #ccsummit http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New Inquiry",
        "screen_name" : "thenewinquiry",
        "indices" : [ 74, 88 ],
        "id_str" : "633062329",
        "id" : 633062329
      }, {
        "name" : "ashe dryden",
        "screen_name" : "ashedryden",
        "indices" : [ 94, 105 ],
        "id_str" : "9510922",
        "id" : 9510922
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/GDxq9laifF",
        "expanded_url" : "https:\/\/thenewinquiry.com\/white-collar-crime-risk-zones\/",
        "display_url" : "thenewinquiry.com\/white-collar-c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "858332994775515144",
    "text" : "shout-out to the white collar crime risk zones predictive policing app by @thenewinquiry from @ashedryden #ccsummit https:\/\/t.co\/GDxq9laifF",
    "id" : 858332994775515144,
    "created_at" : "2017-04-29 14:51:47 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 858334359438462976,
  "created_at" : "2017-04-29 14:57:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/UxTVDEurI7",
      "expanded_url" : "https:\/\/goo.gl\/images\/AYS6Kw",
      "display_url" : "goo.gl\/images\/AYS6Kw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64281980970588, -79.38385496103473 ]
  },
  "id_str" : "858332359585918977",
  "text" : "\u00ABLook at those shark people attacking Elon Musk.\u00BB Learning about time travel at #ccsummit https:\/\/t.co\/UxTVDEurI7",
  "id" : 858332359585918977,
  "created_at" : "2017-04-29 14:49:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858119857145040897\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/OLD2VtKj83",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-incI2XUAAdI96.jpg",
      "id_str" : "858119830867759104",
      "id" : 858119830867759104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-incI2XUAAdI96.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OLD2VtKj83"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858118757050462212",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6635464548354, -79.41881252588954 ]
  },
  "id_str" : "858119857145040897",
  "in_reply_to_user_id" : 14286491,
  "text" : "It\u2019s getting even better. https:\/\/t.co\/OLD2VtKj83",
  "id" : 858119857145040897,
  "in_reply_to_status_id" : 858118757050462212,
  "created_at" : "2017-04-29 00:44:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 11, 21 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858118757050462212\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/3hDcnzV7np",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-imaiEW0AEIUIr.jpg",
      "id_str" : "858118703765966849",
      "id" : 858118703765966849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-imaiEW0AEIUIr.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/3hDcnzV7np"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858118757050462212\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/3hDcnzV7np",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-imaS_XgAElAlr.jpg",
      "id_str" : "858118699718508545",
      "id" : 858118699718508545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-imaS_XgAElAlr.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/3hDcnzV7np"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.66334179886027, -79.4186081551755 ]
  },
  "id_str" : "858118757050462212",
  "text" : "Looks like @eltonjohn is taking me to the weirdest and funniest places. \uD83D\uDC19 https:\/\/t.co\/3hDcnzV7np",
  "id" : 858118757050462212,
  "created_at" : "2017-04-29 00:40:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sciencegurl",
      "screen_name" : "sciencegurlz0",
      "indices" : [ 0, 14 ],
      "id_str" : "274063094",
      "id" : 274063094
    }, {
      "name" : "Chris Waters",
      "screen_name" : "WatersLabMSU",
      "indices" : [ 15, 28 ],
      "id_str" : "302472463",
      "id" : 302472463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858102757680705536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.66399663504554, -79.4162076619262 ]
  },
  "id_str" : "858114401118846981",
  "in_reply_to_user_id" : 274063094,
  "text" : "@sciencegurlz0 @WatersLabMSU these are lovely!",
  "id" : 858114401118846981,
  "in_reply_to_status_id" : 858102757680705536,
  "created_at" : "2017-04-29 00:23:10 +0000",
  "in_reply_to_screen_name" : "sciencegurlz0",
  "in_reply_to_user_id_str" : "274063094",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858083643016826880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311660788677, -79.38383574352315 ]
  },
  "id_str" : "858083816149221377",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb Fits all occasions!",
  "id" : 858083816149221377,
  "in_reply_to_status_id" : 858083643016826880,
  "created_at" : "2017-04-28 22:21:38 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/858080749681082373\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/yaYZz446EC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-iD4LNWAAAGZ0Z.jpg",
      "id_str" : "858080730118750208",
      "id" : 858080730118750208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-iD4LNWAAAGZ0Z.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/yaYZz446EC"
    } ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "858066075665223680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64318379046642, -79.38411690930133 ]
  },
  "id_str" : "858080749681082373",
  "in_reply_to_user_id" : 14286491,
  "text" : "That was an easy fix. #ccsummit https:\/\/t.co\/yaYZz446EC",
  "id" : 858080749681082373,
  "in_reply_to_status_id" : 858066075665223680,
  "created_at" : "2017-04-28 22:09:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64314600088515, -79.38411992447001 ]
  },
  "id_str" : "858066075665223680",
  "text" : "Now: Bringing the Commons Back to Sharing, fighting the co-opting. #ccsummit",
  "id" : 858066075665223680,
  "created_at" : "2017-04-28 21:11:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaurav Godhwani",
      "screen_name" : "gggodhwani",
      "indices" : [ 3, 14 ],
      "id_str" : "856179222",
      "id" : 856179222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857989470251044864",
  "text" : "RT @gggodhwani: To enable new voices in community, we need to make sure people who speak loud &amp; clear to stop for a while &amp; listen: @scanno\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "scann",
        "screen_name" : "scannopolis",
        "indices" : [ 124, 136 ],
        "id_str" : "759561529",
        "id" : 759561529
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gggodhwani\/status\/857989063260987392\/photo\/1",
        "indices" : [ 148, 171 ],
        "url" : "https:\/\/t.co\/HJalNB4pFl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-gwgFPUAAA3XpQ.jpg",
        "id_str" : "857989056734429184",
        "id" : 857989056734429184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-gwgFPUAAA3XpQ.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/HJalNB4pFl"
      } ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 138, 147 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "857989063260987392",
    "text" : "To enable new voices in community, we need to make sure people who speak loud &amp; clear to stop for a while &amp; listen: @scannopolis  #ccsummit https:\/\/t.co\/HJalNB4pFl",
    "id" : 857989063260987392,
    "created_at" : "2017-04-28 16:05:08 +0000",
    "user" : {
      "name" : "Gaurav Godhwani",
      "screen_name" : "gggodhwani",
      "protected" : false,
      "id_str" : "856179222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464655310053863424\/s1LyPIAg_normal.jpeg",
      "id" : 856179222,
      "verified" : false
    }
  },
  "id" : 857989470251044864,
  "created_at" : "2017-04-28 16:06:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857988495301898240",
  "text" : "RT @lorrainechu3n: Incorporating new voices: Let's review our privileges for: being white, being men, being from rich countries -@scannopol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "scann",
        "screen_name" : "scannopolis",
        "indices" : [ 110, 122 ],
        "id_str" : "759561529",
        "id" : 759561529
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "857987960255467526",
    "text" : "Incorporating new voices: Let's review our privileges for: being white, being men, being from rich countries -@scannopolis at #ccsummit",
    "id" : 857987960255467526,
    "created_at" : "2017-04-28 16:00:45 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 857988495301898240,
  "created_at" : "2017-04-28 16:02:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Ryan Merkley",
      "screen_name" : "ryanmerkley",
      "indices" : [ 127, 139 ],
      "id_str" : "16648767",
      "id" : 16648767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857985385149890563",
  "text" : "RT @abbycabs: \"Movement building: you have to give ppl agency &amp; opportunity, but you have to let them be part of the work\" @ryanmerkley #cc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Merkley",
        "screen_name" : "ryanmerkley",
        "indices" : [ 113, 125 ],
        "id_str" : "16648767",
        "id" : 16648767
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/857985081390051330\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/NrQpQKUnbU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-gs4HtV0AAzcLN.jpg",
        "id_str" : "857985071667597312",
        "id" : 857985071667597312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-gs4HtV0AAzcLN.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/NrQpQKUnbU"
      } ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "857985081390051330",
    "text" : "\"Movement building: you have to give ppl agency &amp; opportunity, but you have to let them be part of the work\" @ryanmerkley #ccsummit https:\/\/t.co\/NrQpQKUnbU",
    "id" : 857985081390051330,
    "created_at" : "2017-04-28 15:49:18 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789110152070823938\/O_ena-j7_normal.jpg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 857985385149890563,
  "created_at" : "2017-04-28 15:50:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 39, 50 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857966063945998336\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/bDmZWvtZHI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-gblmvXoAEPuS2.jpg",
      "id_str" : "857966061882417153",
      "id" : 857966061882417153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-gblmvXoAEPuS2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/bDmZWvtZHI"
    } ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857966063945998336",
  "text" : "\u00ABEveryone is getting a coloring book!\u00BB @bella_velo #ccsummit https:\/\/t.co\/bDmZWvtZHI",
  "id" : 857966063945998336,
  "created_at" : "2017-04-28 14:33:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencircle",
      "indices" : [ 42, 53 ]
    }, {
      "text" : "openscience",
      "indices" : [ 91, 103 ]
    }, {
      "text" : "ccsummit",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64287087760079, -79.38397094845213 ]
  },
  "id_str" : "857959242262876160",
  "text" : "Just by chance I ended up next to another #opencircle participant, interested in fostering #openscience in chemistry. \uD83D\uDC96 #ccsummit",
  "id" : 857959242262876160,
  "created_at" : "2017-04-28 14:06:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857956102264291328",
  "text" : "RT @lorrainechu3n: Thank you #ccsummit for opening with an indigenous speaker!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 10, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "857954388001910794",
    "text" : "Thank you #ccsummit for opening with an indigenous speaker!!!",
    "id" : 857954388001910794,
    "created_at" : "2017-04-28 13:47:20 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 857956102264291328,
  "created_at" : "2017-04-28 13:54:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 43, 52 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 61, 70 ],
      "id_str" : "16728620",
      "id" : 16728620
    }, {
      "name" : "ahmed ogunlaja",
      "screen_name" : "mendulla",
      "indices" : [ 72, 81 ],
      "id_str" : "77655905",
      "id" : 77655905
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857947498446553089\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/NLPO4KG5dp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-gKsugXgAETwSa.jpg",
      "id_str" : "857947492528390145",
      "id" : 857947492528390145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-gKsugXgAETwSa.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/NLPO4KG5dp"
    } ],
    "hashtags" : [ {
      "text" : "opencircle",
      "indices" : [ 12, 23 ]
    }, {
      "text" : "ccsummit",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64279513966459, -79.38396622135753 ]
  },
  "id_str" : "857947498446553089",
  "text" : "Even at the #opencircle you end up next to @open_con people, @nshockey! @mendulla #ccsummit https:\/\/t.co\/NLPO4KG5dp",
  "id" : 857947498446553089,
  "created_at" : "2017-04-28 13:19:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857939997109911559\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/8l4S54gD48",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-gD3fyW0AEmeiy.jpg",
      "id_str" : "857939980974477313",
      "id" : 857939980974477313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-gD3fyW0AEmeiy.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8l4S54gD48"
    } ],
    "hashtags" : [ {
      "text" : "opencircle",
      "indices" : [ 16, 27 ]
    }, {
      "text" : "ccsummit",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64283674816669, -79.38386697200872 ]
  },
  "id_str" : "857939997109911559",
  "text" : "The drawings at #opencircle #ccsummit https:\/\/t.co\/8l4S54gD48",
  "id" : 857939997109911559,
  "created_at" : "2017-04-28 12:50:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "opencircle",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64283383335469, -79.38387004803073 ]
  },
  "id_str" : "857936784881274881",
  "text" : "Starting off the #ccsummit with a self-drawing exercise at #opencircle. \uD83C\uDFA8",
  "id" : 857936784881274881,
  "created_at" : "2017-04-28 12:37:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MU-Peter Shimon\uD83C\uDC04",
      "screen_name" : "MU_Peter",
      "indices" : [ 0, 9 ],
      "id_str" : "488929910",
      "id" : 488929910
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 10, 20 ],
      "id_str" : "111093392",
      "id" : 111093392
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 21, 35 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "paleorxiv",
      "screen_name" : "paleorxiv",
      "indices" : [ 36, 46 ],
      "id_str" : "810331766691074049",
      "id" : 810331766691074049
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 47, 60 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857921868271104001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64309386775133, -79.38378386635252 ]
  },
  "id_str" : "857922167299862533",
  "in_reply_to_user_id" : 488929910,
  "text" : "@MU_Peter @Hao_and_Y @Protohedgehog @paleorxiv @PhilippBayer Well, the left-handed DNA is certainly different :p",
  "id" : 857922167299862533,
  "in_reply_to_status_id" : 857921868271104001,
  "created_at" : "2017-04-28 11:39:18 +0000",
  "in_reply_to_screen_name" : "MU_Peter",
  "in_reply_to_user_id_str" : "488929910",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857803342776487936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64309059311345, -79.38377899480356 ]
  },
  "id_str" : "857804098128818176",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks Maybe you didn\u2019t try often enough and your experiment was just underpowered?",
  "id" : 857804098128818176,
  "in_reply_to_status_id" : 857803342776487936,
  "created_at" : "2017-04-28 03:50:08 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857802662066085888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311085284965, -79.38381439714648 ]
  },
  "id_str" : "857803069052071936",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks Easy science experiment to figure that one out: In which direction did you scare the kids more?",
  "id" : 857803069052071936,
  "in_reply_to_status_id" : 857802662066085888,
  "created_at" : "2017-04-28 03:46:03 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857777658259791873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311085284965, -79.38381439714648 ]
  },
  "id_str" : "857802443551363072",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks Wasn\u2019t the speaker supposed to speak into the wall to use the echo as an amplifier?",
  "id" : 857802443551363072,
  "in_reply_to_status_id" : 857777658259791873,
  "created_at" : "2017-04-28 03:43:34 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 0, 10 ],
      "id_str" : "111093392",
      "id" : 111093392
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "paleorxiv",
      "screen_name" : "paleorxiv",
      "indices" : [ 26, 36 ],
      "id_str" : "810331766691074049",
      "id" : 810331766691074049
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 37, 50 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857800541207842817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311085284965, -79.38381439714648 ]
  },
  "id_str" : "857802125849628672",
  "in_reply_to_user_id" : 111093392,
  "text" : "@Hao_and_Y @Protohedgehog @paleorxiv @PhilippBayer (and always love that phrase). To give you an idea of the German mindset: our equivalent idiom is literally \u201Ctwo idiots, one thought\u201D.",
  "id" : 857802125849628672,
  "in_reply_to_status_id" : 857800541207842817,
  "created_at" : "2017-04-28 03:42:18 +0000",
  "in_reply_to_screen_name" : "Hao_and_Y",
  "in_reply_to_user_id_str" : "111093392",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 0, 10 ],
      "id_str" : "111093392",
      "id" : 111093392
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "paleorxiv",
      "screen_name" : "paleorxiv",
      "indices" : [ 26, 36 ],
      "id_str" : "810331766691074049",
      "id" : 810331766691074049
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 37, 50 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857800541207842817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311038435315, -79.38380321613731 ]
  },
  "id_str" : "857800803444305920",
  "in_reply_to_user_id" : 111093392,
  "text" : "@Hao_and_Y @Protohedgehog @paleorxiv @PhilippBayer Ha, awesome! \uD83D\uDC4F\uD83C\uDFFC",
  "id" : 857800803444305920,
  "in_reply_to_status_id" : 857800541207842817,
  "created_at" : "2017-04-28 03:37:03 +0000",
  "in_reply_to_screen_name" : "Hao_and_Y",
  "in_reply_to_user_id_str" : "111093392",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "paleorxiv",
      "screen_name" : "paleorxiv",
      "indices" : [ 15, 25 ],
      "id_str" : "810331766691074049",
      "id" : 810331766691074049
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 26, 39 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857798854640492544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311757375948, -79.38379993562177 ]
  },
  "id_str" : "857800528880951296",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @paleorxiv @PhilippBayer But I\u2019m sure we can rename Spaghetti code to \u201CSaurocodomorpha\u201D for the long necks &amp; tails.",
  "id" : 857800528880951296,
  "in_reply_to_status_id" : 857798854640492544,
  "created_at" : "2017-04-28 03:35:57 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "paleorxiv",
      "screen_name" : "paleorxiv",
      "indices" : [ 15, 25 ],
      "id_str" : "810331766691074049",
      "id" : 810331766691074049
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 26, 39 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857798854640492544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311681994616, -79.38381073699504 ]
  },
  "id_str" : "857799883788627968",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @paleorxiv @PhilippBayer Also: I can\u2019t believe you didn\u2019t name the service Arxivopteryx",
  "id" : 857799883788627968,
  "in_reply_to_status_id" : 857798854640492544,
  "created_at" : "2017-04-28 03:33:24 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.63902932552256, -79.38445087537612 ]
  },
  "id_str" : "857797618252095488",
  "text" : "Random elevator encounter: \u00ABI\u2019m here for a beer conference, but I\u2019m sure #ccsummit is fun too.\u00BB \uD83D\uDE02",
  "id" : 857797618252095488,
  "created_at" : "2017-04-28 03:24:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "paleorxiv",
      "screen_name" : "paleorxiv",
      "indices" : [ 15, 25 ],
      "id_str" : "810331766691074049",
      "id" : 810331766691074049
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 63, 76 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857763950452015104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64293672614139, -79.38383515931608 ]
  },
  "id_str" : "857796870625689600",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @paleorxiv Do you accept software paleontology? @PhilippBayer and I could easily dig into our archives :D",
  "id" : 857796870625689600,
  "in_reply_to_status_id" : 857763950452015104,
  "created_at" : "2017-04-28 03:21:25 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 3, 16 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "ccglobalsummit",
      "screen_name" : "ccglobalsummit",
      "indices" : [ 69, 84 ],
      "id_str" : "850100656841138176",
      "id" : 850100656841138176
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 124, 133 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/njPFPkATLl",
      "expanded_url" : "http:\/\/sched.co\/AF1D",
      "display_url" : "sched.co\/AF1D"
    } ]
  },
  "geo" : { },
  "id_str" : "857793182519709697",
  "text" : "RT @jeroenbosman: Preparing for our session on the scholarly commons @ccglobalsummit #ccsummit https:\/\/t.co\/njPFPkATLl with @MsPhelps, @ged\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ccglobalsummit",
        "screen_name" : "ccglobalsummit",
        "indices" : [ 51, 66 ],
        "id_str" : "850100656841138176",
        "id" : 850100656841138176
      }, {
        "name" : "Bi\u24D0nca Kramer",
        "screen_name" : "MsPhelps",
        "indices" : [ 106, 115 ],
        "id_str" : "22963112",
        "id" : 22963112
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 117, 133 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/857775534834581504\/photo\/1",
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/YlnvcX6yGf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-duRGgXYAA77HZ.jpg",
        "id_str" : "857775494120562688",
        "id" : 857775494120562688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-duRGgXYAA77HZ.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YlnvcX6yGf"
      } ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 67, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/njPFPkATLl",
        "expanded_url" : "http:\/\/sched.co\/AF1D",
        "display_url" : "sched.co\/AF1D"
      } ]
    },
    "geo" : { },
    "id_str" : "857775534834581504",
    "text" : "Preparing for our session on the scholarly commons @ccglobalsummit #ccsummit https:\/\/t.co\/njPFPkATLl with @MsPhelps, @gedankenstuecke https:\/\/t.co\/YlnvcX6yGf",
    "id" : 857775534834581504,
    "created_at" : "2017-04-28 01:56:38 +0000",
    "user" : {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "protected" : false,
      "id_str" : "9104202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853627325715558401\/_66XunIl_normal.jpg",
      "id" : 9104202,
      "verified" : false
    }
  },
  "id" : 857793182519709697,
  "created_at" : "2017-04-28 03:06:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 12, 23 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 24, 34 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 35, 51 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 52, 64 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857773396729356289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.91726980855061, -79.55596106313124 ]
  },
  "id_str" : "857789217757442048",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @Neurosarda @jillemery @daniellecrobins @denormalize Oh no!",
  "id" : 857789217757442048,
  "in_reply_to_status_id" : 857773396729356289,
  "created_at" : "2017-04-28 02:51:01 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 63, 77 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 6, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/IEC6urAqxf",
      "expanded_url" : "https:\/\/twitter.com\/nshockey\/status\/857766613432639489",
      "display_url" : "twitter.com\/nshockey\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.91726980855061, -79.55596106313124 ]
  },
  "id_str" : "857775636663947264",
  "text" : "These #opencon folks, can\u2019t walk 3 steps without meeting them. @lorrainechu3n \uD83D\uDE02 https:\/\/t.co\/IEC6urAqxf",
  "id" : 857775636663947264,
  "created_at" : "2017-04-28 01:57:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857756821968134144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.9173105875732, -79.55594354232399 ]
  },
  "id_str" : "857763343750373376",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @wilbanks That\u2019s at least some good news :p",
  "id" : 857763343750373376,
  "in_reply_to_status_id" : 857756821968134144,
  "created_at" : "2017-04-28 01:08:12 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857755239256117251",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.91748772031749, -79.5560580133364 ]
  },
  "id_str" : "857763245649801216",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks So disappointing!",
  "id" : 857763245649801216,
  "in_reply_to_status_id" : 857755239256117251,
  "created_at" : "2017-04-28 01:07:48 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 0, 11 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 12, 23 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 24, 34 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 35, 51 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 52, 64 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857754679811244032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.91755548032114, -79.55610794701052 ]
  },
  "id_str" : "857763204629499905",
  "in_reply_to_user_id" : 4657994587,
  "text" : "@Neurosarda @rchampieux @jillemery @daniellecrobins @denormalize Despite my tweeting I have learned the lesson to sometimes stay quiet and listen ;)",
  "id" : 857763204629499905,
  "in_reply_to_status_id" : 857754679811244032,
  "created_at" : "2017-04-28 01:07:39 +0000",
  "in_reply_to_screen_name" : "Neurosarda",
  "in_reply_to_user_id_str" : "4657994587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 0, 11 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 12, 23 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 24, 34 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 35, 51 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 52, 64 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857753422551891968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.91748872398777, -79.55615521472016 ]
  },
  "id_str" : "857753860902932480",
  "in_reply_to_user_id" : 4657994587,
  "text" : "@Neurosarda @rchampieux @jillemery @daniellecrobins @denormalize I\u2019ll let you decide as I obviously have no expertise to make an informed decision. Just for the name I love the \uD83D\uDC36\uD83D\uDE09",
  "id" : 857753860902932480,
  "in_reply_to_status_id" : 857753422551891968,
  "created_at" : "2017-04-28 00:30:31 +0000",
  "in_reply_to_screen_name" : "Neurosarda",
  "in_reply_to_user_id_str" : "4657994587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857751306592825344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.91748355046293, -79.5561438423262 ]
  },
  "id_str" : "857751607857041408",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks your game on getting into near-misses with me is spot on. Leaving for PDX on Sunday evening.",
  "id" : 857751607857041408,
  "in_reply_to_status_id" : 857751306592825344,
  "created_at" : "2017-04-28 00:21:34 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857750366439579649\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/6S4fT3GMCa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-dXZ9gUIAESxgK.jpg",
      "id_str" : "857750357555814401",
      "id" : 857750357555814401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-dXZ9gUIAESxgK.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/6S4fT3GMCa"
    } ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.91737868005666, -79.55606039343111 ]
  },
  "id_str" : "857750366439579649",
  "text" : "Timothy Snyder on the notion of disruption (from \u2018On Tyranny\u2019). #ccsummit https:\/\/t.co\/6S4fT3GMCa",
  "id" : 857750366439579649,
  "created_at" : "2017-04-28 00:16:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857749686886817793\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/KW1pwICigE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-dWyN8UAAAuBSm.jpg",
      "id_str" : "857749674773446656",
      "id" : 857749674773446656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-dWyN8UAAAuBSm.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/KW1pwICigE"
    } ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.91739672226132, -79.5560795182747 ]
  },
  "id_str" : "857749686886817793",
  "text" : "Andreas Gr\u00FCntzig, doing the first crowdsourced operation via live streaming, 1978 in Zurich. #ccsummit https:\/\/t.co\/KW1pwICigE",
  "id" : 857749686886817793,
  "created_at" : "2017-04-28 00:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony vander Hoorn",
      "screen_name" : "anthony_vdh",
      "indices" : [ 0, 12 ],
      "id_str" : "218224040",
      "id" : 218224040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857711907276333057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64308838569072, -79.38383705061888 ]
  },
  "id_str" : "857712028978475008",
  "in_reply_to_user_id" : 218224040,
  "text" : "@anthony_vdh I went last year for the first time. It\u2019s amazing and I\u2019m looking forward to come back!",
  "id" : 857712028978475008,
  "in_reply_to_status_id" : 857711907276333057,
  "created_at" : "2017-04-27 21:44:17 +0000",
  "in_reply_to_screen_name" : "anthony_vdh",
  "in_reply_to_user_id_str" : "218224040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857704414420901889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64285112486885, -79.38390867804804 ]
  },
  "id_str" : "857707938974224385",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks That\u2019s the most expensive of the whole bunch!",
  "id" : 857707938974224385,
  "in_reply_to_status_id" : 857704414420901889,
  "created_at" : "2017-04-27 21:28:02 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony vander Hoorn",
      "screen_name" : "anthony_vdh",
      "indices" : [ 0, 12 ],
      "id_str" : "218224040",
      "id" : 218224040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857707567736213504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64285112486885, -79.38390867804804 ]
  },
  "id_str" : "857707876441350144",
  "in_reply_to_user_id" : 218224040,
  "text" : "@anthony_vdh Not yet, must have been my doppelg\u00E4nger!",
  "id" : 857707876441350144,
  "in_reply_to_status_id" : 857707567736213504,
  "created_at" : "2017-04-27 21:27:47 +0000",
  "in_reply_to_screen_name" : "anthony_vdh",
  "in_reply_to_user_id_str" : "218224040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 0, 11 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 12, 23 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 24, 34 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 35, 51 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 52, 64 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857696000588128256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64308523622238, -79.38385082016127 ]
  },
  "id_str" : "857702522827542528",
  "in_reply_to_user_id" : 4657994587,
  "text" : "@Neurosarda @rchampieux @jillemery @daniellecrobins @denormalize nah, i\u2019m totally harmless when it comes to that :)",
  "id" : 857702522827542528,
  "in_reply_to_status_id" : 857696000588128256,
  "created_at" : "2017-04-27 21:06:31 +0000",
  "in_reply_to_screen_name" : "Neurosarda",
  "in_reply_to_user_id_str" : "4657994587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857675108520951808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64309280132737, -79.38384315492208 ]
  },
  "id_str" : "857675152913563651",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman sounds good, meeting in the lobby?",
  "id" : 857675152913563651,
  "in_reply_to_status_id" : 857675108520951808,
  "created_at" : "2017-04-27 19:17:45 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857674919903211520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64309280132737, -79.38384315492208 ]
  },
  "id_str" : "857674996394713089",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman sure, when would you arrive?",
  "id" : 857674996394713089,
  "in_reply_to_status_id" : 857674919903211520,
  "created_at" : "2017-04-27 19:17:08 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/rEbP10Pad5",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/840276652814917632",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "857641108729466883",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64310541744452, -79.38382396464529 ]
  },
  "id_str" : "857671426429661185",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest the gamified approach here is also nice: https:\/\/t.co\/rEbP10Pad5",
  "id" : 857671426429661185,
  "in_reply_to_status_id" : 857641108729466883,
  "created_at" : "2017-04-27 19:02:57 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 17, 31 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857666876884885504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64309227639179, -79.38385318127031 ]
  },
  "id_str" : "857667807458340864",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @marcelsalathe only if you\u2019re participating in your coffee shops reward program.",
  "id" : 857667807458340864,
  "in_reply_to_status_id" : 857666876884885504,
  "created_at" : "2017-04-27 18:48:34 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857666047100542977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64309227639179, -79.38385318127031 ]
  },
  "id_str" : "857667543535890432",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb well deserved, Prof!",
  "id" : 857667543535890432,
  "in_reply_to_status_id" : 857666047100542977,
  "created_at" : "2017-04-27 18:47:31 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857660490444623873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64308210661823, -79.38381094208076 ]
  },
  "id_str" : "857666744684609536",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe To be fair, $1.8M buys you what, like 10 espresso in Switzerland? \uD83D\uDE1C",
  "id" : 857666744684609536,
  "in_reply_to_status_id" : 857660490444623873,
  "created_at" : "2017-04-27 18:44:21 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 0, 11 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 12, 23 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 24, 34 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 35, 51 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 52, 64 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857658485382627328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64308591320982, -79.38385167416052 ]
  },
  "id_str" : "857658572389351424",
  "in_reply_to_user_id" : 4657994587,
  "text" : "@Neurosarda @rchampieux @jillemery @daniellecrobins @denormalize works for me!",
  "id" : 857658572389351424,
  "in_reply_to_status_id" : 857658485382627328,
  "created_at" : "2017-04-27 18:11:52 +0000",
  "in_reply_to_screen_name" : "Neurosarda",
  "in_reply_to_user_id_str" : "4657994587",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857652934116618240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64310784573414, -79.38380465793333 ]
  },
  "id_str" : "857653328041435138",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli yeah, probably it\u2019s more \u201Ehow many commutes to Zurich will I have to cut out\u201C: \u201EI love you, but I\u2019ve chosen AR Wallace\u201C. \uD83D\uDE02",
  "id" : 857653328041435138,
  "in_reply_to_status_id" : 857652934116618240,
  "created_at" : "2017-04-27 17:51:02 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 0, 14 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 15, 24 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857652029510094848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64308167339732, -79.38379499291865 ]
  },
  "id_str" : "857652145818144772",
  "in_reply_to_user_id" : 15090415,
  "text" : "@annakrystalli @msandstr trying to figure out how long I\u2019ll have to survive on instant ramen to offset it :D",
  "id" : 857652145818144772,
  "in_reply_to_status_id" : 857652029510094848,
  "created_at" : "2017-04-27 17:46:20 +0000",
  "in_reply_to_screen_name" : "annakrystalli",
  "in_reply_to_user_id_str" : "15090415",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 10, 24 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857650634891423744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6430065030619, -79.38369854639616 ]
  },
  "id_str" : "857651589804380160",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @annakrystalli Found a 1871 ed. of AR Wallace\u2019s \u00ABContributions to the Theory of Natural Selection\u00BB, still tempted &amp; budgeting. \uD83E\uDD14",
  "id" : 857651589804380160,
  "in_reply_to_status_id" : 857650634891423744,
  "created_at" : "2017-04-27 17:44:08 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857642205695143936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6430065030619, -79.38369854639616 ]
  },
  "id_str" : "857649077869305857",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks don\u2019t worry, Zuckerberg will have figured it all out soon I heard. Looking forward to retiring early.",
  "id" : 857649077869305857,
  "in_reply_to_status_id" : 857642205695143936,
  "created_at" : "2017-04-27 17:34:09 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 63, 77 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857646370316050432",
  "text" : "RT @arikia: Had the pleasure of getting to know the founder of @OpenHumansOrg this past weekend. Very important work here. https:\/\/t.co\/mrk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenHumansOrg",
        "screen_name" : "OpenHumansOrg",
        "indices" : [ 51, 65 ],
        "id_str" : "2282943410",
        "id" : 2282943410
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/mrkYHloCxO",
        "expanded_url" : "https:\/\/twitter.com\/genomeuyg\/status\/857293189409099778",
        "display_url" : "twitter.com\/genomeuyg\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "857635211559014408",
    "text" : "Had the pleasure of getting to know the founder of @OpenHumansOrg this past weekend. Very important work here. https:\/\/t.co\/mrkYHloCxO",
    "id" : 857635211559014408,
    "created_at" : "2017-04-27 16:39:03 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 857646370316050432,
  "created_at" : "2017-04-27 17:23:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857644493348188161\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/FvcoiazfHq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-b3HrGWAAAuSDE.jpg",
      "id_str" : "857644490261135360",
      "id" : 857644490261135360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-b3HrGWAAAuSDE.jpg",
      "sizes" : [ {
        "h" : 1069,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 1069,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/FvcoiazfHq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/PElA7TZgba",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/4qJE0hyrzN3",
      "display_url" : "swarmapp.com\/c\/4qJE0hyrzN3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.643068947579046, -79.38386499881744 ]
  },
  "id_str" : "857644493348188161",
  "text" : "Someone's making up for the weather earlier this week. (@ Delta Hotels by Marriott Toronto) https:\/\/t.co\/PElA7TZgba https:\/\/t.co\/FvcoiazfHq",
  "id" : 857644493348188161,
  "created_at" : "2017-04-27 17:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anxious dinosaur",
      "screen_name" : "_fluoreszent",
      "indices" : [ 0, 13 ],
      "id_str" : "237439292",
      "id" : 237439292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857643581774987265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311870140824, -79.3838037137571 ]
  },
  "id_str" : "857644059745288192",
  "in_reply_to_user_id" : 237439292,
  "text" : "@_fluoreszent I know! But combined they are like 1 1\/2 months worth of my salary \uD83D\uDE2D",
  "id" : 857644059745288192,
  "in_reply_to_status_id" : 857643581774987265,
  "created_at" : "2017-04-27 17:14:12 +0000",
  "in_reply_to_screen_name" : "_fluoreszent",
  "in_reply_to_user_id_str" : "237439292",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857643018354122753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64311384342323, -79.38378913440559 ]
  },
  "id_str" : "857643145890344960",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman Okay, will be at the hotel until ~6 i guess.",
  "id" : 857643145890344960,
  "in_reply_to_status_id" : 857643018354122753,
  "created_at" : "2017-04-27 17:10:34 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857641958554185728\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/st7Fhnb4Lh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-b0smTVYAEVumv.jpg",
      "id_str" : "857641826093719553",
      "id" : 857641826093719553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-b0smTVYAEVumv.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/st7Fhnb4Lh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857641958554185728\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/st7Fhnb4Lh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-b0skOVYAA76QU.jpg",
      "id_str" : "857641825535877120",
      "id" : 857641825535877120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-b0skOVYAA76QU.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      } ],
      "display_url" : "pic.twitter.com\/st7Fhnb4Lh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857641958554185728\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/st7Fhnb4Lh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-b0soPUAAAsDif.jpg",
      "id_str" : "857641826613723136",
      "id" : 857641826613723136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-b0soPUAAAsDif.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/st7Fhnb4Lh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/857641958554185728\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/st7Fhnb4Lh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-b0sqXVwAAoY7l.jpg",
      "id_str" : "857641827184263168",
      "id" : 857641827184263168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-b0sqXVwAAoY7l.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/st7Fhnb4Lh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64310834560882, -79.38378696337284 ]
  },
  "id_str" : "857641958554185728",
  "text" : "Someone please stop me from spending all my money in this book store! https:\/\/t.co\/st7Fhnb4Lh",
  "id" : 857641958554185728,
  "created_at" : "2017-04-27 17:05:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857639861418905602",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64309060944104, -79.38376273374479 ]
  },
  "id_str" : "857641513819484160",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman No worries! And I see you\u2019re preparing already!",
  "id" : 857641513819484160,
  "in_reply_to_status_id" : 857639861418905602,
  "created_at" : "2017-04-27 17:04:05 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 3, 9 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 15, 27 ]
    }, {
      "text" : "OpenSource",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/ElGndLb1mW",
      "expanded_url" : "https:\/\/twitter.com\/transh4ck\/status\/857595433912238083",
      "display_url" : "twitter.com\/transh4ck\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857619799534428160",
  "text" : "RT @shefw: Hey #openscience folks!  Great opportunity here if you're interested. #OpenSource https:\/\/t.co\/ElGndLb1mW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 4, 16 ]
      }, {
        "text" : "OpenSource",
        "indices" : [ 70, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/ElGndLb1mW",
        "expanded_url" : "https:\/\/twitter.com\/transh4ck\/status\/857595433912238083",
        "display_url" : "twitter.com\/transh4ck\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "857615140664918016",
    "text" : "Hey #openscience folks!  Great opportunity here if you're interested. #OpenSource https:\/\/t.co\/ElGndLb1mW",
    "id" : 857615140664918016,
    "created_at" : "2017-04-27 15:19:17 +0000",
    "user" : {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "protected" : false,
      "id_str" : "48636190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677947392080019456\/CHnYz4aV_normal.jpg",
      "id" : 48636190,
      "verified" : false
    }
  },
  "id" : 857619799534428160,
  "created_at" : "2017-04-27 15:37:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 14, 24 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857614878705500160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65040839557203, -79.3718184700612 ]
  },
  "id_str" : "857619603886923777",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @yokofakun got one about RNAseq stuff some weeks ago as well.  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 857619603886923777,
  "in_reply_to_status_id" : 857614878705500160,
  "created_at" : "2017-04-27 15:37:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65032494252621, -79.37184386468087 ]
  },
  "id_str" : "857607461435527170",
  "text" : "\u00ABIf you\u2019re gone for too long you\u2019ll find me binge eating ice cream &amp; mass plotting pie charts with Matlab.\u00BB I\u2019m being blackmailed! \uD83C\uDF66\uD83C\uDF70\uD83D\uDCCA",
  "id" : 857607461435527170,
  "created_at" : "2017-04-27 14:48:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 16, 29 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857601184483422208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65502252296063, -79.37436658404904 ]
  },
  "id_str" : "857602265665982464",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps Lucky @jeroenbosman, having an experienced guide! :D",
  "id" : 857602265665982464,
  "in_reply_to_status_id" : 857601184483422208,
  "created_at" : "2017-04-27 14:28:08 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857600254341992448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65509078721381, -79.37444213610242 ]
  },
  "id_str" : "857600916404547584",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman Enjoy the trip!",
  "id" : 857600916404547584,
  "in_reply_to_status_id" : 857600254341992448,
  "created_at" : "2017-04-27 14:22:46 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857600254341992448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65506180166067, -79.37436770754375 ]
  },
  "id_str" : "857600337070436352",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman Right!",
  "id" : 857600337070436352,
  "in_reply_to_status_id" : 857600254341992448,
  "created_at" : "2017-04-27 14:20:28 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857599550424571904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65506180166067, -79.37436770754375 ]
  },
  "id_str" : "857599988750319616",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman Ah, still need to pack up my stuff, moving from an Airbnb to the conference hotel today. Let\u2019s do lunch when you\u2019re back!",
  "id" : 857599988750319616,
  "in_reply_to_status_id" : 857599550424571904,
  "created_at" : "2017-04-27 14:19:05 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857598026306682885",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65521259003491, -79.37431372002284 ]
  },
  "id_str" : "857598859622719488",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman When are you heading out?",
  "id" : 857598859622719488,
  "in_reply_to_status_id" : 857598026306682885,
  "created_at" : "2017-04-27 14:14:36 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/yYjnGoLtFf",
      "expanded_url" : "https:\/\/twitter.com\/NatureNews\/status\/857207659061235713",
      "display_url" : "twitter.com\/NatureNews\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65489139990584, -79.3743308047077 ]
  },
  "id_str" : "857574883236093953",
  "text" : "But how will Nature now decide on how much their subscriptions will cost? https:\/\/t.co\/yYjnGoLtFf",
  "id" : 857574883236093953,
  "created_at" : "2017-04-27 12:39:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/llk3kKobU9",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTXXD4ClTLV\/",
      "display_url" : "instagram.com\/p\/BTXXD4ClTLV\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.638023116412, -79.387944418965 ]
  },
  "id_str" : "857357831485444096",
  "text" : "Meet the Empire @ Harbourfront Lakeshore https:\/\/t.co\/llk3kKobU9",
  "id" : 857357831485444096,
  "created_at" : "2017-04-26 22:16:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "new boobs who this",
      "screen_name" : "Tesseraconteur",
      "indices" : [ 3, 18 ],
      "id_str" : "281670339",
      "id" : 281670339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "857302179954270208",
  "text" : "RT @Tesseraconteur: whoever became a carpenter just to make sure homeless folks couldn't get some sleep is literally the anti-christ\n\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/t3kBMj9nB2",
        "expanded_url" : "https:\/\/twitter.com\/willsommer\/status\/857006315427823616",
        "display_url" : "twitter.com\/willsommer\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "857028934470295553",
    "text" : "whoever became a carpenter just to make sure homeless folks couldn't get some sleep is literally the anti-christ\n\nhttps:\/\/t.co\/t3kBMj9nB2",
    "id" : 857028934470295553,
    "created_at" : "2017-04-26 00:29:55 +0000",
    "user" : {
      "name" : "new boobs who this",
      "screen_name" : "Tesseraconteur",
      "protected" : false,
      "id_str" : "281670339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/898063239199703040\/y8dicpAW_normal.jpg",
      "id" : 281670339,
      "verified" : false
    }
  },
  "id" : 857302179954270208,
  "created_at" : "2017-04-26 18:35:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 0, 13 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 14, 23 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857296944204566536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65485465363513, -79.37460273201953 ]
  },
  "id_str" : "857297198257721344",
  "in_reply_to_user_id" : 9104202,
  "text" : "@jeroenbosman @MsPhelps That sounds good!",
  "id" : 857297198257721344,
  "in_reply_to_status_id" : 857296944204566536,
  "created_at" : "2017-04-26 18:15:54 +0000",
  "in_reply_to_screen_name" : "jeroenbosman",
  "in_reply_to_user_id_str" : "9104202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/wl4dNPXMqh",
      "expanded_url" : "https:\/\/www.eventbrite.ca\/e\/toronto-ladies-learning-code-instructor-and-mentor-appreciation-night-on-april-26th-tickets-31545290814",
      "display_url" : "eventbrite.ca\/e\/toronto-ladi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "857281127664545792",
  "text" : "Hey Toronto, anyone else at the 'Ladies Learning Code Instructor and Mentor Appreciation Night' today? https:\/\/t.co\/wl4dNPXMqh",
  "id" : 857281127664545792,
  "created_at" : "2017-04-26 17:12:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "857097576323182593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65509875416718, -79.37433851649344 ]
  },
  "id_str" : "857097824642662400",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes Totally, we celebrated accordingly, using applied yeast genomics \uD83C\uDF7A",
  "id" : 857097824642662400,
  "in_reply_to_status_id" : 857097576323182593,
  "created_at" : "2017-04-26 05:03:40 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/ltoDYfFIjb",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTVgOPMF5Cq\/",
      "display_url" : "instagram.com\/p\/BTVgOPMF5Cq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.653333333333, -79.383888888889 ]
  },
  "id_str" : "857096499817271299",
  "text" : "Toronto \uD83C\uDF41 @ Toronto City Hall https:\/\/t.co\/ltoDYfFIjb",
  "id" : 857096499817271299,
  "created_at" : "2017-04-26 04:58:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/4Kxo2FCcNF",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTVM9ZAFLC6\/",
      "display_url" : "instagram.com\/p\/BTVM9ZAFLC6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "857054139733479424",
  "text" : "genome #1 ever uploaded to openSNP, meet genome #2! https:\/\/t.co\/4Kxo2FCcNF",
  "id" : 857054139733479424,
  "created_at" : "2017-04-26 02:10:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856996602325630976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65503685391164, -79.37438107779529 ]
  },
  "id_str" : "856996842197929990",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs screwed up the time zones with either coming in or adding it to my calendar. My calendar that I came in to YYZ too late to join!",
  "id" : 856996842197929990,
  "in_reply_to_status_id" : 856996602325630976,
  "created_at" : "2017-04-25 22:22:24 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Granados",
      "screen_name" : "Monsauce",
      "indices" : [ 0, 9 ],
      "id_str" : "297073565",
      "id" : 297073565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856954989838827520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65499831573852, -79.3744390688312 ]
  },
  "id_str" : "856955066548441088",
  "in_reply_to_user_id" : 297073565,
  "text" : "@Monsauce awesome, looking forward to meet again!",
  "id" : 856955066548441088,
  "in_reply_to_status_id" : 856954989838827520,
  "created_at" : "2017-04-25 19:36:23 +0000",
  "in_reply_to_screen_name" : "Monsauce",
  "in_reply_to_user_id_str" : "297073565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ASAPbio",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/pLeqiIjQhb",
      "expanded_url" : "http:\/\/asapbio.org\/gov",
      "display_url" : "asapbio.org\/gov"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65492447195777, -79.37434960594211 ]
  },
  "id_str" : "856954574317465600",
  "text" : "How should an aggregation service for preprints be governed? #ASAPbio wants your feedback on draft principles https:\/\/t.co\/pLeqiIjQhb",
  "id" : 856954574317465600,
  "created_at" : "2017-04-25 19:34:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ccsummit",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/fC6xFYJOHH",
      "expanded_url" : "https:\/\/creativecommons.org\/2017\/04\/25\/meetcc-voices-global-summit-scholarship-recipients\/",
      "display_url" : "creativecommons.org\/2017\/04\/25\/mee\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65493987979534, -79.37445333979771 ]
  },
  "id_str" : "856953718281056256",
  "text" : "Meet the recipients of the #ccsummit Scholarship. I\u2019m so honored to be part of this amazing group of people! https:\/\/t.co\/fC6xFYJOHH",
  "id" : 856953718281056256,
  "created_at" : "2017-04-25 19:31:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DNADay17",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/0makMv7NQM",
      "expanded_url" : "https:\/\/twitter.com\/csmarcum\/status\/856937575239618560",
      "display_url" : "twitter.com\/csmarcum\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65495767448438, -79.37430946163775 ]
  },
  "id_str" : "856942369052139520",
  "text" : "That\u2019s an awesome way to celebrate #DNADay17: give the gift of data. \uD83C\uDF89\uD83D\uDE0D https:\/\/t.co\/0makMv7NQM",
  "id" : 856942369052139520,
  "created_at" : "2017-04-25 18:45:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 9, 19 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856935851993030657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65463329483164, -79.39028285451177 ]
  },
  "id_str" : "856935966023467008",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai @blahah404 I will take you up on that!",
  "id" : 856935966023467008,
  "in_reply_to_status_id" : 856935851993030657,
  "created_at" : "2017-04-25 18:20:30 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 11, 19 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856926488758804487",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65538888560803, -79.38034712676931 ]
  },
  "id_str" : "856926703263911937",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @cbahlai I already got all the necessary papers. Who wants to give their name as supervisor for holding a proper defense? :p",
  "id" : 856926703263911937,
  "in_reply_to_status_id" : 856926488758804487,
  "created_at" : "2017-04-25 17:43:41 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/hvD361CVM3",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/856925561876361217",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "856925561876361217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65535360940997, -79.38033776761445 ]
  },
  "id_str" : "856925765400743936",
  "in_reply_to_user_id" : 14286491,
  "text" : "By now I should totally get a PhD in Open Science. \uD83D\uDE02 https:\/\/t.co\/hvD361CVM3",
  "id" : 856925765400743936,
  "in_reply_to_status_id" : 856925561876361217,
  "created_at" : "2017-04-25 17:39:58 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65540468138052, -79.380518188774 ]
  },
  "id_str" : "856925561876361217",
  "text" : "Getting the first positive review on the F1000 Research article about Sci-Hub and having another paper accepted today. \uD83D\uDE0D\uD83E\uDD42\uD83C\uDF89",
  "id" : 856925561876361217,
  "created_at" : "2017-04-25 17:39:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856922693802876930",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65544167997347, -79.38036736116949 ]
  },
  "id_str" : "856925012636258304",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil Cool, schaue ich mir mal an!",
  "id" : 856925012636258304,
  "in_reply_to_status_id" : 856922693802876930,
  "created_at" : "2017-04-25 17:36:58 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/0sUnwlICMR",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTUQZkGlli2\/",
      "display_url" : "instagram.com\/p\/BTUQZkGlli2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "856920966336843778",
  "text" : "Feels like home already https:\/\/t.co\/0sUnwlICMR",
  "id" : 856920966336843778,
  "created_at" : "2017-04-25 17:20:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "\u0394 (alt-J)",
      "screen_name" : "alt_J",
      "indices" : [ 10, 16 ],
      "id_str" : "301931359",
      "id" : 301931359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856918159172882432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65528373035016, -79.38011767272802 ]
  },
  "id_str" : "856918256048885761",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @alt_J I didn\u2019t expect anything less \uD83D\uDE09",
  "id" : 856918256048885761,
  "in_reply_to_status_id" : 856918159172882432,
  "created_at" : "2017-04-25 17:10:07 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "\u0394 (alt-J)",
      "screen_name" : "alt_J",
      "indices" : [ 10, 16 ],
      "id_str" : "301931359",
      "id" : 301931359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856917282668199936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65515536167068, -79.38002239920141 ]
  },
  "id_str" : "856918082979323905",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @alt_J I didn\u2019t, thanks for the pointer \uD83D\uDE0D",
  "id" : 856918082979323905,
  "in_reply_to_status_id" : 856917282668199936,
  "created_at" : "2017-04-25 17:09:26 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856916574015553537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.65458442833615, -79.38063779853226 ]
  },
  "id_str" : "856917423970242562",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil Danke, werde ich mir ansehen :) sonst irgendwelche Tipps? :)",
  "id" : 856917423970242562,
  "in_reply_to_status_id" : 856916574015553537,
  "created_at" : "2017-04-25 17:06:49 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Stewart",
      "screen_name" : "BioStew",
      "indices" : [ 0, 8 ],
      "id_str" : "221032511",
      "id" : 221032511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856907646804389888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.6468418129195, -79.37547286979796 ]
  },
  "id_str" : "856907819098001408",
  "in_reply_to_user_id" : 221032511,
  "text" : "@BioStew Thanks!",
  "id" : 856907819098001408,
  "in_reply_to_status_id" : 856907646804389888,
  "created_at" : "2017-04-25 16:28:39 +0000",
  "in_reply_to_screen_name" : "BioStew",
  "in_reply_to_user_id_str" : "221032511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/UVWIPgCYaY",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTUJj-FFj0Y\/",
      "display_url" : "instagram.com\/p\/BTUJj-FFj0Y\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.64552, -79.38031 ]
  },
  "id_str" : "856905931896098817",
  "text" : "Ohai Toronto @ Union Station https:\/\/t.co\/UVWIPgCYaY",
  "id" : 856905931896098817,
  "created_at" : "2017-04-25 16:21:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rike MW",
      "screen_name" : "rike_mw",
      "indices" : [ 0, 8 ],
      "id_str" : "79192038",
      "id" : 79192038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856881319149785088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 43.70144496675925, -79.61194069132172 ]
  },
  "id_str" : "856897098436030467",
  "in_reply_to_user_id" : 79192038,
  "text" : "@rike_mw When\/how long are you here?",
  "id" : 856897098436030467,
  "in_reply_to_status_id" : 856881319149785088,
  "created_at" : "2017-04-25 15:46:03 +0000",
  "in_reply_to_screen_name" : "rike_mw",
  "in_reply_to_user_id_str" : "79192038",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.97968554102015, -87.89951511974753 ]
  },
  "id_str" : "856862062072520709",
  "text" : "\u00ABOnce that door closes we\u2019re going to Toronto, even if that\u2019s not where you wanna be. Last chance to get off this plane.\u00BB",
  "id" : 856862062072520709,
  "created_at" : "2017-04-25 13:26:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Xu",
      "screen_name" : "annathehybrid",
      "indices" : [ 0, 14 ],
      "id_str" : "2997606122",
      "id" : 2997606122
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 15, 27 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856854279482728448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.97678159460609, -87.8966841102465 ]
  },
  "id_str" : "856854540590743552",
  "in_reply_to_user_id" : 2997606122,
  "text" : "@annathehybrid @froggleston That feels especially mean given that I\u2019m just off a red eye and feel all but rested myself :D",
  "id" : 856854540590743552,
  "in_reply_to_status_id" : 856854279482728448,
  "created_at" : "2017-04-25 12:56:56 +0000",
  "in_reply_to_screen_name" : "annathehybrid",
  "in_reply_to_user_id_str" : "2997606122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856852920637239296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.97690797046699, -87.89688074426284 ]
  },
  "id_str" : "856853703663419394",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston And hadn\u2019t have the goat so far. But the Link-rip off rocks too!",
  "id" : 856853703663419394,
  "in_reply_to_status_id" : 856852920637239296,
  "created_at" : "2017-04-25 12:53:37 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Xu",
      "screen_name" : "annathehybrid",
      "indices" : [ 0, 14 ],
      "id_str" : "2997606122",
      "id" : 2997606122
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 15, 27 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856852937485766657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.97690797046699, -87.89688074426284 ]
  },
  "id_str" : "856853623279693826",
  "in_reply_to_user_id" : 2997606122,
  "text" : "@annathehybrid @froggleston I\u2019ve been trying for a good while but always die at the border crossing.",
  "id" : 856853623279693826,
  "in_reply_to_status_id" : 856852937485766657,
  "created_at" : "2017-04-25 12:53:18 +0000",
  "in_reply_to_screen_name" : "annathehybrid",
  "in_reply_to_user_id_str" : "2997606122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.97681594414112, -87.8966244939613 ]
  },
  "id_str" : "856852151800344576",
  "text" : "What better way to prepare for my flight ORD \u2708\uFE0F YYZ than playing \u2018Death Road to Canada\u2019?",
  "id" : 856852151800344576,
  "created_at" : "2017-04-25 12:47:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Metallica",
      "screen_name" : "Metallica",
      "indices" : [ 11, 21 ],
      "id_str" : "238475531",
      "id" : 238475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856848674021928960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.97688931044036, -87.8969698727629 ]
  },
  "id_str" : "856850146671329280",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @Metallica Did we set a trend? \uD83E\uDD18",
  "id" : 856850146671329280,
  "in_reply_to_status_id" : 856848674021928960,
  "created_at" : "2017-04-25 12:39:29 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaetan Burgio",
      "screen_name" : "GaetanBurgio",
      "indices" : [ 3, 16 ],
      "id_str" : "2731401072",
      "id" : 2731401072
    }, {
      "name" : "STAT",
      "screen_name" : "statnews",
      "indices" : [ 112, 121 ],
      "id_str" : "3290364847",
      "id" : 3290364847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CRISPR",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "856839813445627906",
  "text" : "RT @GaetanBurgio: Very good read 'The Broad Institute is testing the limits of what \u2018nonprofit\u2019 means' #CRISPR  @statnews https:\/\/t.co\/oCd6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "STAT",
        "screen_name" : "statnews",
        "indices" : [ 94, 103 ],
        "id_str" : "3290364847",
        "id" : 3290364847
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CRISPR",
        "indices" : [ 85, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/oCd6kZMBTD",
        "expanded_url" : "https:\/\/www.statnews.com\/2017\/04\/25\/broad-institute-nonprofit-crispr\/",
        "display_url" : "statnews.com\/2017\/04\/25\/bro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "856824209082793984",
    "text" : "Very good read 'The Broad Institute is testing the limits of what \u2018nonprofit\u2019 means' #CRISPR  @statnews https:\/\/t.co\/oCd6kZMBTD",
    "id" : 856824209082793984,
    "created_at" : "2017-04-25 10:56:25 +0000",
    "user" : {
      "name" : "Gaetan Burgio",
      "screen_name" : "GaetanBurgio",
      "protected" : false,
      "id_str" : "2731401072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616564777746198528\/VSwdFtoj_normal.jpg",
      "id" : 2731401072,
      "verified" : false
    }
  },
  "id" : 856839813445627906,
  "created_at" : "2017-04-25 11:58:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Pettigrew",
      "screen_name" : "Nick_Pettigrew",
      "indices" : [ 3, 18 ],
      "id_str" : "132660956",
      "id" : 132660956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "856763393104953344",
  "text" : "RT @Nick_Pettigrew: \"First they came for the Putin-supporting, Trump-enabling rape suspects and I was like 'Good, it's about time, he's ove\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nick_Pettigrew\/status\/856747229448720384\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/gCYNd0kmKW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-PHDbPXUAAQyuE.jpg",
        "id_str" : "856747215796260864",
        "id" : 856747215796260864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-PHDbPXUAAQyuE.jpg",
        "sizes" : [ {
          "h" : 829,
          "resize" : "fit",
          "w" : 1290
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 829,
          "resize" : "fit",
          "w" : 1290
        } ],
        "display_url" : "pic.twitter.com\/gCYNd0kmKW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "856747229448720384",
    "text" : "\"First they came for the Putin-supporting, Trump-enabling rape suspects and I was like 'Good, it's about time, he's over there'.\" https:\/\/t.co\/gCYNd0kmKW",
    "id" : 856747229448720384,
    "created_at" : "2017-04-25 05:50:31 +0000",
    "user" : {
      "name" : "Nick Pettigrew",
      "screen_name" : "Nick_Pettigrew",
      "protected" : false,
      "id_str" : "132660956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916392068775317505\/0ABkZWpP_normal.jpg",
      "id" : 132660956,
      "verified" : false
    }
  },
  "id" : 856763393104953344,
  "created_at" : "2017-04-25 06:54:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/W1r7RpZ8I6",
      "expanded_url" : "http:\/\/dogswithtonguestickingoutalittle.tumblr.com\/post\/159956660536\/zeus-with-the-smallest-of-bleps",
      "display_url" : "\u2026thtonguestickingoutalittle.tumblr.com\/post\/159956660\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856744845800390657",
  "text" : "Having a clear goal for my flight SEA \u2708\uFE0F ORD. https:\/\/t.co\/W1r7RpZ8I6",
  "id" : 856744845800390657,
  "created_at" : "2017-04-25 05:41:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 10, 19 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Camille Nebeker",
      "screen_name" : "cnebeker",
      "indices" : [ 20, 29 ],
      "id_str" : "39059095",
      "id" : 39059095
    }, {
      "name" : "Meg Doerr",
      "screen_name" : "MegDoerr",
      "indices" : [ 30, 39 ],
      "id_str" : "2406334545",
      "id" : 2406334545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/aMt7l3ui01",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/dungeon-classes",
      "display_url" : "smbc-comics.com\/comic\/dungeon-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "856545807394385921",
  "geo" : { },
  "id_str" : "856741796629463040",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @eramirez @cnebeker @MegDoerr of course not, we can extend our RPG-model to be more fit to our purpose: https:\/\/t.co\/aMt7l3ui01",
  "id" : 856741796629463040,
  "in_reply_to_status_id" : 856545807394385921,
  "created_at" : "2017-04-25 05:28:56 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Camille Nebeker",
      "screen_name" : "cnebeker",
      "indices" : [ 20, 29 ],
      "id_str" : "39059095",
      "id" : 39059095
    }, {
      "name" : "Meg Doerr",
      "screen_name" : "MegDoerr",
      "indices" : [ 30, 39 ],
      "id_str" : "2406334545",
      "id" : 2406334545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856541098033815552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61461789458602, -122.3455957094916 ]
  },
  "id_str" : "856545277020221442",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @wilbanks @cnebeker @MegDoerr chaotic good ftw!",
  "id" : 856545277020221442,
  "in_reply_to_status_id" : 856541098033815552,
  "created_at" : "2017-04-24 16:28:02 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ollie",
      "screen_name" : "ojedge",
      "indices" : [ 3, 10 ],
      "id_str" : "284687555",
      "id" : 284687555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "856522660389441536",
  "text" : "RT @ojedge: Do you, Karen, take David the Optometrist to be your lawfully wedded husband, for better or worse? Better... or worse? Better..\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538257725466365952",
    "text" : "Do you, Karen, take David the Optometrist to be your lawfully wedded husband, for better or worse? Better... or worse? Better... or worse?",
    "id" : 538257725466365952,
    "created_at" : "2014-11-28 09:06:56 +0000",
    "user" : {
      "name" : "Ollie",
      "screen_name" : "ojedge",
      "protected" : false,
      "id_str" : "284687555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929842530216218625\/2A-vXy4y_normal.jpg",
      "id" : 284687555,
      "verified" : false
    }
  },
  "id" : 856522660389441536,
  "created_at" : "2017-04-24 14:58:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/VFf7uilFqF",
      "expanded_url" : "https:\/\/twitter.com\/HansZauner\/status\/856400179821502466",
      "display_url" : "twitter.com\/HansZauner\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61466990506315, -122.3456272185217 ]
  },
  "id_str" : "856401122600169472",
  "text" : "The terrible loss of time is largely due to trying to get the permit A 38 from the vital records office. https:\/\/t.co\/VFf7uilFqF",
  "id" : 856401122600169472,
  "created_at" : "2017-04-24 06:55:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatjana Scheffler",
      "screen_name" : "tschfflr",
      "indices" : [ 0, 9 ],
      "id_str" : "313810815",
      "id" : 313810815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856392946756837377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61464389646312, -122.3456235499418 ]
  },
  "id_str" : "856400397069570049",
  "in_reply_to_user_id" : 313810815,
  "text" : "@tschfflr yes. \nVegan == no animal products. Fungi != animals. \n\nEvolutionary biology saves the day once again. \uD83D\uDE1B",
  "id" : 856400397069570049,
  "in_reply_to_status_id" : 856392946756837377,
  "created_at" : "2017-04-24 06:52:20 +0000",
  "in_reply_to_screen_name" : "tschfflr",
  "in_reply_to_user_id_str" : "313810815",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/1tF2TVZMJ1",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/854612584305233920",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "856397813432832000",
  "text" : "Result: ~75% of sciency people get married to solve or make migration issues easier. Aren't we true romantics? https:\/\/t.co\/1tF2TVZMJ1",
  "id" : 856397813432832000,
  "created_at" : "2017-04-24 06:42:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Metallica",
      "screen_name" : "Metallica",
      "indices" : [ 11, 21 ],
      "id_str" : "238475531",
      "id" : 238475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856360550695002112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.62408581621789, -122.3566837857986 ]
  },
  "id_str" : "856360827254853633",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @Metallica If you ask me their music has lost all its depth for quite a while already. ;)",
  "id" : 856360827254853633,
  "in_reply_to_status_id" : 856360550695002112,
  "created_at" : "2017-04-24 04:15:06 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6147570584081, -122.3448951200726 ]
  },
  "id_str" : "856347393796657153",
  "text" : "Best thing about this hotel: it\u2019s across the road from a dog park. \uD83D\uDC36\uD83D\uDE0D",
  "id" : 856347393796657153,
  "created_at" : "2017-04-24 03:21:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856323737267740672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61388997881589, -122.3455455730413 ]
  },
  "id_str" : "856323830809116672",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, first edition as far as i could tell!",
  "id" : 856323830809116672,
  "in_reply_to_status_id" : 856323737267740672,
  "created_at" : "2017-04-24 01:48:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 4, 13 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/VW6wQlhefk",
      "expanded_url" : "https:\/\/twitter.com\/junanaguy\/status\/856317028285599745",
      "display_url" : "twitter.com\/junanaguy\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61388997881589, -122.3455455730413 ]
  },
  "id_str" : "856323450918420481",
  "text" : "The @open_con community is! https:\/\/t.co\/VW6wQlhefk",
  "id" : 856323450918420481,
  "created_at" : "2017-04-24 01:46:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 15, 25 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/b5pPF2q8j0",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/mguPrVJAnEHIY\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/mguPrVJA\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "856320877629251584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61388997881589, -122.3455455730413 ]
  },
  "id_str" : "856322717703782401",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @l_matthia how about https:\/\/t.co\/b5pPF2q8j0 ?",
  "id" : 856322717703782401,
  "in_reply_to_status_id" : 856320877629251584,
  "created_at" : "2017-04-24 01:43:40 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 0, 8 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856306172835446785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61389010410547, -122.3455457001738 ]
  },
  "id_str" : "856321847113076737",
  "in_reply_to_user_id" : 19843630,
  "text" : "@mbeisen you gotta teach them early, how else would they become accepted amongst fellow science illustrators?",
  "id" : 856321847113076737,
  "in_reply_to_status_id" : 856306172835446785,
  "created_at" : "2017-04-24 01:40:12 +0000",
  "in_reply_to_screen_name" : "mbeisen",
  "in_reply_to_user_id_str" : "19843630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "856285603595407360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61498426992394, -122.3493816008102 ]
  },
  "id_str" : "856286185588572160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer USD 12. Can give it to you next time we meet :D",
  "id" : 856286185588572160,
  "in_reply_to_status_id" : 856285603595407360,
  "created_at" : "2017-04-23 23:18:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/B7EOAM7XzJ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTPpHW2ln0Z\/",
      "display_url" : "instagram.com\/p\/BTPpHW2ln0Z\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.629611111111, -122.35941666667 ]
  },
  "id_str" : "856271627646119939",
  "text" : "enjoying the weather @ Kerry Park https:\/\/t.co\/B7EOAM7XzJ",
  "id" : 856271627646119939,
  "created_at" : "2017-04-23 22:20:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/uenVovFEya",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTPinIXFwDM\/",
      "display_url" : "instagram.com\/p\/BTPinIXFwDM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "856257340215111680",
  "text" : "A bookstore full of cats! \uD83D\uDE0D https:\/\/t.co\/uenVovFEya",
  "id" : 856257340215111680,
  "created_at" : "2017-04-23 21:23:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Exchange",
      "screen_name" : "ScienceExchange",
      "indices" : [ 17, 33 ],
      "id_str" : "269584194",
      "id" : 269584194
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/856244653984763905\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/I3gYeYQkST",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-H9-UaXoAA6yUq.jpg",
      "id_str" : "856244651250130944",
      "id" : 856244651250130944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-H9-UaXoAA6yUq.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/I3gYeYQkST"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "856244653984763905",
  "text" : "Funny, where the @ScienceExchange logo pops up! https:\/\/t.co\/I3gYeYQkST",
  "id" : 856244653984763905,
  "created_at" : "2017-04-23 20:33:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/1oDD9Wzsxc",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTPXbrbl4GM\/",
      "display_url" : "instagram.com\/p\/BTPXbrbl4GM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "856232745676271619",
  "text" : "Mixture https:\/\/t.co\/1oDD9Wzsxc",
  "id" : 856232745676271619,
  "created_at" : "2017-04-23 19:46:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/856232093273047040\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ojojxSLs5l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-HyhHrUAAAqcIF.jpg",
      "id_str" : "856232054987423744",
      "id" : 856232054987423744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-HyhHrUAAAqcIF.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ojojxSLs5l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61495658999998, -122.34926283 ]
  },
  "id_str" : "856232093273047040",
  "text" : "Times are tough in Seattle: This biochemist really wants to be added to your professional network. https:\/\/t.co\/ojojxSLs5l",
  "id" : 856232093273047040,
  "created_at" : "2017-04-23 19:43:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@F0O0",
      "screen_name" : "F0O0",
      "indices" : [ 0, 5 ],
      "id_str" : "105943845",
      "id" : 105943845
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 6, 19 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/0f2JHzUgvX",
      "expanded_url" : "http:\/\/darwin-online.org.uk\/EditorialIntroductions\/vanWyhe_notebooks.html",
      "display_url" : "darwin-online.org.uk\/EditorialIntro\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "856206329752559617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61839402378315, -122.3220058345444 ]
  },
  "id_str" : "856207059175342080",
  "in_reply_to_user_id" : 105943845,
  "text" : "@F0O0 @PhilippBayer https:\/\/t.co\/0f2JHzUgvX :D",
  "id" : 856207059175342080,
  "in_reply_to_status_id" : 856206329752559617,
  "created_at" : "2017-04-23 18:04:05 +0000",
  "in_reply_to_screen_name" : "F0O0",
  "in_reply_to_user_id_str" : "105943845",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 25, 38 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/856206078312300544\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/70gyufqtwe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-Ha4UXUMAAywfk.jpg",
      "id_str" : "856206065251135488",
      "id" : 856206065251135488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-Ha4UXUMAAywfk.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/70gyufqtwe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.62271751004924, -122.3254301880236 ]
  },
  "id_str" : "856206078312300544",
  "text" : "Random bookstore find. \uD83D\uDE0D @PhilippBayer https:\/\/t.co\/70gyufqtwe",
  "id" : 856206078312300544,
  "created_at" : "2017-04-23 18:00:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/CWWVbDvUPx",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTPDiybFuFf\/",
      "display_url" : "instagram.com\/p\/BTPDiybFuFf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "856189008963133442",
  "text" : "listening in https:\/\/t.co\/CWWVbDvUPx",
  "id" : 856189008963133442,
  "created_at" : "2017-04-23 16:52:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/856184416476909568\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/hjAx6CdNAy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-HHLOiU0AIVTlH.jpg",
      "id_str" : "856184399871660034",
      "id" : 856184399871660034,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-HHLOiU0AIVTlH.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hjAx6CdNAy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61458173925663, -122.3425521533407 ]
  },
  "id_str" : "856184416476909568",
  "text" : "That\u2019s my kind of modern art. https:\/\/t.co\/hjAx6CdNAy",
  "id" : 856184416476909568,
  "created_at" : "2017-04-23 16:34:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Douche   \uD83D\uDCAB",
      "screen_name" : "novenator",
      "indices" : [ 3, 13 ],
      "id_str" : "18548184",
      "id" : 18548184
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/novenator\/status\/855797753380777985\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/892z9sLbyV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-BnhNoUMAAe0Pd.jpg",
      "id_str" : "855797749492494336",
      "id" : 855797749492494336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-BnhNoUMAAe0Pd.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/892z9sLbyV"
    } ],
    "hashtags" : [ {
      "text" : "MarchForScience",
      "indices" : [ 43, 59 ]
    }, {
      "text" : "ScienceMarch",
      "indices" : [ 69, 82 ]
    }, {
      "text" : "Archaeology",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "856139837924974592",
  "text" : "RT @novenator: My friend's sign in today's #MarchForScience in Reno. #ScienceMarch #Archaeology https:\/\/t.co\/892z9sLbyV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/friendsplus.me\" rel=\"nofollow\"\u003EFriends Me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/novenator\/status\/855797753380777985\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/892z9sLbyV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-BnhNoUMAAe0Pd.jpg",
        "id_str" : "855797749492494336",
        "id" : 855797749492494336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-BnhNoUMAAe0Pd.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/892z9sLbyV"
      } ],
      "hashtags" : [ {
        "text" : "MarchForScience",
        "indices" : [ 28, 44 ]
      }, {
        "text" : "ScienceMarch",
        "indices" : [ 54, 67 ]
      }, {
        "text" : "Archaeology",
        "indices" : [ 68, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "855797753380777985",
    "text" : "My friend's sign in today's #MarchForScience in Reno. #ScienceMarch #Archaeology https:\/\/t.co\/892z9sLbyV",
    "id" : 855797753380777985,
    "created_at" : "2017-04-22 14:57:39 +0000",
    "user" : {
      "name" : "Peter Douche   \uD83D\uDCAB",
      "screen_name" : "novenator",
      "protected" : false,
      "id_str" : "18548184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/124109541\/Pulsar3c_normal.gif",
      "id" : 18548184,
      "verified" : false
    }
  },
  "id" : 856139837924974592,
  "created_at" : "2017-04-23 13:36:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sciencemarch",
      "indices" : [ 12, 25 ]
    }, {
      "text" : "latergram",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Q0FkSbrOpS",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTN_h3mlvh0\/",
      "display_url" : "instagram.com\/p\/BTN_h3mlvh0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.622452052018, -122.35201527709 ]
  },
  "id_str" : "856039449913958400",
  "text" : "Joining the #sciencemarch: The Satanic Temple Seattle #latergram @ Seattle Center Fountain https:\/\/t.co\/Q0FkSbrOpS",
  "id" : 856039449913958400,
  "created_at" : "2017-04-23 06:58:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 66, 75 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 129, 152 ],
      "url" : "https:\/\/t.co\/NVfBZDpOdT",
      "expanded_url" : "https:\/\/twitter.com\/Helena_LB\/status\/855906337582141440",
      "display_url" : "twitter.com\/Helena_LB\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61510536210348, -122.3492432574233 ]
  },
  "id_str" : "856036926511497217",
  "text" : "After this successful challenge I felt obliged to do karaoke with @nshockey to end the #sageassembly in an appropriate manner! \uD83C\uDFA4 https:\/\/t.co\/NVfBZDpOdT",
  "id" : 856036926511497217,
  "created_at" : "2017-04-23 06:48:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/856021296949346304\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/3v312QKjv1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-Ey0fEUIAEe9m9.jpg",
      "id_str" : "856021281451286529",
      "id" : 856021281451286529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-Ey0fEUIAEe9m9.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/3v312QKjv1"
    } ],
    "hashtags" : [ {
      "text" : "sciencemarch",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614619398012, -122.344685866002 ]
  },
  "id_str" : "856021296949346304",
  "text" : "There\u2019s some conspiracy theory here on why the #sciencemarch took place on this date. https:\/\/t.co\/3v312QKjv1",
  "id" : 856021296949346304,
  "created_at" : "2017-04-23 05:45:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science March - SEA",
      "screen_name" : "SciMarchSeattle",
      "indices" : [ 3, 19 ],
      "id_str" : "824129460664434688",
      "id" : 824129460664434688
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Seattle",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "Startrek",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "TNG",
      "indices" : [ 106, 110 ]
    }, {
      "text" : "marchforscience",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "856019373613432832",
  "text" : "RT @SciMarchSeattle: There are so many amazing signs up here in #Seattle! How good is this one!\n#Startrek #TNG #marchforscience https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciMarchSeattle\/status\/855701964604166144\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/oKXoYNsQ38",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C-AQOVNV0AAdQ08.jpg",
        "id_str" : "855701767597707264",
        "id" : 855701767597707264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-AQOVNV0AAdQ08.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/oKXoYNsQ38"
      } ],
      "hashtags" : [ {
        "text" : "Seattle",
        "indices" : [ 43, 51 ]
      }, {
        "text" : "Startrek",
        "indices" : [ 75, 84 ]
      }, {
        "text" : "TNG",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "marchforscience",
        "indices" : [ 90, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "855701964604166144",
    "text" : "There are so many amazing signs up here in #Seattle! How good is this one!\n#Startrek #TNG #marchforscience https:\/\/t.co\/oKXoYNsQ38",
    "id" : 855701964604166144,
    "created_at" : "2017-04-22 08:37:01 +0000",
    "user" : {
      "name" : "Science March - SEA",
      "screen_name" : "SciMarchSeattle",
      "protected" : false,
      "id_str" : "824129460664434688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889175678826008577\/VCSbQR9j_normal.jpg",
      "id" : 824129460664434688,
      "verified" : false
    }
  },
  "id" : 856019373613432832,
  "created_at" : "2017-04-23 05:38:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/F7QVt826FP",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTNfRGOlrNe\/",
      "display_url" : "instagram.com\/p\/BTNfRGOlrNe\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.62738, -122.37011 ]
  },
  "id_str" : "855968497838567425",
  "text" : "Cider Tasting @ Citizen Six https:\/\/t.co\/F7QVt826FP",
  "id" : 855968497838567425,
  "created_at" : "2017-04-23 02:16:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akp\u00E9li Nordor",
      "screen_name" : "akpelinordor",
      "indices" : [ 0, 13 ],
      "id_str" : "825964982",
      "id" : 825964982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855958548047577088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.62736323018795, -122.370008760249 ]
  },
  "id_str" : "855963440434692097",
  "in_reply_to_user_id" : 825964982,
  "text" : "@akpelinordor Same for me! Hope to meet again soon!",
  "id" : 855963440434692097,
  "in_reply_to_status_id" : 855958548047577088,
  "created_at" : "2017-04-23 01:56:01 +0000",
  "in_reply_to_screen_name" : "akpelinordor",
  "in_reply_to_user_id_str" : "825964982",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/Qri4ahHVfo",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTNYGG4FkdU\/",
      "display_url" : "instagram.com\/p\/BTNYGG4FkdU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "855952729277169664",
  "text" : "The sun comes out after the march for science. https:\/\/t.co\/Qri4ahHVfo",
  "id" : 855952729277169664,
  "created_at" : "2017-04-23 01:13:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Metallica",
      "screen_name" : "Metallica",
      "indices" : [ 11, 21 ],
      "id_str" : "238475531",
      "id" : 238475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855906337582141440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61527666179373, -122.3270472914101 ]
  },
  "id_str" : "855914772834820097",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @Metallica Where do we meet for drinks?",
  "id" : 855914772834820097,
  "in_reply_to_status_id" : 855906337582141440,
  "created_at" : "2017-04-22 22:42:38 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "marchforscience",
      "indices" : [ 24, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61147618763857, -122.3370983732141 ]
  },
  "id_str" : "855863503244017664",
  "text" : "Sending pictures of the #marchforscience back home,  answer: \u2018looks like there are more people in Seattle than at the inauguration.\u2019 \uD83D\uDE02\uD83D\uDD25",
  "id" : 855863503244017664,
  "created_at" : "2017-04-22 19:18:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/855862439342034944\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/VHEMaktl0k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-CiUfQU0AAI1h0.jpg",
      "id_str" : "855862402071449600",
      "id" : 855862402071449600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-CiUfQU0AAI1h0.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/VHEMaktl0k"
    } ],
    "hashtags" : [ {
      "text" : "sciencemarch",
      "indices" : [ 16, 29 ]
    }, {
      "text" : "marchforscience",
      "indices" : [ 30, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61243944840169, -122.3345415884857 ]
  },
  "id_str" : "855862439342034944",
  "text" : "Citation needed #sciencemarch #marchforscience https:\/\/t.co\/VHEMaktl0k",
  "id" : 855862439342034944,
  "created_at" : "2017-04-22 19:14:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/855859800885739520\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/EuoEkyGlXc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C-Cf7-CUIAAdnvW.jpg",
      "id_str" : "855859781814198272",
      "id" : 855859781814198272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C-Cf7-CUIAAdnvW.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EuoEkyGlXc"
    } ],
    "hashtags" : [ {
      "text" : "marchforscience",
      "indices" : [ 24, 40 ]
    }, {
      "text" : "sageassembly",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61488258057251, -122.3257072098878 ]
  },
  "id_str" : "855859800885739520",
  "text" : "Successfully joined the #marchforscience. #sageassembly https:\/\/t.co\/EuoEkyGlXc",
  "id" : 855859800885739520,
  "created_at" : "2017-04-22 19:04:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    }, {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 8, 18 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855837892546973698",
  "geo" : { },
  "id_str" : "855839132509130752",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia @Helena_LB let's see which album it will be next year \uD83D\uDE02",
  "id" : 855839132509130752,
  "in_reply_to_status_id" : 855837892546973698,
  "created_at" : "2017-04-22 17:42:04 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Todd",
      "screen_name" : "MatToddChem",
      "indices" : [ 0, 12 ],
      "id_str" : "21448858",
      "id" : 21448858
    }, {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 13, 24 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855832168777400320",
  "geo" : { },
  "id_str" : "855837640200822785",
  "in_reply_to_user_id" : 21448858,
  "text" : "@MatToddChem @lteytelman as a vegetarian that doesn't appeal to me. Tahina is my bacon :D",
  "id" : 855837640200822785,
  "in_reply_to_status_id" : 855832168777400320,
  "created_at" : "2017-04-22 17:36:08 +0000",
  "in_reply_to_screen_name" : "MatToddChem",
  "in_reply_to_user_id_str" : "21448858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 3, 14 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 30, 46 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 16, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855837108044300288",
  "text" : "RT @lteytelman: #sageassembly @gedankenstuecke, \"Everything is better if you put 'open' in front of it Open[Science\/Data\/Access\/Hearts\/Mind\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 14, 30 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sageassembly",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "855831616022757376",
    "text" : "#sageassembly @gedankenstuecke, \"Everything is better if you put 'open' in front of it Open[Science\/Data\/Access\/Hearts\/Minds\/Bar]\".",
    "id" : 855831616022757376,
    "created_at" : "2017-04-22 17:12:12 +0000",
    "user" : {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "protected" : false,
      "id_str" : "1343132275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819433710831472640\/WxJQTMMz_normal.jpg",
      "id" : 1343132275,
      "verified" : false
    }
  },
  "id" : 855837108044300288,
  "created_at" : "2017-04-22 17:34:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/cBv7ChqIh6",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/14xAw2hSwvhpC",
      "display_url" : "giphy.com\/gifs\/14xAw2hSw\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "855835382788771840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60733805057586, -122.334008498726 ]
  },
  "id_str" : "855835671662960640",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB https:\/\/t.co\/cBv7ChqIh6",
  "id" : 855835671662960640,
  "in_reply_to_status_id" : 855835382788771840,
  "created_at" : "2017-04-22 17:28:19 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 38, 47 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/k0Pn6BN2Vb",
      "expanded_url" : "https:\/\/twitter.com\/nshockey\/status\/855833660888555520",
      "display_url" : "twitter.com\/nshockey\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60733805057586, -122.334008498726 ]
  },
  "id_str" : "855834988456968192",
  "text" : "Really appreciate the great work that @open_con is doing! #sageassembly https:\/\/t.co\/k0Pn6BN2Vb",
  "id" : 855834988456968192,
  "created_at" : "2017-04-22 17:25:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "indices" : [ 3, 12 ],
      "id_str" : "621133833",
      "id" : 621133833
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 40, 49 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 96, 112 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Open",
      "indices" : [ 25, 30 ]
    }, {
      "text" : "OpenCon",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855834848522403840",
  "text" : "RT @april_cs: We want an #Open Society! @open_con builds that w\/ diverse perspectives, regions. @gedankenstuecke Give $$$$ to #OpenCon! #sa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenCon",
        "screen_name" : "open_con",
        "indices" : [ 26, 35 ],
        "id_str" : "2452073258",
        "id" : 2452073258
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 82, 98 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Open",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "OpenCon",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "sageassembly",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "855833310492110850",
    "text" : "We want an #Open Society! @open_con builds that w\/ diverse perspectives, regions. @gedankenstuecke Give $$$$ to #OpenCon! #sageassembly",
    "id" : 855833310492110850,
    "created_at" : "2017-04-22 17:18:56 +0000",
    "user" : {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "protected" : false,
      "id_str" : "621133833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847911246137499648\/YEEZitGO_normal.jpg",
      "id" : 621133833,
      "verified" : false
    }
  },
  "id" : 855834848522403840,
  "created_at" : "2017-04-22 17:25:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855831283452305408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731512698793, -122.3340145118327 ]
  },
  "id_str" : "855833839989424128",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks We need to do that more often.",
  "id" : 855833839989424128,
  "in_reply_to_status_id" : 855831283452305408,
  "created_at" : "2017-04-22 17:21:02 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 13, 23 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731512698793, -122.3340145118327 ]
  },
  "id_str" : "855833713107550208",
  "text" : "I challenged @Helena_LB to mention all track titles of Metallica\u2019s Black Album in her closing speech. I owe her a \uD83C\uDF7A! #sageassembly",
  "id" : 855833713107550208,
  "created_at" : "2017-04-22 17:20:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855828293991383040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731348094033, -122.3339990762185 ]
  },
  "id_str" : "855828481422237696",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \u201Cthere\u2019s Elsevier in the sausage?!\u201D",
  "id" : 855828481422237696,
  "in_reply_to_status_id" : 855828293991383040,
  "created_at" : "2017-04-22 16:59:45 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 8, 17 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/ZXRxijqPGh",
      "expanded_url" : "https:\/\/twitter.com\/junanaguy\/status\/855827420175138816",
      "display_url" : "twitter.com\/junanaguy\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732253309695, -122.333986953144 ]
  },
  "id_str" : "855827791085944832",
  "text" : "Hearing @eramirez explain his citation managing workflow. \uD83D\uDE02 https:\/\/t.co\/ZXRxijqPGh",
  "id" : 855827791085944832,
  "created_at" : "2017-04-22 16:57:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Daniela Saderi",
      "screen_name" : "Neurosarda",
      "indices" : [ 12, 23 ],
      "id_str" : "4657994587",
      "id" : 4657994587
    }, {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 24, 34 ],
      "id_str" : "11385492",
      "id" : 11385492
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 35, 51 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 52, 64 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855606056440938496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60744445030355, -122.3340436724223 ]
  },
  "id_str" : "855663540404760576",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @Neurosarda @jillemery @daniellecrobins @denormalize Yay, looking forward to meet all of you again. \uD83D\uDC96",
  "id" : 855663540404760576,
  "in_reply_to_status_id" : 855606056440938496,
  "created_at" : "2017-04-22 06:04:20 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg",
      "screen_name" : "EatYourSoup1",
      "indices" : [ 0, 13 ],
      "id_str" : "824026115513679873",
      "id" : 824026115513679873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855596542098624512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60737468501583, -122.3383639464129 ]
  },
  "id_str" : "855598030728253440",
  "in_reply_to_user_id" : 824026115513679873,
  "text" : "@EatYourSoup1 It\u2019s mine too!",
  "id" : 855598030728253440,
  "in_reply_to_status_id" : 855596542098624512,
  "created_at" : "2017-04-22 01:44:01 +0000",
  "in_reply_to_screen_name" : "EatYourSoup1",
  "in_reply_to_user_id_str" : "824026115513679873",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855596514340593664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.607120304435, -122.3380651538802 ]
  },
  "id_str" : "855597954802958338",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery Will be in town 30th to 3rd. And would love to meet!",
  "id" : 855597954802958338,
  "in_reply_to_status_id" : 855596514340593664,
  "created_at" : "2017-04-22 01:43:43 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg",
      "screen_name" : "EatYourSoup1",
      "indices" : [ 0, 13 ],
      "id_str" : "824026115513679873",
      "id" : 824026115513679873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855583510475792384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60776958224989, -122.3389059541649 ]
  },
  "id_str" : "855596382819827712",
  "in_reply_to_user_id" : 824026115513679873,
  "text" : "@EatYourSoup1 My whole reason for writing the paper ;)",
  "id" : 855596382819827712,
  "in_reply_to_status_id" : 855583510475792384,
  "created_at" : "2017-04-22 01:37:28 +0000",
  "in_reply_to_screen_name" : "EatYourSoup1",
  "in_reply_to_user_id_str" : "824026115513679873",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855595553048084481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60774290581622, -122.3389024222938 ]
  },
  "id_str" : "855596306437292032",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery Thanks for agreeing to do it! \uD83D\uDC96 I\u2019ll be in PDX for csvconf btw!",
  "id" : 855596306437292032,
  "in_reply_to_status_id" : 855595553048084481,
  "created_at" : "2017-04-22 01:37:10 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "indices" : [ 0, 9 ],
      "id_str" : "621133833",
      "id" : 621133833
    }, {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 10, 20 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/855548152039981056\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/KtTE6Mhmht",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C9-Ef-hUIAA75xI.jpg",
      "id_str" : "855548139117223936",
      "id" : 855548139117223936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9-Ef-hUIAA75xI.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/KtTE6Mhmht"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855543432269316096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613405557824, -122.344800433193 ]
  },
  "id_str" : "855548152039981056",
  "in_reply_to_user_id" : 621133833,
  "text" : "@april_cs @kaythaney Oh snap, we\u2019re at here! https:\/\/t.co\/KtTE6Mhmht",
  "id" : 855548152039981056,
  "in_reply_to_status_id" : 855543432269316096,
  "created_at" : "2017-04-21 22:25:49 +0000",
  "in_reply_to_screen_name" : "april_cs",
  "in_reply_to_user_id_str" : "621133833",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MU-Peter Shimon\uD83C\uDC04",
      "screen_name" : "MU_Peter",
      "indices" : [ 0, 9 ],
      "id_str" : "488929910",
      "id" : 488929910
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 25, 34 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 73, 87 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/eCIjh5mBB9",
      "expanded_url" : "http:\/\/www.opencon2017.org\/opencon_2016_toronto",
      "display_url" : "opencon2017.org\/opencon_2016_t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "855525140850987016",
  "geo" : { },
  "id_str" : "855525531231465472",
  "in_reply_to_user_id" : 488929910,
  "text" : "@MU_Peter @Protohedgehog @open_con there was one last year, organized by @lorrainechu3n! https:\/\/t.co\/eCIjh5mBB9",
  "id" : 855525531231465472,
  "in_reply_to_status_id" : 855525140850987016,
  "created_at" : "2017-04-21 20:55:56 +0000",
  "in_reply_to_screen_name" : "MU_Peter",
  "in_reply_to_user_id_str" : "488929910",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/1tF2TVZMJ1",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/854612584305233920",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731763132903, -122.3340218200517 ]
  },
  "id_str" : "855518818600275968",
  "text" : "Last 12 hours to vote on this one: https:\/\/t.co\/1tF2TVZMJ1",
  "id" : 855518818600275968,
  "created_at" : "2017-04-21 20:29:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "indices" : [ 3, 15 ],
      "id_str" : "561297215",
      "id" : 561297215
    }, {
      "name" : "Kieran Samuk",
      "screen_name" : "ksamuk",
      "indices" : [ 17, 24 ],
      "id_str" : "2294753461",
      "id" : 2294753461
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jrossibarra\/status\/855472198974296064\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/WGTFf8KBUw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C98_YbJUMAAfqQx.jpg",
      "id_str" : "855472143059922944",
      "id" : 855472143059922944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C98_YbJUMAAfqQx.jpg",
      "sizes" : [ {
        "h" : 529,
        "resize" : "fit",
        "w" : 707
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 707
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 707
      } ],
      "display_url" : "pic.twitter.com\/WGTFf8KBUw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855518190033551360",
  "text" : "RT @jrossibarra: @ksamuk I can help explain with a Venn diagram. https:\/\/t.co\/WGTFf8KBUw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kieran Samuk",
        "screen_name" : "ksamuk",
        "indices" : [ 0, 7 ],
        "id_str" : "2294753461",
        "id" : 2294753461
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jrossibarra\/status\/855472198974296064\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/WGTFf8KBUw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C98_YbJUMAAfqQx.jpg",
        "id_str" : "855472143059922944",
        "id" : 855472143059922944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C98_YbJUMAAfqQx.jpg",
        "sizes" : [ {
          "h" : 529,
          "resize" : "fit",
          "w" : 707
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 707
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 707
        } ],
        "display_url" : "pic.twitter.com\/WGTFf8KBUw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "855453280922677249",
    "geo" : { },
    "id_str" : "855472198974296064",
    "in_reply_to_user_id" : 2294753461,
    "text" : "@ksamuk I can help explain with a Venn diagram. https:\/\/t.co\/WGTFf8KBUw",
    "id" : 855472198974296064,
    "in_reply_to_status_id" : 855453280922677249,
    "created_at" : "2017-04-21 17:24:00 +0000",
    "in_reply_to_screen_name" : "ksamuk",
    "in_reply_to_user_id_str" : "2294753461",
    "user" : {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "protected" : false,
      "id_str" : "561297215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656691317519466496\/tJ966bzU_normal.png",
      "id" : 561297215,
      "verified" : false
    }
  },
  "id" : 855518190033551360,
  "created_at" : "2017-04-21 20:26:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran Samuk",
      "screen_name" : "ksamuk",
      "indices" : [ 3, 10 ],
      "id_str" : "2294753461",
      "id" : 2294753461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855518165782089728",
  "text" : "RT @ksamuk: biologists: pie charts are bad because they are hard to read! \nalso biologists: anyway, here's a crazy circos plot of 10 vars a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ksamuk\/status\/855453280922677249\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/3XdnQjqAR7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C98tfenXUAMU7EX.jpg",
        "id_str" : "855452473041047555",
        "id" : 855452473041047555,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C98tfenXUAMU7EX.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/3XdnQjqAR7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "855453280922677249",
    "text" : "biologists: pie charts are bad because they are hard to read! \nalso biologists: anyway, here's a crazy circos plot of 10 vars across genome. https:\/\/t.co\/3XdnQjqAR7",
    "id" : 855453280922677249,
    "created_at" : "2017-04-21 16:08:50 +0000",
    "user" : {
      "name" : "Kieran Samuk",
      "screen_name" : "ksamuk",
      "protected" : false,
      "id_str" : "2294753461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495261732613271553\/4P6Xqrwv_normal.jpeg",
      "id" : 2294753461,
      "verified" : false
    }
  },
  "id" : 855518165782089728,
  "created_at" : "2017-04-21 20:26:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    }, {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 13, 23 ],
      "id_str" : "267256091",
      "id" : 267256091
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 24, 36 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855515069337096192",
  "geo" : { },
  "id_str" : "855515288506216448",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke @_inundata @froggleston and I'd be totally up for that, it's been too long folks!",
  "id" : 855515288506216448,
  "in_reply_to_status_id" : 855515069337096192,
  "created_at" : "2017-04-21 20:15:14 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855513901319962624",
  "text" : "RT @JBYoder: \u201CMaybe scientists' refusal to acknowledge and engage with politics is part of the reason things have gotten so dire\" https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9Q33jVxAFL",
        "expanded_url" : "http:\/\/www.thestranger.com\/slog\/2017\/04\/21\/25099607\/the-march-for-science-shows-how-bad-scientists-are-at-politics",
        "display_url" : "thestranger.com\/slog\/2017\/04\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "855510326141476864",
    "text" : "\u201CMaybe scientists' refusal to acknowledge and engage with politics is part of the reason things have gotten so dire\" https:\/\/t.co\/9Q33jVxAFL",
    "id" : 855510326141476864,
    "created_at" : "2017-04-21 19:55:31 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 855513901319962624,
  "created_at" : "2017-04-21 20:09:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855509964017680384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732203838459, -122.3339905745809 ]
  },
  "id_str" : "855510071425486848",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke You should have offered that earlier, now I already got my flights back!",
  "id" : 855510071425486848,
  "in_reply_to_status_id" : 855509964017680384,
  "created_at" : "2017-04-21 19:54:30 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/QON47zwrQ2",
      "expanded_url" : "https:\/\/genomequilts.com\/quilts\/genome-quilts-3\/",
      "display_url" : "genomequilts.com\/quilts\/genome-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6072719281761, -122.3339763832901 ]
  },
  "id_str" : "855506985927688193",
  "text" : "For the personal genome knitters: have a look at the Genome Quilts. https:\/\/t.co\/QON47zwrQ2 #sageassembly",
  "id" : 855506985927688193,
  "created_at" : "2017-04-21 19:42:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855506515515527168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6072719281761, -122.3339763832901 ]
  },
  "id_str" : "855506799633457152",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke Totally, but I\u2019m missing you here. Especially next week when I\u2019ll be in PDX again!",
  "id" : 855506799633457152,
  "in_reply_to_status_id" : 855506515515527168,
  "created_at" : "2017-04-21 19:41:30 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u1ECA\u1ECAy Meinke",
      "screen_name" : "billymeinke",
      "indices" : [ 0, 12 ],
      "id_str" : "296003222",
      "id" : 296003222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855499526597033985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60730993765667, -122.333990598741 ]
  },
  "id_str" : "855504748715294720",
  "in_reply_to_user_id" : 296003222,
  "text" : "@billymeinke Hi Billy \uD83D\uDC4B",
  "id" : 855504748715294720,
  "in_reply_to_status_id" : 855499526597033985,
  "created_at" : "2017-04-21 19:33:21 +0000",
  "in_reply_to_screen_name" : "billymeinke",
  "in_reply_to_user_id_str" : "296003222",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fbz",
      "screen_name" : "fbz",
      "indices" : [ 16, 20 ],
      "id_str" : "15282432",
      "id" : 15282432
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732368403772, -122.3340012803124 ]
  },
  "id_str" : "855503356034334720",
  "text" : "Awesome to hear @fbz talk about how she seized the means of production with a knitting machine. \uD83D\uDC96 #sageassembly",
  "id" : 855503356034334720,
  "created_at" : "2017-04-21 19:27:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/RfT9iDvYT6",
      "expanded_url" : "https:\/\/twitter.com\/Magda_Skipper\/status\/855492707837292548",
      "display_url" : "twitter.com\/Magda_Skipper\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "855494696247762944",
  "text" : "Not only the case for legal reasons. Just try to transfer some terabytes of data to Australia. Quickest way is snail mail. #sageassembly https:\/\/t.co\/RfT9iDvYT6",
  "id" : 855494696247762944,
  "created_at" : "2017-04-21 18:53:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/OU0EiS4J4O",
      "expanded_url" : "https:\/\/www.wired.com\/2017\/04\/geneticists-fear-illuminas-sequencers-may-distort-results\/",
      "display_url" : "wired.com\/2017\/04\/geneti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "855493819055222785",
  "text" : "RT @pathogenomenick: And then ... after all that work, we decided to do some basic negative controls! https:\/\/t.co\/OU0EiS4J4O https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/855177900043194369\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/t0iR5JQYqN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C94ztSbXoAAQSzy.jpg",
        "id_str" : "855177832380735488",
        "id" : 855177832380735488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C94ztSbXoAAQSzy.jpg",
        "sizes" : [ {
          "h" : 368,
          "resize" : "fit",
          "w" : 1076
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 1076
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 1076
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/t0iR5JQYqN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/OU0EiS4J4O",
        "expanded_url" : "https:\/\/www.wired.com\/2017\/04\/geneticists-fear-illuminas-sequencers-may-distort-results\/",
        "display_url" : "wired.com\/2017\/04\/geneti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "855177900043194369",
    "text" : "And then ... after all that work, we decided to do some basic negative controls! https:\/\/t.co\/OU0EiS4J4O https:\/\/t.co\/t0iR5JQYqN",
    "id" : 855177900043194369,
    "created_at" : "2017-04-20 21:54:34 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 855493819055222785,
  "created_at" : "2017-04-21 18:49:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 21, 34 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731862292248, -122.3339815248161 ]
  },
  "id_str" : "855468609425899521",
  "text" : "\u2018Don\u2019t bullshit me\u2019 (@MishaAngrist) sounds like a general rule to live by, not only for research participation. #sageassembly",
  "id" : 855468609425899521,
  "created_at" : "2017-04-21 17:09:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 14, 27 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731416777595, -122.333989911977 ]
  },
  "id_str" : "855467210428489728",
  "text" : "So jealous of @MishaAngrist\u2019s new job title: Director of Translational Cynicism  #sageassembly",
  "id" : 855467210428489728,
  "created_at" : "2017-04-21 17:04:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kadija Ferryman, PhD",
      "screen_name" : "KadijaFerryman",
      "indices" : [ 7, 22 ],
      "id_str" : "578252814",
      "id" : 578252814
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855464058186747904",
  "text" : "Thanks @KadijaFerryman for a great talk on the gift giving dynamics of data. #sageassembly",
  "id" : 855464058186747904,
  "created_at" : "2017-04-21 16:51:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "scann",
      "screen_name" : "scannopolis",
      "indices" : [ 107, 119 ],
      "id_str" : "759561529",
      "id" : 759561529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855456604187090945",
  "text" : "RT @bella_velo: \"There is a proper and specific value in diversity.\" The gender gap in the open movement \/ @scannopolis https:\/\/t.co\/oAIhRs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "scann",
        "screen_name" : "scannopolis",
        "indices" : [ 91, 103 ],
        "id_str" : "759561529",
        "id" : 759561529
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/oAIhRsrrgn",
        "expanded_url" : "http:\/\/www.genderit.org\/feminist-talk\/column-open-software-movements-open-content-free-culture-where-are-women",
        "display_url" : "genderit.org\/feminist-talk\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "855456205069668352",
    "text" : "\"There is a proper and specific value in diversity.\" The gender gap in the open movement \/ @scannopolis https:\/\/t.co\/oAIhRsrrgn",
    "id" : 855456205069668352,
    "created_at" : "2017-04-21 16:20:27 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 855456604187090945,
  "created_at" : "2017-04-21 16:22:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 0, 9 ],
      "id_str" : "16728620",
      "id" : 16728620
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 60, 74 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855453521738571776",
  "geo" : { },
  "id_str" : "855453731298566144",
  "in_reply_to_user_id" : 16728620,
  "text" : "@nshockey no problem! Was a lot of people after all! But as @Protohedgehog isn't around I wanted to give a second face to talk to locally :)",
  "id" : 855453731298566144,
  "in_reply_to_status_id" : 855453521738571776,
  "created_at" : "2017-04-21 16:10:37 +0000",
  "in_reply_to_screen_name" : "nshockey",
  "in_reply_to_user_id_str" : "16728620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hekler",
      "screen_name" : "ehekler",
      "indices" : [ 0, 8 ],
      "id_str" : "136385823",
      "id" : 136385823
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 24, 33 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855451673040371712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60734016641527, -122.3339870661839 ]
  },
  "id_str" : "855451905199194112",
  "in_reply_to_user_id" : 136385823,
  "text" : "@ehekler @Protohedgehog @nshockey Sure, let\u2019s do that over coffee!",
  "id" : 855451905199194112,
  "in_reply_to_status_id" : 855451673040371712,
  "created_at" : "2017-04-21 16:03:22 +0000",
  "in_reply_to_screen_name" : "ehekler",
  "in_reply_to_user_id_str" : "136385823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Farley",
      "screen_name" : "ashleydfarley",
      "indices" : [ 0, 14 ],
      "id_str" : "3931240040",
      "id" : 3931240040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855450682299621378",
  "geo" : { },
  "id_str" : "855451166754226176",
  "in_reply_to_user_id" : 3931240040,
  "text" : "@ashleydfarley that was me, being the \"young\" person on the board :P",
  "id" : 855451166754226176,
  "in_reply_to_status_id" : 855450682299621378,
  "created_at" : "2017-04-21 16:00:26 +0000",
  "in_reply_to_screen_name" : "ashleydfarley",
  "in_reply_to_user_id_str" : "3931240040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 19, 33 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 78, 87 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855451003771953153",
  "text" : "Come &amp; talk to @Protohedgehog and me if you want to know about hosting an @open_con satellite, we've done one in Berlin. #sageassembly",
  "id" : 855451003771953153,
  "created_at" : "2017-04-21 15:59:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 5, 14 ],
      "id_str" : "16728620",
      "id" : 16728620
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 50, 59 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731540414566, -122.3339934102238 ]
  },
  "id_str" : "855446717063340032",
  "text" : "Now: @nshockey presenting some success stories of @open_con #sageassembly",
  "id" : 855446717063340032,
  "created_at" : "2017-04-21 15:42:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/855446215764328448\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/aoQyxEwThr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C98nw6pV0AANpYZ.jpg",
      "id_str" : "855446175553540096",
      "id" : 855446175553540096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C98nw6pV0AANpYZ.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/aoQyxEwThr"
    } ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 22, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60729628325424, -122.3340025792836 ]
  },
  "id_str" : "855446215764328448",
  "text" : "The wheel of open* at #sageassembly https:\/\/t.co\/aoQyxEwThr",
  "id" : 855446215764328448,
  "created_at" : "2017-04-21 15:40:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855444368559230976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6073150260088, -122.3340284962823 ]
  },
  "id_str" : "855444467158982656",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB Where do I have to meet you? :D",
  "id" : 855444467158982656,
  "in_reply_to_status_id" : 855444368559230976,
  "created_at" : "2017-04-21 15:33:49 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855442956228198400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6073150260088, -122.3340284962823 ]
  },
  "id_str" : "855444006079037440",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB Tattoos?!",
  "id" : 855444006079037440,
  "in_reply_to_status_id" : 855442956228198400,
  "created_at" : "2017-04-21 15:31:59 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/aXqtUiH83b",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/6-541\/v1",
      "display_url" : "f1000research.com\/articles\/6-541\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60740555701763, -122.3323217470717 ]
  },
  "id_str" : "855428039450046464",
  "text" : "My pre-print on the content of Sci-Hub and its Usage made it to F1000 Research, awaiting reviewers\u2019 comments! https:\/\/t.co\/aXqtUiH83b",
  "id" : 855428039450046464,
  "created_at" : "2017-04-21 14:28:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/zCQOWcRSfM",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/marimba-rasta\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/marim\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60740555701763, -122.3323217470717 ]
  },
  "id_str" : "855427800005660672",
  "text" : "Something to support if you love Marimba \uD83D\uDE02 https:\/\/t.co\/zCQOWcRSfM",
  "id" : 855427800005660672,
  "created_at" : "2017-04-21 14:27:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855299018905092096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60748891257418, -122.3324013289288 ]
  },
  "id_str" : "855299094029324288",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \uD83D\uDC4Dgood night!",
  "id" : 855299094029324288,
  "in_reply_to_status_id" : 855299018905092096,
  "created_at" : "2017-04-21 05:56:09 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855298740831137792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60751889616409, -122.3321777582098 ]
  },
  "id_str" : "855298901724717056",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez okay for me. Feeling \uD83D\uDCA4 now thanks to the jet lag!",
  "id" : 855298901724717056,
  "in_reply_to_status_id" : 855298740831137792,
  "created_at" : "2017-04-21 05:55:23 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Agaricus",
      "screen_name" : "agaricus",
      "indices" : [ 25, 34 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Eric Hekler",
      "screen_name" : "ehekler",
      "indices" : [ 35, 43 ],
      "id_str" : "136385823",
      "id" : 136385823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855199665083498496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60904652536624, -122.3325106223322 ]
  },
  "id_str" : "855281278119063552",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @eramirez @agaricus @ehekler has this now been moved to tomorrow? :p",
  "id" : 855281278119063552,
  "in_reply_to_status_id" : 855199665083498496,
  "created_at" : "2017-04-21 04:45:21 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 0, 7 ],
      "id_str" : "71654283",
      "id" : 71654283
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 8, 17 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/GYsxGVVa4Y",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/bird-explosion-parakeet-ceHKRKMR6Ojao",
      "display_url" : "giphy.com\/gifs\/bird-expl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "855223696025309184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60733172680614, -122.3339917125158 ]
  },
  "id_str" : "855224733821837312",
  "in_reply_to_user_id" : 71654283,
  "text" : "@arikia @wilbanks sounds about right! https:\/\/t.co\/GYsxGVVa4Y",
  "id" : 855224733821837312,
  "in_reply_to_status_id" : 855223696025309184,
  "created_at" : "2017-04-21 01:00:40 +0000",
  "in_reply_to_screen_name" : "arikia",
  "in_reply_to_user_id_str" : "71654283",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731970956714, -122.3339911445672 ]
  },
  "id_str" : "855219865686204416",
  "text" : "\u00ABI\u2019ve been working at CRI for 10 years and still don\u2019t really know what the institute is about.\u00BB \uD83D\uDE02 #sageassembly",
  "id" : 855219865686204416,
  "created_at" : "2017-04-21 00:41:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 15, 25 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855213287142809605",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732794395155, -122.3340204341709 ]
  },
  "id_str" : "855213525014151168",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @Helena_LB do it your way: start digging to find me :p",
  "id" : 855213525014151168,
  "in_reply_to_status_id" : 855213287142809605,
  "created_at" : "2017-04-21 00:16:08 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855208714277486592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60728527045997, -122.3339934076737 ]
  },
  "id_str" : "855212005900156928",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog I guess from them no one expects anything else \uD83D\uDE0B",
  "id" : 855212005900156928,
  "in_reply_to_status_id" : 855208714277486592,
  "created_at" : "2017-04-21 00:10:05 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 11, 21 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855207026393329664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6073132875001, -122.3340009268189 ]
  },
  "id_str" : "855211450490540032",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Hao_and_Y will take you up on that!",
  "id" : 855211450490540032,
  "in_reply_to_status_id" : 855207026393329664,
  "created_at" : "2017-04-21 00:07:53 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 11, 21 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855206102950170625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732657173669, -122.3340131015334 ]
  },
  "id_str" : "855206487349633024",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Hao_and_Y guess need to visit you :D",
  "id" : 855206487349633024,
  "in_reply_to_status_id" : 855206102950170625,
  "created_at" : "2017-04-20 23:48:10 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 11, 21 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855205597595275264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732657173669, -122.3340131015334 ]
  },
  "id_str" : "855206322777739264",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Hao_and_Y aye, that\u2019s a discussion to have over a \uD83C\uDF7B.",
  "id" : 855206322777739264,
  "in_reply_to_status_id" : 855205597595275264,
  "created_at" : "2017-04-20 23:47:30 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 11, 21 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855205470382026752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732657173669, -122.3340131015334 ]
  },
  "id_str" : "855205900717445120",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Hao_and_Y agree on that, guess my point here is partly lost w\/o having the original statement.",
  "id" : 855205900717445120,
  "in_reply_to_status_id" : 855205470382026752,
  "created_at" : "2017-04-20 23:45:50 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 11, 21 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855204400742227968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732257044721, -122.334008125734 ]
  },
  "id_str" : "855205127824658432",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Hao_and_Y sure, but don\u2019t see anything wrong with finding it suspect if people are only in it for the money.",
  "id" : 855205127824658432,
  "in_reply_to_status_id" : 855204400742227968,
  "created_at" : "2017-04-20 23:42:46 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732257044721, -122.334008125734 ]
  },
  "id_str" : "855204719601504256",
  "text" : "\u00ABPeople don\u2019t appreciate how bad our data in biomed are.\u00BB Aye, nothing better then this to turn you into a nihilist. #sageassembly",
  "id" : 855204719601504256,
  "created_at" : "2017-04-20 23:41:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 11, 21 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855202871150772224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731432764123, -122.3340153199651 ]
  },
  "id_str" : "855203580256501761",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Hao_and_Y wrong way: \u201Cthis needs to have direct (financial\/outcome) benefits, this is why we do it\u201D",
  "id" : 855203580256501761,
  "in_reply_to_status_id" : 855202871150772224,
  "created_at" : "2017-04-20 23:36:37 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 11, 21 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855202871150772224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731432764123, -122.3340153199651 ]
  },
  "id_str" : "855203386924310528",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @Hao_and_Y yes, just see the framing as wrong way around, right way: \u201CThis is the right thing, that\u2019s why we incentivize it\u201D",
  "id" : 855203386924310528,
  "in_reply_to_status_id" : 855202871150772224,
  "created_at" : "2017-04-20 23:35:51 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean \uD83D\uDC68\u200D\uD83D\uDCBB",
      "screen_name" : "JeanManguy",
      "indices" : [ 0, 11 ],
      "id_str" : "2924006571",
      "id" : 2924006571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855201838693593090",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60735762414992, -122.3340218096897 ]
  },
  "id_str" : "855202184685735936",
  "in_reply_to_user_id" : 2924006571,
  "text" : "@JeanManguy don\u2019t know. Often ethical obligations are translated into legal obligations as well? Wouldn\u2019t call that \u201Cincentive\u201D any longer \uD83D\uDE09",
  "id" : 855202184685735936,
  "in_reply_to_status_id" : 855201838693593090,
  "created_at" : "2017-04-20 23:31:04 +0000",
  "in_reply_to_screen_name" : "JeanManguy",
  "in_reply_to_user_id_str" : "2924006571",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855200951661207552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60738487671802, -122.333969274479 ]
  },
  "id_str" : "855201831479255040",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 relying on incentives is just a very wobbly base to build your conduct upon.",
  "id" : 855201831479255040,
  "in_reply_to_status_id" : 855200951661207552,
  "created_at" : "2017-04-20 23:29:40 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leila Jamal",
      "screen_name" : "jamalenator",
      "indices" : [ 3, 15 ],
      "id_str" : "19053598",
      "id" : 19053598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855201357480943616",
  "text" : "RT @jamalenator: #sageassembly journalist Arikia Millian:  no news reader has ever said \"show me an unskippable ad and then lie to me\" - to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sageassembly",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "855201088907100160",
    "text" : "#sageassembly journalist Arikia Millian:  no news reader has ever said \"show me an unskippable ad and then lie to me\" - touch\u00E9!",
    "id" : 855201088907100160,
    "created_at" : "2017-04-20 23:26:43 +0000",
    "user" : {
      "name" : "Leila Jamal",
      "screen_name" : "jamalenator",
      "protected" : false,
      "id_str" : "19053598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826084099525840901\/VMmBfPn5_normal.jpg",
      "id" : 19053598,
      "verified" : false
    }
  },
  "id" : 855201357480943616,
  "created_at" : "2017-04-20 23:27:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Hekler",
      "screen_name" : "ehekler",
      "indices" : [ 0, 8 ],
      "id_str" : "136385823",
      "id" : 136385823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855200043439083520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60736232996023, -122.3340236551911 ]
  },
  "id_str" : "855200784614531072",
  "in_reply_to_user_id" : 136385823,
  "text" : "@ehekler sure, but implementation is step 2 after acknowledging the ethical obligation to doing the right thing?",
  "id" : 855200784614531072,
  "in_reply_to_status_id" : 855200043439083520,
  "created_at" : "2017-04-20 23:25:30 +0000",
  "in_reply_to_screen_name" : "ehekler",
  "in_reply_to_user_id_str" : "136385823",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6073669151297, -122.3339822772529 ]
  },
  "id_str" : "855199522573623297",
  "text" : "Maybe just me, but I\u2019d prefer if MD\/researchers did the right thing out of ethical consideration than due to incentives. \uD83E\uDD37\u200D\u2640\uFE0F #sageassembly",
  "id" : 855199522573623297,
  "created_at" : "2017-04-20 23:20:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 11, 25 ],
      "id_str" : "19216179",
      "id" : 19216179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/34qmHhhhAT",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/785904798977691648",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732406940495, -122.3340038742331 ]
  },
  "id_str" : "855197519613001729",
  "text" : "Related to @stevenkeating\u2019s data access stories: What happened when I asked 23andMe for my data. #sageassembly https:\/\/t.co\/34qmHhhhAT",
  "id" : 855197519613001729,
  "created_at" : "2017-04-20 23:12:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 11, 20 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Justin Kiggins",
      "screen_name" : "neuromusic",
      "indices" : [ 21, 32 ],
      "id_str" : "8932272",
      "id" : 8932272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855194757659840513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60730705911514, -122.3340238025591 ]
  },
  "id_str" : "855195313195302912",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @eramirez @neuromusic I think that\u2019s even a rather easy album to pull that one off. \uD83D\uDE02",
  "id" : 855195313195302912,
  "in_reply_to_status_id" : 855194757659840513,
  "created_at" : "2017-04-20 23:03:46 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 5, 12 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60736834686172, -122.3340659946556 ]
  },
  "id_str" : "855194646925803520",
  "text" : "Now: @arikia on seeking truth instead of seeking profit as a mode of journalism. #sageassembly",
  "id" : 855194646925803520,
  "created_at" : "2017-04-20 23:01:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 11, 20 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Justin Kiggins",
      "screen_name" : "neuromusic",
      "indices" : [ 21, 32 ],
      "id_str" : "8932272",
      "id" : 8932272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855192891316154369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60733552546631, -122.3339922434756 ]
  },
  "id_str" : "855193417311113216",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @eramirez @neuromusic I\u2019ll buy a drink if you can casually drop the titles of all Black Album tracks into your talk ;)",
  "id" : 855193417311113216,
  "in_reply_to_status_id" : 855192891316154369,
  "created_at" : "2017-04-20 22:56:14 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    }, {
      "name" : "Elizabeth Yeampierre",
      "screen_name" : "yeampierre",
      "indices" : [ 78, 89 ],
      "id_str" : "422104815",
      "id" : 422104815
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855192549249630208",
  "text" : "RT @kaythaney: \"If not everyone is at the table, then the table's not set.\" - @yeampierre",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elizabeth Yeampierre",
        "screen_name" : "yeampierre",
        "indices" : [ 63, 74 ],
        "id_str" : "422104815",
        "id" : 422104815
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "855192165911117826",
    "text" : "\"If not everyone is at the table, then the table's not set.\" - @yeampierre",
    "id" : 855192165911117826,
    "created_at" : "2017-04-20 22:51:15 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 855192549249630208,
  "created_at" : "2017-04-20 22:52:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 11, 20 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Justin Kiggins",
      "screen_name" : "neuromusic",
      "indices" : [ 21, 32 ],
      "id_str" : "8932272",
      "id" : 8932272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855191693167120386",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732303833074, -122.3340016027575 ]
  },
  "id_str" : "855192502575407104",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @eramirez @neuromusic \u201CI think Metallica said it best: kill \u2018em all!\u201D?",
  "id" : 855192502575407104,
  "in_reply_to_status_id" : 855191693167120386,
  "created_at" : "2017-04-20 22:52:35 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/KtUw5zCEwF",
      "expanded_url" : "https:\/\/twitter.com\/april_cs\/status\/855190260833177600",
      "display_url" : "twitter.com\/april_cs\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60733015559938, -122.3340159268439 ]
  },
  "id_str" : "855190628430299136",
  "text" : "True for all fields of leadership, disconnect between these things a common theme. #sageassembly https:\/\/t.co\/KtUw5zCEwF",
  "id" : 855190628430299136,
  "created_at" : "2017-04-20 22:45:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/855180181492781056\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/OQwYC1oUps",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C94112NUIAAM-zZ.jpg",
      "id_str" : "855180178447671296",
      "id" : 855180178447671296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C94112NUIAAM-zZ.jpg",
      "sizes" : [ {
        "h" : 377,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OQwYC1oUps"
    } ],
    "hashtags" : [ {
      "text" : "sageassembly",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "855180181492781056",
  "text" : "Our progress towards open* #sageassembly https:\/\/t.co\/OQwYC1oUps",
  "id" : 855180181492781056,
  "created_at" : "2017-04-20 22:03:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 7, 16 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855172475361021952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60735043861126, -122.3340019458303 ]
  },
  "id_str" : "855172845495660544",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw @wilbanks fair enough. I heard it\u2019s hard to get any good coffee in this town \uD83D\uDE0B",
  "id" : 855172845495660544,
  "in_reply_to_status_id" : 855172475361021952,
  "created_at" : "2017-04-20 21:34:29 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 7, 16 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855170930254823424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60732681157404, -122.3340198167292 ]
  },
  "id_str" : "855172140127186945",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw @wilbanks is that a real question when addressed to me? \uD83D\uDE09",
  "id" : 855172140127186945,
  "in_reply_to_status_id" : 855170930254823424,
  "created_at" : "2017-04-20 21:31:41 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855170176735731714",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731348399316, -122.3340138428637 ]
  },
  "id_str" : "855170264883122176",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn looking forward to it! \uD83D\uDC96\uD83D\uDE0D",
  "id" : 855170264883122176,
  "in_reply_to_status_id" : 855170176735731714,
  "created_at" : "2017-04-20 21:24:14 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 7, 16 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855169774589956100",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60731348399316, -122.3340138428637 ]
  },
  "id_str" : "855170179923181568",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw @wilbanks exactly two months until I finally get her photo 51 tattooed! \uD83D\uDE0D",
  "id" : 855170179923181568,
  "in_reply_to_status_id" : 855169774589956100,
  "created_at" : "2017-04-20 21:23:53 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 24, 33 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/zKuDoLZbhT",
      "expanded_url" : "https:\/\/www.rachelignotofskydesign.com\/free-downloads\/",
      "display_url" : "rachelignotofskydesign.com\/free-downloads\/"
    } ]
  },
  "in_reply_to_status_id_str" : "855166234790248448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60736395978123, -122.3340040743765 ]
  },
  "id_str" : "855166925315350528",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw i like this one! @wilbanks https:\/\/t.co\/zKuDoLZbhT",
  "id" : 855166925315350528,
  "in_reply_to_status_id" : 855166234790248448,
  "created_at" : "2017-04-20 21:10:57 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855138357806084098",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60733362948843, -122.3340005100725 ]
  },
  "id_str" : "855165642504232960",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a please do. I went because I camped next to the AT&amp;T store waiting for it to open. :p",
  "id" : 855165642504232960,
  "in_reply_to_status_id" : 855138357806084098,
  "created_at" : "2017-04-20 21:05:52 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855117550627291137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60896589145773, -122.339690812046 ]
  },
  "id_str" : "855117835072188416",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 don\u2019t want to start a war on their turf, it\u2019s their heartland after all \uD83D\uDE0B",
  "id" : 855117835072188416,
  "in_reply_to_status_id" : 855117550627291137,
  "created_at" : "2017-04-20 17:55:53 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855117245562970112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60902467046022, -122.3397283215042 ]
  },
  "id_str" : "855117471866474496",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 took all my willpower, but I resisted the urge.",
  "id" : 855117471866474496,
  "in_reply_to_status_id" : 855117245562970112,
  "created_at" : "2017-04-20 17:54:27 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60908331366478, -122.3396540231951 ]
  },
  "id_str" : "855114605068075008",
  "text" : "Barista at Starbucks asked whether I was in town for the Global Specialty Coffee Expo. \uD83E\uDD14",
  "id" : 855114605068075008,
  "created_at" : "2017-04-20 17:43:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Geoff Boeing",
      "screen_name" : "gboeing",
      "indices" : [ 10, 18 ],
      "id_str" : "15290609",
      "id" : 15290609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/MEZk4LxJlt",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/04\/10\/124495",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "855104041679847425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60977495350147, -122.3375737956824 ]
  },
  "id_str" : "855108117071183873",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @gboeing preprint at https:\/\/t.co\/MEZk4LxJlt :)",
  "id" : 855108117071183873,
  "in_reply_to_status_id" : 855104041679847425,
  "created_at" : "2017-04-20 17:17:16 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/855107971251974144\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/fKxVQ9mO4U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C930JwyUAAAh7oj.jpg",
      "id_str" : "855107952822190080",
      "id" : 855107952822190080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C930JwyUAAAh7oj.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fKxVQ9mO4U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6096993145506, -122.3377055281183 ]
  },
  "id_str" : "855107971251974144",
  "text" : "Outdoor essentials means different things for different people. https:\/\/t.co\/fKxVQ9mO4U",
  "id" : 855107971251974144,
  "created_at" : "2017-04-20 17:16:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/y4eRMMzPSl",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTHU2l6FrCG\/",
      "display_url" : "instagram.com\/p\/BTHU2l6FrCG\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608055555556, -122.33611111111 ]
  },
  "id_str" : "855101174550327296",
  "text" : "Heavily disappointed by this kind of dogs though. Despite the name. \uD83D\uDE31 @ Downtown Seattle https:\/\/t.co\/y4eRMMzPSl",
  "id" : 855101174550327296,
  "created_at" : "2017-04-20 16:49:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855095673359925248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60741092470191, -122.3323089806676 ]
  },
  "id_str" : "855095744608337920",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg mh, wer kommt noch mit? :)",
  "id" : 855095744608337920,
  "in_reply_to_status_id" : 855095673359925248,
  "created_at" : "2017-04-20 16:28:07 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855029955381669890",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60741107146814, -122.3323097232953 ]
  },
  "id_str" : "855095261470703617",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg omg, wann? \uD83D\uDE0D",
  "id" : 855095261470703617,
  "in_reply_to_status_id" : 855029955381669890,
  "created_at" : "2017-04-20 16:26:11 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/6dEz7sj4PD",
      "expanded_url" : "http:\/\/gif-finder.com\/wp-content\/uploads\/2016\/01\/Cat-and-Dog-Play-Chess.gif",
      "display_url" : "gif-finder.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "855093011793027073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6073992452793, -122.3323123306151 ]
  },
  "id_str" : "855094550351589376",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField there are too many jokes to do with that one, but I can totally do that! https:\/\/t.co\/6dEz7sj4PD",
  "id" : 855094550351589376,
  "in_reply_to_status_id" : 855093011793027073,
  "created_at" : "2017-04-20 16:23:22 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/855092611475845120\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/P51AeH97Q3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C93mLwLUQAAKxzL.jpg",
      "id_str" : "855092593855578112",
      "id" : 855092593855578112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C93mLwLUQAAKxzL.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/P51AeH97Q3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60758831656948, -122.3318935033282 ]
  },
  "id_str" : "855092611475845120",
  "text" : "Please check me in into the doggy day care! \uD83D\uDE0D https:\/\/t.co\/P51AeH97Q3",
  "id" : 855092611475845120,
  "created_at" : "2017-04-20 16:15:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854649066713755649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61057823435181, -122.335721310342 ]
  },
  "id_str" : "855091892454801408",
  "in_reply_to_user_id" : 14286491,
  "text" : "Went with AT&amp;T, for my own future reference.",
  "id" : 855091892454801408,
  "in_reply_to_status_id" : 854649066713755649,
  "created_at" : "2017-04-20 16:12:48 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "open_epi",
      "screen_name" : "april_cs",
      "indices" : [ 0, 9 ],
      "id_str" : "621133833",
      "id" : 621133833
    }, {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 10, 19 ],
      "id_str" : "16728620",
      "id" : 16728620
    }, {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 20, 30 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "855082757592014848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60959867495716, -122.3377090993925 ]
  },
  "id_str" : "855082987355987969",
  "in_reply_to_user_id" : 621133833,
  "text" : "@april_cs @nshockey @kaythaney \uD83D\uDE0D",
  "id" : 855082987355987969,
  "in_reply_to_status_id" : 855082757592014848,
  "created_at" : "2017-04-20 15:37:25 +0000",
  "in_reply_to_screen_name" : "april_cs",
  "in_reply_to_user_id_str" : "621133833",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 15, 24 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Agaricus",
      "screen_name" : "agaricus",
      "indices" : [ 25, 34 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854931972799385600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60744026848727, -122.3323468536633 ]
  },
  "id_str" : "855054812206870530",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @eramirez @agaricus I\u2019ll be in town until midnight of 24th!",
  "id" : 855054812206870530,
  "in_reply_to_status_id" : 854931972799385600,
  "created_at" : "2017-04-20 13:45:28 +0000",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/1tF2TVZMJ1",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/854612584305233920",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "854612584305233920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60744027056755, -122.3323468584563 ]
  },
  "id_str" : "855054345947168768",
  "in_reply_to_user_id" : 14286491,
  "text" : "For the European crowd, if you haven\u2019t voted yet: https:\/\/t.co\/1tF2TVZMJ1",
  "id" : 855054345947168768,
  "in_reply_to_status_id" : 854612584305233920,
  "created_at" : "2017-04-20 13:43:36 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854875498282795008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.43900004286245, -122.3026872532052 ]
  },
  "id_str" : "854878827255742464",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog what are dinner plans? :)",
  "id" : 854878827255742464,
  "in_reply_to_status_id" : 854875498282795008,
  "created_at" : "2017-04-20 02:06:09 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 15, 24 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 25, 35 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Ashley Farley",
      "screen_name" : "ashleydfarley",
      "indices" : [ 36, 50 ],
      "id_str" : "3931240040",
      "id" : 3931240040
    }, {
      "name" : "Lara Mangravite",
      "screen_name" : "LaraMangravite",
      "indices" : [ 51, 66 ],
      "id_str" : "761048056183738370",
      "id" : 761048056183738370
    }, {
      "name" : "Justin Kiggins",
      "screen_name" : "neuromusic",
      "indices" : [ 67, 78 ],
      "id_str" : "8932272",
      "id" : 8932272
    }, {
      "name" : "Sage Bionetworks",
      "screen_name" : "Sagebio",
      "indices" : [ 79, 87 ],
      "id_str" : "130579391",
      "id" : 130579391
    }, {
      "name" : "Brian M Bot",
      "screen_name" : "BrianMBot",
      "indices" : [ 88, 98 ],
      "id_str" : "504127665",
      "id" : 504127665
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 99, 109 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854875498282795008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.43902692884561, -122.3032138990755 ]
  },
  "id_str" : "854877924335513600",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @wilbanks @Helena_LB @ashleydfarley @LaraMangravite @neuromusic @Sagebio @BrianMBot @l_matthia just touched down",
  "id" : 854877924335513600,
  "in_reply_to_status_id" : 854875498282795008,
  "created_at" : "2017-04-20 02:02:34 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "episodeiv",
      "screen_name" : "episodeiv",
      "indices" : [ 0, 10 ],
      "id_str" : "14819618",
      "id" : 14819618
    }, {
      "name" : "Icelandair",
      "screen_name" : "Icelandair",
      "indices" : [ 62, 73 ],
      "id_str" : "21759987",
      "id" : 21759987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854756760946712577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99307357260875, -22.62571125341657 ]
  },
  "id_str" : "854757104208445440",
  "in_reply_to_user_id" : 14819618,
  "text" : "@episodeiv rather hope my flight will leave soon. Second time @Icelandair is having 1+ hour delay today\u2026",
  "id" : 854757104208445440,
  "in_reply_to_status_id" : 854756760946712577,
  "created_at" : "2017-04-19 18:02:28 +0000",
  "in_reply_to_screen_name" : "episodeiv",
  "in_reply_to_user_id_str" : "14819618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "episodeiv",
      "screen_name" : "episodeiv",
      "indices" : [ 0, 10 ],
      "id_str" : "14819618",
      "id" : 14819618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854756223278776323",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99321093063718, -22.62685465960681 ]
  },
  "id_str" : "854756402266505231",
  "in_reply_to_user_id" : 14819618,
  "text" : "@episodeiv sun instead \uD83D\uDE02",
  "id" : 854756402266505231,
  "in_reply_to_status_id" : 854756223278776323,
  "created_at" : "2017-04-19 17:59:41 +0000",
  "in_reply_to_screen_name" : "episodeiv",
  "in_reply_to_user_id_str" : "14819618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/fP5EGw1dcP",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTE3sbil0V4\/",
      "display_url" : "instagram.com\/p\/BTE3sbil0V4\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.995936792997, -22.623745405451 ]
  },
  "id_str" : "854755578773618689",
  "text" : "Well, at least it doesn't rain any longer. @ Keflavik International Airport https:\/\/t.co\/fP5EGw1dcP",
  "id" : 854755578773618689,
  "created_at" : "2017-04-19 17:56:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854748673808318464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99397789057548, -22.62569338013505 ]
  },
  "id_str" : "854748945322561536",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez snap. I guess we\u2019ll have to dine on another day then!",
  "id" : 854748945322561536,
  "in_reply_to_status_id" : 854748673808318464,
  "created_at" : "2017-04-19 17:30:03 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/hTQSkIKppM",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BTE0V8Rlmj3\/",
      "display_url" : "instagram.com\/p\/BTE0V8Rlmj3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "854748207179542528",
  "text" : "Approaching the rain #latergram \u2614\uFE0F https:\/\/t.co\/hTQSkIKppM",
  "id" : 854748207179542528,
  "created_at" : "2017-04-19 17:27:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854745555934879744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99299587613113, -22.62576539676196 ]
  },
  "id_str" : "854745738470993920",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 only on arrival. Departure I can do pretty confidently now",
  "id" : 854745738470993920,
  "in_reply_to_status_id" : 854745555934879744,
  "created_at" : "2017-04-19 17:17:19 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854742929151275009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99323101659265, -22.62573283547607 ]
  },
  "id_str" : "854745031537831937",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 i still get lost in FRA when arriving ;)",
  "id" : 854745031537831937,
  "in_reply_to_status_id" : 854742929151275009,
  "created_at" : "2017-04-19 17:14:30 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854742819768029184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99323101659265, -22.62573283547607 ]
  },
  "id_str" : "854744631090741252",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 like all scientists it seems.",
  "id" : 854744631090741252,
  "in_reply_to_status_id" : 854742819768029184,
  "created_at" : "2017-04-19 17:12:55 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 3, 13 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 15, 31 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854743785238138880",
  "text" : "RT @Julie_B92: @gedankenstuecke Can't vote cause not married but \"immigration purposes\" is near the top of my list of reasons to get marrie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854612584305233920",
    "geo" : { },
    "id_str" : "854742819768029184",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Can't vote cause not married but \"immigration purposes\" is near the top of my list of reasons to get married cause I am super romantic",
    "id" : 854742819768029184,
    "in_reply_to_status_id" : 854612584305233920,
    "created_at" : "2017-04-19 17:05:43 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "protected" : false,
      "id_str" : "1385861262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813827716151644160\/JvmX-W-T_normal.jpg",
      "id" : 1385861262,
      "verified" : false
    }
  },
  "id" : 854743785238138880,
  "created_at" : "2017-04-19 17:09:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854742517035749376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99346960174286, -22.62533049784175 ]
  },
  "id_str" : "854742690608680960",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 luckily I can navigate KEF by now, made it :D",
  "id" : 854742690608680960,
  "in_reply_to_status_id" : 854742517035749376,
  "created_at" : "2017-04-19 17:05:12 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 47, 55 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 56, 65 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/BOD3q7u0F0",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/854735345547702273",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "854735345547702273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99400857262742, -22.62489897995989 ]
  },
  "id_str" : "854740596275204097",
  "in_reply_to_user_id" : 14286491,
  "text" : "Worst part: no time to buy new licorice candy! @branleb @Senficon! \uD83D\uDE31\uD83D\uDE2D https:\/\/t.co\/BOD3q7u0F0",
  "id" : 854740596275204097,
  "in_reply_to_status_id" : 854735345547702273,
  "created_at" : "2017-04-19 16:56:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.98887143010645, -22.63184390032909 ]
  },
  "id_str" : "854735345547702273",
  "text" : "1h delay means having 30 minutes to make my KEF \u2708\uFE0FSEA connection. \uD83C\uDFC3",
  "id" : 854735345547702273,
  "created_at" : "2017-04-19 16:36:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    }, {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 10, 20 ],
      "id_str" : "234309722",
      "id" : 234309722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854669466524897281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.049088781898, 8.583237752406498 ]
  },
  "id_str" : "854669777473863680",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr @Helena_LB that\u2019s so kind. I haven\u2019t forgotten about the twin thing I wanted to chat about in SAN when we missed each other!",
  "id" : 854669777473863680,
  "in_reply_to_status_id" : 854669466524897281,
  "created_at" : "2017-04-19 12:15:28 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 51, 60 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854667869539282944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04912006802405, 8.583491212811031 ]
  },
  "id_str" : "854668147982565376",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB absolutely, can\u2019t wait to finally meet! @eramirez let me know if you\u2019re having dinner plans tonight!",
  "id" : 854668147982565376,
  "in_reply_to_status_id" : 854667869539282944,
  "created_at" : "2017-04-19 12:09:00 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SageAssembly",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04959201677787, 8.584309172219527 ]
  },
  "id_str" : "854667714794848257",
  "text" : "Now: FRA \u2708\uFE0F KEF, en route to #SageAssembly!",
  "id" : 854667714794848257,
  "created_at" : "2017-04-19 12:07:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dixie",
      "screen_name" : "timiat",
      "indices" : [ 0, 7 ],
      "id_str" : "10388582",
      "id" : 10388582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854662695634776065",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05026221056313, 8.584343080172058 ]
  },
  "id_str" : "854662813872267267",
  "in_reply_to_user_id" : 10388582,
  "text" : "@timiat something to work on during the flight.",
  "id" : 854662813872267267,
  "in_reply_to_status_id" : 854662695634776065,
  "created_at" : "2017-04-19 11:47:48 +0000",
  "in_reply_to_screen_name" : "timiat",
  "in_reply_to_user_id_str" : "10388582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854661190143946755",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05025592713849, 8.584359801856554 ]
  },
  "id_str" : "854661599310827520",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock me too, curious whether confirmation bias or a strong force that keeps marriage as an institution afloat in academic circles.",
  "id" : 854661599310827520,
  "in_reply_to_status_id" : 854661190143946755,
  "created_at" : "2017-04-19 11:42:58 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854660298908856320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0502510487233, 8.584338041775693 ]
  },
  "id_str" : "854660492522029056",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock ah, yeah, I would put that as a yes in the survey. But see the subtle difference.",
  "id" : 854660492522029056,
  "in_reply_to_status_id" : 854660298908856320,
  "created_at" : "2017-04-19 11:38:34 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dixie",
      "screen_name" : "timiat",
      "indices" : [ 0, 7 ],
      "id_str" : "10388582",
      "id" : 10388582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854657319820460033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05024864969389, 8.584288306988022 ]
  },
  "id_str" : "854659835832524800",
  "in_reply_to_user_id" : 10388582,
  "text" : "@timiat i had hoped for your expert advice! \uD83D\uDE31",
  "id" : 854659835832524800,
  "in_reply_to_status_id" : 854657319820460033,
  "created_at" : "2017-04-19 11:35:58 +0000",
  "in_reply_to_screen_name" : "timiat",
  "in_reply_to_user_id_str" : "10388582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854658875152363521",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05026134283227, 8.584340994725057 ]
  },
  "id_str" : "854659622388588544",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock that would be a subset I guess? :)",
  "id" : 854659622388588544,
  "in_reply_to_status_id" : 854658875152363521,
  "created_at" : "2017-04-19 11:35:07 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0509351953843, 8.586595331775001 ]
  },
  "id_str" : "854649066713755649",
  "text" : "Any recommendations on what carrier to use to get mobile internet for two weeks in \uD83C\uDDFA\uD83C\uDDF8 and \uD83C\uDDE8\uD83C\uDDE6?",
  "id" : 854649066713755649,
  "created_at" : "2017-04-19 10:53:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 3, 18 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    }, {
      "name" : "Brandon Hurr",
      "screen_name" : "bhive01",
      "indices" : [ 20, 28 ],
      "id_str" : "12296332",
      "id" : 12296332
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 29, 45 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854633112101421057",
  "text" : "RT @TheLabAndField: @bhive01 @gedankenstuecke same for us &amp; UK, especially with everything in flux at the time (2009\/10ish) re: same-sex ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brandon Hurr",
        "screen_name" : "bhive01",
        "indices" : [ 0, 8 ],
        "id_str" : "12296332",
        "id" : 12296332
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 9, 25 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854621423029104641",
    "geo" : { },
    "id_str" : "854632225714966528",
    "in_reply_to_user_id" : 12296332,
    "text" : "@bhive01 @gedankenstuecke same for us &amp; UK, especially with everything in flux at the time (2009\/10ish) re: same-sex marriage\/civil partnerships",
    "id" : 854632225714966528,
    "in_reply_to_status_id" : 854621423029104641,
    "created_at" : "2017-04-19 09:46:15 +0000",
    "in_reply_to_screen_name" : "bhive01",
    "in_reply_to_user_id_str" : "12296332",
    "user" : {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "protected" : false,
      "id_str" : "1060545835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851184072890167297\/jIBXYvtR_normal.jpg",
      "id" : 1060545835,
      "verified" : false
    }
  },
  "id" : 854633112101421057,
  "created_at" : "2017-04-19 09:49:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "David Stark",
      "screen_name" : "zarkonnen_com",
      "indices" : [ 12, 26 ],
      "id_str" : "108888710",
      "id" : 108888710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854622987928162304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10688464255224, 8.754768331598331 ]
  },
  "id_str" : "854625049529208833",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler @zarkonnen_com but there\u2019s only so many characters in a tweet.",
  "id" : 854625049529208833,
  "in_reply_to_status_id" : 854622987928162304,
  "created_at" : "2017-04-19 09:17:44 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 0, 11 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "David Stark",
      "screen_name" : "zarkonnen_com",
      "indices" : [ 12, 26 ],
      "id_str" : "108888710",
      "id" : 108888710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854622987928162304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10744829750031, 8.754558331907793 ]
  },
  "id_str" : "854624989190000641",
  "in_reply_to_user_id" : 1244114060,
  "text" : "@RaeKnowler @zarkonnen_com I\u2019d take a very broad sciency definition. Everyone who\u2019s work easily requires going abroad.",
  "id" : 854624989190000641,
  "in_reply_to_status_id" : 854622987928162304,
  "created_at" : "2017-04-19 09:17:30 +0000",
  "in_reply_to_screen_name" : "RaeKnowler",
  "in_reply_to_user_id_str" : "1244114060",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 3, 14 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 16, 32 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "David Stark",
      "screen_name" : "zarkonnen_com",
      "indices" : [ 33, 47 ],
      "id_str" : "108888710",
      "id" : 108888710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854624092963688448",
  "text" : "RT @RaeKnowler: @gedankenstuecke @zarkonnen_com Immigration or citizenship necessity are the only reasons we would marry tbh. Luckily we've\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "David Stark",
        "screen_name" : "zarkonnen_com",
        "indices" : [ 17, 31 ],
        "id_str" : "108888710",
        "id" : 108888710
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854622987928162304",
    "geo" : { },
    "id_str" : "854623576753922048",
    "in_reply_to_user_id" : 1244114060,
    "text" : "@gedankenstuecke @zarkonnen_com Immigration or citizenship necessity are the only reasons we would marry tbh. Luckily we've only moved within Europe so far.",
    "id" : 854623576753922048,
    "in_reply_to_status_id" : 854622987928162304,
    "created_at" : "2017-04-19 09:11:53 +0000",
    "in_reply_to_screen_name" : "RaeKnowler",
    "in_reply_to_user_id_str" : "1244114060",
    "user" : {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "protected" : false,
      "id_str" : "1244114060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897886763435294720\/nvIG3s3i_normal.jpg",
      "id" : 1244114060,
      "verified" : false
    }
  },
  "id" : 854624092963688448,
  "created_at" : "2017-04-19 09:13:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 3, 14 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 16, 32 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "David Stark",
      "screen_name" : "zarkonnen_com",
      "indices" : [ 102, 116 ],
      "id_str" : "108888710",
      "id" : 108888710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854624058373222402",
  "text" : "RT @RaeKnowler: @gedankenstuecke It hasn't come to that yet (and I'm no longer a sciency person), but @zarkonnen_com and I have considered\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "David Stark",
        "screen_name" : "zarkonnen_com",
        "indices" : [ 86, 100 ],
        "id_str" : "108888710",
        "id" : 108888710
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854612584305233920",
    "geo" : { },
    "id_str" : "854622987928162304",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke It hasn't come to that yet (and I'm no longer a sciency person), but @zarkonnen_com and I have considered it.",
    "id" : 854622987928162304,
    "in_reply_to_status_id" : 854612584305233920,
    "created_at" : "2017-04-19 09:09:33 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "protected" : false,
      "id_str" : "1244114060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897886763435294720\/nvIG3s3i_normal.jpg",
      "id" : 1244114060,
      "verified" : false
    }
  },
  "id" : 854624058373222402,
  "created_at" : "2017-04-19 09:13:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hurr",
      "screen_name" : "bhive01",
      "indices" : [ 3, 11 ],
      "id_str" : "12296332",
      "id" : 12296332
    }, {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 13, 28 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 29, 45 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854624038957842432",
  "text" : "RT @bhive01: @TheLabAndField @gedankenstuecke It played a role for us too. Made it way easier to get a visa in US for wife and leave to rem\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Bond",
        "screen_name" : "TheLabAndField",
        "indices" : [ 0, 15 ],
        "id_str" : "1060545835",
        "id" : 1060545835
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 16, 32 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854612996814974976",
    "geo" : { },
    "id_str" : "854621423029104641",
    "in_reply_to_user_id" : 1060545835,
    "text" : "@TheLabAndField @gedankenstuecke It played a role for us too. Made it way easier to get a visa in US for wife and leave to remain in U.K. for me.",
    "id" : 854621423029104641,
    "in_reply_to_status_id" : 854612996814974976,
    "created_at" : "2017-04-19 09:03:20 +0000",
    "in_reply_to_screen_name" : "TheLabAndField",
    "in_reply_to_user_id_str" : "1060545835",
    "user" : {
      "name" : "Brandon Hurr",
      "screen_name" : "bhive01",
      "protected" : false,
      "id_str" : "12296332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/44573772\/bhive01Icon_normal.jpg",
      "id" : 12296332,
      "verified" : false
    }
  },
  "id" : 854624038957842432,
  "created_at" : "2017-04-19 09:13:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854618943092404225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11080941049877, 8.753089913240645 ]
  },
  "id_str" : "854624012055572480",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim more like jobs abroad are the new babies I guess.",
  "id" : 854624012055572480,
  "in_reply_to_status_id" : 854618943092404225,
  "created_at" : "2017-04-19 09:13:37 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChristofferFlensburg",
      "screen_name" : "CFlensburg",
      "indices" : [ 0, 11 ],
      "id_str" : "2156191704",
      "id" : 2156191704
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 12, 25 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854616529622544384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11189802554446, 8.753349138431952 ]
  },
  "id_str" : "854623596404191232",
  "in_reply_to_user_id" : 2156191704,
  "text" : "@CFlensburg @PhilippBayer that\u2019s ridiculous!",
  "id" : 854623596404191232,
  "in_reply_to_status_id" : 854616529622544384,
  "created_at" : "2017-04-19 09:11:58 +0000",
  "in_reply_to_screen_name" : "CFlensburg",
  "in_reply_to_user_id_str" : "2156191704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 0, 7 ],
      "id_str" : "53749209",
      "id" : 53749209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854614985003159552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11190925729471, 8.753870157533095 ]
  },
  "id_str" : "854623532126535681",
  "in_reply_to_user_id" : 53749209,
  "text" : "@blinry sure, always bugs me if I see polls :p",
  "id" : 854623532126535681,
  "in_reply_to_status_id" : 854614985003159552,
  "created_at" : "2017-04-19 09:11:42 +0000",
  "in_reply_to_screen_name" : "blinry",
  "in_reply_to_user_id_str" : "53749209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChristofferFlensburg",
      "screen_name" : "CFlensburg",
      "indices" : [ 3, 14 ],
      "id_str" : "2156191704",
      "id" : 2156191704
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 16, 32 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 33, 46 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854620067912437760",
  "text" : "RT @CFlensburg: @gedankenstuecke @PhilippBayer We had to produce a 112 page .pdf with evidence of de-facto relationship. But it couldn't be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Philipp Bayer\uD83C\uDF08",
        "screen_name" : "PhilippBayer",
        "indices" : [ 17, 30 ],
        "id_str" : "121777206",
        "id" : 121777206
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854615570259562497",
    "geo" : { },
    "id_str" : "854616529622544384",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @PhilippBayer We had to produce a 112 page .pdf with evidence of de-facto relationship. But it couldn't be more than 10MB for their email server... \uD83D\uDE44",
    "id" : 854616529622544384,
    "in_reply_to_status_id" : 854615570259562497,
    "created_at" : "2017-04-19 08:43:53 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "ChristofferFlensburg",
      "screen_name" : "CFlensburg",
      "protected" : false,
      "id_str" : "2156191704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000648749773\/df937b0dfb311f4b8908e48658b8ddc3_normal.jpeg",
      "id" : 2156191704,
      "verified" : false
    }
  },
  "id" : 854620067912437760,
  "created_at" : "2017-04-19 08:57:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChristofferFlensburg",
      "screen_name" : "CFlensburg",
      "indices" : [ 0, 11 ],
      "id_str" : "2156191704",
      "id" : 2156191704
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 12, 25 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854615239303634944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406129826065, 8.753431565715555 ]
  },
  "id_str" : "854615570259562497",
  "in_reply_to_user_id" : 2156191704,
  "text" : "@CFlensburg @PhilippBayer the latter one, regardless of countries of immigration. :)",
  "id" : 854615570259562497,
  "in_reply_to_status_id" : 854615239303634944,
  "created_at" : "2017-04-19 08:40:04 +0000",
  "in_reply_to_screen_name" : "CFlensburg",
  "in_reply_to_user_id_str" : "2156191704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 3, 11 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854614373251391488",
  "text" : "RT @kaiblin: @gedankenstuecke I'm not married, but this is totally on our list of \"things we would get marrried for\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854612584305233920",
    "geo" : { },
    "id_str" : "854614213926498305",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke I'm not married, but this is totally on our list of \"things we would get marrried for\"",
    "id" : 854614213926498305,
    "in_reply_to_status_id" : 854612584305233920,
    "created_at" : "2017-04-19 08:34:41 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "protected" : false,
      "id_str" : "124202458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629590097\/kai_portrait_normal.jpg",
      "id" : 124202458,
      "verified" : false
    }
  },
  "id" : 854614373251391488,
  "created_at" : "2017-04-19 08:35:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854614213926498305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140002487694, 8.753241347157166 ]
  },
  "id_str" : "854614364174798848",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin i wish twitter would allow more characters for formulating your poll questions!",
  "id" : 854614364174798848,
  "in_reply_to_status_id" : 854614213926498305,
  "created_at" : "2017-04-19 08:35:17 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854612996814974976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406132282739, 8.753431599872764 ]
  },
  "id_str" : "854613311358455812",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField that\u2019s a yes I take? (it\u2019s a poll btw if your client doesn\u2019t show it).",
  "id" : 854613311358455812,
  "in_reply_to_status_id" : 854612996814974976,
  "created_at" : "2017-04-19 08:31:06 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 3, 18 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 20, 36 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854613118508564480",
  "text" : "RT @TheLabAndField: @gedankenstuecke I'm a dual national &amp; it was a major factor in deciding whether my partner and I would got married for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854612584305233920",
    "geo" : { },
    "id_str" : "854612996814974976",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke I'm a dual national &amp; it was a major factor in deciding whether my partner and I would got married formally",
    "id" : 854612996814974976,
    "in_reply_to_status_id" : 854612584305233920,
    "created_at" : "2017-04-19 08:29:51 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "protected" : false,
      "id_str" : "1060545835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/851184072890167297\/jIBXYvtR_normal.jpg",
      "id" : 1060545835,
      "verified" : false
    }
  },
  "id" : 854613118508564480,
  "created_at" : "2017-04-19 08:30:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 59, 72 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/60aWQ6M0Zi",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/854237817886490624",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "854612584305233920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406132282739, 8.753431599872764 ]
  },
  "id_str" : "854612826899591168",
  "in_reply_to_user_id" : 14286491,
  "text" : "For the changes in Australian visa rules see the tweets by @PhilippBayer  https:\/\/t.co\/60aWQ6M0Zi",
  "id" : 854612826899591168,
  "in_reply_to_status_id" : 854612584305233920,
  "created_at" : "2017-04-19 08:29:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854612584305233920",
  "text" : "Curious after \uD83C\uDDE6\uD83C\uDDFA visa changes: Was easier joint immigration to another country one of the main reasons for you sciency folks to get married?",
  "id" : 854612584305233920,
  "created_at" : "2017-04-19 08:28:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IbwH25a5FR",
      "expanded_url" : "https:\/\/twitter.com\/PLOSCompBiol\/status\/854534772374159360",
      "display_url" : "twitter.com\/PLOSCompBiol\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854609815410266113",
  "text" : "RT @PhilippBayer: Rule 11: restructure funding to create incentives for robust research software, as there is none https:\/\/t.co\/IbwH25a5FR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/IbwH25a5FR",
        "expanded_url" : "https:\/\/twitter.com\/PLOSCompBiol\/status\/854534772374159360",
        "display_url" : "twitter.com\/PLOSCompBiol\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "854535528523247620",
    "text" : "Rule 11: restructure funding to create incentives for robust research software, as there is none https:\/\/t.co\/IbwH25a5FR",
    "id" : 854535528523247620,
    "created_at" : "2017-04-19 03:22:01 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 854609815410266113,
  "created_at" : "2017-04-19 08:17:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Johnson",
      "screen_name" : "BioMath",
      "indices" : [ 3, 11 ],
      "id_str" : "21234787",
      "id" : 21234787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854605074420596737",
  "text" : "RT @BioMath: my daughter is taking an ungrad bioinformatics course. I'm happy to hear she is learning the important stuff https:\/\/t.co\/bvqT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BioMath\/status\/854530533820440581\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/bvqTLnBS9Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C9vm15HUQAAA17H.jpg",
        "id_str" : "854530367855804416",
        "id" : 854530367855804416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9vm15HUQAAA17H.jpg",
        "sizes" : [ {
          "h" : 418,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 730
        } ],
        "display_url" : "pic.twitter.com\/bvqTLnBS9Z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "854530533820440581",
    "text" : "my daughter is taking an ungrad bioinformatics course. I'm happy to hear she is learning the important stuff https:\/\/t.co\/bvqTLnBS9Z",
    "id" : 854530533820440581,
    "created_at" : "2017-04-19 03:02:10 +0000",
    "user" : {
      "name" : "Charlie Johnson",
      "screen_name" : "BioMath",
      "protected" : false,
      "id_str" : "21234787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877259644992757760\/vQuWicLh_normal.jpg",
      "id" : 21234787,
      "verified" : false
    }
  },
  "id" : 854605074420596737,
  "created_at" : "2017-04-19 07:58:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paola Masuzzo",
      "screen_name" : "pcmasuzzo",
      "indices" : [ 0, 10 ],
      "id_str" : "438729858",
      "id" : 438729858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854576740752076800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389358905154, 8.753313180067346 ]
  },
  "id_str" : "854580626480967680",
  "in_reply_to_user_id" : 438729858,
  "text" : "@pcmasuzzo thanks! :)",
  "id" : 854580626480967680,
  "in_reply_to_status_id" : 854576740752076800,
  "created_at" : "2017-04-19 06:21:13 +0000",
  "in_reply_to_screen_name" : "pcmasuzzo",
  "in_reply_to_user_id_str" : "438729858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140549896623, 8.753427821956715 ]
  },
  "id_str" : "854580403340021760",
  "text" : "Open the blinds, see snow. Thinking: good thing I\u2019ll be leaving to Seattle, Toronto and Portland to escape the weather. \uD83D\uDE02",
  "id" : 854580403340021760,
  "created_at" : "2017-04-19 06:20:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Molloy",
      "screen_name" : "jenny_molloy",
      "indices" : [ 0, 13 ],
      "id_str" : "252245569",
      "id" : 252245569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854469536325783552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405820274062, 8.753425437241852 ]
  },
  "id_str" : "854469679892529152",
  "in_reply_to_user_id" : 252245569,
  "text" : "@jenny_molloy when and on which route are you coming in? :)",
  "id" : 854469679892529152,
  "in_reply_to_status_id" : 854469536325783552,
  "created_at" : "2017-04-18 23:00:21 +0000",
  "in_reply_to_screen_name" : "jenny_molloy",
  "in_reply_to_user_id_str" : "252245569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854456437967400964",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406119715943, 8.753431424385735 ]
  },
  "id_str" : "854456509803237376",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks waiting for the dropbox icon to rumble. :p",
  "id" : 854456509803237376,
  "in_reply_to_status_id" : 854456437967400964,
  "created_at" : "2017-04-18 22:08:01 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/Q1G3cSQk2J",
      "expanded_url" : "http:\/\/31.media.tumblr.com\/tumblr_lyjy23swG01qm2l53o3_250.gif",
      "display_url" : "31.media.tumblr.com\/tumblr_lyjy23s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "854454676468748288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406122377318, 8.753431468449616 ]
  },
  "id_str" : "854455821597646848",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks feeling like https:\/\/t.co\/Q1G3cSQk2J",
  "id" : 854455821597646848,
  "in_reply_to_status_id" : 854454676468748288,
  "created_at" : "2017-04-18 22:05:17 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854454518574186496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405002679005, 8.7534530726267 ]
  },
  "id_str" : "854454592700121088",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks what kind of evil punishment is that? ;)",
  "id" : 854454592700121088,
  "in_reply_to_status_id" : 854454518574186496,
  "created_at" : "2017-04-18 22:00:24 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/fZ9t7rihjb",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/854394917287854080",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404107754743, 8.753471718195703 ]
  },
  "id_str" : "854398971200110593",
  "text" : "Not at all intimidating to be on a list with these! \uD83D\uDE31 https:\/\/t.co\/fZ9t7rihjb",
  "id" : 854398971200110593,
  "created_at" : "2017-04-18 18:19:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 0, 10 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 11, 20 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854397430342848514",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406197018536, 8.753431472200715 ]
  },
  "id_str" : "854397488522022913",
  "in_reply_to_user_id" : 234309722,
  "text" : "@Helena_LB @wilbanks I hoped I could copy yours!",
  "id" : 854397488522022913,
  "in_reply_to_status_id" : 854397430342848514,
  "created_at" : "2017-04-18 18:13:29 +0000",
  "in_reply_to_screen_name" : "Helena_LB",
  "in_reply_to_user_id_str" : "234309722",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854396559034912772",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406195073743, 8.753431419597312 ]
  },
  "id_str" : "854396765872820227",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks the closing reflections are so hard, means you have to stay awake for all of the meeting! \uD83D\uDE02",
  "id" : 854396765872820227,
  "in_reply_to_status_id" : 854396559034912772,
  "created_at" : "2017-04-18 18:10:37 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/Q2SvVMownv",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/852043823333072896",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "854371901795442688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.15245038555017, 8.661637371414026 ]
  },
  "id_str" : "854377680103460864",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @Protohedgehog c.f. https:\/\/t.co\/Q2SvVMownv",
  "id" : 854377680103460864,
  "in_reply_to_status_id" : 854371901795442688,
  "created_at" : "2017-04-18 16:54:47 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854375672114008064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16184380910802, 8.649099780238162 ]
  },
  "id_str" : "854376889221296129",
  "in_reply_to_user_id" : 14286491,
  "text" : "That I\u2019m already feeling jet-lagged without boarding a single flight is promising.",
  "id" : 854376889221296129,
  "in_reply_to_status_id" : 854375672114008064,
  "created_at" : "2017-04-18 16:51:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/854375672114008064\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/5f52wKw5Ns",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C9taIPxXoAIUUVE.jpg",
      "id_str" : "854375652035895298",
      "id" : 854375652035895298,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C9taIPxXoAIUUVE.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5f52wKw5Ns"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854375672114008064",
  "text" : "Who can't be bothered to carry a poster roll on 7 flights and thus just folded his non-cloth poster? https:\/\/t.co\/5f52wKw5Ns",
  "id" : 854375672114008064,
  "created_at" : "2017-04-18 16:46:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "854360718480740353",
  "text" : "RT @eramirez: @gedankenstuecke I think of you every time I have to play \"sneaky access\" researcher.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "854351294399696896",
    "geo" : { },
    "id_str" : "854360474489454592",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke I think of you every time I have to play \"sneaky access\" researcher.",
    "id" : 854360474489454592,
    "in_reply_to_status_id" : 854351294399696896,
    "created_at" : "2017-04-18 15:46:25 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866822214267666432\/IYzsQHYG_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 854360718480740353,
  "created_at" : "2017-04-18 15:47:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854360474489454592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234856696724, 8.627526023712104 ]
  },
  "id_str" : "854360663698935812",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez \uD83D\uDE0D\uD83D\uDC96 and that\u2019s a lovely term! Even better than Guerilla Open Access! \uD83D\uDE02",
  "id" : 854360663698935812,
  "in_reply_to_status_id" : 854360474489454592,
  "created_at" : "2017-04-18 15:47:10 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ContentMine",
      "screen_name" : "TheContentMine",
      "indices" : [ 35, 50 ],
      "id_str" : "2466224420",
      "id" : 2466224420
    }, {
      "name" : "Ilyass",
      "screen_name" : "Joydisee",
      "indices" : [ 54, 63 ],
      "id_str" : "49310539",
      "id" : 49310539
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ajbLolevZC",
      "expanded_url" : "http:\/\/iltabiai.github.io\/research\/2017\/04\/17\/getpapers.html",
      "display_url" : "iltabiai.github.io\/research\/2017\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231585265824, 8.62753947473933 ]
  },
  "id_str" : "854359226373869568",
  "text" : "That\u2019s a nice first exploration of @TheContentMine by @Joydisee! https:\/\/t.co\/ajbLolevZC #mozwow",
  "id" : 854359226373869568,
  "created_at" : "2017-04-18 15:41:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854351241006030849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229341850727, 8.62755123775376 ]
  },
  "id_str" : "854351294399696896",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez of course, looking forward to it!",
  "id" : 854351294399696896,
  "in_reply_to_status_id" : 854351241006030849,
  "created_at" : "2017-04-18 15:09:56 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854335928139206658",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229341850727, 8.62755123775376 ]
  },
  "id_str" : "854350763316924416",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps is your guess the # of German tourists? :P",
  "id" : 854350763316924416,
  "in_reply_to_status_id" : 854335928139206658,
  "created_at" : "2017-04-18 15:07:49 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 3, 12 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scholarlycommons",
      "indices" : [ 44, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/ppCvN14Mnv",
      "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/854251249604190210",
      "display_url" : "twitter.com\/jeroenbosman\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "854268387907842048",
  "text" : "RT @MsPhelps: Or... any language you speak! #scholarlycommons https:\/\/t.co\/ppCvN14Mnv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scholarlycommons",
        "indices" : [ 30, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/ppCvN14Mnv",
        "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/854251249604190210",
        "display_url" : "twitter.com\/jeroenbosman\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "854252473736974336",
    "text" : "Or... any language you speak! #scholarlycommons https:\/\/t.co\/ppCvN14Mnv",
    "id" : 854252473736974336,
    "created_at" : "2017-04-18 08:37:15 +0000",
    "user" : {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "protected" : false,
      "id_str" : "22963112",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665529153576390660\/ukieWtR4_normal.jpg",
      "id" : 22963112,
      "verified" : false
    }
  },
  "id" : 854268387907842048,
  "created_at" : "2017-04-18 09:40:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "854093597192273921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405726735004, 8.753425286845491 ]
  },
  "id_str" : "854193497393508358",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez see you in Seattle! \uD83D\uDE0D",
  "id" : 854193497393508358,
  "in_reply_to_status_id" : 854093597192273921,
  "created_at" : "2017-04-18 04:42:54 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 9, 18 ],
      "id_str" : "819601236",
      "id" : 819601236
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 19, 27 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853999884575309825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405793679724, 8.753423917338365 ]
  },
  "id_str" : "854050228332371968",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @Ragetina @rantleb \uD83D\uDE02 bin ab Mittwoch bis zum 04.05. Nicht da um sie von der Post zu holen falls n\u00F6tig.",
  "id" : 854050228332371968,
  "in_reply_to_status_id" : 853999884575309825,
  "created_at" : "2017-04-17 19:13:36 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vin\u24EAdh Ilang\u24EAvan",
      "screen_name" : "InquisitiveVi",
      "indices" : [ 0, 14 ],
      "id_str" : "3443391621",
      "id" : 3443391621
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 15, 29 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853882973632049154",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114060615011, 8.753424046280216 ]
  },
  "id_str" : "853889845290303488",
  "in_reply_to_user_id" : 3443391621,
  "text" : "@InquisitiveVi @Protohedgehog I\u2019m only using Twitter through Tweetbot, so there\u2019s no ads for me.",
  "id" : 853889845290303488,
  "in_reply_to_status_id" : 853882973632049154,
  "created_at" : "2017-04-17 08:36:18 +0000",
  "in_reply_to_screen_name" : "InquisitiveVi",
  "in_reply_to_user_id_str" : "3443391621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Xu",
      "screen_name" : "annathehybrid",
      "indices" : [ 3, 17 ],
      "id_str" : "2997606122",
      "id" : 2997606122
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 19, 35 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "853716740563496960",
  "text" : "RT @annathehybrid: @gedankenstuecke They're growers, not showers \uD83D\uDE01\uD83D\uDE01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "853642697567084544",
    "geo" : { },
    "id_str" : "853676581528666112",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke They're growers, not showers \uD83D\uDE01\uD83D\uDE01",
    "id" : 853676581528666112,
    "in_reply_to_status_id" : 853642697567084544,
    "created_at" : "2017-04-16 18:28:52 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Anna Xu",
      "screen_name" : "annathehybrid",
      "protected" : false,
      "id_str" : "2997606122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572886774881521665\/8yGXAfqn_normal.jpeg",
      "id" : 2997606122,
      "verified" : false
    }
  },
  "id" : 853716740563496960,
  "created_at" : "2017-04-16 21:08:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dixie",
      "screen_name" : "timiat",
      "indices" : [ 0, 7 ],
      "id_str" : "10388582",
      "id" : 10388582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853655524965060608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405926638579, 8.75342223079216 ]
  },
  "id_str" : "853657267153108998",
  "in_reply_to_user_id" : 10388582,
  "text" : "@timiat \uD83D\uDE0D\uD83D\uDE02 thanks for those!",
  "id" : 853657267153108998,
  "in_reply_to_status_id" : 853655524965060608,
  "created_at" : "2017-04-16 17:12:07 +0000",
  "in_reply_to_screen_name" : "timiat",
  "in_reply_to_user_id_str" : "10388582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/853642697567084544\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/9ozQu82trE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C9i_gjvWsAE1NFZ.jpg",
      "id_str" : "853642695457288193",
      "id" : 853642695457288193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9i_gjvWsAE1NFZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/9ozQu82trE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "853642697567084544",
  "text" : "My mom made koulourakia for Easter. Comment of my flat mate: 'Who cooked these penis shaped cookies?' \uD83D\uDE02 https:\/\/t.co\/9ozQu82trE",
  "id" : 853642697567084544,
  "created_at" : "2017-04-16 16:14:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853288438166159360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08941256882527, 7.613480275598642 ]
  },
  "id_str" : "853288569066201088",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser you bet, like twins separated at birth!",
  "id" : 853288569066201088,
  "in_reply_to_status_id" : 853288438166159360,
  "created_at" : "2017-04-15 16:47:02 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853285580033097728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.0894423621194, 7.613434053107575 ]
  },
  "id_str" : "853288256447926273",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser and ordered! \u2705\uD83D\uDE0A",
  "id" : 853288256447926273,
  "in_reply_to_status_id" : 853285580033097728,
  "created_at" : "2017-04-15 16:45:48 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853285580033097728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08936570438904, 7.61351911248139 ]
  },
  "id_str" : "853286509084106752",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser thanks! \uD83D\uDC96",
  "id" : 853286509084106752,
  "in_reply_to_status_id" : 853285580033097728,
  "created_at" : "2017-04-15 16:38:51 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 59, 71 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08935477775716, 7.613532515249786 ]
  },
  "id_str" : "853284115948478466",
  "text" : "Best use of Swarm\/Foursquare today: impromptu meeting with @herr_schrat for coffee! \uD83C\uDF89 \u2615\uFE0F",
  "id" : 853284115948478466,
  "created_at" : "2017-04-15 16:29:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 9, 23 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853278032714444804",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08938219055506, 7.613476016970305 ]
  },
  "id_str" : "853283230279237634",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @annakrystalli after hours of searching \uD83C\uDF68 in Z\u00FCrich I went to the 30k people town where I was raised today: \uD83C\uDF68 shops!",
  "id" : 853283230279237634,
  "in_reply_to_status_id" : 853278032714444804,
  "created_at" : "2017-04-15 16:25:49 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 26, 42 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/853264526837518336\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/WLBDjA7iJb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C9dnj_GWAAEzzzy.jpg",
      "id_str" : "853264522341122049",
      "id" : 853264522341122049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9dnj_GWAAEzzzy.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/WLBDjA7iJb"
    } ],
    "hashtags" : [ {
      "text" : "MicrobesAgainstMisogyny",
      "indices" : [ 73, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "853282799369035776",
  "text" : "RT @auremoser: Channeling @gedankenstuecke with my tardigrade tee today, #MicrobesAgainstMisogyny https:\/\/t.co\/WLBDjA7iJb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 11, 27 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/auremoser\/status\/853264526837518336\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/WLBDjA7iJb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C9dnj_GWAAEzzzy.jpg",
        "id_str" : "853264522341122049",
        "id" : 853264522341122049,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9dnj_GWAAEzzzy.jpg",
        "sizes" : [ {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/WLBDjA7iJb"
      } ],
      "hashtags" : [ {
        "text" : "MicrobesAgainstMisogyny",
        "indices" : [ 58, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "853264526837518336",
    "text" : "Channeling @gedankenstuecke with my tardigrade tee today, #MicrobesAgainstMisogyny https:\/\/t.co\/WLBDjA7iJb",
    "id" : 853264526837518336,
    "created_at" : "2017-04-15 15:11:30 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 853282799369035776,
  "created_at" : "2017-04-15 16:24:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "853264526837518336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08937164474692, 7.613518101742505 ]
  },
  "id_str" : "853282793387896832",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser awesome. Where can I get one? \uD83D\uDE0D",
  "id" : 853282793387896832,
  "in_reply_to_status_id" : 853264526837518336,
  "created_at" : "2017-04-15 16:24:05 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 10, 20 ],
      "id_str" : "111093392",
      "id" : 111093392
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 21, 35 ],
      "id_str" : "15090415",
      "id" : 15090415
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 36, 44 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.08943423835098, 7.613537831035843 ]
  },
  "id_str" : "853263660575334400",
  "text" : "@kopshtik @Hao_and_Y @annakrystalli @betatim can we please all go for ice cream now?",
  "id" : 853263660575334400,
  "created_at" : "2017-04-15 15:08:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "annakrystalli",
      "screen_name" : "annakrystalli",
      "indices" : [ 9, 23 ],
      "id_str" : "15090415",
      "id" : 15090415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852928152699629571",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407585972705, 8.753291244792432 ]
  },
  "id_str" : "852938132622364676",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @annakrystalli \uD83D\uDE0D looks nice!",
  "id" : 852938132622364676,
  "in_reply_to_status_id" : 852928152699629571,
  "created_at" : "2017-04-14 17:34:32 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "openscience",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "852648486076076032",
  "text" : "RT @MozillaScience: Beyond excited to announce our 2017 #mozsprint, June 1-2, join us to collaborate on #openscience projects globally: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MozillaScience\/status\/852560008386666496\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/5lKWTZuKtW",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C9TmiSQXsAAodvz.jpg",
        "id_str" : "852559706170306560",
        "id" : 852559706170306560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C9TmiSQXsAAodvz.jpg",
        "sizes" : [ {
          "h" : 280,
          "resize" : "fit",
          "w" : 496
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 496
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 496
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 496
        } ],
        "display_url" : "pic.twitter.com\/5lKWTZuKtW"
      } ],
      "hashtags" : [ {
        "text" : "mozsprint",
        "indices" : [ 36, 46 ]
      }, {
        "text" : "openscience",
        "indices" : [ 84, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/o4Ar7WWpBp",
        "expanded_url" : "https:\/\/science.mozilla.org\/blog\/global-sprint-std",
        "display_url" : "science.mozilla.org\/blog\/global-sp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "852560008386666496",
    "text" : "Beyond excited to announce our 2017 #mozsprint, June 1-2, join us to collaborate on #openscience projects globally: https:\/\/t.co\/o4Ar7WWpBp https:\/\/t.co\/5lKWTZuKtW",
    "id" : 852560008386666496,
    "created_at" : "2017-04-13 16:32:00 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 852648486076076032,
  "created_at" : "2017-04-13 22:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Leimbach",
      "screen_name" : "aleimba",
      "indices" : [ 0, 8 ],
      "id_str" : "353615907",
      "id" : 353615907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852564732418682881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405865227356, 8.753424046699948 ]
  },
  "id_str" : "852566997892202496",
  "in_reply_to_user_id" : 353615907,
  "text" : "@aleimba totally agree.",
  "id" : 852566997892202496,
  "in_reply_to_status_id" : 852564732418682881,
  "created_at" : "2017-04-13 16:59:46 +0000",
  "in_reply_to_screen_name" : "aleimba",
  "in_reply_to_user_id_str" : "353615907",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "ISMBECCB",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ugvjyBQ4ub",
      "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2017",
      "display_url" : "open-bio.org\/wiki\/BOSC_2017"
    } ]
  },
  "geo" : { },
  "id_str" : "852507488859631616",
  "text" : "RT @OBF_BOSC: Reminder TODAY (Thursday 13 April) is main deadline for abstracts to #BOSC2017, #ISMBECCB \u2026 https:\/\/t.co\/ugvjyBQ4ub https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 69, 78 ]
      }, {
        "text" : "ISMBECCB",
        "indices" : [ 80, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/ugvjyBQ4ub",
        "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2017",
        "display_url" : "open-bio.org\/wiki\/BOSC_2017"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/3oVBVob806",
        "expanded_url" : "https:\/\/www.iscb.org\/ismbeccb2017\/2933",
        "display_url" : "iscb.org\/ismbeccb2017\/2\u2026"
      }, {
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/osgIUdvXQS",
        "expanded_url" : "https:\/\/twitter.com\/obf_news\/status\/852469343157989378",
        "display_url" : "twitter.com\/obf_news\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "852470314823020544",
    "text" : "Reminder TODAY (Thursday 13 April) is main deadline for abstracts to #BOSC2017, #ISMBECCB \u2026 https:\/\/t.co\/ugvjyBQ4ub https:\/\/t.co\/3oVBVob806 https:\/\/t.co\/osgIUdvXQS",
    "id" : 852470314823020544,
    "created_at" : "2017-04-13 10:35:35 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 852507488859631616,
  "created_at" : "2017-04-13 13:03:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852456615785582592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232141587078, 8.627556321435208 ]
  },
  "id_str" : "852458312247410688",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks and yeah, it\u2019s hard to beat the experience of good mentorship!",
  "id" : 852458312247410688,
  "in_reply_to_status_id" : 852456615785582592,
  "created_at" : "2017-04-13 09:47:54 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "852457956134334464",
  "text" : "RT @PhilippBayer: @gedankenstuecke great thread! One of the main reasons I'm still with my PhD's supervisor during postdoc is that he's a p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "852044321310203910",
    "geo" : { },
    "id_str" : "852456615785582592",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke great thread! One of the main reasons I'm still with my PhD's supervisor during postdoc is that he's a pretty great mentor",
    "id" : 852456615785582592,
    "in_reply_to_status_id" : 852044321310203910,
    "created_at" : "2017-04-13 09:41:09 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 852457956134334464,
  "created_at" : "2017-04-13 09:46:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/XjJZq7DmiD",
      "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_Abstract_Submission",
      "display_url" : "open-bio.org\/wiki\/BOSC_Abst\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230219564964, 8.627579321683635 ]
  },
  "id_str" : "852455739155251201",
  "text" : "Open Source Bioinformaticians please remember: Today is your last chance to submit an abstract for #BOSC2017 https:\/\/t.co\/XjJZq7DmiD",
  "id" : 852455739155251201,
  "created_at" : "2017-04-13 09:37:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852449189493649408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229273449635, 8.627586752396628 ]
  },
  "id_str" : "852450696708411392",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp and as code is law, code is poetry? ;)",
  "id" : 852450696708411392,
  "in_reply_to_status_id" : 852449189493649408,
  "created_at" : "2017-04-13 09:17:38 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 9, 21 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852448308413026305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234301411553, 8.627530281486008 ]
  },
  "id_str" : "852448467448418305",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @TwelveSharp I think they call it \u201EG\u00FCltigkeitszeitraum\u201C in those cases.",
  "id" : 852448467448418305,
  "in_reply_to_status_id" : 852448308413026305,
  "created_at" : "2017-04-13 09:08:47 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chocho Zhang",
      "screen_name" : "chocho_z",
      "indices" : [ 0, 9 ],
      "id_str" : "3221119766",
      "id" : 3221119766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852409286692962305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232630681109, 8.6275332594587 ]
  },
  "id_str" : "852439895675207680",
  "in_reply_to_user_id" : 3221119766,
  "text" : "@chocho_z \uD83D\uDE0D",
  "id" : 852439895675207680,
  "in_reply_to_status_id" : 852409286692962305,
  "created_at" : "2017-04-13 08:34:43 +0000",
  "in_reply_to_screen_name" : "chocho_z",
  "in_reply_to_user_id_str" : "3221119766",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yves Clement",
      "screen_name" : "TwelveSharp",
      "indices" : [ 0, 12 ],
      "id_str" : "519952673",
      "id" : 519952673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852425953934442496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233613952579, 8.627530113091874 ]
  },
  "id_str" : "852430679061254144",
  "in_reply_to_user_id" : 519952673,
  "text" : "@TwelveSharp the language of poets. If by poet one means lawyers. :p",
  "id" : 852430679061254144,
  "in_reply_to_status_id" : 852425953934442496,
  "created_at" : "2017-04-13 07:58:05 +0000",
  "in_reply_to_screen_name" : "TwelveSharp",
  "in_reply_to_user_id_str" : "519952673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172363522321, 8.627518382256257 ]
  },
  "id_str" : "852424465095036928",
  "text" : "The German language: where \u2018Ehef\u00E4higkeitszeugnis\u2019 has the same ring to it as \u2018Unbedenklichkeitsbescheinigung\u2019.",
  "id" : 852424465095036928,
  "created_at" : "2017-04-13 07:33:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Alli",
      "screen_name" : "headinthebooth",
      "indices" : [ 0, 15 ],
      "id_str" : "332529012",
      "id" : 332529012
    }, {
      "name" : "sydney",
      "screen_name" : "syswsi",
      "indices" : [ 16, 23 ],
      "id_str" : "2786240838",
      "id" : 2786240838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852271076612681728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140598863534, 8.753428918416992 ]
  },
  "id_str" : "852271295169523714",
  "in_reply_to_user_id" : 332529012,
  "text" : "@headinthebooth @syswsi thanks! \uD83D\uDC4D",
  "id" : 852271295169523714,
  "in_reply_to_status_id" : 852271076612681728,
  "created_at" : "2017-04-12 21:24:45 +0000",
  "in_reply_to_screen_name" : "headinthebooth",
  "in_reply_to_user_id_str" : "332529012",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Alli",
      "screen_name" : "headinthebooth",
      "indices" : [ 0, 15 ],
      "id_str" : "332529012",
      "id" : 332529012
    }, {
      "name" : "sydney",
      "screen_name" : "syswsi",
      "indices" : [ 16, 23 ],
      "id_str" : "2786240838",
      "id" : 2786240838
    }, {
      "name" : "DEF CON Bio Hacking",
      "screen_name" : "DC_BHV",
      "indices" : [ 110, 117 ],
      "id_str" : "2573503315",
      "id" : 2573503315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852267294894018560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405969973229, 8.753428688509613 ]
  },
  "id_str" : "852270472129638400",
  "in_reply_to_user_id" : 332529012,
  "text" : "@headinthebooth @syswsi would be much appreciated! Because assume same CoC\/rules\/visitor behavior applies for @DC_BHV as 4 main conference?",
  "id" : 852270472129638400,
  "in_reply_to_status_id" : 852267294894018560,
  "created_at" : "2017-04-12 21:21:29 +0000",
  "in_reply_to_screen_name" : "headinthebooth",
  "in_reply_to_user_id_str" : "332529012",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Alli",
      "screen_name" : "headinthebooth",
      "indices" : [ 0, 15 ],
      "id_str" : "332529012",
      "id" : 332529012
    }, {
      "name" : "sydney",
      "screen_name" : "syswsi",
      "indices" : [ 16, 23 ],
      "id_str" : "2786240838",
      "id" : 2786240838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852265988892610560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140253586163, 8.753461553755294 ]
  },
  "id_str" : "852266835819057152",
  "in_reply_to_user_id" : 332529012,
  "text" : "@headinthebooth @syswsi thanks, do you know of any concrete actions taken after the 2016 incidents mentioned in the article?",
  "id" : 852266835819057152,
  "in_reply_to_status_id" : 852265988892610560,
  "created_at" : "2017-04-12 21:07:02 +0000",
  "in_reply_to_screen_name" : "headinthebooth",
  "in_reply_to_user_id_str" : "332529012",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian",
      "screen_name" : "MrEnkapsis",
      "indices" : [ 0, 11 ],
      "id_str" : "115717883",
      "id" : 115717883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852261543563714560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11137384390454, 8.75567885011466 ]
  },
  "id_str" : "852262686947778564",
  "in_reply_to_user_id" : 115717883,
  "text" : "@MrEnkapsis \uD83D\uDC4B hey \uD83D\uDE0A",
  "id" : 852262686947778564,
  "in_reply_to_status_id" : 852261543563714560,
  "created_at" : "2017-04-12 20:50:33 +0000",
  "in_reply_to_screen_name" : "MrEnkapsis",
  "in_reply_to_user_id_str" : "115717883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/31R6qJgc3H",
      "expanded_url" : "https:\/\/twitter.com\/keyboardpipette\/status\/852255501270364160",
      "display_url" : "twitter.com\/keyboardpipett\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140595193088, 8.75342915300861 ]
  },
  "id_str" : "852260926413840390",
  "text" : "So which gene name was auto-converted to November Rain? https:\/\/t.co\/31R6qJgc3H",
  "id" : 852260926413840390,
  "created_at" : "2017-04-12 20:43:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852249092222836736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405921599491, 8.753429934006608 ]
  },
  "id_str" : "852249126892908544",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor danke &lt;3",
  "id" : 852249126892908544,
  "in_reply_to_status_id" : 852249092222836736,
  "created_at" : "2017-04-12 19:56:40 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852248831282565120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405921599491, 8.753429934006608 ]
  },
  "id_str" : "852249008114458624",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor haha, ernsthaft? :D",
  "id" : 852249008114458624,
  "in_reply_to_status_id" : 852248831282565120,
  "created_at" : "2017-04-12 19:56:12 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/xsilXVSmTk",
      "expanded_url" : "http:\/\/phdcomics.com\/comics.php?f=1940",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "852044321310203910",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723280358003, 8.627540289119766 ]
  },
  "id_str" : "852187003353526273",
  "in_reply_to_user_id" : 14286491,
  "text" : "The latest PhD comic on drive-by mentoring also seems appropriate for this thread: https:\/\/t.co\/xsilXVSmTk",
  "id" : 852187003353526273,
  "in_reply_to_status_id" : 852044321310203910,
  "created_at" : "2017-04-12 15:49:49 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/l5QxseiLW0",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/851554842648748033",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852173064477585412",
  "text" : "RT @gedankenstuecke: As this one is still making the rounds and is being discussed some thoughts on it. https:\/\/t.co\/l5QxseiLW0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/l5QxseiLW0",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/851554842648748033",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.10163408819435, 8.71175379832958 ]
    },
    "id_str" : "852043823333072896",
    "text" : "As this one is still making the rounds and is being discussed some thoughts on it. https:\/\/t.co\/l5QxseiLW0",
    "id" : 852043823333072896,
    "created_at" : "2017-04-12 06:20:52 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 852173064477585412,
  "created_at" : "2017-04-12 14:54:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Gillespie,PhD",
      "screen_name" : "LGillesp13",
      "indices" : [ 0, 11 ],
      "id_str" : "1363508408",
      "id" : 1363508408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852165826430021633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231327292386, 8.627562201029207 ]
  },
  "id_str" : "852168450520883201",
  "in_reply_to_user_id" : 1363508408,
  "text" : "@LGillesp13 thanks for the kind words! \uD83D\uDC96",
  "id" : 852168450520883201,
  "in_reply_to_status_id" : 852165826430021633,
  "created_at" : "2017-04-12 14:36:05 +0000",
  "in_reply_to_screen_name" : "LGillesp13",
  "in_reply_to_user_id_str" : "1363508408",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852147793405849600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233504985017, 8.627547812887313 ]
  },
  "id_str" : "852148130892185600",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima thanks! \uD83D\uDE0D",
  "id" : 852148130892185600,
  "in_reply_to_status_id" : 852147793405849600,
  "created_at" : "2017-04-12 13:15:21 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852138948285661189",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234165190468, 8.627535742439562 ]
  },
  "id_str" : "852139500918771718",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb Oh, I hadn\u2019t noticed!",
  "id" : 852139500918771718,
  "in_reply_to_status_id" : 852138948285661189,
  "created_at" : "2017-04-12 12:41:03 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852138108380381186",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234809691501, 8.627518023237334 ]
  },
  "id_str" : "852138524488982528",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb Ah, Hesse, Bavaria &amp; Saarland are the evil\u2122 states!",
  "id" : 852138524488982528,
  "in_reply_to_status_id" : 852138108380381186,
  "created_at" : "2017-04-12 12:37:10 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/cOCHZOCz0g",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/852130037318918145",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234171725855, 8.627532147329168 ]
  },
  "id_str" : "852131099207716864",
  "text" : "Also: Shops in \uD83C\uDDE9\uD83C\uDDEA close at 8pm tomorrow (will feel like \uD83C\uDDE8\uD83C\uDDED for once). I had a forced diet on Good Friday because of this last year\u2026 \uD83D\uDE02 https:\/\/t.co\/cOCHZOCz0g",
  "id" : 852131099207716864,
  "created_at" : "2017-04-12 12:07:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikels Skele",
      "screen_name" : "Skelemika",
      "indices" : [ 0, 10 ],
      "id_str" : "1428336606",
      "id" : 1428336606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852128563339939840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232901434085, 8.627549002431122 ]
  },
  "id_str" : "852128855708119040",
  "in_reply_to_user_id" : 1428336606,
  "text" : "@Skelemika maybe another discipline specific difference? Assume students in STEM are more dependent on supervisors (access to lab\/money).",
  "id" : 852128855708119040,
  "in_reply_to_status_id" : 852128563339939840,
  "created_at" : "2017-04-12 11:58:45 +0000",
  "in_reply_to_screen_name" : "Skelemika",
  "in_reply_to_user_id_str" : "1428336606",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    }, {
      "name" : "Jonathan Dugan",
      "screen_name" : "JMDugan",
      "indices" : [ 11, 19 ],
      "id_str" : "14747526",
      "id" : 14747526
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 20, 25 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852128219532849153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233058990405, 8.627557883573783 ]
  },
  "id_str" : "852128316526137357",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice @JMDugan @PLOS well done! \uD83D\uDC4D\uD83D\uDE02",
  "id" : 852128316526137357,
  "in_reply_to_status_id" : 852128219532849153,
  "created_at" : "2017-04-12 11:56:37 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikels Skele",
      "screen_name" : "Skelemika",
      "indices" : [ 0, 10 ],
      "id_str" : "1428336606",
      "id" : 1428336606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852126890982854656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233058990405, 8.627557883573783 ]
  },
  "id_str" : "852127979702562816",
  "in_reply_to_user_id" : 1428336606,
  "text" : "@Skelemika yes, some. But the power &amp; experience differential puts more of the burden &amp; responsibility on the supervisors.",
  "id" : 852127979702562816,
  "in_reply_to_status_id" : 852126890982854656,
  "created_at" : "2017-04-12 11:55:16 +0000",
  "in_reply_to_screen_name" : "Skelemika",
  "in_reply_to_user_id_str" : "1428336606",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Dawn Field",
      "screen_name" : "fiedawn",
      "indices" : [ 47, 55 ],
      "id_str" : "18589743",
      "id" : 18589743
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 73, 89 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/BluSlOMbMo",
      "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_2017_Keynote_Speakers",
      "display_url" : "open-bio.org\/wiki\/BOSC_2017\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852113758168252416",
  "text" : "RT @OBF_BOSC: #BOSC2017 keynotes by Dawn Field @fiedawn &amp; Nick Loman @pathogenomenick https:\/\/t.co\/BluSlOMbMo\n\nIf you want to talk, abstrac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dawn Field",
        "screen_name" : "fiedawn",
        "indices" : [ 33, 41 ],
        "id_str" : "18589743",
        "id" : 18589743
      }, {
        "name" : "Nick Loman",
        "screen_name" : "pathogenomenick",
        "indices" : [ 59, 75 ],
        "id_str" : "85906238",
        "id" : 85906238
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/BluSlOMbMo",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_2017_Keynote_Speakers",
        "display_url" : "open-bio.org\/wiki\/BOSC_2017\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "852113158575710209",
    "text" : "#BOSC2017 keynotes by Dawn Field @fiedawn &amp; Nick Loman @pathogenomenick https:\/\/t.co\/BluSlOMbMo\n\nIf you want to talk, abstracts due 13 April",
    "id" : 852113158575710209,
    "created_at" : "2017-04-12 10:56:23 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 852113758168252416,
  "created_at" : "2017-04-12 10:58:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/3qgQuTgKLi",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/852043823333072896",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852112633734025216",
  "text" : "RT @Senficon: This thread: https:\/\/t.co\/3qgQuTgKLi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/3qgQuTgKLi",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/852043823333072896",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "852105705171693569",
    "text" : "This thread: https:\/\/t.co\/3qgQuTgKLi",
    "id" : 852105705171693569,
    "created_at" : "2017-04-12 10:26:46 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 852112633734025216,
  "created_at" : "2017-04-12 10:54:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852097557270593536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235421354471, 8.627535858011132 ]
  },
  "id_str" : "852097821293654016",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage alles klar :D",
  "id" : 852097821293654016,
  "in_reply_to_status_id" : 852097557270593536,
  "created_at" : "2017-04-12 09:55:26 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/igPdJeTbvn",
      "expanded_url" : "https:\/\/medium.com\/athena-talks\/queer-pressure-when-inclusivity-fails-45e2747d8925?source=twitterShare-aaeb714c1b80-1491988693",
      "display_url" : "medium.com\/athena-talks\/q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "852088533590343680",
  "text" : "Queer Pressure\u200A\u2014\u200AWhen Inclusivity Fails https:\/\/t.co\/igPdJeTbvn",
  "id" : 852088533590343680,
  "created_at" : "2017-04-12 09:18:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Dugan",
      "screen_name" : "JMDugan",
      "indices" : [ 0, 8 ],
      "id_str" : "14747526",
      "id" : 14747526
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 9, 14 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852086549747466240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226307380673, 8.627530636257521 ]
  },
  "id_str" : "852088175237496832",
  "in_reply_to_user_id" : 14747526,
  "text" : "@JMDugan @PLOS saw that too, totally bugs me. :(",
  "id" : 852088175237496832,
  "in_reply_to_status_id" : 852086549747466240,
  "created_at" : "2017-04-12 09:17:06 +0000",
  "in_reply_to_screen_name" : "JMDugan",
  "in_reply_to_user_id_str" : "14747526",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/azUnp9Ivw8",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0175368#abstract0",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234894158555, 8.62751805453029 ]
  },
  "id_str" : "852081631099854848",
  "text" : "A systematic identification and analysis of scientists on Twitter https:\/\/t.co\/azUnp9Ivw8",
  "id" : 852081631099854848,
  "created_at" : "2017-04-12 08:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikels Skele",
      "screen_name" : "Skelemika",
      "indices" : [ 0, 10 ],
      "id_str" : "1428336606",
      "id" : 1428336606
    }, {
      "name" : "Niki",
      "screen_name" : "TheZwitterion",
      "indices" : [ 11, 25 ],
      "id_str" : "161682025",
      "id" : 161682025
    }, {
      "name" : "Abeba Birhane",
      "screen_name" : "Abebab",
      "indices" : [ 26, 33 ],
      "id_str" : "229005889",
      "id" : 229005889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Q2SvVMG7f3",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/852043823333072896",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "851966599372439552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11111912221734, 8.690070823131743 ]
  },
  "id_str" : "852044505532387329",
  "in_reply_to_user_id" : 1428336606,
  "text" : "@Skelemika @TheZwitterion @Abebab sorry, needed a bit more space for my reply. See thread here: https:\/\/t.co\/Q2SvVMG7f3",
  "id" : 852044505532387329,
  "in_reply_to_status_id" : 851966599372439552,
  "created_at" : "2017-04-12 06:23:34 +0000",
  "in_reply_to_screen_name" : "Skelemika",
  "in_reply_to_user_id_str" : "1428336606",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852044271355961347",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11150850435779, 8.689619684616613 ]
  },
  "id_str" : "852044321310203910",
  "in_reply_to_user_id" : 14286491,
  "text" : "tl;dr: Systematic failure of teaching mentoring skills reproduces bad supervision &amp; is the consequence of current academic reward structure.",
  "id" : 852044321310203910,
  "in_reply_to_status_id" : 852044271355961347,
  "created_at" : "2017-04-12 06:22:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852044240171302913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11541375400345, 8.684753130917857 ]
  },
  "id_str" : "852044271355961347",
  "in_reply_to_user_id" : 14286491,
  "text" : "Instead everyone is learning by example from their supervisors. Which might work fine if you\u2019re having good examples an horribly otherwise.",
  "id" : 852044271355961347,
  "in_reply_to_status_id" : 852044240171302913,
  "created_at" : "2017-04-12 06:22:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852044156910186499",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11040602188827, 8.695191619888691 ]
  },
  "id_str" : "852044240171302913",
  "in_reply_to_user_id" : 14286491,
  "text" : "Unfortunately the ability to get research published in the right places is an extremely bad predictor for supervision skills.",
  "id" : 852044240171302913,
  "in_reply_to_status_id" : 852044156910186499,
  "created_at" : "2017-04-12 06:22:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852044107438448641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11037109534348, 8.695399331348222 ]
  },
  "id_str" : "852044156910186499",
  "in_reply_to_user_id" : 14286491,
  "text" : "Yet, everyone and their dog are put in a position to supervise students, based on the fact that they are publishing \u201Chigh impact\u201D research.",
  "id" : 852044156910186499,
  "in_reply_to_status_id" : 852044107438448641,
  "created_at" : "2017-04-12 06:22:11 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852044014664601604",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10165233913893, 8.689652408506332 ]
  },
  "id_str" : "852044107438448641",
  "in_reply_to_user_id" : 14286491,
  "text" : "We wouldn\u2019t let anyone perform experiments without first learning about lab safety. Instead it\u2019s a legal requirement to protect people.",
  "id" : 852044107438448641,
  "in_reply_to_status_id" : 852044014664601604,
  "created_at" : "2017-04-12 06:22:00 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852043923518234624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10165023051292, 8.700723224954102 ]
  },
  "id_str" : "852044014664601604",
  "in_reply_to_user_id" : 14286491,
  "text" : "Which isn\u2019t necessarily even bad intent from the supervisor\u2019s side, it\u2019s a lack of training when it comes to supervising.",
  "id" : 852044014664601604,
  "in_reply_to_status_id" : 852043923518234624,
  "created_at" : "2017-04-12 06:21:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "852043823333072896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10163778551122, 8.711755152647722 ]
  },
  "id_str" : "852043923518234624",
  "in_reply_to_user_id" : 14286491,
  "text" : "Being a good student might be the mentees responsibility, but there\u2019s a ton of bad supervisors keeping students from being good at science.",
  "id" : 852043923518234624,
  "in_reply_to_status_id" : 852043823333072896,
  "created_at" : "2017-04-12 06:21:16 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/l5QxseiLW0",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/851554842648748033",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10163408819435, 8.71175379832958 ]
  },
  "id_str" : "852043823333072896",
  "text" : "As this one is still making the rounds and is being discussed some thoughts on it. https:\/\/t.co\/l5QxseiLW0",
  "id" : 852043823333072896,
  "created_at" : "2017-04-12 06:20:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sydney",
      "screen_name" : "syswsi",
      "indices" : [ 0, 7 ],
      "id_str" : "2786240838",
      "id" : 2786240838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/X4mwTM1m4H",
      "expanded_url" : "https:\/\/medium.com\/@emilymaxima\/when-will-defcon-stop-being-a-massive-sexist-cringe-fest-cd9d58ccb549?source=linkShare-aaeb714c1b80-1491977170",
      "display_url" : "medium.com\/@emilymaxima\/w\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "852010777192013826",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10565447131161, 8.739715976427096 ]
  },
  "id_str" : "852040442203955201",
  "in_reply_to_user_id" : 2786240838,
  "text" : "@syswsi great hearing from you! Sounds interesting. But has anything changed compared to e.g. this report? https:\/\/t.co\/X4mwTM1m4H",
  "id" : 852040442203955201,
  "in_reply_to_status_id" : 852010777192013826,
  "created_at" : "2017-04-12 06:07:26 +0000",
  "in_reply_to_screen_name" : "syswsi",
  "in_reply_to_user_id_str" : "2786240838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "indices" : [ 3, 12 ],
      "id_str" : "18284047",
      "id" : 18284047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851926538819907585",
  "text" : "RT @chapmanb: A welcoming, open community solving biological problems with code; submit an abstract before Thursday for @BOSC 2017 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Vh6n0h8bjh",
        "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2017",
        "display_url" : "open-bio.org\/wiki\/BOSC_2017"
      } ]
    },
    "geo" : { },
    "id_str" : "851802815571820544",
    "text" : "A welcoming, open community solving biological problems with code; submit an abstract before Thursday for @BOSC 2017 https:\/\/t.co\/Vh6n0h8bjh",
    "id" : 851802815571820544,
    "created_at" : "2017-04-11 14:23:11 +0000",
    "user" : {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "protected" : false,
      "id_str" : "18284047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200195086\/356314252_7adb180ecc_normal.jpg",
      "id" : 18284047,
      "verified" : false
    }
  },
  "id" : 851926538819907585,
  "created_at" : "2017-04-11 22:34:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikels Skele",
      "screen_name" : "Skelemika",
      "indices" : [ 0, 10 ],
      "id_str" : "1428336606",
      "id" : 1428336606
    }, {
      "name" : "Niki",
      "screen_name" : "TheZwitterion",
      "indices" : [ 11, 25 ],
      "id_str" : "161682025",
      "id" : 161682025
    }, {
      "name" : "Abeba Birhane",
      "screen_name" : "Abebab",
      "indices" : [ 26, 33 ],
      "id_str" : "229005889",
      "id" : 229005889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851903535142891520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405906234086, 8.753429042917652 ]
  },
  "id_str" : "851923791076896769",
  "in_reply_to_user_id" : 1428336606,
  "text" : "@Skelemika @TheZwitterion @Abebab that\u2019s true in STEM too. But: failing students are mostly seen as failing personally, not mentoring fails.",
  "id" : 851923791076896769,
  "in_reply_to_status_id" : 851903535142891520,
  "created_at" : "2017-04-11 22:23:54 +0000",
  "in_reply_to_screen_name" : "Skelemika",
  "in_reply_to_user_id_str" : "1428336606",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 3, 8 ],
      "id_str" : "9377892",
      "id" : 9377892
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tpoi\/status\/851880745400455168\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/1cXyrN5jcL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C9J9AVpXYAA8Fwl.jpg",
      "id_str" : "851880724290560000",
      "id" : 851880724290560000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9J9AVpXYAA8Fwl.jpg",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 739
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 739
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 739
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1cXyrN5jcL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851889159103033344",
  "text" : "RT @tpoi: I love the first answer more than I should. https:\/\/t.co\/1cXyrN5jcL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tpoi\/status\/851880745400455168\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/1cXyrN5jcL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C9J9AVpXYAA8Fwl.jpg",
        "id_str" : "851880724290560000",
        "id" : 851880724290560000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9J9AVpXYAA8Fwl.jpg",
        "sizes" : [ {
          "h" : 306,
          "resize" : "fit",
          "w" : 739
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 739
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 739
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/1cXyrN5jcL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "851880745400455168",
    "text" : "I love the first answer more than I should. https:\/\/t.co\/1cXyrN5jcL",
    "id" : 851880745400455168,
    "created_at" : "2017-04-11 19:32:51 +0000",
    "user" : {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "protected" : false,
      "id_str" : "9377892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919272965581299713\/CCD-XjJ1_normal.jpg",
      "id" : 9377892,
      "verified" : false
    }
  },
  "id" : 851889159103033344,
  "created_at" : "2017-04-11 20:06:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shimrit Meir",
      "screen_name" : "shimritmeir",
      "indices" : [ 3, 15 ],
      "id_str" : "247244259",
      "id" : 247244259
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/shimritmeir\/status\/851865517686239232\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/o3NnZuzNu9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C9JvKs7XoAAjjas.jpg",
      "id_str" : "851865509175992320",
      "id" : 851865509175992320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9JvKs7XoAAjjas.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/o3NnZuzNu9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851871722353676288",
  "text" : "RT @shimritmeir: \u05D9\u05D5\u05DD \u05E2\u05DE\u05D5\u05E1 \u05DC\u05DB\u05D5\u05EA\u05D1\u05D9 \u05D4\u05E1\u05D8\u05E8\u05D9\u05D9\u05E4\u05D9\u05DD https:\/\/t.co\/o3NnZuzNu9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/shimritmeir\/status\/851865517686239232\/photo\/1",
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/o3NnZuzNu9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C9JvKs7XoAAjjas.jpg",
        "id_str" : "851865509175992320",
        "id" : 851865509175992320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9JvKs7XoAAjjas.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/o3NnZuzNu9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "851860951619993602",
    "geo" : { },
    "id_str" : "851865517686239232",
    "in_reply_to_user_id" : 247244259,
    "text" : "\u05D9\u05D5\u05DD \u05E2\u05DE\u05D5\u05E1 \u05DC\u05DB\u05D5\u05EA\u05D1\u05D9 \u05D4\u05E1\u05D8\u05E8\u05D9\u05D9\u05E4\u05D9\u05DD https:\/\/t.co\/o3NnZuzNu9",
    "id" : 851865517686239232,
    "in_reply_to_status_id" : 851860951619993602,
    "created_at" : "2017-04-11 18:32:20 +0000",
    "in_reply_to_screen_name" : "shimritmeir",
    "in_reply_to_user_id_str" : "247244259",
    "user" : {
      "name" : "Shimrit Meir",
      "screen_name" : "shimritmeir",
      "protected" : false,
      "id_str" : "247244259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/869633583765495808\/IagkH4xY_normal.jpg",
      "id" : 247244259,
      "verified" : false
    }
  },
  "id" : 851871722353676288,
  "created_at" : "2017-04-11 18:57:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 9, 18 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/851836774330621952\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/OjjBfunREG",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C9JVBp1XgAAT-zy.jpg",
      "id_str" : "851836766424367104",
      "id" : 851836766424367104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C9JVBp1XgAAT-zy.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/OjjBfunREG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851835746390597633",
  "geo" : { },
  "id_str" : "851836774330621952",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @OBF_BOSC Aren't we all, one way or another? https:\/\/t.co\/OjjBfunREG",
  "id" : 851836774330621952,
  "in_reply_to_status_id" : 851835746390597633,
  "created_at" : "2017-04-11 16:38:08 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 28, 37 ]
    }, {
      "text" : "ISMBECCB",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ruCbn3kIeP",
      "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_2017",
      "display_url" : "open-bio.org\/wiki\/BOSC_2017"
    } ]
  },
  "geo" : { },
  "id_str" : "851825010662625280",
  "text" : "RT @OBF_BOSC: Abstracts for #BOSC2017 and other groups at #ISMBECCB conference due this Thursday 13 April https:\/\/t.co\/ruCbn3kIeP https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 14, 23 ]
      }, {
        "text" : "ISMBECCB",
        "indices" : [ 44, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/ruCbn3kIeP",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_2017",
        "display_url" : "open-bio.org\/wiki\/BOSC_2017"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/zqSCpYiLrN",
        "expanded_url" : "https:\/\/www.iscb.org\/ismbeccb2017",
        "display_url" : "iscb.org\/ismbeccb2017"
      } ]
    },
    "geo" : { },
    "id_str" : "851764611309285377",
    "text" : "Abstracts for #BOSC2017 and other groups at #ISMBECCB conference due this Thursday 13 April https:\/\/t.co\/ruCbn3kIeP https:\/\/t.co\/zqSCpYiLrN",
    "id" : 851764611309285377,
    "created_at" : "2017-04-11 11:51:23 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 851825010662625280,
  "created_at" : "2017-04-11 15:51:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235134931347, 8.627514085060106 ]
  },
  "id_str" : "851820330398220289",
  "text" : "@LizMarchio in my experience the worst ones are the ones that alternate between hands-off and micro-managing. Means constant stress.",
  "id" : 851820330398220289,
  "created_at" : "2017-04-11 15:32:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mich\u24D0el\u24D0  Rossini",
      "screen_name" : "mr0ssini",
      "indices" : [ 3, 12 ],
      "id_str" : "161270361",
      "id" : 161270361
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 100, 116 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scihub",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/e6KafTelmu",
      "expanded_url" : "http:\/\/www.the-scientist.com\/?articles.view%2FarticleNo%2F49177%2Ftitle%2FNine-Publishers--Millions-of-Illegal-Paper-Downloads%2F&utm_campaign=NEWSLETTER_TS_The-Scientist-Daily_2016&utm_source=hs_email&utm_medium=email&utm_content=50393312&_hsenc=p2ANqtz-_fFwGADXRgtmeiLpGKuY9ID4LlKziw21H5AAG1bxXC1mkWBkMJuvjDy1B7EvhTtkyBiV7zanwFOTw07vPo-Tu3DRAan1coSIGF-7A-4czvVOBSSnU&_hsmi=50393312%2F#.WOzt6PdHlQt.twitter",
      "display_url" : "the-scientist.com\/?articles.view\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851819966848520192",
  "text" : "RT @mr0ssini: Nine Publishers, Millions of Illegal Paper Downloads  https:\/\/t.co\/e6KafTelmu #scihub @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 86, 102 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scihub",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/e6KafTelmu",
        "expanded_url" : "http:\/\/www.the-scientist.com\/?articles.view%2FarticleNo%2F49177%2Ftitle%2FNine-Publishers--Millions-of-Illegal-Paper-Downloads%2F&utm_campaign=NEWSLETTER_TS_The-Scientist-Daily_2016&utm_source=hs_email&utm_medium=email&utm_content=50393312&_hsenc=p2ANqtz-_fFwGADXRgtmeiLpGKuY9ID4LlKziw21H5AAG1bxXC1mkWBkMJuvjDy1B7EvhTtkyBiV7zanwFOTw07vPo-Tu3DRAan1coSIGF-7A-4czvVOBSSnU&_hsmi=50393312%2F#.WOzt6PdHlQt.twitter",
        "display_url" : "the-scientist.com\/?articles.view\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "851810648099082240",
    "text" : "Nine Publishers, Millions of Illegal Paper Downloads  https:\/\/t.co\/e6KafTelmu #scihub @gedankenstuecke",
    "id" : 851810648099082240,
    "created_at" : "2017-04-11 14:54:19 +0000",
    "user" : {
      "name" : "Mich\u24D0el\u24D0  Rossini",
      "screen_name" : "mr0ssini",
      "protected" : false,
      "id_str" : "161270361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613993979231772672\/TTPr8vTW_normal.jpg",
      "id" : 161270361,
      "verified" : false
    }
  },
  "id" : 851819966848520192,
  "created_at" : "2017-04-11 15:31:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851806384542818304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234237218462, 8.62751820484394 ]
  },
  "id_str" : "851806616890609665",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer reusers live off the data provided &amp; it\u2019s hosted in the technical sense as well. Looking forward to the \u201Eresearch host awards\u201C",
  "id" : 851806616890609665,
  "in_reply_to_status_id" : 851806384542818304,
  "created_at" : "2017-04-11 14:38:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851803326635057152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235153037655, 8.627513246189794 ]
  },
  "id_str" : "851805408159313920",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, though I guess \u201Ehost\u201C works just as well in this case, doesn\u2019t it? :D",
  "id" : 851805408159313920,
  "in_reply_to_status_id" : 851803326635057152,
  "created_at" : "2017-04-11 14:33:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/KYj5diJIzY",
      "expanded_url" : "https:\/\/github.com\/trvinh\/phyloprofile\/blob\/master\/data\/demo\/test.main.long",
      "display_url" : "github.com\/trvinh\/phylopr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "851514651040899072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233019091525, 8.62753810693192 ]
  },
  "id_str" : "851803840106180608",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy have a look at https:\/\/t.co\/KYj5diJIzY You can now also provide long-formatted data, should be much easier to generate.",
  "id" : 851803840106180608,
  "in_reply_to_status_id" : 851514651040899072,
  "created_at" : "2017-04-11 14:27:15 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851796217142968320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235339483948, 8.627518431672028 ]
  },
  "id_str" : "851796331421196289",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer wouldn\u2019t we be a data host? :D",
  "id" : 851796331421196289,
  "in_reply_to_status_id" : 851796217142968320,
  "created_at" : "2017-04-11 13:57:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851791928362385408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233748455144, 8.627545456264983 ]
  },
  "id_str" : "851792448523292673",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer there should be awards for that!",
  "id" : 851792448523292673,
  "in_reply_to_status_id" : 851791928362385408,
  "created_at" : "2017-04-11 13:41:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851788704360411136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233940922533, 8.627535487834152 ]
  },
  "id_str" : "851788841119821824",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC thanks, the #BOSC2017 deadline was the one of interest. :)",
  "id" : 851788841119821824,
  "in_reply_to_status_id" : 851788704360411136,
  "created_at" : "2017-04-11 13:27:39 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceMarch",
      "indices" : [ 10, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/8k0FzBXLgP",
      "expanded_url" : "https:\/\/upload.wikimedia.org\/wikipedia\/commons\/thumb\/b\/b4\/Hannibal_in_Italy_by_Jacopo_Ripanda_-_Sala_di_Annibale_-_Palazzo_dei_Conservatori_-_Musei_Capitolini_-_Rome_2016_%282%29.jpg\/800px-Hannibal_in_Italy_by_Jacopo_Ripanda_-_Sala_di_Annibale_-_Palazzo_dei_Conservatori_-_Musei_Capitolini_-_Rome_2016_%282%29.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    }, {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/c0S7DJQRuP",
      "expanded_url" : "https:\/\/twitter.com\/statnews\/status\/851782045495955458",
      "display_url" : "twitter.com\/statnews\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233877012804, 8.627528594469617 ]
  },
  "id_str" : "851783215664726016",
  "text" : "Breaking: #ScienceMarch Boston will be done riding on mammoths\u2019 backs. First artistic impressions: https:\/\/t.co\/8k0FzBXLgP https:\/\/t.co\/c0S7DJQRuP",
  "id" : 851783215664726016,
  "created_at" : "2017-04-11 13:05:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/4xkhYljPig",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/851779415872688129",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233224121313, 8.627540795483139 ]
  },
  "id_str" : "851781003924426752",
  "text" : "Also a true story. \uD83D\uDE02 https:\/\/t.co\/4xkhYljPig",
  "id" : 851781003924426752,
  "created_at" : "2017-04-11 12:56:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/e8iXOm1jws",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.2001818",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234343837355, 8.627523350360676 ]
  },
  "id_str" : "851773793425121280",
  "text" : "I for one would much rather have biomedical research be the (old, non-profit) CouchSurfing than Airbnb\u2026 https:\/\/t.co\/e8iXOm1jws",
  "id" : 851773793425121280,
  "created_at" : "2017-04-11 12:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/y8EKaNq61y",
      "expanded_url" : "https:\/\/blogs.scientificamerican.com\/dog-spies\/things-to-know-on-dog-farting-awareness-day\/",
      "display_url" : "blogs.scientificamerican.com\/dog-spies\/thin\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233210539935, 8.627532814899078 ]
  },
  "id_str" : "851769468913102849",
  "text" : "Oh no, I missed Dog Farting Awareness Day! https:\/\/t.co\/y8EKaNq61y",
  "id" : 851769468913102849,
  "created_at" : "2017-04-11 12:10:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9xUMTeFFXp",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0175418",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234035999061, 8.627603305088721 ]
  },
  "id_str" : "851768065201238016",
  "text" : "Assessing the uptake of persistent identifiers by research infrastructure users https:\/\/t.co\/9xUMTeFFXp",
  "id" : 851768065201238016,
  "created_at" : "2017-04-11 12:05:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851764611309285377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233443208253, 8.627533492771933 ]
  },
  "id_str" : "851766478848364544",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC I was asked about that: End of day on 13th or end of 12th? :D",
  "id" : 851766478848364544,
  "in_reply_to_status_id" : 851764611309285377,
  "created_at" : "2017-04-11 11:58:48 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851764903224512512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233443208253, 8.627533492771933 ]
  },
  "id_str" : "851765975615721476",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed strange. My Chrome + \u00B5block (w\/ \u00B1 standard settings) shows it.",
  "id" : 851765975615721476,
  "in_reply_to_status_id" : 851764903224512512,
  "created_at" : "2017-04-11 11:56:48 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/851764162837565441\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/EHDRw3yRky",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C9IS_RlXcAAkPVt.jpg",
      "id_str" : "851764157787631616",
      "id" : 851764157787631616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C9IS_RlXcAAkPVt.jpg",
      "sizes" : [ {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/EHDRw3yRky"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851762741585096704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237261195351, 8.627543707766408 ]
  },
  "id_str" : "851764162837565441",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed next to Facebook? :) https:\/\/t.co\/EHDRw3yRky",
  "id" : 851764162837565441,
  "in_reply_to_status_id" : 851762741585096704,
  "created_at" : "2017-04-11 11:49:36 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "indices" : [ 0, 15 ],
      "id_str" : "1639877449",
      "id" : 1639877449
    }, {
      "name" : "Paola Masuzzo",
      "screen_name" : "pcmasuzzo",
      "indices" : [ 16, 26 ],
      "id_str" : "438729858",
      "id" : 438729858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851761981497516033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237261195351, 8.627543707766408 ]
  },
  "id_str" : "851764078381064193",
  "in_reply_to_user_id" : 1639877449,
  "text" : "@AsuraEnkhbayar @pcmasuzzo cool, thanks!",
  "id" : 851764078381064193,
  "in_reply_to_status_id" : 851761981497516033,
  "created_at" : "2017-04-11 11:49:15 +0000",
  "in_reply_to_screen_name" : "AsuraEnkhbayar",
  "in_reply_to_user_id_str" : "1639877449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851761215110082560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235531472358, 8.627520274052376 ]
  },
  "id_str" : "851761524725166080",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed yeah, they have the tiny \u201Estar on GH button\u201C on the bottom of their page :D",
  "id" : 851761524725166080,
  "in_reply_to_status_id" : 851761215110082560,
  "created_at" : "2017-04-11 11:39:07 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851758654718185472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229727613998, 8.627509256618167 ]
  },
  "id_str" : "851759094914592769",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed I\u2019m using ether pads a lot for that too. But guess there\u2019s no \u201Cthis is what everyone is using\u201D-consensus yet. :)",
  "id" : 851759094914592769,
  "in_reply_to_status_id" : 851758654718185472,
  "created_at" : "2017-04-11 11:29:27 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/cVZeqnoqiQ",
      "expanded_url" : "https:\/\/hackmd.io\/",
      "display_url" : "hackmd.io"
    } ]
  },
  "in_reply_to_status_id_str" : "851757920459141120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238670482791, 8.62752044744464 ]
  },
  "id_str" : "851758242275491840",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed https:\/\/t.co\/cVZeqnoqiQ could work for that.",
  "id" : 851758242275491840,
  "in_reply_to_status_id" : 851757920459141120,
  "created_at" : "2017-04-11 11:26:04 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851757920459141120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238670482791, 8.62752044744464 ]
  },
  "id_str" : "851758127380824065",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed Thanks, unfortunately Etherpad doesn\u2019t really do the syntax of Markdown. Thought there might be a nicer alternative.",
  "id" : 851758127380824065,
  "in_reply_to_status_id" : 851757920459141120,
  "created_at" : "2017-04-11 11:25:37 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paola Masuzzo",
      "screen_name" : "pcmasuzzo",
      "indices" : [ 0, 10 ],
      "id_str" : "438729858",
      "id" : 438729858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851757679555076096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238670482791, 8.62752044744464 ]
  },
  "id_str" : "851758007956496385",
  "in_reply_to_user_id" : 438729858,
  "text" : "@pcmasuzzo thanks. But I\u2019m fine with Atom \/ iA Writer for solo-writing. Looking for something that\u2019s nicer than Etherpad for &gt;1 person.",
  "id" : 851758007956496385,
  "in_reply_to_status_id" : 851757679555076096,
  "created_at" : "2017-04-11 11:25:08 +0000",
  "in_reply_to_screen_name" : "pcmasuzzo",
  "in_reply_to_user_id_str" : "438729858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723413267625, 8.627532154936729 ]
  },
  "id_str" : "851756355493007360",
  "text" : "Something different folks: are any of you using collaborative editors for drafting READMEs etc, specifically for markdown? If so: which one?",
  "id" : 851756355493007360,
  "created_at" : "2017-04-11 11:18:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marikka Beecroft",
      "screen_name" : "beecr_micro",
      "indices" : [ 0, 12 ],
      "id_str" : "702494148117577729",
      "id" : 702494148117577729
    }, {
      "name" : "Teatime Science!!",
      "screen_name" : "Teatimesci",
      "indices" : [ 13, 24 ],
      "id_str" : "4210783047",
      "id" : 4210783047
    }, {
      "name" : "Kate Armfield",
      "screen_name" : "KateFredA",
      "indices" : [ 25, 35 ],
      "id_str" : "29168271",
      "id" : 29168271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851741784942292993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17180053193396, 8.631481957958712 ]
  },
  "id_str" : "851743995663396864",
  "in_reply_to_user_id" : 702494148117577729,
  "text" : "@beecr_micro @Teatimesci @KateFredA sounds familiar.",
  "id" : 851743995663396864,
  "in_reply_to_status_id" : 851741784942292993,
  "created_at" : "2017-04-11 10:29:27 +0000",
  "in_reply_to_screen_name" : "beecr_micro",
  "in_reply_to_user_id_str" : "702494148117577729",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marikka Beecroft",
      "screen_name" : "beecr_micro",
      "indices" : [ 3, 15 ],
      "id_str" : "702494148117577729",
      "id" : 702494148117577729
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 17, 33 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Teatime Science!!",
      "screen_name" : "Teatimesci",
      "indices" : [ 34, 45 ],
      "id_str" : "4210783047",
      "id" : 4210783047
    }, {
      "name" : "Kate Armfield",
      "screen_name" : "KateFredA",
      "indices" : [ 46, 56 ],
      "id_str" : "29168271",
      "id" : 29168271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851743574559522816",
  "text" : "RT @beecr_micro: @gedankenstuecke @Teatimesci @KateFredA Unfortunately not. I have a fantastic supervisor now but it wasn't always the case\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Teatime Science!!",
        "screen_name" : "Teatimesci",
        "indices" : [ 17, 28 ],
        "id_str" : "4210783047",
        "id" : 4210783047
      }, {
        "name" : "Kate Armfield",
        "screen_name" : "KateFredA",
        "indices" : [ 29, 39 ],
        "id_str" : "29168271",
        "id" : 29168271
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "851741272847126528",
    "geo" : { },
    "id_str" : "851741784942292993",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke @Teatimesci @KateFredA Unfortunately not. I have a fantastic supervisor now but it wasn't always the case &amp; others aren't so lucky!",
    "id" : 851741784942292993,
    "in_reply_to_status_id" : 851741272847126528,
    "created_at" : "2017-04-11 10:20:40 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Marikka Beecroft",
      "screen_name" : "beecr_micro",
      "protected" : false,
      "id_str" : "702494148117577729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836672521151864832\/XcZv6Zya_normal.jpg",
      "id" : 702494148117577729,
      "verified" : false
    }
  },
  "id" : 851743574559522816,
  "created_at" : "2017-04-11 10:27:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marikka Beecroft",
      "screen_name" : "beecr_micro",
      "indices" : [ 0, 12 ],
      "id_str" : "702494148117577729",
      "id" : 702494148117577729
    }, {
      "name" : "Teatime Science!!",
      "screen_name" : "Teatimesci",
      "indices" : [ 13, 24 ],
      "id_str" : "4210783047",
      "id" : 4210783047
    }, {
      "name" : "Kate Armfield",
      "screen_name" : "KateFredA",
      "indices" : [ 25, 35 ],
      "id_str" : "29168271",
      "id" : 29168271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851740677843148800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1718427329586, 8.631262759932923 ]
  },
  "id_str" : "851741272847126528",
  "in_reply_to_user_id" : 702494148117577729,
  "text" : "@beecr_micro @Teatimesci @KateFredA you\u2019re not the first person to say this \uD83D\uDE28",
  "id" : 851741272847126528,
  "in_reply_to_status_id" : 851740677843148800,
  "created_at" : "2017-04-11 10:18:38 +0000",
  "in_reply_to_screen_name" : "beecr_micro",
  "in_reply_to_user_id_str" : "702494148117577729",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ludmila Carone",
      "screen_name" : "Exotides",
      "indices" : [ 3, 12 ],
      "id_str" : "78689305",
      "id" : 78689305
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851732818505986048",
  "text" : "RT @Exotides: @gedankenstuecke I'm a supervisor and know good and excellent supervisors. I can guarantuee you that your mentor royally suck\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "851554842648748033",
    "geo" : { },
    "id_str" : "851732624288690176",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke I'm a supervisor and know good and excellent supervisors. I can guarantuee you that your mentor royally sucks.",
    "id" : 851732624288690176,
    "in_reply_to_status_id" : 851554842648748033,
    "created_at" : "2017-04-11 09:44:16 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Ludmila Carone",
      "screen_name" : "Exotides",
      "protected" : false,
      "id_str" : "78689305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446614853\/HintermMond_normal.jpg",
      "id" : 78689305,
      "verified" : false
    }
  },
  "id" : 851732818505986048,
  "created_at" : "2017-04-11 09:45:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Kingsley",
      "screen_name" : "dannykay68",
      "indices" : [ 3, 14 ],
      "id_str" : "588914106",
      "id" : 588914106
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uksg17",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851731981872267266",
  "text" : "RT @dannykay68: SECOND WORST INVENTION \u2013 after JIF is supplementary data. 80% of links are broken so data is gone #uksg17",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "uksg17",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "851716366193352705",
    "text" : "SECOND WORST INVENTION \u2013 after JIF is supplementary data. 80% of links are broken so data is gone #uksg17",
    "id" : 851716366193352705,
    "created_at" : "2017-04-11 08:39:40 +0000",
    "user" : {
      "name" : "Danny Kingsley",
      "screen_name" : "dannykay68",
      "protected" : false,
      "id_str" : "588914106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554609395917545472\/k1N9aWdb_normal.jpeg",
      "id" : 588914106,
      "verified" : false
    }
  },
  "id" : 851731981872267266,
  "created_at" : "2017-04-11 09:41:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greta Lazutkaite",
      "screen_name" : "GretaLazu",
      "indices" : [ 0, 10 ],
      "id_str" : "773476660008062976",
      "id" : 773476660008062976
    }, {
      "name" : "AMHC",
      "screen_name" : "amhc2016",
      "indices" : [ 11, 20 ],
      "id_str" : "765591701612355585",
      "id" : 765591701612355585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851706473335926784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235463309347, 8.627514335827325 ]
  },
  "id_str" : "851731746294988800",
  "in_reply_to_user_id" : 773476660008062976,
  "text" : "@GretaLazu @amhc2016 not saying there aren\u2019t exceptions. But in the grand scale the responsibility is certainly on the supervisor.",
  "id" : 851731746294988800,
  "in_reply_to_status_id" : 851706473335926784,
  "created_at" : "2017-04-11 09:40:47 +0000",
  "in_reply_to_screen_name" : "GretaLazu",
  "in_reply_to_user_id_str" : "773476660008062976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851731572155965440",
  "text" : "RT @gedankenstuecke: No fellow PhD students, if you\u2019re afraid to meet your supervisor it\u2019s virtually guaranteed that it\u2019s because they suck\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 138, 161 ],
        "url" : "https:\/\/t.co\/9o6qzfFpDE",
        "expanded_url" : "https:\/\/twitter.com\/neuromusic\/status\/851509896491159553",
        "display_url" : "twitter.com\/neuromusic\/sta\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.113845907612, 8.753310910722512 ]
    },
    "id_str" : "851554842648748033",
    "text" : "No fellow PhD students, if you\u2019re afraid to meet your supervisor it\u2019s virtually guaranteed that it\u2019s because they suck at being a mentor. https:\/\/t.co\/9o6qzfFpDE",
    "id" : 851554842648748033,
    "created_at" : "2017-04-10 21:57:50 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 851731572155965440,
  "created_at" : "2017-04-11 09:40:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Yates",
      "screen_name" : "LibraryWriteHer",
      "indices" : [ 7, 23 ],
      "id_str" : "172178529",
      "id" : 172178529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/jjDVeQ7fv5",
      "expanded_url" : "http:\/\/www.ala.org\/acrl\/sites\/ala.org.acrl\/files\/content\/conferences\/confsandpreconfs\/2017\/WalkingthePlank.pdf",
      "display_url" : "ala.org\/acrl\/sites\/ala\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "851014241452740609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235705292642, 8.627518824198816 ]
  },
  "id_str" : "851729505630789632",
  "in_reply_to_user_id" : 14286491,
  "text" : "Thanks @LibraryWriteHer for this case study, demonstrating how copyright can interfere with doing meta-studies! https:\/\/t.co\/jjDVeQ7fv5",
  "id" : 851729505630789632,
  "in_reply_to_status_id" : 851014241452740609,
  "created_at" : "2017-04-11 09:31:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/75kde1y17W",
      "expanded_url" : "https:\/\/twitter.com\/obf_news\/status\/851467741815091201",
      "display_url" : "twitter.com\/obf_news\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851689853532209153",
  "text" : "RT @gedankenstuecke: Submit to #BOSC2017 and join the coolest conference on open source in bioinformatics! https:\/\/t.co\/75kde1y17W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 10, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/75kde1y17W",
        "expanded_url" : "https:\/\/twitter.com\/obf_news\/status\/851467741815091201",
        "display_url" : "twitter.com\/obf_news\/statu\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11405571288107, 8.753432246324726 ]
    },
    "id_str" : "851516067872636928",
    "text" : "Submit to #BOSC2017 and join the coolest conference on open source in bioinformatics! https:\/\/t.co\/75kde1y17W",
    "id" : 851516067872636928,
    "created_at" : "2017-04-10 19:23:45 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 851689853532209153,
  "created_at" : "2017-04-11 06:54:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/WiOcbnahKw",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/04\/08\/124495",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723168350555, 8.62752240730052 ]
  },
  "id_str" : "851688170127339522",
  "text" : "Looking at Altmetrics for my preprint on Sci-Hub is interesting: 50% of people sharing are \u201Emembers of the public\u201C https:\/\/t.co\/WiOcbnahKw",
  "id" : 851688170127339522,
  "created_at" : "2017-04-11 06:47:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paola Masuzzo",
      "screen_name" : "pcmasuzzo",
      "indices" : [ 0, 10 ],
      "id_str" : "438729858",
      "id" : 438729858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851686147499728896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233581796107, 8.627567588218266 ]
  },
  "id_str" : "851687391672795136",
  "in_reply_to_user_id" : 438729858,
  "text" : "@pcmasuzzo good luck with the travel grant!",
  "id" : 851687391672795136,
  "in_reply_to_status_id" : 851686147499728896,
  "created_at" : "2017-04-11 06:44:32 +0000",
  "in_reply_to_screen_name" : "pcmasuzzo",
  "in_reply_to_user_id_str" : "438729858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paola Masuzzo",
      "screen_name" : "pcmasuzzo",
      "indices" : [ 0, 10 ],
      "id_str" : "438729858",
      "id" : 438729858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851685910987067392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17389039553591, 8.628884266792708 ]
  },
  "id_str" : "851685994256449536",
  "in_reply_to_user_id" : 438729858,
  "text" : "@pcmasuzzo awesome! \uD83D\uDE0D",
  "id" : 851685994256449536,
  "in_reply_to_status_id" : 851685910987067392,
  "created_at" : "2017-04-11 06:38:59 +0000",
  "in_reply_to_screen_name" : "pcmasuzzo",
  "in_reply_to_user_id_str" : "438729858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paola Masuzzo",
      "screen_name" : "pcmasuzzo",
      "indices" : [ 0, 10 ],
      "id_str" : "438729858",
      "id" : 438729858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851685533516517376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17391839043099, 8.62842785102821 ]
  },
  "id_str" : "851685650818633728",
  "in_reply_to_user_id" : 438729858,
  "text" : "@pcmasuzzo awesome, looking forward to see you there. What will you present? :)",
  "id" : 851685650818633728,
  "in_reply_to_status_id" : 851685533516517376,
  "created_at" : "2017-04-11 06:37:37 +0000",
  "in_reply_to_screen_name" : "pcmasuzzo",
  "in_reply_to_user_id_str" : "438729858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lily Chumley",
      "screen_name" : "lilychumley",
      "indices" : [ 0, 12 ],
      "id_str" : "404947774",
      "id" : 404947774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851667408284598272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405469364771, 8.753427142424567 ]
  },
  "id_str" : "851670359208337409",
  "in_reply_to_user_id" : 404947774,
  "text" : "@lilychumley \u201Cwhat\u2019s your goal, where are we now, what\u2019s the steps for the next X weeks\u201D. Making sure these are kept is imho superiors task.",
  "id" : 851670359208337409,
  "in_reply_to_status_id" : 851667408284598272,
  "created_at" : "2017-04-11 05:36:51 +0000",
  "in_reply_to_screen_name" : "lilychumley",
  "in_reply_to_user_id_str" : "404947774",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lily Chumley",
      "screen_name" : "lilychumley",
      "indices" : [ 0, 12 ],
      "id_str" : "404947774",
      "id" : 404947774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851667408284598272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405469364771, 8.753427142424567 ]
  },
  "id_str" : "851670105260011520",
  "in_reply_to_user_id" : 404947774,
  "text" : "@lilychumley don\u2019t think it\u2019s about managing research schedules. But having regular meetings about the research is part of mentoring.",
  "id" : 851670105260011520,
  "in_reply_to_status_id" : 851667408284598272,
  "created_at" : "2017-04-11 05:35:51 +0000",
  "in_reply_to_screen_name" : "lilychumley",
  "in_reply_to_user_id_str" : "404947774",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lily Chumley",
      "screen_name" : "lilychumley",
      "indices" : [ 0, 12 ],
      "id_str" : "404947774",
      "id" : 404947774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851581011871776768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405505799169, 8.753427282708165 ]
  },
  "id_str" : "851666010180636672",
  "in_reply_to_user_id" : 404947774,
  "text" : "@lilychumley I think that\u2019s possible. But mentorship is also about how to deal with failure. Even dropping out does not need to lead to this",
  "id" : 851666010180636672,
  "in_reply_to_status_id" : 851581011871776768,
  "created_at" : "2017-04-11 05:19:34 +0000",
  "in_reply_to_screen_name" : "lilychumley",
  "in_reply_to_user_id_str" : "404947774",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 0, 9 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851557404487671813",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140663089142, 8.753434054519545 ]
  },
  "id_str" : "851557709325492224",
  "in_reply_to_user_id" : 583180584,
  "text" : "@OBF_BOSC I hoped so, but now everyone can sleep soundly knowing my pre-OC-fandom. :p",
  "id" : 851557709325492224,
  "in_reply_to_status_id" : 851557404487671813,
  "created_at" : "2017-04-10 22:09:13 +0000",
  "in_reply_to_screen_name" : "OBF_BOSC",
  "in_reply_to_user_id_str" : "583180584",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 52, 61 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allothersbringdata",
      "indices" : [ 102, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/mvSzgDaeQO",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/752144469760368641",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "851554436640100352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406596525481, 8.75343521755009 ]
  },
  "id_str" : "851556155209986050",
  "in_reply_to_user_id" : 14286491,
  "text" : "Don\u2019t only take my word for it, here\u2019s me endorsing @OBF_BOSC before any COI. https:\/\/t.co\/mvSzgDaeQO #allothersbringdata",
  "id" : 851556155209986050,
  "in_reply_to_status_id" : 851554436640100352,
  "created_at" : "2017-04-10 22:03:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 138, 161 ],
      "url" : "https:\/\/t.co\/9o6qzfFpDE",
      "expanded_url" : "https:\/\/twitter.com\/neuromusic\/status\/851509896491159553",
      "display_url" : "twitter.com\/neuromusic\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113845907612, 8.753310910722512 ]
  },
  "id_str" : "851554842648748033",
  "text" : "No fellow PhD students, if you\u2019re afraid to meet your supervisor it\u2019s virtually guaranteed that it\u2019s because they suck at being a mentor. https:\/\/t.co\/9o6qzfFpDE",
  "id" : 851554842648748033,
  "created_at" : "2017-04-10 21:57:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 34, 43 ]
    }, {
      "text" : "BOSC2016",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/B1TmDc6L6c",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/851553853757677569",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396324469085, 8.752935152006252 ]
  },
  "id_str" : "851554436640100352",
  "text" : "You can go back to my tweets from #BOSC2015 and #BOSC2016, where I\u2019ve voiced the same opinion before joining the organizing committee \uD83D\uDE0A\uD83D\uDE09 https:\/\/t.co\/B1TmDc6L6c",
  "id" : 851554436640100352,
  "created_at" : "2017-04-10 21:56:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851514651040899072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405665119538, 8.753434495860382 ]
  },
  "id_str" : "851516778257805315",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy and let me know if you need more help with it. Can get you in touch with the author!",
  "id" : 851516778257805315,
  "in_reply_to_status_id" : 851514651040899072,
  "created_at" : "2017-04-10 19:26:35 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/75kde1y17W",
      "expanded_url" : "https:\/\/twitter.com\/obf_news\/status\/851467741815091201",
      "display_url" : "twitter.com\/obf_news\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405571288107, 8.753432246324726 ]
  },
  "id_str" : "851516067872636928",
  "text" : "Submit to #BOSC2017 and join the coolest conference on open source in bioinformatics! https:\/\/t.co\/75kde1y17W",
  "id" : 851516067872636928,
  "created_at" : "2017-04-10 19:23:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851514651040899072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405571288107, 8.753432246324726 ]
  },
  "id_str" : "851514716094685185",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy totally. And submit something! Deadline is 13th!",
  "id" : 851514716094685185,
  "in_reply_to_status_id" : 851514651040899072,
  "created_at" : "2017-04-10 19:18:23 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851514262329610240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11073499679686, 8.751591005657877 ]
  },
  "id_str" : "851514576789229570",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy should be enough to get it running",
  "id" : 851514576789229570,
  "in_reply_to_status_id" : 851514262329610240,
  "created_at" : "2017-04-10 19:17:50 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851514262329610240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140557697129, 8.753432441088787 ]
  },
  "id_str" : "851514541116719104",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy use test.main for the first one and then test.architecture or how it\u2019s called for the features.",
  "id" : 851514541116719104,
  "in_reply_to_status_id" : 851514262329610240,
  "created_at" : "2017-04-10 19:17:41 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851511511373697026",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140557697129, 8.753432441088787 ]
  },
  "id_str" : "851514223888936960",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy (I know the documentation is not ideal so far. But right now the author is focused on getting his #BOSC2017 abstract written ;))",
  "id" : 851514223888936960,
  "in_reply_to_status_id" : 851511511373697026,
  "created_at" : "2017-04-10 19:16:26 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851511511373697026",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140557697129, 8.753432441088787 ]
  },
  "id_str" : "851514056443928576",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy did you check out the demo data?",
  "id" : 851514056443928576,
  "in_reply_to_status_id" : 851511511373697026,
  "created_at" : "2017-04-10 19:15:46 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 3, 11 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/SUBcX4y3lQ",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/good_puppeRs",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851503201975250945",
  "text" : "RT @heyaudy: Very good data analysis right here. 11\/10. https:\/\/t.co\/SUBcX4y3lQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 66 ],
        "url" : "https:\/\/t.co\/SUBcX4y3lQ",
        "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/good_puppeRs",
        "display_url" : "github.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "851501312222965760",
    "text" : "Very good data analysis right here. 11\/10. https:\/\/t.co\/SUBcX4y3lQ",
    "id" : 851501312222965760,
    "created_at" : "2017-04-10 18:25:07 +0000",
    "user" : {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "protected" : false,
      "id_str" : "14534523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923034147777474561\/zZvXWmSQ_normal.jpg",
      "id" : 14534523,
      "verified" : false
    }
  },
  "id" : 851503201975250945,
  "created_at" : "2017-04-10 18:32:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851501312222965760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1126504395559, 8.755096929008015 ]
  },
  "id_str" : "851503193058156544",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy finally someone appreciates it \uD83D\uDE02",
  "id" : 851503193058156544,
  "in_reply_to_status_id" : 851501312222965760,
  "created_at" : "2017-04-10 18:32:36 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Digital Science",
      "screen_name" : "digitalsci",
      "indices" : [ 10, 21 ],
      "id_str" : "144972081",
      "id" : 144972081
    }, {
      "name" : "Mark Hahnel",
      "screen_name" : "MarkHahnel",
      "indices" : [ 22, 33 ],
      "id_str" : "160877807",
      "id" : 160877807
    }, {
      "name" : "Madeleine",
      "screen_name" : "mbonsma",
      "indices" : [ 34, 42 ],
      "id_str" : "422839831",
      "id" : 422839831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851487153590861824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080147317146, 8.766547199346839 ]
  },
  "id_str" : "851496367814053888",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @digitalsci @MarkHahnel @mbonsma calendar says I\u2019m in town on that day. Probably see you there!",
  "id" : 851496367814053888,
  "in_reply_to_status_id" : 851487153590861824,
  "created_at" : "2017-04-10 18:05:28 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851482407341625344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11255474765795, 8.756071915858199 ]
  },
  "id_str" : "851493933939077125",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler thanks for sharing! :)",
  "id" : 851493933939077125,
  "in_reply_to_status_id" : 851482407341625344,
  "created_at" : "2017-04-10 17:55:48 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "indices" : [ 3, 15 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "CSVConf",
      "screen_name" : "CSVConference",
      "indices" : [ 39, 53 ],
      "id_str" : "2510333484",
      "id" : 2510333484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/unvAm3rkiU",
      "expanded_url" : "https:\/\/csvconf.com\/",
      "display_url" : "csvconf.com"
    } ]
  },
  "geo" : { },
  "id_str" : "851457216037232640",
  "text" : "RT @denormalize: If you want to attend @CSVConference next month in Portland we only have a handful of tickets left: https:\/\/t.co\/unvAm3rkiU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CSVConf",
        "screen_name" : "CSVConference",
        "indices" : [ 22, 36 ],
        "id_str" : "2510333484",
        "id" : 2510333484
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/unvAm3rkiU",
        "expanded_url" : "https:\/\/csvconf.com\/",
        "display_url" : "csvconf.com"
      } ]
    },
    "geo" : { },
    "id_str" : "851451215254769664",
    "text" : "If you want to attend @CSVConference next month in Portland we only have a handful of tickets left: https:\/\/t.co\/unvAm3rkiU",
    "id" : 851451215254769664,
    "created_at" : "2017-04-10 15:06:03 +0000",
    "user" : {
      "name" : "maxwell ogden",
      "screen_name" : "denormalize",
      "protected" : false,
      "id_str" : "12241752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706616363599532032\/b5z-Hw5g_normal.jpg",
      "id" : 12241752,
      "verified" : false
    }
  },
  "id" : 851457216037232640,
  "created_at" : "2017-04-10 15:29:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851386111481880576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17175952128743, 8.631632315292238 ]
  },
  "id_str" : "851386621882650625",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer now my to-be-written biography has a title.",
  "id" : 851386621882650625,
  "in_reply_to_status_id" : 851386111481880576,
  "created_at" : "2017-04-10 10:49:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851374213738897409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17176394672305, 8.631675799704222 ]
  },
  "id_str" : "851385574036557824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer also great for a biography.",
  "id" : 851385574036557824,
  "in_reply_to_status_id" : 851374213738897409,
  "created_at" : "2017-04-10 10:45:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Clavey",
      "screen_name" : "mart1oeil",
      "indices" : [ 0, 10 ],
      "id_str" : "122451753",
      "id" : 122451753
    }, {
      "name" : "Guillaume Cabanac",
      "screen_name" : "gcabanac",
      "indices" : [ 11, 20 ],
      "id_str" : "237738266",
      "id" : 237738266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851355588961460224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.69141834420123, 8.603151971482301 ]
  },
  "id_str" : "851358990911102977",
  "in_reply_to_user_id" : 122451753,
  "text" : "@mart1oeil @gcabanac because in my literature search I couldn\u2019t find any.",
  "id" : 851358990911102977,
  "in_reply_to_status_id" : 851355588961460224,
  "created_at" : "2017-04-10 08:59:35 +0000",
  "in_reply_to_screen_name" : "mart1oeil",
  "in_reply_to_user_id_str" : "122451753",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Clavey",
      "screen_name" : "mart1oeil",
      "indices" : [ 0, 10 ],
      "id_str" : "122451753",
      "id" : 122451753
    }, {
      "name" : "Guillaume Cabanac",
      "screen_name" : "gcabanac",
      "indices" : [ 11, 20 ],
      "id_str" : "237738266",
      "id" : 237738266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851355588961460224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.67489157807983, 8.599659232430719 ]
  },
  "id_str" : "851358887156559873",
  "in_reply_to_user_id" : 122451753,
  "text" : "@mart1oeil @gcabanac fair enough. Do you have any links to studies that compare their corpus to the actual usage? :)",
  "id" : 851358887156559873,
  "in_reply_to_status_id" : 851355588961460224,
  "created_at" : "2017-04-10 08:59:10 +0000",
  "in_reply_to_screen_name" : "mart1oeil",
  "in_reply_to_user_id_str" : "122451753",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 51, 59 ],
      "id_str" : "381187236",
      "id" : 381187236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/WiOcbnahKw",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/04\/08\/124495",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.16131745097149, 8.569250274457568 ]
  },
  "id_str" : "851350348811956224",
  "text" : "If you missed it over the weekend: I looked at the @Sci_Hub corpus &amp; downloads to see how &amp; by whom it is is used. https:\/\/t.co\/WiOcbnahKw",
  "id" : 851350348811956224,
  "created_at" : "2017-04-10 08:25:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gimena del Rio",
      "screen_name" : "gimenadelr",
      "indices" : [ 0, 11 ],
      "id_str" : "1434359630",
      "id" : 1434359630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851196342399578114",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.82518177763356, 8.834027554848076 ]
  },
  "id_str" : "851316377562558465",
  "in_reply_to_user_id" : 1434359630,
  "text" : "@gimenadelr thanks!",
  "id" : 851316377562558465,
  "in_reply_to_status_id" : 851196342399578114,
  "created_at" : "2017-04-10 06:10:15 +0000",
  "in_reply_to_screen_name" : "gimenadelr",
  "in_reply_to_user_id_str" : "1434359630",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Scientists DE",
      "screen_name" : "realsci_DE",
      "indices" : [ 0, 11 ],
      "id_str" : "810555350944464896",
      "id" : 810555350944464896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851314048931028992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.82520436686261, 8.833980197095157 ]
  },
  "id_str" : "851315928730042368",
  "in_reply_to_user_id" : 810555350944464896,
  "text" : "@realsci_DE ich glaube ich hab noch keine Login-Daten bekommen :p",
  "id" : 851315928730042368,
  "in_reply_to_status_id" : 851314048931028992,
  "created_at" : "2017-04-10 06:08:28 +0000",
  "in_reply_to_screen_name" : "realsci_DE",
  "in_reply_to_user_id_str" : "810555350944464896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Inouye",
      "screen_name" : "minouye271",
      "indices" : [ 3, 14 ],
      "id_str" : "4757324228",
      "id" : 4757324228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/OY4Y57YrDE",
      "expanded_url" : "https:\/\/twitter.com\/biorxivpreprint\/status\/851162911447941122",
      "display_url" : "twitter.com\/biorxivpreprin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851178407685750784",
  "text" : "RT @minouye271: Uhh, have u sequenced something since 2015? Read this. https:\/\/t.co\/OY4Y57YrDE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/OY4Y57YrDE",
        "expanded_url" : "https:\/\/twitter.com\/biorxivpreprint\/status\/851162911447941122",
        "display_url" : "twitter.com\/biorxivpreprin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "851164383539470336",
    "text" : "Uhh, have u sequenced something since 2015? Read this. https:\/\/t.co\/OY4Y57YrDE",
    "id" : 851164383539470336,
    "created_at" : "2017-04-09 20:06:17 +0000",
    "user" : {
      "name" : "Mike Inouye",
      "screen_name" : "minouye271",
      "protected" : false,
      "id_str" : "4757324228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705975520928731136\/T2Ov4ul3_normal.jpg",
      "id" : 4757324228,
      "verified" : false
    }
  },
  "id" : 851178407685750784,
  "created_at" : "2017-04-09 21:02:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose George",
      "screen_name" : "rosegeorge3",
      "indices" : [ 3, 15 ],
      "id_str" : "48839054",
      "id" : 48839054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/NhwJ6UxDMb",
      "expanded_url" : "http:\/\/nautil.us\/issue\/46\/balance\/darwin-was-a-slacker-and-you-should-be-too?utm_medium=email&utm_source=newsletter&utm_term=170403&utm_campaign=sharetheview",
      "display_url" : "nautil.us\/issue\/46\/balan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "851177910249697281",
  "text" : "RT @rosegeorge3: Yes, oh yes: Darwin was a slacker &amp; I want to be too. Fascinating. https:\/\/t.co\/NhwJ6UxDMb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/NhwJ6UxDMb",
        "expanded_url" : "http:\/\/nautil.us\/issue\/46\/balance\/darwin-was-a-slacker-and-you-should-be-too?utm_medium=email&utm_source=newsletter&utm_term=170403&utm_campaign=sharetheview",
        "display_url" : "nautil.us\/issue\/46\/balan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "851173874364534784",
    "text" : "Yes, oh yes: Darwin was a slacker &amp; I want to be too. Fascinating. https:\/\/t.co\/NhwJ6UxDMb",
    "id" : 851173874364534784,
    "created_at" : "2017-04-09 20:44:00 +0000",
    "user" : {
      "name" : "Rose George",
      "screen_name" : "rosegeorge3",
      "protected" : false,
      "id_str" : "48839054",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615091307036430336\/Gj5vH-5h_normal.jpg",
      "id" : 48839054,
      "verified" : false
    }
  },
  "id" : 851177910249697281,
  "created_at" : "2017-04-09 21:00:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willem van Schaik",
      "screen_name" : "WvSchaik",
      "indices" : [ 0, 9 ],
      "id_str" : "18585425",
      "id" : 18585425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851122113083834368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35936575602697, 8.58778713441399 ]
  },
  "id_str" : "851132547237117957",
  "in_reply_to_user_id" : 18585425,
  "text" : "@WvSchaik unfortunately not my invention the term :p",
  "id" : 851132547237117957,
  "in_reply_to_status_id" : 851122113083834368,
  "created_at" : "2017-04-09 17:59:47 +0000",
  "in_reply_to_screen_name" : "WvSchaik",
  "in_reply_to_user_id_str" : "18585425",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 46, 54 ],
      "id_str" : "381187236",
      "id" : 381187236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851115767680651265",
  "text" : "RT @gedankenstuecke: I used the data from the @Sci_Hub corpus and their downloads to see how and by whom the service is used. Preprint at h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sci Hub",
        "screen_name" : "Sci_Hub",
        "indices" : [ 25, 33 ],
        "id_str" : "381187236",
        "id" : 381187236
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/WiOcbnahKw",
        "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/04\/08\/124495",
        "display_url" : "biorxiv.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 47.35951036179578, 8.587950475657026 ]
    },
    "id_str" : "851014241452740609",
    "text" : "I used the data from the @Sci_Hub corpus and their downloads to see how and by whom the service is used. Preprint at https:\/\/t.co\/WiOcbnahKw",
    "id" : 851014241452740609,
    "created_at" : "2017-04-09 10:09:40 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 851115767680651265,
  "created_at" : "2017-04-09 16:53:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851114270117040129",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3593496867278, 8.587821249321202 ]
  },
  "id_str" : "851114361884114945",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 noted for the next version. :)",
  "id" : 851114361884114945,
  "in_reply_to_status_id" : 851114270117040129,
  "created_at" : "2017-04-09 16:47:31 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851111913463439360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35946911090286, 8.588131125963542 ]
  },
  "id_str" : "851112829256167424",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 see your point, would \u201Cpotentially illegal\u201D be an easy fix?",
  "id" : 851112829256167424,
  "in_reply_to_status_id" : 851111913463439360,
  "created_at" : "2017-04-09 16:41:26 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/gNMDwub7ao",
      "expanded_url" : "http:\/\/clearscience.info\/wp\/?p=159",
      "display_url" : "clearscience.info\/wp\/?p=159"
    } ]
  },
  "in_reply_to_status_id_str" : "851110673455210499",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35945332631071, 8.58806663308751 ]
  },
  "id_str" : "851111227677868033",
  "in_reply_to_user_id" : 845091326,
  "text" : "@randogp we build something like https:\/\/t.co\/gNMDwub7ao for my PI For his birthday. A picture of it is somewhere on instagram :)",
  "id" : 851111227677868033,
  "in_reply_to_status_id" : 851110673455210499,
  "created_at" : "2017-04-09 16:35:04 +0000",
  "in_reply_to_screen_name" : "gianpaolo_rando",
  "in_reply_to_user_id_str" : "845091326",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851100809010061313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35941727501363, 8.58798575110395 ]
  },
  "id_str" : "851110875280920577",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 ah, that\u2019s a good point. Thanks!",
  "id" : 851110875280920577,
  "in_reply_to_status_id" : 851100809010061313,
  "created_at" : "2017-04-09 16:33:40 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Peter Murray-Rust",
      "screen_name" : "petermurrayrust",
      "indices" : [ 11, 27 ],
      "id_str" : "25676709",
      "id" : 25676709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851099738682392576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35941727501363, 8.58798575110395 ]
  },
  "id_str" : "851110786835632129",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @petermurrayrust thanks! :)",
  "id" : 851110786835632129,
  "in_reply_to_status_id" : 851099738682392576,
  "created_at" : "2017-04-09 16:33:19 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851093238400270338",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933137527115, 8.587799334668512 ]
  },
  "id_str" : "851110664823296000",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery looking forward to your opinion! :)",
  "id" : 851110664823296000,
  "in_reply_to_status_id" : 851093238400270338,
  "created_at" : "2017-04-09 16:32:50 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 0, 12 ],
      "id_str" : "16629477",
      "id" : 16629477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851088092673003520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35940703980384, 8.588018353822315 ]
  },
  "id_str" : "851090113123803136",
  "in_reply_to_user_id" : 16629477,
  "text" : "@dgmacarthur thanks for sharing!",
  "id" : 851090113123803136,
  "in_reply_to_status_id" : 851088092673003520,
  "created_at" : "2017-04-09 15:11:10 +0000",
  "in_reply_to_screen_name" : "dgmacarthur",
  "in_reply_to_user_id_str" : "16629477",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851076830375403525",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35940703980384, 8.588018353822315 ]
  },
  "id_str" : "851089734755643393",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg thanks!",
  "id" : 851089734755643393,
  "in_reply_to_status_id" : 851076830375403525,
  "created_at" : "2017-04-09 15:09:39 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Preater",
      "screen_name" : "preater",
      "indices" : [ 0, 8 ],
      "id_str" : "17602517",
      "id" : 17602517
    }, {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 9, 17 ],
      "id_str" : "381187236",
      "id" : 381187236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851073530682855426",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35940703980384, 8.588018353822315 ]
  },
  "id_str" : "851089700416835584",
  "in_reply_to_user_id" : 17602517,
  "text" : "@preater @Sci_Hub thanks! Hope you can use the data as well! :)",
  "id" : 851089700416835584,
  "in_reply_to_status_id" : 851073530682855426,
  "created_at" : "2017-04-09 15:09:31 +0000",
  "in_reply_to_screen_name" : "preater",
  "in_reply_to_user_id_str" : "17602517",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Schneider",
      "screen_name" : "schneiderleonid",
      "indices" : [ 3, 19 ],
      "id_str" : "2496089581",
      "id" : 2496089581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "851051471235887104",
  "text" : "RT @schneiderleonid: \"illegally circumventing paywalls\": ethical legality depends on whom you see as original paper owner: scientists or pu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 128, 151 ],
        "url" : "https:\/\/t.co\/oftBqZhSvt",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/851014241452740609",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "851039176309035008",
    "text" : "\"illegally circumventing paywalls\": ethical legality depends on whom you see as original paper owner: scientists or publishers. https:\/\/t.co\/oftBqZhSvt",
    "id" : 851039176309035008,
    "created_at" : "2017-04-09 11:48:45 +0000",
    "user" : {
      "name" : "Leonid Schneider",
      "screen_name" : "schneiderleonid",
      "protected" : false,
      "id_str" : "2496089581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/904996383429713920\/mYsULa-D_normal.jpg",
      "id" : 2496089581,
      "verified" : false
    }
  },
  "id" : 851051471235887104,
  "created_at" : "2017-04-09 12:37:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851033062662180864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3592181597346, 8.587873522200237 ]
  },
  "id_str" : "851033175891599362",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice enjoy! :)",
  "id" : 851033175891599362,
  "in_reply_to_status_id" : 851033062662180864,
  "created_at" : "2017-04-09 11:24:55 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    }, {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 16, 24 ],
      "id_str" : "381187236",
      "id" : 381187236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "851017046930456577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35930494483336, 8.587756334512202 ]
  },
  "id_str" : "851017308411752448",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField @Sci_Hub yes, something that i wouldn\u2019t have expected! And wouldn\u2019t show with having only either one of the data sets!",
  "id" : 851017308411752448,
  "in_reply_to_status_id" : 851017046930456577,
  "created_at" : "2017-04-09 10:21:52 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sci Hub",
      "screen_name" : "Sci_Hub",
      "indices" : [ 25, 33 ],
      "id_str" : "381187236",
      "id" : 381187236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/WiOcbnahKw",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2017\/04\/08\/124495",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35951036179578, 8.587950475657026 ]
  },
  "id_str" : "851014241452740609",
  "text" : "I used the data from the @Sci_Hub corpus and their downloads to see how and by whom the service is used. Preprint at https:\/\/t.co\/WiOcbnahKw",
  "id" : 851014241452740609,
  "created_at" : "2017-04-09 10:09:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 9, 20 ],
      "id_str" : "402180727",
      "id" : 402180727
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 21, 34 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "850817288131555329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35891645077654, 8.587885593126066 ]
  },
  "id_str" : "850973628170723328",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @PHerterich @RaoOfPhysics yep, that\u2019s mine too. \uD83C\uDF66\uD83C\uDF68",
  "id" : 850973628170723328,
  "in_reply_to_status_id" : 850817288131555329,
  "created_at" : "2017-04-09 07:28:17 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bioRxiv",
      "screen_name" : "biorxivpreprint",
      "indices" : [ 3, 19 ],
      "id_str" : "1949132852",
      "id" : 1949132852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioRxiv",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/VFCw8tGT6d",
      "expanded_url" : "http:\/\/biorxiv.org\/cgi\/content\/short\/124495v1",
      "display_url" : "biorxiv.org\/cgi\/content\/sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "850970772776640512",
  "text" : "RT @biorxivpreprint: Looking Into Pandora's Box: The Content Of Sci-Hub And Its Usage  https:\/\/t.co\/VFCw8tGT6d #bioRxiv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/biorxiv.org\/\" rel=\"nofollow\"\u003Ebiorxiv_connect\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioRxiv",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/VFCw8tGT6d",
        "expanded_url" : "http:\/\/biorxiv.org\/cgi\/content\/short\/124495v1",
        "display_url" : "biorxiv.org\/cgi\/content\/sh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "850921390198972416",
    "text" : "Looking Into Pandora's Box: The Content Of Sci-Hub And Its Usage  https:\/\/t.co\/VFCw8tGT6d #bioRxiv",
    "id" : 850921390198972416,
    "created_at" : "2017-04-09 04:00:43 +0000",
    "user" : {
      "name" : "bioRxiv",
      "screen_name" : "biorxivpreprint",
      "protected" : false,
      "id_str" : "1949132852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000604961290\/9d34ea56f103db66ac428b5489365f89_normal.png",
      "id" : 1949132852,
      "verified" : false
    }
  },
  "id" : 850970772776640512,
  "created_at" : "2017-04-09 07:16:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "850967599945043968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35869250055653, 8.586933749517215 ]
  },
  "id_str" : "850970747371737088",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed thanks for spreading the word! :)",
  "id" : 850970747371737088,
  "in_reply_to_status_id" : 850967599945043968,
  "created_at" : "2017-04-09 07:16:51 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3592542598177, 8.587872740928105 ]
  },
  "id_str" : "850801077045915648",
  "text" : "\u00ABWhat would you like now?\u00BB \u2014 \u00ABThat we have many loving and healthy years with each other left.\u00BB \u2014 \u00ABThat\u2019s a cool evening plan!\u00BB",
  "id" : 850801077045915648,
  "created_at" : "2017-04-08 20:02:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Kelly",
      "screen_name" : "TyLKelly",
      "indices" : [ 0, 9 ],
      "id_str" : "38707602",
      "id" : 38707602
    }, {
      "name" : "Wicked Queer",
      "screen_name" : "wickedqueer",
      "indices" : [ 10, 22 ],
      "id_str" : "25862275",
      "id" : 25862275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "850693480947036160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35928325385431, 8.58771936010627 ]
  },
  "id_str" : "850735560679464960",
  "in_reply_to_user_id" : 38707602,
  "text" : "@TyLKelly @wickedqueer \uD83D\uDC96\uD83D\uDE0D",
  "id" : 850735560679464960,
  "in_reply_to_status_id" : 850693480947036160,
  "created_at" : "2017-04-08 15:42:18 +0000",
  "in_reply_to_screen_name" : "TyLKelly",
  "in_reply_to_user_id_str" : "38707602",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35911368081668, 8.587574367273975 ]
  },
  "id_str" : "850732018619084800",
  "text" : "\u00ABSpringer Nature remains neutral with regard to jurisdictional claims in published maps\/affiliations\u00BB curious, which incident prompted that?",
  "id" : 850732018619084800,
  "created_at" : "2017-04-08 15:28:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 60, 68 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 73, 81 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/IPbdllr0Kz",
      "expanded_url" : "https:\/\/genomebiology.biomedcentral.com\/articles\/10.1186\/s13059-017-1198-y",
      "display_url" : "genomebiology.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "850731643224678400",
  "text" : "\u00ABComing out: the experience of LGBT+ people in STEM\u00BB thanks @JBYoder and @PhdGeek! https:\/\/t.co\/IPbdllr0Kz",
  "id" : 850731643224678400,
  "created_at" : "2017-04-08 15:26:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/IEcZSsDYbN",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BSoQ1HmjJk1\/",
      "display_url" : "instagram.com\/p\/BSoQ1HmjJk1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "850729458189426689",
  "text" : "\uD83C\uDF4D\uD83D\uDE0D https:\/\/t.co\/IEcZSsDYbN",
  "id" : 850729458189426689,
  "created_at" : "2017-04-08 15:18:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 39, 52 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "850726784186408961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35959193136082, 8.587933427050732 ]
  },
  "id_str" : "850727633411346432",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim sounds good to me, let\u2019s grab @RaoOfPhysics. I ended up in a \uD83C\uDF63 place to eat wasabi \uD83C\uDF66.",
  "id" : 850727633411346432,
  "in_reply_to_status_id" : 850726784186408961,
  "created_at" : "2017-04-08 15:10:48 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "850702691961622529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37365918592398, 8.544635169807824 ]
  },
  "id_str" : "850707227673595904",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Also: i would suck at selling ice cream, being my own best customer and dying of diabetes 2 weeks in.",
  "id" : 850707227673595904,
  "in_reply_to_status_id" : 850702691961622529,
  "created_at" : "2017-04-08 13:49:43 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "850701517028036610",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37364597549571, 8.544470526016719 ]
  },
  "id_str" : "850702279929888768",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim we were just wondering: could you sell ice cream for 6 mo here &amp; for the other 6 live in Germany and work unpaid on open science?",
  "id" : 850702279929888768,
  "in_reply_to_status_id" : 850701517028036610,
  "created_at" : "2017-04-08 13:30:03 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 47, 55 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37363126500018, 8.54448677737863 ]
  },
  "id_str" : "850699473181446145",
  "text" : "Why are there no ice cream places around here? @betatim \uD83D\uDE31\uD83D\uDE2D",
  "id" : 850699473181446145,
  "created_at" : "2017-04-08 13:18:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bioRxiv",
      "screen_name" : "biorxivpreprint",
      "indices" : [ 20, 36 ],
      "id_str" : "1949132852",
      "id" : 1949132852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35924175146211, 8.587742368419265 ]
  },
  "id_str" : "850654938032205824",
  "text" : "Is it just me or is @biorxivpreprint a bit behind their &lt;24h screening goal? (~3 days so far)",
  "id" : 850654938032205824,
  "created_at" : "2017-04-08 10:21:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/DaJ0MkdcFe",
      "expanded_url" : "https:\/\/twitter.com\/mimimibe\/status\/850306201904701440",
      "display_url" : "twitter.com\/mimimibe\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226710642229, 8.627566207935585 ]
  },
  "id_str" : "850307003528478720",
  "text" : "micro-cold brew https:\/\/t.co\/DaJ0MkdcFe",
  "id" : 850307003528478720,
  "created_at" : "2017-04-07 11:19:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/850305970291040256\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/nUC1pAJWY1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C8zkxdUXgAA5VuX.jpg",
      "id_str" : "850305968000958464",
      "id" : 850305968000958464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8zkxdUXgAA5VuX.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/nUC1pAJWY1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "850305970291040256",
  "text" : "Unsure whether I'll get beer disguised as coffee or vice versa. https:\/\/t.co\/nUC1pAJWY1",
  "id" : 850305970291040256,
  "created_at" : "2017-04-07 11:15:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 3, 16 ],
      "id_str" : "9104202",
      "id" : 9104202
    }, {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 30, 39 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 40, 56 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 78, 94 ],
      "id_str" : "17462723",
      "id" : 17462723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "850281370324807680",
  "text" : "RT @jeroenbosman: Speaking w\/ @MsPhelps @gedankenstuecke on scholarly commons @creativecommons Global Summit Apr 29 Toronto https:\/\/t.co\/nj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bi\u24D0nca Kramer",
        "screen_name" : "MsPhelps",
        "indices" : [ 12, 21 ],
        "id_str" : "22963112",
        "id" : 22963112
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 22, 38 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Creative Commons",
        "screen_name" : "creativecommons",
        "indices" : [ 60, 76 ],
        "id_str" : "17462723",
        "id" : 17462723
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeroenbosman\/status\/850281257472798720\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/X93Yyru0v7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C8zNrqMUQAE8yME.jpg",
        "id_str" : "850280579610198017",
        "id" : 850280579610198017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8zNrqMUQAE8yME.jpg",
        "sizes" : [ {
          "h" : 279,
          "resize" : "fit",
          "w" : 279
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 279
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 279
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 279
        } ],
        "display_url" : "pic.twitter.com\/X93Yyru0v7"
      } ],
      "hashtags" : [ {
        "text" : "ccsummit",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/njPFPkATLl",
        "expanded_url" : "http:\/\/sched.co\/AF1D",
        "display_url" : "sched.co\/AF1D"
      } ]
    },
    "geo" : { },
    "id_str" : "850281257472798720",
    "text" : "Speaking w\/ @MsPhelps @gedankenstuecke on scholarly commons @creativecommons Global Summit Apr 29 Toronto https:\/\/t.co\/njPFPkATLl #ccsummit https:\/\/t.co\/X93Yyru0v7",
    "id" : 850281257472798720,
    "created_at" : "2017-04-07 09:37:03 +0000",
    "user" : {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "protected" : false,
      "id_str" : "9104202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853627325715558401\/_66XunIl_normal.jpg",
      "id" : 9104202,
      "verified" : false
    }
  },
  "id" : 850281370324807680,
  "created_at" : "2017-04-07 09:37:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/k8YYHHrRO7",
      "expanded_url" : "https:\/\/m.theregister.co.uk\/2017\/04\/04\/intimate_adult_toy_fails_penetration_test\/",
      "display_url" : "m.theregister.co.uk\/2017\/04\/04\/int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "850271621038317568",
  "text" : "\u00ABWi-Fi sex toy with built-in camera fails penetration test\u00BB \uD83D\uDE02 https:\/\/t.co\/k8YYHHrRO7",
  "id" : 850271621038317568,
  "created_at" : "2017-04-07 08:58:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Wing",
      "screen_name" : "nickpwing",
      "indices" : [ 3, 13 ],
      "id_str" : "83788240",
      "id" : 83788240
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nickpwing\/status\/850047808874979328\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/0u7yQB5cSO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C8v59_qXkAANXJo.jpg",
      "id_str" : "850047798145945600",
      "id" : 850047798145945600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8v59_qXkAANXJo.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/0u7yQB5cSO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "850110527787454464",
  "text" : "RT @nickpwing: Found one more photo of Jared Kushner in Iraq https:\/\/t.co\/0u7yQB5cSO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nickpwing\/status\/850047808874979328\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/0u7yQB5cSO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C8v59_qXkAANXJo.jpg",
        "id_str" : "850047798145945600",
        "id" : 850047798145945600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8v59_qXkAANXJo.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/0u7yQB5cSO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "850047808874979328",
    "text" : "Found one more photo of Jared Kushner in Iraq https:\/\/t.co\/0u7yQB5cSO",
    "id" : 850047808874979328,
    "created_at" : "2017-04-06 18:09:25 +0000",
    "user" : {
      "name" : "Nick Wing",
      "screen_name" : "nickpwing",
      "protected" : false,
      "id_str" : "83788240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897274284468555776\/oEmMf642_normal.jpg",
      "id" : 83788240,
      "verified" : true
    }
  },
  "id" : 850110527787454464,
  "created_at" : "2017-04-06 22:18:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Holden",
      "screen_name" : "mtgholden",
      "indices" : [ 3, 13 ],
      "id_str" : "2900377593",
      "id" : 2900377593
    }, {
      "name" : "bioRxiv",
      "screen_name" : "biorxivpreprint",
      "indices" : [ 48, 64 ],
      "id_str" : "1949132852",
      "id" : 1949132852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "850010854535946240",
  "text" : "RT @mtgholden: Pleasantly surprised by my first @biorxivpreprint experience. Great feedback, included comments from a journal club of the p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "bioRxiv",
        "screen_name" : "biorxivpreprint",
        "indices" : [ 33, 49 ],
        "id_str" : "1949132852",
        "id" : 1949132852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "849898008791658496",
    "text" : "Pleasantly surprised by my first @biorxivpreprint experience. Great feedback, included comments from a journal club of the pre-print.",
    "id" : 849898008791658496,
    "created_at" : "2017-04-06 08:14:10 +0000",
    "user" : {
      "name" : "Matthew Holden",
      "screen_name" : "mtgholden",
      "protected" : false,
      "id_str" : "2900377593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539368041528578048\/ILpSZA3q_normal.jpeg",
      "id" : 2900377593,
      "verified" : false
    }
  },
  "id" : 850010854535946240,
  "created_at" : "2017-04-06 15:42:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Holden",
      "screen_name" : "mtgholden",
      "indices" : [ 0, 10 ],
      "id_str" : "2900377593",
      "id" : 2900377593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849898008791658496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234239954563, 8.627532585621314 ]
  },
  "id_str" : "849979139415265281",
  "in_reply_to_user_id" : 2900377593,
  "text" : "@mtgholden so glad you found it useful!",
  "id" : 849979139415265281,
  "in_reply_to_status_id" : 849898008791658496,
  "created_at" : "2017-04-06 13:36:33 +0000",
  "in_reply_to_screen_name" : "mtgholden",
  "in_reply_to_user_id_str" : "2900377593",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "849964594286272512",
  "text" : "RT @OBF_BOSC: This year, #BOSC2017 will feature a new session on Citizen\/Participatory Science! Submit your abstract now: https:\/\/t.co\/ruCb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 11, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ruCbn3Cj6n",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_2017",
        "display_url" : "open-bio.org\/wiki\/BOSC_2017"
      } ]
    },
    "geo" : { },
    "id_str" : "849335462967758848",
    "text" : "This year, #BOSC2017 will feature a new session on Citizen\/Participatory Science! Submit your abstract now: https:\/\/t.co\/ruCbn3Cj6n \uD83C\uDF50",
    "id" : 849335462967758848,
    "created_at" : "2017-04-04 18:58:48 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 849964594286272512,
  "created_at" : "2017-04-06 12:38:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849925238104227841",
  "geo" : { },
  "id_str" : "849925278092734464",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 then you should be fine with cat. :)",
  "id" : 849925278092734464,
  "in_reply_to_status_id" : 849925238104227841,
  "created_at" : "2017-04-06 10:02:31 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849924913859362817",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231496058302, 8.627536860392542 ]
  },
  "id_str" : "849925143203860480",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 is the library layout the same for both libs? (insert size, orientation)",
  "id" : 849925143203860480,
  "in_reply_to_status_id" : 849924913859362817,
  "created_at" : "2017-04-06 10:01:59 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/wdrzp0Uep0",
      "expanded_url" : "http:\/\/cab.spbu.ru\/files\/release3.10.1\/manual.html#yaml",
      "display_url" : "cab.spbu.ru\/files\/release3\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "849904639575293953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234697366129, 8.62753291492775 ]
  },
  "id_str" : "849917545939431425",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 for multiple files of PE runs and putting them into SPAdes see https:\/\/t.co\/wdrzp0Uep0",
  "id" : 849917545939431425,
  "in_reply_to_status_id" : 849904639575293953,
  "created_at" : "2017-04-06 09:31:48 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849904639575293953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232171881294, 8.627547271875514 ]
  },
  "id_str" : "849917187909459968",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 as long as you\u2019re not mixing F and R files yes.",
  "id" : 849917187909459968,
  "in_reply_to_status_id" : 849904639575293953,
  "created_at" : "2017-04-06 09:30:22 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 0, 7 ],
      "id_str" : "53749209",
      "id" : 53749209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849913505943867396",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236817289238, 8.627513937181925 ]
  },
  "id_str" : "849913723355582464",
  "in_reply_to_user_id" : 53749209,
  "text" : "@blinry we track coffee consumption (and actually have to pay at the end :p)",
  "id" : 849913723355582464,
  "in_reply_to_status_id" : 849913505943867396,
  "created_at" : "2017-04-06 09:16:36 +0000",
  "in_reply_to_screen_name" : "blinry",
  "in_reply_to_user_id_str" : "53749209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849913060802404353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234594524573, 8.627526874461097 ]
  },
  "id_str" : "849913515984945152",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski fun fact: that\u2019s \u00B1 half a month\u2019s net income for a PhD student here.",
  "id" : 849913515984945152,
  "in_reply_to_status_id" : 849913060802404353,
  "created_at" : "2017-04-06 09:15:47 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849906469675950080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234594524573, 8.627526874461097 ]
  },
  "id_str" : "849912959375728641",
  "in_reply_to_user_id" : 14286491,
  "text" : "In related news: In the office alone I drank coffee for 740,61 \u20AC since starting my PhD.",
  "id" : 849912959375728641,
  "in_reply_to_status_id" : 849906469675950080,
  "created_at" : "2017-04-06 09:13:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/849906469675950080\/photo\/1",
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/2F8eb1WUIU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C8t5Z6kXcAAYSx-.jpg",
      "id_str" : "849906440814948352",
      "id" : 849906440814948352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8t5Z6kXcAAYSx-.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/2F8eb1WUIU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231531652732, 8.627527056478698 ]
  },
  "id_str" : "849906469675950080",
  "text" : "Code Red in the office this morning. https:\/\/t.co\/2F8eb1WUIU",
  "id" : 849906469675950080,
  "created_at" : "2017-04-06 08:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M\u24D0rtin W\u24D0gner",
      "screen_name" : "martiwag",
      "indices" : [ 0, 9 ],
      "id_str" : "1162531196",
      "id" : 1162531196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849898707306917888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234214294353, 8.62752161045772 ]
  },
  "id_str" : "849902070870224896",
  "in_reply_to_user_id" : 1162531196,
  "text" : "@martiwag awesome, will feel like home after two weeks in which I\u2019ll spend ~35h on planes.",
  "id" : 849902070870224896,
  "in_reply_to_status_id" : 849898707306917888,
  "created_at" : "2017-04-06 08:30:18 +0000",
  "in_reply_to_screen_name" : "martiwag",
  "in_reply_to_user_id_str" : "1162531196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M\u24D0rtin W\u24D0gner",
      "screen_name" : "martiwag",
      "indices" : [ 0, 9 ],
      "id_str" : "1162531196",
      "id" : 1162531196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849896817135427584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230879453156, 8.627536159109482 ]
  },
  "id_str" : "849897786938142720",
  "in_reply_to_user_id" : 1162531196,
  "text" : "@martiwag ah, nice. Coming back from PDX that day, but if jet lag allows I\u2019ll drop by :D",
  "id" : 849897786938142720,
  "in_reply_to_status_id" : 849896817135427584,
  "created_at" : "2017-04-06 08:13:17 +0000",
  "in_reply_to_screen_name" : "martiwag",
  "in_reply_to_user_id_str" : "1162531196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M\u24D0rtin W\u24D0gner",
      "screen_name" : "martiwag",
      "indices" : [ 0, 9 ],
      "id_str" : "1162531196",
      "id" : 1162531196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849889305761910784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236268448102, 8.627521386005009 ]
  },
  "id_str" : "849893804559790080",
  "in_reply_to_user_id" : 1162531196,
  "text" : "@martiwag in which language? :)",
  "id" : 849893804559790080,
  "in_reply_to_status_id" : 849889305761910784,
  "created_at" : "2017-04-06 07:57:27 +0000",
  "in_reply_to_screen_name" : "martiwag",
  "in_reply_to_user_id_str" : "1162531196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/uGYNxI1k3e",
      "expanded_url" : "https:\/\/twitter.com\/JennyBryan\/status\/849755690272829440",
      "display_url" : "twitter.com\/JennyBryan\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406517539394, 8.753436342599699 ]
  },
  "id_str" : "849764745775382528",
  "text" : "See you there! https:\/\/t.co\/uGYNxI1k3e",
  "id" : 849764745775382528,
  "created_at" : "2017-04-05 23:24:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/849720205165068288\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/CA4bdomXMo",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C8rQBGlXgAIWArf.jpg",
      "id_str" : "849720197078548482",
      "id" : 849720197078548482,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C8rQBGlXgAIWArf.jpg",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/CA4bdomXMo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/izxewM538t",
      "expanded_url" : "https:\/\/twitter.com\/biomickwatson\/status\/849716742922350592",
      "display_url" : "twitter.com\/biomickwatson\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "849720205165068288",
  "text" : "But I saw a complete documentary series about this?! https:\/\/t.co\/izxewM538t https:\/\/t.co\/CA4bdomXMo",
  "id" : 849720205165068288,
  "created_at" : "2017-04-05 20:27:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "849686634715127808",
  "text" : "RT @OBF_BOSC: #BOSC2017 would love to get more abstracts about Medical and Translational Bioinformatics! Submit yours at https:\/\/t.co\/ruCbn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/ruCbn3Cj6n",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_2017",
        "display_url" : "open-bio.org\/wiki\/BOSC_2017"
      } ]
    },
    "geo" : { },
    "id_str" : "849680294663737344",
    "text" : "#BOSC2017 would love to get more abstracts about Medical and Translational Bioinformatics! Submit yours at https:\/\/t.co\/ruCbn3Cj6n by 13-Apr",
    "id" : 849680294663737344,
    "created_at" : "2017-04-05 17:49:03 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 849686634715127808,
  "created_at" : "2017-04-05 18:14:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "indices" : [ 3, 7 ],
      "id_str" : "793517",
      "id" : 793517
    }, {
      "name" : "World Bank",
      "screen_name" : "WorldBank",
      "indices" : [ 105, 115 ],
      "id_str" : "27860681",
      "id" : 27860681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "849668221779181568",
  "text" : "RT @tkb: Are you a Data Scientist? Want to work on interesting development problems? We're hiring at the @WorldBank! - https:\/\/t.co\/7mbuxvc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "World Bank",
        "screen_name" : "WorldBank",
        "indices" : [ 96, 106 ],
        "id_str" : "27860681",
        "id" : 27860681
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Jobs",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/7mbuxvcatT",
        "expanded_url" : "http:\/\/web.worldbank.org\/external\/default\/main?pagePK=8454041&piPK=8454059&theSitePK=8453353&JobNo=170687&contentMDK=23158967&order=descending&sortBy=job-req-num&location=WAS&menuPK=8453611&JobType=Professional%20%26%20Technical&JobGrade=GF",
        "display_url" : "web.worldbank.org\/external\/defau\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "849657344111906817",
    "text" : "Are you a Data Scientist? Want to work on interesting development problems? We're hiring at the @WorldBank! - https:\/\/t.co\/7mbuxvcatT #Jobs",
    "id" : 849657344111906817,
    "created_at" : "2017-04-05 16:17:51 +0000",
    "user" : {
      "name" : "Tariq Khokhar",
      "screen_name" : "tkb",
      "protected" : false,
      "id_str" : "793517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496438943441645568\/4A8HcjA7_normal.jpeg",
      "id" : 793517,
      "verified" : false
    }
  },
  "id" : 849668221779181568,
  "created_at" : "2017-04-05 17:01:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Method",
      "screen_name" : "methodpodcast",
      "indices" : [ 3, 17 ],
      "id_str" : "841811845811974146",
      "id" : 841811845811974146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/fFgOxwDpBa",
      "expanded_url" : "http:\/\/eepurl.com\/cG-olv",
      "display_url" : "eepurl.com\/cG-olv"
    } ]
  },
  "geo" : { },
  "id_str" : "849656771446800386",
  "text" : "RT @methodpodcast: Join us to make the first open source podcast about science!  https:\/\/t.co\/fFgOxwDpBa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.mailchimp.com\" rel=\"nofollow\"\u003EMailChimp\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/fFgOxwDpBa",
        "expanded_url" : "http:\/\/eepurl.com\/cG-olv",
        "display_url" : "eepurl.com\/cG-olv"
      } ]
    },
    "geo" : { },
    "id_str" : "849592433239351297",
    "text" : "Join us to make the first open source podcast about science!  https:\/\/t.co\/fFgOxwDpBa",
    "id" : 849592433239351297,
    "created_at" : "2017-04-05 11:59:55 +0000",
    "user" : {
      "name" : "The Method",
      "screen_name" : "methodpodcast",
      "protected" : false,
      "id_str" : "841811845811974146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841813767092547584\/3m_KI3Xl_normal.jpg",
      "id" : 841811845811974146,
      "verified" : false
    }
  },
  "id" : 849656771446800386,
  "created_at" : "2017-04-05 16:15:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849618359209517056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237386227396, 8.627523740625909 ]
  },
  "id_str" : "849619260112609281",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, read it too, it\u2019s really good!",
  "id" : 849619260112609281,
  "in_reply_to_status_id" : 849618359209517056,
  "created_at" : "2017-04-05 13:46:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/mEUpnDerZQ",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0175011",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241520993679, 8.627522064509975 ]
  },
  "id_str" : "849616592681959424",
  "text" : "A socioeconomic related 'digital divide' exists in how, not if, young people use computers https:\/\/t.co\/mEUpnDerZQ",
  "id" : 849616592681959424,
  "created_at" : "2017-04-05 13:35:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/CP19aGO2de",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1005399",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406563751481, 8.753435937037784 ]
  },
  "id_str" : "849390264133222401",
  "text" : "\u00ABAcknowledge that data are people\nand can do harm\u00BB Ten simple rules for responsible big data research https:\/\/t.co\/CP19aGO2de @philippbayer",
  "id" : 849390264133222401,
  "created_at" : "2017-04-04 22:36:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849372713500233728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405902655946, 8.753428696357412 ]
  },
  "id_str" : "849378376586539008",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim self-chosen deadline and the fun of data analysis.",
  "id" : 849378376586539008,
  "in_reply_to_status_id" : 849372713500233728,
  "created_at" : "2017-04-04 21:49:20 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nadia Eghbal",
      "screen_name" : "nayafia",
      "indices" : [ 3, 11 ],
      "id_str" : "326511843",
      "id" : 326511843
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nayafia\/status\/848944903509987328\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/UTy7u6SAIW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C8gO45LXsAAn7ah.jpg",
      "id_str" : "848944900343312384",
      "id" : 848944900343312384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8gO45LXsAAn7ah.jpg",
      "sizes" : [ {
        "h" : 413,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/UTy7u6SAIW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/F3oWHKJKyu",
      "expanded_url" : "https:\/\/medium.com\/@nayafia\/5-000-no-strings-attached-9e7b95d33e50#---98-182",
      "display_url" : "medium.com\/@nayafia\/5-000\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "849367506838065156",
  "text" : "RT @nayafia: Let\u2019s have some fun! I\u2019m offering two grants of $5,000 for whatever you want: https:\/\/t.co\/F3oWHKJKyu https:\/\/t.co\/UTy7u6SAIW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nayafia\/status\/848944903509987328\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/UTy7u6SAIW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/C8gO45LXsAAn7ah.jpg",
        "id_str" : "848944900343312384",
        "id" : 848944900343312384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8gO45LXsAAn7ah.jpg",
        "sizes" : [ {
          "h" : 413,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/UTy7u6SAIW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/F3oWHKJKyu",
        "expanded_url" : "https:\/\/medium.com\/@nayafia\/5-000-no-strings-attached-9e7b95d33e50#---98-182",
        "display_url" : "medium.com\/@nayafia\/5-000\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "848944903509987328",
    "text" : "Let\u2019s have some fun! I\u2019m offering two grants of $5,000 for whatever you want: https:\/\/t.co\/F3oWHKJKyu https:\/\/t.co\/UTy7u6SAIW",
    "id" : 848944903509987328,
    "created_at" : "2017-04-03 17:06:52 +0000",
    "user" : {
      "name" : "Nadia Eghbal",
      "screen_name" : "nayafia",
      "protected" : false,
      "id_str" : "326511843",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1648848489\/twitter_normal.png",
      "id" : 326511843,
      "verified" : false
    }
  },
  "id" : 849367506838065156,
  "created_at" : "2017-04-04 21:06:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849349613232455681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402126463675, 8.753432789858513 ]
  },
  "id_str" : "849349807911120896",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman great, I\u2019ll be in town from the Tuesday on I think.",
  "id" : 849349807911120896,
  "in_reply_to_status_id" : 849349613232455681,
  "created_at" : "2017-04-04 19:55:49 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 10, 23 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849349269417021444",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405829456434, 8.753427741829952 ]
  },
  "id_str" : "849349416909770754",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @jeroenbosman absolutely. Well you come in before the Summit starts?",
  "id" : 849349416909770754,
  "in_reply_to_status_id" : 849349269417021444,
  "created_at" : "2017-04-04 19:54:15 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849348801152389124",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405700554209, 8.753427740108329 ]
  },
  "id_str" : "849349100764090370",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps dips in total time measured would be lunch, dinner and having a phone call :D",
  "id" : 849349100764090370,
  "in_reply_to_status_id" : 849348801152389124,
  "created_at" : "2017-04-04 19:53:00 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849347969467940865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405817625566, 8.753426909473077 ]
  },
  "id_str" : "849348692431732737",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps e.g. spent most of my productive time yesterday on Overleaf, in R and my command line. Most unproductive time on Telegram.",
  "id" : 849348692431732737,
  "in_reply_to_status_id" : 849347969467940865,
  "created_at" : "2017-04-04 19:51:23 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849347969467940865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405932725674, 8.753428537769578 ]
  },
  "id_str" : "849348495530242048",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps green: productive work, red: unproductive. User can classify apps &amp; websites themselves (much already pre-classified).",
  "id" : 849348495530242048,
  "in_reply_to_status_id" : 849347969467940865,
  "created_at" : "2017-04-04 19:50:36 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/849347285364482048\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ryrnvP1jhm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C8l82UPXoAEt8ZO.jpg",
      "id_str" : "849347277324001281",
      "id" : 849347277324001281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C8l82UPXoAEt8ZO.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ryrnvP1jhm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "849344886960795650",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11412653683892, 8.75336764414787 ]
  },
  "id_str" : "849347285364482048",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps surveillance for your activities. In concert with Gyroscope produces nice figures like this. https:\/\/t.co\/ryrnvP1jhm",
  "id" : 849347285364482048,
  "in_reply_to_status_id" : 849344886960795650,
  "created_at" : "2017-04-04 19:45:47 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11370466389175, 8.753373327761253 ]
  },
  "id_str" : "849342645390503936",
  "text" : "Oof, according to RescueTime I already worked 25h this week. \uD83D\uDE31",
  "id" : 849342645390503936,
  "created_at" : "2017-04-04 19:27:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/849029731425161216\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/fJTTRMclmU",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/C8hcA01XYAE9oTv.jpg",
      "id_str" : "849029699011567617",
      "id" : 849029699011567617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/C8hcA01XYAE9oTv.jpg",
      "sizes" : [ {
        "h" : 548,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/fJTTRMclmU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405814185226, 8.753418679810178 ]
  },
  "id_str" : "849029731425161216",
  "text" : "Looked out of my window to see what\u2019s making the noise outside. Saw a \uD83D\uDC30 being hunted by a \uD83E\uDD8A. https:\/\/t.co\/fJTTRMclmU",
  "id" : 849029731425161216,
  "created_at" : "2017-04-03 22:43:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "848994759159009280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11405923860183, 8.753424752476796 ]
  },
  "id_str" : "848994908388118528",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce guess your blog will be cited then :D",
  "id" : 848994908388118528,
  "in_reply_to_status_id" : 848994759159009280,
  "created_at" : "2017-04-03 20:25:34 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406029041766, 8.753424380659919 ]
  },
  "id_str" : "848985701089783810",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce do you have some sources\/references\/overviews to vanishing papers like the OUP case?",
  "id" : 848985701089783810,
  "created_at" : "2017-04-03 19:48:59 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Kreminski",
      "screen_name" : "maxkreminski",
      "indices" : [ 3, 16 ],
      "id_str" : "432047363",
      "id" : 432047363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "848866063601156096",
  "text" : "RT @maxkreminski: \uD83C\uDF08  Went to a 6-hour game jam &amp; made a FREE ONLINE GENDER QUIZ. Finally you too can know what your gender is! https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/GrFMpNqSy6",
        "expanded_url" : "https:\/\/mkremins.github.io\/genderquiz",
        "display_url" : "mkremins.github.io\/genderquiz"
      } ]
    },
    "geo" : { },
    "id_str" : "848571644498935812",
    "text" : "\uD83C\uDF08  Went to a 6-hour game jam &amp; made a FREE ONLINE GENDER QUIZ. Finally you too can know what your gender is! https:\/\/t.co\/GrFMpNqSy6",
    "id" : 848571644498935812,
    "created_at" : "2017-04-02 16:23:40 +0000",
    "user" : {
      "name" : "Max Kreminski",
      "screen_name" : "maxkreminski",
      "protected" : false,
      "id_str" : "432047363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/855680615294787584\/ILu_jXjs_normal.jpg",
      "id" : 432047363,
      "verified" : false
    }
  },
  "id" : 848866063601156096,
  "created_at" : "2017-04-03 11:53:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "_katsel",
      "indices" : [ 0, 8 ],
      "id_str" : "892038837052076033",
      "id" : 892038837052076033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "848619922141917184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406558284443, 8.753435609535867 ]
  },
  "id_str" : "848620203437174784",
  "in_reply_to_user_id" : 730326143295959040,
  "text" : "@_katsel we didn\u2019t take it that far :D",
  "id" : 848620203437174784,
  "in_reply_to_status_id" : 848619922141917184,
  "created_at" : "2017-04-02 19:36:37 +0000",
  "in_reply_to_screen_name" : "katheyrina",
  "in_reply_to_user_id_str" : "730326143295959040",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "848588485606998017",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11369837351461, 8.753289030269137 ]
  },
  "id_str" : "848619645573750785",
  "in_reply_to_user_id" : 14286491,
  "text" : "Only thanks to the broken internet: After 2 1\/2 years of living together all 4 people of the flat share go out for dinner together.",
  "id" : 848619645573750785,
  "in_reply_to_status_id" : 848588485606998017,
  "created_at" : "2017-04-02 19:34:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11142559018182, 8.755764873504793 ]
  },
  "id_str" : "848588485606998017",
  "text" : "\u00ABOh no, the Internet broke! Well, maybe I could go and take a shower now\u2026\u00BB",
  "id" : 848588485606998017,
  "created_at" : "2017-04-02 17:30:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 3, 11 ],
      "id_str" : "222765418",
      "id" : 222765418
    }, {
      "name" : "Todd Vision",
      "screen_name" : "tjvision",
      "indices" : [ 108, 117 ],
      "id_str" : "127003086",
      "id" : 127003086
    }, {
      "name" : "Corin\u24D0 Logan",
      "screen_name" : "LoganCorina",
      "indices" : [ 118, 130 ],
      "id_str" : "840002166",
      "id" : 840002166
    }, {
      "name" : "Laurent G\u24D0tt\u24EA",
      "screen_name" : "lgatt0",
      "indices" : [ 131, 138 ],
      "id_str" : "188423774",
      "id" : 188423774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/JZtYPRSqIf",
      "expanded_url" : "http:\/\/rossmounce.co.uk\/2017\/04\/02\/open-letter-to-oxford-university-press\/",
      "display_url" : "rossmounce.co.uk\/2017\/04\/02\/ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "848572046670000129",
  "text" : "RT @rmounce: Email sent: An Open Letter to Oxford University Press on Publishing https:\/\/t.co\/JZtYPRSqIf cc @tjvision @LoganCorina @lgatt0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Todd Vision",
        "screen_name" : "tjvision",
        "indices" : [ 95, 104 ],
        "id_str" : "127003086",
        "id" : 127003086
      }, {
        "name" : "Corin\u24D0 Logan",
        "screen_name" : "LoganCorina",
        "indices" : [ 105, 117 ],
        "id_str" : "840002166",
        "id" : 840002166
      }, {
        "name" : "Laurent G\u24D0tt\u24EA",
        "screen_name" : "lgatt0",
        "indices" : [ 118, 125 ],
        "id_str" : "188423774",
        "id" : 188423774
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/JZtYPRSqIf",
        "expanded_url" : "http:\/\/rossmounce.co.uk\/2017\/04\/02\/open-letter-to-oxford-university-press\/",
        "display_url" : "rossmounce.co.uk\/2017\/04\/02\/ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "848567811383451648",
    "text" : "Email sent: An Open Letter to Oxford University Press on Publishing https:\/\/t.co\/JZtYPRSqIf cc @tjvision @LoganCorina @lgatt0",
    "id" : 848567811383451648,
    "created_at" : "2017-04-02 16:08:26 +0000",
    "user" : {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "protected" : false,
      "id_str" : "222765418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668402841262927872\/2vZUj52I_normal.jpg",
      "id" : 222765418,
      "verified" : false
    }
  },
  "id" : 848572046670000129,
  "created_at" : "2017-04-02 16:25:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 0, 11 ],
      "id_str" : "402180727",
      "id" : 402180727
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 12, 17 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "848568143509430272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11198800527501, 8.753615012400553 ]
  },
  "id_str" : "848569573653843971",
  "in_reply_to_user_id" : 402180727,
  "text" : "@PHerterich @PLOS also doesn\u2019t help if you\u2019re doing non-institutional research on your own time.",
  "id" : 848569573653843971,
  "in_reply_to_status_id" : 848568143509430272,
  "created_at" : "2017-04-02 16:15:26 +0000",
  "in_reply_to_screen_name" : "PHerterich",
  "in_reply_to_user_id_str" : "402180727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 0, 11 ],
      "id_str" : "402180727",
      "id" : 402180727
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 12, 17 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "848561674453962754",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10611354843723, 8.752397876241014 ]
  },
  "id_str" : "848566830805471232",
  "in_reply_to_user_id" : 402180727,
  "text" : "@PHerterich @PLOS in which case all APCs bar F1000 Research are not affordable.",
  "id" : 848566830805471232,
  "in_reply_to_status_id" : 848561674453962754,
  "created_at" : "2017-04-02 16:04:32 +0000",
  "in_reply_to_screen_name" : "PHerterich",
  "in_reply_to_user_id_str" : "402180727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 0, 11 ],
      "id_str" : "402180727",
      "id" : 402180727
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 12, 17 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "848561674453962754",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396456770284, 8.75338862893442 ]
  },
  "id_str" : "848566688786370561",
  "in_reply_to_user_id" : 402180727,
  "text" : "@PHerterich @PLOS I know. But came up in the context of publishing there as a single individual without funding for the project.",
  "id" : 848566688786370561,
  "in_reply_to_status_id" : 848561674453962754,
  "created_at" : "2017-04-02 16:03:58 +0000",
  "in_reply_to_screen_name" : "PHerterich",
  "in_reply_to_user_id_str" : "402180727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 14, 19 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406349143366, 8.75343818621484 ]
  },
  "id_str" : "848558624108687360",
  "text" : "\u00ABThe APCs for @PLOS are so high, I wonder whether more people submit during summer as it\u2019s easier to live on the streets during that time.\u00BB",
  "id" : 848558624108687360,
  "created_at" : "2017-04-02 15:31:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "848170442686947329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395111033217, 8.753608222607337 ]
  },
  "id_str" : "848183175696273410",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg nur tausende seiner Haare.",
  "id" : 848183175696273410,
  "in_reply_to_status_id" : 848170442686947329,
  "created_at" : "2017-04-01 14:40:02 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/zaTMuT2CB2",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BSV3AK5j2NB\/",
      "display_url" : "instagram.com\/p\/BSV3AK5j2NB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "848139388299218944",
  "text" : "Enjoy breakfast in the sun \u2600\uFE0F https:\/\/t.co\/zaTMuT2CB2",
  "id" : 848139388299218944,
  "created_at" : "2017-04-01 11:46:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "848072707824640002",
  "text" : "RT @NazeefaFatima: Sharing this important thread here -Includes safety tips on protecting yourself from emotional manipulation\/abuse! https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/jlT4ZiRNfO",
        "expanded_url" : "https:\/\/twitter.com\/gaileyfrey\/status\/847179929011732480",
        "display_url" : "twitter.com\/gaileyfrey\/sta\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "847108829519204353",
    "geo" : { },
    "id_str" : "847410420419772416",
    "in_reply_to_user_id" : 37054704,
    "text" : "Sharing this important thread here -Includes safety tips on protecting yourself from emotional manipulation\/abuse! https:\/\/t.co\/jlT4ZiRNfO",
    "id" : 847410420419772416,
    "in_reply_to_status_id" : 847108829519204353,
    "created_at" : "2017-03-30 11:29:23 +0000",
    "in_reply_to_screen_name" : "NazeefaFatima",
    "in_reply_to_user_id_str" : "37054704",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 848072707824640002,
  "created_at" : "2017-04-01 07:21:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]