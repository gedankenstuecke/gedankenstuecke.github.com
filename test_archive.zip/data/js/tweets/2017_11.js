Grailbird.data.tweets_2017_11 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Lewnard",
      "screen_name" : "jLewnard",
      "indices" : [ 3, 12 ],
      "id_str" : "4856364754",
      "id" : 4856364754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933069693954375680",
  "text" : "RT @jLewnard: Randomization in the time of Peter Thiel: \u201CThis individual requested that I give him two immunizations to double the effect\u2026\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 227, 250 ],
        "url" : "https:\/\/t.co\/3JBZg9Stzt",
        "expanded_url" : "https:\/\/twitter.com\/statnews\/status\/932976125906649088",
        "display_url" : "twitter.com\/statnews\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932988393583202304",
    "text" : "Randomization in the time of Peter Thiel: \u201CThis individual requested that I give him two immunizations to double the effect\u2026 one immunization per leg.\u201D For everyone who complains about IRBs, a chilling reminder of their value. https:\/\/t.co\/3JBZg9Stzt",
    "id" : 932988393583202304,
    "created_at" : "2017-11-21 15:05:41 +0000",
    "user" : {
      "name" : "Joseph Lewnard",
      "screen_name" : "jLewnard",
      "protected" : false,
      "id_str" : "4856364754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/878477480566370305\/wj9gtCcF_normal.jpg",
      "id" : 4856364754,
      "verified" : false
    }
  },
  "id" : 933069693954375680,
  "created_at" : "2017-11-21 20:28:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/AYclr6aTs1",
      "expanded_url" : "https:\/\/opensnp.org\/openhumans",
      "display_url" : "opensnp.org\/openhumans"
    } ]
  },
  "geo" : { },
  "id_str" : "933065503257403392",
  "text" : "You are on openSNP and Open Humans? You can now link your accounts! https:\/\/t.co\/AYclr6aTs1 \uD83C\uDF89",
  "id" : 933065503257403392,
  "created_at" : "2017-11-21 20:12:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 3, 12 ],
      "id_str" : "20624794",
      "id" : 20624794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenScience",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933019892843814912",
  "text" : "RT @obf_news: The OBF isn\u2019t doing enough in public policy &amp; advocacy around #OpenScience, and we're looking to recruit a new board member w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenScience",
        "indices" : [ 66, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 173, 196 ],
        "url" : "https:\/\/t.co\/KRoP9A2cvp",
        "expanded_url" : "https:\/\/news.open-bio.org\/2017\/11\/14\/obf-visioning-2017\/",
        "display_url" : "news.open-bio.org\/2017\/11\/14\/obf\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932978481096310786",
    "text" : "The OBF isn\u2019t doing enough in public policy &amp; advocacy around #OpenScience, and we're looking to recruit a new board member who is interested in this role. Is that you? https:\/\/t.co\/KRoP9A2cvp",
    "id" : 932978481096310786,
    "created_at" : "2017-11-21 14:26:18 +0000",
    "user" : {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "protected" : false,
      "id_str" : "20624794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77404934\/OBF_logo_normal.png",
      "id" : 20624794,
      "verified" : false
    }
  },
  "id" : 933019892843814912,
  "created_at" : "2017-11-21 17:10:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "ulrich genick",
      "screen_name" : "UlrichGenick",
      "indices" : [ 12, 25 ],
      "id_str" : "2524449624",
      "id" : 2524449624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932888812488921088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86325278139851, -122.2726996925658 ]
  },
  "id_str" : "932892103520149504",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena @UlrichGenick Also: why is it Citizen science? How is my participation bound to having the right passport. ;)",
  "id" : 932892103520149504,
  "in_reply_to_status_id" : 932888812488921088,
  "created_at" : "2017-11-21 08:43:04 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 3, 9 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932887032447221760",
  "text" : "RT @aath0: Don't miss the chance to apply for this one! It has been a fantastic introduction on how to set up and manage an open project! P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 166, 189 ],
        "url" : "https:\/\/t.co\/1pu3WNRxFU",
        "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/932642441919913990",
        "display_url" : "twitter.com\/MozOpenLeaders\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932862374532411392",
    "text" : "Don't miss the chance to apply for this one! It has been a fantastic introduction on how to set up and manage an open project! Plus it made github seem less spooky \uD83D\uDE09 https:\/\/t.co\/1pu3WNRxFU",
    "id" : 932862374532411392,
    "created_at" : "2017-11-21 06:44:56 +0000",
    "user" : {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "protected" : false,
      "id_str" : "753358633593925632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918218018500595713\/0-LcTq1y_normal.jpg",
      "id" : 753358633593925632,
      "verified" : false
    }
  },
  "id" : 932887032447221760,
  "created_at" : "2017-11-21 08:22:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pwn \u2588\u2588 \u2588\u2588 \u2588\u2588\u2588 1.4(C) - Declassified in Part",
      "screen_name" : "pwnallthethings",
      "indices" : [ 3, 19 ],
      "id_str" : "2237808535",
      "id" : 2237808535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932734286632960000",
  "text" : "RT @pwnallthethings: How to evaluate blockchain-based tech:\n\nQ: Is your blockchain a cryptocurrency?\nYes: sounds like a Ponzi scheme\nNo: so\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "932639947403689985",
    "geo" : { },
    "id_str" : "932642823136038912",
    "in_reply_to_user_id" : 2237808535,
    "text" : "How to evaluate blockchain-based tech:\n\nQ: Is your blockchain a cryptocurrency?\nYes: sounds like a Ponzi scheme\nNo: sounds like you don't understand how blockchain works",
    "id" : 932642823136038912,
    "in_reply_to_status_id" : 932639947403689985,
    "created_at" : "2017-11-20 16:12:31 +0000",
    "in_reply_to_screen_name" : "pwnallthethings",
    "in_reply_to_user_id_str" : "2237808535",
    "user" : {
      "name" : "Pwn \u2588\u2588 \u2588\u2588 \u2588\u2588\u2588 1.4(C) - Declassified in Part",
      "screen_name" : "pwnallthethings",
      "protected" : false,
      "id_str" : "2237808535",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000850716039\/0bc84c66d3048178cd4d1361f34aa224_normal.jpeg",
      "id" : 2237808535,
      "verified" : false
    }
  },
  "id" : 932734286632960000,
  "created_at" : "2017-11-20 22:15:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/WjmtZ7KeAR",
      "expanded_url" : "https:\/\/twitter.com\/verge\/status\/932610006129762306",
      "display_url" : "twitter.com\/verge\/status\/9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932733167542321152",
  "text" : "\u00ABHelix is unlikely to do major harm, but it\u2019s unlikely to help either.\u00BB On DTC genetics &amp; overselling hype. https:\/\/t.co\/WjmtZ7KeAR",
  "id" : 932733167542321152,
  "created_at" : "2017-11-20 22:11:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 3, 11 ],
      "id_str" : "10328012",
      "id" : 10328012
    }, {
      "name" : "Summer Anne Burton",
      "screen_name" : "summeranne",
      "indices" : [ 13, 24 ],
      "id_str" : "12618872",
      "id" : 12618872
    }, {
      "name" : "Eva Amsen",
      "screen_name" : "easternblot",
      "indices" : [ 25, 37 ],
      "id_str" : "14506075",
      "id" : 14506075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hormiga\/status\/932685362035441665\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/8pGH1RmYXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPGQY-3VQAA-R_k.jpg",
      "id_str" : "932685356708741120",
      "id" : 932685356708741120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPGQY-3VQAA-R_k.jpg",
      "sizes" : [ {
        "h" : 368,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 1094
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 1094
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 1094
      } ],
      "display_url" : "pic.twitter.com\/8pGH1RmYXh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932722051348963328",
  "text" : "RT @hormiga: @summeranne @easternblot Too real https:\/\/t.co\/8pGH1RmYXh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Summer Anne Burton",
        "screen_name" : "summeranne",
        "indices" : [ 0, 11 ],
        "id_str" : "12618872",
        "id" : 12618872
      }, {
        "name" : "Eva Amsen",
        "screen_name" : "easternblot",
        "indices" : [ 12, 24 ],
        "id_str" : "14506075",
        "id" : 14506075
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hormiga\/status\/932685362035441665\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/8pGH1RmYXh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DPGQY-3VQAA-R_k.jpg",
        "id_str" : "932685356708741120",
        "id" : 932685356708741120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPGQY-3VQAA-R_k.jpg",
        "sizes" : [ {
          "h" : 368,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 1094
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 1094
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 1094
        } ],
        "display_url" : "pic.twitter.com\/8pGH1RmYXh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "932392520117637120",
    "geo" : { },
    "id_str" : "932685362035441665",
    "in_reply_to_user_id" : 12618872,
    "text" : "@summeranne @easternblot Too real https:\/\/t.co\/8pGH1RmYXh",
    "id" : 932685362035441665,
    "in_reply_to_status_id" : 932392520117637120,
    "created_at" : "2017-11-20 19:01:33 +0000",
    "in_reply_to_screen_name" : "summeranne",
    "in_reply_to_user_id_str" : "12618872",
    "user" : {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "protected" : false,
      "id_str" : "10328012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/598149093337092096\/YArgwOG7_normal.jpg",
      "id" : 10328012,
      "verified" : true
    }
  },
  "id" : 932722051348963328,
  "created_at" : "2017-11-20 21:27:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 3, 10 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/9gQXRWWaWB",
      "expanded_url" : "https:\/\/twitter.com\/nke_ise\/status\/897756900753891328",
      "display_url" : "twitter.com\/nke_ise\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "932720608785326080",
  "text" : "RT @sujaik: I'm glad the guys in the video are laughing - I'd have probably punched the soap dispenser! https:\/\/t.co\/9gQXRWWaWB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/9gQXRWWaWB",
        "expanded_url" : "https:\/\/twitter.com\/nke_ise\/status\/897756900753891328",
        "display_url" : "twitter.com\/nke_ise\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932678679536291840",
    "text" : "I'm glad the guys in the video are laughing - I'd have probably punched the soap dispenser! https:\/\/t.co\/9gQXRWWaWB",
    "id" : 932678679536291840,
    "created_at" : "2017-11-20 18:35:00 +0000",
    "user" : {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "protected" : false,
      "id_str" : "33651124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499041232765460480\/J2nyoivC_normal.jpeg",
      "id" : 33651124,
      "verified" : false
    }
  },
  "id" : 932720608785326080,
  "created_at" : "2017-11-20 21:21:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Holden",
      "screen_name" : "danrholden",
      "indices" : [ 3, 14 ],
      "id_str" : "36339416",
      "id" : 36339416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932716314824556544",
  "text" : "RT @danrholden: ATTENTION, ATTENTION! This is not a drill! \nREPEAT! This is not a drill! \nWE HAVE REACHED PEAK SCHOLARLY KITCHEN!\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 138, 149 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/OEncxjONTD",
        "expanded_url" : "https:\/\/scholarlykitchen.sspnet.org\/2017\/11\/20\/creating-safety-net-double-dipping-wrong-term-right-approach\/",
        "display_url" : "scholarlykitchen.sspnet.org\/2017\/11\/20\/cre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932581304364949504",
    "text" : "ATTENTION, ATTENTION! This is not a drill! \nREPEAT! This is not a drill! \nWE HAVE REACHED PEAK SCHOLARLY KITCHEN!\nhttps:\/\/t.co\/OEncxjONTD\n#openaccess",
    "id" : 932581304364949504,
    "created_at" : "2017-11-20 12:08:04 +0000",
    "user" : {
      "name" : "Dan Holden",
      "screen_name" : "danrholden",
      "protected" : false,
      "id_str" : "36339416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701696211603087360\/Tqg_J0zK_normal.jpg",
      "id" : 36339416,
      "verified" : false
    }
  },
  "id" : 932716314824556544,
  "created_at" : "2017-11-20 21:04:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenny Teytelman",
      "screen_name" : "lteytelman",
      "indices" : [ 0, 11 ],
      "id_str" : "1343132275",
      "id" : 1343132275
    }, {
      "name" : "Anneliese Taylor",
      "screen_name" : "tayloras21",
      "indices" : [ 12, 23 ],
      "id_str" : "316605521",
      "id" : 316605521
    }, {
      "name" : "jeremy freeman",
      "screen_name" : "thefreemanlab",
      "indices" : [ 24, 38 ],
      "id_str" : "261789755",
      "id" : 261789755
    }, {
      "name" : "Stephen Floor",
      "screen_name" : "stephenfloor",
      "indices" : [ 39, 52 ],
      "id_str" : "37781348",
      "id" : 37781348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931690702307696640",
  "geo" : { },
  "id_str" : "932712258160824320",
  "in_reply_to_user_id" : 1343132275,
  "text" : "@lteytelman @tayloras21 @thefreemanlab @stephenfloor see you there? :)",
  "id" : 932712258160824320,
  "in_reply_to_status_id" : 931690702307696640,
  "created_at" : "2017-11-20 20:48:25 +0000",
  "in_reply_to_screen_name" : "lteytelman",
  "in_reply_to_user_id_str" : "1343132275",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/evCCye7y7P",
      "expanded_url" : "https:\/\/twitter.com\/MozOpenLeaders\/status\/932642441919913990",
      "display_url" : "twitter.com\/MozOpenLeaders\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86326364535286, -122.2727128711637 ]
  },
  "id_str" : "932643522372550656",
  "text" : "A great opportunity you should take: https:\/\/t.co\/evCCye7y7P",
  "id" : 932643522372550656,
  "created_at" : "2017-11-20 16:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nnedi Okorafor, PhD",
      "screen_name" : "Nnedi",
      "indices" : [ 0, 6 ],
      "id_str" : "16504257",
      "id" : 16504257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932496625062285314",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86342335315216, -122.2725748177321 ]
  },
  "id_str" : "932499026921996288",
  "in_reply_to_user_id" : 16504257,
  "text" : "@Nnedi I somewhat fittingly read it beginning of the month on a \u2708\uFE0F  when moving from \uD83C\uDDEA\uD83C\uDDFA to the \uD83C\uDDFA\uD83C\uDDF8. \uD83D\uDE0D",
  "id" : 932499026921996288,
  "in_reply_to_status_id" : 932496625062285314,
  "created_at" : "2017-11-20 06:41:07 +0000",
  "in_reply_to_screen_name" : "Nnedi",
  "in_reply_to_user_id_str" : "16504257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/OuKFZicmcR",
      "expanded_url" : "https:\/\/twitter.com\/Nnedi\/status\/930568934146957312",
      "display_url" : "twitter.com\/Nnedi\/status\/9\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86320099792056, -122.2728461199651 ]
  },
  "id_str" : "932495460845027329",
  "text" : "Take my vote \uD83D\uDDF3\uD83D\uDE0D https:\/\/t.co\/OuKFZicmcR",
  "id" : 932495460845027329,
  "created_at" : "2017-11-20 06:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932434573253754881",
  "geo" : { },
  "id_str" : "932434680263073792",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD aaah, this was walking! :)",
  "id" : 932434680263073792,
  "in_reply_to_status_id" : 932434573253754881,
  "created_at" : "2017-11-20 02:25:26 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932424727796133889",
  "geo" : { },
  "id_str" : "932429039926624257",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD low gear? :)",
  "id" : 932429039926624257,
  "in_reply_to_status_id" : 932424727796133889,
  "created_at" : "2017-11-20 02:03:01 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/FCGGP1PsKV",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbsvBdzFjfI\/",
      "display_url" : "instagram.com\/p\/BbsvBdzFjfI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.883, -122.239 ]
  },
  "id_str" : "932424014588534784",
  "text" : "It\u2019s called the Fun(gal) Kingdom for a reason. @ Berkeley Hills https:\/\/t.co\/FCGGP1PsKV",
  "id" : 932424014588534784,
  "created_at" : "2017-11-20 01:43:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/AvzRAsjOYh",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbsuharFaL3\/",
      "display_url" : "instagram.com\/p\/BbsuharFaL3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.883, -122.239 ]
  },
  "id_str" : "932422499995934721",
  "text" : "Hiking in the woods @ Berkeley Hills https:\/\/t.co\/AvzRAsjOYh",
  "id" : 932422499995934721,
  "created_at" : "2017-11-20 01:37:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/932417094087458816\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/Z7yIqtIpgM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DPCcZpvVwAYEF5k.jpg",
      "id_str" : "932417087380766726",
      "id" : 932417087380766726,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DPCcZpvVwAYEF5k.jpg",
      "sizes" : [ {
        "h" : 498,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 2332
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 850,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Z7yIqtIpgM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932417094087458816",
  "text" : "Today consisted of finding a way around Panoramic Hill. https:\/\/t.co\/Z7yIqtIpgM",
  "id" : 932417094087458816,
  "created_at" : "2017-11-20 01:15:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ala'a Shehabi",
      "screen_name" : "alaashehabi",
      "indices" : [ 3, 15 ],
      "id_str" : "20060060",
      "id" : 20060060
    }, {
      "name" : "Morgan Marquis-Boire",
      "screen_name" : "headhntr",
      "indices" : [ 24, 33 ],
      "id_str" : "22404415",
      "id" : 22404415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932339010902507520",
  "text" : "RT @alaashehabi: Morgan @headhntr did some awesome technical work on exposing surveillance technology that was used to target me in 2012 .\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Morgan Marquis-Boire",
        "screen_name" : "headhntr",
        "indices" : [ 7, 16 ],
        "id_str" : "22404415",
        "id" : 22404415
      }, {
        "name" : "women in general",
        "screen_name" : "sarahjeong",
        "indices" : [ 163, 174 ],
        "id_str" : "47509268",
        "id" : 47509268
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 260, 283 ],
        "url" : "https:\/\/t.co\/JMf2qq34hE",
        "expanded_url" : "https:\/\/www.theverge.com\/2017\/11\/19\/16675704\/morgan-marquis-boire-hacker-sexual-assault",
        "display_url" : "theverge.com\/2017\/11\/19\/166\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "932330967175442437",
    "text" : "Morgan @headhntr did some awesome technical work on exposing surveillance technology that was used to target me in 2012 . He was also a serial rapist. The Verge's @sarahjeong exposes him here. Painful &amp; sad to read this about someone who shared a platform https:\/\/t.co\/JMf2qq34hE",
    "id" : 932330967175442437,
    "created_at" : "2017-11-19 19:33:19 +0000",
    "user" : {
      "name" : "Ala'a Shehabi",
      "screen_name" : "alaashehabi",
      "protected" : false,
      "id_str" : "20060060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737024326478659584\/62BM-i3c_normal.jpg",
      "id" : 20060060,
      "verified" : true
    }
  },
  "id" : 932339010902507520,
  "created_at" : "2017-11-19 20:05:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "932150268225040389",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86330798972787, -122.2726352085709 ]
  },
  "id_str" : "932154502861357056",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin Every single thing!",
  "id" : 932154502861357056,
  "in_reply_to_status_id" : 932150268225040389,
  "created_at" : "2017-11-19 07:52:06 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/hCvn257lXV",
      "expanded_url" : "https:\/\/twitter.com\/paleofuture\/status\/931709067923374080",
      "display_url" : "twitter.com\/paleofuture\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86328705917083, -122.2726268855983 ]
  },
  "id_str" : "932143778034360320",
  "text" : "This can\u2019t come soon enough. Also ISO 8601 please? https:\/\/t.co\/hCvn257lXV",
  "id" : 932143778034360320,
  "created_at" : "2017-11-19 07:09:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/kaft7CunO0",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbqvBthFDiT\/",
      "display_url" : "instagram.com\/p\/BbqvBthFDiT\/"
    } ]
  },
  "geo" : { },
  "id_str" : "932142339266695169",
  "text" : "Yet another hill to climb #latergram https:\/\/t.co\/kaft7CunO0",
  "id" : 932142339266695169,
  "created_at" : "2017-11-19 07:03:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/w0iIEZJbYZ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbqNPPeFkCb\/",
      "display_url" : "instagram.com\/p\/BbqNPPeFkCb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "932067847462731778",
  "text" : "A hill with a view https:\/\/t.co\/w0iIEZJbYZ",
  "id" : 932067847462731778,
  "created_at" : "2017-11-19 02:07:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/mZK3XSoSs2",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbqLINvlGKE\/",
      "display_url" : "instagram.com\/p\/BbqLINvlGKE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.80826162724, -122.41462400665 ]
  },
  "id_str" : "932063209686573056",
  "text" : "Mid-flight \uD83C\uDF0A\uD83E\uDD85\uD83D\uDEA2 @ Fisherman's Wharf https:\/\/t.co\/mZK3XSoSs2",
  "id" : 932063209686573056,
  "created_at" : "2017-11-19 01:49:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/aalHL5I3nh",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/Bbp-lu6FqRF\/",
      "display_url" : "instagram.com\/p\/Bbp-lu6FqRF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "932035634151038976",
  "text" : "Not exactly Palo Alto https:\/\/t.co\/aalHL5I3nh",
  "id" : 932035634151038976,
  "created_at" : "2017-11-18 23:59:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931935202133278721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86328298426795, -122.272547886983 ]
  },
  "id_str" : "931938153283313669",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy We\u2019ll need a bit more data for that ;)",
  "id" : 931938153283313669,
  "in_reply_to_status_id" : 931935202133278721,
  "created_at" : "2017-11-18 17:32:24 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931798242320437253",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86328298426795, -122.272547886983 ]
  },
  "id_str" : "931938067757252608",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin They are certified free of genes, is that okay too?",
  "id" : 931938067757252608,
  "in_reply_to_status_id" : 931798242320437253,
  "created_at" : "2017-11-18 17:32:04 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Bowyer",
      "screen_name" : "adrianbowyer",
      "indices" : [ 0, 13 ],
      "id_str" : "172501837",
      "id" : 172501837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931934566406852608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86328298426795, -122.272547886983 ]
  },
  "id_str" : "931937791344197633",
  "in_reply_to_user_id" : 172501837,
  "text" : "@adrianbowyer Freely sharing your genome attracts certain kinds of people? :)",
  "id" : 931937791344197633,
  "in_reply_to_status_id" : 931934566406852608,
  "created_at" : "2017-11-18 17:30:58 +0000",
  "in_reply_to_screen_name" : "adrianbowyer",
  "in_reply_to_user_id_str" : "172501837",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931933732956790785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86303538366953, -122.2729446274436 ]
  },
  "id_str" : "931934318993162240",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy That\u2019s what I had assumed. Barely making the top half but farish to the economic right :)",
  "id" : 931934318993162240,
  "in_reply_to_status_id" : 931933732956790785,
  "created_at" : "2017-11-18 17:17:10 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Bond",
      "screen_name" : "TheLabAndField",
      "indices" : [ 0, 15 ],
      "id_str" : "1060545835",
      "id" : 1060545835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931933472746295297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86323801396691, -122.2726862530128 ]
  },
  "id_str" : "931933617911033856",
  "in_reply_to_user_id" : 1060545835,
  "text" : "@TheLabAndField Let me try @ as soon as I\u2019m in better shape? ;)",
  "id" : 931933617911033856,
  "in_reply_to_status_id" : 931933472746295297,
  "created_at" : "2017-11-18 17:14:23 +0000",
  "in_reply_to_screen_name" : "TheLabAndField",
  "in_reply_to_user_id_str" : "1060545835",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Pardy",
      "screen_name" : "BrianPardy",
      "indices" : [ 0, 11 ],
      "id_str" : "611699110",
      "id" : 611699110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931931655085985792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86316488407353, -122.2729862855023 ]
  },
  "id_str" : "931933347701391360",
  "in_reply_to_user_id" : 611699110,
  "text" : "@BrianPardy Where in the top right are you? :D",
  "id" : 931933347701391360,
  "in_reply_to_status_id" : 931931655085985792,
  "created_at" : "2017-11-18 17:13:19 +0000",
  "in_reply_to_screen_name" : "BrianPardy",
  "in_reply_to_user_id_str" : "611699110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/931933214368718848\/photo\/1",
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/kh3YGIO4pW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DO7kUZZUQAEjKgP.jpg",
      "id_str" : "931933211977859073",
      "id" : 931933211977859073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DO7kUZZUQAEjKgP.jpg",
      "sizes" : [ {
        "h" : 785,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 785,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/kh3YGIO4pW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931933214368718848",
  "text" : "\u2318 \uD83C\uDFC3 https:\/\/t.co\/kh3YGIO4pW",
  "id" : 931933214368718848,
  "created_at" : "2017-11-18 17:12:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931922020345905152",
  "text" : "RT @gedankenstuecke: By now 22 openSNP users share their political compass results. Not really surprised by the distribution. (data at http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/931684658604949505\/photo\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/GE46tGydb7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DO4CQc_UEAAlXw0.png",
        "id_str" : "931684654595182592",
        "id" : 931684654595182592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DO4CQc_UEAAlXw0.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1544,
          "resize" : "fit",
          "w" : 1576
        }, {
          "h" : 1544,
          "resize" : "fit",
          "w" : 1576
        }, {
          "h" : 1176,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/GE46tGydb7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/RqNna6goVu",
        "expanded_url" : "https:\/\/opensnp.org\/phenotypes\/276",
        "display_url" : "opensnp.org\/phenotypes\/276"
      } ]
    },
    "geo" : { },
    "id_str" : "931684658604949505",
    "text" : "By now 22 openSNP users share their political compass results. Not really surprised by the distribution. (data at https:\/\/t.co\/RqNna6goVu) https:\/\/t.co\/GE46tGydb7",
    "id" : 931684658604949505,
    "created_at" : "2017-11-18 00:45:07 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 931922020345905152,
  "created_at" : "2017-11-18 16:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931921997155717121",
  "text" : "RT @gedankenstuecke: Take a look at the Keeping Pace study on Open Humans. You and your smartphone can make a difference to public health r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 127, 150 ],
        "url" : "https:\/\/t.co\/lCqKDl7D0z",
        "expanded_url" : "https:\/\/blog.openhumans.org\/2017\/11\/17\/keeping-pace-you-can-advance-health-research-with-your-smartphone\/",
        "display_url" : "blog.openhumans.org\/2017\/11\/17\/kee\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "931579186677870593",
    "text" : "Take a look at the Keeping Pace study on Open Humans. You and your smartphone can make a difference to public health research! https:\/\/t.co\/lCqKDl7D0z",
    "id" : 931579186677870593,
    "created_at" : "2017-11-17 17:46:00 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 931921997155717121,
  "created_at" : "2017-11-18 16:28:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/MsngzFW6Xe",
      "expanded_url" : "https:\/\/upload.wikimedia.org\/wikipedia\/commons\/thumb\/7\/7d\/Disneyland_Prop_65_Warning_crop.jpg\/220px-Disneyland_Prop_65_Warning_crop.jpg",
      "display_url" : "upload.wikimedia.org\/wikipedia\/comm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "931777500581187584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86329889445133, -122.2727381214334 ]
  },
  "id_str" : "931777974407348224",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad https:\/\/t.co\/MsngzFW6Xe \uD83D\uDE02",
  "id" : 931777974407348224,
  "in_reply_to_status_id" : 931777500581187584,
  "created_at" : "2017-11-18 06:55:55 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/MEBgZelnSY",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/California_Proposition_65_(1986)",
      "display_url" : "en.wikipedia.org\/wiki\/Californi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "931776736299241472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86317318215767, -122.2728648317254 ]
  },
  "id_str" : "931777060833411072",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad Virtually all of them. It\u2019s like these cookie warnings on websites \uD83D\uDE02 https:\/\/t.co\/MEBgZelnSY",
  "id" : 931777060833411072,
  "in_reply_to_status_id" : 931776736299241472,
  "created_at" : "2017-11-18 06:52:17 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/lxQs0qdXUS",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BboH0GylCF6\/",
      "display_url" : "instagram.com\/p\/BboH0GylCF6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "931774436776308736",
  "text" : "The writing on the wall https:\/\/t.co\/lxQs0qdXUS",
  "id" : 931774436776308736,
  "created_at" : "2017-11-18 06:41:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Arvestad",
      "screen_name" : "arvestad",
      "indices" : [ 0, 9 ],
      "id_str" : "403987115",
      "id" : 403987115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931769818285527040",
  "geo" : { },
  "id_str" : "931773605607718912",
  "in_reply_to_user_id" : 403987115,
  "text" : "@arvestad did it have the \u2018this product contains chemicals known to the State of California to cause cancer and birth defects or other reproductive harms\u2019-warning label though? :D",
  "id" : 931773605607718912,
  "in_reply_to_status_id" : 931769818285527040,
  "created_at" : "2017-11-18 06:38:33 +0000",
  "in_reply_to_screen_name" : "arvestad",
  "in_reply_to_user_id_str" : "403987115",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 3, 15 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931745628232626176",
  "text" : "RT @monimunozto: Make that three coins in the bucket of \"friends who got a great new job because of their awesomeness - with a tiny push fr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "931713442116861952",
    "text" : "Make that three coins in the bucket of \"friends who got a great new job because of their awesomeness - with a tiny push from my ninja networking skills\". It makes me feel both so proud and so happy! Woohoo! \uD83C\uDF87\uD83D\uDCAB\uD83C\uDF86",
    "id" : 931713442116861952,
    "created_at" : "2017-11-18 02:39:29 +0000",
    "user" : {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "protected" : false,
      "id_str" : "538714687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713239690309083136\/QlP8BsHj_normal.jpg",
      "id" : 538714687,
      "verified" : false
    }
  },
  "id" : 931745628232626176,
  "created_at" : "2017-11-18 04:47:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86327321736497, -122.2727649591624 ]
  },
  "id_str" : "931743380299661312",
  "text" : "Californian ingredient lists are ridiculous. I see your \u2018Aluminum Free Baking Soda\u2019 and raise \u2018Arsenic Free Sea Salt\u2019. \uD83D\uDE02",
  "id" : 931743380299661312,
  "created_at" : "2017-11-18 04:38:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931686307205713920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85131012963549, -122.2942140162119 ]
  },
  "id_str" : "931688922152706048",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr Also: I think two people cheated. Don\u2019t think you can be more left than -10. :D",
  "id" : 931688922152706048,
  "in_reply_to_status_id" : 931686307205713920,
  "created_at" : "2017-11-18 01:02:03 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/931684658604949505\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/GE46tGydb7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DO4CQc_UEAAlXw0.png",
      "id_str" : "931684654595182592",
      "id" : 931684654595182592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DO4CQc_UEAAlXw0.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1544,
        "resize" : "fit",
        "w" : 1576
      }, {
        "h" : 1544,
        "resize" : "fit",
        "w" : 1576
      }, {
        "h" : 1176,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/GE46tGydb7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RqNna6goVu",
      "expanded_url" : "https:\/\/opensnp.org\/phenotypes\/276",
      "display_url" : "opensnp.org\/phenotypes\/276"
    } ]
  },
  "geo" : { },
  "id_str" : "931684658604949505",
  "text" : "By now 22 openSNP users share their political compass results. Not really surprised by the distribution. (data at https:\/\/t.co\/RqNna6goVu) https:\/\/t.co\/GE46tGydb7",
  "id" : 931684658604949505,
  "created_at" : "2017-11-18 00:45:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mouse Reeve",
      "screen_name" : "tripofmice",
      "indices" : [ 3, 14 ],
      "id_str" : "1304991110",
      "id" : 1304991110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/KpjNpHvdUU",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=xR1c2ysHl7Q",
      "display_url" : "youtube.com\/watch?v=xR1c2y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931641675830591488",
  "text" : "RT @tripofmice: wow the new boston dynamics robot is incredible\nhttps:\/\/t.co\/KpjNpHvdUU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/KpjNpHvdUU",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=xR1c2ysHl7Q",
        "display_url" : "youtube.com\/watch?v=xR1c2y\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "931553263513563136",
    "text" : "wow the new boston dynamics robot is incredible\nhttps:\/\/t.co\/KpjNpHvdUU",
    "id" : 931553263513563136,
    "created_at" : "2017-11-17 16:03:00 +0000",
    "user" : {
      "name" : "Mouse Reeve",
      "screen_name" : "tripofmice",
      "protected" : false,
      "id_str" : "1304991110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877644089356713984\/sdBg_srE_normal.jpg",
      "id" : 1304991110,
      "verified" : false
    }
  },
  "id" : 931641675830591488,
  "created_at" : "2017-11-17 21:54:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/931592398513217536\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/gJ5cFcn7qI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DO2uWOEUMAENPMP.jpg",
      "id_str" : "931592394692112385",
      "id" : 931592394692112385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DO2uWOEUMAENPMP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 289,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1598
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1598
      } ],
      "display_url" : "pic.twitter.com\/gJ5cFcn7qI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931592398513217536",
  "text" : "The openSNP &lt;\u2013&gt; Open Humans connection is getting there. \uD83C\uDF89 https:\/\/t.co\/gJ5cFcn7qI",
  "id" : 931592398513217536,
  "created_at" : "2017-11-17 18:38:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 150 ],
      "url" : "https:\/\/t.co\/lCqKDl7D0z",
      "expanded_url" : "https:\/\/blog.openhumans.org\/2017\/11\/17\/keeping-pace-you-can-advance-health-research-with-your-smartphone\/",
      "display_url" : "blog.openhumans.org\/2017\/11\/17\/kee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "931579186677870593",
  "text" : "Take a look at the Keeping Pace study on Open Humans. You and your smartphone can make a difference to public health research! https:\/\/t.co\/lCqKDl7D0z",
  "id" : 931579186677870593,
  "created_at" : "2017-11-17 17:46:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 0, 11 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/pfh4D3bDQs",
      "expanded_url" : "https:\/\/opensnp.org\/statistics",
      "display_url" : "opensnp.org\/statistics"
    } ]
  },
  "in_reply_to_status_id_str" : "931557631453380608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86317921712796, -122.2729701084292 ]
  },
  "id_str" : "931559097064767489",
  "in_reply_to_user_id" : 1218100328,
  "text" : "@ChrisFiloG Yep, and it\u2019s a steady growth. https:\/\/t.co\/pfh4D3bDQs",
  "id" : 931559097064767489,
  "in_reply_to_status_id" : 931557631453380608,
  "created_at" : "2017-11-17 16:26:10 +0000",
  "in_reply_to_screen_name" : "ChrisFiloG",
  "in_reply_to_user_id_str" : "1218100328",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 0, 11 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931552595142778880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86325902262006, -122.2728142017156 ]
  },
  "id_str" : "931556312856399873",
  "in_reply_to_user_id" : 1218100328,
  "text" : "@ChrisFiloG Though I do fully agree with the sentiment of course :)",
  "id" : 931556312856399873,
  "in_reply_to_status_id" : 931552595142778880,
  "created_at" : "2017-11-17 16:15:07 +0000",
  "in_reply_to_screen_name" : "ChrisFiloG",
  "in_reply_to_user_id_str" : "1218100328",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 0, 11 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931552595142778880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86342573506644, -122.2728612040768 ]
  },
  "id_str" : "931556231864397824",
  "in_reply_to_user_id" : 1218100328,
  "text" : "@ChrisFiloG Actually, that\u2019s not completely correct: 6,000 registered users, but only ~3,600 have uploaded at least a single file. For a total of ~3,800 genetic data files. :)",
  "id" : 931556231864397824,
  "in_reply_to_status_id" : 931552595142778880,
  "created_at" : "2017-11-17 16:14:47 +0000",
  "in_reply_to_screen_name" : "ChrisFiloG",
  "in_reply_to_user_id_str" : "1218100328",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "indices" : [ 3, 14 ],
      "id_str" : "1218100328",
      "id" : 1218100328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931555921540431872",
  "text" : "RT @ChrisFiloG: 6000 people donated their genetic data to the OpenSNP project for public unconstrained redistribution, despite a very expli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 257, 280 ],
        "url" : "https:\/\/t.co\/xWfESn1WHg",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/931333522693877762",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "931552595142778880",
    "text" : "6000 people donated their genetic data to the OpenSNP project for public unconstrained redistribution, despite a very explicit consent form warning of reidentification and other risks. Proof that many participants want to maximize the impact of their data! https:\/\/t.co\/xWfESn1WHg",
    "id" : 931552595142778880,
    "created_at" : "2017-11-17 16:00:20 +0000",
    "user" : {
      "name" : "Chris Gorgolewski",
      "screen_name" : "ChrisFiloG",
      "protected" : false,
      "id_str" : "1218100328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428604938995109888\/FDYSkfdz_normal.jpeg",
      "id" : 1218100328,
      "verified" : false
    }
  },
  "id" : 931555921540431872,
  "created_at" : "2017-11-17 16:13:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931334854272102400",
  "geo" : { },
  "id_str" : "931336000785170432",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch plus ~800 new files since start of 2017. \uD83C\uDF89",
  "id" : 931336000785170432,
  "in_reply_to_status_id" : 931334854272102400,
  "created_at" : "2017-11-17 01:39:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 26, 39 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 40, 52 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931333522693877762",
  "text" : "Another openSNP milestone @PhilippBayer @helgerausch and I slept through: 6,000 registered users on 2017-11-10. \uD83D\uDE48\uD83D\uDE34\uD83C\uDF89\uD83D\uDE02",
  "id" : 931333522693877762,
  "created_at" : "2017-11-17 01:29:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    }, {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 17, 28 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931284533252644865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85132566268917, -122.2941652901368 ]
  },
  "id_str" : "931292039722835968",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski @EffyVayena Let\u2019s see how long it\u2019ll be before it\u2019s approved. This was just the application ;)",
  "id" : 931292039722835968,
  "in_reply_to_status_id" : 931284533252644865,
  "created_at" : "2017-11-16 22:44:59 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931270770688479232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85142359236477, -122.2945145947057 ]
  },
  "id_str" : "931283189804306432",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena The hour-long wait in which nothing happened. ;)",
  "id" : 931283189804306432,
  "in_reply_to_status_id" : 931270770688479232,
  "created_at" : "2017-11-16 22:09:49 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931268186560794624",
  "text" : "Applying for a social security number brought back fond memories of the Greek bureaucracy. \uD83D\uDE02",
  "id" : 931268186560794624,
  "created_at" : "2017-11-16 21:10:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931065194092093441",
  "geo" : { },
  "id_str" : "931268045779083270",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha yeah, that\u2019s my assumption to! (but then IANAL either).",
  "id" : 931268045779083270,
  "in_reply_to_status_id" : 931065194092093441,
  "created_at" : "2017-11-16 21:09:38 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/Rl3v8kUFqT",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbkC0ynlHH2\/",
      "display_url" : "instagram.com\/p\/BbkC0ynlHH2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "931200511306584069",
  "text" : "Splendor. As founds on my way to the office. https:\/\/t.co\/Rl3v8kUFqT",
  "id" : 931200511306584069,
  "created_at" : "2017-11-16 16:41:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "simine vazire",
      "screen_name" : "siminevazire",
      "indices" : [ 3, 16 ],
      "id_str" : "836548849",
      "id" : 836548849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931062139397091328",
  "text" : "RT @siminevazire: When reviewers know authors' identities (vs. blind), they pick high status authors more.\nReviewers=human=biased\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/XaxUJJvT7C",
        "expanded_url" : "http:\/\/www.pnas.org\/content\/early\/2017\/11\/13\/1707323114.full.pdf",
        "display_url" : "pnas.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "930972734917505024",
    "text" : "When reviewers know authors' identities (vs. blind), they pick high status authors more.\nReviewers=human=biased\nhttps:\/\/t.co\/XaxUJJvT7C",
    "id" : 930972734917505024,
    "created_at" : "2017-11-16 01:36:11 +0000",
    "user" : {
      "name" : "simine vazire",
      "screen_name" : "siminevazire",
      "protected" : false,
      "id_str" : "836548849",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592128718656516097\/3tBnCOCs_normal.jpg",
      "id" : 836548849,
      "verified" : false
    }
  },
  "id" : 931062139397091328,
  "created_at" : "2017-11-16 07:31:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/YDgvseiIEj",
      "expanded_url" : "https:\/\/twitter.com\/JakeOrlowitz\/status\/930963655411187713",
      "display_url" : "twitter.com\/JakeOrlowitz\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86331068379266, -122.272572677151 ]
  },
  "id_str" : "931061375949926400",
  "text" : "Can\u2019t advise use of sci-hub for legal and risk reasons? Is there a single case where a _user_ of Sci-Hub faced consequences? https:\/\/t.co\/YDgvseiIEj",
  "id" : 931061375949926400,
  "created_at" : "2017-11-16 07:28:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 3, 12 ],
      "id_str" : "594278352",
      "id" : 594278352
    }, {
      "name" : "Daniella Lowenberg",
      "screen_name" : "DaniLowenberg",
      "indices" : [ 100, 114 ],
      "id_str" : "115831933",
      "id" : 115831933
    }, {
      "name" : "Dan Morgan",
      "screen_name" : "djjmorgan",
      "indices" : [ 115, 125 ],
      "id_str" : "237018893",
      "id" : 237018893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/84bll66oJW",
      "expanded_url" : "https:\/\/community.stenci.la\/t\/stencila-at-uc-berkeley",
      "display_url" : "community.stenci.la\/t\/stencila-at-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930905789874585600",
  "text" : "RT @stencila: Thank you Berkeley for a great workshop on Stencila Sheets.\n\nhttps:\/\/t.co\/84bll66oJW\n\n@DaniLowenberg @djjmorgan @gedankenstue\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniella Lowenberg",
        "screen_name" : "DaniLowenberg",
        "indices" : [ 86, 100 ],
        "id_str" : "115831933",
        "id" : 115831933
      }, {
        "name" : "Dan Morgan",
        "screen_name" : "djjmorgan",
        "indices" : [ 101, 111 ],
        "id_str" : "237018893",
        "id" : 237018893
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 112, 128 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "ResearchTransparency",
        "screen_name" : "UCBITSS",
        "indices" : [ 129, 137 ],
        "id_str" : "2838358556",
        "id" : 2838358556
      }, {
        "name" : "UC Curation Center",
        "screen_name" : "UC3CDL",
        "indices" : [ 138, 145 ],
        "id_str" : "1944535268",
        "id" : 1944535268
      }, {
        "name" : "Dash",
        "screen_name" : "UC3dash",
        "indices" : [ 146, 154 ],
        "id_str" : "1311656826",
        "id" : 1311656826
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stencila\/status\/930893422457626624\/photo\/1",
        "indices" : [ 155, 178 ],
        "url" : "https:\/\/t.co\/mzzq22KZx0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DOslBelV4AAORcr.jpg",
        "id_str" : "930878455301922816",
        "id" : 930878455301922816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOslBelV4AAORcr.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1094,
          "resize" : "fit",
          "w" : 1642
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1094,
          "resize" : "fit",
          "w" : 1642
        } ],
        "display_url" : "pic.twitter.com\/mzzq22KZx0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/84bll66oJW",
        "expanded_url" : "https:\/\/community.stenci.la\/t\/stencila-at-uc-berkeley",
        "display_url" : "community.stenci.la\/t\/stencila-at-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "930893422457626624",
    "text" : "Thank you Berkeley for a great workshop on Stencila Sheets.\n\nhttps:\/\/t.co\/84bll66oJW\n\n@DaniLowenberg @djjmorgan @gedankenstuecke @UCBITSS @UC3CDL @UC3dash https:\/\/t.co\/mzzq22KZx0",
    "id" : 930893422457626624,
    "created_at" : "2017-11-15 20:21:01 +0000",
    "user" : {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "protected" : false,
      "id_str" : "594278352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876567807357444096\/2MlCMWZ__normal.jpg",
      "id" : 594278352,
      "verified" : false
    }
  },
  "id" : 930905789874585600,
  "created_at" : "2017-11-15 21:10:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 28, 41 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/IiDzRAimgJ",
      "expanded_url" : "https:\/\/twitter.com\/RaoOfPhysics\/status\/930895036920803328",
      "display_url" : "twitter.com\/RaoOfPhysics\/s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "930895036920803328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85170103562607, -122.2944114142453 ]
  },
  "id_str" : "930905527097352192",
  "in_reply_to_user_id" : 67529128,
  "text" : "I can only recommend taking @RaoOfPhysics up on this! \uD83D\uDE0D\uD83D\uDC96 https:\/\/t.co\/IiDzRAimgJ",
  "id" : 930905527097352192,
  "in_reply_to_status_id" : 930895036920803328,
  "created_at" : "2017-11-15 21:09:07 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nokome Bentley",
      "screen_name" : "NokomeBentley",
      "indices" : [ 0, 14 ],
      "id_str" : "1576006626",
      "id" : 1576006626
    }, {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 15, 24 ],
      "id_str" : "594278352",
      "id" : 594278352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930858177440104448",
  "geo" : { },
  "id_str" : "930858310391144448",
  "in_reply_to_user_id" : 1576006626,
  "text" : "@NokomeBentley @stencila No worries, I\u2019d love to contribute but I wouldn\u2019t know where to take the time for that at this point!",
  "id" : 930858310391144448,
  "in_reply_to_status_id" : 930858177440104448,
  "created_at" : "2017-11-15 18:01:30 +0000",
  "in_reply_to_screen_name" : "NokomeBentley",
  "in_reply_to_user_id_str" : "1576006626",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930749725543944192",
  "geo" : { },
  "id_str" : "930851009915633665",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute it\u2019s so well deserved!",
  "id" : 930851009915633665,
  "in_reply_to_status_id" : 930749725543944192,
  "created_at" : "2017-11-15 17:32:29 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930684843654045697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86328990015934, -122.2726727185047 ]
  },
  "id_str" : "930687695009042433",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy You\u2019re a criminal mastermind! \uD83D\uDE02\uD83D\uDE0D",
  "id" : 930687695009042433,
  "in_reply_to_status_id" : 930684843654045697,
  "created_at" : "2017-11-15 06:43:32 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nokome Bentley",
      "screen_name" : "NokomeBentley",
      "indices" : [ 0, 14 ],
      "id_str" : "1576006626",
      "id" : 1576006626
    }, {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 15, 24 ],
      "id_str" : "594278352",
      "id" : 594278352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/QygQmnz0eq",
      "expanded_url" : "http:\/\/gedankenstuecke.github.io\/scienceisglobal\/",
      "display_url" : "gedankenstuecke.github.io\/scienceisgloba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "930656054173560832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86324442353848, -122.2728649805391 ]
  },
  "id_str" : "930661849523134464",
  "in_reply_to_user_id" : 1576006626,
  "text" : "@NokomeBentley @stencila That\u2019s what I basically did for https:\/\/t.co\/QygQmnz0eq",
  "id" : 930661849523134464,
  "in_reply_to_status_id" : 930656054173560832,
  "created_at" : "2017-11-15 05:00:50 +0000",
  "in_reply_to_screen_name" : "NokomeBentley",
  "in_reply_to_user_id_str" : "1576006626",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nokome Bentley",
      "screen_name" : "NokomeBentley",
      "indices" : [ 0, 14 ],
      "id_str" : "1576006626",
      "id" : 1576006626
    }, {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 15, 24 ],
      "id_str" : "594278352",
      "id" : 594278352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930637189272166400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85727177631851, -122.2671521493576 ]
  },
  "id_str" : "930643852121145344",
  "in_reply_to_user_id" : 1576006626,
  "text" : "@NokomeBentley @stencila I struggled with emoji in Google Docs, LibreOffice and even R! So that\u2019s a big plus!",
  "id" : 930643852121145344,
  "in_reply_to_status_id" : 930637189272166400,
  "created_at" : "2017-11-15 03:49:19 +0000",
  "in_reply_to_screen_name" : "NokomeBentley",
  "in_reply_to_user_id_str" : "1576006626",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930503504870776832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86324432184944, -122.2725445855406 ]
  },
  "id_str" : "930621448875417605",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Neighbors car alarm \uD83D\uDEA8 rang for 3 1\/2 hours straight. Just wished someone would finally steal it.",
  "id" : 930621448875417605,
  "in_reply_to_status_id" : 930503504870776832,
  "created_at" : "2017-11-15 02:20:18 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 51, 60 ],
      "id_str" : "594278352",
      "id" : 594278352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86328220844688, -122.2725976621021 ]
  },
  "id_str" : "930616561248829440",
  "text" : "The killer spreadsheet feature I wished for at the @stencila event today: emoji support. \uD83E\uDD1E\uD83D\uDC4D\uD83D\uDE02",
  "id" : 930616561248829440,
  "created_at" : "2017-11-15 02:00:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Morgan",
      "screen_name" : "djjmorgan",
      "indices" : [ 0, 10 ],
      "id_str" : "237018893",
      "id" : 237018893
    }, {
      "name" : "Nokome Bentley",
      "screen_name" : "NokomeBentley",
      "indices" : [ 11, 25 ],
      "id_str" : "1576006626",
      "id" : 1576006626
    }, {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 26, 35 ],
      "id_str" : "594278352",
      "id" : 594278352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930600051734339584",
  "geo" : { },
  "id_str" : "930601095432302593",
  "in_reply_to_user_id" : 237018893,
  "text" : "@djjmorgan @NokomeBentley @stencila fully agree, that was a great session! And good to meet you Dan!",
  "id" : 930601095432302593,
  "in_reply_to_status_id" : 930600051734339584,
  "created_at" : "2017-11-15 00:59:25 +0000",
  "in_reply_to_screen_name" : "djjmorgan",
  "in_reply_to_user_id_str" : "237018893",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 12, 21 ],
      "id_str" : "594278352",
      "id" : 594278352
    }, {
      "name" : "Nokome Bentley",
      "screen_name" : "NokomeBentley",
      "indices" : [ 61, 75 ],
      "id_str" : "1576006626",
      "id" : 1576006626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930526165961338881",
  "text" : "Now for the @stencila workshop at UC Berkeley. Great to meet @NokomeBentley again! \uD83C\uDF89",
  "id" : 930526165961338881,
  "created_at" : "2017-11-14 20:01:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/yeg065RjTX",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbfLbiQl9yS\/",
      "display_url" : "instagram.com\/p\/BbfLbiQl9yS\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86767, -122.3125 ]
  },
  "id_str" : "930515750955114497",
  "text" : "Somewhere there\u2019s SF in the distance.\u2601\uFE0F #latergram @ Berkeley Marina https:\/\/t.co\/yeg065RjTX",
  "id" : 930515750955114497,
  "created_at" : "2017-11-14 19:20:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fbz",
      "screen_name" : "fbz",
      "indices" : [ 0, 4 ],
      "id_str" : "15282432",
      "id" : 15282432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930327474268803072",
  "geo" : { },
  "id_str" : "930336196680589312",
  "in_reply_to_user_id" : 15282432,
  "text" : "@fbz now that I'm over I should finally get one!",
  "id" : 930336196680589312,
  "in_reply_to_status_id" : 930327474268803072,
  "created_at" : "2017-11-14 07:26:48 +0000",
  "in_reply_to_screen_name" : "fbz",
  "in_reply_to_user_id_str" : "15282432",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Cabanac",
      "screen_name" : "gcabanac",
      "indices" : [ 0, 9 ],
      "id_str" : "237738266",
      "id" : 237738266
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 10, 18 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "indices" : [ 19, 32 ],
      "id_str" : "7841792",
      "id" : 7841792
    }, {
      "name" : "Casey Greene",
      "screen_name" : "GreeneScientist",
      "indices" : [ 33, 49 ],
      "id_str" : "95233492",
      "id" : 95233492
    }, {
      "name" : "John Bohannon",
      "screen_name" : "BohannonScience",
      "indices" : [ 50, 66 ],
      "id_str" : "3306715546",
      "id" : 3306715546
    }, {
      "name" : "Ryan Regier",
      "screen_name" : "ryregier",
      "indices" : [ 67, 76 ],
      "id_str" : "1259776242",
      "id" : 1259776242
    }, {
      "name" : "Aaron Tay",
      "screen_name" : "aarontay",
      "indices" : [ 77, 86 ],
      "id_str" : "15196090",
      "id" : 15196090
    }, {
      "name" : "Martin Clavey",
      "screen_name" : "mart1oeil",
      "indices" : [ 87, 97 ],
      "id_str" : "122451753",
      "id" : 122451753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930312994671812608",
  "geo" : { },
  "id_str" : "930313579940659202",
  "in_reply_to_user_id" : 237738266,
  "text" : "@gcabanac @dhimmel @SteveMcLaugh @GreeneScientist @BohannonScience @ryregier @aarontay @mart1oeil thanks!",
  "id" : 930313579940659202,
  "in_reply_to_status_id" : 930312994671812608,
  "created_at" : "2017-11-14 05:56:56 +0000",
  "in_reply_to_screen_name" : "gcabanac",
  "in_reply_to_user_id_str" : "237738266",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/F4P9jME44K",
      "expanded_url" : "https:\/\/twitter.com\/mart1oeil\/status\/930188436421726208",
      "display_url" : "twitter.com\/mart1oeil\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930313547430555648",
  "text" : "Brilliant note about data availability \uD83D\uDE0D \uD83D\uDE02 https:\/\/t.co\/F4P9jME44K",
  "id" : 930313547430555648,
  "created_at" : "2017-11-14 05:56:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/0kx1QDOEOH",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/pull\/438",
      "display_url" : "github.com\/openSNP\/snpr\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "930285362143883264",
  "text" : "Still a lot of work to do, but the connection of Open Humans &amp; openSNP works in my development environment! \uD83C\uDF89 https:\/\/t.co\/0kx1QDOEOH",
  "id" : 930285362143883264,
  "created_at" : "2017-11-14 04:04:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/2TReXzhUi9",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/14mgxYFJHXGmoo\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/14mgxYFJ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "930177331636899840",
  "geo" : { },
  "id_str" : "930180580213366784",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon suspicious! https:\/\/t.co\/2TReXzhUi9",
  "id" : 930180580213366784,
  "in_reply_to_status_id" : 930177331636899840,
  "created_at" : "2017-11-13 21:08:26 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 0, 11 ],
      "id_str" : "351049850",
      "id" : 351049850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930156505445285888",
  "geo" : { },
  "id_str" : "930158868096622592",
  "in_reply_to_user_id" : 351049850,
  "text" : "@NomiHarris It\u2019s just a very sad experience, especially if you compare prices along with the quality \uD83D\uDE09",
  "id" : 930158868096622592,
  "in_reply_to_status_id" : 930156505445285888,
  "created_at" : "2017-11-13 19:42:10 +0000",
  "in_reply_to_screen_name" : "NomiHarris",
  "in_reply_to_user_id_str" : "351049850",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930136355610513408",
  "geo" : { },
  "id_str" : "930136778647859200",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen the good old catch-all :D",
  "id" : 930136778647859200,
  "in_reply_to_status_id" : 930136355610513408,
  "created_at" : "2017-11-13 18:14:23 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 164, 175 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930121883416084480",
  "text" : "Anyone having experience w\/ the latest MacBook Pro\u2019s randomly restarting over night on High Sierra? Log file says \u201Ckernel: (AppleSMC) Previous shutdown cause: 3\u201D \/ @plaetzchen?",
  "id" : 930121883416084480,
  "created_at" : "2017-11-13 17:15:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 25, 33 ]
    }, {
      "text" : "opencon",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 135, 158 ],
      "url" : "https:\/\/t.co\/Am3PejtA0e",
      "expanded_url" : "http:\/\/slackin.openhumans.org\/",
      "display_url" : "slackin.openhumans.org"
    } ]
  },
  "geo" : { },
  "id_str" : "930113854490550272",
  "text" : "All set for a day of the #opencon do-a-thon. Want to chat to me about Open Humans or contribute? Join #opencon-doathon in our Slack at https:\/\/t.co\/Am3PejtA0e",
  "id" : 930113854490550272,
  "created_at" : "2017-11-13 16:43:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "930103552059559937",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86242564212332, -122.278678184489 ]
  },
  "id_str" : "930104428572504064",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim During the four years it took me to finish my undergrad program there I had five bikes stolen. \uD83D\uDE02",
  "id" : 930104428572504064,
  "in_reply_to_status_id" : 930103552059559937,
  "created_at" : "2017-11-13 16:05:50 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 152, 175 ],
      "url" : "https:\/\/t.co\/KI7OSkekwg",
      "expanded_url" : "http:\/\/www.stadt-muenster.de\/english\/transport\/bicycles.html",
      "display_url" : "stadt-muenster.de\/english\/transp\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86329588102376, -122.2724720172905 ]
  },
  "id_str" : "930100907592712192",
  "text" : "Everyone is warning me about bike theft in Berkeley and all I can think is \u201CFolks, I was born and raised in M\u00FCnster\u201D, Germany\u2019s bike theft capital. \uD83D\uDE02 \uD83D\uDEB2 https:\/\/t.co\/KI7OSkekwg",
  "id" : 930100907592712192,
  "created_at" : "2017-11-13 15:51:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/fGNlBYT1lF",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbbPM2MFrjZ\/",
      "display_url" : "instagram.com\/p\/BbbPM2MFrjZ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8718, -122.275 ]
  },
  "id_str" : "929961100602359808",
  "text" : "I heard you like buses\u2026 \uD83D\uDE8C \uD83D\uDE8D @ Berkeley, California https:\/\/t.co\/fGNlBYT1lF",
  "id" : 929961100602359808,
  "created_at" : "2017-11-13 06:36:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/Bkbdn9zTbZ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbbN_WTFmBM\/",
      "display_url" : "instagram.com\/p\/BbbN_WTFmBM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "929958427987791873",
  "text" : "The Volkswagen equivalent of a ghost bike? https:\/\/t.co\/Bkbdn9zTbZ",
  "id" : 929958427987791873,
  "created_at" : "2017-11-13 06:25:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.863207086956, -122.2728846130169 ]
  },
  "id_str" : "929954725214035968",
  "text" : "I must have been the last person on this planet to finally see Blade Runner 2049 today. It\u2019s good enough to not make me regret my tattoo. \uD83D\uDC4D",
  "id" : 929954725214035968,
  "created_at" : "2017-11-13 06:10:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 0, 11 ],
      "id_str" : "351049850",
      "id" : 351049850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929918754158288897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.863207086956, -122.2728846130169 ]
  },
  "id_str" : "929954359072366593",
  "in_reply_to_user_id" : 351049850,
  "text" : "@NomiHarris I\u2019ll check that out! :)",
  "id" : 929954359072366593,
  "in_reply_to_status_id" : 929918754158288897,
  "created_at" : "2017-11-13 06:09:31 +0000",
  "in_reply_to_screen_name" : "NomiHarris",
  "in_reply_to_user_id_str" : "351049850",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 166, 189 ],
      "url" : "https:\/\/t.co\/macEy0s8Cj",
      "expanded_url" : "http:\/\/imgur.com\/gallery\/FL01Uv3",
      "display_url" : "imgur.com\/gallery\/FL01Uv3"
    } ]
  },
  "geo" : { },
  "id_str" : "929890886783082496",
  "text" : "Thermostat isn\u2019t working. Landlord\u2019s advice is to \u201Cjust (dis)connect the red &amp; white wires\u201D.  Turning the heater on\/off now totally feels like defusing a bomb. \uD83D\uDE02 https:\/\/t.co\/macEy0s8Cj",
  "id" : 929890886783082496,
  "created_at" : "2017-11-13 01:57:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929857221063823360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86327196288655, -122.2726007179565 ]
  },
  "id_str" : "929877337830670337",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Already figured out that the Manchego and Feta here are indistinguishable from each other. Which tells you all you need to know. \uD83D\uDE02",
  "id" : 929877337830670337,
  "in_reply_to_status_id" : 929857221063823360,
  "created_at" : "2017-11-13 01:03:28 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/Vr23aHFXt5",
      "expanded_url" : "https:\/\/media.tenor.com\/images\/eedce82f1d971ccc2078a816deebbf00\/tenor.gif",
      "display_url" : "media.tenor.com\/images\/eedce82\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "929856245267230720",
  "text" : "American bread\u2026 https:\/\/t.co\/Vr23aHFXt5",
  "id" : 929856245267230720,
  "created_at" : "2017-11-12 23:39:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929605703819390976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86331643441037, -122.2725385231069 ]
  },
  "id_str" : "929760005179371520",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD ? \uD83D\uDE09",
  "id" : 929760005179371520,
  "in_reply_to_status_id" : 929605703819390976,
  "created_at" : "2017-11-12 17:17:13 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget Kromhout",
      "screen_name" : "bridgetkromhout",
      "indices" : [ 3, 19 ],
      "id_str" : "1465659204",
      "id" : 1465659204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929583995095937024",
  "text" : "RT @bridgetkromhout: Blind review of conference submissions isn't gonna magically create diversity in a given event's lineup, ffs: a rant h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ELrgveEicA",
        "expanded_url" : "http:\/\/bridgetkromhout.com\/blog\/2017\/06\/04\/in-the-kingdom-of-the-blind\/",
        "display_url" : "bridgetkromhout.com\/blog\/2017\/06\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "871411717972086784",
    "text" : "Blind review of conference submissions isn't gonna magically create diversity in a given event's lineup, ffs: a rant https:\/\/t.co\/ELrgveEicA",
    "id" : 871411717972086784,
    "created_at" : "2017-06-04 17:01:58 +0000",
    "user" : {
      "name" : "Bridget Kromhout",
      "screen_name" : "bridgetkromhout",
      "protected" : false,
      "id_str" : "1465659204",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469973128840368128\/Eud_QsXs_normal.png",
      "id" : 1465659204,
      "verified" : true
    }
  },
  "id" : 929583995095937024,
  "created_at" : "2017-11-12 05:37:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget Kromhout",
      "screen_name" : "bridgetkromhout",
      "indices" : [ 3, 19 ],
      "id_str" : "1465659204",
      "id" : 1465659204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/n22HfsfTpy",
      "expanded_url" : "https:\/\/twitter.com\/bridgetkromhout\/status\/871411717972086784",
      "display_url" : "twitter.com\/bridgetkromhou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "929583982324281344",
  "text" : "RT @bridgetkromhout: \"Well, nobody except men applied to speak.\" There's a reason for that.\uD83D\uDE44 https:\/\/t.co\/n22HfsfTpy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/n22HfsfTpy",
        "expanded_url" : "https:\/\/twitter.com\/bridgetkromhout\/status\/871411717972086784",
        "display_url" : "twitter.com\/bridgetkromhou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "929389418745655296",
    "text" : "\"Well, nobody except men applied to speak.\" There's a reason for that.\uD83D\uDE44 https:\/\/t.co\/n22HfsfTpy",
    "id" : 929389418745655296,
    "created_at" : "2017-11-11 16:44:39 +0000",
    "user" : {
      "name" : "Bridget Kromhout",
      "screen_name" : "bridgetkromhout",
      "protected" : false,
      "id_str" : "1465659204",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469973128840368128\/Eud_QsXs_normal.png",
      "id" : 1465659204,
      "verified" : true
    }
  },
  "id" : 929583982324281344,
  "created_at" : "2017-11-12 05:37:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929556268083175425",
  "text" : "First \u05E9\u05E7\u05E9\u05D5\u05E7\u05D4 in the new apartment: Cooked! \uD83E\uDD58\uD83D\uDE0D",
  "id" : 929556268083175425,
  "created_at" : "2017-11-12 03:47:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HC Institute",
      "screen_name" : "hcinst",
      "indices" : [ 3, 10 ],
      "id_str" : "2864356347",
      "id" : 2864356347
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 28, 36 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Shuttleworth",
      "screen_name" : "ShuttleworthFdn",
      "indices" : [ 45, 61 ],
      "id_str" : "2665573442",
      "id" : 2665573442
    }, {
      "name" : "EyesOnALZ",
      "screen_name" : "eyesonalz",
      "indices" : [ 107, 117 ],
      "id_str" : "4294598053",
      "id" : 4294598053
    }, {
      "name" : "Crowd2Map Tanzania",
      "screen_name" : "Crowd2Map",
      "indices" : [ 122, 132 ],
      "id_str" : "700423408820031488",
      "id" : 700423408820031488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929545030456320000",
  "text" : "RT @hcinst: Big congrats to @Seplute for her @ShuttleworthFdn flash grant, who is indeed making waves with @EyesOnALZ and @Crowd2Map! Honor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Egle Ramanauskaite \u2623",
        "screen_name" : "Seplute",
        "indices" : [ 16, 24 ],
        "id_str" : "188833865",
        "id" : 188833865
      }, {
        "name" : "Shuttleworth",
        "screen_name" : "ShuttleworthFdn",
        "indices" : [ 33, 49 ],
        "id_str" : "2665573442",
        "id" : 2665573442
      }, {
        "name" : "EyesOnALZ",
        "screen_name" : "eyesonalz",
        "indices" : [ 95, 105 ],
        "id_str" : "4294598053",
        "id" : 4294598053
      }, {
        "name" : "Crowd2Map Tanzania",
        "screen_name" : "Crowd2Map",
        "indices" : [ 110, 120 ],
        "id_str" : "700423408820031488",
        "id" : 700423408820031488
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "citizenscience",
        "indices" : [ 193, 208 ]
      }, {
        "text" : "crowdsourcing",
        "indices" : [ 209, 223 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "929448915027595264",
    "text" : "Big congrats to @Seplute for her @ShuttleworthFdn flash grant, who is indeed making waves with @EyesOnALZ and @Crowd2Map! Honored to have such a powerful agent of social change on our faculty. #citizenscience #crowdsourcing",
    "id" : 929448915027595264,
    "created_at" : "2017-11-11 20:41:04 +0000",
    "user" : {
      "name" : "HC Institute",
      "screen_name" : "hcinst",
      "protected" : false,
      "id_str" : "2864356347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555465985134587904\/okLUrNbw_normal.png",
      "id" : 2864356347,
      "verified" : false
    }
  },
  "id" : 929545030456320000,
  "created_at" : "2017-11-12 03:03:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/EKLRhK2trg",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbYFQW-Felc\/",
      "display_url" : "instagram.com\/p\/BbYFQW-Felc\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.831388888889, -122.28527777778 ]
  },
  "id_str" : "929517016095924224",
  "text" : "Straight ahead @ Emeryville, California https:\/\/t.co\/EKLRhK2trg",
  "id" : 929517016095924224,
  "created_at" : "2017-11-12 01:11:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vin\u24EAdh Ilang\u24EAvan",
      "screen_name" : "InquisitiveVi",
      "indices" : [ 0, 14 ],
      "id_str" : "3443391621",
      "id" : 3443391621
    }, {
      "name" : "Lia Hern\u00E1ndez P\u00E9rez",
      "screen_name" : "liaphernandezp",
      "indices" : [ 15, 30 ],
      "id_str" : "339493990",
      "id" : 339493990
    }, {
      "name" : "IPANDETEC",
      "screen_name" : "ipandetec",
      "indices" : [ 31, 41 ],
      "id_str" : "488233616",
      "id" : 488233616
    }, {
      "name" : "senik",
      "screen_name" : "senik",
      "indices" : [ 42, 48 ],
      "id_str" : "18075841",
      "id" : 18075841
    }, {
      "name" : "nissou nour",
      "screen_name" : "NourAn",
      "indices" : [ 49, 56 ],
      "id_str" : "884902266",
      "id" : 884902266
    }, {
      "name" : "Laurent G\u24D0tt\u24EA",
      "screen_name" : "lgatt0",
      "indices" : [ 57, 64 ],
      "id_str" : "188423774",
      "id" : 188423774
    }, {
      "name" : "Rafael Goldzweig",
      "screen_name" : "schmuziger",
      "indices" : [ 65, 76 ],
      "id_str" : "37110556",
      "id" : 37110556
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 222, 230 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929311644756467712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86327209153664, -122.2725681625613 ]
  },
  "id_str" : "929363620416208897",
  "in_reply_to_user_id" : 3443391621,
  "text" : "@InquisitiveVi @liaphernandezp @ipandetec @senik @NourAn @lgatt0 @schmuziger Oooh, I loved the story circle last year. Such a great way to make friends and hear moving stories! Now my fear of missing out is even bigger! \uD83D\uDE0D #opencon",
  "id" : 929363620416208897,
  "in_reply_to_status_id" : 929311644756467712,
  "created_at" : "2017-11-11 15:02:08 +0000",
  "in_reply_to_screen_name" : "InquisitiveVi",
  "in_reply_to_user_id_str" : "3443391621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vin\u24EAdh Ilang\u24EAvan",
      "screen_name" : "InquisitiveVi",
      "indices" : [ 3, 17 ],
      "id_str" : "3443391621",
      "id" : 3443391621
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 71, 87 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Lia Hern\u00E1ndez P\u00E9rez",
      "screen_name" : "liaphernandezp",
      "indices" : [ 115, 130 ],
      "id_str" : "339493990",
      "id" : 339493990
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929363167334903808",
  "text" : "RT @InquisitiveVi: Our table for #OpenCon story session is named after @gedankenstuecke. We had great stories from @liaphernandezp of @ipan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 52, 68 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Lia Hern\u00E1ndez P\u00E9rez",
        "screen_name" : "liaphernandezp",
        "indices" : [ 96, 111 ],
        "id_str" : "339493990",
        "id" : 339493990
      }, {
        "name" : "IPANDETEC",
        "screen_name" : "ipandetec",
        "indices" : [ 115, 125 ],
        "id_str" : "488233616",
        "id" : 488233616
      }, {
        "name" : "senik",
        "screen_name" : "senik",
        "indices" : [ 126, 132 ],
        "id_str" : "18075841",
        "id" : 18075841
      }, {
        "name" : "nissou nour",
        "screen_name" : "NourAn",
        "indices" : [ 133, 140 ],
        "id_str" : "884902266",
        "id" : 884902266
      }, {
        "name" : "Laurent G\u24D0tt\u24EA",
        "screen_name" : "lgatt0",
        "indices" : [ 146, 153 ],
        "id_str" : "188423774",
        "id" : 188423774
      }, {
        "name" : "Rafael Goldzweig",
        "screen_name" : "schmuziger",
        "indices" : [ 154, 165 ],
        "id_str" : "37110556",
        "id" : 37110556
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/InquisitiveVi\/status\/929311644756467712\/photo\/1",
        "indices" : [ 166, 189 ],
        "url" : "https:\/\/t.co\/5rtuK7AyCQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DOWT_tcXkAAF9Dp.jpg",
        "id_str" : "929311620861497344",
        "id" : 929311620861497344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOWT_tcXkAAF9Dp.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        } ],
        "display_url" : "pic.twitter.com\/5rtuK7AyCQ"
      } ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 14, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "929311644756467712",
    "text" : "Our table for #OpenCon story session is named after @gedankenstuecke. We had great stories from @liaphernandezp of @ipandetec @senik @nouran rezk @lgatt0 @schmuziger https:\/\/t.co\/5rtuK7AyCQ",
    "id" : 929311644756467712,
    "created_at" : "2017-11-11 11:35:36 +0000",
    "user" : {
      "name" : "Vin\u24EAdh Ilang\u24EAvan",
      "screen_name" : "InquisitiveVi",
      "protected" : false,
      "id_str" : "3443391621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758995054488793088\/YJ7FDn8j_normal.jpg",
      "id" : 3443391621,
      "verified" : false
    }
  },
  "id" : 929363167334903808,
  "created_at" : "2017-11-11 15:00:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 0, 7 ],
      "id_str" : "9723702",
      "id" : 9723702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929241070700871680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86320911008146, -122.273030234059 ]
  },
  "id_str" : "929242870107611136",
  "in_reply_to_user_id" : 9723702,
  "text" : "@ansate Absolutely, that feels so good \uD83D\uDE0D",
  "id" : 929242870107611136,
  "in_reply_to_status_id" : 929241070700871680,
  "created_at" : "2017-11-11 07:02:19 +0000",
  "in_reply_to_screen_name" : "ansate",
  "in_reply_to_user_id_str" : "9723702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929240162902487040",
  "text" : "Truly arrived in the new apartment: We got Wifi now! \uD83C\uDF89\uD83C\uDF8A\uD83C\uDF88",
  "id" : 929240162902487040,
  "created_at" : "2017-11-11 06:51:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929152989432045568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86327613283297, -122.2727006816479 ]
  },
  "id_str" : "929220436998496257",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Don\u2019t get me started on these labels or I\u2019ll ask you for a cigarette!",
  "id" : 929220436998496257,
  "in_reply_to_status_id" : 929152989432045568,
  "created_at" : "2017-11-11 05:33:10 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/35PEtaWYPd",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbV9ZByFqw0\/",
      "display_url" : "instagram.com\/p\/BbV9ZByFqw0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8569, -122.299 ]
  },
  "id_str" : "929218248427655170",
  "text" : "Should have read the plaque @ Aquatic Park https:\/\/t.co\/35PEtaWYPd",
  "id" : 929218248427655170,
  "created_at" : "2017-11-11 05:24:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/929152433292328960\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/h0eSJ9DQhi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DOUDNSZUIAAGknx.jpg",
      "id_str" : "929152424933072896",
      "id" : 929152424933072896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOUDNSZUIAAGknx.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/h0eSJ9DQhi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929151667274166272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86327958990689, -122.2727587321906 ]
  },
  "id_str" : "929152433292328960",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab You would for this one. As it\u2019s ridiculously clipped in and that\u2019s all it is. https:\/\/t.co\/h0eSJ9DQhi",
  "id" : 929152433292328960,
  "in_reply_to_status_id" : 929151667274166272,
  "created_at" : "2017-11-11 01:02:57 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/929150544391782400\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ZpmISYG97O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DOUBfS2VAAAyM-5.jpg",
      "id_str" : "929150535269154816",
      "id" : 929150535269154816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOUBfS2VAAAyM-5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZpmISYG97O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86324452799413, -122.272583477404 ]
  },
  "id_str" : "929150544391782400",
  "text" : "Because this thing totally lacked a big useless plastic background \u201Cpackaging\u201D\u2026 https:\/\/t.co\/ZpmISYG97O",
  "id" : 929150544391782400,
  "created_at" : "2017-11-11 00:55:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/biFoW7VD9c",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/VbQfgkDtYUin6\/200.gif",
      "display_url" : "media.giphy.com\/media\/VbQfgkDt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "929121509188104192",
  "text" : "\u00ABYour new name totally sounds like The Princess Bride.\u00BB \u2013 \u00ABMy name is Bastian Greshake Tzovaras. You killed Open Science. Prepare to die.\u00BB https:\/\/t.co\/biFoW7VD9c",
  "id" : 929121509188104192,
  "created_at" : "2017-11-10 23:00:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "indices" : [ 0, 9 ],
      "id_str" : "1096058449",
      "id" : 1096058449
    }, {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 24, 30 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929054336692371457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86326860168461, -122.2726401621955 ]
  },
  "id_str" : "929054941250850816",
  "in_reply_to_user_id" : 1096058449,
  "text" : "@itatiVCS Another thing @aath0 brought up: how much water is wasted with each shower?",
  "id" : 929054941250850816,
  "in_reply_to_status_id" : 929054336692371457,
  "created_at" : "2017-11-10 18:35:33 +0000",
  "in_reply_to_screen_name" : "itatiVCS",
  "in_reply_to_user_id_str" : "1096058449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "showerthoughts",
      "indices" : [ 8, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86318199758085, -122.2727163522065 ]
  },
  "id_str" : "929053487060566016",
  "text" : "Literal #showerthoughts: How many million dollars are lost in productivity each year due to US showers being fixed to the wall, resulting in each shower taking much more time?",
  "id" : 929053487060566016,
  "created_at" : "2017-11-10 18:29:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nokome Bentley",
      "screen_name" : "NokomeBentley",
      "indices" : [ 0, 14 ],
      "id_str" : "1576006626",
      "id" : 1576006626
    }, {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 15, 31 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 32, 41 ],
      "id_str" : "594278352",
      "id" : 594278352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929014820938047488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8632877055577, -122.2726355132848 ]
  },
  "id_str" : "929016837940977664",
  "in_reply_to_user_id" : 1576006626,
  "text" : "@NokomeBentley @daniellecrobins @stencila Great, looking forward to meet again! :)",
  "id" : 929016837940977664,
  "in_reply_to_status_id" : 929014820938047488,
  "created_at" : "2017-11-10 16:04:09 +0000",
  "in_reply_to_screen_name" : "NokomeBentley",
  "in_reply_to_user_id_str" : "1576006626",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9l\u00E9onore Mayola",
      "screen_name" : "EleonoreMayola",
      "indices" : [ 3, 18 ],
      "id_str" : "502916683",
      "id" : 502916683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/gtLjD2Nd28",
      "expanded_url" : "https:\/\/twitter.com\/pollyn1\/status\/928711154255519744",
      "display_url" : "twitter.com\/pollyn1\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "929016505768873989",
  "text" : "RT @EleonoreMayola: \"In parts of London, as many as one in 25 people are recorded as homeless.\" https:\/\/t.co\/gtLjD2Nd28",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/gtLjD2Nd28",
        "expanded_url" : "https:\/\/twitter.com\/pollyn1\/status\/928711154255519744",
        "display_url" : "twitter.com\/pollyn1\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "928948334550814720",
    "text" : "\"In parts of London, as many as one in 25 people are recorded as homeless.\" https:\/\/t.co\/gtLjD2Nd28",
    "id" : 928948334550814720,
    "created_at" : "2017-11-10 11:31:56 +0000",
    "user" : {
      "name" : "\u00C9l\u00E9onore Mayola",
      "screen_name" : "EleonoreMayola",
      "protected" : false,
      "id_str" : "502916683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891792711124213760\/o1fUkVXB_normal.jpg",
      "id" : 502916683,
      "verified" : false
    }
  },
  "id" : 929016505768873989,
  "created_at" : "2017-11-10 16:02:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 13, 26 ],
      "id_str" : "478181304",
      "id" : 478181304
    }, {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 27, 36 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928544090408603648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86329871240122, -122.2726502170343 ]
  },
  "id_str" : "929005687526400002",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @Mcarthur_Joe @nshockey Still learning the ropes of the new bag pack? \uD83D\uDE02",
  "id" : 929005687526400002,
  "in_reply_to_status_id" : 928544090408603648,
  "created_at" : "2017-11-10 15:19:50 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    }, {
      "name" : "Stencila",
      "screen_name" : "stencila",
      "indices" : [ 17, 26 ],
      "id_str" : "594278352",
      "id" : 594278352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928941787443597313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86332009771698, -122.2726038269608 ]
  },
  "id_str" : "929004570671378432",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins @stencila Meeting for lunch I guess? \uD83D\uDE09",
  "id" : 929004570671378432,
  "in_reply_to_status_id" : 928941787443597313,
  "created_at" : "2017-11-10 15:15:24 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86329893058051, -122.2726656682379 ]
  },
  "id_str" : "928984539665350656",
  "text" : "Twitter\u2019s new character limit for the display name mean I can finally use my real name. \uD83D\uDC4D",
  "id" : 928984539665350656,
  "created_at" : "2017-11-10 13:55:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/3CSs6GkaIv",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbUP6t8FrFX\/",
      "display_url" : "instagram.com\/p\/BbUP6t8FrFX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "928977509038768129",
  "text" : "Well aged https:\/\/t.co\/3CSs6GkaIv",
  "id" : 928977509038768129,
  "created_at" : "2017-11-10 13:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928785514961944576",
  "text" : "Mongolian cab driver recognized my first name as being German and gave me a long lecture about different soccer clubs that I\u2019ve never heard about in my life. \uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 928785514961944576,
  "created_at" : "2017-11-10 00:44:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 7, 13 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928674921080745984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86330414452554, -122.2726071824599 ]
  },
  "id_str" : "928676675562459136",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw @aath0 It has a rich travel history: LHR \u2708\uFE0F FRA \uD83D\uDE97 ZRH \uD83D\uDE97 FRA \u2708\uFE0F SFO. And it still looks great, kudos to your craft! \uD83D\uDE0D",
  "id" : 928676675562459136,
  "in_reply_to_status_id" : 928674921080745984,
  "created_at" : "2017-11-09 17:32:28 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 39, 45 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 113, 119 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/928673020100485120\/photo\/1",
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/JTjJs6mEeo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DONPLw6VQAApUI1.jpg",
      "id_str" : "928673011695173632",
      "id" : 928673011695173632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DONPLw6VQAApUI1.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/JTjJs6mEeo"
    } ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86340297915273, -122.2727206414596 ]
  },
  "id_str" : "928673020100485120",
  "text" : "I hadn\u2019t known that the brain hat that @shefw made at #MozFest 2016 made the move as well. Thanks for packing it @aath0! \uD83D\uDE0D https:\/\/t.co\/JTjJs6mEeo",
  "id" : 928673020100485120,
  "created_at" : "2017-11-09 17:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/S0a7UH2aJx",
      "expanded_url" : "https:\/\/twitter.com\/godtributes\/status\/928515690667048960",
      "display_url" : "twitter.com\/godtributes\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86327446309744, -122.2727637856238 ]
  },
  "id_str" : "928515985920815104",
  "text" : "Word! \uD83D\uDE02 https:\/\/t.co\/S0a7UH2aJx",
  "id" : 928515985920815104,
  "created_at" : "2017-11-09 06:53:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 87, 98 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/928515643053191168\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/yjYaI2xJrM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DOLADkxUQAEpFQ-.jpg",
      "id_str" : "928515640834408449",
      "id" : 928515640834408449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DOLADkxUQAEpFQ-.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/yjYaI2xJrM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928515643053191168",
  "text" : "I couldn\u2019t leave IKEA without getting the pillow cases that\u2019ll constantly remind me of @LouWoodley \uD83D\uDE0D\uD83D\uDC3F https:\/\/t.co\/yjYaI2xJrM",
  "id" : 928515643053191168,
  "created_at" : "2017-11-09 06:52:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86519453101884, -122.2674251984971 ]
  },
  "id_str" : "928489492977090560",
  "text" : "We have moved! Everything somehow fit into the new apartment. \uD83C\uDF89 Now we only need to unpack everything. And find out where to store all the suitcases. \uD83D\uDE02",
  "id" : 928489492977090560,
  "created_at" : "2017-11-09 05:08:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Luschek",
      "screen_name" : "KathleenLuschek",
      "indices" : [ 0, 16 ],
      "id_str" : "1898653928",
      "id" : 1898653928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928417878952501248",
  "geo" : { },
  "id_str" : "928418363042177024",
  "in_reply_to_user_id" : 1898653928,
  "text" : "@KathleenLuschek In for a penny, in for a pound. Which \u2013 thanks to Brexit \u2013 is now worth less than a \u20AC. \uD83D\uDE02",
  "id" : 928418363042177024,
  "in_reply_to_status_id" : 928417878952501248,
  "created_at" : "2017-11-09 00:26:01 +0000",
  "in_reply_to_screen_name" : "KathleenLuschek",
  "in_reply_to_user_id_str" : "1898653928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Luschek",
      "screen_name" : "KathleenLuschek",
      "indices" : [ 0, 16 ],
      "id_str" : "1898653928",
      "id" : 1898653928
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/928417315506372608\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/kuADoQjcU2",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DOJmfb6VwAAyDUw.jpg",
      "id_str" : "928417163446173696",
      "id" : 928417163446173696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DOJmfb6VwAAyDUw.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/kuADoQjcU2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928416283657347073",
  "geo" : { },
  "id_str" : "928417315506372608",
  "in_reply_to_user_id" : 1898653928,
  "text" : "@KathleenLuschek It seems Europe is on the way of ending in a similar situation, so why not taking the shortcut! https:\/\/t.co\/kuADoQjcU2",
  "id" : 928417315506372608,
  "in_reply_to_status_id" : 928416283657347073,
  "created_at" : "2017-11-09 00:21:51 +0000",
  "in_reply_to_screen_name" : "KathleenLuschek",
  "in_reply_to_user_id_str" : "1898653928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Luschek",
      "screen_name" : "KathleenLuschek",
      "indices" : [ 0, 16 ],
      "id_str" : "1898653928",
      "id" : 1898653928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928415046102695936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85149630086881, -122.2944612685005 ]
  },
  "id_str" : "928416054480535552",
  "in_reply_to_user_id" : 1898653928,
  "text" : "@KathleenLuschek also: guess who moved significantly closer to Hawaii! \uD83D\uDE09",
  "id" : 928416054480535552,
  "in_reply_to_status_id" : 928415046102695936,
  "created_at" : "2017-11-09 00:16:51 +0000",
  "in_reply_to_screen_name" : "KathleenLuschek",
  "in_reply_to_user_id_str" : "1898653928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yacine Baroudi",
      "screen_name" : "YacineBaroudi",
      "indices" : [ 0, 14 ],
      "id_str" : "18919233",
      "id" : 18919233
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 15, 26 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Mehdi El Baroudi",
      "screen_name" : "melbaroudi",
      "indices" : [ 27, 38 ],
      "id_str" : "19536218",
      "id" : 19536218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928397475576033280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85145189342024, -122.2944822882769 ]
  },
  "id_str" : "928397612226560000",
  "in_reply_to_user_id" : 18919233,
  "text" : "@YacineBaroudi @openSNPorg @melbaroudi thanks!",
  "id" : 928397612226560000,
  "in_reply_to_status_id" : 928397475576033280,
  "created_at" : "2017-11-08 23:03:34 +0000",
  "in_reply_to_screen_name" : "YacineBaroudi",
  "in_reply_to_user_id_str" : "18919233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dixie",
      "screen_name" : "timiat",
      "indices" : [ 0, 7 ],
      "id_str" : "10388582",
      "id" : 10388582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928342595268431872",
  "geo" : { },
  "id_str" : "928397273129656320",
  "in_reply_to_user_id" : 10388582,
  "text" : "@timiat Can I request a step-by-step guide for that? \uD83D\uDE02",
  "id" : 928397273129656320,
  "in_reply_to_status_id" : 928342595268431872,
  "created_at" : "2017-11-08 23:02:13 +0000",
  "in_reply_to_screen_name" : "timiat",
  "in_reply_to_user_id_str" : "10388582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/BeOL6M3jM6",
      "expanded_url" : "https:\/\/github.com\/sparcopen\/doathon\/issues\/28",
      "display_url" : "github.com\/sparcopen\/doat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "928397095865692166",
  "text" : "As sad as I am of physically missing #opencon this year: At least Open Humans will remotely participate in the Do-A-Thon! \uD83C\uDF89 https:\/\/t.co\/BeOL6M3jM6",
  "id" : 928397095865692166,
  "created_at" : "2017-11-08 23:01:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928278602822639618",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85504138940989, -122.2750086908051 ]
  },
  "id_str" : "928279160073490432",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps At IKEA that didn\u2019t happen to us, as we hadn\u2019t kept track of the sum in our shopping carts in any case. :p",
  "id" : 928279160073490432,
  "in_reply_to_status_id" : 928278602822639618,
  "created_at" : "2017-11-08 15:12:53 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "928267258224369666",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85504138940989, -122.2750086908051 ]
  },
  "id_str" : "928278352498003969",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps Haha, yes! That\u2019s already bitten us! \uD83D\uDE02",
  "id" : 928278352498003969,
  "in_reply_to_status_id" : 928267258224369666,
  "created_at" : "2017-11-08 15:09:40 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928077824862203905",
  "text" : "Shopping at IKEA. Total sum is bigger than flying us and all of our stuff from FRA to SFO. \uD83E\uDD14 \uD83E\uDD37\u200D\u2640\uFE0F",
  "id" : 928077824862203905,
  "created_at" : "2017-11-08 01:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927979690475876353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.87203528456192, -122.2684215010351 ]
  },
  "id_str" : "927980742109310976",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo I gained some pounds while writing up my PhD, it\u2019s not what you\u2019re thinking \uD83D\uDE07",
  "id" : 927980742109310976,
  "in_reply_to_status_id" : 927979690475876353,
  "created_at" : "2017-11-07 19:27:04 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927941668455796736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.87170638586749, -122.2706191727445 ]
  },
  "id_str" : "927977806339784704",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo happens to me all the time \uD83D\uDE09\uD83D\uDE02",
  "id" : 927977806339784704,
  "in_reply_to_status_id" : 927941668455796736,
  "created_at" : "2017-11-07 19:15:24 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.87177167694177, -122.2705354515356 ]
  },
  "id_str" : "927961954337013760",
  "text" : "A clear sign that you\u2019re in the US: Your lab safety training videos include information on how to deal with active shooters\u2026 \uD83D\uDE12",
  "id" : 927961954337013760,
  "created_at" : "2017-11-07 18:12:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 14, 20 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    }, {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 29, 38 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927934052350472193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86560505698049, -122.272123845906 ]
  },
  "id_str" : "927934342021636098",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics @aath0 Only if @nshockey pays for the flights \uD83D\uDE09",
  "id" : 927934342021636098,
  "in_reply_to_status_id" : 927934052350472193,
  "created_at" : "2017-11-07 16:22:41 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927756955245985792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85488997355458, -122.2748826684866 ]
  },
  "id_str" : "927770550092554240",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto We only have some suitcases of stuff in any case. But will have to head to IKEA to get towels, cutlery etc. :)",
  "id" : 927770550092554240,
  "in_reply_to_status_id" : 927756955245985792,
  "created_at" : "2017-11-07 05:31:50 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927753684427071488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85503935523792, -122.2750869616401 ]
  },
  "id_str" : "927755673839869952",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto Now we only have to move in! \uD83D\uDE0D\uD83D\uDE0E",
  "id" : 927755673839869952,
  "in_reply_to_status_id" : 927753684427071488,
  "created_at" : "2017-11-07 04:32:44 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.87166425499527, -122.2730064341166 ]
  },
  "id_str" : "927729347397431296",
  "text" : "Guess who has an apartment now? \uD83C\uDF89",
  "id" : 927729347397431296,
  "created_at" : "2017-11-07 02:48:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mouse Reeve",
      "screen_name" : "tripofmice",
      "indices" : [ 0, 11 ],
      "id_str" : "1304991110",
      "id" : 1304991110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927700301892562944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.87200150549214, -122.2646963318086 ]
  },
  "id_str" : "927702813773242368",
  "in_reply_to_user_id" : 1304991110,
  "text" : "@tripofmice And when was that ever a good idea? \uD83D\uDE02",
  "id" : 927702813773242368,
  "in_reply_to_status_id" : 927700301892562944,
  "created_at" : "2017-11-07 01:02:41 +0000",
  "in_reply_to_screen_name" : "tripofmice",
  "in_reply_to_user_id_str" : "1304991110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 3, 10 ],
      "id_str" : "99586343",
      "id" : 99586343
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lu_cyP\/status\/923444083464462336\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/8BMUeYvn4e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DM_gmdMW4AAxxDA.jpg",
      "id_str" : "923203399910350848",
      "id" : 923203399910350848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DM_gmdMW4AAxxDA.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/8BMUeYvn4e"
    } ],
    "hashtags" : [ {
      "text" : "FORCE2017",
      "indices" : [ 26, 36 ]
    }, {
      "text" : "openscience",
      "indices" : [ 59, 71 ]
    }, {
      "text" : "DIYscience",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/lJHa7mFCd7",
      "expanded_url" : "https:\/\/speakerdeck.com\/lu_cyp\/outside-the-academy-diy-science-communities",
      "display_url" : "speakerdeck.com\/lu_cyp\/outside\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "927698504507518976",
  "text" : "RT @lu_cyP: Slides for my #FORCE2017 keynote this morning\u2026\n#openscience #DIYscience\nhttps:\/\/t.co\/lJHa7mFCd7 https:\/\/t.co\/8BMUeYvn4e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lu_cyP\/status\/923444083464462336\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/8BMUeYvn4e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DM_gmdMW4AAxxDA.jpg",
        "id_str" : "923203399910350848",
        "id" : 923203399910350848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DM_gmdMW4AAxxDA.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/8BMUeYvn4e"
      } ],
      "hashtags" : [ {
        "text" : "FORCE2017",
        "indices" : [ 14, 24 ]
      }, {
        "text" : "openscience",
        "indices" : [ 47, 59 ]
      }, {
        "text" : "DIYscience",
        "indices" : [ 60, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/lJHa7mFCd7",
        "expanded_url" : "https:\/\/speakerdeck.com\/lu_cyp\/outside-the-academy-diy-science-communities",
        "display_url" : "speakerdeck.com\/lu_cyp\/outside\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "923444083464462336",
    "text" : "Slides for my #FORCE2017 keynote this morning\u2026\n#openscience #DIYscience\nhttps:\/\/t.co\/lJHa7mFCd7 https:\/\/t.co\/8BMUeYvn4e",
    "id" : 923444083464462336,
    "created_at" : "2017-10-26 07:00:00 +0000",
    "user" : {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "protected" : false,
      "id_str" : "99586343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000178318979\/04210a37d910f734cabe01698bb747f0_normal.jpeg",
      "id" : 99586343,
      "verified" : false
    }
  },
  "id" : 927698504507518976,
  "created_at" : "2017-11-07 00:45:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.87364256370402, -122.2569187563886 ]
  },
  "id_str" : "927698293781495809",
  "text" : "Thanks to my move openSNP can now provide 24h support as we\u2019re now based in UTC-8, UTC+1 &amp; UTC+8. It does screw up team meetings though.",
  "id" : 927698293781495809,
  "created_at" : "2017-11-07 00:44:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mouse Reeve",
      "screen_name" : "tripofmice",
      "indices" : [ 0, 11 ],
      "id_str" : "1304991110",
      "id" : 1304991110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927696626822475777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.87371116358252, -122.2566040666065 ]
  },
  "id_str" : "927697038447280128",
  "in_reply_to_user_id" : 1304991110,
  "text" : "@tripofmice don\u2019t, it\u2019s a trick!",
  "id" : 927697038447280128,
  "in_reply_to_status_id" : 927696626822475777,
  "created_at" : "2017-11-07 00:39:44 +0000",
  "in_reply_to_screen_name" : "tripofmice",
  "in_reply_to_user_id_str" : "1304991110",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/gipVT9mNAA",
      "expanded_url" : "http:\/\/www.languageonthemove.com\/more-on-banal-cosmopolitanism\/",
      "display_url" : "languageonthemove.com\/more-on-banal-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85502423700291, -122.275004294214 ]
  },
  "id_str" : "927381855149613056",
  "text" : "\u00ABthe world of banal cosmopolitanism is not flat [\u2026]. It\u2019s a hierarchy where even being listed can be a privilege.\u00BB https:\/\/t.co\/gipVT9mNAA",
  "id" : 927381855149613056,
  "created_at" : "2017-11-06 03:47:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/j6vzL6zbq2",
      "expanded_url" : "https:\/\/twitter.com\/phylogenomics\/status\/927344891218108416",
      "display_url" : "twitter.com\/phylogenomics\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85504648325523, -122.2750364981992 ]
  },
  "id_str" : "927368084322533381",
  "text" : "Tyson is a terrible hypocrite who preaches reason all day but likes to make up \u2018facts\u2019 whenever he seems fit for his personal narrative \uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/j6vzL6zbq2",
  "id" : 927368084322533381,
  "created_at" : "2017-11-06 02:52:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927311713375985664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85500991679871, -122.2749938205638 ]
  },
  "id_str" : "927318740613586944",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy It\u2019s next to mine too! So I guess we\u2019re Lab neighbors! \uD83D\uDE0A",
  "id" : 927318740613586944,
  "in_reply_to_status_id" : 927311713375985664,
  "created_at" : "2017-11-05 23:36:31 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Rwv4DxoVmX",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbIZEPMlMb6\/",
      "display_url" : "instagram.com\/p\/BbIZEPMlMb6\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86767, -122.3125 ]
  },
  "id_str" : "927308779779248128",
  "text" : "I sense a lack of appropriate emoji! \uD83D\uDD4A @ Berkeley Marina https:\/\/t.co\/Rwv4DxoVmX",
  "id" : 927308779779248128,
  "created_at" : "2017-11-05 22:56:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 0, 11 ],
      "id_str" : "351049850",
      "id" : 351049850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927283999155691520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85503403176622, -122.2748354296641 ]
  },
  "id_str" : "927285073115615232",
  "in_reply_to_user_id" : 351049850,
  "text" : "@NomiHarris We could be lucky today already, if we can figure out how we can actually deposit money from \uD83C\uDDEA\uD83C\uDDFA bank accounts into \uD83C\uDDFA\uD83C\uDDF8 accounts. ;)",
  "id" : 927285073115615232,
  "in_reply_to_status_id" : 927283999155691520,
  "created_at" : "2017-11-05 21:22:44 +0000",
  "in_reply_to_screen_name" : "NomiHarris",
  "in_reply_to_user_id_str" : "351049850",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 0, 11 ],
      "id_str" : "351049850",
      "id" : 351049850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927283527367802880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85503411708481, -122.2748353806676 ]
  },
  "id_str" : "927284916248748032",
  "in_reply_to_user_id" : 351049850,
  "text" : "@NomiHarris Oh, I can imagine. Sorry for that!",
  "id" : 927284916248748032,
  "in_reply_to_status_id" : 927283527367802880,
  "created_at" : "2017-11-05 21:22:06 +0000",
  "in_reply_to_screen_name" : "NomiHarris",
  "in_reply_to_user_id_str" : "351049850",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/pvmgjlV8fE",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbINSTiFerK\/",
      "display_url" : "instagram.com\/p\/BbINSTiFerK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "927282878857338880",
  "text" : "Aquatic Park https:\/\/t.co\/pvmgjlV8fE",
  "id" : 927282878857338880,
  "created_at" : "2017-11-05 21:14:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/GTD3EwgnRu",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbIMOJRlRcG\/",
      "display_url" : "instagram.com\/p\/BbIMOJRlRcG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "927280564695994368",
  "text" : "\uD83D\uDE82 porn https:\/\/t.co\/GTD3EwgnRu",
  "id" : 927280564695994368,
  "created_at" : "2017-11-05 21:04:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/KQnDmL8mof",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbIMG_FFw1G\/",
      "display_url" : "instagram.com\/p\/BbIMG_FFw1G\/"
    } ]
  },
  "geo" : { },
  "id_str" : "927280278246187010",
  "text" : "Urban \uD83C\uDF44s https:\/\/t.co\/KQnDmL8mof",
  "id" : 927280278246187010,
  "created_at" : "2017-11-05 21:03:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/927266678269808643\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/vFKW2QD25E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DN5QIA9VwAADGGn.jpg",
      "id_str" : "927266671911354368",
      "id" : 927266671911354368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DN5QIA9VwAADGGn.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/vFKW2QD25E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86743064414511, -122.2933619377411 ]
  },
  "id_str" : "927266678269808643",
  "text" : "If we ever miss Switzerland we can easily be transformed to a place home. \uD83D\uDE02 https:\/\/t.co\/vFKW2QD25E",
  "id" : 927266678269808643,
  "created_at" : "2017-11-05 20:09:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927217646998827008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85500321540782, -122.2749351618088 ]
  },
  "id_str" : "927221817239990272",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 Time zone differences, always good for a laugh ;)",
  "id" : 927221817239990272,
  "in_reply_to_status_id" : 927217646998827008,
  "created_at" : "2017-11-05 17:11:22 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927217709594566656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85500321540782, -122.2749351618088 ]
  },
  "id_str" : "927221732523380736",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 Yep, no problems there \uD83D\uDE02",
  "id" : 927221732523380736,
  "in_reply_to_status_id" : 927217709594566656,
  "created_at" : "2017-11-05 17:11:02 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "927081384203706368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85508021513902, -122.2749599936847 ]
  },
  "id_str" : "927216787271192576",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 My dad tried calling before 5am, he wanted to see whether WhatsApp calls work with me being in the US.",
  "id" : 927216787271192576,
  "in_reply_to_status_id" : 927081384203706368,
  "created_at" : "2017-11-05 16:51:23 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/927214224467640320\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/iq4Xj1hgE4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DN4gag6VAAATFWe.jpg",
      "id_str" : "927214213168168960",
      "id" : 927214213168168960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DN4gag6VAAATFWe.jpg",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/iq4Xj1hgE4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927214224467640320",
  "text" : "This year I timed my travel, switching from standard time to daylight saving time twice and also switched back twice. https:\/\/t.co\/iq4Xj1hgE4",
  "id" : 927214224467640320,
  "created_at" : "2017-11-05 16:41:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/6TaScX3N9T",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BbGWiqmlJE-\/",
      "display_url" : "instagram.com\/p\/BbGWiqmlJE-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "927021747408273408",
  "text" : "A look into the little free library \uD83D\uDCDA https:\/\/t.co\/6TaScX3N9T",
  "id" : 927021747408273408,
  "created_at" : "2017-11-05 03:56:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinh Tran",
      "screen_name" : "trvinh_",
      "indices" : [ 0, 8 ],
      "id_str" : "888863514491850752",
      "id" : 888863514491850752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926908398435749890",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8548937477524, -122.2749421187884 ]
  },
  "id_str" : "926940532370059264",
  "in_reply_to_user_id" : 888863514491850752,
  "text" : "@trvinh_ That\u2019s how it feels at least!",
  "id" : 926940532370059264,
  "in_reply_to_status_id" : 926908398435749890,
  "created_at" : "2017-11-04 22:33:39 +0000",
  "in_reply_to_screen_name" : "trvinh_",
  "in_reply_to_user_id_str" : "888863514491850752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/926828799987146752\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/NVEnnLO18A",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DNzB4I_UIAAvHOB.jpg",
      "id_str" : "926828793561358336",
      "id" : 926828793561358336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DNzB4I_UIAAvHOB.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/NVEnnLO18A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926828799987146752",
  "text" : "Ready for another day of apartment hunt. https:\/\/t.co\/NVEnnLO18A",
  "id" : 926828799987146752,
  "created_at" : "2017-11-04 15:09:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926724851813048320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8550140244831, -122.2749275834425 ]
  },
  "id_str" : "926824623710208000",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe Thanks! \uD83D\uDE0D",
  "id" : 926824623710208000,
  "in_reply_to_status_id" : 926724851813048320,
  "created_at" : "2017-11-04 14:53:04 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Letisha R. Wyatt",
      "screen_name" : "dr_lrwyatt",
      "indices" : [ 0, 11 ],
      "id_str" : "741336421361844226",
      "id" : 741336421361844226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926691388191682560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8549835520128, -122.2750658189712 ]
  },
  "id_str" : "926694518149210114",
  "in_reply_to_user_id" : 741336421361844226,
  "text" : "@dr_lrwyatt It\u2019s awesome! :)",
  "id" : 926694518149210114,
  "in_reply_to_status_id" : 926691388191682560,
  "created_at" : "2017-11-04 06:16:04 +0000",
  "in_reply_to_screen_name" : "dr_lrwyatt",
  "in_reply_to_user_id_str" : "741336421361844226",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 0, 10 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926658901398896640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85511341598146, -122.2750883181468 ]
  },
  "id_str" : "926689435646812165",
  "in_reply_to_user_id" : 11385492,
  "text" : "@jillemery Best fake meat ever! \uD83D\uDE0D",
  "id" : 926689435646812165,
  "in_reply_to_status_id" : 926658901398896640,
  "created_at" : "2017-11-04 05:55:53 +0000",
  "in_reply_to_screen_name" : "jillemery",
  "in_reply_to_user_id_str" : "11385492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/926656854964371456\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/khLEU4OxyX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNwlfkkVQAA6EG4.jpg",
      "id_str" : "926656847653715968",
      "id" : 926656847653715968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNwlfkkVQAA6EG4.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/khLEU4OxyX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77782511109551, -122.3914728090101 ]
  },
  "id_str" : "926656854964371456",
  "text" : "The true reason for moving here. \uD83D\uDE02 https:\/\/t.co\/khLEU4OxyX",
  "id" : 926656854964371456,
  "created_at" : "2017-11-04 03:46:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naim Matasci",
      "screen_name" : "nmatasci",
      "indices" : [ 0, 9 ],
      "id_str" : "322061462",
      "id" : 322061462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926541123325018112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85152043485936, -122.2945633822932 ]
  },
  "id_str" : "926541452728983552",
  "in_reply_to_user_id" : 322061462,
  "text" : "@nmatasci Thanks! :)",
  "id" : 926541452728983552,
  "in_reply_to_status_id" : 926541123325018112,
  "created_at" : "2017-11-03 20:07:51 +0000",
  "in_reply_to_screen_name" : "nmatasci",
  "in_reply_to_user_id_str" : "322061462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naim Matasci",
      "screen_name" : "nmatasci",
      "indices" : [ 0, 9 ],
      "id_str" : "322061462",
      "id" : 322061462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926539651287990272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85150338814093, -122.2944904077066 ]
  },
  "id_str" : "926540087478722560",
  "in_reply_to_user_id" : 322061462,
  "text" : "@nmatasci largely looking for a place that makes transfers between US &lt;-&gt; EU easy as there\u2019s still stuff back home that needs to be paid for.",
  "id" : 926540087478722560,
  "in_reply_to_status_id" : 926539651287990272,
  "created_at" : "2017-11-03 20:02:25 +0000",
  "in_reply_to_screen_name" : "nmatasci",
  "in_reply_to_user_id_str" : "322061462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8514628483411, -122.2945579957098 ]
  },
  "id_str" : "926533170798903296",
  "text" : "Ok Twitter, what\u2019s the least shitty bank account you can get in the \uD83C\uDDFA\uD83C\uDDF8 if you\u2019re used to the \uD83C\uDDEA\uD83C\uDDFA bank system? \uD83D\uDE02",
  "id" : 926533170798903296,
  "created_at" : "2017-11-03 19:34:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 99, 113 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IoURlBi2xR",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/6-1151\/v2",
      "display_url" : "f1000research.com\/articles\/6-115\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85502017101476, -122.2749160434963 ]
  },
  "id_str" : "926460065242005505",
  "text" : "V2 of our multi-disciplinary perspective on peer review is now on F1000. Thanks to all the work by @Protohedgehog! https:\/\/t.co\/IoURlBi2xR",
  "id" : 926460065242005505,
  "created_at" : "2017-11-03 14:44:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    }, {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 13, 19 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    }, {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 20, 32 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926432088680570882",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8550122284188, -122.2750024462889 ]
  },
  "id_str" : "926447585836986368",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD @aath0 @monimunozto (To be fair, this one was marked as car parking in the listing. It was just put in the wrong category by the submitter)",
  "id" : 926447585836986368,
  "in_reply_to_status_id" : 926432088680570882,
  "created_at" : "2017-11-03 13:54:51 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926386585947463681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8550122284188, -122.2750024462889 ]
  },
  "id_str" : "926447393955921921",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna Thanks!",
  "id" : 926447393955921921,
  "in_reply_to_status_id" : 926386585947463681,
  "created_at" : "2017-11-03 13:54:05 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katy Wong",
      "screen_name" : "katywmw",
      "indices" : [ 0, 8 ],
      "id_str" : "2423319204",
      "id" : 2423319204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926371327014928384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8550122284188, -122.2750024462889 ]
  },
  "id_str" : "926447347210448899",
  "in_reply_to_user_id" : 2423319204,
  "text" : "@katywmw DMs should be Open already :)",
  "id" : 926447347210448899,
  "in_reply_to_status_id" : 926371327014928384,
  "created_at" : "2017-11-03 13:53:54 +0000",
  "in_reply_to_screen_name" : "katywmw",
  "in_reply_to_user_id_str" : "2423319204",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    }, {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 13, 19 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926224779237101568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.83974996272756, -122.2893720528433 ]
  },
  "id_str" : "926225293383290881",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto @aath0 I\u2019ll happily invite you for drinks once we don\u2019t have to worry about being homeless any more. \uD83D\uDE09",
  "id" : 926225293383290881,
  "in_reply_to_status_id" : 926224779237101568,
  "created_at" : "2017-11-02 23:11:33 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    }, {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 62, 68 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926224168324096000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.84455240707643, -122.2934310884422 ]
  },
  "id_str" : "926224507731406848",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto Unfortunately I\u2019ll probably miss drinks tonight. @aath0 was so busy that she got us even two apartment visit dates for this afternoon!",
  "id" : 926224507731406848,
  "in_reply_to_status_id" : 926224168324096000,
  "created_at" : "2017-11-02 23:08:25 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 0, 9 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926189711479267329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85149298221089, -122.2945033346296 ]
  },
  "id_str" : "926189751740153856",
  "in_reply_to_user_id" : 2362226100,
  "text" : "@InfinoMe thanks!",
  "id" : 926189751740153856,
  "in_reply_to_status_id" : 926189711479267329,
  "created_at" : "2017-11-02 20:50:19 +0000",
  "in_reply_to_screen_name" : "InfinoMe",
  "in_reply_to_user_id_str" : "2362226100",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/926171807576506368\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/FPE9EDMvht",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNpsWOwVAAAFcsB.jpg",
      "id_str" : "926171802551779328",
      "id" : 926171802551779328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNpsWOwVAAAFcsB.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 389
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 389
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 389
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 389
      } ],
      "display_url" : "pic.twitter.com\/FPE9EDMvht"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "926171553053765633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85146351011877, -122.2945687473108 ]
  },
  "id_str" : "926171807576506368",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel Airbnb bietet folgendes an. https:\/\/t.co\/FPE9EDMvht",
  "id" : 926171807576506368,
  "in_reply_to_status_id" : 926171553053765633,
  "created_at" : "2017-11-02 19:39:01 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/926170769117233152\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/pjtfmHuNHi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DNprZ5fVQAAQHUt.jpg",
      "id_str" : "926170766051196928",
      "id" : 926170766051196928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DNprZ5fVQAAQHUt.jpg",
      "sizes" : [ {
        "h" : 469,
        "resize" : "fit",
        "w" : 443
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 443
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 443
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 443
      } ],
      "display_url" : "pic.twitter.com\/pjtfmHuNHi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85146707379452, -122.2945400612258 ]
  },
  "id_str" : "926170769117233152",
  "text" : "Day 1 of apartment search in Berkeley. https:\/\/t.co\/pjtfmHuNHi",
  "id" : 926170769117233152,
  "created_at" : "2017-11-02 19:34:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berkeley Lab",
      "screen_name" : "BerkeleyLab",
      "indices" : [ 14, 26 ],
      "id_str" : "17054817",
      "id" : 17054817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.86375354513327, -122.2722354346162 ]
  },
  "id_str" : "926115079938068480",
  "text" : "Badge for the @BerkeleyLab \u2705\uD83C\uDF89",
  "id" : 926115079938068480,
  "created_at" : "2017-11-02 15:53:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/yNt74ZLoWj",
      "expanded_url" : "https:\/\/gayiceland.is\/2016\/tf-gay-is-ready-for-take-off\/",
      "display_url" : "gayiceland.is\/2016\/tf-gay-is\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99405208029538, -22.62533347275425 ]
  },
  "id_str" : "925759908674498560",
  "text" : "Ready for take-off! https:\/\/t.co\/yNt74ZLoWj",
  "id" : 925759908674498560,
  "created_at" : "2017-11-01 16:22:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 0, 7 ],
      "id_str" : "9723702",
      "id" : 9723702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925756726917263360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99408187257497, -22.62860370802007 ]
  },
  "id_str" : "925756983826886657",
  "in_reply_to_user_id" : 9723702,
  "text" : "@ansate That sounds awesome!",
  "id" : 925756983826886657,
  "in_reply_to_status_id" : 925756726917263360,
  "created_at" : "2017-11-01 16:10:39 +0000",
  "in_reply_to_screen_name" : "ansate",
  "in_reply_to_user_id_str" : "9723702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Santos",
      "screen_name" : "ansate",
      "indices" : [ 0, 7 ],
      "id_str" : "9723702",
      "id" : 9723702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925755991693475842",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99302302153423, -22.62499635245112 ]
  },
  "id_str" : "925756612438093824",
  "in_reply_to_user_id" : 9723702,
  "text" : "@ansate Thanks! Looking forward to meet up!",
  "id" : 925756612438093824,
  "in_reply_to_status_id" : 925755991693475842,
  "created_at" : "2017-11-01 16:09:10 +0000",
  "in_reply_to_screen_name" : "ansate",
  "in_reply_to_user_id_str" : "9723702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 63.99394428363441, -22.62896765025577 ]
  },
  "id_str" : "925755649157423104",
  "text" : "And KEF \u2708\uFE0F SFO now. \uD83C\uDF89",
  "id" : 925755649157423104,
  "created_at" : "2017-11-01 16:05:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    }, {
      "name" : "Frankfurt Airport",
      "screen_name" : "Airport_FRA",
      "indices" : [ 10, 22 ],
      "id_str" : "29191391",
      "id" : 29191391
    }, {
      "name" : "Frankfurt Airport",
      "screen_name" : "Airport_FRA",
      "indices" : [ 41, 53 ],
      "id_str" : "29191391",
      "id" : 29191391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925654561498566662",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0514897623325, 8.589569567256815 ]
  },
  "id_str" : "925659941871988736",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara @Airport_FRA Sometimes leaving @Airport_FRA takes as long as the tube ride from central London to LHR. \uD83D\uDE02",
  "id" : 925659941871988736,
  "in_reply_to_status_id" : 925654561498566662,
  "created_at" : "2017-11-01 09:45:02 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Charlesworth",
      "screen_name" : "janepipistrelle",
      "indices" : [ 0, 16 ],
      "id_str" : "328098087",
      "id" : 328098087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925652087865823232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05165222957248, 8.589776161693901 ]
  },
  "id_str" : "925653642794995712",
  "in_reply_to_user_id" : 328098087,
  "text" : "@janepipistrelle I\u2019m already intrigued!",
  "id" : 925653642794995712,
  "in_reply_to_status_id" : 925652087865823232,
  "created_at" : "2017-11-01 09:20:00 +0000",
  "in_reply_to_screen_name" : "janepipistrelle",
  "in_reply_to_user_id_str" : "328098087",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05161110680895, 8.5897124254254 ]
  },
  "id_str" : "925648570971193344",
  "text" : "When it finally felt like I understood the geography of this airport a bit. \uD83D\uDC4B FRA \u2708\uFE0F KEF.",
  "id" : 925648570971193344,
  "created_at" : "2017-11-01 08:59:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]