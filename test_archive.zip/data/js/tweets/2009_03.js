Grailbird.data.tweets_2009_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1423459812",
  "text" : "Bin ich etwa der einzige der f\u00FCr die #rp09 noch gar nichts gepackt hat und sich auch nicht die Haare k\u00FCrzen l\u00E4sst?",
  "id" : 1423459812,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u263A\uFE0E\uD835\uDD5B\uD835\uDD52\uD835\uDD65\uD835\uDD5A",
      "screen_name" : "jati",
      "indices" : [ 0, 5 ],
      "id_str" : "9331462",
      "id" : 9331462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1423486973",
  "geo" : { },
  "id_str" : "1423494347",
  "in_reply_to_user_id" : 9331462,
  "text" : "@jati Gut, dann kann ich ja beides noch ein bisschen vor mir herschieben :) #rp09",
  "id" : 1423494347,
  "in_reply_to_status_id" : 1423486973,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "jati",
  "in_reply_to_user_id_str" : "9331462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1423493153",
  "geo" : { },
  "id_str" : "1423506620",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju Willkommen im Club der Nicht-Anonymen Prokrastinierer :) #rp09",
  "id" : 1423506620,
  "in_reply_to_status_id" : 1423493153,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1423498482",
  "geo" : { },
  "id_str" : "1423508841",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Ne ne, also morgen fr\u00FCh geht ja mal gar nicht. Da schlafe ich lieber 5 Minuten l\u00E4nger :)",
  "id" : 1423508841,
  "in_reply_to_status_id" : 1423498482,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1423661098",
  "text" : "Schlechte Nachrichten f\u00FCr alle Killerspiel-Verbotsliebhaber: http:\/\/is.gd\/pD2j 3D-Shooter sind gut f\u00FCr das Kontrastsehen.",
  "id" : 1423661098,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1424105928",
  "text" : "Fange nun an meinen Krams f\u00FCr die #rp09 zu packen. Mal sehen was ich im Endeffekt vergessen werde.",
  "id" : 1424105928,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1424600408",
  "text" : "An das Ticket hab ich auf jedenfall schonmal gedacht beim Packen. Ideal! #rp09",
  "id" : 1424600408,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1424940786",
  "text" : "Ich habe das Talent immer genau das Eis beim Pizza-Lieferanten zu bestellen das ausverkauft ist. Und immer die besten Sorten!",
  "id" : 1424940786,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1424950506",
  "geo" : { },
  "id_str" : "1425029377",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays RegExs k\u00F6nnen so was sch\u00F6nes sein. Und so verdammt h\u00E4sslich zu gleich ;)",
  "id" : 1425029377,
  "in_reply_to_status_id" : 1424950506,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1425177468",
  "geo" : { },
  "id_str" : "1425199333",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe Ich bin mal so frei zu antworten: HappyShooting :)",
  "id" : 1425199333,
  "in_reply_to_status_id" : 1425177468,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1425200366",
  "geo" : { },
  "id_str" : "1425214960",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Viel Spa\u00DF, aber Trink nicht so viel, du musst morgen fahren ;)",
  "id" : 1425214960,
  "in_reply_to_status_id" : 1425200366,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1425464443",
  "geo" : { },
  "id_str" : "1426424703",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Aye, werd ich machen :)",
  "id" : 1426424703,
  "in_reply_to_status_id" : 1425464443,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Senger",
      "screen_name" : "rhineduck",
      "indices" : [ 0, 10 ],
      "id_str" : "21312796",
      "id" : 21312796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1426395803",
  "geo" : { },
  "id_str" : "1426431120",
  "in_reply_to_user_id" : 21312796,
  "text" : "@rhineduck Immerhin hab ich eine leckere Alternative gefunden :)",
  "id" : 1426431120,
  "in_reply_to_status_id" : 1426395803,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "rhineduck",
  "in_reply_to_user_id_str" : "21312796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poken",
      "indices" : [ 97, 103 ]
    }, {
      "text" : "rp09",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1426453123",
  "text" : "Laptop & Telefon \u2714 Kamera: \u2714 Ladeger\u00E4te: \u2714 Klamotten: \u2714 Zahnb\u00FCrste etc.: \u2714 Handtuch: \u2714 Ticket: \u2714 #poken: \u2714 Sieht okay aus. #rp09",
  "id" : 1426453123,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thorsten Zoerner",
      "screen_name" : "zoernert",
      "indices" : [ 0, 9 ],
      "id_str" : "5817912",
      "id" : 5817912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1426495146",
  "geo" : { },
  "id_str" : "1426503948",
  "in_reply_to_user_id" : 5817912,
  "text" : "@zoernert Nudistencamp 09? ;)",
  "id" : 1426503948,
  "in_reply_to_status_id" : 1426495146,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "zoernert",
  "in_reply_to_user_id_str" : "5817912",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Senger",
      "screen_name" : "rhineduck",
      "indices" : [ 0, 10 ],
      "id_str" : "21312796",
      "id" : 21312796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1426497355",
  "geo" : { },
  "id_str" : "1426525541",
  "in_reply_to_user_id" : 21312796,
  "text" : "@rhineduck Choc-Choc-Chip. Schoki pur :)",
  "id" : 1426525541,
  "in_reply_to_status_id" : 1426497355,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "rhineduck",
  "in_reply_to_user_id_str" : "21312796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1426881381",
  "text" : "Langsam sollte ich mal meine Wecker stellen und ins Bett gehen.",
  "id" : 1426881381,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raju e",
      "screen_name" : "rajue",
      "indices" : [ 0, 6 ],
      "id_str" : "289833731",
      "id" : 289833731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1417977662",
  "text" : "@rajue Schonmal einleben f\u00FCr die re:publica? :)",
  "id" : 1417977662,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1418579455",
  "text" : "Auf was freut ihr euch bei der #rp09 am meisten?",
  "id" : 1418579455,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1419341249",
  "text" : "Der einzige Kurze Vorteil der Sommerzeit.  http:\/\/twitpic.com\/2lzd2",
  "id" : 1419341249,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1419804718",
  "text" : "Is the whole Steam-network fucked up or just Left4Dead?",
  "id" : 1419804718,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1419825813",
  "text" : "Fail: Zigarette zu locker gedreht, Filter fast verschluckt. Ende-Des-Monats-Syndrom.",
  "id" : 1419825813,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1419762530",
  "geo" : { },
  "id_str" : "1419867528",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Du machst das ganz toll! :)",
  "id" : 1419867528,
  "in_reply_to_status_id" : 1419762530,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "netzpolitik",
      "screen_name" : "netzpolitik",
      "indices" : [ 0, 12 ],
      "id_str" : "9655032",
      "id" : 9655032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1419937269",
  "geo" : { },
  "id_str" : "1419960916",
  "in_reply_to_user_id" : 9655032,
  "text" : "@netzpolitik *Hand heb*",
  "id" : 1419960916,
  "in_reply_to_status_id" : 1419937269,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "netzpolitik",
  "in_reply_to_user_id_str" : "9655032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Reinhardt",
      "screen_name" : "p_j_fry",
      "indices" : [ 0, 8 ],
      "id_str" : "15709530",
      "id" : 15709530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1420005178",
  "geo" : { },
  "id_str" : "1420017475",
  "in_reply_to_user_id" : 15709530,
  "text" : "@p_j_fry Bei der re:publica w\u00FCrd ich es mal versuchen, da werden die Dinger gehandelt.",
  "id" : 1420017475,
  "in_reply_to_status_id" : 1420005178,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "p_j_fry",
  "in_reply_to_user_id_str" : "15709530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1420219530",
  "text" : "Ganz fieses Abendessen: Nutella aus dem Glas L\u00F6ffeln.",
  "id" : 1420219530,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha",
      "screen_name" : "radio_g",
      "indices" : [ 0, 8 ],
      "id_str" : "122664867",
      "id" : 122664867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1420232264",
  "geo" : { },
  "id_str" : "1420324652",
  "in_reply_to_user_id" : 6899832,
  "text" : "@radio_g Aufh\u00F6ren geht erst wenn die \u00DCbelkeit \u00FCberhand gewinnt. ;)",
  "id" : 1420324652,
  "in_reply_to_status_id" : 1420232264,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "inmichaelsworld",
  "in_reply_to_user_id_str" : "6899832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Senger",
      "screen_name" : "rhineduck",
      "indices" : [ 0, 10 ],
      "id_str" : "21312796",
      "id" : 21312796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1420262908",
  "geo" : { },
  "id_str" : "1420327166",
  "in_reply_to_user_id" : 21312796,
  "text" : "@rhineduck Dann bin ich ja beruhigt :)",
  "id" : 1420327166,
  "in_reply_to_status_id" : 1420262908,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "rhineduck",
  "in_reply_to_user_id_str" : "21312796",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1420420169",
  "text" : "Ab ins Bett!",
  "id" : 1420420169,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1416780289",
  "text" : "Vom Telefon geweckt werden. Der Herr Vater dran, sein Windows spinnt. Hab ihm gesagt das muss so.",
  "id" : 1416780289,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1416863645",
  "text" : "Ratet mal wer nun verzweifelt mit seinem Windows-Laptop vor der Haust\u00FCr steht. Verdammt, ich sollte weiter wegziehen.",
  "id" : 1416863645,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1416973288",
  "text" : "Ich weiss nicht was ich mittlerweile mehr hasse: Windows, die Windows-User oder Lenovo f\u00FCr ihre beknackten, nichtfunktionierenden Treiber",
  "id" : 1416973288,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1417002947",
  "geo" : { },
  "id_str" : "1417013238",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Auf irgendwas wird mein Groll schon besonders gro\u00DF sein. Ich glaube auf Lenovo. Treiber per Hand in die Registry einpflegen m\u00FCssen..",
  "id" : 1417013238,
  "in_reply_to_status_id" : 1417002947,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1417229331",
  "text" : "Schau gerade schonmal welche Veranstaltungen der re:publica sich wohl lohnen k\u00F6nnten hinzugehen. Lustiges Kalenderverschieben.",
  "id" : 1417229331,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1417423532",
  "text" : "Endlich mal ein Tag mit richtigem Sonnenschein. Dann kann der Hund endlich mal wieder ein bisschen l\u00E4nger im Wald verweilen.",
  "id" : 1417423532,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1417894136",
  "text" : "Ich glaube ich werde vergessl...",
  "id" : 1417894136,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1417896821",
  "text" : "@JoergR Danke f\u00FCr die Links :)",
  "id" : 1417896821,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1417972701",
  "text" : "10 Minuten lang versucht den Fleck vom Monitor zu wischen, dann erst gemerkt es ist im Wallpaper, nicht auf dem Monitor.",
  "id" : 1417972701,
  "created_at" : "2009-03-30 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1411072724",
  "text" : "Bah, eigentlich ist es erst 7 Uhr.",
  "id" : 1411072724,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1411233644",
  "text" : "Gestern Mirrors gesehen:Jack Bauer goes Ghostbusters.Und dann er die Nonne nicht noch foltert ist auch alles.. Ist sinnlos hoch im IMDB-Rank",
  "id" : 1411233644,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "auge",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1411278013",
  "text" : "Die ISPs sollten einfach mal alle Webseiten von unkritischen Medien wie SpAm und dazu gleich die Seiten der Regierung blocken. #auge-um-auge",
  "id" : 1411278013,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1411458848",
  "text" : "Und nun darf ich zum n\u00E4chsten Familienfest. Vielleicht ist wenigstens das Essen gut. Typische, westf\u00E4lische K\u00FCche ist so gar nicht meins...",
  "id" : 1411458848,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aggressiv",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1411614328",
  "text" : "Familienfeiern auf denen Menschen mit \u00FCberdimensionierten DSLRs im Automatikmodus mit aufklapp-Blitz stressen! #aggressiv",
  "id" : 1411614328,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1411610672",
  "geo" : { },
  "id_str" : "1411615299",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Dann kannst du mich ja mitnehmen! ;)",
  "id" : 1411615299,
  "in_reply_to_status_id" : 1411610672,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1411787485",
  "text" : "Oh ne, schon bald 2 Stunden hier und der Hauptgang l\u00E4sst noch auf sich warten. Slowfood ist einfach nichts f\u00FCr mich.",
  "id" : 1411787485,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1411798494",
  "text" : "Und in der Raucherbar l\u00E4uft \u201EYesterday\u201C in der Schmierigsten Piano-Jazz-Variante die ich je geh\u00F6rt habe.",
  "id" : 1411798494,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fragezeichner",
      "screen_name" : "fragezeichner",
      "indices" : [ 0, 14 ],
      "id_str" : "22900501",
      "id" : 22900501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1411794413",
  "geo" : { },
  "id_str" : "1411809555",
  "in_reply_to_user_id" : 22900501,
  "text" : "@fragezeichner dann w\u00FCrden M\u00E4nner nicht mehr Twittern!",
  "id" : 1411809555,
  "in_reply_to_status_id" : 1411794413,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "fragezeichner",
  "in_reply_to_user_id_str" : "22900501",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1411884768",
  "text" : "Jetzt fehlt nur noch das Dessert. Wehe euch, wenn das nicht gut ist.",
  "id" : 1411884768,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1413047000",
  "text" : "Oha, Quitter ging heut mal kurz wieder. Interessant wer wann aufh\u00F6rt zu followen.",
  "id" : 1413047000,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1413119745",
  "text" : "Noch 3 mal schlafen dann geht es zur #rp09",
  "id" : 1413119745,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1413179026",
  "text" : "Was soll man von Menschen halten die sich Herr der Ringe im Kino ansehen und nach der H\u00E4lfte gehen. Begr\u00FCndung: Zu viel Fantasy.",
  "id" : 1413179026,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1413191396",
  "geo" : { },
  "id_str" : "1413200906",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Wer h\u00E4tte denn damit rechnen k\u00F6nnen das Science-FICTION etwas mit Fiktion zu tun haben k\u00F6nnte? Seltsam seltsam.",
  "id" : 1413200906,
  "in_reply_to_status_id" : 1413191396,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Naurath",
      "screen_name" : "anaurath",
      "indices" : [ 0, 9 ],
      "id_str" : "17346698",
      "id" : 17346698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1413215377",
  "geo" : { },
  "id_str" : "1413294662",
  "in_reply_to_user_id" : 17346698,
  "text" : "@anaurath Gibt es von der Sorte Menschen viele? Das ist irgendwo zwischen dumm und einfach unglaublich ignorant.",
  "id" : 1413294662,
  "in_reply_to_status_id" : 1413215377,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "anaurath",
  "in_reply_to_user_id_str" : "17346698",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cspannagel",
      "screen_name" : "cspannagel",
      "indices" : [ 0, 11 ],
      "id_str" : "578512158",
      "id" : 578512158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1413421583",
  "text" : "@cspannagel Dito! Meine Wanduhr passt nun auch wieder.",
  "id" : 1413421583,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1413921647",
  "text" : "Werd jetzt noch die Nachttaxe im rbb schauen. Finde ich immer ganz witzig.",
  "id" : 1413921647,
  "created_at" : "2009-03-29 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1406231307",
  "geo" : { },
  "id_str" : "1406246174",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Na sag ich doch! :)",
  "id" : 1406246174,
  "in_reply_to_status_id" : 1406231307,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1406251150",
  "text" : "Amazon hat problemlos das Geld f\u00FCr den defekten Sandisk-mp3-Player zur\u00FCckerstattet. Sehr nett, Kleiner Geldregen.",
  "id" : 1406251150,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1406417192",
  "text" : "Oh man, als ob er zuhause verhungern w\u00FCrde  http:\/\/twitpic.com\/2iwut",
  "id" : 1406417192,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1406454771",
  "text" : "Mal wieder von allen Fotos ein Backup auf der letzten externen Festplatte machen. Br\u00E4uchte langsam mal eine neue.",
  "id" : 1406454771,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1406504981",
  "text" : "http:\/\/twitpic.com\/2ixkh - Elvis lebt! Was man nicht alles auf seiner Festplatte findet",
  "id" : 1406504981,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1406765651",
  "geo" : { },
  "id_str" : "1406787659",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod ja ich hatte schon dr\u00FCber gebloggt vor einiger Zeit.",
  "id" : 1406787659,
  "in_reply_to_status_id" : 1406765651,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Songuer",
      "screen_name" : "DirkSonguer",
      "indices" : [ 0, 12 ],
      "id_str" : "17128227",
      "id" : 17128227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 85, 90 ]
    }, {
      "text" : "pokens",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1406857462",
  "geo" : { },
  "id_str" : "1406860455",
  "in_reply_to_user_id" : 17128227,
  "text" : "@DirkSonguer Danke, werden auf der re:publica zum Einsatz kommen geh ich von aus! :) #rp09 #pokens",
  "id" : 1406860455,
  "in_reply_to_status_id" : 1406857462,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "DirkSonguer",
  "in_reply_to_user_id_str" : "17128227",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Songuer",
      "screen_name" : "DirkSonguer",
      "indices" : [ 0, 12 ],
      "id_str" : "17128227",
      "id" : 17128227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1406880168",
  "geo" : { },
  "id_str" : "1406931845",
  "in_reply_to_user_id" : 17128227,
  "text" : "@DirkSonguer Schade, aber es gibt ja noch andere Konferenzen.",
  "id" : 1406931845,
  "in_reply_to_status_id" : 1406880168,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "DirkSonguer",
  "in_reply_to_user_id_str" : "17128227",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1406935582",
  "geo" : { },
  "id_str" : "1406943821",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Absolut geblockt, gegen Kinderporno und so.",
  "id" : 1406943821,
  "in_reply_to_status_id" : 1406935582,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Solder",
      "screen_name" : "wilsberg",
      "indices" : [ 3, 12 ],
      "id_str" : "18932311",
      "id" : 18932311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1407027127",
  "text" : "RT @wilsberg: Twittern als Schulfach? http:\/\/is.gd\/pp1W",
  "id" : 1407027127,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1407077209",
  "geo" : { },
  "id_str" : "1407113115",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich verbiete mir die Welt, wie sie mir gef\u00E4llt.",
  "id" : 1407113115,
  "in_reply_to_status_id" : 1407077209,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1407121191",
  "geo" : { },
  "id_str" : "1407131926",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Absolut :)",
  "id" : 1407131926,
  "in_reply_to_status_id" : 1407121191,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1407622042",
  "text" : "Ist YouTube nur bei mir gerade gar nicht zu benutzen? Es schubst die Daten ja sowas von lahm...",
  "id" : 1407622042,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1407630683",
  "geo" : { },
  "id_str" : "1407636559",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Dann bin ich beruhigt. Dachte schon der Router spinnt einfach mal wieder grundlos rum.",
  "id" : 1407636559,
  "in_reply_to_status_id" : 1407630683,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmuth Ringhandt",
      "screen_name" : "iKieler",
      "indices" : [ 0, 8 ],
      "id_str" : "18356871",
      "id" : 18356871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1407641805",
  "geo" : { },
  "id_str" : "1407650982",
  "in_reply_to_user_id" : 18123358,
  "text" : "@iKieler Sporadisch flitzen die Bytes auch ganz normal durch die Leitung und dann wieder gar nicht mehr. Sehr seltsam und vor allem nervig.",
  "id" : 1407650982,
  "in_reply_to_status_id" : 1407641805,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ringhandt",
  "in_reply_to_user_id_str" : "18123358",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1407699317",
  "text" : "Hatte ich eigentlich schon getwittert, dass ich mal wieder was gebloggt habe? Ich glaube nicht: Generation Internet - http:\/\/is.gd\/ppYW",
  "id" : 1407699317,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1407714516",
  "geo" : { },
  "id_str" : "1407721989",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Infinite Loop? Wash. Rinse. Repeat.",
  "id" : 1407721989,
  "in_reply_to_status_id" : 1407714516,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1407745736",
  "geo" : { },
  "id_str" : "1407750100",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Wenn ich dar\u00FCber bloggen w\u00FCrde k\u00F6nnte ich wieder dr\u00FCber Twittern wor\u00FCber ich seinerseits wieder bloggen k\u00F6nnte. Und so weiter.",
  "id" : 1407750100,
  "in_reply_to_status_id" : 1407745736,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tapio Liller",
      "screen_name" : "tapioliller",
      "indices" : [ 0, 12 ],
      "id_str" : "2854801",
      "id" : 2854801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "poken",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "rp09",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1407711983",
  "geo" : { },
  "id_str" : "1407765799",
  "in_reply_to_user_id" : 2854801,
  "text" : "@tapioliller Schau mal hier: http:\/\/is.gd\/pq4f :) #poken #rp09",
  "id" : 1407765799,
  "in_reply_to_status_id" : 1407711983,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "tapioliller",
  "in_reply_to_user_id_str" : "2854801",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1407788731",
  "text" : "Da YouTube nun wieder geht (zumindest hier): A bit of Fry & Laurie - America http:\/\/is.gd\/pq67",
  "id" : 1407788731,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1407819442",
  "geo" : { },
  "id_str" : "1407841505",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Das Usenet war nie mein place to be. Bin mit den Sitten und Br\u00E4uchen in diesem L\u00E4ndchen nicht so vertraut.",
  "id" : 1407841505,
  "in_reply_to_status_id" : 1407819442,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1408221913",
  "text" : "Kochen! http:\/\/twitpic.com\/2jfrc",
  "id" : 1408221913,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1408346190",
  "text" : "Und fleissig weiterkochen. Indische Linsensuppe soll es werden wenn es fertig ist.",
  "id" : 1408346190,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 0, 10 ],
      "id_str" : "1024351",
      "id" : 1024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1408651962",
  "geo" : { },
  "id_str" : "1408672757",
  "in_reply_to_user_id" : 1024351,
  "text" : "@Labuschin Ich find sie Super. Ist eine \u00DCbungsfrage wie bei der Kleinen auch.",
  "id" : 1408672757,
  "in_reply_to_status_id" : 1408651962,
  "created_at" : "2009-03-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Labuschin",
  "in_reply_to_user_id_str" : "1024351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entspannung",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1399995852",
  "text" : "In der Badewanne liegen und die Nature lesen. #entspannung",
  "id" : 1399995852,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Bertling",
      "screen_name" : "jayzon277",
      "indices" : [ 0, 10 ],
      "id_str" : "372320321",
      "id" : 372320321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1400009160",
  "geo" : { },
  "id_str" : "1400017612",
  "in_reply_to_user_id" : 14115883,
  "text" : "@jayzon277 Viel billiger geht es auch nicht oder?",
  "id" : 1400017612,
  "in_reply_to_status_id" : 1400009160,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus Bertling",
      "screen_name" : "jayzon277",
      "indices" : [ 0, 10 ],
      "id_str" : "372320321",
      "id" : 372320321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1400021417",
  "geo" : { },
  "id_str" : "1400030296",
  "in_reply_to_user_id" : 14115883,
  "text" : "@jayzon277 Das hab ich gestern dann wohl \u00FCbersehen, ist auch gar nicht so schade drum ;)",
  "id" : 1400030296,
  "in_reply_to_status_id" : 1400021417,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "HerrBertling",
  "in_reply_to_user_id_str" : "14115883",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1400098084",
  "text" : "Wo wir gerade bei Schlechten Obama-Ad-Ripoffs sind...  http:\/\/twitpic.com\/2hpvc",
  "id" : 1400098084,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1400144504",
  "text" : "http:\/\/twitpic.com\/2hpvc - Sch\u00F6n w\u00E4re es, aber ich glaube noch nicht daran das es schnell endet.",
  "id" : 1400144504,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ratlos",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1400285742",
  "text" : "Mh wo habe ich wohl das Ladeger\u00E4t f\u00FCr die Kamera-Akkus hingepackt? #ratlos",
  "id" : 1400285742,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1400316787",
  "text" : "Okay Ladeger\u00E4t gefunden, w\u00E4re nun die Frage wo zum Teufel ist das Auto-Ladekabel f\u00FCr die GPS-Mouse? Ich verlange Drahtlosstrom, jetzt!",
  "id" : 1400316787,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1400417764",
  "text" : "Another Relaxing Day Ruined by Physics: http:\/\/is.gd\/pe0H",
  "id" : 1400417764,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1400695890",
  "text" : "Gna, wieso muss man f\u00FCr das bl\u00F6de iLife-Upgrade neustarten?",
  "id" : 1400695890,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1401476215",
  "text" : "Kann man Tabellen aus Numbers eigentlich irgendwie ins Mediawiki-Format exportieren?",
  "id" : 1401476215,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1401549310",
  "text" : "Ah hab den Trick rausgefunden f\u00FCr Numbers -&gt; MediaWiki: Als CSV exportieren und dann auf dieser Webseite http:\/\/is.gd\/ih9Y CSV -&gt; Mediawiki",
  "id" : 1401549310,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathrin Futter",
      "screen_name" : "prozimsun",
      "indices" : [ 0, 10 ],
      "id_str" : "17944376",
      "id" : 17944376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1401963490",
  "geo" : { },
  "id_str" : "1402163408",
  "in_reply_to_user_id" : 17944376,
  "text" : "@prozimsun Ah, ich bleibe trotzdem bei Newsstand :)",
  "id" : 1402163408,
  "in_reply_to_status_id" : 1401963490,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "prozimsun",
  "in_reply_to_user_id_str" : "17944376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1402229989",
  "text" : "Memo an mich: HDMI-Audio-Treiber befinden sich selbstverst\u00E4ndlich im Grafikkarten-Treiberpaket.",
  "id" : 1402229989,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1402753321",
  "geo" : { },
  "id_str" : "1402785142",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Deshalb kann ich mir diesen Mist schon seit einiger Zeit gar nicht mehr ansehen. Knuffig fand ich auch die \u201CStahlatome\u201D [sic!]",
  "id" : 1402785142,
  "in_reply_to_status_id" : 1402753321,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1402837425",
  "geo" : { },
  "id_str" : "1402869812",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Als ob jemand diese Sendungen brauchen w\u00FCrde deren schmierigen Moderatoren am liebsten in Uri Gellers Wunder-Arsch kriechen...",
  "id" : 1402869812,
  "in_reply_to_status_id" : 1402837425,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1402890870",
  "geo" : { },
  "id_str" : "1402902960",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Okay ich schau mal schnell :)",
  "id" : 1402902960,
  "in_reply_to_status_id" : 1402890870,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1402890870",
  "geo" : { },
  "id_str" : "1402919566",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Ist freigeschaltet, der Autor weiss bescheid ;) Und zu Galileo verweise ich gerne auch immer auf diesen Artikel: http:\/\/is.gd\/piAc",
  "id" : 1402919566,
  "in_reply_to_status_id" : 1402890870,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1403092719",
  "text" : "Gar nicht Lustig! http:\/\/is.gd\/piVe",
  "id" : 1403092719,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwischenrufer",
      "screen_name" : "Zwischenrufer",
      "indices" : [ 3, 17 ],
      "id_str" : "16046470",
      "id" : 16046470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1403953011",
  "text" : "RT @Zwischenrufer: Plane mein Filmdebut als Regisseur. Titel: \"Die Liga der \u00E4u\u00DFerst gew\u00F6hnlichen Gentleman\" Wer will mitspielen ?",
  "id" : 1403953011,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1403986321",
  "text" : "So ich werd mich nach einem netten Doppelkopf-Abend ins Bettchen begeben. Ein bisschen Schlaf muss sein...",
  "id" : 1403986321,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 3, 11 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1393526577",
  "text" : "RT @insideX: Programmieren Sie immer so, als w\u00E4re der Typ, der den Code pflegen muss, ein gewaltbereiter Psychopath, der wei\u00DF, wo Sie wohnen",
  "id" : 1393526577,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1394024953",
  "text" : "Den Hund zu fotografieren ist einfach Gl\u00FCckssache. Im passenden Augenblick abdr\u00FCcken und Hoffen das der Autofokus es nicht verbockt hat.",
  "id" : 1394024953,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1394137429",
  "geo" : { },
  "id_str" : "1394210353",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Typische IT-Krankheit: Karpaltunnelsyndrom? ;)",
  "id" : 1394210353,
  "in_reply_to_status_id" : 1394137429,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "charly",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1394222412",
  "text" : "Vintage Hund! http:\/\/is.gd\/p3L8 #charly",
  "id" : 1394222412,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1394234218",
  "geo" : { },
  "id_str" : "1394340014",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Stimmt, aber nicht mehr tippen.",
  "id" : 1394340014,
  "in_reply_to_status_id" : 1394234218,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Songuer",
      "screen_name" : "DirkSonguer",
      "indices" : [ 51, 63 ],
      "id_str" : "17128227",
      "id" : 17128227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1394530571",
  "text" : "Gerade war der Postbote da, mit einem Umschlag von @DirkSonguer Inklusive \u00DCberraschung! Vielen Dank :) http:\/\/twitpic.com\/2glgk",
  "id" : 1394530571,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der Jubilizr",
      "screen_name" : "jubilizr",
      "indices" : [ 62, 71 ],
      "id_str" : "19485705",
      "id" : 19485705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1394629138",
  "text" : "Da hab ich doch glatt den 4000. Tweet verpasst. Und das trotz @jubilizr Mea culpa!",
  "id" : 1394629138,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1394751411",
  "text" : "Und nochmal der Hund, traut sich bei dem Wetter nicht vor die T\u00FCr und bekommt so langsam den Lagerkoller. http:\/\/is.gd\/p4Mh",
  "id" : 1394751411,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1394874872",
  "geo" : { },
  "id_str" : "1394888807",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster Klares Ja :)",
  "id" : 1394888807,
  "in_reply_to_status_id" : 1394874872,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1394946403",
  "text" : "Ist es nicht etwas sch\u00F6nes wenn iTunes einfach unmotiviert abst\u00FCrzt bloss weil es den Programmfokus wiederbekommt? Zauberhaft...",
  "id" : 1394946403,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1395094196",
  "text" : "Winke Winke sagt der Panda-Poken: http:\/\/is.gd\/p5rm",
  "id" : 1395094196,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1395289861",
  "text" : "Church-Fail: http:\/\/is.gd\/oSFV #fail",
  "id" : 1395289861,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1395475328",
  "text" : "Mjam. Schinken und Parmesan.  http:\/\/twitpic.com\/2gqz0",
  "id" : 1395475328,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1395495446",
  "geo" : { },
  "id_str" : "1395514640",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Es ist die Nature letzter Woche, mit dem Newsfeature \u00FCber Science-Blogs und Wissenschaftsjournalismus. Ist sehr gut so weit.",
  "id" : 1395514640,
  "in_reply_to_status_id" : 1395495446,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1395562427",
  "text" : "Gleich gehts wieder zur Sommerlagervorbereitung.",
  "id" : 1395562427,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1395563772",
  "geo" : { },
  "id_str" : "1395585901",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Finde Zeitschriften auf dem Monitor lesen ungem\u00FCtlich. Deshalb drucke ich die meisten Paper die ich lese auch aus.",
  "id" : 1395585901,
  "in_reply_to_status_id" : 1395563772,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "Abo",
      "indices" : [ 76, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1395563772",
  "geo" : { },
  "id_str" : "1395591954",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Und die Nature kommt halt bequem nach Hause geliefert. :) #nature #Abo",
  "id" : 1395591954,
  "in_reply_to_status_id" : 1395563772,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1396081945",
  "geo" : { },
  "id_str" : "1396103080",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 So ist es bei mir auch, die Uninteressanten Paper lese ich ja auch nicht ;)",
  "id" : 1396103080,
  "in_reply_to_status_id" : 1396081945,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1396283057",
  "geo" : { },
  "id_str" : "1396644103",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Diese L\u00F6schfunktion gibt es \u00FCbrigens auch ;)",
  "id" : 1396644103,
  "in_reply_to_status_id" : 1396283057,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1396652589",
  "text" : "Waren sogar Produktiv mit den Kids heute. Im n\u00E4chsten Lager wird wieder ein Trash-Film gedreht!",
  "id" : 1396652589,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1396869222",
  "text" : "Der Hund hat ein Talent daf\u00FCr sein Spielzeug unter das Sofa zu schiessen wo er nicht mehr dran kommt.",
  "id" : 1396869222,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1396902921",
  "text" : "Muss mal wieder meine Feeds sortieren. Sonst verliere ich den \u00DCberblick.",
  "id" : 1396902921,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390400052",
  "geo" : { },
  "id_str" : "1390432910",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Die Arbeit selber finde ich in iTunes das Allerletzte. Daf\u00FCr lohnt sich das Ergebnis total.",
  "id" : 1390432910,
  "in_reply_to_status_id" : 1390400052,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stress",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390502120",
  "geo" : { },
  "id_str" : "1390518814",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Bewerten ist mir zu stressig. Aber der Rest sollte schon stimmen #stress ;)",
  "id" : 1390518814,
  "in_reply_to_status_id" : 1390502120,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390529044",
  "geo" : { },
  "id_str" : "1390567427",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Die sind eh nicht so mein Fall muss ich sagen, wenn dann lieber nach Genre oder so.",
  "id" : 1390567427,
  "in_reply_to_status_id" : 1390529044,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390585101",
  "geo" : { },
  "id_str" : "1390637870",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Hast du irgendwo eine Ziffer vergessen oder hast du eine kleine Sammlung? Bei mir sind es ca. 10 mal so viele Titel. :)",
  "id" : 1390637870,
  "in_reply_to_status_id" : 1390585101,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390711129",
  "geo" : { },
  "id_str" : "1390735281",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Besser auf dem Rechner als die CDs suchen zu m\u00FCssen.",
  "id" : 1390735281,
  "in_reply_to_status_id" : 1390711129,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390711129",
  "geo" : { },
  "id_str" : "1390748782",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Und sobald alleine Interpret, Titel, Album und Genre passen ist es um einiges einfacher als die 3D-Anordnung im CD-Regal :)",
  "id" : 1390748782,
  "in_reply_to_status_id" : 1390711129,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390754862",
  "geo" : { },
  "id_str" : "1390766118",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Bei CDs ist vor allem das Problem die Regale sortiert zu halten. Und die Sortierung: Genre? Interpret? Kombination von beidem? ;)",
  "id" : 1390766118,
  "in_reply_to_status_id" : 1390754862,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1390955099",
  "text" : "Wird Zeit mal ins Bett zu gehen. Dann komme ich vielleicht mal vormittags aus dem Bett.",
  "id" : 1390955099,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1386957979",
  "geo" : { },
  "id_str" : "1387139634",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays wir haben gar keinen Schnee :)",
  "id" : 1387139634,
  "in_reply_to_status_id" : 1386957979,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1387217463",
  "text" : "Vorsicht, Klischee-Student: Guten Morgen!",
  "id" : 1387217463,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malte Welding",
      "screen_name" : "maltewelding",
      "indices" : [ 3, 16 ],
      "id_str" : "6274082",
      "id" : 6274082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1387402899",
  "text" : "RT @maltewelding: Der Papst streichelt einen ausgestopften L\u00F6wen w\u00E4hrend eine Transe hinter ihm l\u00E4chelt\nhttp:\/\/is.gd\/oRMf",
  "id" : 1387402899,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1387419057",
  "text" : "Vintage Babes + Robots aka Nerdporn: http:\/\/is.gd\/oRI7",
  "id" : 1387419057,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1387588496",
  "text" : "\"Die klare Lehre der Kirche ist, dass die heilige Jungfr\u00E4ulichkeit durch ihren hohen Wert die Ehe \u00FCberrage\" 55 Jahre bl\u00F6d: http:\/\/is.gd\/oSc5",
  "id" : 1387588496,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1389017860",
  "text" : "Hab eine Kaffee-\u00DCberdosis zu mir genommen. F\u00FChle mich wie ein flattriger Kolibri.",
  "id" : 1389017860,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1389161379",
  "text" : "Twitter is having a problem, check the twitter website for more information. #fail",
  "id" : 1389161379,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1389222498",
  "text" : "Bald sind wir alle entweder Terroristen oder Kinderporno-Konsumenten: http:\/\/www.netzeitung.de\/politik\/deutschland\/1307797.html",
  "id" : 1389222498,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1389392104",
  "geo" : { },
  "id_str" : "1389397735",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Na dann viel Spa\u00DF bei der anstehenden Hausdurchsuchung w\u00FCrd ich sagen ;)",
  "id" : 1389397735,
  "in_reply_to_status_id" : 1389392104,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1389809302",
  "geo" : { },
  "id_str" : "1389899058",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Sperren bringen einfach nichts. Und wenn man erstmal damit anf\u00E4ngt landen bald noch unliebsame Dinge unter Zensur...",
  "id" : 1389899058,
  "in_reply_to_status_id" : 1389809302,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Weissbier_",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1389907897",
  "text" : "Neuer W&W-Post von Philipp: Von Pilzen und Ameisen http:\/\/tinyurl.com\/d2ybed #Weissbier_&_Wissenschaft",
  "id" : 1389907897,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1390083602",
  "text" : "Schau nun Life.",
  "id" : 1390083602,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390094004",
  "geo" : { },
  "id_str" : "1390117035",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva P\u00E4dophilie ist jetzt schon mehr als ausgegrenzt. Bei keiner anderen Straftat gibt es so starke Reaktionen in der \u00D6ffentlichkei",
  "id" : 1390117035,
  "in_reply_to_status_id" : 1390094004,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390094004",
  "geo" : { },
  "id_str" : "1390129756",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva zu sehr tabuisieren hilft sicherlich nicht. Verdr\u00E4ngt das Problem aus der \u00D6ffentlichkeit um sich im Hintergrund zu verbreiten.",
  "id" : 1390129756,
  "in_reply_to_status_id" : 1390094004,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1390144253",
  "geo" : { },
  "id_str" : "1390176702",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Das Problem ist das damit Zensur T\u00FCr & Tor ge\u00F6ffnet wird.",
  "id" : 1390176702,
  "in_reply_to_status_id" : 1390144253,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1390247247",
  "text" : "Werd mal die neuste Version von EventBox installieren. Bislang der beste Twitterclient den ich ausprobiert habe.",
  "id" : 1390247247,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 64, 80 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1380800512",
  "text" : "Ich muss mir gerade mal selbst einen Beispielfall konstruieren. @gedankenstuecke",
  "id" : 1380800512,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Naurath",
      "screen_name" : "anaurath",
      "indices" : [ 3, 12 ],
      "id_str" : "17346698",
      "id" : 17346698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twtpoll",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1380809264",
  "text" : "RT @anaurath: An die fotoaffinen Twitterer: Mit welcher Software verarbeitet Ihr RAW-Dateien? http:\/\/twtpoll.com\/1rpwzt #twtpoll",
  "id" : 1380809264,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schmolk",
      "screen_name" : "anouphagos",
      "indices" : [ 0, 11 ],
      "id_str" : "368317316",
      "id" : 368317316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1380831667",
  "text" : "@anouphagos Ich w\u00FCrd sagen es ist 5 Minuten her ;)",
  "id" : 1380831667,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1380995967",
  "text" : "Suche jetzt doch spontan noch eine nette \u00DCbernachtungsm\u00F6glichkeit in Berlin zur re:publica. Hat irgendwer gute Tipps? #rp09",
  "id" : 1380995967,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1381127013",
  "geo" : { },
  "id_str" : "1381129312",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron In Eventbox zumindest nicht.",
  "id" : 1381129312,
  "in_reply_to_status_id" : 1381127013,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha",
      "screen_name" : "radio_g",
      "indices" : [ 0, 8 ],
      "id_str" : "122664867",
      "id" : 122664867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1381131535",
  "geo" : { },
  "id_str" : "1381147940",
  "in_reply_to_user_id" : 6899832,
  "text" : "@radio_g Was ein Scheiss ;)",
  "id" : 1381147940,
  "in_reply_to_status_id" : 1381131535,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "inmichaelsworld",
  "in_reply_to_user_id_str" : "6899832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1381586223",
  "text" : "Ein Hostel das sich \u201CHeart Of Gold\u201D nennt (nein nicht nach Neil Young) und dazu noch neben der Kalkscheune, h\u00F6rt sich gut an. #rp09",
  "id" : 1381586223,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1381754870",
  "geo" : { },
  "id_str" : "1381793107",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Feier auf jedenfall sch\u00F6n! :)",
  "id" : 1381793107,
  "in_reply_to_status_id" : 1381754870,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1381984306",
  "text" : "\u00DCber das Wetter zu twittern ist so cool wie \u00FCber N\u00E4hen zu bloggen.",
  "id" : 1381984306,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382009708",
  "geo" : { },
  "id_str" : "1382120551",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum das ist wenigstens noch actiongeladen: Apple-Fanboys vs alle anderen :)",
  "id" : 1382120551,
  "in_reply_to_status_id" : 1382009708,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382024384",
  "geo" : { },
  "id_str" : "1382136663",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Hat sicherlich beides seine Berechtigung, interessiert mich nur so wenig ;)",
  "id" : 1382136663,
  "in_reply_to_status_id" : 1382024384,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382153550",
  "geo" : { },
  "id_str" : "1382179215",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Die aktuellen\n Wetterlage sehr ich auch wenn ich aus dem Fenster schaue. Und Vorhersagen werden selten getwittert :)",
  "id" : 1382179215,
  "in_reply_to_status_id" : 1382153550,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382153550",
  "geo" : { },
  "id_str" : "1382201290",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Und f\u00FCr N\u00E4hen fehlt mir die n\u00F6tige Fingerfertigkeit ;)",
  "id" : 1382201290,
  "in_reply_to_status_id" : 1382153550,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382243984",
  "geo" : { },
  "id_str" : "1382407991",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Stimmt,aber ich glaube selbst die langweilen aktuelle Wetter-Statusmeldungen.H\u00F6chstens ein Modell ala GoogleFluTrends w\u00E4r cool",
  "id" : 1382407991,
  "in_reply_to_status_id" : 1382243984,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382278091",
  "geo" : { },
  "id_str" : "1382413055",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Sehr schick, und da ich es selbst auch gar nicht kann meine tiefe Bewunderung dazu :)",
  "id" : 1382413055,
  "in_reply_to_status_id" : 1382278091,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382469276",
  "geo" : { },
  "id_str" : "1382478852",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Ich glaub da fehlt der Link ;)",
  "id" : 1382478852,
  "in_reply_to_status_id" : 1382469276,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedikt Koehler",
      "screen_name" : "furukama",
      "indices" : [ 0, 9 ],
      "id_str" : "5717402",
      "id" : 5717402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382434704",
  "geo" : { },
  "id_str" : "1382482448",
  "in_reply_to_user_id" : 5717402,
  "text" : "@furukama Das ist schon wieder ganz cool, fehlt nur noch die passende Karte dazu die Locations auswertet.",
  "id" : 1382482448,
  "in_reply_to_status_id" : 1382434704,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "furukama",
  "in_reply_to_user_id_str" : "5717402",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedikt Koehler",
      "screen_name" : "furukama",
      "indices" : [ 0, 9 ],
      "id_str" : "5717402",
      "id" : 5717402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382434704",
  "geo" : { },
  "id_str" : "1382485593",
  "in_reply_to_user_id" : 5717402,
  "text" : "@furukama Und wenn man einzelne User beobachten w\u00FCrde k\u00F6nnte man aus deren Wetterdaten sogar Vorhersagen erstellen.",
  "id" : 1382485593,
  "in_reply_to_status_id" : 1382434704,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "furukama",
  "in_reply_to_user_id_str" : "5717402",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1382908380",
  "text" : "Hat noch wer Probleme sich mit Twitter in Verbindung zu setzen?",
  "id" : 1382908380,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1382912991",
  "geo" : { },
  "id_str" : "1382958036",
  "in_reply_to_user_id" : 11801332,
  "text" : "@kuechenhure Dann bin ich ja beruhigt, dachte schon es w\u00E4re hier das Netz mal einfach wieder m\u00FCllig.",
  "id" : 1382958036,
  "in_reply_to_status_id" : 1382912991,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarioThiel",
  "in_reply_to_user_id_str" : "11801332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RAVI PRAKASH",
      "screen_name" : "rp09",
      "indices" : [ 4, 9 ],
      "id_str" : "546092743",
      "id" : 546092743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1383129874",
  "text" : "Der @rp09-Bot ist auch einfach v\u00F6llig fucked up zur Zeit. Twitter geht kaputt!",
  "id" : 1383129874,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1383459387",
  "text" : "Geschickt: \u00DCberall die TAN-Liste verzweifelt suchen um dann festzustellen das sie UNTER dem Laptop lag. Beim Netbook w\u00E4re das nicht passiert",
  "id" : 1383459387,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1383466285",
  "geo" : { },
  "id_str" : "1383492965",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich hab von der Sparkasse halt diesen normalen DIN A4-Block bekommen mit N\u00FCmmerchen drauf.",
  "id" : 1383492965,
  "in_reply_to_status_id" : 1383466285,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1383540384",
  "text" : "@JoergR Ich hab so ein Notebook-Sleeve in dem der Rechner stehenbleiben kann, zwischen Tasche und Ger\u00E4t eingeklemmt. Wie praktisch.",
  "id" : 1383540384,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1383820532",
  "text" : "Da Twitter ja schon wieder spinnt werd ich nun House schauen.",
  "id" : 1383820532,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hund",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "charly",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1383971722",
  "text" : "Und genau aus solchen Gr\u00FCnden muss der Hund irgendwann gebadet werden: http:\/\/is.gd\/oM7Z #hund #charly",
  "id" : 1383971722,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1384006327",
  "geo" : { },
  "id_str" : "1384033006",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Es ist auch so ekelig, es war gut Dung durchtr\u00E4nktes Stroh ;)",
  "id" : 1384033006,
  "in_reply_to_status_id" : 1384006327,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1384060376",
  "geo" : { },
  "id_str" : "1384108756",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 Er fand es aber prima :)",
  "id" : 1384108756,
  "in_reply_to_status_id" : 1384060376,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1384101953",
  "geo" : { },
  "id_str" : "1384133283",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Ja von Mendeley bin ich auch totaler Fan, vor allem die Groups-Funktion. Sammeln alle Paper f\u00FCr unser Wissenschaftsblog drin.",
  "id" : 1384133283,
  "in_reply_to_status_id" : 1384101953,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1384196338",
  "text" : "I can has cheezeburger? nom nom nom http:\/\/is.gd\/oMv7",
  "id" : 1384196338,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RAVI PRAKASH",
      "screen_name" : "rp09",
      "indices" : [ 0, 5 ],
      "id_str" : "546092743",
      "id" : 546092743
    }, {
      "name" : "Ram\u00F3n Goeden",
      "screen_name" : "websenat",
      "indices" : [ 12, 21 ],
      "id_str" : "14880063",
      "id" : 14880063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1384517729",
  "text" : "@rp09 Doch, @Websenat hat es auch geschafft. Auch wenn mir nicht bewusst ist wie.",
  "id" : 1384517729,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RAVI PRAKASH",
      "screen_name" : "rp09",
      "indices" : [ 0, 5 ],
      "id_str" : "546092743",
      "id" : 546092743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1384563721",
  "text" : "@rp09 Wieso habe ich das Gef\u00FChl das Twitters Schluck\u00E4ufe damit zu tun haben? ;)",
  "id" : 1384563721,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RAVI PRAKASH",
      "screen_name" : "rp09",
      "indices" : [ 0, 5 ],
      "id_str" : "546092743",
      "id" : 546092743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1384619384",
  "text" : "@rp09 Viel Erfolg bei der Fehlersuche auf jeden Fall!",
  "id" : 1384619384,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kcu",
      "screen_name" : "kcu",
      "indices" : [ 0, 4 ],
      "id_str" : "993991",
      "id" : 993991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1384635141",
  "geo" : { },
  "id_str" : "1384657595",
  "in_reply_to_user_id" : 993991,
  "text" : "@kcu Ausgezeichnet, gibt ein Flei\u00DF-K\u00E4rtchen. :)",
  "id" : 1384657595,
  "in_reply_to_status_id" : 1384635141,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "kcu",
  "in_reply_to_user_id_str" : "993991",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1380496563",
  "text" : "Ah das Profilbild hat sich \u00FCber Nacht aktualisiert. Guten Morgen Webdienste!",
  "id" : 1380496563,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1380635789",
  "text" : "In die Badewanne geh\u00FCpft, F\u00FC\u00DFe verbrannt, wieder rausgesprungen.",
  "id" : 1380635789,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 49, 57 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1380717208",
  "text" : "Wenn ich nicht v\u00F6llig daneben liege darf man dem @stelten heute alles gute zum Geburtstag w\u00FCnschen! Feier sch\u00F6n!",
  "id" : 1380717208,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1374695654",
  "text" : "Moin moin!",
  "id" : 1374695654,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1374801516",
  "text" : "Also das ist so eines der unsinnigsten Gadgets die ich je gesehen habe: http:\/\/is.gd\/ow6N",
  "id" : 1374801516,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Naurath",
      "screen_name" : "anaurath",
      "indices" : [ 0, 9 ],
      "id_str" : "17346698",
      "id" : 17346698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1374807541",
  "geo" : { },
  "id_str" : "1374831385",
  "in_reply_to_user_id" : 17346698,
  "text" : "@anaurath Ich kann mir nicht vorstellen das es von denen so viele gibt,vor allem sich dann noch trauen so ein h\u00E4ssliches Teil zu benutzen ;)",
  "id" : 1374831385,
  "in_reply_to_status_id" : 1374807541,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "anaurath",
  "in_reply_to_user_id_str" : "17346698",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1375018434",
  "text" : "Der Hund wird ja so schnell erwachsen. Nun f\u00E4ngt er an das Beinchen zum markieren zu heben.",
  "id" : 1375018434,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Max Henckel",
      "screen_name" : "mark_henckel",
      "indices" : [ 0, 13 ],
      "id_str" : "19586727",
      "id" : 19586727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375020199",
  "geo" : { },
  "id_str" : "1375046887",
  "in_reply_to_user_id" : 19586727,
  "text" : "@mark_henckel Der Papst ist daran schuld das sich auf seinen Wunsch hin nichts \u00E4ndert.",
  "id" : 1375046887,
  "in_reply_to_status_id" : 1375020199,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mark_henckel",
  "in_reply_to_user_id_str" : "19586727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick",
      "screen_name" : "U9TA",
      "indices" : [ 0, 5 ],
      "id_str" : "18407025",
      "id" : 18407025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375053336",
  "geo" : { },
  "id_str" : "1375064269",
  "in_reply_to_user_id" : 18407025,
  "text" : "@U9TA Ich glaube mehr er kommt nicht mit der Tatsache klar das die Bereiche in denen sie angeblich Kompetenz haben dahinschwinden.",
  "id" : 1375064269,
  "in_reply_to_status_id" : 1375053336,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "U9TA",
  "in_reply_to_user_id_str" : "18407025",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Max Henckel",
      "screen_name" : "mark_henckel",
      "indices" : [ 0, 13 ],
      "id_str" : "19586727",
      "id" : 19586727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375077554",
  "geo" : { },
  "id_str" : "1375092115",
  "in_reply_to_user_id" : 19586727,
  "text" : "@mark_henckel Was ist denn deiner Ansicht nach f\u00FCr die AIDS-Problematik verantwortlich?",
  "id" : 1375092115,
  "in_reply_to_status_id" : 1375077554,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mark_henckel",
  "in_reply_to_user_id_str" : "19586727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Max Henckel",
      "screen_name" : "mark_henckel",
      "indices" : [ 0, 13 ],
      "id_str" : "19586727",
      "id" : 19586727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375107490",
  "geo" : { },
  "id_str" : "1375114149",
  "in_reply_to_user_id" : 19586727,
  "text" : "@mark_henckel Du willst ernsthaft leugnen das die kath. Kirche mit ihrer Missionierung und Haltung zur Verh\u00FCtung nicht die Mitschuld tr\u00E4gt?",
  "id" : 1375114149,
  "in_reply_to_status_id" : 1375107490,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mark_henckel",
  "in_reply_to_user_id_str" : "19586727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Max Henckel",
      "screen_name" : "mark_henckel",
      "indices" : [ 0, 13 ],
      "id_str" : "19586727",
      "id" : 19586727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375125251",
  "geo" : { },
  "id_str" : "1375151685",
  "in_reply_to_user_id" : 19586727,
  "text" : "@mark_henckel Das zu leugnen und ins L\u00E4cherliche zu ziehen macht es bestimmt viel einfacher Katholik zu sein oder?",
  "id" : 1375151685,
  "in_reply_to_status_id" : 1375125251,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mark_henckel",
  "in_reply_to_user_id_str" : "19586727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Max Henckel",
      "screen_name" : "mark_henckel",
      "indices" : [ 0, 13 ],
      "id_str" : "19586727",
      "id" : 19586727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375151761",
  "geo" : { },
  "id_str" : "1375174015",
  "in_reply_to_user_id" : 19586727,
  "text" : "@mark_henckel Schau doch mal hier: http:\/\/is.gd\/owXp Das ist gef\u00E4hrlicher Unsinn den die kath. Crossdresser da verbreiten.",
  "id" : 1375174015,
  "in_reply_to_status_id" : 1375151761,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mark_henckel",
  "in_reply_to_user_id_str" : "19586727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick",
      "screen_name" : "U9TA",
      "indices" : [ 0, 5 ],
      "id_str" : "18407025",
      "id" : 18407025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375214254",
  "geo" : { },
  "id_str" : "1375220531",
  "in_reply_to_user_id" : 18407025,
  "text" : "@U9TA Und ich dachte immer es gilt: \u201CIrren ist menschlich. Aber wer richtigen Mist bauen will, braucht einen Computer. \u201D",
  "id" : 1375220531,
  "in_reply_to_status_id" : 1375214254,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "U9TA",
  "in_reply_to_user_id_str" : "18407025",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1375297349",
  "text" : "Gibt es eigentlich einen einfachen Weg Listenelemente in Python vorne anstatt hinten anzuh\u00E4ngen?",
  "id" : 1375297349,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "code",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1375366026",
  "text" : "Sieht nicht so aus, also die Listen umdrehen, anh\u00E4ngen und wieder umdrehen. Nicht sch\u00F6n aber selten. #code",
  "id" : 1375366026,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375826317",
  "geo" : { },
  "id_str" : "1375836579",
  "in_reply_to_user_id" : 11801332,
  "text" : "@kuechenhure Meinst du mit dem rechten Lautsprecher etwa das Mikrofon, rechts vom Dock-Connector? Das soll auch in der Tat leise sein :)",
  "id" : 1375836579,
  "in_reply_to_status_id" : 1375826317,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarioThiel",
  "in_reply_to_user_id_str" : "11801332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375901377",
  "geo" : { },
  "id_str" : "1375927116",
  "in_reply_to_user_id" : 11801332,
  "text" : "@kuechenhure Halt doch mal den Lautsprecher, links, zu. Dann wirst du merken das rechts eigentlich gar nichts rauskommt. :)",
  "id" : 1375927116,
  "in_reply_to_status_id" : 1375901377,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarioThiel",
  "in_reply_to_user_id_str" : "11801332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1375937159",
  "geo" : { },
  "id_str" : "1375949328",
  "in_reply_to_user_id" : 11801332,
  "text" : "@kuechenhure Dann halt links zu, h\u00F6re mal hin, halte dann zus\u00E4tzlich rechts zu und schau ob du einen Lautst\u00E4rkeunterschied merkst. :)",
  "id" : 1375949328,
  "in_reply_to_status_id" : 1375937159,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarioThiel",
  "in_reply_to_user_id_str" : "11801332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1375992096",
  "text" : "Irgendwie ist mein Kopf matsche, hab gerade fast eine halbe Stunde an einem viel zu einfachen Python-Problem gesessen, bisz um Geistesblitz.",
  "id" : 1375992096,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1376548621",
  "text" : "Sehr sch\u00F6n, der erste Teil meines Programms l\u00E4uft also mittlerweile fehlerfrei durch. Mehr geschafft als erwartet, weniger als erhofft.",
  "id" : 1376548621,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Smith",
      "screen_name" : "tilmar",
      "indices" : [ 3, 10 ],
      "id_str" : "2163562470",
      "id" : 2163562470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startcartoon",
      "indices" : [ 48, 61 ]
    }, {
      "text" : "killerspiele",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1376991840",
  "text" : "RT @TilMar: die titanic hats mal wieder erfasst #startcartoon #killerspiele http:\/\/titanic-magazin.de\/home.html",
  "id" : 1376991840,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1377152509",
  "text" : "Genug an der Kiste gesessen f\u00FCr heute.",
  "id" : 1377152509,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pfanni",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1377320122",
  "text" : "\u00DCbrigens sind Pfanni-Bratkartoffeln nicht zu empfehlen.Jeder der sie heute Mittag gegessen hat schl\u00E4gt sich mit Magenproblemen rum. #pfanni",
  "id" : 1377320122,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Sachs",
      "screen_name" : "fischimglas",
      "indices" : [ 0, 12 ],
      "id_str" : "15199614",
      "id" : 15199614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1377324258",
  "geo" : { },
  "id_str" : "1377335334",
  "in_reply_to_user_id" : 15199614,
  "text" : "@fischimglas ja da h\u00E4tte der gesunde Menschenverstand schon warnen m\u00FCssen. Allerdings hat der Zeitmangel gewonnen. War es nicht Wert.",
  "id" : 1377335334,
  "in_reply_to_status_id" : 1377324258,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "fischimglas",
  "in_reply_to_user_id_str" : "15199614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1377405969",
  "text" : "Fringe ist irgendwie X-Files f\u00FCr Arme oder?",
  "id" : 1377405969,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1377521961",
  "geo" : { },
  "id_str" : "1377543545",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ \u00DCberzeugt mich nicht die Serie. Will die Simpsons zur\u00FCck.",
  "id" : 1377543545,
  "in_reply_to_status_id" : 1377521961,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schmolk",
      "screen_name" : "anouphagos",
      "indices" : [ 0, 11 ],
      "id_str" : "368317316",
      "id" : 368317316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1377863203",
  "text" : "@anouphagos Wer ist eigentlich diese Internet-Generation? Die Kinder von heute kennen nur Sch\u00FClerVZ und vielleicht noch YouTube\/YouPorn.",
  "id" : 1377863203,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "Blogs",
      "indices" : [ 80, 86 ]
    }, {
      "text" : "Photography",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1377878052",
  "text" : "Just added myself to the http:\/\/wefollow.com twitter directory under:  #science #Blogs #Photography",
  "id" : 1377878052,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schmolk",
      "screen_name" : "anouphagos",
      "indices" : [ 0, 11 ],
      "id_str" : "368317316",
      "id" : 368317316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1377918436",
  "text" : "@anouphagos Ah okay, also sind damit ganz pr\u00E4zise alle und niemand erfasst.",
  "id" : 1377918436,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1377896856",
  "geo" : { },
  "id_str" : "1377932034",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion dann ist dein Rechner einfach zu alt, wandelst simultan Raw-&gt;JPEG um? :)",
  "id" : 1377932034,
  "in_reply_to_status_id" : 1377896856,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schmolk",
      "screen_name" : "anouphagos",
      "indices" : [ 0, 11 ],
      "id_str" : "368317316",
      "id" : 368317316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1377948250",
  "text" : "@anouphagos Na dann ergibt ja nun alles einen Sinn. Da bleibe ich dann auch bei den X-Files.",
  "id" : 1377948250,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1377957949",
  "geo" : { },
  "id_str" : "1377967949",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ne, aber das erkl\u00E4rt was deinen Rechner lahm legt. Sobald alles umgewandelt ist l\u00E4uft der Rechner wieder fixer.",
  "id" : 1377967949,
  "in_reply_to_status_id" : 1377957949,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1377957949",
  "geo" : { },
  "id_str" : "1377981585",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Und keine Angst, er wandelt alle Fotos als Batch um und l\u00E4dt es dabei schon hoch. Irgendwann l\u00E4dt er dann hoch ohne Konvertieren",
  "id" : 1377981585,
  "in_reply_to_status_id" : 1377957949,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schmolk",
      "screen_name" : "anouphagos",
      "indices" : [ 0, 11 ],
      "id_str" : "368317316",
      "id" : 368317316
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fringe",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1377985041",
  "text" : "@anouphagos Da hast du auch absolut recht. Und ich wei\u00DF auch nicht wie sie hei\u00DFt #fringe",
  "id" : 1377985041,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1377974203",
  "geo" : { },
  "id_str" : "1377991906",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion aber bei meinem alten Thinkpad hatte ich das gleiche Problem das der Rechner dann unbedienbar war.",
  "id" : 1377991906,
  "in_reply_to_status_id" : 1377974203,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1378002136",
  "geo" : { },
  "id_str" : "1378018041",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Spielst du auf die Kinofilme an? ;)",
  "id" : 1378018041,
  "in_reply_to_status_id" : 1378002136,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1378012830",
  "geo" : { },
  "id_str" : "1378029305",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Dann bist du noch gut dran. Ich konnte auf dem alten Rechner nichtmal mehr Surfen oder IMs Verschicken.",
  "id" : 1378029305,
  "in_reply_to_status_id" : 1378012830,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1378071998",
  "geo" : { },
  "id_str" : "1378084262",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Ich muss sagen gerade Lost fand ich ganz ganz grausam.",
  "id" : 1378084262,
  "in_reply_to_status_id" : 1378071998,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1378240465",
  "text" : "Ich mach nun Schluss mit Twitter f\u00FCr heute. Um das Profilbild k\u00FCmmere ich mich morgen.",
  "id" : 1378240465,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1371020146",
  "geo" : { },
  "id_str" : "1371040660",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Gibt es jede Menge in diesem Set bei Flickr: http:\/\/is.gd\/oqt4 So die letzten 20 Fotos oder so sind alle von ihm :)",
  "id" : 1371040660,
  "in_reply_to_status_id" : 1371020146,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1371061103",
  "geo" : { },
  "id_str" : "1371070945",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Das h\u00F6ren wir andauernd, bei allen Leuten geht er auf den ersten Blick als Labbi durch weil man den Schnauzer nicht sieht.",
  "id" : 1371070945,
  "in_reply_to_status_id" : 1371061103,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1371061103",
  "geo" : { },
  "id_str" : "1371073084",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Aber daf\u00FCr ist er dann zu schlank, wenn man einen Labrador daneben stehen sieht sind diese viel breiter und st\u00E4mmiger :)",
  "id" : 1371073084,
  "in_reply_to_status_id" : 1371061103,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1371298564",
  "text" : "Heute M\u00FCnster Tatort oder doch NCIS \/ The Mentalist? Schwierige Entscheidung. Wobei den Tatort kann man vermutlich auf Twitter nachlesen.",
  "id" : 1371298564,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1371308620",
  "geo" : { },
  "id_str" : "1371348769",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Naja bin eigentlich nicht so der gro\u00DFe Tatort-Fan, das w\u00E4re jetzt nur um wieder zu sehen wie unsere Uni verkleidet wird. ;)",
  "id" : 1371348769,
  "in_reply_to_status_id" : 1371308620,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Besimo",
      "screen_name" : "Besimo",
      "indices" : [ 0, 7 ],
      "id_str" : "15787781",
      "id" : 15787781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1371404406",
  "geo" : { },
  "id_str" : "1371416853",
  "in_reply_to_user_id" : 15787781,
  "text" : "@Besimo Ich denke auch das es das wird. Werd den Tatort halt nebenbei per Twitter verfolgen.",
  "id" : 1371416853,
  "in_reply_to_status_id" : 1371404406,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Besimo",
  "in_reply_to_user_id_str" : "15787781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1371504019",
  "text" : "Spiele gerade mit enfuse in Lightroom rum.",
  "id" : 1371504019,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1371628033",
  "text" : "Genug rumgespielt f\u00FCr heute, sieht aber sehr interessant aus. Jetzt TV.",
  "id" : 1371628033,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1372139444",
  "text" : "Ich bin \u00FCberrascht wie wenig heute \u00FCber den Tatort getwittert wurde, scheint also nicht so gut gewesen zu sein. ;)",
  "id" : 1372139444,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1372293375",
  "geo" : { },
  "id_str" : "1372342663",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU irgendwas muss auch aus Zeiten von BRD 1.0 noch h\u00E4ngen geblieben sein ;)",
  "id" : 1372342663,
  "in_reply_to_status_id" : 1372293375,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udo Vetter",
      "screen_name" : "udovetter",
      "indices" : [ 3, 13 ],
      "id_str" : "15998669",
      "id" : 15998669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1369759848",
  "text" : "RT @udovetter: Papst kritisiert afrikanischen \"Zauberglauben\". Wie gut, dass sein Gesch\u00E4ftsmodell v\u00F6llig anders ist. http:\/\/twurl.nl\/zusmc1",
  "id" : 1369759848,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1369784133",
  "geo" : { },
  "id_str" : "1369803861",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ist ja auch ein wchtiger Gesch\u00E4ftszweig von ihm, den kann man nicht einfach so den Schwarzen \u00FCberlassen...",
  "id" : 1369803861,
  "in_reply_to_status_id" : 1369784133,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1369816998",
  "text" : "Wieso ist es v\u00F6llig in Ordnung terminal kranke Tiere von ihrem Leid zu erl\u00F6sen und einzuschl\u00E4fern, aktive Sterbehilfe aber schlecht?",
  "id" : 1369816998,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1369867520",
  "geo" : { },
  "id_str" : "1369873879",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten Geht der Link nur bei mir nicht?",
  "id" : 1369873879,
  "in_reply_to_status_id" : 1369867520,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1369946424",
  "text" : "Jetzt geht es los zur Ausstellung.",
  "id" : 1369946424,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Zillig",
      "screen_name" : "Matthias_Zillig",
      "indices" : [ 0, 16 ],
      "id_str" : "15666442",
      "id" : 15666442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1369906927",
  "geo" : { },
  "id_str" : "1369957245",
  "in_reply_to_user_id" : 15666442,
  "text" : "@Matthias_Zillig Ja aber wieso erl\u00F6sen wir Tiere und verbieten es Menschen? Das ist doch inkonsequent.Oder ist der Tod nur f\u00FCr uns schlecht?",
  "id" : 1369957245,
  "in_reply_to_status_id" : 1369906927,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Matthias_Zillig",
  "in_reply_to_user_id_str" : "15666442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Zillig",
      "screen_name" : "Matthias_Zillig",
      "indices" : [ 0, 16 ],
      "id_str" : "15666442",
      "id" : 15666442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1370027194",
  "geo" : { },
  "id_str" : "1370095572",
  "in_reply_to_user_id" : 15666442,
  "text" : "@Matthias_Zillig vermutlich, diesen Irrglauben muss man vielleicht auch nicht verstehen.",
  "id" : 1370095572,
  "in_reply_to_status_id" : 1370027194,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Matthias_Zillig",
  "in_reply_to_user_id_str" : "15666442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1370097495",
  "text" : "Helmut Newton-Ausstellung fand ich Klasse. Picasso und ich werden aber wohl keine Freunde mehr.",
  "id" : 1370097495,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1370120713",
  "text" : "Familienbesuch kann auch ganz nett sein.",
  "id" : 1370120713,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Zillig",
      "screen_name" : "Matthias_Zillig",
      "indices" : [ 0, 16 ],
      "id_str" : "15666442",
      "id" : 15666442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1370140656",
  "geo" : { },
  "id_str" : "1370198050",
  "in_reply_to_user_id" : 15666442,
  "text" : "@Matthias_Zillig das hat mit weder noch zu tun, sondern am irrationalen Festhalten an \u00FCberlebten Dogmen.",
  "id" : 1370198050,
  "in_reply_to_status_id" : 1370140656,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Matthias_Zillig",
  "in_reply_to_user_id_str" : "15666442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1370783041",
  "text" : "Ich hab neue Daten zum Hund: 8 Monate alt, 27,5 kg schwer, 60 cm Schulterh\u00F6he. Riesenmonster :)",
  "id" : 1370783041,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grupetto.nl",
      "screen_name" : "Grupetto",
      "indices" : [ 0, 9 ],
      "id_str" : "202685746",
      "id" : 202685746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1370786306",
  "geo" : { },
  "id_str" : "1370793324",
  "in_reply_to_user_id" : 15182376,
  "text" : "@grupetto Naja bei dem Mischling ist die Wachstumsphase auch so variabel. Mal sehen wie lange er noch w\u00E4chst :)",
  "id" : 1370793324,
  "in_reply_to_status_id" : 1370786306,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "_catenaccio",
  "in_reply_to_user_id_str" : "15182376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Zillig",
      "screen_name" : "Matthias_Zillig",
      "indices" : [ 0, 16 ],
      "id_str" : "15666442",
      "id" : 15666442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1370795134",
  "geo" : { },
  "id_str" : "1370803926",
  "in_reply_to_user_id" : 15666442,
  "text" : "@Matthias_Zillig Ich glaube f\u00FCr die meisten hat das gar nichts mit Angst zu tun sondern ist einfach Reflex der nicht hinterfragt wird.",
  "id" : 1370803926,
  "in_reply_to_status_id" : 1370795134,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Matthias_Zillig",
  "in_reply_to_user_id_str" : "15666442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Zillig",
      "screen_name" : "Matthias_Zillig",
      "indices" : [ 0, 16 ],
      "id_str" : "15666442",
      "id" : 15666442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1370804063",
  "geo" : { },
  "id_str" : "1370819523",
  "in_reply_to_user_id" : 15666442,
  "text" : "@Matthias_Zillig Ich glaube daran das ich dann sterben sollen d\u00FCrfte wenn es mein Wille ist. Und nicht wenn irgendwelche Freaks es finden.",
  "id" : 1370819523,
  "in_reply_to_status_id" : 1370804063,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Matthias_Zillig",
  "in_reply_to_user_id_str" : "15666442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Zillig",
      "screen_name" : "Matthias_Zillig",
      "indices" : [ 0, 16 ],
      "id_str" : "15666442",
      "id" : 15666442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1370840360",
  "geo" : { },
  "id_str" : "1370855486",
  "in_reply_to_user_id" : 15666442,
  "text" : "@Matthias_Zillig Wie viele Gl\u00E4ubige hinterfragen denn ihren Glauben und sind nicht einfach $Mitglied weil sie so erzogen wurden? Promille...",
  "id" : 1370855486,
  "in_reply_to_status_id" : 1370840360,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "Matthias_Zillig",
  "in_reply_to_user_id_str" : "15666442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1370990936",
  "geo" : { },
  "id_str" : "1371011279",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Ist ein Mischling aus M\u00FCnsterl\u00E4nder und Schnauzer. :)",
  "id" : 1371011279,
  "in_reply_to_status_id" : 1370990936,
  "created_at" : "2009-03-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1363648869",
  "text" : "Dieses Internet find ich ja super, ohne h\u00E4tte ich nie Songs von Alela Diane geh\u00F6rt. \u2665 \u201CWhite As Diamonds\u201D & \u201CThe Rifle\u201D  http:\/\/is.gd\/ogEh",
  "id" : 1363648869,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1365258455",
  "text" : "Guten Mittag oder wie man sagt.",
  "id" : 1365258455,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1365260881",
  "geo" : { },
  "id_str" : "1365283411",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Was ist mit K\u00F6ster am Bahnhof? Online finde ich sonst pixxass recht g\u00FCnstig, schnell und vor allem zuverl\u00E4ssig.",
  "id" : 1365283411,
  "in_reply_to_status_id" : 1365260881,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Rau",
      "screen_name" : "Herr_Rau",
      "indices" : [ 0, 9 ],
      "id_str" : "15499762",
      "id" : 15499762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1365266629",
  "geo" : { },
  "id_str" : "1365284332",
  "in_reply_to_user_id" : 15499762,
  "text" : "@Herr_Rau Sehr gut, dann bin ich wenigstens nicht alleine damit.",
  "id" : 1365284332,
  "in_reply_to_status_id" : 1365266629,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "Herr_Rau",
  "in_reply_to_user_id_str" : "15499762",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UphillGirl",
      "screen_name" : "UphillGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "21393852",
      "id" : 21393852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1365300411",
  "geo" : { },
  "id_str" : "1365334634",
  "in_reply_to_user_id" : 21393852,
  "text" : "@UphillGirl Pass auf das du nicht runterf\u00E4llst :)",
  "id" : 1365334634,
  "in_reply_to_status_id" : 1365300411,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "UphillGirl",
  "in_reply_to_user_id_str" : "21393852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1365392045",
  "text" : "Wenn man den Hund per Fisheye fotografiert sollte man drauf achten wie nah man an der Schnauze ist. Darf nun Linsen von Sabber befreien.",
  "id" : 1365392045,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1365398153",
  "text" : "Die Alben von Alela Diane waren eine gute Investition, sehr entspanntes Singer-Songwriter-Zeugs. Ideal f\u00FCr den Samstag Vormittag zum chillen",
  "id" : 1365398153,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1366087325",
  "text" : "B\u00E4h, Windows XP http:\/\/twitpic.com\/2bb7p",
  "id" : 1366087325,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1366853013",
  "text" : "Ich glaube es ist kein Zufall das SATA und Satan sich nicht so weit von einander unterscheiden...",
  "id" : 1366853013,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "l4d",
      "indices" : [ 48, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1367257351",
  "text" : "Muss nach der Installorgie ein wenig Zombies in #l4d vom Untoten Dasein erl\u00F6sen.",
  "id" : 1367257351,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1367605741",
  "text" : "Nachdem der Letzte Versuch im Picassomuseum ja #fail war versuche ich es morgen nochmal.",
  "id" : 1367605741,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1367625988",
  "text" : "Wenn man irgendwo so zwischen zwei Lichtverh\u00E4ltnissen sitzt dann spinnt der Helligkeitssensor des MBP manchmal auf die \u00FCbelste Art und Weise",
  "id" : 1367625988,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha",
      "screen_name" : "radio_g",
      "indices" : [ 0, 8 ],
      "id_str" : "122664867",
      "id" : 122664867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367642027",
  "geo" : { },
  "id_str" : "1367655478",
  "in_reply_to_user_id" : 6899832,
  "text" : "@radio_g Hat man sich gerade an das Dunkle gew\u00F6hnt und bewegt sich einen halben Centimeter und schon ballert er auf max. Helligkeit *blend*",
  "id" : 1367655478,
  "in_reply_to_status_id" : 1367642027,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "inmichaelsworld",
  "in_reply_to_user_id_str" : "6899832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1367659434",
  "text" : "@houellebeck Dann h\u00E4tte ich schon lange ein Skript programmiert was eine ordentliche Zeitverz\u00F6gerung einbaut, allerdings ne gute Idee ;)",
  "id" : 1367659434,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367666557",
  "geo" : { },
  "id_str" : "1367683228",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Die Idee ist an sich gut,bei \u201Cregelm\u00E4ssigem Licht\u201D taugt es ja auch.Nur wenn man selbst zwischen Lichtquelle und Sensor sitzt nicht.",
  "id" : 1367683228,
  "in_reply_to_status_id" : 1367666557,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367693592",
  "geo" : { },
  "id_str" : "1367700012",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Also das passiert mir selten, greife ja so gut wie nie hinter das Display. :)",
  "id" : 1367700012,
  "in_reply_to_status_id" : 1367693592,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1367759095",
  "text" : "Hund und ich legen uns nun ins Bett. Heut wird das ja doch nix mehr.",
  "id" : 1367759095,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1367848840",
  "text" : "Der Hund ist unruhig, so wird das nichts mit schlafen.",
  "id" : 1367848840,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367834800",
  "geo" : { },
  "id_str" : "1367851978",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex In den neuen Macs ist der Sensor neben der iSight verbaut. Das ist schon ok.",
  "id" : 1367851978,
  "in_reply_to_status_id" : 1367834800,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367838165",
  "geo" : { },
  "id_str" : "1367860254",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex danke! :)",
  "id" : 1367860254,
  "in_reply_to_status_id" : 1367838165,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367870753",
  "geo" : { },
  "id_str" : "1367886885",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Oder einfach die Lichtquelle aus dem R\u00FCcken entfernen\/abschalten :)",
  "id" : 1367886885,
  "in_reply_to_status_id" : 1367870753,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367905101",
  "geo" : { },
  "id_str" : "1367920123",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz und taugt das was?",
  "id" : 1367920123,
  "in_reply_to_status_id" : 1367905101,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1367924488",
  "geo" : { },
  "id_str" : "1367957068",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Das ganze Zusatzzeug finde ich f\u00FCr simultanes Bearbeiten auch gar nicht so wichtig. Wenn das ordentlich geht ist das viel Wert.",
  "id" : 1367957068,
  "in_reply_to_status_id" : 1367924488,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1362187655",
  "geo" : { },
  "id_str" : "1362232752",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion wie schauts mit Lichtst\u00E4rke aus?",
  "id" : 1362232752,
  "in_reply_to_status_id" : 1362187655,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1362309062",
  "geo" : { },
  "id_str" : "1362321179",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Dann wird es aufs Gewicht ankommen und was du bereit bist Auszugeben ;)",
  "id" : 1362321179,
  "in_reply_to_status_id" : 1362309062,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1362345083",
  "geo" : { },
  "id_str" : "1362355985",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion 400 mehr? Was kostet es denn? :)",
  "id" : 1362355985,
  "in_reply_to_status_id" : 1362345083,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1362373883",
  "geo" : { },
  "id_str" : "1362396689",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion ah als Kit. W\u00FCrde ich auch das 200er nehmen. Hast du denn deine Liebste von der Investition \u00FCberzeugen k\u00F6nnen? :)",
  "id" : 1362396689,
  "in_reply_to_status_id" : 1362373883,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1362409088",
  "geo" : { },
  "id_str" : "1362463786",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion sehr sch\u00F6n, da bin ich ja mal gespannt auf das Spielzeug.",
  "id" : 1362463786,
  "in_reply_to_status_id" : 1362409088,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1362647234",
  "text" : "Wieso dauert es eigentlich noch 40 Minuten um die letzten 5% des Macbook-Akkus zu laden?",
  "id" : 1362647234,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1363036599",
  "text" : "Sagt mal kann man bei Eventbox gar nicht sehen auf welchen Tweet sich ein Reply bezieht?",
  "id" : 1363036599,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lens-flare.de",
      "screen_name" : "sgoethling",
      "indices" : [ 3, 14 ],
      "id_str" : "15704678",
      "id" : 15704678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1363058640",
  "text" : "RT @sgoethling: Weltkarte gef\u00E4llig? Bei http:\/\/www.united-domains.de gibbet dat f\u00FCr Blogger kostenlos: http:\/\/is.gd\/nLLL Fein!",
  "id" : 1363058640,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1363417617",
  "text" : "Wieso kann man bei Wordpress.com eigentlich nur YouTube & Google-Video einbinden? Blip.tv geht nicht obwohl es so viel toller ist...",
  "id" : 1363417617,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steffi",
      "screen_name" : "guerillagirl_",
      "indices" : [ 0, 14 ],
      "id_str" : "17117819",
      "id" : 17117819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1363427395",
  "geo" : { },
  "id_str" : "1363442402",
  "in_reply_to_user_id" : 17117819,
  "text" : "@guerillagirl_ Gut zu wissen, leider ist das Video was ich einbinden wollte nur bei blip.tv und das produziert genau gar nichts :(",
  "id" : 1363442402,
  "in_reply_to_status_id" : 1363427395,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "guerillagirl_",
  "in_reply_to_user_id_str" : "17117819",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1363468303",
  "geo" : { },
  "id_str" : "1363478443",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Das spricht nur f\u00FCr dich oder? :)",
  "id" : 1363478443,
  "in_reply_to_status_id" : 1363468303,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1359723077",
  "text" : "Na das ist doch mal ein super Feature von Gmail: Undo f\u00FCr den Mailversand http:\/\/is.gd\/o6xe",
  "id" : 1359723077,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iphone",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "twitter",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1359721796",
  "geo" : { },
  "id_str" : "1359725838",
  "in_reply_to_user_id" : 11801332,
  "text" : "@kuechenhure Glaubensfrage: Twitterfon oder Tweetie. Erste App ist allerdings kostenlos :) #iphone #twitter",
  "id" : 1359725838,
  "in_reply_to_status_id" : 1359721796,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarioThiel",
  "in_reply_to_user_id_str" : "11801332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iphone",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1359731574",
  "geo" : { },
  "id_str" : "1359741160",
  "in_reply_to_user_id" : 11801332,
  "text" : "@kuechenhure Tweetie hat daf\u00FCr das Landscape-Keyboard falls du das ben\u00F6tigen solltest, zeigt daf\u00FCr nicht die Anzahl neuer Tweets an. #iphone",
  "id" : 1359741160,
  "in_reply_to_status_id" : 1359731574,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "MarioThiel",
  "in_reply_to_user_id_str" : "11801332",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1359761191",
  "text" : "Das B\u00FCgeln eine Sportart ist habe ich bis gerade noch gar nicht gewusst, YouTube-Link http:\/\/is.gd\/9lqt",
  "id" : 1359761191,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1359801293",
  "geo" : { },
  "id_str" : "1359808829",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Daf\u00FCr springt Tweetie immer nach oben zum neusten Tweet oder kann man das umstellen?",
  "id" : 1359808829,
  "in_reply_to_status_id" : 1359801293,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1359834963",
  "geo" : { },
  "id_str" : "1359844282",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ah okay. Alternative Bilderdienste sind f\u00FCr mich nicht so wichtig. Und Instapaper auch nicht.",
  "id" : 1359844282,
  "in_reply_to_status_id" : 1359834963,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1359856939",
  "geo" : { },
  "id_str" : "1359870581",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr Mit den passenden Keywords k\u00F6nnte man also rausfinden wie das Wetter gerade ist ohne selbst nach drau\u00DFen schauen zu m\u00FCssen ;)",
  "id" : 1359870581,
  "in_reply_to_status_id" : 1359856939,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ms",
      "indices" : [ 103, 106 ]
    }, {
      "text" : "tweetup",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "twtvite",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1359961143",
  "text" : "RT @lorXsion: Wer sich es sich noch nicht notiert hat: MSTweetup, RSVP hier: http:\/\/twtvite.com\/4lovae #ms und #tweetup #twtvite",
  "id" : 1359961143,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetup",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360008988",
  "text" : "@dasblogt Finde ich auch, aber wir hatten einen twitvote gemacht um den besten Termin zu finden und das ist halt das Ergebnis. #tweetup",
  "id" : 1360008988,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360015399",
  "text" : "Gibt es eigentlich irgendwo eine \u00DCbersicht \u00FCber die Altersgruppen die Twitter nutzen?",
  "id" : 1360015399,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360017467",
  "text" : "@dasblogt Der lief auch Anfang letzten Monats schon irgendwann, vor der pl0gbar.",
  "id" : 1360017467,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "pop",
      "indices" : [ 58, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360033272",
  "text" : "Geek-Pop: Teilchen oder Welle? http:\/\/is.gd\/obe1 #science #pop",
  "id" : 1360033272,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360114930",
  "text" : "Bahn fahren ist schrecklich.",
  "id" : 1360114930,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360160990",
  "text" : "Regional-Express der H\u00F6lle: Strecke M\u00FCnster - Emden.",
  "id" : 1360160990,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360192753",
  "text" : "@houellebeck schwule Schlampen? Wollte da jemand unbedingt das Stilmittel Alliteration verwenden?",
  "id" : 1360192753,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360421691",
  "text" : "Gut wenn man Leute kennt die Vektorgrafiken basteln k\u00F6nnen. Denn irgendwie fehlt mir daf\u00FCr total die Motivation mich da einzuarbeiten.",
  "id" : 1360421691,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leander Wattig",
      "screen_name" : "leanderwattig",
      "indices" : [ 3, 17 ],
      "id_str" : "9739592",
      "id" : 9739592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360467291",
  "text" : "RT @leanderwattig: In Russland ist es Kriminellen offenbar gelungen, einen Trojaner in Bankautomaten einzuschleusen: http:\/\/is.gd\/oc1l",
  "id" : 1360467291,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Weschta",
      "screen_name" : "ThomasWe",
      "indices" : [ 0, 9 ],
      "id_str" : "18760008",
      "id" : 18760008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1360486644",
  "geo" : { },
  "id_str" : "1360493093",
  "in_reply_to_user_id" : 18760008,
  "text" : "@ThomasWe Du weisst doch, fr\u00FCher waren die Menschen viel kleiner. Also so ein antiker Trojaner passt da locker in den Geldautomaten :)",
  "id" : 1360493093,
  "in_reply_to_status_id" : 1360486644,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ThomasWe",
  "in_reply_to_user_id_str" : "18760008",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WN_Muenster",
      "screen_name" : "WN_Muenster",
      "indices" : [ 30, 42 ],
      "id_str" : "2542060171",
      "id" : 2542060171
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gntm",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1360527323",
  "geo" : { },
  "id_str" : "1360551813",
  "in_reply_to_user_id" : 17958972,
  "text" : "F\u00FCr Lokalpatriotismus wie die @WN_Muenster ihn f\u00FCr so ein bl\u00F6des Trashformat wie #gntm zeigt hab ich kein Verst\u00E4ndnis... http:\/\/is.gd\/ocbA",
  "id" : 1360551813,
  "in_reply_to_status_id" : 1360527323,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "WN_Redaktion",
  "in_reply_to_user_id_str" : "17958972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WN_Muenster",
      "screen_name" : "WN_Muenster",
      "indices" : [ 0, 12 ],
      "id_str" : "2542060171",
      "id" : 2542060171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1360527323",
  "geo" : { },
  "id_str" : "1360558651",
  "in_reply_to_user_id" : 17958972,
  "text" : "@WN_Muenster Abgesehen davon Ratio-Fail im Bild im Artikel...",
  "id" : 1360558651,
  "in_reply_to_status_id" : 1360527323,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "WN_Redaktion",
  "in_reply_to_user_id_str" : "17958972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1360644145",
  "geo" : { },
  "id_str" : "1360660819",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster Wieso glaube ich dir das nur sofort? Aber Man muss ja nicht immer nur nachtreten, die sind schon genug gestraft ;)",
  "id" : 1360660819,
  "in_reply_to_status_id" : 1360644145,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360751833",
  "text" : "Mh Facebook mit in Eventbox zu laden ist Unsinn, das einzige was da passiert sind Statusupdates von Leuten die ihren Twitterfeed importieren",
  "id" : 1360751833,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1360917584",
  "text" : "Morgen darf ich wieder ein Thinkpad installieren, lade jetzt schonmal alle ben\u00F6tigten Treiber runter.",
  "id" : 1360917584,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1360925310",
  "geo" : { },
  "id_str" : "1360936065",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja, aber hey, solange die Bezahlung stimmt geht das schon.",
  "id" : 1360936065,
  "in_reply_to_status_id" : 1360925310,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1360957846",
  "geo" : { },
  "id_str" : "1360961557",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja und davon wollte ich mir dann 1-2 Banken kaufen hatte ich so \u00FCberlegt",
  "id" : 1360961557,
  "in_reply_to_status_id" : 1360957846,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1360976975",
  "geo" : { },
  "id_str" : "1361005158",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod: Deren Immobilien vielleicht noch",
  "id" : 1361005158,
  "in_reply_to_status_id" : 1360976975,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1361076431",
  "text" : "So das d\u00FCrften alle Treiber sein, XP liegt ja schon mit SP2 vor. Dann kann es ja auch nicht so lange dauern..",
  "id" : 1361076431,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WN_Muenster",
      "screen_name" : "WN_Muenster",
      "indices" : [ 0, 12 ],
      "id_str" : "2542060171",
      "id" : 2542060171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1361254770",
  "geo" : { },
  "id_str" : "1361292715",
  "in_reply_to_user_id" : 17958972,
  "text" : "@WN_Muenster Ich find es einfach albern. Nur weil sie zuf\u00E4llig M\u00FCnsteranerin ist und sich f\u00FCr so einen Mist verkauft jetzt Werbung zu machen",
  "id" : 1361292715,
  "in_reply_to_status_id" : 1361254770,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "WN_Redaktion",
  "in_reply_to_user_id_str" : "17958972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1361388382",
  "geo" : { },
  "id_str" : "1361677565",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster das passiert aber nicht in M\u00FCnster. Und niemand k\u00E4me auf die Idee alle Amstettener zu verabscheuen wegen eines B\u00FCrgers.",
  "id" : 1361677565,
  "in_reply_to_status_id" : 1361388382,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1361388382",
  "geo" : { },
  "id_str" : "1361681458",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster Bei vermeintlich positiven Dingen ist es aber immer gleich \u201EUnser\u201C.",
  "id" : 1361681458,
  "in_reply_to_status_id" : 1361388382,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1361808748",
  "text" : "Der -tv-Beitrag spricht wirklich B\u00E4nde,auch wie angenervt der Interviewte ist,\u201Edas k\u00F6nnen sie ja bestimmt recherchieren\u201C tinyurl.com\/djldj5",
  "id" : 1361808748,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pizza",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1361834688",
  "geo" : { },
  "id_str" : "1361850259",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Das sieht gut aus, besonders die rechte H\u00E4lfte :) #pizza",
  "id" : 1361850259,
  "in_reply_to_status_id" : 1361834688,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "todesstrafe",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1361867272",
  "text" : "@houellebeck Kennst du \u201CDie Werw\u00F6lfe von D\u00FCsterwald\u201D? Unseren B\u00FCrgermeistern ergeht es dabei auch immer so \u00E4hnlich. #todesstrafe ;)",
  "id" : 1361867272,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1361866385",
  "geo" : { },
  "id_str" : "1361871376",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Bin kein Vegetarier, stehe aber sehr auf vegetarische Gerichte :)",
  "id" : 1361871376,
  "in_reply_to_status_id" : 1361866385,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1361893965",
  "geo" : { },
  "id_str" : "1361949446",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Das hatte ich gestern mit dem Burger im PierHouse",
  "id" : 1361949446,
  "in_reply_to_status_id" : 1361893965,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1362008505",
  "text" : "@dasblogt Absolut, wir spielen es mit unserer Pfadfindergruppe fast jede Woche ;)",
  "id" : 1362008505,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick",
      "screen_name" : "U9TA",
      "indices" : [ 0, 5 ],
      "id_str" : "18407025",
      "id" : 18407025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1361987049",
  "geo" : { },
  "id_str" : "1362015467",
  "in_reply_to_user_id" : 18407025,
  "text" : "@U9TA M\u00FCssten dann nicht konsequenterweise Ostdeutsche Fahrer einen riesen Vorteil haben?",
  "id" : 1362015467,
  "in_reply_to_status_id" : 1361987049,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "U9TA",
  "in_reply_to_user_id_str" : "18407025",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1362065806",
  "text" : "Jurassic Park l\u00E4uft offensichtlich im TV, hab das Theme doch gleich erkannt.",
  "id" : 1362065806,
  "created_at" : "2009-03-20 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1355525507",
  "text" : "Hilfe, Vektorgrafiken \u00FCberfordern mich total!",
  "id" : 1355525507,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1355551840",
  "text" : "@dasblogt Sieht so aus. :)",
  "id" : 1355551840,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355544990",
  "geo" : { },
  "id_str" : "1355556591",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ja das w\u00E4re sicherlich nett geworden. Aber so nat\u00FCrlich erstmal gute Besserung. Die n\u00E4chste #pl0gbar kommt ja bestimmt :)",
  "id" : 1355556591,
  "in_reply_to_status_id" : 1355544990,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1355867240",
  "text" : "Mach mich dann auf den Weg zur #pl0gbar.",
  "id" : 1355867240,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1356856809",
  "text" : "So wieder zuhause von der #pl0gbar Habt ihr das Internet in der Zwischenzeit brav stehen lassen?",
  "id" : 1356856809,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355937090",
  "geo" : { },
  "id_str" : "1356859853",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Gerne, hast du nochmal den Link zum Invite? :)",
  "id" : 1356859853,
  "in_reply_to_status_id" : 1355937090,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1356895326",
  "geo" : { },
  "id_str" : "1356903400",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Manchmal haben wir auch andere Themen drauf als Apple-Produkte :)",
  "id" : 1356903400,
  "in_reply_to_status_id" : 1356895326,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1356914270",
  "geo" : { },
  "id_str" : "1356926546",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Das Mobilfunknetz im Pierhouse ist ja leider so schlecht. Und das \u201Coffene\u201D W-LAN war auch nicht so der hit ;)",
  "id" : 1356926546,
  "in_reply_to_status_id" : 1356914270,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1356942001",
  "geo" : { },
  "id_str" : "1356995961",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Normales Mobilfunknetz w\u00FCrd ja reichen, aber da hat man wenn man am Fenster sitzt im Pierhouse bessere Chancen :)",
  "id" : 1356995961,
  "in_reply_to_status_id" : 1356942001,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1357005662",
  "geo" : { },
  "id_str" : "1357012796",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Macht ja auch nix, so abh\u00E4ngig bin zumindest ich nicht von Twitter das nicht mal 3 Stunden ohne gehen w\u00FCrden.",
  "id" : 1357012796,
  "in_reply_to_status_id" : 1357005662,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1357104353",
  "geo" : { },
  "id_str" : "1357117861",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Das virale mit dem DIY-Anbau find ich super :)",
  "id" : 1357117861,
  "in_reply_to_status_id" : 1357104353,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1357392753",
  "text" : "Carl Zimmer mit einem Vortrag \u00FCber die Evolution der Evolution, h\u00F6rt sich gut an, werd ich nun schauen http:\/\/is.gd\/o6q6",
  "id" : 1357392753,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353361721",
  "text" : "Ich muss einfach nochmal drauf hinweisen: Semesterferien sind so was sch\u00F6nes. Schade das es im BA\/MA-System fast keine mehr gibt.",
  "id" : 1353361721,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 3, 11 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353380712",
  "text" : "RT @JoergFr: Suche immernoch dringend f\u00FCr einen Access-Einsteiger-Kurs am 24.-25. M\u00E4rz in M\u00FCnster einen guten Trainer. Kann jemand helfen?",
  "id" : 1353380712,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353464447",
  "text" : "Wieso followen mir Menschen die ausschliesslich in Fern\u00F6stlichen Schrifts\u00E4tzen twittern?",
  "id" : 1353464447,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353512263",
  "text" : "@houellebeck Das beste ist wie Ralph P. wahllos auf der Tastatur rumpresst damit es ja sch\u00F6n laut ist. :)",
  "id" : 1353512263,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353558904",
  "text" : "RT @stern_mobile: Sende jetzt STERN2 an die 123456 f\u00FCr praktische und kostenlose Werbung f\u00FCr uns und unsere seltsame iPhone-App.",
  "id" : 1353558904,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353636434",
  "text" : "Zeit ein bisschen mit dem Hund zu spielen und rauszugehen.",
  "id" : 1353636434,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353672111",
  "text" : "Ganz guter Beitrag \u00FCber die Berichterstattungen beim Amoklauf. Solche Kameraleute\/Fotografen sind der Hit...  http:\/\/bit.ly\/WJPPG",
  "id" : 1353672111,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353738382",
  "text" : "Twitterpremium-Accounts sind die neuen 4chan-Goldmemberships.",
  "id" : 1353738382,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Peel",
      "screen_name" : "EmmaPeel_",
      "indices" : [ 0, 10 ],
      "id_str" : "17408013",
      "id" : 17408013
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "premiumaccounts",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1353747643",
  "geo" : { },
  "id_str" : "1353750995",
  "in_reply_to_user_id" : 17408013,
  "text" : "@emmapeel_ Ja, das gleiche gilt auch f\u00FCr 4chan. :) #premiumaccounts",
  "id" : 1353750995,
  "in_reply_to_status_id" : 1353747643,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "EmmaPeel_",
  "in_reply_to_user_id_str" : "17408013",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353785518",
  "text" : "\u201CNun sind ja viele Wissenschaftler eitle Leute[...]\u201D Ist mir noch gar nicht aufgefallen, auch m\u00F6gen die meisten Kritik  http:\/\/bit.ly\/4fUGdM",
  "id" : 1353785518,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1353828268",
  "geo" : { },
  "id_str" : "1353834946",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih Ist doch auch ganz gut f\u00FCr die Gesundheit. Freu dich dr\u00FCber :)",
  "id" : 1353834946,
  "in_reply_to_status_id" : 1353828268,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353901409",
  "text" : "@JoergR Python ftw! :)",
  "id" : 1353901409,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1353995569",
  "geo" : { },
  "id_str" : "1354001873",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Hat halt das falshce Bajonett das Teil :)",
  "id" : 1354001873,
  "in_reply_to_status_id" : 1353995569,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1354024997",
  "geo" : { },
  "id_str" : "1354034317",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ne, mit meinen Bodies bin ich ganz zufrieden, aber das Glas ist fein was du da hast :)",
  "id" : 1354034317,
  "in_reply_to_status_id" : 1354024997,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354071147",
  "text" : "Hab TweetDeck verbannt und bin auf EventBox umgestiegen. Das HUD find ich sehr praktisch.",
  "id" : 1354071147,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick",
      "screen_name" : "U9TA",
      "indices" : [ 0, 5 ],
      "id_str" : "18407025",
      "id" : 18407025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1354079406",
  "geo" : { },
  "id_str" : "1354084222",
  "in_reply_to_user_id" : 18407025,
  "text" : "@U9TA Gef\u00E4hrlich ist auch mit Tabasco an den H\u00E4nden sich die Augen zu reiben.",
  "id" : 1354084222,
  "in_reply_to_status_id" : 1354079406,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "U9TA",
  "in_reply_to_user_id_str" : "18407025",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick",
      "screen_name" : "U9TA",
      "indices" : [ 0, 5 ],
      "id_str" : "18407025",
      "id" : 18407025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1354091651",
  "geo" : { },
  "id_str" : "1354096009",
  "in_reply_to_user_id" : 18407025,
  "text" : "@U9TA Na dann hast du ja nochmal Gl\u00FCck gehabt.",
  "id" : 1354096009,
  "in_reply_to_status_id" : 1354091651,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "U9TA",
  "in_reply_to_user_id_str" : "18407025",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1354138931",
  "geo" : { },
  "id_str" : "1354147145",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Na TweetDeck ist ja cross-Plattform. Ich warte halt noch auf den ganz gro\u00DFen Wurf, solange bastel ich weiter am eigenen Client.",
  "id" : 1354147145,
  "in_reply_to_status_id" : 1354138931,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1354143317",
  "geo" : { },
  "id_str" : "1354150153",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Genau das. Finde ich sehr praktisch, auf jedenfall praktischer als die single-column-view von TweetDeck weil Bunt f\u00FCr DM, Reply etc.",
  "id" : 1354150153,
  "in_reply_to_status_id" : 1354143317,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354196214",
  "text" : "@dasblogt Die muss man irgendwo auf der T-Mobile-Seite beantragen und bekommt man dann zugesmst so weit ich weiss.",
  "id" : 1354196214,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354209786",
  "text" : "@dasblogt \u201CEinfach eine SMS mit dem Text \"OPEN\" an die Kurzwahl 9526 und Sie erhalten per SMS Benutzername und Passwort.\u201D",
  "id" : 1354209786,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1354198042",
  "geo" : { },
  "id_str" : "1354215808",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Hab ich auch ausprobiert, fand ich aber im Endeffekt nicht \u00FCberzeugend.",
  "id" : 1354215808,
  "in_reply_to_status_id" : 1354198042,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354217149",
  "text" : "@dasblogt http:\/\/tinyurl.com\/cnncaa ist der Link dazu.",
  "id" : 1354217149,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 0, 9 ],
      "id_str" : "281703380",
      "id" : 281703380
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 25, 33 ]
    }, {
      "text" : "muenster",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354251606",
  "text" : "@dasblogt Ich bin dabei. #pl0gbar #muenster",
  "id" : 1354251606,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354256878",
  "text" : "Ah gerade rausgefunden wie man URLs k\u00FCrzen kann bei Eventbox.",
  "id" : 1354256878,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1354267230",
  "geo" : { },
  "id_str" : "1354627121",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Genau das geht mit Eventbox auch, was ich sehr angenehm finde.",
  "id" : 1354627121,
  "in_reply_to_status_id" : 1354267230,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1354456888",
  "geo" : { },
  "id_str" : "1354635606",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion St\u00E4rkt bestimmt das Immunsystem ;)",
  "id" : 1354635606,
  "in_reply_to_status_id" : 1354456888,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dreck",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354681468",
  "text" : "Nachdem ich mit dem Hund drau\u00DFen war und obwohl es v\u00F6llig trocken ist darf ich mich gleich umziehen. #dreck",
  "id" : 1354681468,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354698622",
  "text" : "Gerade zum ersten mal seit langem auf scienceblogs.de gewesen. Sieht mit Adblock ja grausig aus, alles ca. 800 px nach rechts verschoben.",
  "id" : 1354698622,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1354904538",
  "text" : "\u201COnce again, crazy PETA-Lady\u201D: http:\/\/is.gd\/o1E3",
  "id" : 1354904538,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1355255180",
  "text" : "Also mir zeigt Eventbox gar keine Icons mehr an. Ist Twitter immer noch broken?",
  "id" : 1355255180,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355342658",
  "geo" : { },
  "id_str" : "1355405899",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Was ist mit @LorXsion?",
  "id" : 1355405899,
  "in_reply_to_status_id" : 1355342658,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 0, 15 ],
      "id_str" : "645353",
      "id" : 645353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355418657",
  "geo" : { },
  "id_str" : "1355428730",
  "in_reply_to_user_id" : 645353,
  "text" : "@unimatrixZxero Ist gerade bei mir angekommen. Na denn halt n\u00E4chsten Monat w\u00FCrd ich sagen. Wobei wie sieht es mit dem Tweetup aus? #pl0gbar",
  "id" : 1355428730,
  "in_reply_to_status_id" : 1355418657,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "unimatrixZxero",
  "in_reply_to_user_id_str" : "645353",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355408485",
  "geo" : { },
  "id_str" : "1355434105",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Na wie es mit dir aussieht in Sachen pl0gbar war die Frage, da Twitter gerade rumspinnt hab ich deine Antwort nicht so gefunden :)",
  "id" : 1355434105,
  "in_reply_to_status_id" : 1355408485,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 0, 10 ],
      "id_str" : "1024351",
      "id" : 1024351
    }, {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 11, 23 ],
      "id_str" : "107803659",
      "id" : 107803659
    }, {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 68, 79 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355435741",
  "geo" : { },
  "id_str" : "1355449526",
  "in_reply_to_user_id" : 1024351,
  "text" : "@Labuschin @houellebeck hat auch abgesagt. W\u00E4re damit dann nur noch @chris2newz fraglich",
  "id" : 1355449526,
  "in_reply_to_status_id" : 1355435741,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "Labuschin",
  "in_reply_to_user_id_str" : "1024351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    }, {
      "name" : "Martin Labuschin",
      "screen_name" : "Labuschin",
      "indices" : [ 25, 35 ],
      "id_str" : "1024351",
      "id" : 1024351
    }, {
      "name" : "Sam Figueroa",
      "screen_name" : "unimatrixZxero",
      "indices" : [ 36, 51 ],
      "id_str" : "645353",
      "id" : 645353
    }, {
      "name" : "Kristof Dreier",
      "screen_name" : "dasblogt",
      "indices" : [ 52, 61 ],
      "id_str" : "281703380",
      "id" : 281703380
    }, {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 72, 83 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355452358",
  "geo" : { },
  "id_str" : "1355463833",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu Ok, dann w\u00E4ren wir @Labuschin @unimatrixZxero @dasblogt eventuell @chris2newz  und sowohl deine als auch meine Wenigkeit. Frage:Ja\/N\u00F6?",
  "id" : 1355463833,
  "in_reply_to_status_id" : 1355452358,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    }, {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 12, 17 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355478082",
  "geo" : { },
  "id_str" : "1355490620",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz @balu Na dann komm ich auch auf jedenfall. Spart mir auch das Kochen zuhause. iPhone & CC-Shirt sind Erkennungsmerkmal ;)",
  "id" : 1355490620,
  "in_reply_to_status_id" : 1355478082,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian M.",
      "screen_name" : "chris2newz",
      "indices" : [ 0, 11 ],
      "id_str" : "15479389",
      "id" : 15479389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1355510493",
  "geo" : { },
  "id_str" : "1355521178",
  "in_reply_to_user_id" : 15479389,
  "text" : "@chris2newz Na dann d\u00FCrfte es ja nicht zu schwierig sein dich zu finden. :) #pl0gbar",
  "id" : 1355521178,
  "in_reply_to_status_id" : 1355510493,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "chris2newz",
  "in_reply_to_user_id_str" : "15479389",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1347896493",
  "geo" : { },
  "id_str" : "1347932326",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih Was f\u00FCr ein Hund ist es denn?",
  "id" : 1347932326,
  "in_reply_to_status_id" : 1347896493,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unfug",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1347936584",
  "text" : "Wer verpackt denn gesplittete RAR-Dateien bittesch\u00F6n in einer gro\u00DFen RAR-Datei? #unfug",
  "id" : 1347936584,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1348010176",
  "geo" : { },
  "id_str" : "1348079512",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih Sieht auch sehr kr\u00E4ftig aus. Macht bestimmt Spa\u00DF mit ihm drau\u00DFen :)",
  "id" : 1348079512,
  "in_reply_to_status_id" : 1348010176,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Grosskopf",
      "screen_name" : "peterlih",
      "indices" : [ 0, 9 ],
      "id_str" : "7340442",
      "id" : 7340442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1348094560",
  "geo" : { },
  "id_str" : "1348131196",
  "in_reply_to_user_id" : 7340442,
  "text" : "@peterlih Das kommt mir von meinem bekannt vor.Wenn der will zieht der einen auch durch die Landschaft.M\u00FCsste man mal mit Rollschuhen testen",
  "id" : 1348131196,
  "in_reply_to_status_id" : 1348094560,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "peterlih",
  "in_reply_to_user_id_str" : "7340442",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Walker",
      "screen_name" : "ihatemornings",
      "indices" : [ 3, 17 ],
      "id_str" : "5172361",
      "id" : 5172361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1348196253",
  "text" : "RT @ihatemornings: Yes, I understand how ridiculous it is that I'm linking to this on Twitter. But it's ridiculously funny.http:\/\/is.gd\/nCvV",
  "id" : 1348196253,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "schmerzlassnach",
      "indices" : [ 109, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1348381407",
  "text" : "Sch\u00F6n wenn der Hund sich freut und Luftspr\u00FCnge macht. Aber ob er mir ausversehen fast die Nase brechen muss? #schmerzlassnach",
  "id" : 1348381407,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1349086794",
  "text" : "Werd mal versuchen meine Python-Sachen mit PyObjC mit einem Mac-GUI auszustatten...",
  "id" : 1349086794,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitterFon",
      "screen_name" : "TwitterFon",
      "indices" : [ 0, 11 ],
      "id_str" : "15613175",
      "id" : 15613175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1349617830",
  "in_reply_to_user_id" : 15613175,
  "text" : "@Twitterfon as a Mac-Application would be great...",
  "id" : 1349617830,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "TwitterFon",
  "in_reply_to_user_id_str" : "15613175",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1350332951",
  "text" : "@houellebeck Ah da muss ich dich doch gleich mal adden :)",
  "id" : 1350332951,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1350895637",
  "text" : "Yeah, der Hund f\u00E4ngt endlich an das Bein zu heben beim Pinkeln. Sie werden ja so schnell erwachsen!",
  "id" : 1350895637,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1351071367",
  "text" : "Marley & Ich gesehen. Knuffig und am Ende so kitschig traurig, verstehen wohl nur Hundebesitzer.",
  "id" : 1351071367,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1351096885",
  "text" : "Die teuerste Fl\u00FCssigkeit der Welt. Alt aber gut.  http:\/\/tinyurl.com\/28yv7a",
  "id" : 1351096885,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1347545452",
  "text" : "Auf einmal tauchen DMs hier auf die schon etwas \u00E4lter sind. Schluckauf?",
  "id" : 1347545452,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1347562819",
  "text" : "Probiere gerade Typinator aus. Sieht so weit ganz praktisch aus. Besonders zum coden.",
  "id" : 1347562819,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1347616721",
  "text" : "Der Hund hat \u00FCber das Trackpad geleckt und damit Expos\u00E9 ausgel\u00F6st, interessant.",
  "id" : 1347616721,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1347657888",
  "text" : "Sch\u00F6ner Post \u00FCber den Idioten in Robe der sich Papst nennt:  http:\/\/tinyurl.com\/cphwem",
  "id" : 1347657888,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathrin Futter",
      "screen_name" : "prozimsun",
      "indices" : [ 0, 10 ],
      "id_str" : "17944376",
      "id" : 17944376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1347704625",
  "geo" : { },
  "id_str" : "1347710499",
  "in_reply_to_user_id" : 17944376,
  "text" : "@prozimsun Ich hab NNW f\u00FCrs iPhone auch gar nicht verstanden, irgendwie kam mir das sehr fehlerhaft vor.",
  "id" : 1347710499,
  "in_reply_to_status_id" : 1347704625,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "prozimsun",
  "in_reply_to_user_id_str" : "17944376",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1347819165",
  "text" : "\u201CCharging phones, pods and other gadgets each have their own signature luminescence.\u201D LED-Wahnsinn, kennt wohl jeder http:\/\/bit.ly\/19yyb9",
  "id" : 1347819165,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1347850045",
  "geo" : { },
  "id_str" : "1347890558",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Das passiert halt wenn man nicht mit der Zeit geht und noch ein Weltbild aus dem Mittelalter vertritt.",
  "id" : 1347890558,
  "in_reply_to_status_id" : 1347850045,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341682860",
  "text" : "Manche Programmierer muss man einfach Auslachen f\u00FCr den Mist den sie verzapfen. Sucht euch aber. Bitte einen anderen Job. Schnell.",
  "id" : 1341682860,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1341717912",
  "geo" : { },
  "id_str" : "1341732350",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 d\u00FCrfte die beste L\u00F6sung sein.",
  "id" : 1341732350,
  "in_reply_to_status_id" : 1341717912,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341748881",
  "text" : "Datenbank-\u201CL\u00F6sung\u201D bei Idioten: Server mit Windows an DSL-Leitung auf den per Remotedesktop zugegriffen wird...  Das war nie nie nie klug..",
  "id" : 1341748881,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1341759652",
  "geo" : { },
  "id_str" : "1341763837",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr Ich tippe ja auf kostenpflichtige Zusatzfunktionen wie unbegrenzt API-Zugriffe etc.",
  "id" : 1341763837,
  "in_reply_to_status_id" : 1341759652,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPhone",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341979810",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent MMS sind zumindest f\u00FCr mich v\u00F6llig \u00FCberfl\u00FCssig. Ich hab bestimmt 6 Jahren lang die M\u00F6glichkeit gehabt und nie genutzt #iPhone",
  "id" : 1341979810,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 8, 16 ]
    }, {
      "text" : "muenster",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1342149690",
  "text" : "Auf der #pl0gbar Eventseite sieht es ja bislang noch leer aus f\u00FCr #muenster am Donnerstag.",
  "id" : 1342149690,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1342189975",
  "text" : "@houellebeck Sind die Menschen jetzt schon zu faul geworden die passenden Wiki-Artikel zu lesen?",
  "id" : 1342189975,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "einAnfang",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1342208587",
  "text" : "@houellebeck Hatte ich auch vor kurzem, da wollte jemand einfache Schulbio erkl\u00E4rt haben, hab dann erfolgreich Wikilinks gespammt #einAnfang",
  "id" : 1342208587,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 0, 12 ],
      "id_str" : "428633",
      "id" : 428633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fotoquiz",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1342245970",
  "geo" : { },
  "id_str" : "1342282155",
  "in_reply_to_user_id" : 428633,
  "text" : "@kwerfeldein Die Brennweite h\u00E4ngt von Wellenl\u00E4nge\/Farbe des Lichts ab. Dadurch entstehen bei fehlerhafter Korrektur Farbr\u00E4nder. #Fotoquiz",
  "id" : 1342282155,
  "in_reply_to_status_id" : 1342245970,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "kwerfeldein",
  "in_reply_to_user_id_str" : "428633",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1342285747",
  "geo" : { },
  "id_str" : "1342305561",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr Informationen sind das moderne Gold.",
  "id" : 1342305561,
  "in_reply_to_status_id" : 1342285747,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1342305815",
  "geo" : { },
  "id_str" : "1342319588",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Klar, wie super das mit Enthaltsamkeit funktioniert sieht man ja in den USA. Schwangere Teenies & STDs haupts\u00E4chlich im Biblebelt...",
  "id" : 1342319588,
  "in_reply_to_status_id" : 1342305815,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343067606",
  "geo" : { },
  "id_str" : "1343127785",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Nat\u00FCrlich nicht... Weil Kinder vorehelichen Sex dann nicht verheimlichen und nicht zum Arzt gehen...",
  "id" : 1343127785,
  "in_reply_to_status_id" : 1343067606,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343162878",
  "text" : "Und wird die Keynote heute wieder Twitter kaputt machen?",
  "id" : 1343162878,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343173470",
  "geo" : { },
  "id_str" : "1343178486",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Du weisst schon was ich meine :)",
  "id" : 1343178486,
  "in_reply_to_status_id" : 1343173470,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343188206",
  "geo" : { },
  "id_str" : "1343192907",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Genau das, dabei wird doch jeder den es interessiert die Ticker verfolgen ;)",
  "id" : 1343192907,
  "in_reply_to_status_id" : 1343188206,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343364447",
  "text" : "Push Notification-Dienst und Turn-By-Turn-Navigation. Schonmal 2 gute Sachen.",
  "id" : 1343364447,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343418424",
  "geo" : { },
  "id_str" : "1343438256",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Jetzt bitte noch C&P dann geb ich Ruhe ;)",
  "id" : 1343438256,
  "in_reply_to_status_id" : 1343418424,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micha",
      "screen_name" : "radio_g",
      "indices" : [ 0, 8 ],
      "id_str" : "122664867",
      "id" : 122664867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343492884",
  "geo" : { },
  "id_str" : "1343504049",
  "in_reply_to_user_id" : 6899832,
  "text" : "@radio_g Vermutlich nur heute: St. Paddy's Day",
  "id" : 1343504049,
  "in_reply_to_status_id" : 1343492884,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "inmichaelsworld",
  "in_reply_to_user_id_str" : "6899832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343546096",
  "text" : "Yeah! C&P kommt endlich.",
  "id" : 1343546096,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    }, {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 80, 87 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343556351",
  "geo" : { },
  "id_str" : "1343563309",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Ich hatte gedacht meine TImeline w\u00FCrde vollgespammt worden, aber au\u00DFer @ComPod twittert bei mir gerade niemand \u00FCber OS 3.0. :)",
  "id" : 1343563309,
  "in_reply_to_status_id" : 1343556351,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343576297",
  "geo" : { },
  "id_str" : "1343588488",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Nichts zu entschuldigen, ich freu mich ja das ich nicht ganz alleine bin ohne das es gleich der \u00DCberspam ist.",
  "id" : 1343588488,
  "in_reply_to_status_id" : 1343576297,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343598151",
  "text" : "Ah, endlich das Landscape-Keyboard in allen Apple-Apps. Mail ftw!",
  "id" : 1343598151,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343635282",
  "text" : "Suche in Kalender & Mail. Noch etwas was mein Leben einfacher macht.",
  "id" : 1343635282,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343708856",
  "text" : "Vorbei. Aber auch lustig wie sich gro\u00DFe Jungs \u00FCber Funktionen wie C&P freuen k\u00F6nnen die sonst zum Standard geh\u00F6ren.",
  "id" : 1343708856,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343718709",
  "geo" : { },
  "id_str" : "1343729560",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Geschickte Marketingstrategie eigentlich von Apple. Basisfeatures entziehen und wenn sie dann endlich kommen ist Riesenfreude :)",
  "id" : 1343729560,
  "in_reply_to_status_id" : 1343718709,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343788837",
  "text" : "Sehr sch\u00F6n: C&P, PushNotification, Spotlight, Tethering, LandscapeKeyboard, turn-by-turn-Navigation m\u00F6glich. Von wichtig zu unwichtig sort.",
  "id" : 1343788837,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343798185",
  "text" : "@houellebeck Absolut, du bist doch nur traurig das dein Vertrag noch nicht ausgelaufen ist um zu switchen oder? :)",
  "id" : 1343798185,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343824808",
  "text" : "Und jetzt weiter mit ganz normalen Idioten aus den christlichen Reihen:  http:\/\/tinyurl.com\/dcanrl",
  "id" : 1343824808,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343848732",
  "geo" : { },
  "id_str" : "1343897783",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Sommer ist die allgemeine Ank\u00FCndigung f\u00FCr das Update",
  "id" : 1343897783,
  "in_reply_to_status_id" : 1343848732,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPhone",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "sabber",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1343899243",
  "text" : "@houellebeck Na die 3.0 ist doch dann ein super Grund um das Teil zu kaufen :) #iPhone #sabber",
  "id" : 1343899243,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343915598",
  "geo" : { },
  "id_str" : "1343988172",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Kommst du denn nun eigentlich auch zur pl0gbar?",
  "id" : 1343988172,
  "in_reply_to_status_id" : 1343915598,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1343989858",
  "geo" : { },
  "id_str" : "1344001226",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Hier gibts das Plugin: http:\/\/tinyurl.com\/cwc855",
  "id" : 1344001226,
  "in_reply_to_status_id" : 1343989858,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344012033",
  "geo" : { },
  "id_str" : "1344052544",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Daf\u00FCr musste ich die Seite selbst auch erstmal googlen ;)",
  "id" : 1344052544,
  "in_reply_to_status_id" : 1344012033,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344046452",
  "geo" : { },
  "id_str" : "1344056566",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Doch ich schon. Kann man bequemer nutzen w\u00E4hrend man l\u00E4uft als das kleine :)",
  "id" : 1344056566,
  "in_reply_to_status_id" : 1344046452,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344093888",
  "geo" : { },
  "id_str" : "1344174425",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Also ich lade alle in voller Aufl\u00F6sung hoch,aber meine Fotos sind auch alle CC-Lizensiert so das jeder die gro\u00DFen Fotos laden kann",
  "id" : 1344174425,
  "in_reply_to_status_id" : 1344093888,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344064488",
  "geo" : { },
  "id_str" : "1344180945",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich tippe auf der Hochkant-Tastatur mit 3 Fingern der linken Hand. Und bei Quer mit beiden Daumen.",
  "id" : 1344180945,
  "in_reply_to_status_id" : 1344064488,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eldersign",
      "screen_name" : "eldersign",
      "indices" : [ 0, 10 ],
      "id_str" : "14209202",
      "id" : 14209202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344208526",
  "geo" : { },
  "id_str" : "1344216146",
  "in_reply_to_user_id" : 14209202,
  "text" : "@eldersign Ich glaube du liest nicht Aufmerksam genug :)",
  "id" : 1344216146,
  "in_reply_to_status_id" : 1344208526,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "eldersign",
  "in_reply_to_user_id_str" : "14209202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eldersign",
      "screen_name" : "eldersign",
      "indices" : [ 0, 10 ],
      "id_str" : "14209202",
      "id" : 14209202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344224953",
  "geo" : { },
  "id_str" : "1344252537",
  "in_reply_to_user_id" : 14209202,
  "text" : "@eldersign ich hab die Pressekonferenz verfolgt und dr\u00FCber getwittert :)",
  "id" : 1344252537,
  "in_reply_to_status_id" : 1344224953,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "eldersign",
  "in_reply_to_user_id_str" : "14209202",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1344315300",
  "text" : "Das nennt man wohl dreist  http:\/\/twitpic.com\/26xxy",
  "id" : 1344315300,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344346084",
  "geo" : { },
  "id_str" : "1344473523",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ich hab es geschafft ihn beiseite zu schieben :)",
  "id" : 1344473523,
  "in_reply_to_status_id" : 1344346084,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344493971",
  "geo" : { },
  "id_str" : "1344601702",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ach soll sich nicht so anstellen der Hund.",
  "id" : 1344601702,
  "in_reply_to_status_id" : 1344493971,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Endl",
      "screen_name" : "zielpublikum",
      "indices" : [ 0, 13 ],
      "id_str" : "14711791",
      "id" : 14711791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1344913233",
  "geo" : { },
  "id_str" : "1344968759",
  "in_reply_to_user_id" : 14711791,
  "text" : "@zielpublikum Manchmal geht die durchaus berechtigte Feature-Reduktion von Apple einfach zu weit ;)",
  "id" : 1344968759,
  "in_reply_to_status_id" : 1344913233,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "zielpublikum",
  "in_reply_to_user_id_str" : "14711791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1345024615",
  "text" : "Das nenne ich mal eine super FAQ. Leicht verst\u00E4ndlich. \u00DCbersichtlich. Beantwortet alle Fragen:  http:\/\/tinyurl.com\/yst2kc",
  "id" : 1345024615,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UphillGirl",
      "screen_name" : "UphillGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "21393852",
      "id" : 21393852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1339361576",
  "geo" : { },
  "id_str" : "1339367711",
  "in_reply_to_user_id" : 21393852,
  "text" : "@UphillGirl Immerhin macht er dann wenigstens kurz keinen Krach mehr. Das Zeitfenster k\u00F6nnte man zum selber einschlafen nutzen :)",
  "id" : 1339367711,
  "in_reply_to_status_id" : 1339361576,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "UphillGirl",
  "in_reply_to_user_id_str" : "21393852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1339391372",
  "text" : "Kirchen-Fail: Bei Pharmafirmen \u00FCber Patente auf HIV-Medis beschweren, selber aber Kondome ablehnen...Sagt euch Pr\u00E4vention und Unheilbar was?",
  "id" : 1339391372,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1340978997",
  "text" : "Wieso bin ich eigentlich schon wieder wach?!",
  "id" : 1340978997,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341084775",
  "text" : "Und feiert ihr schon den Paddy's Day? \u00C9irinn go br\u00E1th!",
  "id" : 1341084775,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 38, 46 ]
    }, {
      "text" : "muenster",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341140183",
  "text" : "Schaffe es am Donnerstag nun auch zur #pl0gbar #muenster",
  "id" : 1341140183,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341267158",
  "text" : "Ich frage mich wer einen einzelnen Schuh, Marke Rentner-Slipper, im Wald verliert. Merkt man sowas erst wenn man wieder daheim ist?",
  "id" : 1341267158,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341311222",
  "text" : "Zelda meets Hip Hop, cooles Mashup  http:\/\/tinyurl.com\/c8g9tw",
  "id" : 1341311222,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ute Hamelmann",
      "screen_name" : "Schnutinger",
      "indices" : [ 0, 12 ],
      "id_str" : "12325552",
      "id" : 12325552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1341325939",
  "geo" : { },
  "id_str" : "1341332829",
  "in_reply_to_user_id" : 12325552,
  "text" : "@schnutinger Nachher heisst es das man so Amokl\u00E4ufer z\u00FCchtet...",
  "id" : 1341332829,
  "in_reply_to_status_id" : 1341325939,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "Schnutinger",
  "in_reply_to_user_id_str" : "12325552",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341356838",
  "text" : "Oh! the wind was sighing | And the day was dying | As the loike lay crying | In his prison cell \u266B http:\/\/blip.fm\/~32uml",
  "id" : 1341356838,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1341403402",
  "geo" : { },
  "id_str" : "1341424162",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent C&P, Tethering und leider wird es wohl nur Wunschdenken sein: Multitasking mit Programmen die im Hintergrund laufen k\u00F6nnen.",
  "id" : 1341424162,
  "in_reply_to_status_id" : 1341403402,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "luege",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1335554023",
  "text" : "So lange hab ich gar nicht geschlafen #luege Guten morgen.",
  "id" : 1335554023,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1335758755",
  "text" : "@houellebeck Das nenn ich direkt :)",
  "id" : 1335758755,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1335776673",
  "text" : "Interessant, das \u201CVorzugsabo\u201D f\u00FCr Studenten das die NPG mir schickt ist teurer als wenn ich die Nature \u00FCber einen deutschen Reseller bestell",
  "id" : 1335776673,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1335793826",
  "text" : "\u201CDie HRE braucht wieder einmal 10 Milliarden. Die Bundesregierung sollte langsam mal einen Dauerauftrag einrichten\u201D",
  "id" : 1335793826,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPhone",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1335913925",
  "geo" : { },
  "id_str" : "1335924762",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten Absolut TwitterFon #iPhone",
  "id" : 1335924762,
  "in_reply_to_status_id" : 1335913925,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1335968787",
  "text" : "\u201C...verbreiten soziale Netzwerke kostenlose Informationen an jedermann. Aber kann man ihnen trauen?\u201D Bl\u00F6de Frage http:\/\/tinyurl.com\/dnfnjd",
  "id" : 1335968787,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1335970728",
  "text" : "Nat\u00FCrlich kann man Informationen aus dem Web so wenig trauen wie Infos aus Zeitungen oder aus anderen, \u201Cjournalistischen\u201D Quellen...",
  "id" : 1335970728,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1335975787",
  "geo" : { },
  "id_str" : "1335982225",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ Selbst wenn die Recherche gut ist, man sollte sich immer vor Augen halten das Artikel immer irgendwo Meinungen vertreten...",
  "id" : 1335982225,
  "in_reply_to_status_id" : 1335975787,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauritz",
      "screen_name" : "laune_",
      "indices" : [ 0, 7 ],
      "id_str" : "24357838",
      "id" : 24357838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1335989646",
  "geo" : { },
  "id_str" : "1336015483",
  "in_reply_to_user_id" : 24357838,
  "text" : "@laune_ Ja, das ist ein Problem. Nur weil es in Zeitungen stand oder im Fernsehen kam muss es nicht war sein....",
  "id" : 1336015483,
  "in_reply_to_status_id" : 1335989646,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "laune_",
  "in_reply_to_user_id_str" : "24357838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1336019017",
  "geo" : { },
  "id_str" : "1336026003",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten TweetDeck ist so ziemlich der beste kostenlose Twitterclient den ich kenne. Und dank Adobe AIR Betriebssystem-\u00DCbergreifend.",
  "id" : 1336026003,
  "in_reply_to_status_id" : 1336019017,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Peoplebrowsr",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1336040967",
  "geo" : { },
  "id_str" : "1336203342",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Stimmt, aber was ist wenn ich keinen Firefox benutzen will? Oder zumindest nicht die ganze Zeit anhaben m\u00F6chte? #Peoplebrowsr",
  "id" : 1336203342,
  "in_reply_to_status_id" : 1336040967,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1336213929",
  "geo" : { },
  "id_str" : "1336219350",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Ist ja auch egal, so wirklich 100%ig zufrieden bin ich bislang noch mit keinem Client. Alle haben ihre Macken.",
  "id" : 1336219350,
  "in_reply_to_status_id" : 1336213929,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1336300770",
  "text" : "@houellebeck Was? Das Internet isst die Nazis?",
  "id" : 1336300770,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1336315155",
  "text" : "@houellebeck Dabei dachte ich immer \u201CBildung isst Nazis\u201D? Verwirrende Bilder offenbaren sich da.",
  "id" : 1336315155,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1336887055",
  "text" : "Zeit f\u00FCr... Ich trau mich kaum es zu sagen... Fr\u00FChst\u00FCck!",
  "id" : 1336887055,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1336971164",
  "text" : "Leute die einem nur kurz followen in der Hoffnung zur\u00FCckverfolgt zu werden um einen dann wieder rauszuwerfen sind Abschaum. Merkts euch Pack",
  "id" : 1336971164,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1337111658",
  "geo" : { },
  "id_str" : "1337115018",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Man kann doch Tweets l\u00F6schen ist das nicht Undo genug?",
  "id" : 1337115018,
  "in_reply_to_status_id" : 1337111658,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 0, 14 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1337127124",
  "geo" : { },
  "id_str" : "1337132423",
  "in_reply_to_user_id" : 15318271,
  "text" : "@astrodicticum Das ist doch das Sch\u00F6ne, jeden Tag lernt man was dazu. Zumindest wenn man will ;)",
  "id" : 1337132423,
  "in_reply_to_status_id" : 1337127124,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "astrodicticum",
  "in_reply_to_user_id_str" : "15318271",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1337630824",
  "text" : "Muss dann jetzt auch mal los zur Leiterrunde.",
  "id" : 1337630824,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1338439483",
  "text" : "So wieder da und das Protokoll ist auch schon per Mail rausgegangen.",
  "id" : 1338439483,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1338559707",
  "text" : "Manchmal ist Demokratie einfach scheisse. Ich sollte Diktator werden, dann w\u00E4re alles gleich viel besser ;)",
  "id" : 1338559707,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1338597017",
  "text" : "Morgen soll das OS 3.0 f\u00FCrs iPhone kommen oder? Bitte, bitte Apple: Copy&Paste kann doch wirklich nicht zuviel verlangt sein...",
  "id" : 1338597017,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u062A\u062F\u064A\u0648 \u0642\u064F\u0645\u0631\u0651\u0647",
      "screen_name" : "AlmStudio",
      "indices" : [ 0, 10 ],
      "id_str" : "707534085",
      "id" : 707534085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1338604793",
  "geo" : { },
  "id_str" : "1338611097",
  "in_reply_to_user_id" : 12790302,
  "text" : "@almstudio Mittlerweile w\u00FCrde mir die Best\u00E4tigung von C&P sogar reichen... Ist doch arm das man immer noch per Zettel & Stift behelfen muss.",
  "id" : 1338611097,
  "in_reply_to_status_id" : 1338604793,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "HDRmeurer",
  "in_reply_to_user_id_str" : "12790302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1339085439",
  "text" : "Schlaflos... nicht in Seattle.",
  "id" : 1339085439,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1339246535",
  "text" : "Verdammt was schnarcht der Hund hier mit dem Frauchen um die Wette. Kein Wunder das ich nicht schlafen kann.",
  "id" : 1339246535,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1339328235",
  "text" : "Das ist die \u221A meiner Schlaflosigkeit heute Nacht:  http:\/\/tinyurl.com\/de4c6p \u2623",
  "id" : 1339328235,
  "created_at" : "2009-03-16 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Besimo",
      "screen_name" : "Besimo",
      "indices" : [ 0, 7 ],
      "id_str" : "15787781",
      "id" : 15787781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332366753",
  "geo" : { },
  "id_str" : "1332375966",
  "in_reply_to_user_id" : 15787781,
  "text" : "@Besimo Ja ich schau es mir gleich mal an.",
  "id" : 1332375966,
  "in_reply_to_status_id" : 1332366753,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Besimo",
  "in_reply_to_user_id_str" : "15787781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332386082",
  "geo" : { },
  "id_str" : "1332403373",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Der Metzger macht aber auch mehr als nur Wurst. ;)",
  "id" : 1332403373,
  "in_reply_to_status_id" : 1332386082,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Besimo",
      "screen_name" : "Besimo",
      "indices" : [ 0, 7 ],
      "id_str" : "15787781",
      "id" : 15787781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332366753",
  "geo" : { },
  "id_str" : "1332442775",
  "in_reply_to_user_id" : 15787781,
  "text" : "@Besimo Ne kann es nicht und auch so \u00FCberzeugt mich Postbox auf Anhieb nicht wirklich. Wie komm ich z.B. an das Adressbuch? Was ist mit GPG?",
  "id" : 1332442775,
  "in_reply_to_status_id" : 1332366753,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Besimo",
  "in_reply_to_user_id_str" : "15787781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332425562",
  "geo" : { },
  "id_str" : "1332444161",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Stimmt, aber vermutlich k\u00F6nnte das der Metzger schnell lernen ;)",
  "id" : 1332444161,
  "in_reply_to_status_id" : 1332425562,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "belanglos",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1332464521",
  "text" : "Abendessen! #belanglos http:\/\/twitpic.com\/24pbr",
  "id" : 1332464521,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Besimo",
      "screen_name" : "Besimo",
      "indices" : [ 0, 7 ],
      "id_str" : "15787781",
      "id" : 15787781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332504544",
  "geo" : { },
  "id_str" : "1332519845",
  "in_reply_to_user_id" : 15787781,
  "text" : "@Besimo Ah okay. GPG f\u00E4nde ich noch ganz wichtig. Werd ich mal Google befragen m\u00FCssen.",
  "id" : 1332519845,
  "in_reply_to_status_id" : 1332504544,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Besimo",
  "in_reply_to_user_id_str" : "15787781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1332527002",
  "text" : "So, endlich sind alle Fotos von dem Konzert gestern Abend bei Flickr gelandet:  http:\/\/tinyurl.com\/dm53cj",
  "id" : 1332527002,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1332566549",
  "text" : "Werde nun Navy CIS schauen.",
  "id" : 1332566549,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "muenster",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332778174",
  "geo" : { },
  "id_str" : "1332871853",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten ich Versuch auch wieder dabei zu sein. #pl0gbar #muenster",
  "id" : 1332871853,
  "in_reply_to_status_id" : 1332778174,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    }, {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 9, 17 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332879644",
  "geo" : { },
  "id_str" : "1332888709",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu RT @stelten: pl0gbar M\u00FCnster #22. Wer ist am Start? http:\/\/tinyurl.com\/ccmu4k #muenster",
  "id" : 1332888709,
  "in_reply_to_status_id" : 1332879644,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1333072187",
  "text" : "Hat meine Freundin sich gerade wirklich bei der Sp\u00FClmaschine entschuldigt weil sie die mitten im Sp\u00FClvorgang abgeschaltet hat?",
  "id" : 1333072187,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Peel",
      "screen_name" : "EmmaPeel_",
      "indices" : [ 0, 10 ],
      "id_str" : "17408013",
      "id" : 17408013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1333093387",
  "geo" : { },
  "id_str" : "1333130499",
  "in_reply_to_user_id" : 17408013,
  "text" : "@EmmaPeel_ Ist eigentlich auch gar nicht so abwegig, kenne auch genug Programmierer die ihren Code anschreien und beschimpfen.",
  "id" : 1333130499,
  "in_reply_to_status_id" : 1333093387,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "EmmaPeel_",
  "in_reply_to_user_id_str" : "17408013",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1333268627",
  "text" : "\u201CYou got Dylans \u00ABBlood On The Tracks\u00BB? Classic heartbreat-album...\u201D \u266B http:\/\/blip.fm\/~30v06",
  "id" : 1333268627,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Thielecke",
      "screen_name" : "mthie",
      "indices" : [ 0, 6 ],
      "id_str" : "3253641",
      "id" : 3253641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1333288354",
  "geo" : { },
  "id_str" : "1333368761",
  "in_reply_to_user_id" : 3253641,
  "text" : "@mthie Hab daf\u00FCr zwar keinen besonderen Tag, verfahre aber trotzdem regelm\u00E4ssig genauso. Sonst bringt Twitter nichts.",
  "id" : 1333368761,
  "in_reply_to_status_id" : 1333288354,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "mthie",
  "in_reply_to_user_id_str" : "3253641",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ironie",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1330901185",
  "text" : "Sturztrunkene Christen die was von Fastenzeit erz\u00E4hlen. #ironie",
  "id" : 1330901185,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1331011651",
  "text" : "So alle Fotos importiert. Dann kann ich erstmal fr\u00FChst\u00FCcken.",
  "id" : 1331011651,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1331193256",
  "text" : "Bob Dylan-Sonntag eingel\u00E4utet. Spannend was f\u00FCr coole Bootlegs es gibt.",
  "id" : 1331193256,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1331227010",
  "text" : "Fotoupload l\u00E4uft schon, dieses Flickr-Plugin f\u00FCr Lightroom ist eine der besten Erfindungen die ich kenne.",
  "id" : 1331227010,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1331252299",
  "text" : "High-ISO-Noise ftw!",
  "id" : 1331252299,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1331836182",
  "text" : "So und weiter Fotos hochladen. Irgendwie ist das Netz heute bei mir etwas lahm. ETA: 72 min f\u00FCr 31 28 Fotos?",
  "id" : 1331836182,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1332169692",
  "text" : "Krankenh\u00E4user k\u00F6nnen glaub ich entweder unglaublich cool sein oder unglaublich beschissen. Dazwischen scheint es nichts zu geben.",
  "id" : 1332169692,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332199555",
  "geo" : { },
  "id_str" : "1332219388",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Das UKM finde ich auch nett. Das kleine, christliche Grevener KH in dem mein Dad liegt ist schrecklich.",
  "id" : 1332219388,
  "in_reply_to_status_id" : 1332199555,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332240197",
  "geo" : { },
  "id_str" : "1332249741",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Unter anderem, Christen scheinen auf h\u00E4sslich und trist zu stehen. Wenn einem in jedem Zimmer schon das Kruzifix \u201Canlacht\u201D...",
  "id" : 1332249741,
  "in_reply_to_status_id" : 1332240197,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1332268991",
  "text" : "Seltsam, Mail ist abgekackt w\u00E4hrend ich im KH war und musste gekillt werden und Lightroom hat nicht weiter hochgeladen. Wegen locked Screen?",
  "id" : 1332268991,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332276720",
  "geo" : { },
  "id_str" : "1332283426",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja irgendwie so war der Quatsch. Nur wieso unterhalten diese Freaks dann Krankenh\u00E4user? W\u00E4re qualvoll sterben lassen nicht toll?",
  "id" : 1332283426,
  "in_reply_to_status_id" : 1332276720,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332303431",
  "geo" : { },
  "id_str" : "1332310605",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod \u00C4rzte d\u00FCrfte es dann einfach nicht geben als logische Konsequenz daraus. Sollen sie halt Metzger werden.",
  "id" : 1332310605,
  "in_reply_to_status_id" : 1332303431,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1332318606",
  "text" : "Strange, ich glaube es lag einfach daran das zwischendurch das Netz weg war. Aber Mail ist eh Mist.",
  "id" : 1332318606,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332317261",
  "geo" : { },
  "id_str" : "1332320844",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Zumindest f\u00FCr Chirurgen d\u00FCrfte das sehr nahe kommen. :)",
  "id" : 1332320844,
  "in_reply_to_status_id" : 1332317261,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Besimo",
      "screen_name" : "Besimo",
      "indices" : [ 0, 7 ],
      "id_str" : "15787781",
      "id" : 15787781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332336025",
  "geo" : { },
  "id_str" : "1332346481",
  "in_reply_to_user_id" : 15787781,
  "text" : "@Besimo Wie ist denn da so die Einbindung in MacOS mit iCal, Adressbuch und Spotlight? Das ist an Mail schon nett.",
  "id" : 1332346481,
  "in_reply_to_status_id" : 1332336025,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Besimo",
  "in_reply_to_user_id_str" : "15787781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Besimo",
      "screen_name" : "Besimo",
      "indices" : [ 0, 7 ],
      "id_str" : "15787781",
      "id" : 15787781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332354268",
  "geo" : { },
  "id_str" : "1332359527",
  "in_reply_to_user_id" : 15787781,
  "text" : "@Besimo Das Feature in Mail um neue Kalendereintr\u00E4ge aus Mails zu erstellen finde ich sehr praktisch. Daf\u00FCr ist IMAP in Mail unterirdisch.",
  "id" : 1332359527,
  "in_reply_to_status_id" : 1332354268,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Besimo",
  "in_reply_to_user_id_str" : "15787781",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1332360000",
  "geo" : { },
  "id_str" : "1332374586",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Kommt glaub ich drauf an wie ehrlich der Chirurg zu sich selbst ist. Ich kenne welche die das ohne Umschweife zugeben.",
  "id" : 1332374586,
  "in_reply_to_status_id" : 1332360000,
  "created_at" : "2009-03-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1326298418",
  "text" : "Morgen",
  "id" : 1326298418,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Journalismusinanf\u00FChrungstrichen",
      "indices" : [ 19, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1326331299",
  "text" : "Hart aber fair? ;) #Journalismusinanf\u00FChrungstrichen  http:\/\/tinyurl.com\/bwtrjs",
  "id" : 1326331299,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cspannagel",
      "screen_name" : "cspannagel",
      "indices" : [ 0, 11 ],
      "id_str" : "578512158",
      "id" : 578512158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1326421459",
  "text" : "@cspannagel Viel Spass im Seminar",
  "id" : 1326421459,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cspannagel",
      "screen_name" : "cspannagel",
      "indices" : [ 0, 11 ],
      "id_str" : "578512158",
      "id" : 578512158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1326436945",
  "text" : "@cspannagel Sitze mit Kaffee & Br\u00F6tchen vor dem PC und lese meine RSS-Feeds und kann deshalb nebenbei twittern.",
  "id" : 1326436945,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr\u00E9 Loibl",
      "screen_name" : "andreloibl",
      "indices" : [ 0, 11 ],
      "id_str" : "14843240",
      "id" : 14843240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1326540814",
  "geo" : { },
  "id_str" : "1326562243",
  "in_reply_to_user_id" : 14843240,
  "text" : "@andreloibl Und die fortgeschrittene Version von Sexismus gibt es im Failblog zu sehen: http:\/\/tinyurl.com\/auokn7",
  "id" : 1326562243,
  "in_reply_to_status_id" : 1326540814,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "andreloibl",
  "in_reply_to_user_id_str" : "14843240",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1326633309",
  "text" : "Was gibt es besseres als gem\u00FCtlich in der Badewanne seine Feeds zu lesen?",
  "id" : 1326633309,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "danger",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1326644333",
  "geo" : { },
  "id_str" : "1326673602",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ja ich hab aufgepasst das ich es nicht fallen lasse :) #danger",
  "id" : 1326673602,
  "in_reply_to_status_id" : 1326644333,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WN_Muenster",
      "screen_name" : "WN_Muenster",
      "indices" : [ 63, 75 ],
      "id_str" : "2542060171",
      "id" : 2542060171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1327017348",
  "text" : "Wegen genau solchen Dingen kann ich unsere Lokalzeitungen wie  @WN_Muenster nicht ernst nehmen  http:\/\/tinyurl.com\/arymgu",
  "id" : 1327017348,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1327199379",
  "geo" : { },
  "id_str" : "1327223429",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Oh man den Spa\u00DF hab ich ja ganz verpasst. Wie sieht es mit den Zahlenverh\u00E4ltnissen so aus?",
  "id" : 1327223429,
  "in_reply_to_status_id" : 1327199379,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1327337698",
  "geo" : { },
  "id_str" : "1327470101",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Hat kein Recht solange das Foto nicht nur ihn zeigt.",
  "id" : 1327470101,
  "in_reply_to_status_id" : 1327337698,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1327500550",
  "text" : "Sieht man eigentlich einen der #muenster Twitteraner heut Abend im Rathlins am Hindenburgplatz?",
  "id" : 1327500550,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1327549417",
  "geo" : { },
  "id_str" : "1327565664",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster Ihr seid da auch nicht gerade die Nummer 1 in Zur\u00FCckhaltung beim dem Thema was ich online so gefunden habe. :)",
  "id" : 1327565664,
  "in_reply_to_status_id" : 1327549417,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1327549417",
  "geo" : { },
  "id_str" : "1327574357",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster Aber passt schon, ich bin ja nicht gezwungen es zu lesen. ;)",
  "id" : 1327574357,
  "in_reply_to_status_id" : 1327549417,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rathlins",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1327760833",
  "text" : "@danishkirel Irish Folk von denen hier: http:\/\/tinyurl.com\/dgzlcq . Als St. Paddys-Warmup. #rathlins",
  "id" : 1327760833,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1328117229",
  "geo" : { },
  "id_str" : "1328123401",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster gute Strecke",
  "id" : 1328123401,
  "in_reply_to_status_id" : 1328117229,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1328177611",
  "text" : "Wer sich beeilt schafft es noch p\u00FCnktlich ins Rathlins.",
  "id" : 1328177611,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1328512354",
  "text" : "Prost! [?]",
  "id" : 1328512354,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1329136362",
  "text" : "Konzert ist vorbei. Und ich bin schon zuhause mit jeder Menge Fotos.  http:\/\/twitpic.com\/23t6v",
  "id" : 1329136362,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spon",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1320775418",
  "text" : "\u201CVom Heimcomputer aus habe der Amokl\u00E4ufer seine Taten angek\u00FCndigt\u201D - Heimcomputer ist so ein Wort aus den 80\/90er Jahren. #spon",
  "id" : 1320775418,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1320844959",
  "text" : "@houellebeck Wieso muss ich jetzt an Bier denken? ;)",
  "id" : 1320844959,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "karlkaefer",
      "screen_name" : "karlkaefer",
      "indices" : [ 0, 11 ],
      "id_str" : "18239333",
      "id" : 18239333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1320875944",
  "geo" : { },
  "id_str" : "1320882493",
  "in_reply_to_user_id" : 18239333,
  "text" : "@karlkaefer Ausversehen am Dioptrin-Regler gespielt?",
  "id" : 1320882493,
  "in_reply_to_status_id" : 1320875944,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "karlkaefer",
  "in_reply_to_user_id_str" : "18239333",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1320909124",
  "text" : "@houellebeck Damals Kinder, als wir Bier noch in Dosen beim Aldi kaufen konnten. Ganz ohne Pfand",
  "id" : 1320909124,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "killerspiele",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1320968880",
  "geo" : { },
  "id_str" : "1320974499",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Oh man, die letzte Antwort ist der Hit: Wenn Eltern zu bl\u00F6d sind ihren Job zu machen hilft die Ganztagsschule sicher #killerspiele",
  "id" : 1320974499,
  "in_reply_to_status_id" : 1320968880,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1320976093",
  "geo" : { },
  "id_str" : "1320982014",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Ist doch einfach: Ganztagsschule einrichten, dann kommen P\u00E4dophile nicht mehr an Kinder ran...",
  "id" : 1320982014,
  "in_reply_to_status_id" : 1320976093,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1321008458",
  "geo" : { },
  "id_str" : "1321040563",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Und da wird nur mit Plastikbesteck gegessen und rasieren Verboten damit alle ganz sicher sind.",
  "id" : 1321040563,
  "in_reply_to_status_id" : 1321008458,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1321052503",
  "text" : "Bilde ich mir das nur ein oder ist iTunes mit dem letzten Update wirklich deutlich schneller geworden? Gerade was \u00F6ffnen\/schliessen angeht",
  "id" : 1321052503,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 33, 37 ]
    }, {
      "text" : "sick",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1321158199",
  "text" : "@houellebeck Sehr sehr verr\u00FCckt. #wtf #sick",
  "id" : 1321158199,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1321160429",
  "text" : "Die Neugier hat mich doch gepackt: Installiere die Ubuntu 9.04 Alpha auf dem Thinkpad",
  "id" : 1321160429,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1321360510",
  "text" : "@houellebeck da hilft st\u00E4rkerer Kaffee ;)",
  "id" : 1321360510,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr haekelschwein",
      "screen_name" : "haekelschwein",
      "indices" : [ 3, 17 ],
      "id_str" : "21523802",
      "id" : 21523802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1321369239",
  "text" : "RT @haekelschwein: Die Kirche, in einem einzigen Cartoon zusammengefasst: http:\/\/tinyurl.com\/btd3h9",
  "id" : 1321369239,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1322705010",
  "text" : "TuneInstructor ist zum MP3s taggen prima.",
  "id" : 1322705010,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1322796335",
  "text" : "Heute endlich mal wieder Munchkin spielen.",
  "id" : 1322796335,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Schmolk",
      "screen_name" : "anouphagos",
      "indices" : [ 0, 11 ],
      "id_str" : "368317316",
      "id" : 368317316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1323469109",
  "text" : "@anouphagos Standard, Nr. 2, Nr. 3 und Munchkin Fu.",
  "id" : 1323469109,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1320759192",
  "text" : "Guten morgen zusammen.",
  "id" : 1320759192,
  "created_at" : "2009-03-13 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WN_Muenster",
      "screen_name" : "WN_Muenster",
      "indices" : [ 3, 15 ],
      "id_str" : "2542060171",
      "id" : 2542060171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1315373086",
  "text" : "RT @WN_Muenster: M\u00FCnster: Bus rast in Menschenmenge am Hauptbahnhof http:\/\/tinyurl.com\/dfrzgp",
  "id" : 1315373086,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1315449024",
  "text" : "Gna, 15 Minuten im Supermarkt schlange stehen f\u00FCr eine Schachtel Zigaretten.",
  "id" : 1315449024,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1315587127",
  "geo" : { },
  "id_str" : "1315589808",
  "in_reply_to_user_id" : 8517622,
  "text" : "@LORXSION Nur wenn man kein Kleingeld zusammenbekommt f\u00FCr den Automaten vor der Haust\u00FCr ;)",
  "id" : 1315589808,
  "in_reply_to_status_id" : 1315587127,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "danishkirel",
      "indices" : [ 0, 12 ],
      "id_str" : "3393171664",
      "id" : 3393171664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1315597972",
  "text" : "@danishkirel Hab ich mir auch oft gesagt. Hab dann aber beschlossen erstmal dem Alkohol eine Zeitlang zu entsagen. Rauchen vielleicht sp\u00E4ter",
  "id" : 1315597972,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1315652276",
  "text" : "Christen bei SpOn: Das Spaghetti-Monster ist unfug weil wir dessen Erfinder kennen... Was ist der Umkehrschluss dann bitte f\u00FCr Christen?",
  "id" : 1315652276,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHD_Comics",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1315678267",
  "text" : "http:\/\/tinyurl.com\/an7jpu Kommt mir bekannt vor. #PHD_Comics",
  "id" : 1315678267,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Smith",
      "screen_name" : "tilmar",
      "indices" : [ 0, 7 ],
      "id_str" : "2163562470",
      "id" : 2163562470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spiegel",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "logik",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1315715719",
  "text" : "@TilMar Sei froh das Hitler keine Computerspiele hatte. Mit C&C h\u00E4tte er WW2 vielleicht gewinnen k\u00F6nnen. #spiegel #logik",
  "id" : 1315715719,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1311852855",
  "geo" : { },
  "id_str" : "1315762940",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 zu Twitterfon: Hat es da nicht auch eine Nearby-Funktion in der Suche?",
  "id" : 1315762940,
  "in_reply_to_status_id" : 1311852855,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1315791370",
  "text" : "@JoergR Da werden sie dir aufs Dach springen wegen dem alten Testament.",
  "id" : 1315791370,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1315801956",
  "text" : "@JoergR SpOn-Foren halt, heise in anders.",
  "id" : 1315801956,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1315815620",
  "geo" : { },
  "id_str" : "1315817118",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Ne muss dir nicht peinlich sein, hab ich auch mehr oder weniger zuf\u00E4llig entdeckt :)",
  "id" : 1315817118,
  "in_reply_to_status_id" : 1315815620,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1316267469",
  "text" : "Morgen fr\u00FCh um 6 geht es f\u00FCr einen Tag schonmal nach Berlin. Wehe da ist das Wetter genauso bl\u00F6d.",
  "id" : 1316267469,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheistbus",
      "indices" : [ 108, 119 ]
    }, {
      "text" : "buskampagne",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1316339746",
  "text" : "wtf? Schon \u00FCber 16k \u20AC Spenden f\u00FCr den deutschen Atheistbus? Um fair zu sein: Damit h\u00E4tte ich nie gerechnet. #atheistbus #buskampagne",
  "id" : 1316339746,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1316337821",
  "geo" : { },
  "id_str" : "1316348346",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX F\u00FCr den eventuellen Placebo-Effekt d\u00FCrfte das recht egal sein vermute ich ganz stark.",
  "id" : 1316348346,
  "in_reply_to_status_id" : 1316337821,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1316393055",
  "geo" : { },
  "id_str" : "1316406274",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe Wer sagt denn das die Menschen nicht sowohl als auch tun? Kann nur f\u00FCr mich sprechen und mache bei http:\/\/kiva.org\/ mit.",
  "id" : 1316406274,
  "in_reply_to_status_id" : 1316393055,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1316418757",
  "geo" : { },
  "id_str" : "1316428487",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe Ich weiss. Zum Gl\u00FCck ist spenden ja keine entweder\/oder-Entscheidung in dem Sinne. Au\u00DFer das zu wenig Leute es \u00FCberhaupt tun.",
  "id" : 1316428487,
  "in_reply_to_status_id" : 1316418757,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wundw",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1316521858",
  "text" : "Neuer W&W-Post: St. Paddy's Day naht - Oder: Wieso es in Irland keine Schlangen gibt:  http:\/\/bit.ly\/73NXe #wundw",
  "id" : 1316521858,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1317042574",
  "text" : "Cool, Dropbox hat zur Zeit eine Bonusaktion, wenn man Leute einl\u00E4dt mitzumachen bekommen beide 250 MB mehr Speicher:  http:\/\/bit.ly\/Evs6M",
  "id" : 1317042574,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wunschdenken",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1317045144",
  "geo" : { },
  "id_str" : "1317111462",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Und endlich copy&paste? #wunschdenken",
  "id" : 1317111462,
  "in_reply_to_status_id" : 1317045144,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1317575760",
  "text" : "Ab zu den Rovern.",
  "id" : 1317575760,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1318079658",
  "text" : "Doch nichts mit Berlin, mein Vater liegt im Krankenhaus.",
  "id" : 1318079658,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1318088709",
  "geo" : { },
  "id_str" : "1318148803",
  "in_reply_to_user_id" : 17904767,
  "text" : "@Causa_Motiva Nichts genaues weiss man zum jetzigen Zeitpunkt, Schwindel in Verbindung mit Bluthochdruck",
  "id" : 1318148803,
  "in_reply_to_status_id" : 1318088709,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "SteterTropfen",
  "in_reply_to_user_id_str" : "17904767",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1318345695",
  "geo" : { },
  "id_str" : "1318411959",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion das beste ist selbermachen. Anleitungen auch f\u00FCr Windows hat Google zur gen\u00FCge.",
  "id" : 1318411959,
  "in_reply_to_status_id" : 1318345695,
  "created_at" : "2009-03-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1309716079",
  "geo" : { },
  "id_str" : "1309736498",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Die Landscape-Tastatur w\u00FCrde TwitterFon noch ganz gut stehen finde ich.",
  "id" : 1309736498,
  "in_reply_to_status_id" : 1309716079,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1309877499",
  "geo" : { },
  "id_str" : "1309879469",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Ja, das st\u00F6rt mich bei Tweetie auch, es kann doch nicht so schwer sein den Beschleunigungssensor daf\u00FCr zu verwenden.",
  "id" : 1309879469,
  "in_reply_to_status_id" : 1309877499,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1309956756",
  "geo" : { },
  "id_str" : "1310085045",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Mir f\u00E4llt aber kein wirklich guter Grund ein wieso man das Keyboard nicht automatisch drehen k\u00F6nnen sollte, zumindest als Option.",
  "id" : 1310085045,
  "in_reply_to_status_id" : 1309956756,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max von Webel",
      "screen_name" : "343max",
      "indices" : [ 0, 7 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1310089571",
  "geo" : { },
  "id_str" : "1310120891",
  "in_reply_to_user_id" : 2284151,
  "text" : "@343max Was heisst schon? Wer jetzt erst damit anf\u00E4ngt ist schon sp\u00E4t dran...",
  "id" : 1310120891,
  "in_reply_to_status_id" : 1310089571,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "343max",
  "in_reply_to_user_id_str" : "2284151",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1310293557",
  "text" : "\u201CWhen a dog ran underneath a German tank looking for a tasty treat, the lever was tripped and the bomb was triggered.\u201D  http:\/\/bit.ly\/13ok7Y",
  "id" : 1310293557,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1310317668",
  "text" : "Und wer es nicht glauben kann sollte sich den Wiki-Eintrag \u00FCber Hundeminen anschauen:  http:\/\/bit.ly\/ZES2V",
  "id" : 1310317668,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die Stimme NRWs",
      "screen_name" : "DerWesten",
      "indices" : [ 0, 10 ],
      "id_str" : "795545319408881664",
      "id" : 795545319408881664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1310320752",
  "geo" : { },
  "id_str" : "1310332009",
  "in_reply_to_user_id" : 15071293,
  "text" : "@DerWesten F\u00FChrt ihr Ranglisten mit den erfolgreichsten Amokl\u00E4ufen? So mit Wetten im B\u00FCro und so?",
  "id" : 1310332009,
  "in_reply_to_status_id" : 1310320752,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "WAZ_Redaktion",
  "in_reply_to_user_id_str" : "15071293",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1310451198",
  "text" : "Calvin & Hobbes in ihren sp\u00E4teren Tagen:  http:\/\/bit.ly\/1aBry",
  "id" : 1310451198,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1310809708",
  "geo" : { },
  "id_str" : "1310890166",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr vermutlich haben wir das Letzte Pferd lange vernichtet bevor wir Autos endg\u00FCltig abschaffen.",
  "id" : 1310890166,
  "in_reply_to_status_id" : 1310809708,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1310910435",
  "text" : "Menschen die nichts anderes Twittern als Links zu ihren Blogposts find ich nervig.",
  "id" : 1310910435,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    }, {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 9, 25 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "self",
      "indices" : [ 70, 75 ]
    }, {
      "text" : "blogspam",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1311232990",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr @The_Smoking_GNU Den hab ich auch entdeckt. Und weg damit :) #self #blogspam",
  "id" : 1311232990,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1311244871",
  "text" : "Heute st\u00F6rt mich das glossy Display des MBP zum ersten mal. Sitze aber auch ausnahmsweise mit dem R\u00FCcken zum Fenster. Und kein MS-Regen.",
  "id" : 1311244871,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetievstwitterfon",
      "indices" : [ 71, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1309900067",
  "geo" : { },
  "id_str" : "1311247928",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 Die Anzahl von neuen Tweets find ich bei Twitter auch super.  #tweetievstwitterfon",
  "id" : 1311247928,
  "in_reply_to_status_id" : 1309900067,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sapere Aude!",
      "screen_name" : "_SapereAude_",
      "indices" : [ 0, 13 ],
      "id_str" : "292663620",
      "id" : 292663620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1311262672",
  "text" : "@_sapereaude_ Und dazu diese grausigen Eintr\u00E4ge im \u201CForum\u201D von SpOn. Hat ja mittlerweile Heise-Niveau.",
  "id" : 1311262672,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TITANIC",
      "screen_name" : "titanic",
      "indices" : [ 46, 54 ],
      "id_str" : "12509262",
      "id" : 12509262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1311327183",
  "text" : "Das Ding hatte ich schon wieder vergessen. RT @titanic: \u00DCbersichtlichere Amokl\u00E4ufe dank Amok-Ank\u00FCndigungsformular! http:\/\/tinyurl.com\/ajt34h",
  "id" : 1311327183,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 0, 8 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1311368016",
  "geo" : { },
  "id_str" : "1311375203",
  "in_reply_to_user_id" : 14082615,
  "text" : "@stelten Da tun mir schon vom zusehen die Finger weh.",
  "id" : 1311375203,
  "in_reply_to_status_id" : 1311368016,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "stelten",
  "in_reply_to_user_id_str" : "14082615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ICanHasCheezburger?",
      "screen_name" : "ICHCheezburger",
      "indices" : [ 3, 18 ],
      "id_str" : "346786674",
      "id" : 346786674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1313119339",
  "text" : "RT @ICHCheezburger: Gil Grissom\u2019s assistant thought it http:\/\/tinyurl.com\/b7dl3r",
  "id" : 1313119339,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Amok",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1313126066",
  "text" : "Wow, nach #Amok im TV und Radio nicht dumme Politiker geh\u00F6rt! Verbote bringen nichts und 100% Sicherheit wird es nie geben.Halluziniere ich?",
  "id" : 1313126066,
  "created_at" : "2009-03-11 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twtvite",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "ms",
      "indices" : [ 55, 58 ]
    }, {
      "text" : "tweetup",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1305708613",
  "text" : "YES, I'm going to http:\/\/twtvite.com\/4lovae - #twtvite #ms and #tweetup",
  "id" : 1305708613,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buscampaign",
      "indices" : [ 110, 122 ]
    }, {
      "text" : "buskampagne",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1305793627",
  "text" : "Die deutsche Atheist-Buscampaign hat (trotz der Slogans) schon fast 2000\u20AC erspendet. H\u00E4tte ich nicht gedacht. #buscampaign #buskampagne",
  "id" : 1305793627,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1306514475",
  "text" : "GPS-Mouse gefunden, jetzt mal schauen ob ich GoogleLatitude auf dem WM-Ger\u00E4t zum laufen \u00FCberreden kann.",
  "id" : 1306514475,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1306560089",
  "text" : "wtf? Wieso will GoogleLatitude unbedingt eine Verbindung \u00FCber GPRS herstellen um es einzurichten? Reicht die WLAN-Verbindung nicht aus?",
  "id" : 1306560089,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1306559903",
  "geo" : { },
  "id_str" : "1306571571",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent Ja, den ganzen Tag \u00FCber schon in regelm\u00E4ssigen Abst\u00E4nden Komplettausf\u00E4lle",
  "id" : 1306571571,
  "in_reply_to_status_id" : 1306559903,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 97, 109 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1306603661",
  "text" : "Sehr sch\u00F6ne Gegendemo gegen christliche Fundamentalisten: C'thulhu fhtagn! W\u00E4re auch was f\u00FCr uns @houellebeck  http:\/\/bit.ly\/13aDp8",
  "id" : 1306603661,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1306954937",
  "geo" : { },
  "id_str" : "1306977477",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU why are there daylightsaving times at all? The whole idea is fucked up...",
  "id" : 1306977477,
  "in_reply_to_status_id" : 1306954937,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1307151647",
  "text" : "Schau nun Doktor House. Ich habe eine Schw\u00E4che f\u00FCr geniale Psychopathen.",
  "id" : 1307151647,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1304727497",
  "text" : "Der Hund wird langsam zum Kalb, neues Brustgeschirr muss her. Aus dem alten ist er souver\u00E4n rausgewachsen.",
  "id" : 1304727497,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Myspace",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1304775214",
  "geo" : { },
  "id_str" : "1304778459",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Ich glaub als einfaches Tool f\u00FCr kleine Bands bleibt es erhalten. Aber wer sonst will sich da schon rumtreiben? #Myspace",
  "id" : 1304778459,
  "in_reply_to_status_id" : 1304775214,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1304839701",
  "text" : "Google Latitude d\u00FCrfte sich eigentlich ideal dazu eignen den Hund per GPS live zu tracken. Wenn ich w\u00FCsste wo meine GPS-Mouse ist.",
  "id" : 1304839701,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1304895995",
  "text" : "Das alte Windows-Mobile-Ger\u00E4t hab ich schonmal gefunden, ohne Akkuabdeckung und ohne Stylus, aber Latitude ist schonmal installiert.",
  "id" : 1304895995,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ueberwachung",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1304898436",
  "text" : "Werde dann nun mal weitersuchen nach der GPS-Mouse. Ohne taugt Latitude zum Hund tracken dann doch nicht. #ueberwachung",
  "id" : 1304898436,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1304940803",
  "geo" : { },
  "id_str" : "1305008575",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe Als Visitenkarte ist MySpace wie last.fm Super. Aber eben nicht mehr. Eine, notfalls auch schlichte, eigene Webseite hat mehr Charme.",
  "id" : 1305008575,
  "in_reply_to_status_id" : 1304940803,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305014818",
  "geo" : { },
  "id_str" : "1305085666",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe ich wage zu bezweifeln ob das so einen Riesen Unterschied macht oder aktiv ben\u00FCtzt wird. Bin allerdings kein User und daher nur raten",
  "id" : 1305085666,
  "in_reply_to_status_id" : 1305014818,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305014818",
  "geo" : { },
  "id_str" : "1305096576",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe auf jedenfall ist mir eine eigene, simple Webseite lieber als die tausendste, \u00FCberladene MySpace-Seite.",
  "id" : 1305096576,
  "in_reply_to_status_id" : 1305014818,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1305100008",
  "text" : "Bekloppt: Von Greven nach M\u00FCnster gefahren um hier den Zettel von DHL zu finden das ich mein Paket im Depot in Greven abholen darf.",
  "id" : 1305100008,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1305105311",
  "text" : "Freakiger Typ: ~60 Jahre, arschlange Rastaz\u00F6pfe mit Bomberjacke und Riesensonnenbrille im str\u00F6menden M\u00FCnster-Regen.",
  "id" : 1305105311,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305102382",
  "geo" : { },
  "id_str" : "1305110923",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe geht per Twitter, Blog etc  auf der eigenen Seite auch. :) Aber wie gesagt als Visitenkarte ist MySpace f\u00FCr Bands ein muss.",
  "id" : 1305110923,
  "in_reply_to_status_id" : 1305102382,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305102382",
  "geo" : { },
  "id_str" : "1305114551",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe sollte halt nur nicht das Hauptaush\u00E4ngeschild sein weil zu generisch und man sich 0 von anderen Bands differenziert.",
  "id" : 1305114551,
  "in_reply_to_status_id" : 1305102382,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Kr\u00FCger",
      "screen_name" : "zumpe",
      "indices" : [ 0, 6 ],
      "id_str" : "15614354",
      "id" : 15614354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305120105",
  "geo" : { },
  "id_str" : "1305133462",
  "in_reply_to_user_id" : 15614354,
  "text" : "@zumpe es ist ja auch kein entweder-oder. Man kann ja gl\u00FCcklicherweise beides betreiben was auch das Optimum sein d\u00FCrfte.",
  "id" : 1305133462,
  "in_reply_to_status_id" : 1305120105,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "zumpe",
  "in_reply_to_user_id_str" : "15614354",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tufman",
      "screen_name" : "tufman",
      "indices" : [ 0, 7 ],
      "id_str" : "14566291",
      "id" : 14566291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305111469",
  "geo" : { },
  "id_str" : "1305134883",
  "in_reply_to_user_id" : 14566291,
  "text" : "@tufman absolut, sehr l\u00E4ssiges Outfit.",
  "id" : 1305134883,
  "in_reply_to_status_id" : 1305111469,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "tufman",
  "in_reply_to_user_id_str" : "14566291",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tufman",
      "screen_name" : "tufman",
      "indices" : [ 0, 7 ],
      "id_str" : "14566291",
      "id" : 14566291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305138610",
  "geo" : { },
  "id_str" : "1305154688",
  "in_reply_to_user_id" : 14566291,
  "text" : "@tufman erstmal \u00FCberhaupt so alt werden. Und dann noch Haare haben d\u00FCrfte f\u00FCr mich ein Problem sein.",
  "id" : 1305154688,
  "in_reply_to_status_id" : 1305138610,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "tufman",
  "in_reply_to_user_id_str" : "14566291",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1305376654",
  "text" : "5 Werktage Lieferzeit. V\u00F6llig ok.  http:\/\/twitpic.com\/1z6vq",
  "id" : 1305376654,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1305387967",
  "text" : "Manchmal ist der Hund echt bl\u00F6d. Da hat er heute morgen ein neues Brustgeschirr bekommen und gerade hat er die Plastikverschl\u00FCsse zerkaut.",
  "id" : 1305387967,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "skrupel",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305601078",
  "geo" : { },
  "id_str" : "1305610062",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Vermutlich wirst du einfach abgemahnt ;) #skrupel",
  "id" : 1305610062,
  "in_reply_to_status_id" : 1305601078,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305630636",
  "geo" : { },
  "id_str" : "1305638269",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Mh gute Frage, bislang hatten wir Extrablatt und Pier House. Hast noch gute andere Vorschl\u00E4ge?",
  "id" : 1305638269,
  "in_reply_to_status_id" : 1305630636,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1305653117",
  "text" : "Mittlerweile geht der Hund liebend gerne in diversen Gew\u00E4ssern baden. Regen findet er allerdings immer noch doof und will dann nicht raus.",
  "id" : 1305653117,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Mayer",
      "screen_name" : "monimays",
      "indices" : [ 0, 9 ],
      "id_str" : "14218394",
      "id" : 14218394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1305669614",
  "geo" : { },
  "id_str" : "1305700880",
  "in_reply_to_user_id" : 14218394,
  "text" : "@monimays Ne beim Trinkwasser ist es umgekehrt, frisches Wasser ist bl\u00F6d, wirklich lecker wird es erst wenn es abgestanden ist. :)",
  "id" : 1305700880,
  "in_reply_to_status_id" : 1305669614,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "monimays",
  "in_reply_to_user_id_str" : "14218394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MS",
      "indices" : [ 55, 58 ]
    }, {
      "text" : "Tweetup",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "muenster",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1305703141",
  "text" : "RT @lorXsion: Die Mehrheit hat entschieden das n\u00E4chste #MS #Tweetup ist am 15.4. http:\/\/tr.im\/hcQW #muenster",
  "id" : 1305703141,
  "created_at" : "2009-03-10 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299541938",
  "text" : "@houellebeck Ja die lieben Linken, irgendwie muss man doch einen Nazivergleich provozieren k\u00F6nnen. ;)",
  "id" : 1299541938,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299751988",
  "text" : "Oha, mein Mailpostfach geht wieder. Sch\u00F6n endlich den Spam von 4 Tagen entfernen zu k\u00F6nnen.",
  "id" : 1299751988,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299796854",
  "text" : "Ist das sch\u00F6n wieder ganz normal Mails zugestellt zu bekommen. K\u00F6nnte den Manitu-Techniker der sich das Problem angeschaut hat k\u00FCssen.",
  "id" : 1299796854,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299881453",
  "text" : "Die Webseite der deutschen Atheist-Bus-Campaign ist heute gestartet, leider mit nicht ganz so tollen Slogans wie in UK: http:\/\/bit.ly\/10UDoR",
  "id" : 1299881453,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299889993",
  "text" : "@houellebeck Gro\u00DFartig, das w\u00E4re auch nicht schlecht gewesen f\u00FCr die deutschen Busse :D",
  "id" : 1299889993,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slogans",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "buskampagne",
      "indices" : [ 88, 100 ]
    }, {
      "text" : "atheistbuscampaign",
      "indices" : [ 101, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299905023",
  "text" : "@houellebeck Sind arg bem\u00FCht irgendwie. Typisch Deutsch k\u00F6nnte man auch sagen. #slogans #buskampagne #atheistbuscampaign",
  "id" : 1299905023,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "krampfig",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299915743",
  "text" : "@houellebeck Dabei ist der Stock im Arsch doch sonst mehr Sache der Religionen #krampfig",
  "id" : 1299915743,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "asta",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299922922",
  "text" : "@houellebeck Rosa SS-Uniformen um schwule Nazi-Abtreibungsbef\u00FCrworter zu verk\u00F6rpern w\u00E4re bei der Demo der Hit f\u00FCr alle Parteien.  #asta",
  "id" : 1299922922,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maennerinuniform",
      "indices" : [ 94, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299929879",
  "text" : "@houellebeck Die Frage ist nur: Wo bekommt man sowas so schnell her? Karneval ist doch vorbei #maennerinuniform",
  "id" : 1299929879,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 0, 12 ],
      "id_str" : "428633",
      "id" : 428633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1299946074",
  "geo" : { },
  "id_str" : "1299958480",
  "in_reply_to_user_id" : 428633,
  "text" : "@kwerfeldein Coole Idee, funktioniert leider nur sehr mittelm\u00E4ssig da die Keyword-Datenbank mau ist. Und Zusammenh\u00E4nge kaputt gehen.",
  "id" : 1299958480,
  "in_reply_to_status_id" : 1299946074,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "kwerfeldein",
  "in_reply_to_user_id_str" : "428633",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299959418",
  "text" : "Macht sich nun auf den Weg Fr\u00FChst\u00FCck zu jagen. Discount-B\u00E4cker ich komme.",
  "id" : 1299959418,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1300053296",
  "text" : "@houellebeck Und schon Feedback bekommen zwecks modischem Auftreten? ;)",
  "id" : 1300053296,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1300084185",
  "text" : "@houellebeck Wurden die etwa schon in Paris \u00FCber den Laufsteg getragen?",
  "id" : 1300084185,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1300475652",
  "text" : "Die Abfallbetriebe M\u00FCnster haben online eine Tel.-Nr. um Standorte f\u00FCr Glascontainer zu erfragen. Wieso keine Liste od. Karte? #fail",
  "id" : 1300475652,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buskampagne",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1300666620",
  "text" : "@JoergR Leider. Ich versteh auch nicht wieso nicht die viel besseren Vorschl\u00E4ge aus der Umfrage benutzt wurden... #buskampagne",
  "id" : 1300666620,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1300852581",
  "text" : "@JoergR Ich fand A eigentlich noch am besten von den schlechten Vorschl\u00E4gen",
  "id" : 1300852581,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freizeitstress",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1300855728",
  "text" : "Mist, wieso sind am Samstag eigentlich wieder zwei Konzerte parallel die ich besuchen wollen w\u00FCrde? #freizeitstress",
  "id" : 1300855728,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max von Webel",
      "screen_name" : "343max",
      "indices" : [ 79, 86 ],
      "id_str" : "2284151",
      "id" : 2284151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1301815419",
  "text" : "Gut das jetzt jeder sehen kann in welchen Berliner Restaurants es fies ist: RT @343max: M\u00E4use in Berliner Kneipen! http:\/\/twitpic.com\/1ymdx",
  "id" : 1301815419,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1301995347",
  "text" : "Oh, jetzt hab ich ganz die neue Simpsonsfolge verpasst. Hab ich wirklich was verpasst oder war es wieder mau?",
  "id" : 1301995347,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kycis",
      "screen_name" : "kycis",
      "indices" : [ 0, 6 ],
      "id_str" : "17200285",
      "id" : 17200285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tierfotos",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1302084361",
  "geo" : { },
  "id_str" : "1302098573",
  "in_reply_to_user_id" : 17200285,
  "text" : "@kycis Wie s\u00FC\u00DF! #tierfotos :)",
  "id" : 1302098573,
  "in_reply_to_status_id" : 1302084361,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "kycis",
  "in_reply_to_user_id_str" : "17200285",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sevenmac",
      "screen_name" : "sevenmac",
      "indices" : [ 0, 9 ],
      "id_str" : "16426577",
      "id" : 16426577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1302165772",
  "geo" : { },
  "id_str" : "1302186099",
  "in_reply_to_user_id" : 16426577,
  "text" : "@sevenmac Eure Links gehen nicht.",
  "id" : 1302186099,
  "in_reply_to_status_id" : 1302165772,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "sevenmac",
  "in_reply_to_user_id_str" : "16426577",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1302370533",
  "text" : "Erstmal alle Esoterik-Freaks unfollowt...",
  "id" : 1302370533,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buskampagne",
      "indices" : [ 86, 98 ]
    }, {
      "text" : "atheistbus",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1302381189",
  "text" : "Ein kleiner Beitrag von mir zur deutschen Atheist-Bus-Campaign:  http:\/\/bit.ly\/18Enh0 #buskampagne #atheistbus",
  "id" : 1302381189,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1302508994",
  "text" : "F\u00E4nd es cool wenn man Twitter & seine Feeds endlich zwischen PC\/Mac & iPhone synchron halten k\u00F6nnte. Das ist doch nicht Rocketscience. Oder?",
  "id" : 1302508994,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannes",
      "screen_name" : "ht82",
      "indices" : [ 0, 5 ],
      "id_str" : "5457652",
      "id" : 5457652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1302511449",
  "geo" : { },
  "id_str" : "1302541413",
  "in_reply_to_user_id" : 5457652,
  "text" : "@ht82 iTunes ist auf dem Mac auch scheisse. Nur etwas besser in das System integriert so das man schlechter drumherumkommt...",
  "id" : 1302541413,
  "in_reply_to_status_id" : 1302511449,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ht82",
  "in_reply_to_user_id_str" : "5457652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannes",
      "screen_name" : "ht82",
      "indices" : [ 0, 5 ],
      "id_str" : "5457652",
      "id" : 5457652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1302584349",
  "geo" : { },
  "id_str" : "1302617263",
  "in_reply_to_user_id" : 5457652,
  "text" : "@ht82 Tags sind toll, die automatische Verwaltung von iTunes aber ein Witz. Das k\u00F6nnen jede Menge OpenSourceAlternativen besser...",
  "id" : 1302617263,
  "in_reply_to_status_id" : 1302584349,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ht82",
  "in_reply_to_user_id_str" : "5457652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannes",
      "screen_name" : "ht82",
      "indices" : [ 0, 5 ],
      "id_str" : "5457652",
      "id" : 5457652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1302593177",
  "geo" : { },
  "id_str" : "1302623865",
  "in_reply_to_user_id" : 5457652,
  "text" : "@ht82 vor allem in iTunes taggen geht so gar nicht. Batch-Verarbeitung at it's worst.",
  "id" : 1302623865,
  "in_reply_to_status_id" : 1302593177,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ht82",
  "in_reply_to_user_id_str" : "5457652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannes",
      "screen_name" : "ht82",
      "indices" : [ 0, 5 ],
      "id_str" : "5457652",
      "id" : 5457652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1302635327",
  "geo" : { },
  "id_str" : "1302673608",
  "in_reply_to_user_id" : 5457652,
  "text" : "@ht82 selbstgebrannte Compilations, runtergeladene CC-Musik und so Zeug. Und alle CDs erkennt iTunes auch nicht.",
  "id" : 1302673608,
  "in_reply_to_status_id" : 1302635327,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ht82",
  "in_reply_to_user_id_str" : "5457652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299513740",
  "text" : "@houellebeck Die Internationale tritt das Menschenrecht... oder wie? ;) Ahja machen wir da nun mit bei der Kreuzdemo? :D",
  "id" : 1299513740,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1299517665",
  "text" : "Gerade Wohnungsbesichtigung bei den Bandidos gehabt.Unglaublich wie spiessig harte Rocker eingerichtet sein k\u00F6nnen.",
  "id" : 1299517665,
  "created_at" : "2009-03-09 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1295798151",
  "text" : "Guten Morgen. Gleich gehts dem Newton seine Werke beschauen.",
  "id" : 1295798151,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterfon",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1295802286",
  "geo" : { },
  "id_str" : "1295873719",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 ja hab das gleiche Problem #twitterfon",
  "id" : 1295873719,
  "in_reply_to_status_id" : 1295802286,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcus",
      "screen_name" : "maggi72",
      "indices" : [ 0, 8 ],
      "id_str" : "16603086",
      "id" : 16603086
    }, {
      "name" : "TwitterFon",
      "screen_name" : "TwitterFon",
      "indices" : [ 12, 23 ],
      "id_str" : "15613175",
      "id" : 15613175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1295802286",
  "geo" : { },
  "id_str" : "1295876821",
  "in_reply_to_user_id" : 16603086,
  "text" : "@maggi72 RT @TwitterFon: Profile view bug on v1.4.2: http:\/\/tinyurl.com\/bd6grp Wird behoben sobald Apple das Update bewilligt.",
  "id" : 1295876821,
  "in_reply_to_status_id" : 1295802286,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "maggi72",
  "in_reply_to_user_id_str" : "16603086",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1295915212",
  "text" : "Jetzt ein bisschen Fotos schauen. Frage mich noch wie Newton auf seinen K\u00FCnstlernamen kam.  - http:\/\/bkite.com\/05iAJ",
  "id" : 1295915212,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1295939251",
  "text" : "Ratet mal welches Museum heute f\u00FCr geschlossene Gesellschaft ist..",
  "id" : 1295939251,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1295954472",
  "text" : "@njeppo das bl\u00F6de Picasso-Museum wegen Ausstellungser\u00F6ffnung. Ohne davon mal irgendwo was auf der Webseite zu verraten.",
  "id" : 1295954472,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1295979355",
  "geo" : { },
  "id_str" : "1295996394",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion ja total bl\u00F6d. Verstehe auch nicht wieso sie das nicht online erw\u00E4hnen. Daf\u00FCr ist das Web doch da.",
  "id" : 1295996394,
  "in_reply_to_status_id" : 1295979355,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1295999293",
  "geo" : { },
  "id_str" : "1296006516",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Naja aber das konnte man ja trotzdem irgendwo vermerken anstatt die Standardzeiten zu ver\u00F6ffentlichen.",
  "id" : 1296006516,
  "in_reply_to_status_id" : 1295999293,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1296072422",
  "text" : "Done! Das Cryptonomicon ist durch. In der Tat ein seeehr gutes Buch.",
  "id" : 1296072422,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1296081777",
  "geo" : { },
  "id_str" : "1296085304",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr W\u00E4re sch\u00F6n wenn dann mal mehr Leute zu den TweetUps kommen w\u00FCrden :)",
  "id" : 1296085304,
  "in_reply_to_status_id" : 1296081777,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1296084538",
  "geo" : { },
  "id_str" : "1296090627",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Worum soll es denn gehen?",
  "id" : 1296090627,
  "in_reply_to_status_id" : 1296084538,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1296092483",
  "geo" : { },
  "id_str" : "1296093643",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Wie w\u00E4re es mit Anwendungsbeispielen?",
  "id" : 1296093643,
  "in_reply_to_status_id" : 1296092483,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rg Friedrich",
      "screen_name" : "JoergFr",
      "indices" : [ 0, 8 ],
      "id_str" : "14508163",
      "id" : 14508163
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TweetUps",
      "indices" : [ 125, 134 ]
    }, {
      "text" : "MS",
      "indices" : [ 135, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1296104760",
  "geo" : { },
  "id_str" : "1296108894",
  "in_reply_to_user_id" : 14508163,
  "text" : "@JoergFr Treffen der M\u00FCnsteraner Twitter--User, \u00FCber den n\u00E4chsten Termin wird zur Zeit abgestimmt: http:\/\/twtpoll.com\/ebo1km #TweetUps #MS",
  "id" : 1296108894,
  "in_reply_to_status_id" : 1296104760,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "JoergFr",
  "in_reply_to_user_id_str" : "14508163",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henrik M. Simensen",
      "screen_name" : "Henrikms",
      "indices" : [ 0, 9 ],
      "id_str" : "228005950",
      "id" : 228005950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Papst",
      "indices" : [ 83, 89 ]
    }, {
      "text" : "imperator",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1296872636",
  "text" : "@henrikMS was will er da? Auch gegen Juden, Moslems, Schwule und Verh\u00FCtung p\u00F6beln? #Papst #imperator",
  "id" : 1296872636,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1297085849",
  "text" : "Da ich ja momentan quasi \u00FCber endlos Zeit verf\u00FCge um dicke W\u00E4lzer zu lesen: Welchen Stephenson als n\u00E4chstes?",
  "id" : 1297085849,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitterFon",
      "screen_name" : "TwitterFon",
      "indices" : [ 27, 38 ],
      "id_str" : "15613175",
      "id" : 15613175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1297090856",
  "text" : "No conversationview in new @twitterfon ?",
  "id" : 1297090856,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kwerfeldein",
      "screen_name" : "kwerfeldein",
      "indices" : [ 0, 12 ],
      "id_str" : "428633",
      "id" : 428633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fotoquiz",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1297101499",
  "geo" : { },
  "id_str" : "1297108416",
  "in_reply_to_user_id" : 428633,
  "text" : "@kwerfeldein Bezeichnet die Gr\u00F6\u00DFe der \u00D6ffnung durch die Licht das Objektiv passieren kann. Angegeben in Relation zur Brennweite #Fotoquiz",
  "id" : 1297108416,
  "in_reply_to_status_id" : 1297101499,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "kwerfeldein",
  "in_reply_to_user_id_str" : "428633",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1297108735",
  "geo" : { },
  "id_str" : "1297116616",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Werde ich mir dann mal ansehen. Und erstmal schauen ob noch mehr Feedback kommt :)",
  "id" : 1297116616,
  "in_reply_to_status_id" : 1297108735,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cp145",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1297126216",
  "geo" : { },
  "id_str" : "1297130524",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod H\u00F6rb\u00FCcher find ich immer noch zu stressig. Lese da lieber als zu h\u00F6ren. #cp145",
  "id" : 1297130524,
  "in_reply_to_status_id" : 1297126216,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1297201867",
  "text" : "@JoergR Dann sollte ich das vielleicht erstmal in Angriff nehmen solange die Zeit vorhanden ist :)",
  "id" : 1297201867,
  "created_at" : "2009-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1289694925",
  "geo" : { },
  "id_str" : "1290837805",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion na das kleine ist sicher auch nicht schlecht :)",
  "id" : 1290837805,
  "in_reply_to_status_id" : 1289694925,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PHD_Comics",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1292225910",
  "text" : "Gar nicht so unverbreitet. http:\/\/tinyurl.com\/bpuezw #PHD_Comics",
  "id" : 1292225910,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus",
      "screen_name" : "germanstudent",
      "indices" : [ 0, 14 ],
      "id_str" : "2493441",
      "id" : 2493441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1292360541",
  "geo" : { },
  "id_str" : "1292370766",
  "in_reply_to_user_id" : 2493441,
  "text" : "@germanstudent RAW hat den Nachteil das du mehr od. weniger zu rudiment\u00E4rer Nachbearbeitung gezwungen bist.Ob Vor oder Nachteil liegt an dir",
  "id" : 1292370766,
  "in_reply_to_status_id" : 1292360541,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "germanstudent",
  "in_reply_to_user_id_str" : "2493441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1292465935",
  "text" : "#muenster http:\/\/twitpic.com\/1wg30",
  "id" : 1292465935,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1292604500",
  "text" : "Spiele gerade mit isightcapture rum. Sehr lustig was man damit machen kann.",
  "id" : 1292604500,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1289969850",
  "geo" : { },
  "id_str" : "1292615562",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Das seh ich genauso. Es k\u00F6nnte noch um einiges schlimmer kommen. Deshalb sollten wir uns aber nicht faul zur\u00FCcklehnen.",
  "id" : 1292615562,
  "in_reply_to_status_id" : 1289969850,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rozana Renger",
      "screen_name" : "Rozana",
      "indices" : [ 3, 10 ],
      "id_str" : "6085542",
      "id" : 6085542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1292689043",
  "text" : "RT @Rozana: Katholische Kirche nimmt exkommunizierte Anti-Computer-Sekte wieder auf http:\/\/snurl.com\/dbvlt - Ich steige aus der Kirche aus!",
  "id" : 1292689043,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1292708278",
  "text" : "Der Hund ist definitiv noch kein Autofahrer. Hat gut den Kofferraum vollgekotzt.",
  "id" : 1292708278,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XiongShui \u99AC\u5144\u6C34",
      "screen_name" : "XiongShui",
      "indices" : [ 0, 10 ],
      "id_str" : "9159892",
      "id" : 9159892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1292907098",
  "in_reply_to_user_id" : 9159892,
  "text" : "@XiongShui Aye das kotzen ist auch bei Hunden mitinbegriffen im Preis.",
  "id" : 1292907098,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "XiongShui",
  "in_reply_to_user_id_str" : "9159892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit van Aaken",
      "screen_name" : "gerritvanaaken",
      "indices" : [ 0, 15 ],
      "id_str" : "1002981",
      "id" : 1002981
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cebit",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1293304875",
  "geo" : { },
  "id_str" : "1293311732",
  "in_reply_to_user_id" : 1002981,
  "text" : "@gerritvanaaken Seit wann Tragen diese Leute denn Anz\u00FCge?  #cebit",
  "id" : 1293311732,
  "in_reply_to_status_id" : 1293304875,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "gerritvanaaken",
  "in_reply_to_user_id_str" : "1002981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1293516665",
  "text" : "H\u00E4tte ich nicht einen Anruf bekommen h\u00E4tte ich von der Helmut Newton-Ausstellung in M\u00FCnster nichts mitbekommen http:\/\/bit.ly\/ZYzSJ #muenster",
  "id" : 1293516665,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1293531973",
  "geo" : { },
  "id_str" : "1293569526",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster Kunst\/Kulturveranstaltungskalender als RSS-Feed oder abonnierbarer Kalender. Das w\u00E4re doch mal was f\u00FCr euch. #muenster",
  "id" : 1293569526,
  "in_reply_to_status_id" : 1293531973,
  "created_at" : "2009-03-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1287692723",
  "text" : "Guten Morgen. Ist gestern doch sp\u00E4t geworden, so mit dem Cryptonomicon im Bett.",
  "id" : 1287692723,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1287788046",
  "text" : "Seltsam. iPhone schon wieder \u00FCber Nacht leergesaugt worden. Dabei mit 90% Akku gestern Abend Weggelegt.",
  "id" : 1287788046,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 0, 12 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iPhone",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1287799149",
  "text" : "@houellebeck Ne, alles aus im Standby-Modus gehabt. Benutzung mit der Akkuladung: 2 Stunden. Standby: 16 Stunden. Sehr seltsam #iPhone",
  "id" : 1287799149,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1287869746",
  "geo" : { },
  "id_str" : "1287875270",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Ja, aber zum jetzigen Zeitpunkt bekleckert sich ja keine der Parteien mit Ruhm was das angeht.",
  "id" : 1287875270,
  "in_reply_to_status_id" : 1287869746,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1287885989",
  "text" : "Herrlich subtil:  http:\/\/bit.ly\/FAzos",
  "id" : 1287885989,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1287905321",
  "geo" : { },
  "id_str" : "1287910521",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Glaube ich nicht :)",
  "id" : 1287910521,
  "in_reply_to_status_id" : 1287905321,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1287915117",
  "geo" : { },
  "id_str" : "1287918206",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Der Statistikkurs k\u00F6nnte nur zuf\u00E4llig mit der Erkenntnis korrellieren",
  "id" : 1287918206,
  "in_reply_to_status_id" : 1287915117,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1287924928",
  "geo" : { },
  "id_str" : "1287928447",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Naja ist halt immer so wenn man den Witz erst erkl\u00E4rt kriegen muss oder? :=",
  "id" : 1287928447,
  "in_reply_to_status_id" : 1287924928,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1287931780",
  "text" : "Wieso updated TweetDeck bittesch\u00F6n meine normale Timeline nicht mehr?",
  "id" : 1287931780,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1288253962",
  "geo" : { },
  "id_str" : "1288290817",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Klar, rudiment\u00E4r funktioniert es. Und auch besser als in anderen L\u00E4ndern. Deshalb ist es ja nicht das Optimum oder?",
  "id" : 1288290817,
  "in_reply_to_status_id" : 1288253962,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1288297409",
  "text" : "Juhu, die Uhr ist schon in Frankfurt angekommen. Darf ich Montag vermutlich schon wieder beim Zoll aufschlagen.",
  "id" : 1288297409,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1288309813",
  "text" : "Hat eigentlich noch jemand Probleme mit TweetDeck heute?",
  "id" : 1288309813,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1288617996",
  "text" : "Und wieder ein bisschen Lesepause einlegen. 100 Seiten fehlen noch",
  "id" : 1288617996,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1288666231",
  "geo" : { },
  "id_str" : "1288673302",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Na wirds nun doch endlich was mit dem Mac? ;)",
  "id" : 1288673302,
  "in_reply_to_status_id" : 1288666231,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1288949404",
  "text" : "Alle paar Minuten versagt TweetDeck total den Dienst. Dann halt doch wieder Twitterfon only.",
  "id" : 1288949404,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1289231215",
  "geo" : { },
  "id_str" : "1289558854",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion mit dem MBP kannst du eigentlich nichts falsch machen. :)",
  "id" : 1289558854,
  "in_reply_to_status_id" : 1289231215,
  "created_at" : "2009-03-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282621834",
  "text" : "@JoergR ich bin gro\u00DFer DOI-Fan. Finden geht doch fix \u00FCber die Webseite des DOI. Ist besser als Google.",
  "id" : 1282621834,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282648488",
  "text" : "@JoergR Ah den DOI in Google hab ich nie getestet. Aber deren Webseite leitet ja gleich zum Paper :)",
  "id" : 1282648488,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282649645",
  "text" : "@JoergR Ah du hast es schon gefunden. Freut mich geholfen zu haben.",
  "id" : 1282649645,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282701066",
  "text" : "@JoergR Ah das ist cool. Werd ich mir mal ansehen.",
  "id" : 1282701066,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282702510",
  "text" : "@JoergR Schade, funktioniert noch nicht mit der neusten Firefox-Beta die ich benutze.",
  "id" : 1282702510,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282763241",
  "text" : "Irgendwie ist eMail heute komisch. Mail auf dem iPhone zeigt mir immer wieder 12 Mails als neu an und zaubert sie wieder her. Trotz l\u00F6schen.",
  "id" : 1282763241,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "luanacaf",
      "screen_name" : "twitchhiker",
      "indices" : [ 3, 15 ],
      "id_str" : "2561402600",
      "id" : 2561402600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282784948",
  "text" : "RT @twitchhiker: Only now I realise the sum total of my German vocabulary was learnt from Indiana Jones and the Last Crusade.",
  "id" : 1282784948,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282890941",
  "text" : "Mail auf dem iPhone l\u00E4uft weiter Amok, nur woran liegt es? Am iPhone? An Mail auf OS X? An meinem Mailaccount?",
  "id" : 1282890941,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282967025",
  "text" : "Hab das Gef\u00FChl das die Mailbox jetzt gerade Fubar ist.",
  "id" : 1282967025,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1282969333",
  "geo" : { },
  "id_str" : "1282979925",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Kauf dir doch selber 4 St\u00FCck und verscherbel 3 bei Ebay ;)",
  "id" : 1282979925,
  "in_reply_to_status_id" : 1282969333,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1282981991",
  "text" : "Ich mach jetzt erstmal ein Backup der Mails. Nur f\u00FCr den ganz ganz absoluten Notfall",
  "id" : 1282981991,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1282981970",
  "geo" : { },
  "id_str" : "1282985680",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Na abe dann brauchste ja doch nur 2 Leute die noch mitbestellen ;)",
  "id" : 1282985680,
  "in_reply_to_status_id" : 1282981970,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1283066121",
  "text" : "Kinder find ich nicht so toll... \u266B http:\/\/blip.fm\/~2oerv",
  "id" : 1283066121,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1283162183",
  "text" : "Das sch\u00F6ne am Internet ist ja das jeder in Text, Bild & Ton seinen Schwachsinn der Welt zug\u00E4nglich machen kann. http:\/\/bit.ly\/YaWwR",
  "id" : 1283162183,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "netzpolitik",
      "screen_name" : "netzpolitik",
      "indices" : [ 3, 15 ],
      "id_str" : "9655032",
      "id" : 9655032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1283782405",
  "text" : "RT @netzpolitik: Zitat: \"J\u00F6rg Tauss h\u00E4tte besser eine Ehefrau und Mutter bei einem Skiunfall t\u00F6ten sollen, da kommt man einfacher raus.\"",
  "id" : 1283782405,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1284246177",
  "text" : "Jetzt soll sich der manitu-Support mal um meine Mailbox k\u00FCmmern, ich find den Fehler ums verrecken nicht. Solange gmail oder Uni-Mail.",
  "id" : 1284246177,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1284172805",
  "geo" : { },
  "id_str" : "1284250672",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Schwierig, allerdings glaube ich immer noch das mehr direkte Demokratie besser ist als verstaubtes Parteiendenken.",
  "id" : 1284250672,
  "in_reply_to_status_id" : 1284172805,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1284428252",
  "text" : "Immerhin kann ich die Programme von iTunes zu iPhone wieder synchronisieren.",
  "id" : 1284428252,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1285087127",
  "text" : "So wieder zur\u00FCck von den Pfadfindern.",
  "id" : 1285087127,
  "created_at" : "2009-03-05 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1277854676",
  "text" : "Oha, das iPhone ist gestern wohl nicht von selber in den Standby gegangen. Auf jedenfall war der Akku heute morgen v\u00F6llig leer.",
  "id" : 1277854676,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1277880390",
  "geo" : { },
  "id_str" : "1277882633",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Hatte es ohne in den Standby zu schicken in die Hosentasche gelegt. Allerdings mit dem Homescreen an, sehr seltsam.",
  "id" : 1277882633,
  "in_reply_to_status_id" : 1277880390,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1277903186",
  "text" : "Ich bin wirklich unschl\u00FCssig, ist das Satire oder ernst gemeint?  http:\/\/bit.ly\/8Zju",
  "id" : 1277903186,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1277907426",
  "text" : "Ich h\u00E4tte einfach die Userpage besuchen k\u00F6nnen. Es ist Satire. Gl\u00FCck gehabt.",
  "id" : 1277907426,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1278298087",
  "text" : "So erstmal eine Pause vom Cryptonomicon einlegen, finde keine entspannte Position mehr um das Buch noch halten zu k\u00F6nnen.",
  "id" : 1278298087,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1278613556",
  "text" : "Neeein! Keine Zigaretten mehr, jetzt muss ich das lesen schon wieder unterbrechen.",
  "id" : 1278613556,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1278723059",
  "text" : "Verdammt, musste gerade alle iPhone-Apps neu installieren. Jetzt ist die gro\u00DFe Sortierorgie angesagt...",
  "id" : 1278723059,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279248658",
  "geo" : { },
  "id_str" : "1279535695",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod das Problem war das iTunes keine App-Updates mehr von iTunes zum iPhone laden wollte.",
  "id" : 1279535695,
  "in_reply_to_status_id" : 1279248658,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279547571",
  "geo" : { },
  "id_str" : "1279566644",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod lag irgendwo in den Synchrondaten. Hab einmal alle Programme vom iPhone entfernt und neu drauf nun geht es wieder.",
  "id" : 1279566644,
  "in_reply_to_status_id" : 1279547571,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279547571",
  "geo" : { },
  "id_str" : "1279568779",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Reboot half nicht. Backup ebenfalls nicht.",
  "id" : 1279568779,
  "in_reply_to_status_id" : 1279547571,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279631113",
  "geo" : { },
  "id_str" : "1279669318",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod mh ne. Zumindest seit einiger Zeit nicht mehr.",
  "id" : 1279669318,
  "in_reply_to_status_id" : 1279631113,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1279796223",
  "text" : "Mh scheint doch nichts gebracht zu haben. Werd nochmal ein Backup ins Telefon einspielen.",
  "id" : 1279796223,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279803519",
  "geo" : { },
  "id_str" : "1279807049",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ja ich spiel damit. Habe aber auch sonst gar nichts installiert auf dem Ding. Und das iPhone ist seit dem MBP Windowsfrei.",
  "id" : 1279807049,
  "in_reply_to_status_id" : 1279803519,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279830814",
  "geo" : { },
  "id_str" : "1279907228",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Beim Backup einspielen bleiben die Icons genauso wenig erhalten wenn man vorher zur\u00FCcksetzt...",
  "id" : 1279907228,
  "in_reply_to_status_id" : 1279830814,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279928514",
  "geo" : { },
  "id_str" : "1279936786",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod H\u00F6rt sich ja so an als w\u00E4re Apple viel viel besser als Microsoft ;)",
  "id" : 1279936786,
  "in_reply_to_status_id" : 1279928514,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279929512",
  "geo" : { },
  "id_str" : "1279946943",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Nun hab ich alles manuell geschubst. Zumindest f\u00FCr die ersten beiden Screens, der Rest ist eh nicht sortiert",
  "id" : 1279946943,
  "in_reply_to_status_id" : 1279929512,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thopex",
      "screen_name" : "thopex",
      "indices" : [ 0, 7 ],
      "id_str" : "6266362",
      "id" : 6266362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Icons",
      "indices" : [ 123, 129 ]
    }, {
      "text" : "iPhone",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279972554",
  "geo" : { },
  "id_str" : "1280059015",
  "in_reply_to_user_id" : 6266362,
  "text" : "@thopex Ja das mit den Icons ist ab mehr als 3 Seiten ein Horror in Sachen Benutzerfreundlichkeit. Besonders das sortieren #Icons #iPhone",
  "id" : 1280059015,
  "in_reply_to_status_id" : 1279972554,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "thopex",
  "in_reply_to_user_id_str" : "6266362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1279994846",
  "geo" : { },
  "id_str" : "1280061091",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ne danke, aber du musst zugeben dass sowas echt buggy und unsinnig ist. Und das die Icons auch nur suboptimal sind.",
  "id" : 1280061091,
  "in_reply_to_status_id" : 1279994846,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1280111205",
  "geo" : { },
  "id_str" : "1280132337",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Mh die Daten sind gleich beim ersten mal r\u00FCber. Hab noch alle Feeds und Einstellungen, daran kann es also nicht liegen.",
  "id" : 1280132337,
  "in_reply_to_status_id" : 1280111205,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1280184697",
  "text" : "Ausgezeichnete Feiertagsidee, noch besser als der Evolutionstag: der Blasphemy-Day: http:\/\/tinyurl.com\/bk7o3y",
  "id" : 1280184697,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1280205778",
  "text" : "So jetzt bin ich mal gespannt ob in Zukunft die Updates wieder in beide Richtungen gehen. Hab gerade leider nichts zum Updaten zur Hand.",
  "id" : 1280205778,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Heinrichs",
      "screen_name" : "ComPod",
      "indices" : [ 0, 7 ],
      "id_str" : "12408302",
      "id" : 12408302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1280305735",
  "geo" : { },
  "id_str" : "1280310585",
  "in_reply_to_user_id" : 12408302,
  "text" : "@ComPod Ah, alles klar. Apple sollte es erlauben die Pl\u00E4tze \u00FCber iTunes einzustellen und Gruppierungen zu erlauben.",
  "id" : 1280310585,
  "in_reply_to_status_id" : 1280305735,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "ComPod",
  "in_reply_to_user_id_str" : "12408302",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1280587364",
  "text" : "Andere AIM-User hier die ihre Kontaktliste gerade nicht abgerufen bekommen?",
  "id" : 1280587364,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1280652076",
  "geo" : { },
  "id_str" : "1280654092",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Okay, dann liegts ja nicht an mir und ich bin beruhigt :)",
  "id" : 1280654092,
  "in_reply_to_status_id" : 1280652076,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1280684454",
  "geo" : { },
  "id_str" : "1280699839",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Indeed, sehr gut",
  "id" : 1280699839,
  "in_reply_to_status_id" : 1280684454,
  "created_at" : "2009-03-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1273912019",
  "text" : "Oh, es gibt TapTapRevenge2 kostenlos f\u00FCr das iPhone. Den ersten Teil fand ich schon super.Besonders der Multiplayermode  http:\/\/bit.ly\/pz0wR",
  "id" : 1273912019,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273662125",
  "geo" : { },
  "id_str" : "1274046323",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ah schade das wir uns dann verpassen.",
  "id" : 1274046323,
  "in_reply_to_status_id" : 1273662125,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Koch",
      "screen_name" : "okomuenster",
      "indices" : [ 0, 12 ],
      "id_str" : "10912532",
      "id" : 10912532
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1274711889",
  "geo" : { },
  "id_str" : "1274738926",
  "in_reply_to_user_id" : 10912532,
  "text" : "@okomuenster Probleme mit dem Abwasser? #muenster",
  "id" : 1274738926,
  "in_reply_to_status_id" : 1274711889,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "okomuenster",
  "in_reply_to_user_id_str" : "10912532",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1274848597",
  "text" : "Das Cryptonomicon hat mich gefesselt. Der gro\u00DFe Nachteil: Man kann dabei so schlecht Twitter im Auge behalten.",
  "id" : 1274848597,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Milissa",
      "screen_name" : "pasqualle",
      "indices" : [ 0, 10 ],
      "id_str" : "2531726499",
      "id" : 2531726499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1275114054",
  "text" : "@pasQualle Und dann das Foto von einem angehenden Biologen zur Illustration benutzen ;)",
  "id" : 1275114054,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uhr",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1275512445",
  "text" : "Hab die \u201EProgression\u201C bei Tokyoflash bestellt. #uhr",
  "id" : 1275512445,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1273097859",
  "text" : "Guten Morgen zusammen",
  "id" : 1273097859,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tweetup",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "M\u00FCnster",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1273104340",
  "text" : "RT @lorXsion: Kleiner Hinweis auf unsere aktuelle Terminabstimmung zum #Tweetup #M\u00FCnster http:\/\/tr.im\/gWj0",
  "id" : 1273104340,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273197859",
  "geo" : { },
  "id_str" : "1273222099",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Ja, aber ich meinte auch die erste Befragung. So weit fand ich das gut. Naja es gibt halt kein ideales System bzw...",
  "id" : 1273222099,
  "in_reply_to_status_id" : 1273197859,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273197859",
  "geo" : { },
  "id_str" : "1273222580",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye ...die Menschen sind nicht so ideal wie sie f\u00FCr Demokratie sein m\u00FCssten.",
  "id" : 1273222580,
  "in_reply_to_status_id" : 1273197859,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1273354941",
  "text" : "die cebit finde ich schon seit Jahren ziemlich \u00F6de muss ich sagen.",
  "id" : 1273354941,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273499293",
  "geo" : { },
  "id_str" : "1273550967",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan Haben die PayPal etwa schon wieder abgeschafft?",
  "id" : 1273550967,
  "in_reply_to_status_id" : 1273499293,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1273601543",
  "text" : "Ich werd am 13.03. in Berlin sein, nicht zum ersten Mal. Irgendwelche Tipps was man abseits der Standardsachen sehen sollte.",
  "id" : 1273601543,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273607893",
  "geo" : { },
  "id_str" : "1273610572",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan Also ich hab bei PayPal mein ganz normales Girokonto angegeben und dann zieht PayPal davon ein",
  "id" : 1273610572,
  "in_reply_to_status_id" : 1273607893,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273607893",
  "geo" : { },
  "id_str" : "1273622604",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan \u00DCber \u201CMein Konto\u201D l\u00E4sst sich ein normales Bankkonto eintragen.",
  "id" : 1273622604,
  "in_reply_to_status_id" : 1273607893,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rp09",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1273645078",
  "text" : "Yeah, Lawrence Lessig auf der #rp09  http:\/\/bit.ly\/pIut7",
  "id" : 1273645078,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "paypal",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273635434",
  "geo" : { },
  "id_str" : "1273649148",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan Mh das ist seltsam.Bei mir geht es problemlos.Wenn ich das w\u00E4hle komme ich zur Seite wo ich die Bankdaten eintragen muss. #paypal",
  "id" : 1273649148,
  "in_reply_to_status_id" : 1273635434,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakMaksan",
      "screen_name" : "MakMaksan",
      "indices" : [ 0, 10 ],
      "id_str" : "17112939",
      "id" : 17112939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273664373",
  "geo" : { },
  "id_str" : "1273711083",
  "in_reply_to_user_id" : 17112939,
  "text" : "@MakMaksan Okay, ist bei mir schon ein paar Jahre her das ich das eingerichtet habe. Da kam das auf jedenfall nicht :)",
  "id" : 1273711083,
  "in_reply_to_status_id" : 1273664373,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "MakMaksan",
  "in_reply_to_user_id_str" : "17112939",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273768104",
  "geo" : { },
  "id_str" : "1273780045",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron die gro\u00DFe Frage wie Mobil du sein willst\/musst.",
  "id" : 1273780045,
  "in_reply_to_status_id" : 1273768104,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273790466",
  "geo" : { },
  "id_str" : "1273807618",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron normal im Sinne von Web,Mail,Office etc. sicher nicht.Aber f\u00FCr ab&zu w\u00FCrde ich trotzdem kein Netbook nehmen. Lieber was gr\u00F6\u00DFeres",
  "id" : 1273807618,
  "in_reply_to_status_id" : 1273790466,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273825261",
  "geo" : { },
  "id_str" : "1273884533",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Ich hab das Pro. F\u00FCr mich war das mehr an Grafikleistung entscheidend f\u00FCr Spielen & Video\/Bildbearbeitung.",
  "id" : 1273884533,
  "in_reply_to_status_id" : 1273825261,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crashtron",
      "screen_name" : "crashtron",
      "indices" : [ 0, 10 ],
      "id_str" : "33913",
      "id" : 33913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1273825261",
  "geo" : { },
  "id_str" : "1273887286",
  "in_reply_to_user_id" : 33913,
  "text" : "@crashtron Au\u00DFerdem hatte ich nun 2 Jahre lang Bildbearbeitung auf 12\". Ist auf Dauer anstregend, da machen die 15\" schon einen Unterschied",
  "id" : 1273887286,
  "in_reply_to_status_id" : 1273825261,
  "created_at" : "2009-03-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "crashtron",
  "in_reply_to_user_id_str" : "33913",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Schildw\u00E4chter",
      "screen_name" : "comashop",
      "indices" : [ 0, 9 ],
      "id_str" : "13285092",
      "id" : 13285092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1268970955",
  "geo" : { },
  "id_str" : "1268987387",
  "in_reply_to_user_id" : 13285092,
  "text" : "@comashop Ah ein Leidensgenosse. Mir gehts seit einiger Zeit genauso.",
  "id" : 1268987387,
  "in_reply_to_status_id" : 1268970955,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "comashop",
  "in_reply_to_user_id_str" : "13285092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1269091532",
  "text" : "Lese weiter das Cryptonomicon.",
  "id" : 1269091532,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Schildw\u00E4chter",
      "screen_name" : "comashop",
      "indices" : [ 0, 9 ],
      "id_str" : "13285092",
      "id" : 13285092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269138887",
  "geo" : { },
  "id_str" : "1269143063",
  "in_reply_to_user_id" : 13285092,
  "text" : "@comashop Mag sein, manche haben aber auch deutsche Tweets dazwischen was ich besonders skurril finde.",
  "id" : 1269143063,
  "in_reply_to_status_id" : 1269138887,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "comashop",
  "in_reply_to_user_id_str" : "13285092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pl0gbar",
      "indices" : [ 123, 131 ]
    }, {
      "text" : "ms",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269157832",
  "geo" : { },
  "id_str" : "1269165808",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Aye, diesmal kann ich leider nicht. Donnerstags ist immer doof f\u00FCr mich weil da auch meine Pfadfindergruppe ist. #pl0gbar #ms",
  "id" : 1269165808,
  "in_reply_to_status_id" : 1269157832,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Schildw\u00E4chter",
      "screen_name" : "comashop",
      "indices" : [ 0, 9 ],
      "id_str" : "13285092",
      "id" : 13285092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269154148",
  "geo" : { },
  "id_str" : "1269171632",
  "in_reply_to_user_id" : 13285092,
  "text" : "@comashop Zu recht ;)",
  "id" : 1269171632,
  "in_reply_to_status_id" : 1269154148,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "comashop",
  "in_reply_to_user_id_str" : "13285092",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269361969",
  "geo" : { },
  "id_str" : "1269545010",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Volksentscheide finde ich Super. Setzt nat\u00FCrlich voraus das die Leute informiert sind.",
  "id" : 1269545010,
  "in_reply_to_status_id" : 1269361969,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269710010",
  "geo" : { },
  "id_str" : "1269766474",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Was soll es denn h\u00FCbsches werden?",
  "id" : 1269766474,
  "in_reply_to_status_id" : 1269710010,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269783805",
  "geo" : { },
  "id_str" : "1269817080",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Da gibts ja auch jede Menge verschiedene Modelle :)",
  "id" : 1269817080,
  "in_reply_to_status_id" : 1269783805,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269841407",
  "geo" : { },
  "id_str" : "1269844245",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Zeitlos w\u00FCrde ich sagen :)",
  "id" : 1269844245,
  "in_reply_to_status_id" : 1269841407,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "muenster",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269911595",
  "geo" : { },
  "id_str" : "1269967162",
  "in_reply_to_user_id" : 8517622,
  "text" : "@LORXSION Ich f\u00E4nds gut wenn wir mal wieder ein tweetup machen w\u00FCrden :) #muenster",
  "id" : 1269967162,
  "in_reply_to_status_id" : 1269911595,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269903630",
  "geo" : { },
  "id_str" : "1269968207",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Und ja, die Uhr ist klasse :)",
  "id" : 1269968207,
  "in_reply_to_status_id" : 1269903630,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269940285",
  "geo" : { },
  "id_str" : "1269971968",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Allerdings glaube ich das Menschen sich automatisch f\u00FCr Dinge die zum Entscheid stehen interessieren w\u00FCrden.",
  "id" : 1269971968,
  "in_reply_to_status_id" : 1269940285,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269940285",
  "geo" : { },
  "id_str" : "1269973099",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Einfach weil sie das Gef\u00FChl haben hier direkt was bewirken zu k\u00F6nnen und das es nicht egal ist.",
  "id" : 1269973099,
  "in_reply_to_status_id" : 1269940285,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270123357",
  "geo" : { },
  "id_str" : "1270182148",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Das ganze ein zweites Mal abstimmen zu lassen fand ich auch schrecklich albern. Aber: Immerhin wurden die Menschen befragt..",
  "id" : 1270182148,
  "in_reply_to_status_id" : 1270123357,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetup",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "muenster",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1269991526",
  "geo" : { },
  "id_str" : "1270184666",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Mach doch mal einen Terminvorschlag :) #tweetup #muenster",
  "id" : 1270184666,
  "in_reply_to_status_id" : 1269991526,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1270216282",
  "text" : "Grandiose Krawattenwahl vom Wettermenschen http:\/\/bit.ly\/9d9mW #fail",
  "id" : 1270216282,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Abel",
      "screen_name" : "frankwettert",
      "indices" : [ 0, 13 ],
      "id_str" : "17215480",
      "id" : 17215480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270262288",
  "geo" : { },
  "id_str" : "1270269041",
  "in_reply_to_user_id" : 17215480,
  "text" : "@frankwettert Kein Problem, freut mich behilflich zu sein :)",
  "id" : 1270269041,
  "in_reply_to_status_id" : 1270262288,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankwettert",
  "in_reply_to_user_id_str" : "17215480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gerrit Eicker",
      "screen_name" : "eicker",
      "indices" : [ 115, 122 ],
      "id_str" : "7950992",
      "id" : 7950992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270305696",
  "geo" : { },
  "id_str" : "1270331063",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Ich denke schon das es da noch ein paar Interessierte gibt die nicht ganz dem Zeitdruck unterliegen. Der @eicker z.B.",
  "id" : 1270331063,
  "in_reply_to_status_id" : 1270305696,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 62, 70 ],
      "id_str" : "14082615",
      "id" : 14082615
    }, {
      "name" : "Houellebeck",
      "screen_name" : "houellebeck",
      "indices" : [ 71, 83 ],
      "id_str" : "107803659",
      "id" : 107803659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270339209",
  "geo" : { },
  "id_str" : "1270408695",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Klingt schlecht, da ist doch auch die re:publica wo @stelten @houellebeck und ich sein werden. :P",
  "id" : 1270408695,
  "in_reply_to_status_id" : 1270339209,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1270425454",
  "text" : "Wenn man von Leuten gefollowt wird die Zahlen in ihrem Namen tragen kann man zu 99% sicher sein das es Spammer sind.",
  "id" : 1270425454,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kruemel",
      "screen_name" : "kruemel26",
      "indices" : [ 0, 10 ],
      "id_str" : "17208137",
      "id" : 17208137
    }, {
      "name" : "Dominik",
      "screen_name" : "p9y",
      "indices" : [ 11, 15 ],
      "id_str" : "18424055",
      "id" : 18424055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoSpam",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1270448822",
  "in_reply_to_user_id" : 17208137,
  "text" : "@kruemel26 @p9y Ja, ihr seid Ausnahmen. Dazu kommt: Je mehr Stellen die Zahl hat desto gr\u00F6\u00DFer die Spamwahrscheinlichkeit #NoSpam",
  "id" : 1270448822,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "kruemel26",
  "in_reply_to_user_id_str" : "17208137",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TWTPoll",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "TWTvite",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270524036",
  "geo" : { },
  "id_str" : "1270573472",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Super Idee, Terminvorschl\u00E4ge? #TWTPoll #TWTvite",
  "id" : 1270573472,
  "in_reply_to_status_id" : 1270524036,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "stelten",
      "indices" : [ 10, 18 ],
      "id_str" : "14082615",
      "id" : 14082615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TWTPoll",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "TWTvite",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270524036",
  "geo" : { },
  "id_str" : "1270579075",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion @stelten konnte glaube ich Montags (oder war es Dienstags?) & Freitags nicht.  #TWTPoll #TWTvite",
  "id" : 1270579075,
  "in_reply_to_status_id" : 1270524036,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1270588616",
  "text" : "F\u00FCr mich alles okay ;) Machst du den Poll?",
  "id" : 1270588616,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TWTPoll",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "TWTvite",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270583625",
  "geo" : { },
  "id_str" : "1270609340",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Oh man sollte auch das @\u00A0nicht vergessen. Also erstellst du den Poll? :) #TWTPoll #TWTvite",
  "id" : 1270609340,
  "in_reply_to_status_id" : 1270583625,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270674273",
  "geo" : { },
  "id_str" : "1270679602",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Oh wie peinlich. Danke f\u00FCr den Hinweis,hab es fix ge\u00E4ndert. Das passiert wenn man mit seinen Gedanken nicht ganz bei der Sache ist",
  "id" : 1270679602,
  "in_reply_to_status_id" : 1270674273,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270674273",
  "geo" : { },
  "id_str" : "1270682509",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Oh wie peinlich. Danke f\u00FCr den Hinweis,hab es fix ge\u00E4ndert. Das passiert wenn man mit seinen Gedanken nicht ganz bei der Sache ist",
  "id" : 1270682509,
  "in_reply_to_status_id" : 1270674273,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270674273",
  "geo" : { },
  "id_str" : "1270683626",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Oh wie peinlich. Danke f\u00FCr den Hinweis,hab es fix ge\u00E4ndert. Das passiert wenn man mit seinen Gedanken nicht ganz bei der Sache ist",
  "id" : 1270683626,
  "in_reply_to_status_id" : 1270674273,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270674273",
  "geo" : { },
  "id_str" : "1270684665",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Oh wie peinlich. Danke f\u00FCr den Hinweis,hab es fix ge\u00E4ndert. Das passiert wenn man mit seinen Gedanken nicht ganz bei der Sache ist",
  "id" : 1270684665,
  "in_reply_to_status_id" : 1270674273,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270674273",
  "geo" : { },
  "id_str" : "1270711921",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion Oh wie peinlich. Danke f\u00FCr den Hinweis,hab es fix ge\u00E4ndert. Das passiert wenn man mit seinen Gedanken nicht ganz bei der Sache ist",
  "id" : 1270711921,
  "in_reply_to_status_id" : 1270674273,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genervt",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1270713097",
  "text" : "Twitter zickt ja heute wieder ganz sch\u00F6n rum. #genervt",
  "id" : 1270713097,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "zicken",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270722833",
  "geo" : { },
  "id_str" : "1270748690",
  "in_reply_to_user_id" : 14165822,
  "text" : "@Chikatze Deshalb mach ich auch Schluss f\u00FCr heute #twitter #zicken",
  "id" : 1270748690,
  "in_reply_to_status_id" : 1270722833,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Freistetter",
      "screen_name" : "astrodicticum",
      "indices" : [ 117, 131 ],
      "id_str" : "15318271",
      "id" : 15318271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1270865628",
  "text" : "Ich h\u00E4tte Twitter doch f\u00FCr heute fernbleiben sollen, dann h\u00E4tte ich diesen Mist nicht gelesen: http:\/\/is.gd\/ltKc via @astrodicticum",
  "id" : 1270865628,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBrother",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1270857704",
  "geo" : { },
  "id_str" : "1270867837",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion W\u00E4re vermutlich auch kein gro\u00DFer Verlust wenn die Leute da f\u00FCr immer drinbleiben w\u00FCrden oder? #BigBrother",
  "id" : 1270867837,
  "in_reply_to_status_id" : 1270857704,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268551570",
  "text" : "Ich mach mich nun auf den Weg in die totale B\u00FCrokratie. Zoll M\u00FCnster ich komme",
  "id" : 1268551570,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268644860",
  "text" : "Das ist also der ber\u00FChmte M\u00FCnsteraner Zoll  http:\/\/twitpic.com\/1smkf",
  "id" : 1268644860,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zoll",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268658927",
  "text" : "Nach den Horrorgeschichten bin ich angenehm \u00FCberrascht. Sehr freundliche Damen hier. #zoll",
  "id" : 1268658927,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zoll",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268705631",
  "text" : "Das ging doch erstaunlich fix. Und 11\u20AC Mwt-Steuer f\u00FCr 3 Shirts sind auch akzeptabel. #zoll",
  "id" : 1268705631,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268761498",
  "text" : "Wieso steigt eigentlich die Anzahl von radikalen Gl\u00E4ubigen unter meinen Followeren in den letzten Tagen? Missioniere ich etwa?",
  "id" : 1268761498,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268773880",
  "text" : "Coole Luft-Bilder \u00FCber Venedig:  http:\/\/bit.ly\/ROskG",
  "id" : 1268773880,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268837786",
  "text" : "Creative Commons, Go!  http:\/\/twitpic.com\/1sngt",
  "id" : 1268837786,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1268884502",
  "geo" : { },
  "id_str" : "1268889578",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Das Parteien-System in der jetzigen Ausf\u00FChrung ist einfach \u00FCberholt und der komplexen Realit\u00E4t einfach nicht gewachsen.",
  "id" : 1268889578,
  "in_reply_to_status_id" : 1268884502,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268889650",
  "text" : "http:\/\/twitpic.com\/1snqg - Wegen sowas kann man die Sueddeutsche online nicht ernst nehmen.",
  "id" : 1268889650,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u304F\u308D\u3068\u3089",
      "screen_name" : "chikatze",
      "indices" : [ 0, 9 ],
      "id_str" : "2911368630",
      "id" : 2911368630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterspam",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1268887808",
  "geo" : { },
  "id_str" : "1268890786",
  "in_reply_to_user_id" : 14165822,
  "text" : "@Chikatze Du schaust nach wer dir da folgt und klickst einfach hoffentlich einen ihrer Werbelinks an  #twitterspam",
  "id" : 1268890786,
  "in_reply_to_status_id" : 1268887808,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "Frau_Chikatze",
  "in_reply_to_user_id_str" : "14165822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1268904965",
  "geo" : { },
  "id_str" : "1268909055",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Parteien geht es doch heute haupts\u00E4chlich um ihren Einfluss und nicht mehr um Politik an sich.",
  "id" : 1268909055,
  "in_reply_to_status_id" : 1268904965,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1268904965",
  "geo" : { },
  "id_str" : "1268910209",
  "in_reply_to_user_id" : 18331770,
  "text" : "@MatthiasPleye Da werden sinnvolle Dinge ausgebremst nur weil eine andere Partei es vorgeschlagen hat. Mehr direkte Demokratie w\u00FCrde helfen.",
  "id" : 1268910209,
  "in_reply_to_status_id" : 1268904965,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "zitatmuseum",
  "in_reply_to_user_id_str" : "18331770",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1268950194",
  "text" : "Ok ich versuch es nochmal: Wie kann ich im MacOS-Terminal wortweise springen? Alt+Pfeiltasten geht nicht.",
  "id" : 1268950194,
  "created_at" : "2009-03-02 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1265036637",
  "text" : "Erschreckend: Parties k\u00F6nnen auch Spa\u00DF machen wenn man als einziger n\u00FCchtern bleibt.",
  "id" : 1265036637,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1265045226",
  "text" : "Ich gestehe: Ich followe keine Menschen mit h\u00E4sslichen Webseiten.",
  "id" : 1265045226,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1265050976",
  "text" : "http:\/\/bit.ly\/2nmyE Und ich dachte unser Hund w\u00FCrde zu sehr bet\u00FCddelt.",
  "id" : 1265050976,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herr Rensch",
      "screen_name" : "arensch",
      "indices" : [ 0, 8 ],
      "id_str" : "14725887",
      "id" : 14725887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1265057295",
  "geo" : { },
  "id_str" : "1265062836",
  "in_reply_to_user_id" : 14725887,
  "text" : "@arensch Na das abschlabbern darf unser Hund bei mir auch. Ist f\u00FCr ihn eine M\u00F6glichkeit seinen Respekt dem Alpha-Tier gegen\u00FCber zu zeigen.",
  "id" : 1265062836,
  "in_reply_to_status_id" : 1265057295,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "arensch",
  "in_reply_to_user_id_str" : "14725887",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 6, 18 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1265075632",
  "text" : "Cool, @herr_schrat hat endlich das Cryptonomicon mitgebracht. Hab ich ja n\u00E4chste Woche wieder was zu lesen.",
  "id" : 1265075632,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1265349726",
  "text" : "Ach Mist, die CC-Shirts sind beim Zoll gelandet und ich muss sie morgen aus deren Klauen befreien.",
  "id" : 1265349726,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unsinn",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1265755160",
  "text" : "Wieso kann man die Kalenderfarben in Google, iCal und iPhone nicht eigentlich auch automatisch synchron halten? #unsinn",
  "id" : 1265755160,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rozana Renger",
      "screen_name" : "Rozana",
      "indices" : [ 0, 7 ],
      "id_str" : "6085542",
      "id" : 6085542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1265785908",
  "geo" : { },
  "id_str" : "1265800610",
  "in_reply_to_user_id" : 6085542,
  "text" : "@Rozana ein Touchscreen-Device mit \u201Ccan't touch this\u201D zu bewerben ist auch nicht ganz so der Hit oder? ;)",
  "id" : 1265800610,
  "in_reply_to_status_id" : 1265785908,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "Rozana",
  "in_reply_to_user_id_str" : "6085542",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feierabendblog",
      "screen_name" : "feierabendblog",
      "indices" : [ 0, 15 ],
      "id_str" : "17773201",
      "id" : 17773201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1265877704",
  "geo" : { },
  "id_str" : "1265904141",
  "in_reply_to_user_id" : 17773201,
  "text" : "@feierabendblog Und aus welchem Grund?",
  "id" : 1265904141,
  "in_reply_to_status_id" : 1265877704,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "feierabendblog",
  "in_reply_to_user_id_str" : "17773201",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1265910755",
  "text" : "Neuer W&W-Post: Google is evil? - Grippedatensammlung durch Suchanfragenauswertung:  http:\/\/bit.ly\/WKWWp",
  "id" : 1265910755,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feierabendblog",
      "screen_name" : "feierabendblog",
      "indices" : [ 0, 15 ],
      "id_str" : "17773201",
      "id" : 17773201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1265915153",
  "geo" : { },
  "id_str" : "1265921830",
  "in_reply_to_user_id" : 17773201,
  "text" : "@feierabendblog Ist es nicht egal woher die ihr Geld kriegen solange sie selbst neutral bleiben und alles hosten?",
  "id" : 1265921830,
  "in_reply_to_status_id" : 1265915153,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "feierabendblog",
  "in_reply_to_user_id_str" : "17773201",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feierabendblog",
      "screen_name" : "feierabendblog",
      "indices" : [ 0, 15 ],
      "id_str" : "17773201",
      "id" : 17773201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1265946033",
  "geo" : { },
  "id_str" : "1265956244",
  "in_reply_to_user_id" : 17773201,
  "text" : "@feierabendblog Ist klar,aber die Piratebay ist selbst v\u00F6llig unpolitisch und zensurfrei.Ist doch nicht das alles Nichtrechte gel\u00F6scht wird.",
  "id" : 1265956244,
  "in_reply_to_status_id" : 1265946033,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "feierabendblog",
  "in_reply_to_user_id_str" : "17773201",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feierabendblog",
      "screen_name" : "feierabendblog",
      "indices" : [ 0, 15 ],
      "id_str" : "17773201",
      "id" : 17773201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1265967032",
  "geo" : { },
  "id_str" : "1265971530",
  "in_reply_to_user_id" : 17773201,
  "text" : "@feierabendblog Soll ich ihm verbieten was zu spenden nur weil seine politische Einstellung mir nicht gef\u00E4llt?",
  "id" : 1265971530,
  "in_reply_to_status_id" : 1265967032,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "feierabendblog",
  "in_reply_to_user_id_str" : "17773201",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feierabendblog",
      "screen_name" : "feierabendblog",
      "indices" : [ 0, 15 ],
      "id_str" : "17773201",
      "id" : 17773201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1265967032",
  "geo" : { },
  "id_str" : "1265984481",
  "in_reply_to_user_id" : 17773201,
  "text" : "@feierabendblog TPB haben eine radikale Position von \u201Calles f\u00FCr jedermann\u201D und solange die bestehen bleibt sind die Geldgeber doch egal.",
  "id" : 1265984481,
  "in_reply_to_status_id" : 1265967032,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "feierabendblog",
  "in_reply_to_user_id_str" : "17773201",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feierabendblog",
      "screen_name" : "feierabendblog",
      "indices" : [ 0, 15 ],
      "id_str" : "17773201",
      "id" : 17773201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1265977512",
  "geo" : { },
  "id_str" : "1265990304",
  "in_reply_to_user_id" : 17773201,
  "text" : "@feierabendblog Und die gro\u00DFe Frage: Was w\u00E4re wenn linksradikale Autonome TPB finanzieren w\u00FCrde? W\u00E4re das ok?",
  "id" : 1265990304,
  "in_reply_to_status_id" : 1265977512,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "feierabendblog",
  "in_reply_to_user_id_str" : "17773201",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "feierabendblog",
      "screen_name" : "feierabendblog",
      "indices" : [ 0, 15 ],
      "id_str" : "17773201",
      "id" : 17773201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1266007028",
  "geo" : { },
  "id_str" : "1266012336",
  "in_reply_to_user_id" : 17773201,
  "text" : "@feierabendblog Okay, das finde ich vern\u00FCnftig. Diese k\u00FCnstliche Unterscheidung welcher Extremismus nun ok ist und welcher nicht nervt mich.",
  "id" : 1266012336,
  "in_reply_to_status_id" : 1266007028,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "feierabendblog",
  "in_reply_to_user_id_str" : "17773201",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1266028853",
  "text" : "Geilstes Wallpaper ever:  http:\/\/bit.ly\/Dx0HQ",
  "id" : 1266028853,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Weschta",
      "screen_name" : "ThomasWe",
      "indices" : [ 0, 9 ],
      "id_str" : "18760008",
      "id" : 18760008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1266075892",
  "geo" : { },
  "id_str" : "1266277902",
  "in_reply_to_user_id" : 18760008,
  "text" : "@ThomasWe Ich hab keine Ahnung, aber macht sich in klein auch als iPhone-Wallpaper sehr gut :)",
  "id" : 1266277902,
  "in_reply_to_status_id" : 1266075892,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ThomasWe",
  "in_reply_to_user_id_str" : "18760008",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1266412484",
  "text" : "Google-Killer-Feature: Der W\u00E4hrungsrechner \u00FCber das Suchfeld.",
  "id" : 1266412484,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1266508908",
  "geo" : { },
  "id_str" : "1266526587",
  "in_reply_to_user_id" : 8517622,
  "text" : "@lorXsion das mach ich mit Python oder Spotlight :)",
  "id" : 1266526587,
  "in_reply_to_status_id" : 1266508908,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1266650842",
  "text" : "The Mentalist ist ja ganz cool",
  "id" : 1266650842,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1267124655",
  "text" : "Oha, schon sp\u00E4t. Langsam geh ich dann doch mal ins Bett w\u00FCrd ich sagen. Twittert noch sch\u00F6n.",
  "id" : 1267124655,
  "created_at" : "2009-03-01 00:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]