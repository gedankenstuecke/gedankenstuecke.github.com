Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/goKS3BJp5K",
      "expanded_url" : "http:\/\/tmagazine.blogs.nytimes.com\/2014\/11\/05\/andrew-ohagan-technology\/",
      "display_url" : "tmagazine.blogs.nytimes.com\/2014\/11\/05\/and\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539158639429185536",
  "text" : "In Defense of Technology http:\/\/t.co\/goKS3BJp5K",
  "id" : 539158639429185536,
  "created_at" : "2014-11-30 20:46:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/d8tc8JAsCy",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/owj9CYlCaUo\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539136597124722688",
  "text" : "Linguistic Fun Fact http:\/\/t.co\/d8tc8JAsCy",
  "id" : 539136597124722688,
  "created_at" : "2014-11-30 19:19:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/klkvFw7uIr",
      "expanded_url" : "http:\/\/fraunessy.vanessagiese.de\/2014\/11\/26\/max-mustermann-wundert-sich\/",
      "display_url" : "fraunessy.vanessagiese.de\/2014\/11\/26\/max\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539136340508827648",
  "text" : "\u00ABMax kommt es komisch vor, dass das alles Frauen sind; die Abteilungsleiterinnen, die Leiterinnen der Dependancen\u00BB http:\/\/t.co\/klkvFw7uIr",
  "id" : 539136340508827648,
  "created_at" : "2014-11-30 19:18:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/I7FcNiJwGS",
      "expanded_url" : "http:\/\/conservationbytes.com\/2014\/11\/25\/why-engaging-in-civil-disobedience-was-my-obligation-as-a-scientist-parent-and-citizen\/",
      "display_url" : "conservationbytes.com\/2014\/11\/25\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539119625750192129",
  "text" : "\u00ABWhy engaging in civil disobedience was my obligation as a scientist, parent and\u00A0citizen\u00BB http:\/\/t.co\/I7FcNiJwGS",
  "id" : 539119625750192129,
  "created_at" : "2014-11-30 18:11:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Q1t43DMyYR",
      "expanded_url" : "http:\/\/oglaf.com\/chauncey\/",
      "display_url" : "oglaf.com\/chauncey\/"
    } ]
  },
  "geo" : { },
  "id_str" : "539038040627613696",
  "text" : "\u00ABIch habe auch Eulen, ich glaube das ist ansteckend. Tut aber nicht weh.\u00BB http:\/\/t.co\/Q1t43DMyYR",
  "id" : 539038040627613696,
  "created_at" : "2014-11-30 12:47:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 41, 49 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/j7K94qRbm6",
      "expanded_url" : "http:\/\/instagram.com\/p\/wBfyTbhwrD\/",
      "display_url" : "instagram.com\/p\/wBfyTbhwrD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "539028805948809216",
  "text" : "Da geht man nur kurz zum Burger essen zu @euleule und schon hat man Eulen! http:\/\/t.co\/j7K94qRbm6",
  "id" : 539028805948809216,
  "created_at" : "2014-11-30 12:10:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/gyxUi77kL8",
      "expanded_url" : "http:\/\/instagram.com\/p\/wBT1kBhwq6\/",
      "display_url" : "instagram.com\/p\/wBT1kBhwq6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "539002530852634624",
  "text" : "two more to go http:\/\/t.co\/gyxUi77kL8",
  "id" : 539002530852634624,
  "created_at" : "2014-11-30 10:26:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 67, 83 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/HkJ1woE2MO",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2014\/11\/dna-survives-a-ride-into-spaceon-the-exterior-of-a-rocket\/#p3",
      "display_url" : "arstechnica.com\/science\/2014\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538986669777895424",
  "text" : "I wait for the first extraterrestrial metagenome studies &amp; how @pathogenomenick will point out it's contamination. http:\/\/t.co\/HkJ1woE2MO",
  "id" : 538986669777895424,
  "created_at" : "2014-11-30 09:23:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538935167130546176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1142554358, 8.7534753699 ]
  },
  "id_str" : "538980832040726529",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy \u2018I went to Europe and all I got was this single bottle of Club Mate\u2019",
  "id" : 538980832040726529,
  "in_reply_to_status_id" : 538935167130546176,
  "created_at" : "2014-11-30 09:00:18 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/IHcYjpd49Q",
      "expanded_url" : "http:\/\/thedogsnobs.com\/category\/sex-toy-or-dog-toy\/",
      "display_url" : "thedogsnobs.com\/category\/sex-t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "538868332263636992",
  "geo" : { },
  "id_str" : "538976212337823745",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC W\u00E4re aber insgesamt eine sch\u00F6ne Erg\u00E4nzung zu http:\/\/t.co\/IHcYjpd49Q",
  "id" : 538976212337823745,
  "in_reply_to_status_id" : 538868332263636992,
  "created_at" : "2014-11-30 08:41:57 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538864367933341696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.110666, 8.7599020623 ]
  },
  "id_str" : "538976184290529280",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC bei dem mittleren versagt meine Vorstellungskraft zur Verwendung als Toy.",
  "id" : 538976184290529280,
  "in_reply_to_status_id" : 538864367933341696,
  "created_at" : "2014-11-30 08:41:50 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "538856135789649921",
  "text" : "\u00ABDu siehst aus wie ein Einhorn. Nur ohne Horn.\u00BB \u2014 \u00ABAlso wie ein Pferd\u2026\u00BB",
  "id" : 538856135789649921,
  "created_at" : "2014-11-30 00:44:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538762477698572288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106659888, 8.7599021045 ]
  },
  "id_str" : "538832998037475328",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC Kommentar hier: \u201Cist das auf dem Foto links ein kleiner Teigschaber oder ein Sextoy?\u201D",
  "id" : 538832998037475328,
  "in_reply_to_status_id" : 538762477698572288,
  "created_at" : "2014-11-29 23:12:52 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 7, 15 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538713828176187392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1090388688, 8.7571776358 ]
  },
  "id_str" : "538726552658526209",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @euleule auch von mir vielen Dank. :)",
  "id" : 538726552658526209,
  "in_reply_to_status_id" : 538713828176187392,
  "created_at" : "2014-11-29 16:09:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/FwcsYhJZzP",
      "expanded_url" : "http:\/\/ecoevoevoeco.blogspot.com\/2014\/11\/how-to-be-reviewereditor.html",
      "display_url" : "ecoevoevoeco.blogspot.com\/2014\/11\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538716571670413312",
  "text" : "RT @ctitusbrown: \"Thus, rejecting a paper actually makes the scientific literature WORSE.\" http:\/\/t.co\/FwcsYhJZzP - huh, really good point!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/FwcsYhJZzP",
        "expanded_url" : "http:\/\/ecoevoevoeco.blogspot.com\/2014\/11\/how-to-be-reviewereditor.html",
        "display_url" : "ecoevoevoeco.blogspot.com\/2014\/11\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "538658377463656448",
    "text" : "\"Thus, rejecting a paper actually makes the scientific literature WORSE.\" http:\/\/t.co\/FwcsYhJZzP - huh, really good point!",
    "id" : 538658377463656448,
    "created_at" : "2014-11-29 11:38:59 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 538716571670413312,
  "created_at" : "2014-11-29 15:30:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/538678326806978560\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Lh6bx8k0oD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3nFFPBCcAA9_u2.jpg",
      "id_str" : "538678324168388608",
      "id" : 538678324168388608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3nFFPBCcAA9_u2.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Lh6bx8k0oD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1037889952, 8.7539849058 ]
  },
  "id_str" : "538678326806978560",
  "text" : "Da hat also jemand einen Diplom-Biostudiengang geschafft ohne jemals erfolgreich Chemie zu h\u00F6ren\u2026 http:\/\/t.co\/Lh6bx8k0oD",
  "id" : 538678326806978560,
  "created_at" : "2014-11-29 12:58:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/gSVrk0s7aD",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1765",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538651747468967936",
  "text" : "how to read a professor\u2019s door http:\/\/t.co\/gSVrk0s7aD",
  "id" : 538651747468967936,
  "created_at" : "2014-11-29 11:12:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/dSEy2Xo3gX",
      "expanded_url" : "http:\/\/www.newyorkshitty.com\/new-york-city\/28942",
      "display_url" : "newyorkshitty.com\/new-york-city\/\u2026"
    }, {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/dSEy2Xo3gX",
      "expanded_url" : "http:\/\/www.newyorkshitty.com\/new-york-city\/28942",
      "display_url" : "newyorkshitty.com\/new-york-city\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538372456084692992",
  "text" : "What's that? A subway for hamsters?! http:\/\/t.co\/dSEy2Xo3gX http:\/\/t.co\/dSEy2Xo3gX",
  "id" : 538372456084692992,
  "created_at" : "2014-11-28 16:42:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538320362258575360",
  "text" : "\u00ABI recommend you ask clever questions after seminar talks. Or maybe stupid ones, just like I will do now.\u00BB",
  "id" : 538320362258575360,
  "created_at" : "2014-11-28 13:15:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/ZdiwkRd8eK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=G8J7uMwlDjg",
      "display_url" : "youtube.com\/watch?v=G8J7uM\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538311697833152512",
  "text" : "\u00ABBesser Master Yoda als Master Elisabeth!\u00BB https:\/\/t.co\/ZdiwkRd8eK",
  "id" : 538311697833152512,
  "created_at" : "2014-11-28 12:41:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114364624, 8.7501983643 ]
  },
  "id_str" : "538237864757448704",
  "text" : "\u00ABIch steh dann einfach mal auf.\u00BB \u2013 \u00ABKrass, das ist immer so als ob Cthulhu erwacht!\u00BB",
  "id" : 538237864757448704,
  "created_at" : "2014-11-28 07:48:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "538113912584286208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "538135047921205248",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks any chance you will offer this as a service? I\u2019m in special need for the first two items of that list.",
  "id" : 538135047921205248,
  "in_reply_to_status_id" : 538113912584286208,
  "created_at" : "2014-11-28 00:59:28 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/DHcJV7BVwp",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3556",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538099112349270016",
  "text" : "on virtue ethics and consequentialist ethics http:\/\/t.co\/DHcJV7BVwp",
  "id" : 538099112349270016,
  "created_at" : "2014-11-27 22:36:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/Cut0Ttaxol",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/537325662563205120",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "538012325304082432",
  "geo" : { },
  "id_str" : "538012706302083072",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock haha, that\u2019s a nice. thanks for sending the image. :-) My tweet was an addendum to this one: https:\/\/t.co\/Cut0Ttaxol",
  "id" : 538012706302083072,
  "in_reply_to_status_id" : 538012325304082432,
  "created_at" : "2014-11-27 16:53:19 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538011115373207552",
  "text" : "Achievement unlocked: Cluster-wide root access.",
  "id" : 538011115373207552,
  "created_at" : "2014-11-27 16:47:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723873595, 8.6275800477 ]
  },
  "id_str" : "537939028046540800",
  "text" : "\u00ABOh, Schatz, bist du heute wieder griffig, da bekomme ich glatt Stangenfieber!\u00BB \u2014 \u00ABBei so einer Begr\u00FC\u00DFung kommt man doch gern ins B\u00FCro!\u00BB",
  "id" : 537939028046540800,
  "created_at" : "2014-11-27 12:00:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537918648347017216",
  "text" : "Hierarchical Relationship Modelling: \u00ABeach girlfriend (j) would get a priority score (p_j) adjusting their neediness (b_i) for an event (i)\u00BB",
  "id" : 537918648347017216,
  "created_at" : "2014-11-27 10:39:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/5Dw4uXuRaT",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/12JERbFTQHamDm\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/12JERbFT\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "537913925392928768",
  "geo" : { },
  "id_str" : "537916927491211264",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/5Dw4uXuRaT",
  "id" : 537916927491211264,
  "in_reply_to_status_id" : 537913925392928768,
  "created_at" : "2014-11-27 10:32:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/go2948QjN9",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/doing-good-science\/2014\/11\/26\/kitchen-science-evaluating-methods-of-self-defense-against-onions\/",
      "display_url" : "blogs.scientificamerican.com\/doing-good-sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537907637787312128",
  "text" : "Kitchen science: evaluating methods of self-defense against onions. http:\/\/t.co\/go2948QjN9",
  "id" : 537907637787312128,
  "created_at" : "2014-11-27 09:55:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Jkxw1wf98i",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/11\/26\/jurassic-park-with-cats-instea.html",
      "display_url" : "boingboing.net\/2014\/11\/26\/jur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537899842312605696",
  "text" : "Purrassic Park: They figured out how to open doors! http:\/\/t.co\/Jkxw1wf98i",
  "id" : 537899842312605696,
  "created_at" : "2014-11-27 09:24:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/hWbXq5YrwB",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2014\/11\/26\/peek-inside-furry-convention\/#.VHbrclXF-SM",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537898105401016320",
  "text" : "A Sex Researcher At A Furry Convention http:\/\/t.co\/hWbXq5YrwB",
  "id" : 537898105401016320,
  "created_at" : "2014-11-27 09:17:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/uGk6gvLXY7",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/thetwo-way\/2014\/11\/25\/366660090\/dog-follows-athletes-through-mud-and-water-and-melts-hearts",
      "display_url" : "npr.org\/blogs\/thetwo-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537896402312261632",
  "text" : "Dog Follows Athletes Through Mud And Water, And Melts Hearts http:\/\/t.co\/uGk6gvLXY7",
  "id" : 537896402312261632,
  "created_at" : "2014-11-27 09:11:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Waite",
      "screen_name" : "mattwaite",
      "indices" : [ 3, 13 ],
      "id_str" : "8839152",
      "id" : 8839152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537877918945656832",
  "text" : "RT @mattwaite: I taught my students enough Python to be dangerous and told them to make a Twitter bot. The results were awesome. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Sg2a0Xz613",
        "expanded_url" : "http:\/\/blog.mattwaite.com\/post\/103144761014\/a-classroom-experiment-in-twitter-bots-and-creativity",
        "display_url" : "blog.mattwaite.com\/post\/103144761\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535537892769021952",
    "text" : "I taught my students enough Python to be dangerous and told them to make a Twitter bot. The results were awesome. http:\/\/t.co\/Sg2a0Xz613",
    "id" : 535537892769021952,
    "created_at" : "2014-11-20 20:59:18 +0000",
    "user" : {
      "name" : "Matt Waite",
      "screen_name" : "mattwaite",
      "protected" : false,
      "id_str" : "8839152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812696528800411649\/lGzwQc-y_normal.jpg",
      "id" : 8839152,
      "verified" : true
    }
  },
  "id" : 537877918945656832,
  "created_at" : "2014-11-27 07:57:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999984 ]
  },
  "id_str" : "537764923200512000",
  "text" : "\u00ABHast du mich gerade \u2018W\u00FCrstchen der Finsternis\u2019 genannt?!\u00BB",
  "id" : 537764923200512000,
  "created_at" : "2014-11-27 00:28:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537733267068182528",
  "text" : "\u00ABYou have to get me another book to learn German. If I continue with this one I will vote for Angela Merkel!\u00BB",
  "id" : 537733267068182528,
  "created_at" : "2014-11-26 22:22:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233485638136, 8.627586399597421 ]
  },
  "id_str" : "537590396030033920",
  "text" : "\u00ABUnd das war die letzte Workstation in diesem Raum die noch funktionierte. Mit Betonung auf \u2018war\u2019\u2026\u00BB",
  "id" : 537590396030033920,
  "created_at" : "2014-11-26 12:55:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/W66s94NQpc",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/evo.12565\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537585493396172800",
  "text" : "A phylogenetic test of the Red Queen Hypothesis: outcrossing and parasitism in the Nematode phylum http:\/\/t.co\/W66s94NQpc",
  "id" : 537585493396172800,
  "created_at" : "2014-11-26 12:35:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/rr5sepesqc",
      "expanded_url" : "http:\/\/nbviewer.ipython.org\/github\/mwaskom\/seaborn\/blob\/master\/examples\/plotting_distributions.ipynb",
      "display_url" : "nbviewer.ipython.org\/github\/mwaskom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537583466666541056",
  "text" : "If you are tired by R &amp; ggplot2: Visualizing distributions of data w\/ Python &amp; seaborn http:\/\/t.co\/rr5sepesqc",
  "id" : 537583466666541056,
  "created_at" : "2014-11-26 12:27:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537575083251105792",
  "geo" : { },
  "id_str" : "537582489012015104",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule @Lobot cool, wann sollen wir eigentlich wo sein? :)",
  "id" : 537582489012015104,
  "in_reply_to_status_id" : 537575083251105792,
  "created_at" : "2014-11-26 12:23:47 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 3, 18 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 36, 44 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "NCBI Staff",
      "screen_name" : "NCBI",
      "indices" : [ 55, 60 ],
      "id_str" : "20746400",
      "id" : 20746400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537580306703085568",
  "text" : "RT @torstenseemann: I fully support @pjacock appeal to @NCBI to improve the custom CSV output mode of BLAST+ #bioinformatics http:\/\/t.co\/by\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Cock",
        "screen_name" : "pjacock",
        "indices" : [ 16, 24 ],
        "id_str" : "58756672",
        "id" : 58756672
      }, {
        "name" : "NCBI Staff",
        "screen_name" : "NCBI",
        "indices" : [ 35, 40 ],
        "id_str" : "20746400",
        "id" : 20746400
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 89, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/byYXH4LeEi",
        "expanded_url" : "http:\/\/blastedbio.blogspot.com.au\/2014\/11\/column-headers-in-blast-tabular-and-csv.html?m=1",
        "display_url" : "blastedbio.blogspot.com.au\/2014\/11\/column\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "537576961451622400",
    "text" : "I fully support @pjacock appeal to @NCBI to improve the custom CSV output mode of BLAST+ #bioinformatics http:\/\/t.co\/byYXH4LeEi",
    "id" : 537576961451622400,
    "created_at" : "2014-11-26 12:01:49 +0000",
    "user" : {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "protected" : false,
      "id_str" : "42558652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720526185361510400\/dA-svJxC_normal.jpg",
      "id" : 42558652,
      "verified" : false
    }
  },
  "id" : 537580306703085568,
  "created_at" : "2014-11-26 12:15:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/91iKocbczn",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2014\/11\/25\/raiding-the-oldest-arsenal\/",
      "display_url" : "phenomena.nationalgeographic.com\/2014\/11\/25\/rai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537577709791379456",
  "text" : "raiding the oldest arsenal: on antibiotic genes that repeatedly jumped from bacteria into eukaryotes http:\/\/t.co\/91iKocbczn",
  "id" : 537577709791379456,
  "created_at" : "2014-11-26 12:04:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537387312997728257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964688999998, 8.282987159999996 ]
  },
  "id_str" : "537387528782094337",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule @Lobot um so besser, was sollen wir dann mitbringen? ;)",
  "id" : 537387528782094337,
  "in_reply_to_status_id" : 537387312997728257,
  "created_at" : "2014-11-25 23:29:05 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Veix",
      "screen_name" : "joeveix",
      "indices" : [ 3, 11 ],
      "id_str" : "18205994",
      "id" : 18205994
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/joeveix\/status\/537138111168278529\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/biq1E06Oy4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3RMRAMCIAAIAxV.png",
      "id_str" : "537138110555889664",
      "id" : 537138110555889664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3RMRAMCIAAIAxV.png",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 1016
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 1016
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 1016
      } ],
      "display_url" : "pic.twitter.com\/biq1E06Oy4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537387016313655296",
  "text" : "RT @joeveix: Sneak peek of tomorrow's New York Times. http:\/\/t.co\/biq1E06Oy4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/joeveix\/status\/537138111168278529\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/biq1E06Oy4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3RMRAMCIAAIAxV.png",
        "id_str" : "537138110555889664",
        "id" : 537138110555889664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3RMRAMCIAAIAxV.png",
        "sizes" : [ {
          "h" : 484,
          "resize" : "fit",
          "w" : 1016
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 1016
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 1016
        } ],
        "display_url" : "pic.twitter.com\/biq1E06Oy4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537138111168278529",
    "text" : "Sneak peek of tomorrow's New York Times. http:\/\/t.co\/biq1E06Oy4",
    "id" : 537138111168278529,
    "created_at" : "2014-11-25 06:57:59 +0000",
    "user" : {
      "name" : "Joe Veix",
      "screen_name" : "joeveix",
      "protected" : false,
      "id_str" : "18205994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533732321589874688\/1pQ_CSeO_normal.jpeg",
      "id" : 18205994,
      "verified" : true
    }
  },
  "id" : 537387016313655296,
  "created_at" : "2014-11-25 23:27:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 57, 63 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537377914682368000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11537170410156, 8.750381469726562 ]
  },
  "id_str" : "537385855196102656",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule meinetwegen gerne. Hast du was dagegen wenn ich @Lobot mitbringe? :-)",
  "id" : 537385855196102656,
  "in_reply_to_status_id" : 537377914682368000,
  "created_at" : "2014-11-25 23:22:26 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0430\u0441\u0442\u0430\u0441\u0438\u044F \u041F\u0440\u0438\u0432\u043E\u043B\u0436\u043D\u0430\u044F",
      "screen_name" : "Wutbuergerin",
      "indices" : [ 3, 16 ],
      "id_str" : "224452301",
      "id" : 224452301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/9zwLgzXyJf",
      "expanded_url" : "http:\/\/buff.ly\/15qrkP8",
      "display_url" : "buff.ly\/15qrkP8"
    } ]
  },
  "geo" : { },
  "id_str" : "537363992633954304",
  "text" : "RT @Wutbuergerin: Austria launched its Personal Genome Project today http:\/\/t.co\/9zwLgzXyJf -thrilled to be on the advisory board  #GenomAu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GenomAustria",
        "indices" : [ 113, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/9zwLgzXyJf",
        "expanded_url" : "http:\/\/buff.ly\/15qrkP8",
        "display_url" : "buff.ly\/15qrkP8"
      } ]
    },
    "geo" : { },
    "id_str" : "537359005942022144",
    "text" : "Austria launched its Personal Genome Project today http:\/\/t.co\/9zwLgzXyJf -thrilled to be on the advisory board  #GenomAustria",
    "id" : 537359005942022144,
    "created_at" : "2014-11-25 21:35:45 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 537363992633954304,
  "created_at" : "2014-11-25 21:55:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 3, 13 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/gnhFVXtQ4X",
      "expanded_url" : "http:\/\/youtu.be\/VW8q_rnjQL4?t=47s",
      "display_url" : "youtu.be\/VW8q_rnjQL4?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537362570903318528",
  "text" : "RT @fragmente: \"Things Only a Black Mother Can Prepare You For\" http:\/\/t.co\/gnhFVXtQ4X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/gnhFVXtQ4X",
        "expanded_url" : "http:\/\/youtu.be\/VW8q_rnjQL4?t=47s",
        "display_url" : "youtu.be\/VW8q_rnjQL4?t=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "537342622030123008",
    "text" : "\"Things Only a Black Mother Can Prepare You For\" http:\/\/t.co\/gnhFVXtQ4X",
    "id" : 537342622030123008,
    "created_at" : "2014-11-25 20:30:39 +0000",
    "user" : {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "protected" : false,
      "id_str" : "7207642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457425277317120\/emEVfsV-_normal.jpg",
      "id" : 7207642,
      "verified" : false
    }
  },
  "id" : 537362570903318528,
  "created_at" : "2014-11-25 21:49:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/5k1ZHGSakd",
      "expanded_url" : "http:\/\/jalopnik.com\/here-s-why-the-check-engine-light-is-a-horrible-terrib-1662743563",
      "display_url" : "jalopnik.com\/here-s-why-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537337383776428032",
  "text" : "Here\u2019s Why The Check Engine Light Is A Horrible, Terrible Thing http:\/\/t.co\/5k1ZHGSakd",
  "id" : 537337383776428032,
  "created_at" : "2014-11-25 20:09:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537325895896555522",
  "text" : "Also: how is it that doing transcriptome sequencing + Blast2GO is still considered useful?",
  "id" : 537325895896555522,
  "created_at" : "2014-11-25 19:24:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 5, 18 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/svWgN1ZaRu",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0112245",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537325662563205120",
  "text" : "Hey, @PhilippBayer, recognize this study setup from somewhere? Remarkable similarity, isn\u2019t it? http:\/\/t.co\/svWgN1ZaRu",
  "id" : 537325662563205120,
  "created_at" : "2014-11-25 19:23:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Winters",
      "screen_name" : "replicatedtypo",
      "indices" : [ 3, 18 ],
      "id_str" : "15677536",
      "id" : 15677536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/ST7VvFmh8d",
      "expanded_url" : "http:\/\/ecodevoevo.blogspot.com\/2014\/11\/lets-abandon-significance-tests.html",
      "display_url" : "ecodevoevo.blogspot.com\/2014\/11\/lets-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537317771181572097",
  "text" : "RT @replicatedtypo: Let's Abandon Significance Tests http:\/\/t.co\/ST7VvFmh8d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/ST7VvFmh8d",
        "expanded_url" : "http:\/\/ecodevoevo.blogspot.com\/2014\/11\/lets-abandon-significance-tests.html",
        "display_url" : "ecodevoevo.blogspot.com\/2014\/11\/lets-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "537195560776650752",
    "text" : "Let's Abandon Significance Tests http:\/\/t.co\/ST7VvFmh8d",
    "id" : 537195560776650752,
    "created_at" : "2014-11-25 10:46:16 +0000",
    "user" : {
      "name" : "James Winters",
      "screen_name" : "replicatedtypo",
      "protected" : false,
      "id_str" : "15677536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781432695838609409\/W-qS38wx_normal.jpg",
      "id" : 15677536,
      "verified" : false
    }
  },
  "id" : 537317771181572097,
  "created_at" : "2014-11-25 18:51:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537316857498587136",
  "text" : "\u00ABWhere did you work from January to March 2013?\u00BB \u2013 \u00ABWhat\u2019s this? The \u2018doing my taxes\u2019-version of Serial?\u00BB",
  "id" : 537316857498587136,
  "created_at" : "2014-11-25 18:48:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Y55qjpxI8A",
      "expanded_url" : "http:\/\/creativetimereports.org\/2014\/11\/20\/angela-washko-feminism-world-of-warcraft-gamergate\/",
      "display_url" : "creativetimereports.org\/2014\/11\/20\/ang\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537292390630195201",
  "text" : "\u00ABWhy Talk Feminism in World of Warcraft?\u00BB http:\/\/t.co\/Y55qjpxI8A",
  "id" : 537292390630195201,
  "created_at" : "2014-11-25 17:11:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/faMEW3GWcz",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3554",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537291685517357056",
  "text" : "the most fundamental particle in the universe http:\/\/t.co\/faMEW3GWcz",
  "id" : 537291685517357056,
  "created_at" : "2014-11-25 17:08:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 87, 93 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/raqEdIrQ4m",
      "expanded_url" : "http:\/\/rsos.royalsocietypublishing.org\/content\/1\/3\/140216",
      "display_url" : "rsos.royalsocietypublishing.org\/content\/1\/3\/14\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537177426481405952",
  "text" : "An investigation of the false discovery rate and the misinterpretation of p-values \/cc @Lobot http:\/\/t.co\/raqEdIrQ4m",
  "id" : 537177426481405952,
  "created_at" : "2014-11-25 09:34:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Je8PkVqGdF",
      "expanded_url" : "http:\/\/scientiasalon.wordpress.com\/2014\/11\/10\/the-ongoing-evolution-of-evolutionary-theory\/",
      "display_url" : "scientiasalon.wordpress.com\/2014\/11\/10\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537175443632570368",
  "text" : "The (ongoing) evolution of evolutionary\u00A0theory http:\/\/t.co\/Je8PkVqGdF",
  "id" : 537175443632570368,
  "created_at" : "2014-11-25 09:26:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/0Mn0DFEANV",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/11\/19\/magazine\/the-secret-life-of-passwords.html?nytmobile=0&_r=0",
      "display_url" : "nytimes.com\/2014\/11\/19\/mag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537168833229111296",
  "text" : "\u00ABMany of our passwords are suffused with pathos, mischief, sometimes even poetry.\u00BB http:\/\/t.co\/0Mn0DFEANV",
  "id" : 537168833229111296,
  "created_at" : "2014-11-25 09:00:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537162686061379584",
  "geo" : { },
  "id_str" : "537164780046680064",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch I wish\u2026",
  "id" : 537164780046680064,
  "in_reply_to_status_id" : 537162686061379584,
  "created_at" : "2014-11-25 08:43:58 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236434164734, 8.627526579659158 ]
  },
  "id_str" : "537161806931050496",
  "text" : "Our workstations are now named after characters of Big Bang Theory. m(",
  "id" : 537161806931050496,
  "created_at" : "2014-11-25 08:32:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zak McClendon",
      "screen_name" : "ZakMcc",
      "indices" : [ 3, 10 ],
      "id_str" : "17930943",
      "id" : 17930943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537028199298105345",
  "text" : "RT @ZakMcc: Parenting Tip: Make sure to limit your infant's System Shock 1 time to 30 mins a day (45 if using mouselook patch). http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZakMcc\/status\/536962388759543809\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ca01btgxmq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3OsbxiCEAAX9Zo.jpg",
        "id_str" : "536962373739745280",
        "id" : 536962373739745280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3OsbxiCEAAX9Zo.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ca01btgxmq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "536962388759543809",
    "text" : "Parenting Tip: Make sure to limit your infant's System Shock 1 time to 30 mins a day (45 if using mouselook patch). http:\/\/t.co\/ca01btgxmq",
    "id" : 536962388759543809,
    "created_at" : "2014-11-24 19:19:44 +0000",
    "user" : {
      "name" : "Zak McClendon",
      "screen_name" : "ZakMcc",
      "protected" : false,
      "id_str" : "17930943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921114520688324608\/yfPG1xde_normal.jpg",
      "id" : 17930943,
      "verified" : false
    }
  },
  "id" : 537028199298105345,
  "created_at" : "2014-11-24 23:41:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cathy Barry",
      "screen_name" : "cathyby",
      "indices" : [ 3, 11 ],
      "id_str" : "106382065",
      "id" : 106382065
    }, {
      "name" : "Nigel Warburton",
      "screen_name" : "philosophybites",
      "indices" : [ 17, 33 ],
      "id_str" : "37238862",
      "id" : 37238862
    }, {
      "name" : "Lucy Kafanov",
      "screen_name" : "LucyKafanov",
      "indices" : [ 47, 59 ],
      "id_str" : "98738595",
      "id" : 98738595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537027056350269440",
  "text" : "RT @cathyby: The @philosophybites civil war\nMT @LucyKafanov There can be no peace until they renounce their Rabbit God... http:\/\/t.co\/AVtY6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nigel Warburton",
        "screen_name" : "philosophybites",
        "indices" : [ 4, 20 ],
        "id_str" : "37238862",
        "id" : 37238862
      }, {
        "name" : "Lucy Kafanov",
        "screen_name" : "LucyKafanov",
        "indices" : [ 34, 46 ],
        "id_str" : "98738595",
        "id" : 98738595
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LucyKafanov\/status\/536827421102968832\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/AVtY6jCe2z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3MxsfaIEAAo3UO.jpg",
        "id_str" : "536827421002305536",
        "id" : 536827421002305536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3MxsfaIEAAo3UO.jpg",
        "sizes" : [ {
          "h" : 836,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 521
        }, {
          "h" : 836,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 836,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/AVtY6jCe2z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "536827421102968832",
    "geo" : { },
    "id_str" : "536955250826289152",
    "in_reply_to_user_id" : 98738595,
    "text" : "The @philosophybites civil war\nMT @LucyKafanov There can be no peace until they renounce their Rabbit God... http:\/\/t.co\/AVtY6jCe2z",
    "id" : 536955250826289152,
    "in_reply_to_status_id" : 536827421102968832,
    "created_at" : "2014-11-24 18:51:22 +0000",
    "in_reply_to_screen_name" : "LucyKafanov",
    "in_reply_to_user_id_str" : "98738595",
    "user" : {
      "name" : "Cathy Barry",
      "screen_name" : "cathyby",
      "protected" : false,
      "id_str" : "106382065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496719844520112128\/pMSkhh_6_normal.jpeg",
      "id" : 106382065,
      "verified" : false
    }
  },
  "id" : 537027056350269440,
  "created_at" : "2014-11-24 23:36:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/OOMfsperUo",
      "expanded_url" : "https:\/\/vine.co\/v\/O16nUVBPFrx",
      "display_url" : "vine.co\/v\/O16nUVBPFrx"
    } ]
  },
  "geo" : { },
  "id_str" : "537025680534667264",
  "text" : "Zandvoort https:\/\/t.co\/OOMfsperUo",
  "id" : 537025680534667264,
  "created_at" : "2014-11-24 23:31:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/9pLeo99Xan",
      "expanded_url" : "http:\/\/instagram.com\/p\/vyE7Z9BwiL\/",
      "display_url" : "instagram.com\/p\/vyE7Z9BwiL\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.371976962, 4.529216484 ]
  },
  "id_str" : "536858684005945345",
  "text" : "Castles Made of Sand @ Zandvoort Strand http:\/\/t.co\/9pLeo99Xan",
  "id" : 536858684005945345,
  "created_at" : "2014-11-24 12:27:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536808787194437632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36526962709944, 4.959621261009234 ]
  },
  "id_str" : "536809015008038912",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy hope so! Let me know if you ever plan on going to Amsterdam, because that\u2019s much closer than Berlin is :3",
  "id" : 536809015008038912,
  "in_reply_to_status_id" : 536808787194437632,
  "created_at" : "2014-11-24 09:10:17 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536802995019988992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3652774743, 4.9596061904 ]
  },
  "id_str" : "536808679287582720",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy I fear we won\u2019t meet then. :(",
  "id" : 536808679287582720,
  "in_reply_to_status_id" : 536802995019988992,
  "created_at" : "2014-11-24 09:08:57 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536785230892658688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36556338151205, 4.959949711342305 ]
  },
  "id_str" : "536798851504820224",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy have fun! Vienna is great. How long will you be in Europe?",
  "id" : 536798851504820224,
  "in_reply_to_status_id" : 536785230892658688,
  "created_at" : "2014-11-24 08:29:54 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/IPJ3d1RdNJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/vwZh-gBwve\/",
      "display_url" : "instagram.com\/p\/vwZh-gBwve\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.362297582, 4.88385855 ]
  },
  "id_str" : "536622513313558528",
  "text" : "Fink @ Paradiso Amsterdam http:\/\/t.co\/IPJ3d1RdNJ",
  "id" : 536622513313558528,
  "created_at" : "2014-11-23 20:49:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536541728233508864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.33095486831044, 4.852398533554143 ]
  },
  "id_str" : "536556478459826176",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy unfortunately not. Will you come to Frankfurt by any chance? And what\u2019s up in Vienna?",
  "id" : 536556478459826176,
  "in_reply_to_status_id" : 536541728233508864,
  "created_at" : "2014-11-23 16:26:47 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mama hat keine Zeit",
      "screen_name" : "mamakeinezeit",
      "indices" : [ 3, 17 ],
      "id_str" : "593539906",
      "id" : 593539906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536466369370669056",
  "text" : "RT @mamakeinezeit: Oh ja, DIESEN Rant kann ich gut nachvollziehen! Und nein, es geht nicht gegen V\u00E4ter. \"Lorbeeren f\u00FCr Papi.\"  http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/mOINjWFQQQ",
        "expanded_url" : "http:\/\/buff.ly\/1FdjaWR",
        "display_url" : "buff.ly\/1FdjaWR"
      } ]
    },
    "geo" : { },
    "id_str" : "536443079272980480",
    "text" : "Oh ja, DIESEN Rant kann ich gut nachvollziehen! Und nein, es geht nicht gegen V\u00E4ter. \"Lorbeeren f\u00FCr Papi.\"  http:\/\/t.co\/mOINjWFQQQ",
    "id" : 536443079272980480,
    "created_at" : "2014-11-23 08:56:11 +0000",
    "user" : {
      "name" : "Mama hat keine Zeit",
      "screen_name" : "mamakeinezeit",
      "protected" : false,
      "id_str" : "593539906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3288658285\/a637df7e5b8e57d1ee0d2203a2d39e42_normal.jpeg",
      "id" : 593539906,
      "verified" : false
    }
  },
  "id" : 536466369370669056,
  "created_at" : "2014-11-23 10:28:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/WHrWG1u1II",
      "expanded_url" : "http:\/\/instagram.com\/p\/vvRYMMBwj_\/",
      "display_url" : "instagram.com\/p\/vvRYMMBwj_\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.365330409, 4.959784162 ]
  },
  "id_str" : "536463848023527424",
  "text" : "Campingplatz-Romantik in Amsterdam @ Camping Zeeburg http:\/\/t.co\/WHrWG1u1II",
  "id" : 536463848023527424,
  "created_at" : "2014-11-23 10:18:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/a3oTMC3nUW",
      "expanded_url" : "http:\/\/instagram.com\/p\/vvRAWihwiM\/",
      "display_url" : "instagram.com\/p\/vvRAWihwiM\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.375413145, 4.898221662 ]
  },
  "id_str" : "536463028301357057",
  "text" : "Let's tessellate @ Getto Food and Drinks http:\/\/t.co\/a3oTMC3nUW",
  "id" : 536463028301357057,
  "created_at" : "2014-11-23 10:15:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/E3ML8evE6t",
      "expanded_url" : "http:\/\/massgenomics.org\/2014\/11\/genome-evolution-and-domestication-of-the-cat.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+Massgenomics+%28MassGenomics%29",
      "display_url" : "massgenomics.org\/2014\/11\/genome\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536460905777995777",
  "text" : "Genomics of Cat Domestication http:\/\/t.co\/E3ML8evE6t",
  "id" : 536460905777995777,
  "created_at" : "2014-11-23 10:07:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 45, 51 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/ICZr3QMHfk",
      "expanded_url" : "http:\/\/feeds.arstechnica.com\/~r\/arstechnica\/science\/~3\/Q6VbjC9uN7g\/",
      "display_url" : "feeds.arstechnica.com\/~r\/arstechnica\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536460368869326848",
  "text" : "Lost languages leave traces on the brain \/cc @Lobot  http:\/\/t.co\/ICZr3QMHfk",
  "id" : 536460368869326848,
  "created_at" : "2014-11-23 10:04:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/VSxnsMhKpd",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/kRtba3opAR8\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536459523087945728",
  "text" : "Use Gauss' Theorem! http:\/\/t.co\/VSxnsMhKpd",
  "id" : 536459523087945728,
  "created_at" : "2014-11-23 10:01:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OneWeekofWhy",
      "screen_name" : "OneWeekofWhy",
      "indices" : [ 3, 16 ],
      "id_str" : "2821459834",
      "id" : 2821459834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StreetHarassment",
      "indices" : [ 46, 63 ]
    }, {
      "text" : "1WeekofWhy",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/fFvagkztMt",
      "expanded_url" : "https:\/\/oneweekofwhy.wordpress.com",
      "display_url" : "oneweekofwhy.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "536453943229153280",
  "text" : "RT @OneWeekofWhy: An experiment in addressing #StreetHarassment https:\/\/t.co\/fFvagkztMt #1WeekofWhy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StreetHarassment",
        "indices" : [ 28, 45 ]
      }, {
        "text" : "1WeekofWhy",
        "indices" : [ 70, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/fFvagkztMt",
        "expanded_url" : "https:\/\/oneweekofwhy.wordpress.com",
        "display_url" : "oneweekofwhy.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "535920644366811137",
    "text" : "An experiment in addressing #StreetHarassment https:\/\/t.co\/fFvagkztMt #1WeekofWhy",
    "id" : 535920644366811137,
    "created_at" : "2014-11-21 22:20:13 +0000",
    "user" : {
      "name" : "OneWeekofWhy",
      "screen_name" : "OneWeekofWhy",
      "protected" : false,
      "id_str" : "2821459834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542377607962963968\/l9OSmfHi_normal.jpeg",
      "id" : 2821459834,
      "verified" : false
    }
  },
  "id" : 536453943229153280,
  "created_at" : "2014-11-23 09:39:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536311176083570689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3649916825, 4.961087891 ]
  },
  "id_str" : "536424789637087232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer alles klar. :)",
  "id" : 536424789637087232,
  "in_reply_to_status_id" : 536311176083570689,
  "created_at" : "2014-11-23 07:43:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536301520548265985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.36501109791208, 4.961266089235396 ]
  },
  "id_str" : "536309208766222336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer du\/ihr seid dann gern gesehen bei uns. :)",
  "id" : 536309208766222336,
  "in_reply_to_status_id" : 536301520548265985,
  "created_at" : "2014-11-23 00:04:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536301520548265985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3656766705, 4.9607976203 ]
  },
  "id_str" : "536309182392434689",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ja, da bin ich verf\u00FCgbar. :)",
  "id" : 536309182392434689,
  "in_reply_to_status_id" : 536301520548265985,
  "created_at" : "2014-11-23 00:04:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536279684905172992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.365398231, 4.9596522178 ]
  },
  "id_str" : "536300855990161408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer congratulations. :)",
  "id" : 536300855990161408,
  "in_reply_to_status_id" : 536279684905172992,
  "created_at" : "2014-11-22 23:31:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536265616039354368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3690827987, 4.9649098973 ]
  },
  "id_str" : "536299977451270144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nope, bin leider bis Montag Nachmittag in Amsterdam :(",
  "id" : 536299977451270144,
  "in_reply_to_status_id" : 536265616039354368,
  "created_at" : "2014-11-22 23:27:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536246224362680320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.38323685377208, 4.903286538436098 ]
  },
  "id_str" : "536247950608187392",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju asked whether they have any strap on harnesses that can accommodate rings &gt;&gt; 67mm.",
  "id" : 536247950608187392,
  "in_reply_to_status_id" : 536246224362680320,
  "created_at" : "2014-11-22 20:00:49 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3832256823, 4.9033511849 ]
  },
  "id_str" : "536242815794438144",
  "text" : "\u00BBAchievement unlocked: made a sex shop clerk speechless.\u00BB",
  "id" : 536242815794438144,
  "created_at" : "2014-11-22 19:40:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/7J7VI1HWEA",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/0zFNEW8Lotr",
      "display_url" : "swarmapp.com\/c\/0zFNEW8Lotr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.375386, 4.898236 ]
  },
  "id_str" : "536207092538175488",
  "text" : "Back for dinner (@ Getto in Amsterdam, Netherlands) https:\/\/t.co\/7J7VI1HWEA",
  "id" : 536207092538175488,
  "created_at" : "2014-11-22 17:18:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/XBhbaDfxrG",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/lCB1h77eKfY",
      "display_url" : "swarmapp.com\/c\/lCB1h77eKfY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3728203506, 4.893682301 ]
  },
  "id_str" : "536179716391452672",
  "text" : "\u00ABTell Thorgnyr that we're standing next to that guy who's posing with his penis!\u00BB (@ Nationaal Monument op de Dam) https:\/\/t.co\/XBhbaDfxrG",
  "id" : 536179716391452672,
  "created_at" : "2014-11-22 15:29:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 40, 46 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3661847491, 4.9128734667 ]
  },
  "id_str" : "536119094819704833",
  "text" : "Erste Nacht im Zelt \u00FCberlebt, auch wenn @lobot sich nach Star Wars-Art in meinen Eingeweiden gew\u00E4rmt hat.",
  "id" : 536119094819704833,
  "created_at" : "2014-11-22 11:28:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceamovietitle",
      "indices" : [ 29, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.37541063743135, 4.898292888974549 ]
  },
  "id_str" : "535870382591725568",
  "text" : "Hey Dude, where\u2019s my mtcars? #scienceamovietitle",
  "id" : 535870382591725568,
  "created_at" : "2014-11-21 19:00:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/3xvZ5FaTN2",
      "expanded_url" : "http:\/\/instagram.com\/p\/vrClwAhwmr\/",
      "display_url" : "instagram.com\/p\/vrClwAhwmr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "535868377718611968",
  "text" : "Mirrorball(s) http:\/\/t.co\/3xvZ5FaTN2",
  "id" : 535868377718611968,
  "created_at" : "2014-11-21 18:52:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/9ABn6x7kWI",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/3E4ZqCqwtFq",
      "display_url" : "swarmapp.com\/c\/3E4ZqCqwtFq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.375386, 4.898236 ]
  },
  "id_str" : "535866544052789249",
  "text" : "'different homo made desserts' &lt;3 (@ Getto in Amsterdam, Netherlands) https:\/\/t.co\/9ABn6x7kWI",
  "id" : 535866544052789249,
  "created_at" : "2014-11-21 18:45:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "indices" : [ 3, 8 ],
      "id_str" : "9377892",
      "id" : 9377892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/hi1vH2tzMW",
      "expanded_url" : "http:\/\/ift.tt\/1qEWLPf",
      "display_url" : "ift.tt\/1qEWLPf"
    } ]
  },
  "geo" : { },
  "id_str" : "535780732325871616",
  "text" : "RT @tpoi: [Blog] So you're not a programmer. Are you sure? http:\/\/t.co\/hi1vH2tzMW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/hi1vH2tzMW",
        "expanded_url" : "http:\/\/ift.tt\/1qEWLPf",
        "display_url" : "ift.tt\/1qEWLPf"
      } ]
    },
    "geo" : { },
    "id_str" : "535720788583018497",
    "text" : "[Blog] So you're not a programmer. Are you sure? http:\/\/t.co\/hi1vH2tzMW",
    "id" : 535720788583018497,
    "created_at" : "2014-11-21 09:06:03 +0000",
    "user" : {
      "name" : "Timoth\u00E9e Poisot",
      "screen_name" : "tpoi",
      "protected" : false,
      "id_str" : "9377892",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919272965581299713\/CCD-XjJ1_normal.jpg",
      "id" : 9377892,
      "verified" : false
    }
  },
  "id" : 535780732325871616,
  "created_at" : "2014-11-21 13:04:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535709478302527488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140512988, 8.7532558671 ]
  },
  "id_str" : "535709659060264960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you push harder as well, otherwise we won\u2019t make it to Amsterdam while there\u2019s still daylight!",
  "id" : 535709659060264960,
  "in_reply_to_status_id" : 535709478302527488,
  "created_at" : "2014-11-21 08:21:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 48, 61 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535694837287120896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759902099999998 ]
  },
  "id_str" : "535699584467886080",
  "in_reply_to_user_id" : 1607703990,
  "text" : "@JennyMartin_UQ yes, all the collaboration with @PhilippBayer trained me for the Brisbane&lt;-&gt;Frankfurt time difference.",
  "id" : 535699584467886080,
  "in_reply_to_status_id" : 535694837287120896,
  "created_at" : "2014-11-21 07:41:48 +0000",
  "in_reply_to_screen_name" : "Jenny_STEM",
  "in_reply_to_user_id_str" : "1607703990",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535631277332766722",
  "geo" : { },
  "id_str" : "535694490225614848",
  "in_reply_to_user_id" : 1607703990,
  "text" : "@JennyMartin_UQ as your mornings are my evenings that seems to work out just fine.",
  "id" : 535694490225614848,
  "in_reply_to_status_id" : 535631277332766722,
  "created_at" : "2014-11-21 07:21:33 +0000",
  "in_reply_to_screen_name" : "Jenny_STEM",
  "in_reply_to_user_id_str" : "1607703990",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535554992027889664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "535586851479126016",
  "in_reply_to_user_id" : 1607703990,
  "text" : "@JennyMartin_UQ yes, very much so. Being one it pays off to follow people in all time zones.",
  "id" : 535586851479126016,
  "in_reply_to_status_id" : 535554992027889664,
  "created_at" : "2014-11-21 00:13:50 +0000",
  "in_reply_to_screen_name" : "Jenny_STEM",
  "in_reply_to_user_id_str" : "1607703990",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535553550990843905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "535554312395816960",
  "in_reply_to_user_id" : 1607703990,
  "text" : "@JennyMartin_UQ my late night reads are the PLOS RSS feeds. ;) thanks for writing the 10 rules, hope they will come in handy.",
  "id" : 535554312395816960,
  "in_reply_to_status_id" : 535553550990843905,
  "created_at" : "2014-11-20 22:04:32 +0000",
  "in_reply_to_screen_name" : "Jenny_STEM",
  "in_reply_to_user_id_str" : "1607703990",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Vincent",
      "screen_name" : "heathermvincent",
      "indices" : [ 0, 16 ],
      "id_str" : "355032358",
      "id" : 355032358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535550939558457344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1106703432, 8.7598925024 ]
  },
  "id_str" : "535551194241183744",
  "in_reply_to_user_id" : 355032358,
  "text" : "@heathermvincent me too, currently we have a course with a mix of biology and bioinformatics students. But it\u2019s all pretty much ad hoc.",
  "id" : 535551194241183744,
  "in_reply_to_status_id" : 535550939558457344,
  "created_at" : "2014-11-20 21:52:09 +0000",
  "in_reply_to_screen_name" : "heathermvincent",
  "in_reply_to_user_id_str" : "355032358",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Fountain",
      "screen_name" : "nickfountain",
      "indices" : [ 3, 16 ],
      "id_str" : "205580763",
      "id" : 205580763
    }, {
      "name" : "Sam Greenspan",
      "screen_name" : "samlistens",
      "indices" : [ 18, 29 ],
      "id_str" : "31125463",
      "id" : 31125463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535550827910692864",
  "text" : "RT @nickfountain: @samlistens the latest *pew pew* survey found that each millennial will get married more times than they will talk on the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Greenspan",
        "screen_name" : "samlistens",
        "indices" : [ 0, 11 ],
        "id_str" : "31125463",
        "id" : 31125463
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "535544926948192256",
    "geo" : { },
    "id_str" : "535545450548695041",
    "in_reply_to_user_id" : 31125463,
    "text" : "@samlistens the latest *pew pew* survey found that each millennial will get married more times than they will talk on the phone",
    "id" : 535545450548695041,
    "in_reply_to_status_id" : 535544926948192256,
    "created_at" : "2014-11-20 21:29:20 +0000",
    "in_reply_to_screen_name" : "samlistens",
    "in_reply_to_user_id_str" : "31125463",
    "user" : {
      "name" : "Nick Fountain",
      "screen_name" : "nickfountain",
      "protected" : false,
      "id_str" : "205580763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893196073988104192\/AtT1zbTT_normal.jpg",
      "id" : 205580763,
      "verified" : true
    }
  },
  "id" : 535550827910692864,
  "created_at" : "2014-11-20 21:50:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Vincent",
      "screen_name" : "heathermvincent",
      "indices" : [ 0, 16 ],
      "id_str" : "355032358",
      "id" : 355032358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535550069555343361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1116269981, 8.7577833198 ]
  },
  "id_str" : "535550259465035777",
  "in_reply_to_user_id" : 355032358,
  "text" : "@heathermvincent yes, but I would love to give that a try.",
  "id" : 535550259465035777,
  "in_reply_to_status_id" : 535550069555343361,
  "created_at" : "2014-11-20 21:48:26 +0000",
  "in_reply_to_screen_name" : "heathermvincent",
  "in_reply_to_user_id_str" : "355032358",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/OAZyF79Q5u",
      "expanded_url" : "http:\/\/nautil.us\/issue\/19\/illusions\/your-brain-cant-handle-the-moon",
      "display_url" : "nautil.us\/issue\/19\/illus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535547813048766464",
  "text" : "Your Brain Can\u2019t Handle the Moon http:\/\/t.co\/OAZyF79Q5u",
  "id" : 535547813048766464,
  "created_at" : "2014-11-20 21:38:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/OAqEoksO0R",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003903?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ploscompbiol%2FNewArticles+%28PLOS+Computational+Biology+-+New+Articles%29",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.114044, 8.75334 ]
  },
  "id_str" : "535545428532809731",
  "text" : "\u00ABTen Simple Rules to Achieve Conference Speaker Gender Balance\u00BB by @JennyMartin_UQ http:\/\/t.co\/OAqEoksO0R",
  "id" : 535545428532809731,
  "created_at" : "2014-11-20 21:29:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/yuqZgozVAG",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003896?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ploscompbiol%2FNewArticles+%28PLOS+Computational+Biology+-+New+Articles%29",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535542952173785088",
  "text" : "Teaching Bioinformatics in Concert http:\/\/t.co\/yuqZgozVAG",
  "id" : 535542952173785088,
  "created_at" : "2014-11-20 21:19:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/jMIGLAzWZT",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1176",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535542039019261953",
  "text" : "immortal http:\/\/t.co\/jMIGLAzWZT",
  "id" : 535542039019261953,
  "created_at" : "2014-11-20 21:15:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joint Genome Inst.",
      "screen_name" : "doe_jgi",
      "indices" : [ 14, 22 ],
      "id_str" : "20750406",
      "id" : 20750406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535520959428825088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11224419640602, 8.751930333905674 ]
  },
  "id_str" : "535521261125140481",
  "in_reply_to_user_id" : 1708856215,
  "text" : "@GolfXrayEcho @doe_jgi that\u2019s the same for me. :)",
  "id" : 535521261125140481,
  "in_reply_to_status_id" : 535520959428825088,
  "created_at" : "2014-11-20 19:53:12 +0000",
  "in_reply_to_screen_name" : "maggieRwagner",
  "in_reply_to_user_id_str" : "1708856215",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/IoTbOeibxF",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2105\/15\/357\/abstract",
      "display_url" : "biomedcentral.com\/1471-2105\/15\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535505792812978177",
  "text" : "NeatFreq: reference-free data reduction and coverage normalization for De Novo\u2026 http:\/\/t.co\/IoTbOeibxF",
  "id" : 535505792812978177,
  "created_at" : "2014-11-20 18:51:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "535490561692545024",
  "text" : "\u00ABIch finde es \u00FCbrigens voll gut das die Wohnung mir jetzt Hebr\u00E4isch beibringt. Noch besser finde ich das mein erstes Wort \u2018Toilette\u2019 ist.\u00BB",
  "id" : 535490561692545024,
  "created_at" : "2014-11-20 17:51:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joint Genome Inst.",
      "screen_name" : "doe_jgi",
      "indices" : [ 30, 38 ],
      "id_str" : "20750406",
      "id" : 20750406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140188417, 8.7535502842 ]
  },
  "id_str" : "535486020209639425",
  "text" : "Anyone here going to the 2015 @doe_jgi User Meeting?",
  "id" : 535486020209639425,
  "created_at" : "2014-11-20 17:33:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535463355168079872",
  "text" : "\u00ABWeisst du die Adresse von hier?\u00BB \u2013 \u00ABMax-von-Laue-Stra\u00DFe, Hausnummer: \u2018bis zum Ende durchfahren, der rote Kasten auf der linken Seite\u2019.\u00BB",
  "id" : 535463355168079872,
  "created_at" : "2014-11-20 16:03:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "myworstgrade",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535418445194862593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723655951083, 8.627545577473619 ]
  },
  "id_str" : "535462373025644544",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek I failed \u2018math &amp; comp sci for biologists\u2019, now doing a PhD in bioinformatics. #myworstgrade",
  "id" : 535462373025644544,
  "in_reply_to_status_id" : 535418445194862593,
  "created_at" : "2014-11-20 15:59:12 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535409531137064960",
  "text" : "\u00ABBy entering I agree to receive email communications from participating partners and the occasional confused aunt.\u00BB",
  "id" : 535409531137064960,
  "created_at" : "2014-11-20 12:29:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/9OBfvtV85a",
      "expanded_url" : "https:\/\/modelviewculture.com\/pieces\/you-say-you-want-diversity-but-we-cant-even-get-internships",
      "display_url" : "modelviewculture.com\/pieces\/you-say\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535401651289718784",
  "text" : "You Say You Want Diversity, But We Can\u2019t Even Get Internships https:\/\/t.co\/9OBfvtV85a",
  "id" : 535401651289718784,
  "created_at" : "2014-11-20 11:57:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/qpbcc0JG15",
      "expanded_url" : "http:\/\/goo.gl\/5ou5nu",
      "display_url" : "goo.gl\/5ou5nu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235493033144, 8.627553884238457 ]
  },
  "id_str" : "535385628532539392",
  "text" : "the oral history of the \uD83D\uDCA9 emoji http:\/\/t.co\/qpbcc0JG15",
  "id" : 535385628532539392,
  "created_at" : "2014-11-20 10:54:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 59, 72 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 73, 79 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/sKX5vRk1kT",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0112074",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535384051067404288",
  "text" : "Crowdsourcing Dialect Characterization through Twitter \/cc @PhilippBayer @Lobot http:\/\/t.co\/sKX5vRk1kT",
  "id" : 535384051067404288,
  "created_at" : "2014-11-20 10:47:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/T5lhhNRGfp",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/11\/19\/air-traffic-porn-from-the-uk-s.html",
      "display_url" : "boingboing.net\/2014\/11\/19\/air\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535381194587004928",
  "text" : "Air Traffic Porn from the UK Skies http:\/\/t.co\/T5lhhNRGfp",
  "id" : 535381194587004928,
  "created_at" : "2014-11-20 10:36:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monika",
      "screen_name" : "GreenSkyOverMe",
      "indices" : [ 0, 15 ],
      "id_str" : "345356127",
      "id" : 345356127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/HStHr5GL8x",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/17346997-doing-data-science",
      "display_url" : "goodreads.com\/book\/show\/1734\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535377704506654720",
  "geo" : { },
  "id_str" : "535377985017499648",
  "in_reply_to_user_id" : 345356127,
  "text" : "@GreenSkyOverMe https:\/\/t.co\/HStHr5GL8x",
  "id" : 535377985017499648,
  "in_reply_to_status_id" : 535377704506654720,
  "created_at" : "2014-11-20 10:23:53 +0000",
  "in_reply_to_screen_name" : "GreenSkyOverMe",
  "in_reply_to_user_id_str" : "345356127",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535359165620060160",
  "geo" : { },
  "id_str" : "535359418456899584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot we should get ours printed and hang them up in our room!",
  "id" : 535359418456899584,
  "in_reply_to_status_id" : 535359165620060160,
  "created_at" : "2014-11-20 09:10:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/etl4k8jfqo",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/11\/19\/smart-pipe-a-design-fiction-f.html",
      "display_url" : "boingboing.net\/2014\/11\/19\/sma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535352084846354432",
  "text" : "\u00ABSmart Pipe: flush from everywhere on the globe!\u00BB http:\/\/t.co\/etl4k8jfqo",
  "id" : 535352084846354432,
  "created_at" : "2014-11-20 08:40:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17250552496876, 8.627551873833129 ]
  },
  "id_str" : "535347980061388800",
  "text" : "\u00ABDa ist noch so ein Buch angekommen. Mit einem komischen G\u00FCrteltier auf dem Umschlag!\u00BB",
  "id" : 535347980061388800,
  "created_at" : "2014-11-20 08:24:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066599, 8.7599021 ]
  },
  "id_str" : "535333122834173952",
  "text" : "\u00ABIch hab getr\u00E4umt ich h\u00E4tte einen veganen Einlauf bekommen.\u00BB",
  "id" : 535333122834173952,
  "created_at" : "2014-11-20 07:25:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Hinde",
      "screen_name" : "Mammals_Suck",
      "indices" : [ 3, 16 ],
      "id_str" : "378259736",
      "id" : 378259736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "myworstgrade",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/ls0gw4aWod",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/?id=3548#comic",
      "display_url" : "smbc-comics.com\/?id=3548#comic"
    } ]
  },
  "geo" : { },
  "id_str" : "535223937161240577",
  "text" : "RT @Mammals_Suck: HAHAHAHHAHAHAHAHHAHAHAHAHA!  #myworstgrade http:\/\/t.co\/ls0gw4aWod",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "myworstgrade",
        "indices" : [ 29, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/ls0gw4aWod",
        "expanded_url" : "http:\/\/www.smbc-comics.com\/?id=3548#comic",
        "display_url" : "smbc-comics.com\/?id=3548#comic"
      } ]
    },
    "geo" : { },
    "id_str" : "535124378510712834",
    "text" : "HAHAHAHHAHAHAHAHHAHAHAHAHA!  #myworstgrade http:\/\/t.co\/ls0gw4aWod",
    "id" : 535124378510712834,
    "created_at" : "2014-11-19 17:36:08 +0000",
    "user" : {
      "name" : "Katie Hinde",
      "screen_name" : "Mammals_Suck",
      "protected" : false,
      "id_str" : "378259736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877586217352679424\/T8bLv4WS_normal.jpg",
      "id" : 378259736,
      "verified" : true
    }
  },
  "id" : 535223937161240577,
  "created_at" : "2014-11-20 00:11:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.2009973714, 8.5832499302 ]
  },
  "id_str" : "535100890974531584",
  "text" : "Unsicher ob es nur die Baustelle gegen\u00FCber ist oder ob gerade Kriegselefanten den Riedberg erklimmen.",
  "id" : 535100890974531584,
  "created_at" : "2014-11-19 16:02:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723313024, 8.6275656118 ]
  },
  "id_str" : "535075964569796608",
  "text" : "\u00ABDu hast ja relativ frei geredet w\u00E4hrend des Vortrags.\u00BB \u2014 \u00ABMuss ich ja auch, wenn ich nichts vorbereitet habe.\u00BB",
  "id" : 535075964569796608,
  "created_at" : "2014-11-19 14:23:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/KfVAlVjFzg",
      "expanded_url" : "http:\/\/www.laweekly.com\/informer\/2014\/11\/18\/in-the-gay-wing-of-la-mens-central-jail-its-not-shanks-and-muggings-but-hand-sewn-gowns-and-tears?showFullText=true",
      "display_url" : "laweekly.com\/informer\/2014\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535054296178782208",
  "text" : "In the Gay Wing of L.A. Men's Central Jail http:\/\/t.co\/KfVAlVjFzg",
  "id" : 535054296178782208,
  "created_at" : "2014-11-19 12:57:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/c2FVCZF04S",
      "expanded_url" : "http:\/\/www.spektrum.de\/news\/zur-ehrenrettung-des-kusses\/1319104",
      "display_url" : "spektrum.de\/news\/zur-ehren\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535021897550143490",
  "text" : "Knutschen f\u00FCr die Wissenschaft. Ich hab mir doch ein falsches Thema f\u00FCr den PhD ausgesucht. http:\/\/t.co\/c2FVCZF04S",
  "id" : 535021897550143490,
  "created_at" : "2014-11-19 10:48:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/2Fku5wnAjB",
      "expanded_url" : "http:\/\/img2.wikia.nocookie.net\/__cb20130207013554\/degrassi\/images\/1\/15\/LNJF_Glasses-thumb-500x276-27548.gif",
      "display_url" : "img2.wikia.nocookie.net\/__cb2013020701\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "535011016305041408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18685366939376, 8.605136682663039 ]
  },
  "id_str" : "535018916083675136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/2Fku5wnAjB",
  "id" : 535018916083675136,
  "in_reply_to_status_id" : 535011016305041408,
  "created_at" : "2014-11-19 10:37:04 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeerJ - the journal",
      "screen_name" : "thePeerJ",
      "indices" : [ 123, 132 ],
      "id_str" : "402875257",
      "id" : 402875257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/lYvE3JqNVb",
      "expanded_url" : "https:\/\/peerj.com\/articles\/675\/",
      "display_url" : "peerj.com\/articles\/675\/"
    } ]
  },
  "geo" : { },
  "id_str" : "535007384184573954",
  "text" : "Why embargoes suck: first news stories are already out, but the article itself wont be until 20th? https:\/\/t.co\/lYvE3JqNVb @thePeerJ",
  "id" : 535007384184573954,
  "created_at" : "2014-11-19 09:51:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535002618742202368",
  "text" : "\u00ABWoho, was f\u00FCr ein Grafikupdate!\u00BB Ab und an mal die Brille putzen w\u00E4re vielleicht doch eine gute Idee.",
  "id" : 535002618742202368,
  "created_at" : "2014-11-19 09:32:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Leipzig",
      "screen_name" : "jermdemo",
      "indices" : [ 3, 12 ],
      "id_str" : "16656236",
      "id" : 16656236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/jEpbusOITX",
      "expanded_url" : "https:\/\/www.biostars.org\/p\/119918\/",
      "display_url" : "biostars.org\/p\/119918\/"
    } ]
  },
  "geo" : { },
  "id_str" : "534838224020316160",
  "text" : "RT @jermdemo: Cloudera guy writes \"you all suck\" ppt, stirs up the hornet's nest of biostars\nhttps:\/\/t.co\/jEpbusOITX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/jEpbusOITX",
        "expanded_url" : "https:\/\/www.biostars.org\/p\/119918\/",
        "display_url" : "biostars.org\/p\/119918\/"
      } ]
    },
    "geo" : { },
    "id_str" : "534820997074264064",
    "text" : "Cloudera guy writes \"you all suck\" ppt, stirs up the hornet's nest of biostars\nhttps:\/\/t.co\/jEpbusOITX",
    "id" : 534820997074264064,
    "created_at" : "2014-11-18 21:30:36 +0000",
    "user" : {
      "name" : "Jeremy Leipzig",
      "screen_name" : "jermdemo",
      "protected" : false,
      "id_str" : "16656236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2651814724\/e7bfdcb6e77ede49eb1c9057f96202be_normal.jpeg",
      "id" : 16656236,
      "verified" : false
    }
  },
  "id" : 534838224020316160,
  "created_at" : "2014-11-18 22:39:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534709736101646336",
  "text" : "\u00ABMeine B\u00FCronachbarin deprimiert mich. Sie schreibt die ganze Zeit so fleissig. Und ich dr\u00FCck nur unmotiviert \u2018refresh\u2019 bei Facebook.\u00BB",
  "id" : 534709736101646336,
  "created_at" : "2014-11-18 14:08:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/NhKDRyckbW",
      "expanded_url" : "http:\/\/blog.goldenhelix.com\/?p=3046",
      "display_url" : "blog.goldenhelix.com\/?p=3046"
    } ]
  },
  "geo" : { },
  "id_str" : "534707568929943553",
  "text" : "Variant Notation: In simplicity we find complexity http:\/\/t.co\/NhKDRyckbW",
  "id" : 534707568929943553,
  "created_at" : "2014-11-18 13:59:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 0, 14 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/534688776552189953\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/CYZXXqMGFg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2uYm8KIQAAt9k5.jpg",
      "id_str" : "534688775524597760",
      "id" : 534688775524597760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2uYm8KIQAAt9k5.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/CYZXXqMGFg"
    } ],
    "hashtags" : [ {
      "text" : "scishirt",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534682642999173121",
  "geo" : { },
  "id_str" : "534688776552189953",
  "in_reply_to_user_id" : 112475924,
  "text" : "@JacquelynGill close enough to a #scishirt I guess. http:\/\/t.co\/CYZXXqMGFg",
  "id" : 534688776552189953,
  "in_reply_to_status_id" : 534682642999173121,
  "created_at" : "2014-11-18 12:45:13 +0000",
  "in_reply_to_screen_name" : "JacquelynGill",
  "in_reply_to_user_id_str" : "112475924",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/x4MXAO22aS",
      "expanded_url" : "http:\/\/media1.giphy.com\/media\/hVeBcXPeTrpTO\/200.gif",
      "display_url" : "media1.giphy.com\/media\/hVeBcXPe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "534681584721723392",
  "geo" : { },
  "id_str" : "534681958035759104",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/x4MXAO22aS",
  "id" : 534681958035759104,
  "in_reply_to_status_id" : 534681584721723392,
  "created_at" : "2014-11-18 12:18:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/hAhkjt8Gio",
      "expanded_url" : "http:\/\/jimnolan.typepad.com\/.a\/6a00e5521e0b2e88330120a79b7165970b-pi",
      "display_url" : "jimnolan.typepad.com\/.a\/6a00e5521e0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "534680295191371776",
  "geo" : { },
  "id_str" : "534681007782658049",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/hAhkjt8Gio",
  "id" : 534681007782658049,
  "in_reply_to_status_id" : 534680295191371776,
  "created_at" : "2014-11-18 12:14:20 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534668615338164224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17257240139895, 8.627384975560593 ]
  },
  "id_str" : "534675333312942080",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot so I can sue you for me becoming fat and show my data as evidence?",
  "id" : 534675333312942080,
  "in_reply_to_status_id" : 534668615338164224,
  "created_at" : "2014-11-18 11:51:47 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Adam Rutherford",
      "screen_name" : "AdamRutherford",
      "indices" : [ 3, 18 ],
      "id_str" : "22419487",
      "id" : 22419487
    }, {
      "name" : "EvolDir",
      "screen_name" : "evoldir",
      "indices" : [ 65, 73 ],
      "id_str" : "19108922",
      "id" : 19108922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534657313173692418",
  "text" : "RT @AdamRutherford: Biology: utter filth disguised as science RT @evoldir: survey of which bird species masturbate, for a phylogenetic http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EvolDir",
        "screen_name" : "evoldir",
        "indices" : [ 45, 53 ],
        "id_str" : "19108922",
        "id" : 19108922
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/m50ckgqDeZ",
        "expanded_url" : "http:\/\/bit.ly\/1u5a6ek",
        "display_url" : "bit.ly\/1u5a6ek"
      } ]
    },
    "geo" : { },
    "id_str" : "534654422711042048",
    "text" : "Biology: utter filth disguised as science RT @evoldir: survey of which bird species masturbate, for a phylogenetic http:\/\/t.co\/m50ckgqDeZ",
    "id" : 534654422711042048,
    "created_at" : "2014-11-18 10:28:42 +0000",
    "user" : {
      "name" : "Dr Adam Rutherford",
      "screen_name" : "AdamRutherford",
      "protected" : false,
      "id_str" : "22419487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608384474292846592\/6HNevMZN_normal.jpg",
      "id" : 22419487,
      "verified" : false
    }
  },
  "id" : 534657313173692418,
  "created_at" : "2014-11-18 10:40:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534653397006565376",
  "geo" : { },
  "id_str" : "534654878124347392",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn I\u2019m not really convinced that this is about mob rule.",
  "id" : 534654878124347392,
  "in_reply_to_status_id" : 534653397006565376,
  "created_at" : "2014-11-18 10:30:31 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shirtstorm",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/kKWFecngY7",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/doing-good-science\/2014\/11\/17\/the-rosetta-mission-shirtstorm-was-never-just-about-that-shirt\/",
      "display_url" : "blogs.scientificamerican.com\/doing-good-sci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534651780228202496",
  "text" : "The Rosetta mission #shirtstorm was never just about that shirt. http:\/\/t.co\/kKWFecngY7",
  "id" : 534651780228202496,
  "created_at" : "2014-11-18 10:18:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534461246373126144",
  "geo" : { },
  "id_str" : "534462171192000515",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule klingt gut, ich weiss nur noch nicht ob ich ab Montag oder Dienstag wieder im Land bin.",
  "id" : 534462171192000515,
  "in_reply_to_status_id" : 534461246373126144,
  "created_at" : "2014-11-17 21:44:46 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Rvf92FiUfA",
      "expanded_url" : "http:\/\/qz.com\/297811\/why-im-teaching-serial-instead-of-shakespeare\/",
      "display_url" : "qz.com\/297811\/why-im-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534461977440305152",
  "text" : "Why I\u2019m teaching Serial instead of Shakespeare http:\/\/t.co\/Rvf92FiUfA",
  "id" : 534461977440305152,
  "created_at" : "2014-11-17 21:43:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ZHHO5z3UkH",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/55",
      "display_url" : "existentialcomics.com\/comic\/55"
    } ]
  },
  "geo" : { },
  "id_str" : "534457325655183360",
  "text" : "what could be cooler than living a life of virtue? http:\/\/t.co\/ZHHO5z3UkH",
  "id" : 534457325655183360,
  "created_at" : "2014-11-17 21:25:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Krause",
      "screen_name" : "euleule",
      "indices" : [ 0, 8 ],
      "id_str" : "563152502",
      "id" : 563152502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534426684439920640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11322757309996, 8.753573954501093 ]
  },
  "id_str" : "534445673568301056",
  "in_reply_to_user_id" : 563152502,
  "text" : "@euleule wann darf man zum probekosten kommen? ;)",
  "id" : 534445673568301056,
  "in_reply_to_status_id" : 534426684439920640,
  "created_at" : "2014-11-17 20:39:12 +0000",
  "in_reply_to_screen_name" : "euleule",
  "in_reply_to_user_id_str" : "563152502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/59obBoAgND",
      "expanded_url" : "http:\/\/jonfwilkins.com\/2014\/11\/awesome-evolution-gif\/",
      "display_url" : "jonfwilkins.com\/2014\/11\/awesom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534438705940156416",
  "text" : "RT @jonfwilkins: Excellent evolution GIF\nhttp:\/\/t.co\/59obBoAgND",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/59obBoAgND",
        "expanded_url" : "http:\/\/jonfwilkins.com\/2014\/11\/awesome-evolution-gif\/",
        "display_url" : "jonfwilkins.com\/2014\/11\/awesom\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "534395699929309184",
    "text" : "Excellent evolution GIF\nhttp:\/\/t.co\/59obBoAgND",
    "id" : 534395699929309184,
    "created_at" : "2014-11-17 17:20:38 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 534438705940156416,
  "created_at" : "2014-11-17 20:11:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534436690056986624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759866362002386 ]
  },
  "id_str" : "534436829039427584",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich bum intended.",
  "id" : 534436829039427584,
  "in_reply_to_status_id" : 534436690056986624,
  "created_at" : "2014-11-17 20:04:04 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598938814, 8.75990209701374 ]
  },
  "id_str" : "534436439598325760",
  "text" : "Minzduschgel. Mein Hintern riecht nun nach After Eight.",
  "id" : 534436439598325760,
  "created_at" : "2014-11-17 20:02:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 67, 73 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/xOfxAWQrmZ",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2014\/11\/why-no-one-can-design-a-better-speculum\/382534\/?single_page=true",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534359545616023552",
  "text" : "Why No One Can Design a Better Speculum http:\/\/t.co\/xOfxAWQrmZ \/cc @Lobot",
  "id" : 534359545616023552,
  "created_at" : "2014-11-17 14:56:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/K2S4VNowyz",
      "expanded_url" : "http:\/\/media2.giphy.com\/media\/VdY9woinlWhLW\/200.gif",
      "display_url" : "media2.giphy.com\/media\/VdY9woin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534320536994971648",
  "text" : "\u00ABVerwendungszweck: Weltherrschaftsaktienant\u00ADeil\u00BB http:\/\/t.co\/K2S4VNowyz",
  "id" : 534320536994971648,
  "created_at" : "2014-11-17 12:21:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.19746803282401, 8.586334050685753 ]
  },
  "id_str" : "534288662792781824",
  "text" : "\u00ABHat die Posterior Probability was damit zu tun ob der Bote mein Paket zustellt oder nicht?\u00BB",
  "id" : 534288662792781824,
  "created_at" : "2014-11-17 10:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534286368147783680",
  "text" : "\u00ABWo liegt das File?\u00BB \u2013 \u00ABIn \/home\/user\/garantiertnichthier\/deinname\u00BB",
  "id" : 534286368147783680,
  "created_at" : "2014-11-17 10:06:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/YmYfcQHtOj",
      "expanded_url" : "http:\/\/neoacademic.com\/2014\/11\/13\/can-use-mechanical-turk-mturk-research-study\/#.VGkWiZPF9y8",
      "display_url" : "neoacademic.com\/2014\/11\/13\/can\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534095452690739201",
  "text" : "Can I Use MTurk for a Research Study? http:\/\/t.co\/YmYfcQHtOj",
  "id" : 534095452690739201,
  "created_at" : "2014-11-16 21:27:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/gxCnklyb4m",
      "expanded_url" : "http:\/\/www.salon.com\/2014\/11\/15\/hey_college_kids_major_in_john_oliver_and_neil_degrasse_tyson\/",
      "display_url" : "salon.com\/2014\/11\/15\/hey\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534093384898854912",
  "text" : "\u00ABHey, college kids: Major in John Oliver and Neil deGrasse Tyson\u00BB http:\/\/t.co\/gxCnklyb4m",
  "id" : 534093384898854912,
  "created_at" : "2014-11-16 21:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/88R2tQFqhe",
      "expanded_url" : "http:\/\/setosa.io\/blog\/2014\/07\/26\/markov-chains\/",
      "display_url" : "setosa.io\/blog\/2014\/07\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534078868647600128",
  "text" : "Didn\u2019t want to go into too much detail on Markov Chains &amp; HMMs in my next lecture, but this page makes me reconsider http:\/\/t.co\/88R2tQFqhe",
  "id" : 534078868647600128,
  "created_at" : "2014-11-16 20:21:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stempra",
      "screen_name" : "Stempra",
      "indices" : [ 3, 11 ],
      "id_str" : "23787335",
      "id" : 23787335
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Stempra\/status\/533916826624090112\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/fIvQRsqzuj",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B2jafBYCcAAiYFM.png",
      "id_str" : "533916782323462144",
      "id" : 533916782323462144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B2jafBYCcAAiYFM.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/fIvQRsqzuj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533977848869314560",
  "text" : "RT @Stempra: The difference between journalists and scientists http:\/\/t.co\/fIvQRsqzuj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Stempra\/status\/533916826624090112\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/fIvQRsqzuj",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B2jafBYCcAAiYFM.png",
        "id_str" : "533916782323462144",
        "id" : 533916782323462144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B2jafBYCcAAiYFM.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/fIvQRsqzuj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533916826624090112",
    "text" : "The difference between journalists and scientists http:\/\/t.co\/fIvQRsqzuj",
    "id" : 533916826624090112,
    "created_at" : "2014-11-16 09:37:45 +0000",
    "user" : {
      "name" : "Stempra",
      "screen_name" : "Stempra",
      "protected" : false,
      "id_str" : "23787335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844513509035692033\/uPcm5Vvf_normal.jpg",
      "id" : 23787335,
      "verified" : false
    }
  },
  "id" : 533977848869314560,
  "created_at" : "2014-11-16 13:40:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "indices" : [ 3, 14 ],
      "id_str" : "24506246",
      "id" : 24506246
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/533922458428915713\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/89Jqd4dW8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2jdRrSCIAE7RF0.jpg",
      "id_str" : "533919851589279745",
      "id" : 533919851589279745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2jdRrSCIAE7RF0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 583,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/89Jqd4dW8g"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/i8L2Ln2EuF",
      "expanded_url" : "http:\/\/htz.li\/On",
      "display_url" : "htz.li\/On"
    } ]
  },
  "geo" : { },
  "id_str" : "533926636799160320",
  "text" : "RT @haaretzcom: Jumping off the rooftops: Parkour in post-war in Gaza http:\/\/t.co\/i8L2Ln2EuF http:\/\/t.co\/89Jqd4dW8g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/533922458428915713\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/89Jqd4dW8g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2jdRrSCIAE7RF0.jpg",
        "id_str" : "533919851589279745",
        "id" : 533919851589279745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2jdRrSCIAE7RF0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/89Jqd4dW8g"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/i8L2Ln2EuF",
        "expanded_url" : "http:\/\/htz.li\/On",
        "display_url" : "htz.li\/On"
      } ]
    },
    "geo" : { },
    "id_str" : "533922458428915713",
    "text" : "Jumping off the rooftops: Parkour in post-war in Gaza http:\/\/t.co\/i8L2Ln2EuF http:\/\/t.co\/89Jqd4dW8g",
    "id" : 533922458428915713,
    "created_at" : "2014-11-16 10:00:08 +0000",
    "user" : {
      "name" : "Haaretz.com",
      "screen_name" : "haaretzcom",
      "protected" : false,
      "id_str" : "24506246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669523420774858753\/Q3O8r8FJ_normal.png",
      "id" : 24506246,
      "verified" : true
    }
  },
  "id" : 533926636799160320,
  "created_at" : "2014-11-16 10:16:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 17, 26 ],
      "id_str" : "850704103814705152",
      "id" : 850704103814705152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/wcNACtOG1F",
      "expanded_url" : "http:\/\/mindhacks.com\/2014\/11\/14\/hearing-wifi\/",
      "display_url" : "mindhacks.com\/2014\/11\/14\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533738155196051456",
  "text" : "Hearing WiFi \/cc @ennomane  http:\/\/t.co\/wcNACtOG1F",
  "id" : 533738155196051456,
  "created_at" : "2014-11-15 21:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/z0iqOywbkQ",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003892?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ploscompbiol%2FNewArticles+%28PLOS+Computational+Biology+-+New+Articles%29",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533737216737300480",
  "text" : "Global Disease Monitoring and Forecasting with Wikipedia http:\/\/t.co\/z0iqOywbkQ",
  "id" : 533737216737300480,
  "created_at" : "2014-11-15 21:44:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 32, 38 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "533551481690292224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067263369954, 8.7594942341813 ]
  },
  "id_str" : "533558589638848512",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy du hast das Pech zu nah an @Lobot Geburtstag zu haben. Da sind die etwas weniger WTFigen Penis-GIFs schon weg. ;)",
  "id" : 533558589638848512,
  "in_reply_to_status_id" : 533551481690292224,
  "created_at" : "2014-11-15 09:54:15 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/rLWUSGGYQv",
      "expanded_url" : "http:\/\/img0.joyreactor.com\/pics\/comment\/gif-penis-necklace-nsfw-304207.gif",
      "display_url" : "img0.joyreactor.com\/pics\/comment\/g\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11067220113692, 8.759627938817973 ]
  },
  "id_str" : "533539346960637952",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy alles gute zum Geburtstag (Symbolfoto: http:\/\/t.co\/rLWUSGGYQv)",
  "id" : 533539346960637952,
  "created_at" : "2014-11-15 08:37:47 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401180373129, 8.75348142684843 ]
  },
  "id_str" : "533537501508812800",
  "text" : "\u00ABMuss ich bei deinen Eltern noch was beachten?\u00BB \u2014 \u00ABNicht nach Mitternacht f\u00FCttern.\u00BB",
  "id" : 533537501508812800,
  "created_at" : "2014-11-15 08:30:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 35, 41 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/FIoyCtRvbw",
      "expanded_url" : "http:\/\/time.com\/why-schools-cant-teach-sex-ed\/",
      "display_url" : "time.com\/why-schools-ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533420144631238656",
  "text" : "Why Schools Can\u2019t Teach Sex Ed \/cc @Lobot  http:\/\/t.co\/FIoyCtRvbw",
  "id" : 533420144631238656,
  "created_at" : "2014-11-15 00:44:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/U2O24OeiCV",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/quO1-dLpGa8\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533419183477096448",
  "text" : "mad scientists http:\/\/t.co\/U2O24OeiCV",
  "id" : 533419183477096448,
  "created_at" : "2014-11-15 00:40:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Check Hayden",
      "screen_name" : "Erika_Check",
      "indices" : [ 3, 15 ],
      "id_str" : "17221246",
      "id" : 17221246
    }, {
      "name" : "Elie Dolgin",
      "screen_name" : "ElieDolgin",
      "indices" : [ 36, 47 ],
      "id_str" : "18235879",
      "id" : 18235879
    }, {
      "name" : "Nautilus",
      "screen_name" : "NautilusMag",
      "indices" : [ 48, 60 ],
      "id_str" : "485109912",
      "id" : 485109912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533348911273238528",
  "text" : "RT @Erika_Check: Must-read piece by @ElieDolgin @NautilusMag: \"A plea to stop developing drugs for the cancer that killed my mom\" http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elie Dolgin",
        "screen_name" : "ElieDolgin",
        "indices" : [ 19, 30 ],
        "id_str" : "18235879",
        "id" : 18235879
      }, {
        "name" : "Nautilus",
        "screen_name" : "NautilusMag",
        "indices" : [ 31, 43 ],
        "id_str" : "485109912",
        "id" : 485109912
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/P8zV7fsRaA",
        "expanded_url" : "http:\/\/bit.ly\/1wu14co",
        "display_url" : "bit.ly\/1wu14co"
      } ]
    },
    "geo" : { },
    "id_str" : "533262281468301315",
    "text" : "Must-read piece by @ElieDolgin @NautilusMag: \"A plea to stop developing drugs for the cancer that killed my mom\" http:\/\/t.co\/P8zV7fsRaA",
    "id" : 533262281468301315,
    "created_at" : "2014-11-14 14:16:50 +0000",
    "user" : {
      "name" : "Erika Check Hayden",
      "screen_name" : "Erika_Check",
      "protected" : false,
      "id_str" : "17221246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571365132605734912\/VhDhcr4i_normal.jpeg",
      "id" : 17221246,
      "verified" : true
    }
  },
  "id" : 533348911273238528,
  "created_at" : "2014-11-14 20:01:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/swBhbtRIQv",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0111700",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533348222316843009",
  "text" : "\u00ABAdolescent Sleep Patterns and Night-Time Technology Use\u00BB http:\/\/t.co\/swBhbtRIQv",
  "id" : 533348222316843009,
  "created_at" : "2014-11-14 19:58:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/dSQvjWjB8z",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/11\/13\/style\/alex-from-target-the-other-side-of-fame.html",
      "display_url" : "nytimes.com\/2014\/11\/13\/sty\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533347675853565952",
  "text" : "Alex From Target: The Other Side of Fame http:\/\/t.co\/dSQvjWjB8z",
  "id" : 533347675853565952,
  "created_at" : "2014-11-14 19:56:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 29, 42 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/XjIoPkHlZa",
      "expanded_url" : "http:\/\/www.boredpanda.com\/now-you-can-use-bitcoin-to-anonymously-send-poop-to-your-enemies\/",
      "display_url" : "boredpanda.com\/now-you-can-us\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09933880473973, 8.519000740593974 ]
  },
  "id_str" : "533342680118734849",
  "text" : "It\u2019s like Amazon for poo! RT @MaliciaRogue: You Can Now Anonymously Send Poop To Your Enemies http:\/\/t.co\/XjIoPkHlZa",
  "id" : 533342680118734849,
  "created_at" : "2014-11-14 19:36:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Statistics Blog",
      "screen_name" : "statisticsblog",
      "indices" : [ 3, 18 ],
      "id_str" : "31290415",
      "id" : 31290415
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/statisticsblog\/status\/465116862452211713\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/rbTeHiUkj0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnRtUkRCIAAn60g.jpg",
      "id_str" : "465116861625933824",
      "id" : 465116861625933824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnRtUkRCIAAn60g.jpg",
      "sizes" : [ {
        "h" : 468,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/rbTeHiUkj0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533342028814635008",
  "text" : "RT @statisticsblog: Type I and II errors simplified. http:\/\/t.co\/rbTeHiUkj0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/statisticsblog\/status\/465116862452211713\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/rbTeHiUkj0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnRtUkRCIAAn60g.jpg",
        "id_str" : "465116861625933824",
        "id" : 465116861625933824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnRtUkRCIAAn60g.jpg",
        "sizes" : [ {
          "h" : 468,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/rbTeHiUkj0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465116862452211713",
    "text" : "Type I and II errors simplified. http:\/\/t.co\/rbTeHiUkj0",
    "id" : 465116862452211713,
    "created_at" : "2014-05-10 13:11:16 +0000",
    "user" : {
      "name" : "Statistics Blog",
      "screen_name" : "statisticsblog",
      "protected" : false,
      "id_str" : "31290415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3143151325\/03c2d8d365c0135e09f752165312161f_normal.jpeg",
      "id" : 31290415,
      "verified" : false
    }
  },
  "id" : 533342028814635008,
  "created_at" : "2014-11-14 19:33:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Lowder",
      "screen_name" : "jbryanlowder",
      "indices" : [ 3, 16 ],
      "id_str" : "18316818",
      "id" : 18316818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533341610395049984",
  "text" : "RT @jbryanlowder: The new gay blood donation ban recommendation has been described as a \"softening\"; it's really an embarrassment: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/WlaQG4KLpx",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/outward\/2014\/11\/14\/gay_men_may_soon_be_able_to_donate_blood_if_they_re_celibate.html",
        "display_url" : "slate.com\/blogs\/outward\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "533319173880160257",
    "text" : "The new gay blood donation ban recommendation has been described as a \"softening\"; it's really an embarrassment: http:\/\/t.co\/WlaQG4KLpx",
    "id" : 533319173880160257,
    "created_at" : "2014-11-14 18:02:54 +0000",
    "user" : {
      "name" : "Bryan Lowder",
      "screen_name" : "jbryanlowder",
      "protected" : false,
      "id_str" : "18316818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/845287795245682688\/idlymS74_normal.jpg",
      "id" : 18316818,
      "verified" : true
    }
  },
  "id" : 533341610395049984,
  "created_at" : "2014-11-14 19:32:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/uTmxmCvsgB",
      "expanded_url" : "http:\/\/jonfwilkins.com\/2014\/11\/is-e-o-wilson-senile-narcissistic-or-just-an-asshole\/",
      "display_url" : "jonfwilkins.com\/2014\/11\/is-e-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533339113727205376",
  "text" : "RT @jonfwilkins: Today's question: Is E O Wilson senile, narcissistic, or just an a$$hole? http:\/\/t.co\/uTmxmCvsgB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/uTmxmCvsgB",
        "expanded_url" : "http:\/\/jonfwilkins.com\/2014\/11\/is-e-o-wilson-senile-narcissistic-or-just-an-asshole\/",
        "display_url" : "jonfwilkins.com\/2014\/11\/is-e-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "533299757255753728",
    "text" : "Today's question: Is E O Wilson senile, narcissistic, or just an a$$hole? http:\/\/t.co\/uTmxmCvsgB",
    "id" : 533299757255753728,
    "created_at" : "2014-11-14 16:45:45 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 533339113727205376,
  "created_at" : "2014-11-14 19:22:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Alice Bell",
      "screen_name" : "alicebell",
      "indices" : [ 112, 122 ],
      "id_str" : "19178857",
      "id" : 19178857
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shirtstorm",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532888848939098112",
  "text" : "RT @edyong209: #shirtstorm \"Pointing this out is not a distraction to the science. It\u2019s part of it.\" THANK YOU, @alicebell http:\/\/t.co\/vGTR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alice Bell",
        "screen_name" : "alicebell",
        "indices" : [ 97, 107 ],
        "id_str" : "19178857",
        "id" : 19178857
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shirtstorm",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/vGTRhQKmsK",
        "expanded_url" : "http:\/\/www.theguardian.com\/science\/2014\/nov\/13\/why-women-in-science-are-annoyed-at-rosetta-mission-scientists-clothing",
        "display_url" : "theguardian.com\/science\/2014\/n\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532866605030854656",
    "text" : "#shirtstorm \"Pointing this out is not a distraction to the science. It\u2019s part of it.\" THANK YOU, @alicebell http:\/\/t.co\/vGTRhQKmsK",
    "id" : 532866605030854656,
    "created_at" : "2014-11-13 12:04:33 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 532888848939098112,
  "created_at" : "2014-11-13 13:32:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/0DZp96HYsh",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/fAU5XJPlY5J4s\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/fAU5XJPl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "532823934216208384",
  "geo" : { },
  "id_str" : "532825332215472129",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i even made you some cake! http:\/\/t.co\/0DZp96HYsh",
  "id" : 532825332215472129,
  "in_reply_to_status_id" : 532823934216208384,
  "created_at" : "2014-11-13 09:20:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/USXbmRLzAx",
      "expanded_url" : "http:\/\/blogs.plos.org\/obesitypanacea\/2014\/11\/12\/could-smoking-cigarettes-make-you-a-better-runner\/",
      "display_url" : "blogs.plos.org\/obesitypanacea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532822596312911872",
  "text" : "Could smoking cigarettes make you a better runner? http:\/\/t.co\/USXbmRLzAx",
  "id" : 532822596312911872,
  "created_at" : "2014-11-13 09:09:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 12, 18 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/aU50g5XBFe",
      "expanded_url" : "http:\/\/img0.joyreactor.com\/pics\/post\/gif-nsfw-cat-penis-1205477.gif",
      "display_url" : "img0.joyreactor.com\/pics\/post\/gif-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532817278359044096",
  "text" : "Alles gute, @Lobot. Hier traditionsgem\u00E4\u00DF dein Twitter-Geschenk: http:\/\/t.co\/aU50g5XBFe",
  "id" : 532817278359044096,
  "created_at" : "2014-11-13 08:48:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SarcasticRover",
      "screen_name" : "SarcasticRover",
      "indices" : [ 3, 18 ],
      "id_str" : "740109097",
      "id" : 740109097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532695516514369536",
  "text" : "RT @SarcasticRover: I assume the lander is just saving its harpoons so it can hunt down that bearded idiot in the gross shirt.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532604308303269889",
    "text" : "I assume the lander is just saving its harpoons so it can hunt down that bearded idiot in the gross shirt.",
    "id" : 532604308303269889,
    "created_at" : "2014-11-12 18:42:17 +0000",
    "user" : {
      "name" : "SarcasticRover",
      "screen_name" : "SarcasticRover",
      "protected" : false,
      "id_str" : "740109097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839728901165203456\/mFZ-sZXQ_normal.jpg",
      "id" : 740109097,
      "verified" : false
    }
  },
  "id" : 532695516514369536,
  "created_at" : "2014-11-13 00:44:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 0, 11 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "Rose Eveleth \u25B7\u25B7",
      "screen_name" : "roseveleth",
      "indices" : [ 12, 23 ],
      "id_str" : "44903491",
      "id" : 44903491
    }, {
      "name" : "Emily [redacted] Willingham\uD83C\uDFC1",
      "screen_name" : "ejwillingham",
      "indices" : [ 24, 37 ],
      "id_str" : "77907514",
      "id" : 77907514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532540497387339776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11075508792079, 8.755801142493738 ]
  },
  "id_str" : "532694024554299392",
  "in_reply_to_user_id" : 46743752,
  "text" : "@joshwitten @roseveleth @ejwillingham it\u2019s like just seeing the problem would be rocket science. Oh, wait\u2026",
  "id" : 532694024554299392,
  "in_reply_to_status_id" : 532540497387339776,
  "created_at" : "2014-11-13 00:38:47 +0000",
  "in_reply_to_screen_name" : "joshwitten",
  "in_reply_to_user_id_str" : "46743752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/OHw7Ia5fAg",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/11\/12\/a-gay-guy-and-his-mom-go-to-a.html",
      "display_url" : "boingboing.net\/2014\/11\/12\/a-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532512545283002368",
  "text" : "\u00ABA gay guy and his mom go to a brothel, and have a good\u00A0time\u00BB http:\/\/t.co\/OHw7Ia5fAg",
  "id" : 532512545283002368,
  "created_at" : "2014-11-12 12:37:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532447766572957696",
  "geo" : { },
  "id_str" : "532455341989330944",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick yay, congratulations!",
  "id" : 532455341989330944,
  "in_reply_to_status_id" : 532447766572957696,
  "created_at" : "2014-11-12 08:50:20 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532455281461321728",
  "text" : "RT @pathogenomenick: Here it is at last! Reagent and laboratory contamination can critically impact sequence-based microbiome analyses http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/8Yn9jO2x2R",
        "expanded_url" : "http:\/\/www.biomedcentral.com\/1741-7007\/12\/87",
        "display_url" : "biomedcentral.com\/1741-7007\/12\/87"
      } ]
    },
    "geo" : { },
    "id_str" : "532447766572957696",
    "text" : "Here it is at last! Reagent and laboratory contamination can critically impact sequence-based microbiome analyses http:\/\/t.co\/8Yn9jO2x2R",
    "id" : 532447766572957696,
    "created_at" : "2014-11-12 08:20:14 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 532455281461321728,
  "created_at" : "2014-11-12 08:50:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 3, 18 ],
      "id_str" : "579299426",
      "id" : 579299426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/O4Z5oIbNEx",
      "expanded_url" : "http:\/\/www.maa.org\/sites\/default\/files\/pdf\/Mathhorizons\/supplement\/MH-CoreyWeb.pdf",
      "display_url" : "maa.org\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532270243893481472",
  "text" : "RT @stevenstrogatz: \"When will I ever use this?\" One math professor responds: http:\/\/t.co\/O4Z5oIbNEx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/O4Z5oIbNEx",
        "expanded_url" : "http:\/\/www.maa.org\/sites\/default\/files\/pdf\/Mathhorizons\/supplement\/MH-CoreyWeb.pdf",
        "display_url" : "maa.org\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532264164660891648",
    "text" : "\"When will I ever use this?\" One math professor responds: http:\/\/t.co\/O4Z5oIbNEx",
    "id" : 532264164660891648,
    "created_at" : "2014-11-11 20:10:40 +0000",
    "user" : {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "protected" : false,
      "id_str" : "579299426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2220536257\/fence_normal.jpeg",
      "id" : 579299426,
      "verified" : false
    }
  },
  "id" : 532270243893481472,
  "created_at" : "2014-11-11 20:34:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532243907464400897",
  "text" : "\u00ABWie lief es bei dir heute?\u00BB \u2014 \u00ABIch habe Perl-Code gelesen bis die Tr\u00E4nens\u00E4cke leer waren.\u00BB",
  "id" : 532243907464400897,
  "created_at" : "2014-11-11 18:50:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532192571603562496",
  "geo" : { },
  "id_str" : "532192724595003392",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Das sagst du mir jetzt wo der Bahnstreik vorbei ist und man wieder halbwegs normal zur Arbeit fahren kann?",
  "id" : 532192724595003392,
  "in_reply_to_status_id" : 532192571603562496,
  "created_at" : "2014-11-11 15:26:47 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532191442790514688",
  "geo" : { },
  "id_str" : "532192176441397248",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj \u201Classen sie mich durch, ich bin bald Doktor und meine Daten brauchen mich!\u201D",
  "id" : 532192176441397248,
  "in_reply_to_status_id" : 532191442790514688,
  "created_at" : "2014-11-11 15:24:37 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532190562246737920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235032259195, 8.627502236568391 ]
  },
  "id_str" : "532190991210799105",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj kommt darauf an um welche Uhrzeit man versucht durch die Frankfurter Innenstadt zu kommen. ;)",
  "id" : 532190991210799105,
  "in_reply_to_status_id" : 532190562246737920,
  "created_at" : "2014-11-11 15:19:54 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/KXUrsMREXD",
      "expanded_url" : "http:\/\/instagram.com\/p\/vQ54pIBwv3\/",
      "display_url" : "instagram.com\/p\/vQ54pIBwv3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "532190061534937088",
  "text" : "Still the 'fastest' way to move 1.5 TB of results\u2026 http:\/\/t.co\/KXUrsMREXD",
  "id" : 532190061534937088,
  "created_at" : "2014-11-11 15:16:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/HLtIvn8IHf",
      "expanded_url" : "http:\/\/bb.wynnear.com\/pics\/sauna.jpg",
      "display_url" : "bb.wynnear.com\/pics\/sauna.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "532158526001782784",
  "geo" : { },
  "id_str" : "532160347470573569",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/HLtIvn8IHf ;)",
  "id" : 532160347470573569,
  "in_reply_to_status_id" : 532158526001782784,
  "created_at" : "2014-11-11 13:18:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Research Wahlberg",
      "screen_name" : "ResearchMark",
      "indices" : [ 3, 16 ],
      "id_str" : "1868925908",
      "id" : 1868925908
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ResearchMark\/status\/532141912711782400\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/jUwIbboDOX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2KMPvqIcAA5LFL.jpg",
      "id_str" : "532141908102246400",
      "id" : 532141908102246400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2KMPvqIcAA5LFL.jpg",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 484
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 484
      } ],
      "display_url" : "pic.twitter.com\/jUwIbboDOX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532157174320218112",
  "text" : "RT @ResearchMark: Sup grad nation. Good luck out there. http:\/\/t.co\/jUwIbboDOX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ResearchMark\/status\/532141912711782400\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/jUwIbboDOX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2KMPvqIcAA5LFL.jpg",
        "id_str" : "532141908102246400",
        "id" : 532141908102246400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2KMPvqIcAA5LFL.jpg",
        "sizes" : [ {
          "h" : 484,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 484
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 484
        } ],
        "display_url" : "pic.twitter.com\/jUwIbboDOX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532141912711782400",
    "text" : "Sup grad nation. Good luck out there. http:\/\/t.co\/jUwIbboDOX",
    "id" : 532141912711782400,
    "created_at" : "2014-11-11 12:04:53 +0000",
    "user" : {
      "name" : "Research Wahlberg",
      "screen_name" : "ResearchMark",
      "protected" : false,
      "id_str" : "1868925908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650362041643986944\/fz6-xmr8_normal.jpg",
      "id" : 1868925908,
      "verified" : false
    }
  },
  "id" : 532157174320218112,
  "created_at" : "2014-11-11 13:05:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532156925119836160",
  "geo" : { },
  "id_str" : "532157053754933248",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich glaube \u201Cnackt im Wohnzimmer sitzen\u201D muss erst das WG-Tribunal \u00FCberstehen.",
  "id" : 532157053754933248,
  "in_reply_to_status_id" : 532156925119836160,
  "created_at" : "2014-11-11 13:05:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532153769270968320",
  "geo" : { },
  "id_str" : "532155819371286528",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot gut das wir so ein gro\u00DFes Wohnzimmer haben!",
  "id" : 532155819371286528,
  "in_reply_to_status_id" : 532153769270968320,
  "created_at" : "2014-11-11 13:00:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "532125633049296896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226716694195, 8.627563761996782 ]
  },
  "id_str" : "532149074729140224",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot deshalb wolltest du gern mit mir in die Sauna?",
  "id" : 532149074729140224,
  "in_reply_to_status_id" : 532125633049296896,
  "created_at" : "2014-11-11 12:33:20 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17279243009336, 8.627497564454263 ]
  },
  "id_str" : "532129233783754752",
  "text" : "\u00ABDas teuerste in dem Laden war alkoholfreies Wasser!\u00BB",
  "id" : 532129233783754752,
  "created_at" : "2014-11-11 11:14:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/DswrGZLmei",
      "expanded_url" : "http:\/\/instagram.com\/p\/vQXV94BwtJ\/",
      "display_url" : "instagram.com\/p\/vQXV94BwtJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "532114103125692418",
  "text" : "Rumsitzen und Warten http:\/\/t.co\/DswrGZLmei",
  "id" : 532114103125692418,
  "created_at" : "2014-11-11 10:14:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/FCox75nQxm",
      "expanded_url" : "http:\/\/bytesizebio.net\/2014\/11\/10\/why-scripting-is-not-as-simple-as-scripting\/",
      "display_url" : "bytesizebio.net\/2014\/11\/10\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531940621423214592",
  "text" : "Why scripting is not as simple as... scripting http:\/\/t.co\/FCox75nQxm",
  "id" : 531940621423214592,
  "created_at" : "2014-11-10 22:45:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Love",
      "screen_name" : "christinelove",
      "indices" : [ 3, 17 ],
      "id_str" : "14852199",
      "id" : 14852199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531934297981464576",
  "text" : "RT @christinelove: My girlfriend can flirt with whoever she wants, we have an open relationship, but\u2026 still, FUNCTIONAL PROGRAMMING, really\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531922229341069312",
    "text" : "My girlfriend can flirt with whoever she wants, we have an open relationship, but\u2026 still, FUNCTIONAL PROGRAMMING, really? Why, honey",
    "id" : 531922229341069312,
    "created_at" : "2014-11-10 21:31:56 +0000",
    "user" : {
      "name" : "Christine Love",
      "screen_name" : "christinelove",
      "protected" : false,
      "id_str" : "14852199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929084299172704256\/L1tPIyKz_normal.jpg",
      "id" : 14852199,
      "verified" : false
    }
  },
  "id" : 531934297981464576,
  "created_at" : "2014-11-10 22:19:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa T. Moreno",
      "screen_name" : "DanielGennaoui",
      "indices" : [ 3, 18 ],
      "id_str" : "790017240733278208",
      "id" : 790017240733278208
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Australia",
      "indices" : [ 39, 49 ]
    }, {
      "text" : "globalwarming",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5C5cvnHX9e",
      "expanded_url" : "http:\/\/bit.ly\/NiumeRighthere",
      "display_url" : "bit.ly\/NiumeRighthere"
    } ]
  },
  "geo" : { },
  "id_str" : "531932289119551488",
  "text" : "RT @DanielGennaoui: Awesome protest in #Australia against the lack of action on global warming: http:\/\/t.co\/5C5cvnHX9e #globalwarming http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DanielGennaoui\/status\/514753144996507648\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/QMRHlmneg1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByTFQgaIAAAAcFz.jpg",
        "id_str" : "514753144795168768",
        "id" : 514753144795168768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByTFQgaIAAAAcFz.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 625
        } ],
        "display_url" : "pic.twitter.com\/QMRHlmneg1"
      } ],
      "hashtags" : [ {
        "text" : "Australia",
        "indices" : [ 19, 29 ]
      }, {
        "text" : "globalwarming",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/5C5cvnHX9e",
        "expanded_url" : "http:\/\/bit.ly\/NiumeRighthere",
        "display_url" : "bit.ly\/NiumeRighthere"
      } ]
    },
    "geo" : { },
    "id_str" : "531516089986191362",
    "text" : "Awesome protest in #Australia against the lack of action on global warming: http:\/\/t.co\/5C5cvnHX9e #globalwarming http:\/\/t.co\/QMRHlmneg1",
    "id" : 531516089986191362,
    "created_at" : "2014-11-09 18:38:05 +0000",
    "user" : {
      "name" : "Daniel Gennaoui",
      "screen_name" : "danigennaoui",
      "protected" : false,
      "id_str" : "619374235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578665798660669440\/GwAC_KlI_normal.jpeg",
      "id" : 619374235,
      "verified" : false
    }
  },
  "id" : 531932289119551488,
  "created_at" : "2014-11-10 22:11:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Dart",
      "screen_name" : "R_Dart",
      "indices" : [ 3, 10 ],
      "id_str" : "302883217",
      "id" : 302883217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/R_Dart\/status\/531849715940593664\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/Dp9FY9wJyF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2GCf1kIYAAxV-x.jpg",
      "id_str" : "531849714472607744",
      "id" : 531849714472607744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2GCf1kIYAAxV-x.jpg",
      "sizes" : [ {
        "h" : 1198,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 1198,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 1198,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 505
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Dp9FY9wJyF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531930527851642880",
  "text" : "RT @R_Dart: This is what it was like to be alive in the 80s. http:\/\/t.co\/Dp9FY9wJyF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/R_Dart\/status\/531849715940593664\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/Dp9FY9wJyF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2GCf1kIYAAxV-x.jpg",
        "id_str" : "531849714472607744",
        "id" : 531849714472607744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2GCf1kIYAAxV-x.jpg",
        "sizes" : [ {
          "h" : 1198,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 1198,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 1198,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 505
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Dp9FY9wJyF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531849715940593664",
    "text" : "This is what it was like to be alive in the 80s. http:\/\/t.co\/Dp9FY9wJyF",
    "id" : 531849715940593664,
    "created_at" : "2014-11-10 16:43:48 +0000",
    "user" : {
      "name" : "Rebecca Dart",
      "screen_name" : "R_Dart",
      "protected" : false,
      "id_str" : "302883217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683357636318789633\/0cE5HMUI_normal.jpg",
      "id" : 302883217,
      "verified" : false
    }
  },
  "id" : 531930527851642880,
  "created_at" : "2014-11-10 22:04:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531930004943548416",
  "text" : "\u00ABDie deutsche Sprache macht Liebe mit meiner Seele.\u00BB \u2013 \u00ABDu schl\u00E4fst nicht nur mit mir, sondern auch mit meiner Mutter(sprache)?!\u00BB",
  "id" : 531930004943548416,
  "created_at" : "2014-11-10 22:02:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531898452264116225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.13132428103323, 8.626240042840005 ]
  },
  "id_str" : "531898543670566913",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 ach, w\u00E4re bestimmt auch nicht schlimmer ;)",
  "id" : 531898543670566913,
  "in_reply_to_status_id" : 531898452264116225,
  "created_at" : "2014-11-10 19:57:49 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 36, 42 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531897394179612672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.13134541281072, 8.6262130309362 ]
  },
  "id_str" : "531898338820775936",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 dann h\u00E4ttest du ja auch f\u00FCr @Lobot einspringen k\u00F6nnen!",
  "id" : 531898338820775936,
  "in_reply_to_status_id" : 531897394179612672,
  "created_at" : "2014-11-10 19:57:00 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Topol",
      "screen_name" : "EricTopol",
      "indices" : [ 3, 13 ],
      "id_str" : "86626845",
      "id" : 86626845
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "genomic",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Kuxy7wHymi",
      "expanded_url" : "http:\/\/goo.gl\/vdBWMY",
      "display_url" : "goo.gl\/vdBWMY"
    } ]
  },
  "geo" : { },
  "id_str" : "531897936280829952",
  "text" : "RT @EricTopol: How to avoid getting typhoid fever?  Here's a #genomic variant that provides &gt;80% protection http:\/\/t.co\/Kuxy7wHymi http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EricTopol\/status\/531890543232442368\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/TTTf6JFz3n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2GnoWhCUAAt52W.png",
        "id_str" : "531890542687178752",
        "id" : 531890542687178752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2GnoWhCUAAt52W.png",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/TTTf6JFz3n"
      } ],
      "hashtags" : [ {
        "text" : "genomic",
        "indices" : [ 46, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Kuxy7wHymi",
        "expanded_url" : "http:\/\/goo.gl\/vdBWMY",
        "display_url" : "goo.gl\/vdBWMY"
      } ]
    },
    "geo" : { },
    "id_str" : "531890543232442368",
    "text" : "How to avoid getting typhoid fever?  Here's a #genomic variant that provides &gt;80% protection http:\/\/t.co\/Kuxy7wHymi http:\/\/t.co\/TTTf6JFz3n",
    "id" : 531890543232442368,
    "created_at" : "2014-11-10 19:26:02 +0000",
    "user" : {
      "name" : "Eric Topol",
      "screen_name" : "EricTopol",
      "protected" : false,
      "id_str" : "86626845",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1388145490\/ET_IMG_6354_normal.jpg",
      "id" : 86626845,
      "verified" : true
    }
  },
  "id" : 531897936280829952,
  "created_at" : "2014-11-10 19:55:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Desktop Genetics",
      "screen_name" : "DesktopGenetics",
      "indices" : [ 3, 19 ],
      "id_str" : "631284628",
      "id" : 631284628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DIYbio",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "igem2014",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/HWWVrDBdOW",
      "expanded_url" : "http:\/\/buff.ly\/1xdmS1r",
      "display_url" : "buff.ly\/1xdmS1r"
    } ]
  },
  "geo" : { },
  "id_str" : "531894194089242624",
  "text" : "RT @DesktopGenetics: Open biology comes of age http:\/\/t.co\/HWWVrDBdOW #DIYbio #igem2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DIYbio",
        "indices" : [ 49, 56 ]
      }, {
        "text" : "igem2014",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/HWWVrDBdOW",
        "expanded_url" : "http:\/\/buff.ly\/1xdmS1r",
        "display_url" : "buff.ly\/1xdmS1r"
      } ]
    },
    "geo" : { },
    "id_str" : "531876699072626688",
    "text" : "Open biology comes of age http:\/\/t.co\/HWWVrDBdOW #DIYbio #igem2014",
    "id" : 531876699072626688,
    "created_at" : "2014-11-10 18:31:01 +0000",
    "user" : {
      "name" : "Desktop Genetics",
      "screen_name" : "DesktopGenetics",
      "protected" : false,
      "id_str" : "631284628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577890399605252097\/DRGh5YLz_normal.png",
      "id" : 631284628,
      "verified" : false
    }
  },
  "id" : 531894194089242624,
  "created_at" : "2014-11-10 19:40:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 86, 99 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/6jowBMhNpE",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0110579?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plosone%2FPLoSONE+%28PLOS+ONE+Alerts%3A+New+Articles%29",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.131254, 8.626093 ]
  },
  "id_str" : "531884353270587392",
  "text" : "On the Prospect of Identifying Adaptive Loci in Recently Bottlenecked Populations \/cc @PhilippBayer  http:\/\/t.co\/6jowBMhNpE",
  "id" : 531884353270587392,
  "created_at" : "2014-11-10 19:01:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/AKWXTN2rHz",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/54",
      "display_url" : "existentialcomics.com\/comic\/54"
    } ]
  },
  "geo" : { },
  "id_str" : "531883558529675265",
  "text" : "The Long Walk http:\/\/t.co\/AKWXTN2rHz",
  "id" : 531883558529675265,
  "created_at" : "2014-11-10 18:58:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/lxNOjqfWJZ",
      "expanded_url" : "http:\/\/feeds.wired.com\/c\/35185\/f\/661470\/s\/40580b49\/sc\/8\/l\/0L0Swired0N0C20A140C110Cverdict0Eoverturned0Eitalian0Egeoscientists0Econvicted0Emanslaughter0C\/story01.htm",
      "display_url" : "feeds.wired.com\/c\/35185\/f\/6614\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531880664904511488",
  "text" : "Verdict Overturned for Italian Geoscientists Convicted of Manslaughter http:\/\/t.co\/lxNOjqfWJZ",
  "id" : 531880664904511488,
  "created_at" : "2014-11-10 18:46:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aleksandar D. Kostic",
      "screen_name" : "adkostic",
      "indices" : [ 3, 12 ],
      "id_str" : "514318408",
      "id" : 514318408
    }, {
      "name" : "The Finch and Pea",
      "screen_name" : "finchandpea",
      "indices" : [ 105, 117 ],
      "id_str" : "156920978",
      "id" : 156920978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/f4kmo5kG7R",
      "expanded_url" : "http:\/\/wp.me\/pXK0q-3wh",
      "display_url" : "wp.me\/pXK0q-3wh"
    } ]
  },
  "geo" : { },
  "id_str" : "531879099355381760",
  "text" : "RT @adkostic: Let's call a spade a spade: Perpetuating the PhD pyramid scheme http:\/\/t.co\/f4kmo5kG7R via @finchandpea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Finch and Pea",
        "screen_name" : "finchandpea",
        "indices" : [ 91, 103 ],
        "id_str" : "156920978",
        "id" : 156920978
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/f4kmo5kG7R",
        "expanded_url" : "http:\/\/wp.me\/pXK0q-3wh",
        "display_url" : "wp.me\/pXK0q-3wh"
      } ]
    },
    "geo" : { },
    "id_str" : "531864590913515520",
    "text" : "Let's call a spade a spade: Perpetuating the PhD pyramid scheme http:\/\/t.co\/f4kmo5kG7R via @finchandpea",
    "id" : 531864590913515520,
    "created_at" : "2014-11-10 17:42:54 +0000",
    "user" : {
      "name" : "Aleksandar D. Kostic",
      "screen_name" : "adkostic",
      "protected" : false,
      "id_str" : "514318408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635174896780333056\/MqONLKQy_normal.jpg",
      "id" : 514318408,
      "verified" : false
    }
  },
  "id" : 531879099355381760,
  "created_at" : "2014-11-10 18:40:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/HVqPUJdbe0",
      "expanded_url" : "http:\/\/www.almob.org\/content\/8\/1\/25",
      "display_url" : "almob.org\/content\/8\/1\/25"
    } ]
  },
  "geo" : { },
  "id_str" : "531755725316685824",
  "text" : "Data compression for sequencing data http:\/\/t.co\/HVqPUJdbe0",
  "id" : 531755725316685824,
  "created_at" : "2014-11-10 10:30:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/OJdkmXBa61",
      "expanded_url" : "http:\/\/genomebiology.com\/2014\/15\/10\/501\/abstract",
      "display_url" : "genomebiology.com\/2014\/15\/10\/501\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531749626534440960",
  "text" : "Bayesian transcriptome assembly http:\/\/t.co\/OJdkmXBa61",
  "id" : 531749626534440960,
  "created_at" : "2014-11-10 10:06:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/UFi2FaSd8c",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/camelswithhammers\/2014\/07\/why-do-we-need-feminism-shouldnt-we-just-be-humanists-and-equalists\/",
      "display_url" : "patheos.com\/blogs\/camelswi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531748149917151233",
  "text" : "\u201CWhy Do We Need Feminism, Shouldn\u2019t We Just Be Humanists and Equalists?\u201D http:\/\/t.co\/UFi2FaSd8c",
  "id" : 531748149917151233,
  "created_at" : "2014-11-10 10:00:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/HyPE8tFmQ7",
      "expanded_url" : "http:\/\/www.metalinjection.net\/video\/heres-what-metallicas-one-sounds-like-in-medieval-times",
      "display_url" : "metalinjection.net\/video\/heres-wh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531746154678325248",
  "text" : "Metallica\u2019s \u2018One\u2019 played on medieval instruments http:\/\/t.co\/HyPE8tFmQ7",
  "id" : 531746154678325248,
  "created_at" : "2014-11-10 09:52:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/nnY4lWsSVX",
      "expanded_url" : "https:\/\/theconversation.com\/health-check-clash-of-the-orgasms-clitoral-vs-vaginal-32732",
      "display_url" : "theconversation.com\/health-check-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531733878621630464",
  "text" : "Health Check: clash of the orgasms, clitoral vs\u00A0vaginal https:\/\/t.co\/nnY4lWsSVX",
  "id" : 531733878621630464,
  "created_at" : "2014-11-10 09:03:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531726685096673280",
  "text" : "\u00ABPronunciation by PupsGesicht\u00BB Makes learning on a Monday morning instantly more fun.",
  "id" : 531726685096673280,
  "created_at" : "2014-11-10 08:34:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Switek @MFF",
      "screen_name" : "Laelaps",
      "indices" : [ 3, 11 ],
      "id_str" : "29342640",
      "id" : 29342640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531611777856192512",
  "text" : "RT @Laelaps: Want to see someone's tattoo? Don't paw. Don't pull at their clothes. Ask politely. No touching unless you're invited http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Laelaps\/status\/531607814750609408\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/GBahL9xlBi",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B2CmeN9CQAAlOVl.png",
        "id_str" : "531607794101665792",
        "id" : 531607794101665792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B2CmeN9CQAAlOVl.png",
        "sizes" : [ {
          "h" : 232,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/GBahL9xlBi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531607814750609408",
    "text" : "Want to see someone's tattoo? Don't paw. Don't pull at their clothes. Ask politely. No touching unless you're invited http:\/\/t.co\/GBahL9xlBi",
    "id" : 531607814750609408,
    "created_at" : "2014-11-10 00:42:34 +0000",
    "user" : {
      "name" : "Brian Switek @MFF",
      "screen_name" : "Laelaps",
      "protected" : false,
      "id_str" : "29342640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808347036579811328\/cy4jaooH_normal.jpg",
      "id" : 29342640,
      "verified" : true
    }
  },
  "id" : 531611777856192512,
  "created_at" : "2014-11-10 00:58:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/531528516991737856\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/fCzo7UZD91",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2BeXd0IEAAPFNS.jpg",
      "id_str" : "531528513262981120",
      "id" : 531528513262981120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2BeXd0IEAAPFNS.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/fCzo7UZD91"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10957149622593, 8.7566511505378 ]
  },
  "id_str" : "531528516991737856",
  "text" : "In Mainz dauert alles etwas l\u00E4nger. http:\/\/t.co\/fCzo7UZD91",
  "id" : 531528516991737856,
  "created_at" : "2014-11-09 19:27:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auazitrone \uD83C\uDF4B",
      "screen_name" : "mynnia",
      "indices" : [ 0, 7 ],
      "id_str" : "28602592",
      "id" : 28602592
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 8, 21 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531438178985852928",
  "geo" : { },
  "id_str" : "531458230955048960",
  "in_reply_to_user_id" : 28602592,
  "text" : "@mynnia @Naturalismus Zwillinge, bei der Geburt getrennt.",
  "id" : 531458230955048960,
  "in_reply_to_status_id" : 531438178985852928,
  "created_at" : "2014-11-09 14:48:10 +0000",
  "in_reply_to_screen_name" : "mynnia",
  "in_reply_to_user_id_str" : "28602592",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 3, 16 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/HxmyeDtvSj",
      "expanded_url" : "https:\/\/www.flickr.com\/photos\/vollefolklore\/15721853332\/",
      "display_url" : "flickr.com\/photos\/vollefo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531437215499694080",
  "text" : "RT @Naturalismus: has science gone too far?! https:\/\/t.co\/HxmyeDtvSj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/HxmyeDtvSj",
        "expanded_url" : "https:\/\/www.flickr.com\/photos\/vollefolklore\/15721853332\/",
        "display_url" : "flickr.com\/photos\/vollefo\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "531431588891201536",
    "geo" : { },
    "id_str" : "531432335716417538",
    "in_reply_to_user_id" : 77216385,
    "text" : "has science gone too far?! https:\/\/t.co\/HxmyeDtvSj",
    "id" : 531432335716417538,
    "in_reply_to_status_id" : 531431588891201536,
    "created_at" : "2014-11-09 13:05:17 +0000",
    "in_reply_to_screen_name" : "fireantprincess",
    "in_reply_to_user_id_str" : "77216385",
    "user" : {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "protected" : false,
      "id_str" : "77216385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791952428648148992\/xNKfrFl1_normal.jpg",
      "id" : 77216385,
      "verified" : false
    }
  },
  "id" : 531437215499694080,
  "created_at" : "2014-11-09 13:24:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531432130136801280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11084551113817, 8.759717026954101 ]
  },
  "id_str" : "531435854787776512",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus danke &lt;3",
  "id" : 531435854787776512,
  "in_reply_to_status_id" : 531432130136801280,
  "created_at" : "2014-11-09 13:19:16 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531431475464642561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11089161964127, 8.759593636491125 ]
  },
  "id_str" : "531431785180463105",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus bislang hat mir nie jemand das Mad Scientist-Image abgekauft. Mal schauen ob sich das \u00E4ndert.",
  "id" : 531431785180463105,
  "in_reply_to_status_id" : 531431475464642561,
  "created_at" : "2014-11-09 13:03:05 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/4OwGb5YySS",
      "expanded_url" : "http:\/\/massgenomics.org\/2014\/11\/brace-yourself-for-large-scale-whole-genome-sequencing.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+Massgenomics+%28MassGenomics%29",
      "display_url" : "massgenomics.org\/2014\/11\/brace-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531381280232202240",
  "text" : "Brace Yourself for Large-Scale Whole Genome Sequencing http:\/\/t.co\/4OwGb5YySS",
  "id" : 531381280232202240,
  "created_at" : "2014-11-09 09:42:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531221577300733952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11084415072841, 8.759658164349162 ]
  },
  "id_str" : "531221915638431745",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube wo ist auch schon der Spa\u00DF in \u2018einfach\u2019  ;)",
  "id" : 531221915638431745,
  "in_reply_to_status_id" : 531221577300733952,
  "created_at" : "2014-11-08 23:09:08 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531219996564000768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066639070067, 8.751959953049672 ]
  },
  "id_str" : "531220289955573760",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube das sieht von innen betrachtet nicht leichter aus, glaube ich.",
  "id" : 531220289955573760,
  "in_reply_to_status_id" : 531219996564000768,
  "created_at" : "2014-11-08 23:02:41 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531217799742754816",
  "text" : "\u00ABIch liebe dich.\u00BB \u2013 \u00ABUnd deine Mutter ist mehr so deine Secondary Partnerin, oder wie?\u00BB",
  "id" : 531217799742754816,
  "created_at" : "2014-11-08 22:52:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 56, 69 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/bbWKwGAjes",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001983",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531204868468641792",
  "text" : "\u00ABRedefining Genomic Privacy: Trust and Empowerment\u00BB \/cc @PhilippBayer http:\/\/t.co\/bbWKwGAjes",
  "id" : 531204868468641792,
  "created_at" : "2014-11-08 22:01:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/I7VpPObjpK",
      "expanded_url" : "https:\/\/medium.com\/message\/against-productivity-b19f56b67da6",
      "display_url" : "medium.com\/message\/agains\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531203335194673153",
  "text" : "Against Productivity: \u00ABThere was a time when you could write a few poems, die of TB, and call it a life well lived\u00BB https:\/\/t.co\/I7VpPObjpK",
  "id" : 531203335194673153,
  "created_at" : "2014-11-08 21:55:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/531193002803621888\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/BJI7UqBHxW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B18tN_QIMAACNbw.jpg",
      "id_str" : "531192999393636352",
      "id" : 531192999393636352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B18tN_QIMAACNbw.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/BJI7UqBHxW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11173364908409, 8.75585386511626 ]
  },
  "id_str" : "531193002803621888",
  "text" : "Christmas is nearing. And some of my flatmates already started handing out gifts. http:\/\/t.co\/BJI7UqBHxW",
  "id" : 531193002803621888,
  "created_at" : "2014-11-08 21:14:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/8DJ8u3GWbU",
      "expanded_url" : "http:\/\/bbc.in\/1zCBN6g",
      "display_url" : "bbc.in\/1zCBN6g"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00741314272771, 8.261496232700944 ]
  },
  "id_str" : "531152886034882560",
  "text" : "\u00ABMy other children, the orphan gorillas of Virunga\u00BB http:\/\/t.co\/8DJ8u3GWbU",
  "id" : 531152886034882560,
  "created_at" : "2014-11-08 18:34:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531149560081833984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00729674079113, 8.261593519200428 ]
  },
  "id_str" : "531149971673083904",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez congratulations!",
  "id" : 531149971673083904,
  "in_reply_to_status_id" : 531149560081833984,
  "created_at" : "2014-11-08 18:23:16 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 3, 8 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/klmr\/status\/531122270719467521\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/4TAD0ljamo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B17s4_lIAAAiZDc.png",
      "id_str" : "531122269960273920",
      "id" : 531122269960273920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B17s4_lIAAAiZDc.png",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4TAD0ljamo"
    } ],
    "hashtags" : [ {
      "text" : "emblomics",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/2ZVeGRL9hi",
      "expanded_url" : "http:\/\/chandoo.org\/wp\/2013\/04\/12\/why-3d-pie-charts-are-evil\/",
      "display_url" : "chandoo.org\/wp\/2013\/04\/12\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531147095877881856",
  "text" : "RT @klmr: 3D pie charts. #emblomics \n\nhttp:\/\/t.co\/2ZVeGRL9hi http:\/\/t.co\/4TAD0ljamo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/klmr\/status\/531122270719467521\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/4TAD0ljamo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B17s4_lIAAAiZDc.png",
        "id_str" : "531122269960273920",
        "id" : 531122269960273920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B17s4_lIAAAiZDc.png",
        "sizes" : [ {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4TAD0ljamo"
      } ],
      "hashtags" : [ {
        "text" : "emblomics",
        "indices" : [ 15, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/2ZVeGRL9hi",
        "expanded_url" : "http:\/\/chandoo.org\/wp\/2013\/04\/12\/why-3d-pie-charts-are-evil\/",
        "display_url" : "chandoo.org\/wp\/2013\/04\/12\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531122270719467521",
    "text" : "3D pie charts. #emblomics \n\nhttp:\/\/t.co\/2ZVeGRL9hi http:\/\/t.co\/4TAD0ljamo",
    "id" : 531122270719467521,
    "created_at" : "2014-11-08 16:33:11 +0000",
    "user" : {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "protected" : false,
      "id_str" : "773450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2617576817\/4n2x4ln6fqopk944375r_normal.jpeg",
      "id" : 773450,
      "verified" : false
    }
  },
  "id" : 531147095877881856,
  "created_at" : "2014-11-08 18:11:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mo Costandi",
      "screen_name" : "mocost",
      "indices" : [ 3, 10 ],
      "id_str" : "18985501",
      "id" : 18985501
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mocost\/status\/531054355315953664\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/BkBReY5fsl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B16vHvNCEAAbnC7.jpg",
      "id_str" : "531054353541369856",
      "id" : 531054353541369856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B16vHvNCEAAbnC7.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 555
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 555
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 555
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 555
      } ],
      "display_url" : "pic.twitter.com\/BkBReY5fsl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/3jM1rqfbOf",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1410.8001",
      "display_url" : "arxiv.org\/abs\/1410.8001"
    } ]
  },
  "geo" : { },
  "id_str" : "531075066860437505",
  "text" : "RT @mocost: The hipster effect: When anticonformists all look the same http:\/\/t.co\/3jM1rqfbOf http:\/\/t.co\/BkBReY5fsl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mocost\/status\/531054355315953664\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/BkBReY5fsl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B16vHvNCEAAbnC7.jpg",
        "id_str" : "531054353541369856",
        "id" : 531054353541369856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B16vHvNCEAAbnC7.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 555
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 555
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 555
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 555
        } ],
        "display_url" : "pic.twitter.com\/BkBReY5fsl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/3jM1rqfbOf",
        "expanded_url" : "http:\/\/arxiv.org\/abs\/1410.8001",
        "display_url" : "arxiv.org\/abs\/1410.8001"
      } ]
    },
    "geo" : { },
    "id_str" : "531054355315953664",
    "text" : "The hipster effect: When anticonformists all look the same http:\/\/t.co\/3jM1rqfbOf http:\/\/t.co\/BkBReY5fsl",
    "id" : 531054355315953664,
    "created_at" : "2014-11-08 12:03:19 +0000",
    "user" : {
      "name" : "Mo Costandi",
      "screen_name" : "mocost",
      "protected" : false,
      "id_str" : "18985501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830037263463698433\/-ijq6uXA_normal.jpg",
      "id" : 18985501,
      "verified" : false
    }
  },
  "id" : 531075066860437505,
  "created_at" : "2014-11-08 13:25:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Band",
      "screen_name" : "johnb78",
      "indices" : [ 3, 11 ],
      "id_str" : "19659468",
      "id" : 19659468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/iUujNXry7a",
      "expanded_url" : "https:\/\/twitter.com\/OHTheMaryD\/status\/510620909158150144\/photo\/1",
      "display_url" : "pic.twitter.com\/iUujNXry7a"
    } ]
  },
  "geo" : { },
  "id_str" : "531041427250487296",
  "text" : "RT @johnb78: This is brilliant. Actual linguist strikes down ignorant racist-ish grammar pedant http:\/\/t.co\/iUujNXry7a v\/@OHTheMaryD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/iUujNXry7a",
        "expanded_url" : "https:\/\/twitter.com\/OHTheMaryD\/status\/510620909158150144\/photo\/1",
        "display_url" : "pic.twitter.com\/iUujNXry7a"
      } ]
    },
    "geo" : { },
    "id_str" : "530958646293700608",
    "text" : "This is brilliant. Actual linguist strikes down ignorant racist-ish grammar pedant http:\/\/t.co\/iUujNXry7a v\/@OHTheMaryD",
    "id" : 530958646293700608,
    "created_at" : "2014-11-08 05:43:00 +0000",
    "user" : {
      "name" : "John Band",
      "screen_name" : "johnb78",
      "protected" : false,
      "id_str" : "19659468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763757371436904448\/uLEh0cnY_normal.jpg",
      "id" : 19659468,
      "verified" : false
    }
  },
  "id" : 531041427250487296,
  "created_at" : "2014-11-08 11:11:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530832768398159873",
  "geo" : { },
  "id_str" : "530862221426188289",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn but still you would think that researchers would be happy for any exposure for their work.",
  "id" : 530862221426188289,
  "in_reply_to_status_id" : 530832768398159873,
  "created_at" : "2014-11-07 23:19:51 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530862091746701313",
  "text" : "\u00ABWhat\u2019s that noise?\u00BB \u2013 \u00ABJust my flatmates, discussing how to invade Russia.\u00BB \u2013 \u00ABPlease, not again\u2026\u00BB",
  "id" : 530862091746701313,
  "created_at" : "2014-11-07 23:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530816634844639232",
  "geo" : { },
  "id_str" : "530822059157651456",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn because, really, it would be a shame if people could read some public journal articles! they could even cite them!",
  "id" : 530822059157651456,
  "in_reply_to_status_id" : 530816634844639232,
  "created_at" : "2014-11-07 20:40:15 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530816634844639232",
  "geo" : { },
  "id_str" : "530821946377003008",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn and, typical for Germany, DOIs have been blacked out for one university due to privacy concerns.",
  "id" : 530821946377003008,
  "in_reply_to_status_id" : 530816634844639232,
  "created_at" : "2014-11-07 20:39:48 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530796264288686080",
  "text" : "\u00ABIch wollte dich nicht bedr\u00E4ngen, ich wollte kuscheln heute Nacht.\u00BB\u2013\u00ABKuscheln? Das f\u00FChlte sich mehr nach Kuschelraum im Osten gewinnen an!\u00BB",
  "id" : 530796264288686080,
  "created_at" : "2014-11-07 18:57:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 3, 11 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/SqITUNVUDQ",
      "expanded_url" : "https:\/\/github.com\/domitry\/mikon",
      "display_url" : "github.com\/domitry\/mikon"
    } ]
  },
  "geo" : { },
  "id_str" : "530752286705090561",
  "text" : "RT @heyaudy: A Data Frame for Ruby! https:\/\/t.co\/SqITUNVUDQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/SqITUNVUDQ",
        "expanded_url" : "https:\/\/github.com\/domitry\/mikon",
        "display_url" : "github.com\/domitry\/mikon"
      } ]
    },
    "geo" : { },
    "id_str" : "530751418060537858",
    "text" : "A Data Frame for Ruby! https:\/\/t.co\/SqITUNVUDQ",
    "id" : 530751418060537858,
    "created_at" : "2014-11-07 15:59:33 +0000",
    "user" : {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "protected" : false,
      "id_str" : "14534523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923034147777474561\/zZvXWmSQ_normal.jpg",
      "id" : 14534523,
      "verified" : false
    }
  },
  "id" : 530752286705090561,
  "created_at" : "2014-11-07 16:03:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 0, 13 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530729788684926977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231255307208, 8.627610667976347 ]
  },
  "id_str" : "530730006507712512",
  "in_reply_to_user_id" : 49413866,
  "text" : "@randal_olson that would be interesting. Equally for the age difference.",
  "id" : 530730006507712512,
  "in_reply_to_status_id" : 530729788684926977,
  "created_at" : "2014-11-07 14:34:28 +0000",
  "in_reply_to_screen_name" : "randal_olson",
  "in_reply_to_user_id_str" : "49413866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 0, 13 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530729197019598848",
  "geo" : { },
  "id_str" : "530729486724382720",
  "in_reply_to_user_id" : 49413866,
  "text" : "@randal_olson but seriously, was that corrected for untimely death? :)",
  "id" : 530729486724382720,
  "in_reply_to_status_id" : 530729197019598848,
  "created_at" : "2014-11-07 14:32:24 +0000",
  "in_reply_to_screen_name" : "randal_olson",
  "in_reply_to_user_id_str" : "49413866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 0, 13 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530725376432283648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235969537574, 8.627480370085303 ]
  },
  "id_str" : "530728473040793600",
  "in_reply_to_user_id" : 49413866,
  "text" : "@randal_olson but the longer you stay together the closer you are to death anyway?",
  "id" : 530728473040793600,
  "in_reply_to_status_id" : 530725376432283648,
  "created_at" : "2014-11-07 14:28:23 +0000",
  "in_reply_to_screen_name" : "randal_olson",
  "in_reply_to_user_id_str" : "49413866",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/QDjPlJGihP",
      "expanded_url" : "http:\/\/m.youtube.com\/watch?v=P1erBDceTxI",
      "display_url" : "m.youtube.com\/watch?v=P1erBD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530716633359474688",
  "text" : "It's About Ethics In Journalism!! http:\/\/t.co\/QDjPlJGihP",
  "id" : 530716633359474688,
  "created_at" : "2014-11-07 13:41:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/jlz7zxugF2",
      "expanded_url" : "http:\/\/blog.longreads.com\/2014\/11\/06\/a-birth-story\/",
      "display_url" : "blog.longreads.com\/2014\/11\/06\/a-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530644576235962370",
  "text" : "A Birth Story: \u00ABFuck everything, I thought. Bring on the cascading interventions.\u00BB http:\/\/t.co\/jlz7zxugF2",
  "id" : 530644576235962370,
  "created_at" : "2014-11-07 08:55:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/P4iOgv7iAW",
      "expanded_url" : "http:\/\/blogs.plos.org\/citizensci\/2014\/11\/06\/groundbreaking-air-quality-study-demonstrates-power-citizen-science\/",
      "display_url" : "blogs.plos.org\/citizensci\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530642574617620480",
  "text" : "Groundbreaking Air Quality Study Demonstrates the Power of Citizen Science http:\/\/t.co\/P4iOgv7iAW",
  "id" : 530642574617620480,
  "created_at" : "2014-11-07 08:47:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Petre",
      "screen_name" : "BenjPetre",
      "indices" : [ 3, 13 ],
      "id_str" : "319616281",
      "id" : 319616281
    }, {
      "name" : "Samuel L. Jackson",
      "screen_name" : "SamuelLJackson",
      "indices" : [ 66, 81 ],
      "id_str" : "75974281",
      "id" : 75974281
    }, {
      "name" : "Sophien Kamoun",
      "screen_name" : "KamounLab",
      "indices" : [ 82, 92 ],
      "id_str" : "49270737",
      "id" : 49270737
    }, {
      "name" : "Tolga Bozkurt",
      "screen_name" : "Tolga_Bzkrt",
      "indices" : [ 93, 105 ],
      "id_str" : "2707427939",
      "id" : 2707427939
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BenjPetre\/status\/530424440556122113\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Roc18d3OVA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1xyN6rIIAAh6Tg.jpg",
      "id_str" : "530424439536885760",
      "id" : 530424439536885760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1xyN6rIIAAh6Tg.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1153
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1967
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1967
      } ],
      "display_url" : "pic.twitter.com\/Roc18d3OVA"
    } ],
    "hashtags" : [ {
      "text" : "oomycetearenotfungi",
      "indices" : [ 45, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530499087762993152",
  "text" : "RT @BenjPetre: 'SAY FUNGI ONE MORE TIME ...' #oomycetearenotfungi @SamuelLJackson @KamounLab @Tolga_Bzkrt http:\/\/t.co\/Roc18d3OVA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Samuel L. Jackson",
        "screen_name" : "SamuelLJackson",
        "indices" : [ 51, 66 ],
        "id_str" : "75974281",
        "id" : 75974281
      }, {
        "name" : "Sophien Kamoun",
        "screen_name" : "KamounLab",
        "indices" : [ 67, 77 ],
        "id_str" : "49270737",
        "id" : 49270737
      }, {
        "name" : "Tolga Bozkurt",
        "screen_name" : "Tolga_Bzkrt",
        "indices" : [ 78, 90 ],
        "id_str" : "2707427939",
        "id" : 2707427939
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BenjPetre\/status\/530424440556122113\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/Roc18d3OVA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1xyN6rIIAAh6Tg.jpg",
        "id_str" : "530424439536885760",
        "id" : 530424439536885760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1xyN6rIIAAh6Tg.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1153
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1967
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1967
        } ],
        "display_url" : "pic.twitter.com\/Roc18d3OVA"
      } ],
      "hashtags" : [ {
        "text" : "oomycetearenotfungi",
        "indices" : [ 30, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530424440556122113",
    "text" : "'SAY FUNGI ONE MORE TIME ...' #oomycetearenotfungi @SamuelLJackson @KamounLab @Tolga_Bzkrt http:\/\/t.co\/Roc18d3OVA",
    "id" : 530424440556122113,
    "created_at" : "2014-11-06 18:20:16 +0000",
    "user" : {
      "name" : "Ben Petre",
      "screen_name" : "BenjPetre",
      "protected" : false,
      "id_str" : "319616281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783031478657683456\/A0q2fhzJ_normal.jpg",
      "id" : 319616281,
      "verified" : false
    }
  },
  "id" : 530499087762993152,
  "created_at" : "2014-11-06 23:16:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530496321556590592",
  "text" : "\u00ABIch weiss das du mich nat\u00FCrlich auch lieben w\u00FCrdest wenn ich Sexarbeit mache. Wenn ich PR machen w\u00FCrde bin ich mir da aber nicht so sicher\u00BB",
  "id" : 530496321556590592,
  "created_at" : "2014-11-06 23:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/AhTtkyIxqL",
      "expanded_url" : "http:\/\/www.theguardian.com\/higher-education-network\/blog\/2013\/nov\/15\/supervisor-sadness-phd-thesis-deadline?CMP=share_btn_tw",
      "display_url" : "theguardian.com\/higher-educati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530494081542393856",
  "text" : "PhD supervisor sadness: the empty nest http:\/\/t.co\/AhTtkyIxqL",
  "id" : 530494081542393856,
  "created_at" : "2014-11-06 22:56:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.07708001710408, 8.228939968367895 ]
  },
  "id_str" : "530449228846620673",
  "text" : "\u00ABDude, this is ridiculous. 1200 people and a single bathroom!\u00BB \u2014 \u00ABI guess that tells you how well visited the church services were?\u00BB",
  "id" : 530449228846620673,
  "created_at" : "2014-11-06 19:58:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/F3Wnyat6WH",
      "expanded_url" : "http:\/\/instagram.com\/p\/vEhtb-hwlt\/",
      "display_url" : "instagram.com\/p\/vEhtb-hwlt\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.077203076, 8.229913344 ]
  },
  "id_str" : "530448050905681920",
  "text" : "Iron &amp; Wine (data not shown) @ Ringkirche http:\/\/t.co\/F3Wnyat6WH",
  "id" : 530448050905681920,
  "created_at" : "2014-11-06 19:54:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jojo Scoble \uD83D\uDD2C",
      "screen_name" : "Paraphyso",
      "indices" : [ 3, 13 ],
      "id_str" : "290019499",
      "id" : 290019499
    }, {
      "name" : "EvolDir",
      "screen_name" : "evoldir",
      "indices" : [ 119, 127 ],
      "id_str" : "19108922",
      "id" : 19108922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PhD",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/LkO4NB6S7k",
      "expanded_url" : "http:\/\/bit.ly\/1z1P0SU",
      "display_url" : "bit.ly\/1z1P0SU"
    } ]
  },
  "geo" : { },
  "id_str" : "530331775638454272",
  "text" : "RT @Paraphyso: 27 new PhD positions!!! WOW. Spread the word. PhD funding - University of Exeter http:\/\/t.co\/LkO4NB6S7k @evoldir #PhD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EvolDir",
        "screen_name" : "evoldir",
        "indices" : [ 104, 112 ],
        "id_str" : "19108922",
        "id" : 19108922
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PhD",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/LkO4NB6S7k",
        "expanded_url" : "http:\/\/bit.ly\/1z1P0SU",
        "display_url" : "bit.ly\/1z1P0SU"
      } ]
    },
    "geo" : { },
    "id_str" : "530329346570215424",
    "text" : "27 new PhD positions!!! WOW. Spread the word. PhD funding - University of Exeter http:\/\/t.co\/LkO4NB6S7k @evoldir #PhD",
    "id" : 530329346570215424,
    "created_at" : "2014-11-06 12:02:23 +0000",
    "user" : {
      "name" : "Jojo Scoble \uD83D\uDD2C",
      "screen_name" : "Paraphyso",
      "protected" : false,
      "id_str" : "290019499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564863846121496576\/UZqFw1vO_normal.jpeg",
      "id" : 290019499,
      "verified" : false
    }
  },
  "id" : 530331775638454272,
  "created_at" : "2014-11-06 12:12:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bended Realities",
      "screen_name" : "bendedrealities",
      "indices" : [ 3, 19 ],
      "id_str" : "1332989701",
      "id" : 1332989701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530313240983904256",
  "text" : "RT @bendedrealities: Wir bauen ein Computermuseum, Kulturzentrum, Caf\u00E9 &amp; einen Makerspace f\u00FCr Offenbach und jede Spende bringt uns weiter h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/EYRvJyi48G",
        "expanded_url" : "https:\/\/www.startnext.de\/digital-retro-park",
        "display_url" : "startnext.de\/digital-retro-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530055736081268736",
    "text" : "Wir bauen ein Computermuseum, Kulturzentrum, Caf\u00E9 &amp; einen Makerspace f\u00FCr Offenbach und jede Spende bringt uns weiter https:\/\/t.co\/EYRvJyi48G",
    "id" : 530055736081268736,
    "created_at" : "2014-11-05 17:55:10 +0000",
    "user" : {
      "name" : "Bended Realities",
      "screen_name" : "bendedrealities",
      "protected" : false,
      "id_str" : "1332989701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453446975455637504\/bIoGf0dC_normal.jpeg",
      "id" : 1332989701,
      "verified" : false
    }
  },
  "id" : 530313240983904256,
  "created_at" : "2014-11-06 10:58:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530283801348689920",
  "geo" : { },
  "id_str" : "530287965134934016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot we would never be sure whether the battery or the cat is dead.",
  "id" : 530287965134934016,
  "in_reply_to_status_id" : 530283801348689920,
  "created_at" : "2014-11-06 09:17:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 40, 46 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/bhK6UvmFI8",
      "expanded_url" : "http:\/\/sipping.coffee\/2014\/10\/29\/cat-fitbit-fitness-tracking\/",
      "display_url" : "sipping.coffee\/2014\/10\/29\/cat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530260996905263104",
  "text" : "QuantifiedCat. May I borrow your Fitbit @Lobot? http:\/\/t.co\/bhK6UvmFI8",
  "id" : 530260996905263104,
  "created_at" : "2014-11-06 07:30:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530248724476624896",
  "text" : "\u00ABNicht nackt das Zimmer verlassen, sonst f\u00E4llt drau\u00DFen jemand vor Schreck vom Sofa.\u00BB\u2013\u00ABDer hat schon mal einen Penis gesehen, der ist JuPi.\u00BB",
  "id" : 530248724476624896,
  "created_at" : "2014-11-06 06:42:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/V1EwFm4lbW",
      "expanded_url" : "http:\/\/www.companionanimalpsychology.com\/2014\/11\/how-many-dogs-is-enough-for-canine.html",
      "display_url" : "companionanimalpsychology.com\/2014\/11\/how-ma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530125859794194433",
  "text" : "How Many Dogs is Enough for Canine Science? http:\/\/t.co\/V1EwFm4lbW",
  "id" : 530125859794194433,
  "created_at" : "2014-11-05 22:33:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/BWPqupH8db",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/11\/05\/watch-very-polite-robber.html",
      "display_url" : "boingboing.net\/2014\/11\/05\/wat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403203956897, 8.753436155993837 ]
  },
  "id_str" : "530123881844310018",
  "text" : "very polite robber http:\/\/t.co\/BWPqupH8db",
  "id" : 530123881844310018,
  "created_at" : "2014-11-05 22:25:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sexletterchallenge",
      "indices" : [ 21, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/h2rtB1aoW1",
      "expanded_url" : "http:\/\/sexlettersproject.tumblr.com\/post\/101810832409\/youre-right-keep-ignoring-them-hazels-letter",
      "display_url" : "sexlettersproject.tumblr.com\/post\/101810832\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530109751859097600",
  "text" : "RT @vortacist: First #sexletterchallenge letter is up! You\u2019re Right \u2014 Keep Ignoring Them: Hazel\u2019s Letter http:\/\/t.co\/h2rtB1aoW1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sexletterchallenge",
        "indices" : [ 6, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/h2rtB1aoW1",
        "expanded_url" : "http:\/\/sexlettersproject.tumblr.com\/post\/101810832409\/youre-right-keep-ignoring-them-hazels-letter",
        "display_url" : "sexlettersproject.tumblr.com\/post\/101810832\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530062347503927296",
    "text" : "First #sexletterchallenge letter is up! You\u2019re Right \u2014 Keep Ignoring Them: Hazel\u2019s Letter http:\/\/t.co\/h2rtB1aoW1",
    "id" : 530062347503927296,
    "created_at" : "2014-11-05 18:21:26 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 530109751859097600,
  "created_at" : "2014-11-05 21:29:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Ouellette",
      "screen_name" : "JenLucPiquant",
      "indices" : [ 3, 17 ],
      "id_str" : "128292609",
      "id" : 128292609
    }, {
      "name" : "Ben Orlin",
      "screen_name" : "benorlin",
      "indices" : [ 128, 137 ],
      "id_str" : "123096209",
      "id" : 123096209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/9KzhJoYkUL",
      "expanded_url" : "http:\/\/wp.me\/p3gt4l-LI",
      "display_url" : "wp.me\/p3gt4l-LI"
    } ]
  },
  "geo" : { },
  "id_str" : "530047483398066176",
  "text" : "RT @JenLucPiquant: Wrong But Not Stupid, or, How to Call Out Mistakes without Trampling the Mistaken http:\/\/t.co\/9KzhJoYkUL via @benorlin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Orlin",
        "screen_name" : "benorlin",
        "indices" : [ 109, 118 ],
        "id_str" : "123096209",
        "id" : 123096209
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/9KzhJoYkUL",
        "expanded_url" : "http:\/\/wp.me\/p3gt4l-LI",
        "display_url" : "wp.me\/p3gt4l-LI"
      } ]
    },
    "geo" : { },
    "id_str" : "530044013135417344",
    "text" : "Wrong But Not Stupid, or, How to Call Out Mistakes without Trampling the Mistaken http:\/\/t.co\/9KzhJoYkUL via @benorlin",
    "id" : 530044013135417344,
    "created_at" : "2014-11-05 17:08:35 +0000",
    "user" : {
      "name" : "Jennifer Ouellette",
      "screen_name" : "JenLucPiquant",
      "protected" : false,
      "id_str" : "128292609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525328824133636096\/85rXVsFk_normal.jpeg",
      "id" : 128292609,
      "verified" : true
    }
  },
  "id" : 530047483398066176,
  "created_at" : "2014-11-05 17:22:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235177728968, 8.62746951475343 ]
  },
  "id_str" : "530020762175148033",
  "text" : "TIL: You should move your TeX installation before upgrading to Yosemite. Too bad I learnt that after starting the update\u2026",
  "id" : 530020762175148033,
  "created_at" : "2014-11-05 15:36:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mendeley Support",
      "screen_name" : "MendeleySupport",
      "indices" : [ 0, 16 ],
      "id_str" : "36346494",
      "id" : 36346494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "530019741432168448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18112603795121, 8.619971083153647 ]
  },
  "id_str" : "530020466850025472",
  "in_reply_to_user_id" : 36346494,
  "text" : "@MendeleySupport thanks, just sent it out. :-)",
  "id" : 530020466850025472,
  "in_reply_to_status_id" : 530019741432168448,
  "created_at" : "2014-11-05 15:35:01 +0000",
  "in_reply_to_screen_name" : "MendeleySupport",
  "in_reply_to_user_id_str" : "36346494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VickySchneider",
      "screen_name" : "MVickySchneider",
      "indices" : [ 0, 16 ],
      "id_str" : "991600273",
      "id" : 991600273
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 17, 27 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "TGAC",
      "screen_name" : "GenomeAnalysis",
      "indices" : [ 28, 43 ],
      "id_str" : "741221534082183168",
      "id" : 741221534082183168
    }, {
      "name" : "Bernardo Clavijo",
      "screen_name" : "bjclavijo",
      "indices" : [ 44, 54 ],
      "id_str" : "14884989",
      "id" : 14884989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529993684784545792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723384921042, 8.627572236710563 ]
  },
  "id_str" : "529997388346572801",
  "in_reply_to_user_id" : 991600273,
  "text" : "@MVickySchneider @blahah404 @GenomeAnalysis @bjclavijo thanks, took down the date :-)",
  "id" : 529997388346572801,
  "in_reply_to_status_id" : 529993684784545792,
  "created_at" : "2014-11-05 14:03:18 +0000",
  "in_reply_to_screen_name" : "MVickySchneider",
  "in_reply_to_user_id_str" : "991600273",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Moore",
      "screen_name" : "peromhc",
      "indices" : [ 0, 8 ],
      "id_str" : "4302347242",
      "id" : 4302347242
    }, {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 9, 22 ],
      "id_str" : "216793572",
      "id" : 216793572
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 69, 81 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529982319411884032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234556987943, 8.627551405750927 ]
  },
  "id_str" : "529992045960892416",
  "in_reply_to_user_id" : 11824072,
  "text" : "@PeroMHC @assemblathon Sounds great, I enjoyed reading the papers by @ctitusbrown so far ;)",
  "id" : 529992045960892416,
  "in_reply_to_status_id" : 529982319411884032,
  "created_at" : "2014-11-05 13:42:05 +0000",
  "in_reply_to_screen_name" : "macmanes",
  "in_reply_to_user_id_str" : "11824072",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529984159352373248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234556987943, 8.627551405750927 ]
  },
  "id_str" : "529991957582741505",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman thanks, I will look into it!",
  "id" : 529991957582741505,
  "in_reply_to_status_id" : 529984159352373248,
  "created_at" : "2014-11-05 13:41:44 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "TGAC",
      "screen_name" : "GenomeAnalysis",
      "indices" : [ 11, 26 ],
      "id_str" : "741221534082183168",
      "id" : 741221534082183168
    }, {
      "name" : "Bernardo Clavijo",
      "screen_name" : "bjclavijo",
      "indices" : [ 27, 37 ],
      "id_str" : "14884989",
      "id" : 14884989
    }, {
      "name" : "VickySchneider",
      "screen_name" : "MVickySchneider",
      "indices" : [ 38, 54 ],
      "id_str" : "991600273",
      "id" : 991600273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529983524116639744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234556987943, 8.627551405750927 ]
  },
  "id_str" : "529991927132090368",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @GenomeAnalysis @bjclavijo @MVickySchneider thanks, are there already plans when it will take place again?",
  "id" : 529991927132090368,
  "in_reply_to_status_id" : 529983524116639744,
  "created_at" : "2014-11-05 13:41:36 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CoauthorRoles",
      "indices" : [ 23, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/fqKw3mBH0G",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/101760336638\/when-my-pi-puts-me-as-second-author-instead",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/101760336\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529932751240445952",
  "text" : "http:\/\/t.co\/fqKw3mBH0G #CoauthorRoles",
  "id" : 529932751240445952,
  "created_at" : "2014-11-05 09:46:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529888736201289730",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236615098808, 8.627567876232277 ]
  },
  "id_str" : "529922779324628992",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann congrats!",
  "id" : 529922779324628992,
  "in_reply_to_status_id" : 529888736201289730,
  "created_at" : "2014-11-05 09:06:50 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529920571954696192",
  "text" : "\u00ABthe main door is repaired and you can enter again the biologicum on the weekend uncomplicated.\u00BB finally!",
  "id" : 529920571954696192,
  "created_at" : "2014-11-05 08:58:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529907868687171584",
  "text" : "\u00ABIch hab geh\u00F6rt wir haben morgen wieder die Ehre von dir unterrichtet zu werden. Du wusstest davon noch nichts, oder?\u00BB",
  "id" : 529907868687171584,
  "created_at" : "2014-11-05 08:07:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/WKyfBbKDdY",
      "expanded_url" : "http:\/\/images4.fanpop.com\/image\/photos\/16100000\/PJ-Harvey-Bjork-and-Tori-Amos-1-pj-harvey-16194825-370-440.jpg",
      "display_url" : "images4.fanpop.com\/image\/photos\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "529773105296596994",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152150892, 8.7504111819 ]
  },
  "id_str" : "529778754713710593",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy http:\/\/t.co\/WKyfBbKDdY",
  "id" : 529778754713710593,
  "in_reply_to_status_id" : 529773105296596994,
  "created_at" : "2014-11-04 23:34:32 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529745971643961344",
  "geo" : { },
  "id_str" : "529746428537892865",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann in person, Europe but willing to travel, focus on smallish (Mbp, not Gbp) eukaryotes preferred.",
  "id" : 529746428537892865,
  "in_reply_to_status_id" : 529745971643961344,
  "created_at" : "2014-11-04 21:26:05 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "indices" : [ 3, 13 ],
      "id_str" : "347340056",
      "id" : 347340056
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sexletterchallenge",
      "indices" : [ 95, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/A8RVMnDKw1",
      "expanded_url" : "http:\/\/sexlettersproject.tumblr.com\/post\/100790439009\/promises-from-your-older-self-kristens-letter",
      "display_url" : "sexlettersproject.tumblr.com\/post\/100790439\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529745689304399872",
  "text" : "RT @vortacist: What would you tell your teen self about sex? Read my letter then submit yours! #sexletterchallenge http:\/\/t.co\/A8RVMnDKw1 v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pleasure Pie",
        "screen_name" : "PleasurePie",
        "indices" : [ 127, 139 ],
        "id_str" : "2786245794",
        "id" : 2786245794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sexletterchallenge",
        "indices" : [ 80, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/A8RVMnDKw1",
        "expanded_url" : "http:\/\/sexlettersproject.tumblr.com\/post\/100790439009\/promises-from-your-older-self-kristens-letter",
        "display_url" : "sexlettersproject.tumblr.com\/post\/100790439\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529738167411556352",
    "text" : "What would you tell your teen self about sex? Read my letter then submit yours! #sexletterchallenge http:\/\/t.co\/A8RVMnDKw1 via @PleasurePie",
    "id" : 529738167411556352,
    "created_at" : "2014-11-04 20:53:15 +0000",
    "user" : {
      "name" : "Kit Stubbs, Ph.D.",
      "screen_name" : "vortacist",
      "protected" : false,
      "id_str" : "347340056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/819220259148177408\/UYT71cyh_normal.jpg",
      "id" : 347340056,
      "verified" : false
    }
  },
  "id" : 529745689304399872,
  "created_at" : "2014-11-04 21:23:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529744098522333184",
  "text" : "Hey lazy science web: Does anyone have recommendations for workshops\/courses on NGS &amp; (de novo) assembly?",
  "id" : 529744098522333184,
  "created_at" : "2014-11-04 21:16:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mac cowell",
      "screen_name" : "100ideas",
      "indices" : [ 3, 12 ],
      "id_str" : "1656891",
      "id" : 1656891
    }, {
      "name" : "Chai Biotechnologies",
      "screen_name" : "openqpcr",
      "indices" : [ 35, 44 ],
      "id_str" : "1606373324",
      "id" : 1606373324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/eY5TLj2tDW",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/chaibio\/open-qpcr-dna-diagnostics-for-everyone",
      "display_url" : "kickstarter.com\/projects\/chaib\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529738386467479553",
  "text" : "RT @100ideas: Back this! At $1400, @openqpcr is 10x less expensive, 100x easier, &amp; infinitely more open! https:\/\/t.co\/eY5TLj2tDW http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chai Biotechnologies",
        "screen_name" : "openqpcr",
        "indices" : [ 21, 30 ],
        "id_str" : "1606373324",
        "id" : 1606373324
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/100ideas\/status\/529685017082208256\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/JtbhDGx7TN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1nRrDzCYAAQ0ae.jpg",
        "id_str" : "529684968876695552",
        "id" : 529684968876695552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1nRrDzCYAAQ0ae.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/JtbhDGx7TN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/eY5TLj2tDW",
        "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/chaibio\/open-qpcr-dna-diagnostics-for-everyone",
        "display_url" : "kickstarter.com\/projects\/chaib\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529685017082208256",
    "text" : "Back this! At $1400, @openqpcr is 10x less expensive, 100x easier, &amp; infinitely more open! https:\/\/t.co\/eY5TLj2tDW http:\/\/t.co\/JtbhDGx7TN",
    "id" : 529685017082208256,
    "created_at" : "2014-11-04 17:22:03 +0000",
    "user" : {
      "name" : "mac cowell",
      "screen_name" : "100ideas",
      "protected" : false,
      "id_str" : "1656891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/73189865\/DIYbio_Cowell1-big-square_normal.jpg",
      "id" : 1656891,
      "verified" : false
    }
  },
  "id" : 529738386467479553,
  "created_at" : "2014-11-04 20:54:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/ejc3CTiYGB",
      "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2014\/10\/29\/bioinformatics.btu721.short",
      "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529670040531263488",
  "text" : "TIPP:Taxonomic Identification and Phylogenetic Profiling http:\/\/t.co\/ejc3CTiYGB",
  "id" : 529670040531263488,
  "created_at" : "2014-11-04 16:22:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mendeley Support",
      "screen_name" : "MendeleySupport",
      "indices" : [ 59, 75 ],
      "id_str" : "36346494",
      "id" : 36346494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529668683782950912",
  "text" : "Uhm, am I doing something wrong that tags added on the iOS @MendeleySupport app aren\u2019t synced back?",
  "id" : 529668683782950912,
  "created_at" : "2014-11-04 16:17:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 8, 21 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529661926008446977",
  "geo" : { },
  "id_str" : "529662120607379456",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @Naturalismus mein Eindruck bislang war das es generell lohnenswert ist in solchen F\u00E4llen die \u2018Heimatsprache\u2019 anzusehen.",
  "id" : 529662120607379456,
  "in_reply_to_status_id" : 529661926008446977,
  "created_at" : "2014-11-04 15:51:04 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 8, 21 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529659322448773120",
  "geo" : { },
  "id_str" : "529661309911314432",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @Naturalismus Bei in .de heimischen Arten oder allgemein?",
  "id" : 529661309911314432,
  "in_reply_to_status_id" : 529659322448773120,
  "created_at" : "2014-11-04 15:47:51 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Lindsay Waldrop",
      "screen_name" : "invertenerd",
      "indices" : [ 3, 15 ],
      "id_str" : "407476898",
      "id" : 407476898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529650384747659264",
  "text" : "RT @invertenerd: At the very least, I wish that flying a flag of math ignorance wasn't celebrated in biology. It's not something to be prou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529647682604646400",
    "text" : "At the very least, I wish that flying a flag of math ignorance wasn't celebrated in biology. It's not something to be proud of, people.",
    "id" : 529647682604646400,
    "created_at" : "2014-11-04 14:53:42 +0000",
    "user" : {
      "name" : "Dr Lindsay Waldrop",
      "screen_name" : "invertenerd",
      "protected" : false,
      "id_str" : "407476898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2280960080\/uvhx01c8ge960myeti8l_normal.jpeg",
      "id" : 407476898,
      "verified" : false
    }
  },
  "id" : 529650384747659264,
  "created_at" : "2014-11-04 15:04:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/MkbotdudJx",
      "expanded_url" : "http:\/\/www.nybooks.com\/articles\/archives\/2014\/nov\/20\/why-innocent-people-plead-guilty\/",
      "display_url" : "nybooks.com\/articles\/archi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234571449931, 8.627464243297664 ]
  },
  "id_str" : "529648871463743488",
  "text" : "Why Innocent People Plead Guilty http:\/\/t.co\/MkbotdudJx",
  "id" : 529648871463743488,
  "created_at" : "2014-11-04 14:58:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 3, 17 ],
      "id_str" : "48966898",
      "id" : 48966898
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 36, 48 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Ben Langmead",
      "screen_name" : "BenLangmead",
      "indices" : [ 49, 61 ],
      "id_str" : "296300255",
      "id" : 296300255
    }, {
      "name" : "Josh Quick",
      "screen_name" : "Scalene",
      "indices" : [ 62, 70 ],
      "id_str" : "20441966",
      "id" : 20441966
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 71, 87 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Illumina",
      "screen_name" : "illumina",
      "indices" : [ 88, 97 ],
      "id_str" : "46145761",
      "id" : 46145761
    }, {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 102, 109 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529604474470662144",
  "text" : "RT @lexnederbragt: In which I thank @ctitusbrown @BenLangmead @Scalene @pathogenomenick @illumina and @PacBio for helping my course http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Titus Brown",
        "screen_name" : "ctitusbrown",
        "indices" : [ 17, 29 ],
        "id_str" : "26616462",
        "id" : 26616462
      }, {
        "name" : "Ben Langmead",
        "screen_name" : "BenLangmead",
        "indices" : [ 30, 42 ],
        "id_str" : "296300255",
        "id" : 296300255
      }, {
        "name" : "Josh Quick",
        "screen_name" : "Scalene",
        "indices" : [ 43, 51 ],
        "id_str" : "20441966",
        "id" : 20441966
      }, {
        "name" : "Nick Loman",
        "screen_name" : "pathogenomenick",
        "indices" : [ 52, 68 ],
        "id_str" : "85906238",
        "id" : 85906238
      }, {
        "name" : "Illumina",
        "screen_name" : "illumina",
        "indices" : [ 69, 78 ],
        "id_str" : "46145761",
        "id" : 46145761
      }, {
        "name" : "PacBio",
        "screen_name" : "PacBio",
        "indices" : [ 83, 90 ],
        "id_str" : "39694489",
        "id" : 39694489
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/0KbgX5FfBJ",
        "expanded_url" : "http:\/\/flxlexblog.wordpress.com\/2014\/11\/04\/on-the-benefits-of-open-for-teaching\/",
        "display_url" : "flxlexblog.wordpress.com\/2014\/11\/04\/on-\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "529591144951607296",
    "geo" : { },
    "id_str" : "529591527602130945",
    "in_reply_to_user_id" : 48966898,
    "text" : "In which I thank @ctitusbrown @BenLangmead @Scalene @pathogenomenick @illumina and @PacBio for helping my course http:\/\/t.co\/0KbgX5FfBJ",
    "id" : 529591527602130945,
    "in_reply_to_status_id" : 529591144951607296,
    "created_at" : "2014-11-04 11:10:34 +0000",
    "in_reply_to_screen_name" : "lexnederbragt",
    "in_reply_to_user_id_str" : "48966898",
    "user" : {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "protected" : false,
      "id_str" : "48966898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099225219\/DSC01628a_normal.jpg",
      "id" : 48966898,
      "verified" : false
    }
  },
  "id" : 529604474470662144,
  "created_at" : "2014-11-04 12:02:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/sZX5ewN73r",
      "expanded_url" : "http:\/\/www.replicatedtypo.com\/how-to-speak-stone-age-bullshit\/9506.html",
      "display_url" : "replicatedtypo.com\/how-to-speak-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529592004041506816",
  "text" : "How to Speak Stone-Age Bullshit http:\/\/t.co\/sZX5ewN73r",
  "id" : 529592004041506816,
  "created_at" : "2014-11-04 11:12:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529584890661330944",
  "geo" : { },
  "id_str" : "529586653644750848",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy quicktime player :3",
  "id" : 529586653644750848,
  "in_reply_to_status_id" : 529584890661330944,
  "created_at" : "2014-11-04 10:51:12 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529569744048107520",
  "text" : "\u00ABN\u00E4chstes Jahr laufen wir den Staffelmarathon dann zu zweit. Ich mach die 11 und die 7 km Strecken und du den Rest.\u00BB",
  "id" : 529569744048107520,
  "created_at" : "2014-11-04 09:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Motherboard",
      "screen_name" : "motherboard",
      "indices" : [ 3, 15 ],
      "id_str" : "56510427",
      "id" : 56510427
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/motherboard\/status\/529349820964548609\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/5h2tPe0wY2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1ie_CcCAAE9ocV.jpg",
      "id_str" : "529347762039422977",
      "id" : 529347762039422977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1ie_CcCAAE9ocV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 732
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 732
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 732
      } ],
      "display_url" : "pic.twitter.com\/5h2tPe0wY2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/R6eYPau0tx",
      "expanded_url" : "http:\/\/bit.ly\/1A5Zhlf",
      "display_url" : "bit.ly\/1A5Zhlf"
    } ]
  },
  "geo" : { },
  "id_str" : "529414347689586688",
  "text" : "RT @motherboard: Why we still want Laika the space dog to come home: http:\/\/t.co\/R6eYPau0tx http:\/\/t.co\/5h2tPe0wY2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/motherboard\/status\/529349820964548609\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/5h2tPe0wY2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1ie_CcCAAE9ocV.jpg",
        "id_str" : "529347762039422977",
        "id" : 529347762039422977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1ie_CcCAAE9ocV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 732
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 732
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 732
        } ],
        "display_url" : "pic.twitter.com\/5h2tPe0wY2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/R6eYPau0tx",
        "expanded_url" : "http:\/\/bit.ly\/1A5Zhlf",
        "display_url" : "bit.ly\/1A5Zhlf"
      } ]
    },
    "geo" : { },
    "id_str" : "529349820964548609",
    "text" : "Why we still want Laika the space dog to come home: http:\/\/t.co\/R6eYPau0tx http:\/\/t.co\/5h2tPe0wY2",
    "id" : 529349820964548609,
    "created_at" : "2014-11-03 19:10:06 +0000",
    "user" : {
      "name" : "Motherboard",
      "screen_name" : "motherboard",
      "protected" : false,
      "id_str" : "56510427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827207967799930880\/ZNgndgEm_normal.jpg",
      "id" : 56510427,
      "verified" : true
    }
  },
  "id" : 529414347689586688,
  "created_at" : "2014-11-03 23:26:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 113, 125 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529413535135440896",
  "text" : "RT @pjacock: \"the whole concept that biologists can avoid math or computing in their training ... needs to die\", @ctitusbrown: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Titus Brown",
        "screen_name" : "ctitusbrown",
        "indices" : [ 100, 112 ],
        "id_str" : "26616462",
        "id" : 26616462
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/VyCKf3ufxn",
        "expanded_url" : "http:\/\/ivory.idyll.org\/blog\/2014-doing-biology-however-it-needs-to-be-done.html",
        "display_url" : "ivory.idyll.org\/blog\/2014-doin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529346159928963073",
    "text" : "\"the whole concept that biologists can avoid math or computing in their training ... needs to die\", @ctitusbrown: http:\/\/t.co\/VyCKf3ufxn",
    "id" : 529346159928963073,
    "created_at" : "2014-11-03 18:55:33 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 529413535135440896,
  "created_at" : "2014-11-03 23:23:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/dhjLpI7CAT",
      "expanded_url" : "http:\/\/www.fastcoexist.com\/3037843\/heres-what-happens-when-a-school-pays-its-teachers-a-lot-lot-more-money",
      "display_url" : "fastcoexist.com\/3037843\/heres-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234406497495, 8.627528849565053 ]
  },
  "id_str" : "529321823532773378",
  "text" : "What Happens When A School Pays Its Teachers A Lot, Lot More Money http:\/\/t.co\/dhjLpI7CAT",
  "id" : 529321823532773378,
  "created_at" : "2014-11-03 17:18:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/GGyLQ8dHmr",
      "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2014\/10\/22\/bioinformatics.btu661.short",
      "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529308233937477632",
  "text" : "\u00ABA5-miseq can produce high quality microbial genome assemblies on a laptop\u00BB Working with prokaryotes must be nice http:\/\/t.co\/GGyLQ8dHmr",
  "id" : 529308233937477632,
  "created_at" : "2014-11-03 16:24:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529302204621283328",
  "geo" : { },
  "id_str" : "529302314814029824",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer gratz!",
  "id" : 529302314814029824,
  "in_reply_to_status_id" : 529302204621283328,
  "created_at" : "2014-11-03 16:01:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "indices" : [ 3, 12 ],
      "id_str" : "185910976",
      "id" : 185910976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/57eqQvipBM",
      "expanded_url" : "http:\/\/buff.ly\/1GcG2ag",
      "display_url" : "buff.ly\/1GcG2ag"
    } ]
  },
  "geo" : { },
  "id_str" : "529254337902809089",
  "text" : "RT @hollybik: A Teenager Gets Grilled By Her Dad About Why She\u2019s Not That Into Coding \u2014 Matter \u2014 Medium http:\/\/t.co\/57eqQvipBM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/57eqQvipBM",
        "expanded_url" : "http:\/\/buff.ly\/1GcG2ag",
        "display_url" : "buff.ly\/1GcG2ag"
      } ]
    },
    "geo" : { },
    "id_str" : "529253161488617472",
    "text" : "A Teenager Gets Grilled By Her Dad About Why She\u2019s Not That Into Coding \u2014 Matter \u2014 Medium http:\/\/t.co\/57eqQvipBM",
    "id" : 529253161488617472,
    "created_at" : "2014-11-03 12:46:01 +0000",
    "user" : {
      "name" : "Holly Bik",
      "screen_name" : "hollybik",
      "protected" : false,
      "id_str" : "185910976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753203361848188928\/lnfaIldf_normal.jpg",
      "id" : 185910976,
      "verified" : false
    }
  },
  "id" : 529254337902809089,
  "created_at" : "2014-11-03 12:50:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/04yWSsNlcu",
      "expanded_url" : "http:\/\/bitsandbugs.org\/2014\/11\/02\/thoughts-on-bioinformatics-as-wet-lab-kits\/",
      "display_url" : "bitsandbugs.org\/2014\/11\/02\/tho\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172354, 8.627459 ]
  },
  "id_str" : "529232728961863681",
  "text" : "Thoughts on bioinformatics as wet-lab kits http:\/\/t.co\/04yWSsNlcu",
  "id" : 529232728961863681,
  "created_at" : "2014-11-03 11:24:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529226735389536257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233217872106, 8.627520238009174 ]
  },
  "id_str" : "529226935415885824",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Leider hat Super Eraser erst am Samstag Zeit daf\u00FCr ;-)",
  "id" : 529226935415885824,
  "in_reply_to_status_id" : 529226735389536257,
  "created_at" : "2014-11-03 11:01:48 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "529225150873743360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233191958906, 8.627523993755554 ]
  },
  "id_str" : "529226152901365760",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich all your color will be lost in no time, like tears in the rain!",
  "id" : 529226152901365760,
  "in_reply_to_status_id" : 529225150873743360,
  "created_at" : "2014-11-03 10:58:42 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18067952976164, 8.61994026177373 ]
  },
  "id_str" : "529223286413352960",
  "text" : "Tired? Me? Never! By accident I nearly drank the whiteboard cleaner instead of my coffee\u2026",
  "id" : 529223286413352960,
  "created_at" : "2014-11-03 10:47:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529206119471001600",
  "text" : "Bioinformatics workflow: discover promising sounding tool -&gt; download -&gt; fails to run -&gt; fix bugs -&gt; send pull request -&gt; try the tool",
  "id" : 529206119471001600,
  "created_at" : "2014-11-03 09:39:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JqmuVgVmu8",
      "expanded_url" : "http:\/\/boingboing.net\/2014\/11\/02\/uk-cultural-institutions-leave.html",
      "display_url" : "boingboing.net\/2014\/11\/02\/uk-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529194645323272192",
  "text" : "UK cultural institutions leave their WWI cases empty to protest insane\u00A0copyright http:\/\/t.co\/JqmuVgVmu8",
  "id" : 529194645323272192,
  "created_at" : "2014-11-03 08:53:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/eMYkmDctB1",
      "expanded_url" : "http:\/\/instagram.com\/p\/u6p8rgBwsV\/",
      "display_url" : "instagram.com\/p\/u6p8rgBwsV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "529058792005046272",
  "text" : "Dinosaurs in Space http:\/\/t.co\/eMYkmDctB1",
  "id" : 529058792005046272,
  "created_at" : "2014-11-02 23:53:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leucine Rich Bio",
      "screen_name" : "LeucineRichBio",
      "indices" : [ 3, 18 ],
      "id_str" : "434875052",
      "id" : 434875052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/gDmwXPSSrI",
      "expanded_url" : "http:\/\/nsaunders.wordpress.com\/2014\/10\/30\/create-your-own-gene-ids-no-wait-dont\/",
      "display_url" : "nsaunders.wordpress.com\/2014\/10\/30\/cre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529057456715214848",
  "text" : "RT @LeucineRichBio: Create your own gene IDs! No wait. Don\u2019t. http:\/\/t.co\/gDmwXPSSrI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/gDmwXPSSrI",
        "expanded_url" : "http:\/\/nsaunders.wordpress.com\/2014\/10\/30\/create-your-own-gene-ids-no-wait-dont\/",
        "display_url" : "nsaunders.wordpress.com\/2014\/10\/30\/cre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529047856460886018",
    "text" : "Create your own gene IDs! No wait. Don\u2019t. http:\/\/t.co\/gDmwXPSSrI",
    "id" : 529047856460886018,
    "created_at" : "2014-11-02 23:10:12 +0000",
    "user" : {
      "name" : "Leucine Rich Bio",
      "screen_name" : "LeucineRichBio",
      "protected" : false,
      "id_str" : "434875052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758354770432106496\/9VhuRBEI_normal.jpg",
      "id" : 434875052,
      "verified" : false
    }
  },
  "id" : 529057456715214848,
  "created_at" : "2014-11-02 23:48:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 3, 19 ],
      "id_str" : "15626406",
      "id" : 15626406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528994219160260608",
  "text" : "RT @michael_nielsen: This article is too cautious to say it, but implicitly it says: the # 1 cause of ADHD is that schools are boring http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/RSdM0m9UmC",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/11\/02\/opinion\/sunday\/a-natural-fix-for-adhd.html",
        "display_url" : "nytimes.com\/2014\/11\/02\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528903086551490560",
    "text" : "This article is too cautious to say it, but implicitly it says: the # 1 cause of ADHD is that schools are boring http:\/\/t.co\/RSdM0m9UmC",
    "id" : 528903086551490560,
    "created_at" : "2014-11-02 13:34:57 +0000",
    "user" : {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "protected" : false,
      "id_str" : "15626406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2756243281\/6d3d0ade1bd4364b75d7d0151dce38e5_normal.png",
      "id" : 15626406,
      "verified" : false
    }
  },
  "id" : 528994219160260608,
  "created_at" : "2014-11-02 19:37:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "indices" : [ 3, 9 ],
      "id_str" : "15276911",
      "id" : 15276911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetmovieplot",
      "indices" : [ 106, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528989530633035776",
  "text" : "RT @iddux: Blade Runner: poor performance of binary classification algorithms requires constant patching. #tweetmovieplot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tweetmovieplot",
        "indices" : [ 95, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528937142677164032",
    "text" : "Blade Runner: poor performance of binary classification algorithms requires constant patching. #tweetmovieplot",
    "id" : 528937142677164032,
    "created_at" : "2014-11-02 15:50:16 +0000",
    "user" : {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "protected" : false,
      "id_str" : "15276911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893496089013174272\/l628-eyh_normal.jpg",
      "id" : 15276911,
      "verified" : false
    }
  },
  "id" : 528989530633035776,
  "created_at" : "2014-11-02 19:18:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/1eymiJqTRi",
      "expanded_url" : "https:\/\/vine.co\/v\/OOXUKvtUdQT",
      "display_url" : "vine.co\/v\/OOXUKvtUdQT"
    } ]
  },
  "geo" : { },
  "id_str" : "528960513968209920",
  "text" : "Wuff https:\/\/t.co\/1eymiJqTRi",
  "id" : 528960513968209920,
  "created_at" : "2014-11-02 17:23:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11109141140949, 8.752360380847065 ]
  },
  "id_str" : "528874037943238656",
  "text" : "\u00ABIch werde bald Sexarbeiterin. Oder mache PR im \u00F6ffentlichen Dienst. Ich wei\u00DF noch nicht so genau.\u00BB",
  "id" : 528874037943238656,
  "created_at" : "2014-11-02 11:39:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/pydveq2FpD",
      "expanded_url" : "http:\/\/instagram.com\/p\/u4B_n-BwjV\/",
      "display_url" : "instagram.com\/p\/u4B_n-BwjV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "528689455767777280",
  "text" : "Diese Mainzer. Wie die Lachen. Und wie die Leben. http:\/\/t.co\/pydveq2FpD",
  "id" : 528689455767777280,
  "created_at" : "2014-11-01 23:26:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atul Butte",
      "screen_name" : "atulbutte",
      "indices" : [ 3, 13 ],
      "id_str" : "262365030",
      "id" : 262365030
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "basf14",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528684596066799616",
  "text" : "RT @atulbutte: Teaching toddlers about oligonucleotide synthesis... with beads! Wish it were this easy in real life! #basf14 http:\/\/t.co\/hI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/atulbutte\/status\/528660935331049472\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/hI2uauWX6a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1YuT1yIUAACGhv.jpg",
        "id_str" : "528660924652343296",
        "id" : 528660924652343296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1YuT1yIUAACGhv.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/hI2uauWX6a"
      } ],
      "hashtags" : [ {
        "text" : "basf14",
        "indices" : [ 102, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528660935331049472",
    "text" : "Teaching toddlers about oligonucleotide synthesis... with beads! Wish it were this easy in real life! #basf14 http:\/\/t.co\/hI2uauWX6a",
    "id" : 528660935331049472,
    "created_at" : "2014-11-01 21:32:43 +0000",
    "user" : {
      "name" : "Atul Butte",
      "screen_name" : "atulbutte",
      "protected" : false,
      "id_str" : "262365030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685703528526950400\/C_EwTgXo_normal.jpg",
      "id" : 262365030,
      "verified" : true
    }
  },
  "id" : 528684596066799616,
  "created_at" : "2014-11-01 23:06:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Icoiypfa0H",
      "expanded_url" : "http:\/\/cryptogenomicon.wordpress.com\/2014\/11\/01\/high-throughput-sequencing-for-neuroscience\/",
      "display_url" : "cryptogenomicon.wordpress.com\/2014\/11\/01\/hig\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528683572744699906",
  "text" : "RT @pjacock: \u201Cdata analysis skills \u2026 must be acquired by biologists, \u2026\u201D http:\/\/t.co\/Icoiypfa0H future of #bioinformatics from Sean Eddy @cr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Eddy",
        "screen_name" : "cryptogenomicon",
        "indices" : [ 123, 139 ],
        "id_str" : "894893826531356672",
        "id" : 894893826531356672
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/Icoiypfa0H",
        "expanded_url" : "http:\/\/cryptogenomicon.wordpress.com\/2014\/11\/01\/high-throughput-sequencing-for-neuroscience\/",
        "display_url" : "cryptogenomicon.wordpress.com\/2014\/11\/01\/hig\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528657944603545600",
    "text" : "\u201Cdata analysis skills \u2026 must be acquired by biologists, \u2026\u201D http:\/\/t.co\/Icoiypfa0H future of #bioinformatics from Sean Eddy @cryptogenomicon",
    "id" : 528657944603545600,
    "created_at" : "2014-11-01 21:20:50 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 528683572744699906,
  "created_at" : "2014-11-01 23:02:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "die_krabbe",
      "screen_name" : "die_krabbe",
      "indices" : [ 0, 11 ],
      "id_str" : "8991502",
      "id" : 8991502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528656938247417856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11521911621092, 8.75038146972656 ]
  },
  "id_str" : "528679864443109376",
  "in_reply_to_user_id" : 8991502,
  "text" : "@die_krabbe dunno, procrastinated reading the article.",
  "id" : 528679864443109376,
  "in_reply_to_status_id" : 528656938247417856,
  "created_at" : "2014-11-01 22:47:56 +0000",
  "in_reply_to_screen_name" : "die_krabbe",
  "in_reply_to_user_id_str" : "8991502",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528653240003739648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11521911616772, 8.750381469718938 ]
  },
  "id_str" : "528654812100182017",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks great, thanks a lot!",
  "id" : 528654812100182017,
  "in_reply_to_status_id" : 528653240003739648,
  "created_at" : "2014-11-01 21:08:23 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528652251842498561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11521900607438, 8.750381450290702 ]
  },
  "id_str" : "528652744241209344",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks thanks for writing it. :-) btw. do you already have more details on the sage conf in paris?",
  "id" : 528652744241209344,
  "in_reply_to_status_id" : 528652251842498561,
  "created_at" : "2014-11-01 21:00:10 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1111095135, 8.7520373539 ]
  },
  "id_str" : "528651291351085056",
  "text" : "\u00ABWe could be happy with what we have.\u00BB \u2014 \u00ABOr we die of Ebola!\u00BB",
  "id" : 528651291351085056,
  "created_at" : "2014-11-01 20:54:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 99, 108 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/bJO5JINUbE",
      "expanded_url" : "http:\/\/del-fi.org\/post\/101425506916\/informed-consent-post-snowden",
      "display_url" : "del-fi.org\/post\/101425506\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528643680769675264",
  "text" : "\u00ABif we wait [\u2026], we can expect informed consent to get road-graded down to a one-click\u00BB Well done, @wilbanks http:\/\/t.co\/bJO5JINUbE",
  "id" : 528643680769675264,
  "created_at" : "2014-11-01 20:24:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528633350278221824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11424636836944, 8.750209808342769 ]
  },
  "id_str" : "528640800113328129",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez for us it\u2019s a huge topic when going for walks :)",
  "id" : 528640800113328129,
  "in_reply_to_status_id" : 528633350278221824,
  "created_at" : "2014-11-01 20:12:43 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/GPmghDBC3P",
      "expanded_url" : "http:\/\/lifehacker.com\/use-this-flowchart-to-identify-what-type-of-procrastina-1615614759?utm_content=buffer78741&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
      "display_url" : "lifehacker.com\/use-this-flowc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528635889552216064",
  "text" : "What Type of Procrastinator Are You? http:\/\/t.co\/GPmghDBC3P",
  "id" : 528635889552216064,
  "created_at" : "2014-11-01 19:53:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528633829356240897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1152192165118, 8.750381510714856 ]
  },
  "id_str" : "528635432985460737",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai das ist Offenbach, k\u00F6nnte auch ein ganz normaler Samstagabend sein.",
  "id" : 528635432985460737,
  "in_reply_to_status_id" : 528633829356240897,
  "created_at" : "2014-11-01 19:51:23 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11066598999998, 8.759447299999998 ]
  },
  "id_str" : "528633622895820800",
  "text" : "Der Br\u00FCckenabriss nebenan klingt so als w\u00E4re gerade Krieg ausgebrochen.",
  "id" : 528633622895820800,
  "created_at" : "2014-11-01 19:44:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 132, 138 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/6uULffBkq5",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/jsm.12734\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/js\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1110884813241, 8.75240919192671 ]
  },
  "id_str" : "528332914082447360",
  "text" : "Surprise: if you ask the internet about its sexuals fantasies then virtually every single one is common. http:\/\/t.co\/6uULffBkq5 \/cc @Lobot",
  "id" : 528332914082447360,
  "created_at" : "2014-10-31 23:49:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]