Grailbird.data.tweets_2017_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/Gveojd0tnC",
      "expanded_url" : "https:\/\/twitter.com\/DABaranger\/status\/892046987515879424",
      "display_url" : "twitter.com\/DABaranger\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11391484068344, 8.753058880659513 ]
  },
  "id_str" : "892073998724542464",
  "text" : "That's so awesome to see. All the best for the workshop! \uD83D\uDE0D https:\/\/t.co\/Gveojd0tnC",
  "id" : 892073998724542464,
  "created_at" : "2017-07-31 17:26:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 9, 21 ],
      "id_str" : "53560219",
      "id" : 53560219
    }, {
      "name" : "CitSci",
      "screen_name" : "CitSci",
      "indices" : [ 22, 29 ],
      "id_str" : "392328306",
      "id" : 392328306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890901832482074624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233643858307, 8.627524450689263 ]
  },
  "id_str" : "890921111277514752",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H @openscience @CitSci Word! Even in non-participatory science has that issue: half my lab wouldn't be allowed to work if it was citizen science ;)",
  "id" : 890921111277514752,
  "in_reply_to_status_id" : 890901832482074624,
  "created_at" : "2017-07-28 13:05:20 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 3, 12 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "ISMBECCB",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/QZYo2LKgsL",
      "expanded_url" : "https:\/\/medium.com\/p\/bosc-2017-day-2-part-3-keynote-bosc2017-ismbeccb-5a1598be50c4",
      "display_url" : "medium.com\/p\/bosc-2017-da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "890919578100019203",
  "text" : "RT @yoyehudi: I just published \u201CBOSC 2017 Day 2, Part 3: Keynote #BOSC2017 #ISMBECCB\u201D https:\/\/t.co\/QZYo2LKgsL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 51, 60 ]
      }, {
        "text" : "ISMBECCB",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/QZYo2LKgsL",
        "expanded_url" : "https:\/\/medium.com\/p\/bosc-2017-day-2-part-3-keynote-bosc2017-ismbeccb-5a1598be50c4",
        "display_url" : "medium.com\/p\/bosc-2017-da\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "890895212129779712",
    "text" : "I just published \u201CBOSC 2017 Day 2, Part 3: Keynote #BOSC2017 #ISMBECCB\u201D https:\/\/t.co\/QZYo2LKgsL",
    "id" : 890895212129779712,
    "created_at" : "2017-07-28 11:22:25 +0000",
    "user" : {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "protected" : false,
      "id_str" : "1073388199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905684496288243712\/tW_i_5Qt_normal.jpg",
      "id" : 1073388199,
      "verified" : false
    }
  },
  "id" : 890919578100019203,
  "created_at" : "2017-07-28 12:59:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roland Krause",
      "screen_name" : "spitshine",
      "indices" : [ 0, 10 ],
      "id_str" : "14567800",
      "id" : 14567800
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 11, 19 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890899936723783680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232390793752, 8.627533090556511 ]
  },
  "id_str" : "890900032471388161",
  "in_reply_to_user_id" : 14567800,
  "text" : "@spitshine @betatim the relevant question is: Did the authors notice?",
  "id" : 890900032471388161,
  "in_reply_to_status_id" : 890899936723783680,
  "created_at" : "2017-07-28 11:41:34 +0000",
  "in_reply_to_screen_name" : "spitshine",
  "in_reply_to_user_id_str" : "14567800",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890865031704739840",
  "geo" : { },
  "id_str" : "890870537613963264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer someone's early! That's a change! \uD83D\uDE02",
  "id" : 890870537613963264,
  "in_reply_to_status_id" : 890865031704739840,
  "created_at" : "2017-07-28 09:44:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/zh0Gjs72AL",
      "expanded_url" : "https:\/\/peerj.com\/preprints\/3100\/",
      "display_url" : "peerj.com\/preprints\/3100\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235881624894, 8.627504844770922 ]
  },
  "id_str" : "890860233526042625",
  "text" : "AI at work: Google Scholar highlights a new preprint I might want to read. Even though I\u2019m on the author list. \uD83E\uDD14 https:\/\/t.co\/zh0Gjs72AL",
  "id" : 890860233526042625,
  "created_at" : "2017-07-28 09:03:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sobel",
      "screen_name" : "JonathanSobel1",
      "indices" : [ 32, 47 ],
      "id_str" : "841497890",
      "id" : 841497890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/25nPsYLa72",
      "expanded_url" : "https:\/\/jonathansobel1.wordpress.com\/2017\/07\/27\/bosc-session-of-the-eccbismb-2017\/",
      "display_url" : "jonathansobel1.wordpress.com\/2017\/07\/27\/bos\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "889200101641650177",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1131551661805, 8.753827626737335 ]
  },
  "id_str" : "890821238238715904",
  "in_reply_to_user_id" : 14286491,
  "text" : "A nice recap about #BOSC2017 by @JonathanSobel1 https:\/\/t.co\/25nPsYLa72",
  "id" : 890821238238715904,
  "in_reply_to_status_id" : 889200101641650177,
  "created_at" : "2017-07-28 06:28:28 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B\u00E9r\u00E9nice Batut",
      "screen_name" : "bebatut",
      "indices" : [ 3, 11 ],
      "id_str" : "326034810",
      "id" : 326034810
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 77, 85 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 87, 103 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uLpSlKlEiS",
      "expanded_url" : "http:\/\/buff.ly\/2uBnan2",
      "display_url" : "buff.ly\/2uBnan2"
    } ]
  },
  "geo" : { },
  "id_str" : "890638145653317633",
  "text" : "RT @bebatut: \"Sci-Hub provides access to nearly all scholarly literature\" by @dhimmel, @gedankenstuecke and others \nhttps:\/\/t.co\/uLpSlKlEiS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Himmelstein",
        "screen_name" : "dhimmel",
        "indices" : [ 64, 72 ],
        "id_str" : "289107682",
        "id" : 289107682
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 74, 90 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/uLpSlKlEiS",
        "expanded_url" : "http:\/\/buff.ly\/2uBnan2",
        "display_url" : "buff.ly\/2uBnan2"
      } ]
    },
    "geo" : { },
    "id_str" : "890631274951450624",
    "text" : "\"Sci-Hub provides access to nearly all scholarly literature\" by @dhimmel, @gedankenstuecke and others \nhttps:\/\/t.co\/uLpSlKlEiS",
    "id" : 890631274951450624,
    "created_at" : "2017-07-27 17:53:37 +0000",
    "user" : {
      "name" : "B\u00E9r\u00E9nice Batut",
      "screen_name" : "bebatut",
      "protected" : false,
      "id_str" : "326034810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751067403749060608\/kx5PT9_z_normal.jpg",
      "id" : 326034810,
      "verified" : false
    }
  },
  "id" : 890638145653317633,
  "created_at" : "2017-07-27 18:20:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890506668387250176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234227533459, 8.627524767195991 ]
  },
  "id_str" : "890509681722085376",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick Thanks! \uD83D\uDC4D",
  "id" : 890509681722085376,
  "in_reply_to_status_id" : 890506668387250176,
  "created_at" : "2017-07-27 09:50:27 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clive G. Brown",
      "screen_name" : "Clive_G_Brown",
      "indices" : [ 0, 14 ],
      "id_str" : "1949299478",
      "id" : 1949299478
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 15, 31 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890502876426117121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235513136409, 8.62751136430603 ]
  },
  "id_str" : "890503081653415936",
  "in_reply_to_user_id" : 1949299478,
  "text" : "@Clive_G_Brown @pathogenomenick thanks for jumping in! You\u2019re right, I should have specified: longest, alignable read. :)",
  "id" : 890503081653415936,
  "in_reply_to_status_id" : 890502876426117121,
  "created_at" : "2017-07-27 09:24:14 +0000",
  "in_reply_to_screen_name" : "Clive_G_Brown",
  "in_reply_to_user_id_str" : "1949299478",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235513135122, 8.627511364310608 ]
  },
  "id_str" : "890501903557300224",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick what\u2019s the longest nanopore read you have documented on Twitter? Need a link for citation in my thesis :D",
  "id" : 890501903557300224,
  "created_at" : "2017-07-27 09:19:33 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890332808740253696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401053353509, 8.753343203417932 ]
  },
  "id_str" : "890353108253102080",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks \u201Egrabbing your healthcare quicker than your land\u201C sounds like catchy tagline\u2026",
  "id" : 890353108253102080,
  "in_reply_to_status_id" : 890332808740253696,
  "created_at" : "2017-07-26 23:28:17 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 0, 9 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890288890409570304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140129549334, 8.753348991948455 ]
  },
  "id_str" : "890292712724987904",
  "in_reply_to_user_id" : 1073388199,
  "text" : "@yoyehudi \u05DB\u05DF, \u05D0\u05DC\u05D4 \u05E1\u05D8\u05D9\u05E7\u05E8\u05D9\u05DD \u05D1\u05DB\u05DC \u05DE\u05E7\u05D5\u05DD! (Probably totally butchered this :p)",
  "id" : 890292712724987904,
  "in_reply_to_status_id" : 890288890409570304,
  "created_at" : "2017-07-26 19:28:18 +0000",
  "in_reply_to_screen_name" : "yoyehudi",
  "in_reply_to_user_id_str" : "1073388199",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 35, 45 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 46, 53 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 54, 62 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/890283218045476864\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/C2ISh1OJw0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFrr17TWAAEYfvh.jpg",
      "id_str" : "890283188043513857",
      "id" : 890283188043513857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFrr17TWAAEYfvh.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/C2ISh1OJw0"
    } ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401402856634, 8.753345122878857 ]
  },
  "id_str" : "890283218045476864",
  "text" : "I think we\u2019re all set for #mozfest @auremoser @sujaik @Seplute! https:\/\/t.co\/C2ISh1OJw0",
  "id" : 890283218045476864,
  "created_at" : "2017-07-26 18:50:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 15, 23 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Hanna Isotalus",
      "screen_name" : "hisotalus",
      "indices" : [ 24, 34 ],
      "id_str" : "1872245198",
      "id" : 1872245198
    }, {
      "name" : "Charles Oppenheim",
      "screen_name" : "CharlesOppenh",
      "indices" : [ 35, 49 ],
      "id_str" : "259625864",
      "id" : 259625864
    }, {
      "name" : "Mark Summers",
      "screen_name" : "maxhummus",
      "indices" : [ 50, 60 ],
      "id_str" : "2458019263",
      "id" : 2458019263
    }, {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 61, 73 ],
      "id_str" : "439273539",
      "id" : 439273539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890178216937345026",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232669666463, 8.627524620318718 ]
  },
  "id_str" : "890196168705290241",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @o_guest @hisotalus @CharlesOppenh @maxhummus @chartgerink Did Mr. Science-Trump already ask you to provide your birth certificate as well?",
  "id" : 890196168705290241,
  "in_reply_to_status_id" : 890178216937345026,
  "created_at" : "2017-07-26 13:04:40 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sobel",
      "screen_name" : "JonathanSobel1",
      "indices" : [ 0, 15 ],
      "id_str" : "841497890",
      "id" : 841497890
    }, {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 16, 22 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 146, 158 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890111773587779584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232861384164, 8.627526690866427 ]
  },
  "id_str" : "890112060905971712",
  "in_reply_to_user_id" : 841497890,
  "text" : "@JonathanSobel1 @heluc Thanks! Looking forward to read it! And hope you had a great time at #BOSC2017. Must have been the perfect town to present @beerdecoded ;)",
  "id" : 890112060905971712,
  "in_reply_to_status_id" : 890111773587779584,
  "created_at" : "2017-07-26 07:30:27 +0000",
  "in_reply_to_screen_name" : "JonathanSobel1",
  "in_reply_to_user_id_str" : "841497890",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Hackuarium",
      "screen_name" : "hackuarium",
      "indices" : [ 7, 18 ],
      "id_str" : "2418603105",
      "id" : 2418603105
    }, {
      "name" : "Beer DeCoded",
      "screen_name" : "beerdecoded",
      "indices" : [ 19, 31 ],
      "id_str" : "3295237359",
      "id" : 3295237359
    }, {
      "name" : "Jonathan Sobel",
      "screen_name" : "JonathanSobel1",
      "indices" : [ 50, 65 ],
      "id_str" : "841497890",
      "id" : 841497890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889912004139520000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246005532643, 8.627590311739269 ]
  },
  "id_str" : "890109720161333248",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @hackuarium @beerdecoded Really well done! @JonathanSobel1 did a great job presenting the project.",
  "id" : 890109720161333248,
  "in_reply_to_status_id" : 889912004139520000,
  "created_at" : "2017-07-26 07:21:09 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890094686752432128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234359324998, 8.62752378213832 ]
  },
  "id_str" : "890094922195492864",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn go for that website, comparative kandinskomics :p",
  "id" : 890094922195492864,
  "in_reply_to_status_id" : 890094686752432128,
  "created_at" : "2017-07-26 06:22:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890088727510487041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17214538335742, 8.62765471995296 ]
  },
  "id_str" : "890093296802041859",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn Limit down to rsid + allele?",
  "id" : 890093296802041859,
  "in_reply_to_status_id" : 890088727510487041,
  "created_at" : "2017-07-26 06:15:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890087755107184640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11432339256871, 8.747644407336818 ]
  },
  "id_str" : "890088456290017282",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn Next step: build a single serving site that is a gallery of all openSNP users :p",
  "id" : 890088456290017282,
  "in_reply_to_status_id" : 890087755107184640,
  "created_at" : "2017-07-26 05:56:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890087213035397121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388604533869, 8.75033332967083 ]
  },
  "id_str" : "890087444825223169",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Let me know if you want me to have a look and give feedback once you have a deck :)",
  "id" : 890087444825223169,
  "in_reply_to_status_id" : 890087213035397121,
  "created_at" : "2017-07-26 05:52:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/aknR37vgam",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/890086163591172097",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11379258711833, 8.751169173055096 ]
  },
  "id_str" : "890087243880202241",
  "text" : "Draw me like one of your Brassica species. \uD83D\uDE0D https:\/\/t.co\/aknR37vgam",
  "id" : 890087243880202241,
  "created_at" : "2017-07-26 05:51:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "890004597879717889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139429706319, 8.75347034825442 ]
  },
  "id_str" : "890086444114604032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Ah, good luck this Friday then! :)",
  "id" : 890086444114604032,
  "in_reply_to_status_id" : 890004597879717889,
  "created_at" : "2017-07-26 05:48:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886850548091244545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401703549502, 8.753352437167322 ]
  },
  "id_str" : "889980483626573825",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer How did go? :)",
  "id" : 889980483626573825,
  "in_reply_to_status_id" : 886850548091244545,
  "created_at" : "2017-07-25 22:47:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Greene",
      "screen_name" : "GreeneScientist",
      "indices" : [ 0, 16 ],
      "id_str" : "95233492",
      "id" : 95233492
    }, {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "indices" : [ 17, 30 ],
      "id_str" : "7841792",
      "id" : 7841792
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 31, 39 ],
      "id_str" : "289107682",
      "id" : 289107682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889967604906983424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401017927622, 8.753342326630408 ]
  },
  "id_str" : "889968362893258752",
  "in_reply_to_user_id" : 95233492,
  "text" : "@GreeneScientist @SteveMcLaugh @dhimmel that\u2019s even better: \u201EWe put the preprint up before we even followed each other on Twitter\u201C ;)",
  "id" : 889968362893258752,
  "in_reply_to_status_id" : 889967604906983424,
  "created_at" : "2017-07-25 21:59:27 +0000",
  "in_reply_to_screen_name" : "GreeneScientist",
  "in_reply_to_user_id_str" : "95233492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Greene",
      "screen_name" : "GreeneScientist",
      "indices" : [ 0, 16 ],
      "id_str" : "95233492",
      "id" : 95233492
    }, {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "indices" : [ 17, 30 ],
      "id_str" : "7841792",
      "id" : 7841792
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 31, 39 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 78, 86 ],
      "id_str" : "289107682",
      "id" : 289107682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/bscdkfE7O1",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888313345530638336",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "889966254219550720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401135216725, 8.753344298429072 ]
  },
  "id_str" : "889966706885570560",
  "in_reply_to_user_id" : 95233492,
  "text" : "@GreeneScientist @SteveMcLaugh @dhimmel I already had the pleasure of meeting @dhimmel, at opencon last year, c.f. https:\/\/t.co\/bscdkfE7O1 ;)",
  "id" : 889966706885570560,
  "in_reply_to_status_id" : 889966254219550720,
  "created_at" : "2017-07-25 21:52:52 +0000",
  "in_reply_to_screen_name" : "GreeneScientist",
  "in_reply_to_user_id_str" : "95233492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Greene",
      "screen_name" : "GreeneScientist",
      "indices" : [ 0, 16 ],
      "id_str" : "95233492",
      "id" : 95233492
    }, {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "indices" : [ 17, 30 ],
      "id_str" : "7841792",
      "id" : 7841792
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 31, 39 ],
      "id_str" : "289107682",
      "id" : 289107682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889953303836209156",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397505325472, 8.753396938164569 ]
  },
  "id_str" : "889953638289899520",
  "in_reply_to_user_id" : 95233492,
  "text" : "@GreeneScientist @SteveMcLaugh @dhimmel it\u2019s too bad we didn\u2019t have more time at #BOSC2017, I guess I\u2019ll have to come by and visit one day!",
  "id" : 889953638289899520,
  "in_reply_to_status_id" : 889953303836209156,
  "created_at" : "2017-07-25 21:00:56 +0000",
  "in_reply_to_screen_name" : "GreeneScientist",
  "in_reply_to_user_id_str" : "95233492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 20, 29 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/889927826513829888\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/TA6675nfw4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFmom7NXsAA6vxZ.jpg",
      "id_str" : "889927788064649216",
      "id" : 889927788064649216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFmom7NXsAA6vxZ.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/TA6675nfw4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401652476428, 8.753372624326117 ]
  },
  "id_str" : "889927826513829888",
  "text" : "Aww, thanks so much @abbycabs! Looking forward to the next round. And I\u2019ll take you up on that lunch! \uD83D\uDE0D https:\/\/t.co\/TA6675nfw4",
  "id" : 889927826513829888,
  "created_at" : "2017-07-25 19:18:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Glaser",
      "screen_name" : "freckledgenes",
      "indices" : [ 3, 17 ],
      "id_str" : "882704206536290304",
      "id" : 882704206536290304
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/freckledgenes\/status\/889857991624753153\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ycUXzupX7h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFlpIAoXsAIPETl.jpg",
      "id_str" : "889857987711578114",
      "id" : 889857987711578114,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFlpIAoXsAIPETl.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ycUXzupX7h"
    } ],
    "hashtags" : [ {
      "text" : "genetics",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "DNA",
      "indices" : [ 64, 68 ]
    }, {
      "text" : "rosalindfranklin",
      "indices" : [ 69, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "889892234082103300",
  "text" : "RT @freckledgenes: Happy birthday, Rosalind Franklin! #genetics #DNA #rosalindfranklin https:\/\/t.co\/ycUXzupX7h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/freckledgenes\/status\/889857991624753153\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/ycUXzupX7h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DFlpIAoXsAIPETl.jpg",
        "id_str" : "889857987711578114",
        "id" : 889857987711578114,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFlpIAoXsAIPETl.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/ycUXzupX7h"
      } ],
      "hashtags" : [ {
        "text" : "genetics",
        "indices" : [ 35, 44 ]
      }, {
        "text" : "DNA",
        "indices" : [ 45, 49 ]
      }, {
        "text" : "rosalindfranklin",
        "indices" : [ 50, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "889857991624753153",
    "text" : "Happy birthday, Rosalind Franklin! #genetics #DNA #rosalindfranklin https:\/\/t.co\/ycUXzupX7h",
    "id" : 889857991624753153,
    "created_at" : "2017-07-25 14:40:52 +0000",
    "user" : {
      "name" : "Nicole Glaser",
      "screen_name" : "freckledgenes",
      "protected" : false,
      "id_str" : "882704206536290304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884464080500776962\/WrVKW-u2_normal.jpg",
      "id" : 882704206536290304,
      "verified" : false
    }
  },
  "id" : 889892234082103300,
  "created_at" : "2017-07-25 16:56:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "TEDx Athens",
      "screen_name" : "TEDxAthens",
      "indices" : [ 43, 54 ],
      "id_str" : "38014087",
      "id" : 38014087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "citizenscience",
      "indices" : [ 27, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/B95nGsSJb9",
      "expanded_url" : "https:\/\/twitter.com\/JohannRoduit\/status\/888305037813964800",
      "display_url" : "twitter.com\/JohannRoduit\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "889878507807023104",
  "text" : "RT @EffyVayena: My talk on #citizenscience @TEDxAthens https:\/\/t.co\/B95nGsSJb9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TEDx Athens",
        "screen_name" : "TEDxAthens",
        "indices" : [ 27, 38 ],
        "id_str" : "38014087",
        "id" : 38014087
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "citizenscience",
        "indices" : [ 11, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/B95nGsSJb9",
        "expanded_url" : "https:\/\/twitter.com\/JohannRoduit\/status\/888305037813964800",
        "display_url" : "twitter.com\/JohannRoduit\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "888311464620163072",
    "text" : "My talk on #citizenscience @TEDxAthens https:\/\/t.co\/B95nGsSJb9",
    "id" : 888311464620163072,
    "created_at" : "2017-07-21 08:15:31 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 889878507807023104,
  "created_at" : "2017-07-25 16:02:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/GUvsDkKORT",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BW-ZLsGFzMx\/",
      "display_url" : "instagram.com\/p\/BW-ZLsGFzMx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "889872866123972608",
  "text" : "Maybe not a hundred, but a good number of spires were seen. Goodbye Prague. \u26EA\uFE0F\uD83D\uDD4D https:\/\/t.co\/GUvsDkKORT",
  "id" : 889872866123972608,
  "created_at" : "2017-07-25 15:39:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 3, 15 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 56, 65 ]
    }, {
      "text" : "ISMBECCB",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/5ECSV7ga7g",
      "expanded_url" : "https:\/\/storify.com\/pjacock\/bosc-2017-day-one?utm_campaign=website&utm_source=email&utm_medium=email",
      "display_url" : "storify.com\/pjacock\/bosc-2\u2026"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/YiXwsHhO50",
      "expanded_url" : "https:\/\/storify.com\/pjacock\/bosc-2017-day-two?utm_campaign=website&utm_source=email&utm_medium=email",
      "display_url" : "storify.com\/pjacock\/bosc-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "889871272917819392",
  "text" : "RT @monimunozto: Much fun was had, so much was learned. #BOSC2017 #ISMBECCB\nDay 1 https:\/\/t.co\/5ECSV7ga7g \nDay 2 https:\/\/t.co\/YiXwsHhO50\nTh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/monimunozto\/status\/889834855109980160\/photo\/1",
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/BYG3ao8Sq6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DFlTW-YW0AA6oaP.jpg",
        "id_str" : "889834055549767680",
        "id" : 889834055549767680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFlTW-YW0AA6oaP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1747,
          "resize" : "fit",
          "w" : 2621
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/BYG3ao8Sq6"
      } ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 39, 48 ]
      }, {
        "text" : "ISMBECCB",
        "indices" : [ 49, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/5ECSV7ga7g",
        "expanded_url" : "https:\/\/storify.com\/pjacock\/bosc-2017-day-one?utm_campaign=website&utm_source=email&utm_medium=email",
        "display_url" : "storify.com\/pjacock\/bosc-2\u2026"
      }, {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/YiXwsHhO50",
        "expanded_url" : "https:\/\/storify.com\/pjacock\/bosc-2017-day-two?utm_campaign=website&utm_source=email&utm_medium=email",
        "display_url" : "storify.com\/pjacock\/bosc-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "889834855109980160",
    "text" : "Much fun was had, so much was learned. #BOSC2017 #ISMBECCB\nDay 1 https:\/\/t.co\/5ECSV7ga7g \nDay 2 https:\/\/t.co\/YiXwsHhO50\nThanks everyone! https:\/\/t.co\/BYG3ao8Sq6",
    "id" : 889834855109980160,
    "created_at" : "2017-07-25 13:08:56 +0000",
    "user" : {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "protected" : false,
      "id_str" : "538714687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713239690309083136\/QlP8BsHj_normal.jpg",
      "id" : 538714687,
      "verified" : false
    }
  },
  "id" : 889871272917819392,
  "created_at" : "2017-07-25 15:33:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B\u00E9r\u00E9nice Batut",
      "screen_name" : "bebatut",
      "indices" : [ 3, 11 ],
      "id_str" : "326034810",
      "id" : 326034810
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 40, 49 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 13, 22 ]
    }, {
      "text" : "ISMBECCB",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/1UkZLLEFHB",
      "expanded_url" : "https:\/\/flic.kr\/s\/aHsm17uM1x",
      "display_url" : "flic.kr\/s\/aHsm17uM1x"
    } ]
  },
  "geo" : { },
  "id_str" : "889870798315544576",
  "text" : "RT @bebatut: #BOSC2017 pictures. Thanks @OBF_BOSC for the conference! #ISMBECCB https:\/\/t.co\/1UkZLLEFHB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BOSC",
        "screen_name" : "OBF_BOSC",
        "indices" : [ 27, 36 ],
        "id_str" : "583180584",
        "id" : 583180584
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "ISMBECCB",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/1UkZLLEFHB",
        "expanded_url" : "https:\/\/flic.kr\/s\/aHsm17uM1x",
        "display_url" : "flic.kr\/s\/aHsm17uM1x"
      } ]
    },
    "geo" : { },
    "id_str" : "889785555319390208",
    "text" : "#BOSC2017 pictures. Thanks @OBF_BOSC for the conference! #ISMBECCB https:\/\/t.co\/1UkZLLEFHB",
    "id" : 889785555319390208,
    "created_at" : "2017-07-25 09:53:02 +0000",
    "user" : {
      "name" : "B\u00E9r\u00E9nice Batut",
      "screen_name" : "bebatut",
      "protected" : false,
      "id_str" : "326034810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751067403749060608\/kx5PT9_z_normal.jpg",
      "id" : 326034810,
      "verified" : false
    }
  },
  "id" : 889870798315544576,
  "created_at" : "2017-07-25 15:31:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinh Tran",
      "screen_name" : "trvinh_",
      "indices" : [ 0, 8 ],
      "id_str" : "888863514491850752",
      "id" : 888863514491850752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889584246507139073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.07653419936762, 14.41584217221927 ]
  },
  "id_str" : "889589032698519552",
  "in_reply_to_user_id" : 888863514491850752,
  "text" : "@trvinh_ \uD83D\uDE0D",
  "id" : 889589032698519552,
  "in_reply_to_status_id" : 889584246507139073,
  "created_at" : "2017-07-24 20:52:07 +0000",
  "in_reply_to_screen_name" : "trvinh_",
  "in_reply_to_user_id_str" : "888863514491850752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald McKnight",
      "screen_name" : "donaldmcknight2",
      "indices" : [ 3, 19 ],
      "id_str" : "714247012892459008",
      "id" : 714247012892459008
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "turtles",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "889581668645957633",
  "text" : "RT @donaldmcknight2: \"Good vibrations: a novel method for sexing turtles\" has been published. It is exactly what it sounds like. #turtles h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/donaldmcknight2\/status\/889523453245747200\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/2d3eucoas2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DFg4ukrXUAELN93.jpg",
        "id_str" : "889523299176370177",
        "id" : 889523299176370177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFg4ukrXUAELN93.jpg",
        "sizes" : [ {
          "h" : 4096,
          "resize" : "fit",
          "w" : 2725
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1363
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 452
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 798
        } ],
        "display_url" : "pic.twitter.com\/2d3eucoas2"
      } ],
      "hashtags" : [ {
        "text" : "turtles",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/TmXnGCSsIH",
        "expanded_url" : "https:\/\/tinyurl.com\/yd5sh7wp",
        "display_url" : "tinyurl.com\/yd5sh7wp"
      } ]
    },
    "geo" : { },
    "id_str" : "889523453245747200",
    "text" : "\"Good vibrations: a novel method for sexing turtles\" has been published. It is exactly what it sounds like. #turtles https:\/\/t.co\/TmXnGCSsIH https:\/\/t.co\/2d3eucoas2",
    "id" : 889523453245747200,
    "created_at" : "2017-07-24 16:31:32 +0000",
    "user" : {
      "name" : "Donald McKnight",
      "screen_name" : "donaldmcknight2",
      "protected" : false,
      "id_str" : "714247012892459008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714251168470446080\/-RhBB6p__normal.jpg",
      "id" : 714247012892459008,
      "verified" : false
    }
  },
  "id" : 889581668645957633,
  "created_at" : "2017-07-24 20:22:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/VUf3HjmRG2",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BW8RDMCFAUD\/",
      "display_url" : "instagram.com\/p\/BW8RDMCFAUD\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.086335699568, 14.41294670105 ]
  },
  "id_str" : "889573494593400832",
  "text" : "\uD83C\uDFF0 @ Karl\u016Fv most - Charles Bridge - Ponte Carlo - Puente de Carlos https:\/\/t.co\/VUf3HjmRG2",
  "id" : 889573494593400832,
  "created_at" : "2017-07-24 19:50:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/0heykyVboB",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BW8ACd6Fxoh\/",
      "display_url" : "instagram.com\/p\/BW8ACd6Fxoh\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.089722222222, 14.417222222222 ]
  },
  "id_str" : "889536098300506113",
  "text" : "One rarely gets a chance to visit so much history in so little space @ Old Jewish Cemetery, Prague https:\/\/t.co\/0heykyVboB",
  "id" : 889536098300506113,
  "created_at" : "2017-07-24 17:21:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 98, 113 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/K5M5U1vjBi",
      "expanded_url" : "https:\/\/medium.com\/read-write-participate\/work-in-the-open-with-mozilla-1410be0a83b2",
      "display_url" : "medium.com\/read-write-par\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.07650294079922, 14.4158684182274 ]
  },
  "id_str" : "889517761977831424",
  "text" : "If #BOSC2017 inspired you to start your own open* project: you can still apply for mentoring with @MozOpenLeaders https:\/\/t.co\/K5M5U1vjBi",
  "id" : 889517761977831424,
  "created_at" : "2017-07-24 16:08:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "indices" : [ 3, 16 ],
      "id_str" : "636023721",
      "id" : 636023721
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/neuroecology\/status\/889479494813319168\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/ph5SPqUMNn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFgQxY9XYAAoaCj.jpg",
      "id_str" : "889479367105142784",
      "id" : 889479367105142784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFgQxY9XYAAoaCj.jpg",
      "sizes" : [ {
        "h" : 303,
        "resize" : "fit",
        "w" : 903
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 903
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 903
      } ],
      "display_url" : "pic.twitter.com\/ph5SPqUMNn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/neuroecology\/status\/889479494813319168\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/ph5SPqUMNn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFgQ4kdWsAAfbOJ.jpg",
      "id_str" : "889479490451189760",
      "id" : 889479490451189760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFgQ4kdWsAAfbOJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 903
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 903
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 903
      } ],
      "display_url" : "pic.twitter.com\/ph5SPqUMNn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/jY0pU4ZNfC",
      "expanded_url" : "https:\/\/www.theverge.com\/2017\/7\/21\/15999544\/biohacking-finger-magnet-human-augmentation-loss",
      "display_url" : "theverge.com\/2017\/7\/21\/1599\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "889515539088932865",
  "text" : "RT @neuroecology: I hacked my body for a future that never came https:\/\/t.co\/jY0pU4ZNfC https:\/\/t.co\/ph5SPqUMNn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/neuroecology\/status\/889479494813319168\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/ph5SPqUMNn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DFgQxY9XYAAoaCj.jpg",
        "id_str" : "889479367105142784",
        "id" : 889479367105142784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFgQxY9XYAAoaCj.jpg",
        "sizes" : [ {
          "h" : 303,
          "resize" : "fit",
          "w" : 903
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 903
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 903
        } ],
        "display_url" : "pic.twitter.com\/ph5SPqUMNn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/neuroecology\/status\/889479494813319168\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/ph5SPqUMNn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DFgQ4kdWsAAfbOJ.jpg",
        "id_str" : "889479490451189760",
        "id" : 889479490451189760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFgQ4kdWsAAfbOJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 903
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 903
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 903
        } ],
        "display_url" : "pic.twitter.com\/ph5SPqUMNn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/jY0pU4ZNfC",
        "expanded_url" : "https:\/\/www.theverge.com\/2017\/7\/21\/15999544\/biohacking-finger-magnet-human-augmentation-loss",
        "display_url" : "theverge.com\/2017\/7\/21\/1599\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "889479494813319168",
    "text" : "I hacked my body for a future that never came https:\/\/t.co\/jY0pU4ZNfC https:\/\/t.co\/ph5SPqUMNn",
    "id" : 889479494813319168,
    "created_at" : "2017-07-24 13:36:51 +0000",
    "user" : {
      "name" : "Adam J Calhoun",
      "screen_name" : "neuroecology",
      "protected" : false,
      "id_str" : "636023721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796806166332444673\/MihDU_e8_normal.jpg",
      "id" : 636023721,
      "verified" : true
    }
  },
  "id" : 889515539088932865,
  "created_at" : "2017-07-24 16:00:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uCXHEQB9Fo",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BW7he0lFmXs\/",
      "display_url" : "instagram.com\/p\/BW7he0lFmXs\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09023018, 14.43593075 ]
  },
  "id_str" : "889468897895886849",
  "text" : "In total Pinkasova's walls are covered with the names of around 80,000 victims of the Shoah. @\u2026 https:\/\/t.co\/uCXHEQB9Fo",
  "id" : 889468897895886849,
  "created_at" : "2017-07-24 12:54:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/G0AK07nOM5",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BW7hCngl8Jw\/",
      "display_url" : "instagram.com\/p\/BW7hCngl8Jw\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.09023018, 14.43593075 ]
  },
  "id_str" : "889467934845829120",
  "text" : "The names of some of people my ancestors systematically murdered @ Sinagoga Pinkasova https:\/\/t.co\/G0AK07nOM5",
  "id" : 889467934845829120,
  "created_at" : "2017-07-24 12:50:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    }, {
      "name" : "Apollo Annotation",
      "screen_name" : "apollo_bbop",
      "indices" : [ 13, 25 ],
      "id_str" : "732278787518304256",
      "id" : 732278787518304256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889415635998003200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0902465404472, 14.41862713621107 ]
  },
  "id_str" : "889429915816402946",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto @apollo_bbop Totally deserved!",
  "id" : 889429915816402946,
  "in_reply_to_status_id" : 889415635998003200,
  "created_at" : "2017-07-24 10:19:51 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silvia Di Giorgio",
      "screen_name" : "silviadg87",
      "indices" : [ 0, 11 ],
      "id_str" : "191368435",
      "id" : 191368435
    }, {
      "name" : "Vinh Tran",
      "screen_name" : "trvinh_",
      "indices" : [ 12, 20 ],
      "id_str" : "888863514491850752",
      "id" : 888863514491850752
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/889391587737948161\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/rilbZX4ENq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFfA7X6WAAASFwL.jpg",
      "id_str" : "889391577692504064",
      "id" : 889391577692504064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFfA7X6WAAASFwL.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/rilbZX4ENq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.08163700816229, 14.41305382178576 ]
  },
  "id_str" : "889391587737948161",
  "in_reply_to_user_id" : 191368435,
  "text" : "@silviadg87 @trvinh_ to keep with the food tradition \uD83D\uDE09 https:\/\/t.co\/rilbZX4ENq",
  "id" : 889391587737948161,
  "created_at" : "2017-07-24 07:47:33 +0000",
  "in_reply_to_screen_name" : "silviadg87",
  "in_reply_to_user_id_str" : "191368435",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bosc2017",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/YEGrvzG4Et",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BW69tRulVNc\/",
      "display_url" : "instagram.com\/p\/BW69tRulVNc\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0811111111, 14.4133333333 ]
  },
  "id_str" : "889390231073456128",
  "text" : "Now for 1 1\/2 days of exploring Prague after 2 great days of #bosc2017 @ National Theatre https:\/\/t.co\/YEGrvzG4Et",
  "id" : 889390231073456128,
  "created_at" : "2017-07-24 07:42:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 0, 9 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889262444069224448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.07651678271217, 14.41584669979047 ]
  },
  "id_str" : "889264031005061120",
  "in_reply_to_user_id" : 1073388199,
  "text" : "@yoyehudi +1",
  "id" : 889264031005061120,
  "in_reply_to_status_id" : 889262444069224448,
  "created_at" : "2017-07-23 23:20:41 +0000",
  "in_reply_to_screen_name" : "yoyehudi",
  "in_reply_to_user_id_str" : "1073388199",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/oGrsbpXOzE",
      "expanded_url" : "https:\/\/twitter.com\/silviadg87\/status\/889199818387673090",
      "display_url" : "twitter.com\/silviadg87\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "889199828240150529",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05874418319666, 14.41795633174607 ]
  },
  "id_str" : "889200101641650177",
  "in_reply_to_user_id" : 14286491,
  "text" : "And here is the dinner from the other angle. #BOSC2017 \uD83C\uDF89\uD83E\uDD57\uD83C\uDF5C\uD83C\uDF54 https:\/\/t.co\/oGrsbpXOzE",
  "id" : 889200101641650177,
  "in_reply_to_status_id" : 889199828240150529,
  "created_at" : "2017-07-23 19:06:39 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/FiuSDQ7Tql",
      "expanded_url" : "https:\/\/twitter.com\/fzkhan88\/status\/889196857443979264",
      "display_url" : "twitter.com\/fzkhan88\/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "889162097610952708",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05883856368135, 14.41783264587925 ]
  },
  "id_str" : "889199828240150529",
  "in_reply_to_user_id" : 14286491,
  "text" : "Our dinner from one angle. #BOSC2017 https:\/\/t.co\/FiuSDQ7Tql",
  "id" : 889199828240150529,
  "in_reply_to_status_id" : 889162097610952708,
  "created_at" : "2017-07-23 19:05:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Brueffer",
      "screen_name" : "cbrueffer",
      "indices" : [ 0, 10 ],
      "id_str" : "2475490934",
      "id" : 2475490934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889181055911157762",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05885774410061, 14.41735207202636 ]
  },
  "id_str" : "889187311732346880",
  "in_reply_to_user_id" : 2475490934,
  "text" : "@cbrueffer It was the very scenic route!",
  "id" : 889187311732346880,
  "in_reply_to_status_id" : 889181055911157762,
  "created_at" : "2017-07-23 18:15:50 +0000",
  "in_reply_to_screen_name" : "cbrueffer",
  "in_reply_to_user_id_str" : "2475490934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Brueffer",
      "screen_name" : "cbrueffer",
      "indices" : [ 0, 10 ],
      "id_str" : "2475490934",
      "id" : 2475490934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889176631281147906",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06522582848562, 14.41659685225637 ]
  },
  "id_str" : "889176860554297344",
  "in_reply_to_user_id" : 2475490934,
  "text" : "@cbrueffer Perfect. We\u2019re nearly there! Took the scenic route",
  "id" : 889176860554297344,
  "in_reply_to_status_id" : 889176631281147906,
  "created_at" : "2017-07-23 17:34:18 +0000",
  "in_reply_to_screen_name" : "cbrueffer",
  "in_reply_to_user_id_str" : "2475490934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889143856201175040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06290046781501, 14.43158551703775 ]
  },
  "id_str" : "889162097610952708",
  "in_reply_to_user_id" : 14286491,
  "text" : "If you\u2019re signed up for the #BOSC2017 dinner tonight: leaving at ~19:10 (that\u2019s 7:10 pm) from the conference entrance.",
  "id" : 889162097610952708,
  "in_reply_to_status_id" : 889143856201175040,
  "created_at" : "2017-07-23 16:35:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889133040152215552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06210080120587, 14.42905932104004 ]
  },
  "id_str" : "889143856201175040",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThe Great Firewall for Sequencing Data\u00BB Can Nanopore be the VPN-equivalent to get genomics data out of China?  #BOSC2017",
  "id" : 889143856201175040,
  "in_reply_to_status_id" : 889133040152215552,
  "created_at" : "2017-07-23 15:23:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 33, 49 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 79, 87 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/889133040152215552\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/mTSzesEKhh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFbVvhmWAAAe-KE.jpg",
      "id_str" : "889132988902014976",
      "id" : 889132988902014976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFbVvhmWAAAe-KE.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      } ],
      "display_url" : "pic.twitter.com\/mTSzesEKhh"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889120935407648769",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.061584497164, 14.42900987481467 ]
  },
  "id_str" : "889133040152215552",
  "in_reply_to_user_id" : 14286491,
  "text" : "The crowd sourced talk title for @pathogenomenick: Talky McTalkface, thanks to @kaiblin  #BOSC2017 https:\/\/t.co\/mTSzesEKhh",
  "id" : 889133040152215552,
  "in_reply_to_status_id" : 889120935407648769,
  "created_at" : "2017-07-23 14:40:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Evelo",
      "screen_name" : "Chris_Evelo",
      "indices" : [ 0, 12 ],
      "id_str" : "89169314",
      "id" : 89169314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/S7LoeePY4M",
      "expanded_url" : "https:\/\/github.com\/greenelab\/scihub-manuscript\/",
      "display_url" : "github.com\/greenelab\/scih\u2026"
    }, {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/CJlzSAHIsB",
      "expanded_url" : "https:\/\/github.com\/greenelab\/scihub",
      "display_url" : "github.com\/greenelab\/scih\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "889122098169487362",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06156987159222, 14.42900831327455 ]
  },
  "id_str" : "889122725897396224",
  "in_reply_to_user_id" : 89169314,
  "text" : "@Chris_Evelo GitHub works as well, see https:\/\/t.co\/S7LoeePY4M &amp; https:\/\/t.co\/CJlzSAHIsB",
  "id" : 889122725897396224,
  "in_reply_to_status_id" : 889122098169487362,
  "created_at" : "2017-07-23 13:59:11 +0000",
  "in_reply_to_screen_name" : "Chris_Evelo",
  "in_reply_to_user_id_str" : "89169314",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/JhIafc2IdF",
      "expanded_url" : "http:\/\/rossmounce.co.uk\/2017\/04\/02\/open-letter-to-oxford-university-press\/",
      "display_url" : "rossmounce.co.uk\/2017\/04\/02\/ope\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "889120375317164032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06163105035467, 14.42903252152956 ]
  },
  "id_str" : "889120935407648769",
  "in_reply_to_user_id" : 14286491,
  "text" : "Look at this case for how publishers screw up data hosting: https:\/\/t.co\/JhIafc2IdF to my knowledge OUP hasn\u2019t fixed to this day #BOSC2017",
  "id" : 889120935407648769,
  "in_reply_to_status_id" : 889120375317164032,
  "created_at" : "2017-07-23 13:52:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889119592186040320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06127699019058, 14.42898050148669 ]
  },
  "id_str" : "889120375317164032",
  "in_reply_to_user_id" : 14286491,
  "text" : "Journals who don\u2019t care about supplementary data. OUP, we\u2019re looking at you. #BOSC2017",
  "id" : 889120375317164032,
  "in_reply_to_status_id" : 889119592186040320,
  "created_at" : "2017-07-23 13:49:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889115840578289664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0615505991307, 14.4290069792634 ]
  },
  "id_str" : "889119592186040320",
  "in_reply_to_user_id" : 14286491,
  "text" : "Open data could be abused, example case: observation data of endangered species, would be used by poachers if open. #BOSC2017",
  "id" : 889119592186040320,
  "in_reply_to_status_id" : 889115840578289664,
  "created_at" : "2017-07-23 13:46:44 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889114975180120064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06169453607303, 14.42874839204245 ]
  },
  "id_str" : "889115840578289664",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABSome data is only interesting to the producer. And that\u2019s only because they haven\u2019t figured out yet that it\u2019s boring.\u00BB #BOSC2017",
  "id" : 889115840578289664,
  "in_reply_to_status_id" : 889114975180120064,
  "created_at" : "2017-07-23 13:31:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran O'Neill",
      "screen_name" : "oneillkza",
      "indices" : [ 0, 10 ],
      "id_str" : "100371111",
      "id" : 100371111
    }, {
      "name" : "Andrew Su",
      "screen_name" : "andrewsu",
      "indices" : [ 11, 20 ],
      "id_str" : "25743783",
      "id" : 25743783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889114783118753792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06172128315413, 14.42848979939551 ]
  },
  "id_str" : "889115073125527552",
  "in_reply_to_user_id" : 100371111,
  "text" : "@oneillkza @andrewsu \uD83D\uDC4D",
  "id" : 889115073125527552,
  "in_reply_to_status_id" : 889114783118753792,
  "created_at" : "2017-07-23 13:28:47 +0000",
  "in_reply_to_screen_name" : "oneillkza",
  "in_reply_to_user_id_str" : "100371111",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Su",
      "screen_name" : "andrewsu",
      "indices" : [ 30, 39 ],
      "id_str" : "25743783",
      "id" : 25743783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889113275706855424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06172128315413, 14.42848979939551 ]
  },
  "id_str" : "889114975180120064",
  "in_reply_to_user_id" : 14286491,
  "text" : "If you\u2019re doing a post-doc in @andrewsu\u2019s group you\u2019re getting to write SPARQL queries and extract tables from PDFs \uD83D\uDE1C #BOSC2017",
  "id" : 889114975180120064,
  "in_reply_to_status_id" : 889113275706855424,
  "created_at" : "2017-07-23 13:28:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Su",
      "screen_name" : "andrewsu",
      "indices" : [ 6, 15 ],
      "id_str" : "25743783",
      "id" : 25743783
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889111468410634240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06170731224665, 14.42878640363828 ]
  },
  "id_str" : "889113275706855424",
  "in_reply_to_user_id" : 14286491,
  "text" : "While @andrewsu doesn\u2019t go as far, I\u2019d say: Don\u2019t use CC BY for data. #BOSC2017",
  "id" : 889113275706855424,
  "in_reply_to_status_id" : 889111468410634240,
  "created_at" : "2017-07-23 13:21:38 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/lTJ9mpfEy4",
      "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/889110275349254144",
      "display_url" : "twitter.com\/SCEdmunds\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "889094073159647232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06167558862757, 14.42876048486256 ]
  },
  "id_str" : "889111468410634240",
  "in_reply_to_user_id" : 14286491,
  "text" : "His sequencing run hasn\u2019t finished yet. \uD83D\uDE09 #BOSC2017 https:\/\/t.co\/lTJ9mpfEy4",
  "id" : 889111468410634240,
  "in_reply_to_status_id" : 889094073159647232,
  "created_at" : "2017-07-23 13:14:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889067657164619776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06174410692707, 14.42872940658385 ]
  },
  "id_str" : "889094073159647232",
  "in_reply_to_user_id" : 14286491,
  "text" : "Seems we\u2019re in the right place to hear about Apache Kafka.  #BOSC2017",
  "id" : 889094073159647232,
  "in_reply_to_status_id" : 889067657164619776,
  "created_at" : "2017-07-23 12:05:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 21, 29 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889066897920196610",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06155635776998, 14.42901960532674 ]
  },
  "id_str" : "889067657164619776",
  "in_reply_to_user_id" : 14286491,
  "text" : "A big shout out from @kaiblin to all OSS developers that built tools that make his own tools possible. #BOSC2017",
  "id" : 889067657164619776,
  "in_reply_to_status_id" : 889066897920196610,
  "created_at" : "2017-07-23 10:20:22 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 46, 54 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889065096466636801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06155635776998, 14.42901960532674 ]
  },
  "id_str" : "889066897920196610",
  "in_reply_to_user_id" : 14286491,
  "text" : "Fighting Superbugs with Open Source Software, @kaiblin about finding new, naturally occurring antibiotics. #BOSC2017",
  "id" : 889066897920196610,
  "in_reply_to_status_id" : 889065096466636801,
  "created_at" : "2017-07-23 10:17:21 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/1n3tsk5CGx",
      "expanded_url" : "https:\/\/twitter.com\/GreeneScientist\/status\/889064945912086528",
      "display_url" : "twitter.com\/GreeneScientis\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "889054971831910401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06153635840975, 14.42901297633615 ]
  },
  "id_str" : "889065096466636801",
  "in_reply_to_user_id" : 14286491,
  "text" : "Yep, that\u2019s such a cool experience! #BOSC2017 https:\/\/t.co\/1n3tsk5CGx",
  "id" : 889065096466636801,
  "in_reply_to_status_id" : 889054971831910401,
  "created_at" : "2017-07-23 10:10:11 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889064071491977217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06153635840975, 14.42901297633615 ]
  },
  "id_str" : "889064723798536192",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto The hallways flanking the BOSC room to the left and right!",
  "id" : 889064723798536192,
  "in_reply_to_status_id" : 889064071491977217,
  "created_at" : "2017-07-23 10:08:42 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Greene",
      "screen_name" : "GreeneScientist",
      "indices" : [ 0, 16 ],
      "id_str" : "95233492",
      "id" : 95233492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889063491981725696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06158080962891, 14.42905185223288 ]
  },
  "id_str" : "889063819586285569",
  "in_reply_to_user_id" : 95233492,
  "text" : "@GreeneScientist Oh, you\u2019re here? :)",
  "id" : 889063819586285569,
  "in_reply_to_status_id" : 889063491981725696,
  "created_at" : "2017-07-23 10:05:07 +0000",
  "in_reply_to_screen_name" : "GreeneScientist",
  "in_reply_to_user_id_str" : "95233492",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/dD46AtVKyz",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BW4ouYeFy5d\/",
      "display_url" : "instagram.com\/p\/BW4ouYeFy5d\/"
    } ]
  },
  "geo" : { },
  "id_str" : "889062612998205444",
  "text" : "The #BOSC2017 data plumbing is alive and kicking in the ceilings here. https:\/\/t.co\/dD46AtVKyz",
  "id" : 889062612998205444,
  "created_at" : "2017-07-23 10:00:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amel Ghouila",
      "screen_name" : "AmelGhouila",
      "indices" : [ 36, 48 ],
      "id_str" : "2596654898",
      "id" : 2596654898
    }, {
      "name" : "H3ABioNet",
      "screen_name" : "H3ABionet",
      "indices" : [ 79, 89 ],
      "id_str" : "3131069933",
      "id" : 3131069933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889042945827065856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06158874752783, 14.42902237813571 ]
  },
  "id_str" : "889054971831910401",
  "in_reply_to_user_id" : 14286491,
  "text" : "Fun to see screenshots that feature @AmelGhouila in the slides about the great @H3ABionet project at #BOSC2017",
  "id" : 889054971831910401,
  "in_reply_to_status_id" : 889042945827065856,
  "created_at" : "2017-07-23 09:29:57 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889053235276914688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06160609252325, 14.4290242541493 ]
  },
  "id_str" : "889053920689082368",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena Thanks for sharing it!",
  "id" : 889053920689082368,
  "in_reply_to_status_id" : 889053235276914688,
  "created_at" : "2017-07-23 09:25:47 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 92, 108 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EffyVayena\/status\/889053235276914688\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/uU47pYaDPK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFaM9QlXkAAjQ-Z.jpg",
      "id_str" : "889052960503861248",
      "id" : 889052960503861248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFaM9QlXkAAjQ-Z.jpg",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 254
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 254
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 254
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 254
      } ],
      "display_url" : "pic.twitter.com\/uU47pYaDPK"
    } ],
    "hashtags" : [ {
      "text" : "Schweiz",
      "indices" : [ 16, 24 ]
    }, {
      "text" : "genomics",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/JvxI7MKJTg",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0177158",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "889053778724433921",
  "text" : "RT @EffyVayena: #Schweiz am Wochende reports on our study https:\/\/t.co\/JvxI7MKJTg #genomics @gedankenstuecke https:\/\/t.co\/uU47pYaDPK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 76, 92 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EffyVayena\/status\/889053235276914688\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/uU47pYaDPK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DFaM9QlXkAAjQ-Z.jpg",
        "id_str" : "889052960503861248",
        "id" : 889052960503861248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFaM9QlXkAAjQ-Z.jpg",
        "sizes" : [ {
          "h" : 522,
          "resize" : "fit",
          "w" : 254
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 254
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 254
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 254
        } ],
        "display_url" : "pic.twitter.com\/uU47pYaDPK"
      } ],
      "hashtags" : [ {
        "text" : "Schweiz",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "genomics",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/JvxI7MKJTg",
        "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0177158",
        "display_url" : "journals.plos.org\/plosone\/articl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "889053235276914688",
    "text" : "#Schweiz am Wochende reports on our study https:\/\/t.co\/JvxI7MKJTg #genomics @gedankenstuecke https:\/\/t.co\/uU47pYaDPK",
    "id" : 889053235276914688,
    "created_at" : "2017-07-23 09:23:03 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 889053778724433921,
  "created_at" : "2017-07-23 09:25:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 3, 15 ],
      "id_str" : "538714687",
      "id" : 538714687
    }, {
      "name" : "Apollo Annotation",
      "screen_name" : "apollo_bbop",
      "indices" : [ 50, 62 ],
      "id_str" : "732278787518304256",
      "id" : 732278787518304256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "889049966475444226",
  "text" : "RT @monimunozto: I just counted: I've held &gt;50 @apollo_bbop trainings for ~1K scientists from &gt;12 countries in ~3 years. #BOSC2017 \\O\/ #Too\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Apollo Annotation",
        "screen_name" : "apollo_bbop",
        "indices" : [ 33, 45 ],
        "id_str" : "732278787518304256",
        "id" : 732278787518304256
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 110, 119 ]
      }, {
        "text" : "TootingMyOwnHorn",
        "indices" : [ 124, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "889049829887938560",
    "text" : "I just counted: I've held &gt;50 @apollo_bbop trainings for ~1K scientists from &gt;12 countries in ~3 years. #BOSC2017 \\O\/ #TootingMyOwnHorn",
    "id" : 889049829887938560,
    "created_at" : "2017-07-23 09:09:31 +0000",
    "user" : {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "protected" : false,
      "id_str" : "538714687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713239690309083136\/QlP8BsHj_normal.jpg",
      "id" : 538714687,
      "verified" : false
    }
  },
  "id" : 889049966475444226,
  "created_at" : "2017-07-23 09:10:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889041567377391616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06185502811433, 14.42903606444509 ]
  },
  "id_str" : "889042945827065856",
  "in_reply_to_user_id" : 14286491,
  "text" : "Trying to put a price tag on the work the community does: the apollo community contributed time worth ~ USD10k #BOSC2017",
  "id" : 889042945827065856,
  "in_reply_to_status_id" : 889041567377391616,
  "created_at" : "2017-07-23 08:42:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889040077879484417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06127175782369, 14.42899577672726 ]
  },
  "id_str" : "889041567377391616",
  "in_reply_to_user_id" : 14286491,
  "text" : "I love the Apollo project, jointly fixing broken genome annotations is so cool. #BOSC2017",
  "id" : 889041567377391616,
  "in_reply_to_status_id" : 889040077879484417,
  "created_at" : "2017-07-23 08:36:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 5, 17 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/889040077879484417\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/rWnlTNyxbe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFaBOT0XUAAlBaG.jpg",
      "id_str" : "889040059290308608",
      "id" : 889040059290308608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFaBOT0XUAAlBaG.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/rWnlTNyxbe"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889038760586948608",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06157368515383, 14.42902035171917 ]
  },
  "id_str" : "889040077879484417",
  "in_reply_to_user_id" : 14286491,
  "text" : "Now: @monimunozto about curation communities. #BOSC2017 https:\/\/t.co\/rWnlTNyxbe",
  "id" : 889040077879484417,
  "in_reply_to_status_id" : 889038760586948608,
  "created_at" : "2017-07-23 08:30:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889038120691392513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06175448257282, 14.42902647386991 ]
  },
  "id_str" : "889038760586948608",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABBeer Expert\u00BB sounds like a job description may here dream of! #BOSC2017",
  "id" : 889038760586948608,
  "in_reply_to_status_id" : 889038120691392513,
  "created_at" : "2017-07-23 08:25:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Evelo",
      "screen_name" : "Chris_Evelo",
      "indices" : [ 0, 12 ],
      "id_str" : "89169314",
      "id" : 89169314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889038299226148865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06155854639572, 14.42902005201429 ]
  },
  "id_str" : "889038389009424384",
  "in_reply_to_user_id" : 89169314,
  "text" : "@Chris_Evelo Cheers! \uD83C\uDF7B",
  "id" : 889038389009424384,
  "in_reply_to_status_id" : 889038299226148865,
  "created_at" : "2017-07-23 08:24:04 +0000",
  "in_reply_to_screen_name" : "Chris_Evelo",
  "in_reply_to_user_id_str" : "89169314",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/889038120691392513\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/JY0sLuXtzw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFZ_c1UXoAAcSzP.jpg",
      "id_str" : "889038109777829888",
      "id" : 889038109777829888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFZ_c1UXoAAcSzP.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/JY0sLuXtzw"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889037978890375168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06153229220369, 14.42901814646092 ]
  },
  "id_str" : "889038120691392513",
  "in_reply_to_user_id" : 14286491,
  "text" : "The scientific method reloaded: Analyse data, think, drink, repeat. #BOSC2017 https:\/\/t.co\/JY0sLuXtzw",
  "id" : 889038120691392513,
  "in_reply_to_status_id" : 889037978890375168,
  "created_at" : "2017-07-23 08:23:00 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/889037978890375168\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/6NuBUGrG9A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFZ_UOiXcAAQpP5.jpg",
      "id_str" : "889037961928601600",
      "id" : 889037961928601600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFZ_UOiXcAAQpP5.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      } ],
      "display_url" : "pic.twitter.com\/6NuBUGrG9A"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889036948224036864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06127382859481, 14.42899594827622 ]
  },
  "id_str" : "889037978890375168",
  "in_reply_to_user_id" : 14286491,
  "text" : "Detecting the taxonomic diversity in beer. #BOSC2017 https:\/\/t.co\/6NuBUGrG9A",
  "id" : 889037978890375168,
  "in_reply_to_status_id" : 889036948224036864,
  "created_at" : "2017-07-23 08:22:26 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889036030531301377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06149938149002, 14.42901548871904 ]
  },
  "id_str" : "889036948224036864",
  "in_reply_to_user_id" : 14286491,
  "text" : "Crowdfunding for sequencing lots of beer is much easier than getting funds for drinking lots of beer. #BOSC2017",
  "id" : 889036948224036864,
  "in_reply_to_status_id" : 889036030531301377,
  "created_at" : "2017-07-23 08:18:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hackuarium",
      "screen_name" : "hackuarium",
      "indices" : [ 27, 38 ],
      "id_str" : "2418603105",
      "id" : 2418603105
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/889036030531301377\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/0B9Lg2dTDM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFZ9jGTXkAIRss-.jpg",
      "id_str" : "889036018392993794",
      "id" : 889036018392993794,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFZ9jGTXkAIRss-.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/0B9Lg2dTDM"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889035746505617408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06149938149002, 14.42901548871904 ]
  },
  "id_str" : "889036030531301377",
  "in_reply_to_user_id" : 14286491,
  "text" : "Getting a brief intro into @hackuarium #BOSC2017 https:\/\/t.co\/0B9Lg2dTDM",
  "id" : 889036030531301377,
  "in_reply_to_status_id" : 889035746505617408,
  "created_at" : "2017-07-23 08:14:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sobel",
      "screen_name" : "JonathanSobel1",
      "indices" : [ 55, 70 ],
      "id_str" : "841497890",
      "id" : 841497890
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/889035746505617408\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/rWJtLSAVNL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFZ9SN3XoAEpoGb.jpg",
      "id_str" : "889035728365264897",
      "id" : 889035728365264897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFZ9SN3XoAEpoGb.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      } ],
      "display_url" : "pic.twitter.com\/rWJtLSAVNL"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "889033820346908672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06193487393878, 14.42904260608548 ]
  },
  "id_str" : "889035746505617408",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABToday I\u2019m talking about my hobby. Sequencing beer.\u00BB \uD83C\uDF7B @JonathanSobel1 #BOSC2017 https:\/\/t.co\/rWJtLSAVNL",
  "id" : 889035746505617408,
  "in_reply_to_status_id" : 889033820346908672,
  "created_at" : "2017-07-23 08:13:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888839232722219009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06155684924833, 14.42901740296232 ]
  },
  "id_str" : "889033820346908672",
  "in_reply_to_user_id" : 14286491,
  "text" : "Looking forward to this morning\u2019s Citizen Science &amp; Community Building session. #BOSC2017",
  "id" : 889033820346908672,
  "in_reply_to_status_id" : 888839232722219009,
  "created_at" : "2017-07-23 08:05:54 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malvika Sharan",
      "screen_name" : "MalvikaSharan",
      "indices" : [ 0, 14 ],
      "id_str" : "1612233594",
      "id" : 1612233594
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 15, 23 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 24, 34 ],
      "id_str" : "75261668",
      "id" : 75261668
    }, {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 35, 44 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888879431787393025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06289021116687, 14.43188058213743 ]
  },
  "id_str" : "888884020158877696",
  "in_reply_to_user_id" : 1612233594,
  "text" : "@MalvikaSharan @pjacock @npscience @OBF_BOSC I thought it was a cheap shot at Apple and their closedness :)",
  "id" : 888884020158877696,
  "in_reply_to_status_id" : 888879431787393025,
  "created_at" : "2017-07-22 22:10:39 +0000",
  "in_reply_to_screen_name" : "MalvikaSharan",
  "in_reply_to_user_id_str" : "1612233594",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 11, 19 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/IaUWAO02RJ",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Belle_de_Boskoop",
      "display_url" : "en.m.wikipedia.org\/wiki\/Belle_de_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "888866377729224705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06330578478472, 14.42969738983785 ]
  },
  "id_str" : "888870448368418816",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience @pjacock Same here. That\u2019s something I\u2019d have recognized https:\/\/t.co\/IaUWAO02RJ",
  "id" : 888870448368418816,
  "in_reply_to_status_id" : 888866377729224705,
  "created_at" : "2017-07-22 21:16:43 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888860363676160000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05940217575368, 14.41961296373267 ]
  },
  "id_str" : "888862275775418370",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience I can always claim language barrier derived ignorance. ;)",
  "id" : 888862275775418370,
  "in_reply_to_status_id" : 888860363676160000,
  "created_at" : "2017-07-22 20:44:15 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888848068468191233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05950784881185, 14.41973383924125 ]
  },
  "id_str" : "888859563042242560",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience I felt a bit embarrassed when I figured that out earlier this year.",
  "id" : 888859563042242560,
  "in_reply_to_status_id" : 888848068468191233,
  "created_at" : "2017-07-22 20:33:28 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u033Ce\u0325b\u0353a\u0330s\u032Cti\u035Aa\u0349n\u034E M\u031Fo\u034Drr\u033B",
      "screen_name" : "blinry",
      "indices" : [ 0, 7 ],
      "id_str" : "53749209",
      "id" : 53749209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888839731248861189",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05951556603965, 14.41963295182288 ]
  },
  "id_str" : "888839954129973250",
  "in_reply_to_user_id" : 53749209,
  "text" : "@blinry A blueberry dumpling \uD83D\uDE02",
  "id" : 888839954129973250,
  "in_reply_to_status_id" : 888839731248861189,
  "created_at" : "2017-07-22 19:15:33 +0000",
  "in_reply_to_screen_name" : "blinry",
  "in_reply_to_user_id_str" : "53749209",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888839232722219009\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/TFCTJ35tC8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFXKjhYXoAA10WF.jpg",
      "id_str" : "888839213080354816",
      "id" : 888839213080354816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFXKjhYXoAA10WF.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/TFCTJ35tC8"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888838850990284801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0594146098714, 14.41954227503633 ]
  },
  "id_str" : "888839232722219009",
  "in_reply_to_user_id" : 14286491,
  "text" : "Czech vegetarian food.  #BOSC2017 https:\/\/t.co\/TFCTJ35tC8",
  "id" : 888839232722219009,
  "in_reply_to_status_id" : 888838850990284801,
  "created_at" : "2017-07-22 19:12:41 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 3, 13 ],
      "id_str" : "75261668",
      "id" : 75261668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/190sdeFMBH",
      "expanded_url" : "https:\/\/twitter.com\/malvikasharan\/status\/888733382368272384",
      "display_url" : "twitter.com\/malvikasharan\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "888839050102288384",
  "text" : "RT @npscience: We've had an incredible discussion about diversity and inclusion at #BOSC2017 1\/n https:\/\/t.co\/190sdeFMBH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 68, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/190sdeFMBH",
        "expanded_url" : "https:\/\/twitter.com\/malvikasharan\/status\/888733382368272384",
        "display_url" : "twitter.com\/malvikasharan\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "888797205968158722",
    "text" : "We've had an incredible discussion about diversity and inclusion at #BOSC2017 1\/n https:\/\/t.co\/190sdeFMBH",
    "id" : 888797205968158722,
    "created_at" : "2017-07-22 16:25:41 +0000",
    "user" : {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "protected" : false,
      "id_str" : "75261668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473846126341140480\/jSM4hSgv_normal.jpeg",
      "id" : 75261668,
      "verified" : false
    }
  },
  "id" : 888839050102288384,
  "created_at" : "2017-07-22 19:11:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/xuVyx7s4Yx",
      "expanded_url" : "https:\/\/twitter.com\/pjacock\/status\/888811456791269376",
      "display_url" : "twitter.com\/pjacock\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "888783736434774016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05940212395542, 14.41951243957876 ]
  },
  "id_str" : "888838850990284801",
  "in_reply_to_user_id" : 14286491,
  "text" : "And not only #BOSC2017, we accidentally took another group with us. \uD83D\uDE02 https:\/\/t.co\/xuVyx7s4Yx",
  "id" : 888838850990284801,
  "in_reply_to_status_id" : 888783736434774016,
  "created_at" : "2017-07-22 19:11:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc RobinsonRechavi",
      "screen_name" : "marc_rr",
      "indices" : [ 0, 8 ],
      "id_str" : "454724555",
      "id" : 454724555
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888800788239323141\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/l19S7S4eE7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFWnl6ZWsAAcajd.jpg",
      "id_str" : "888800771248140288",
      "id" : 888800771248140288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFWnl6ZWsAAcajd.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/l19S7S4eE7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06262043573228, 14.42902515036559 ]
  },
  "id_str" : "888800788239323141",
  "in_reply_to_user_id" : 454724555,
  "text" : "@marc_rr drop by here, this might be of interest to you :) https:\/\/t.co\/l19S7S4eE7",
  "id" : 888800788239323141,
  "created_at" : "2017-07-22 16:39:55 +0000",
  "in_reply_to_screen_name" : "marc_rr",
  "in_reply_to_user_id_str" : "454724555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/wSVBjB6hjv",
      "expanded_url" : "https:\/\/gyrosco.pe\/gedankenstuecke\/helix\/",
      "display_url" : "gyrosco.pe\/gedankenstueck\u2026"
    }, {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/6ZIpj013He",
      "expanded_url" : "https:\/\/opensnp.org\/users\/1",
      "display_url" : "opensnp.org\/users\/1"
    }, {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/bGbXws1y84",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/888779332721803265",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "888781814906724354",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06127802338086, 14.42899598539307 ]
  },
  "id_str" : "888783736434774016",
  "in_reply_to_user_id" : 14286491,
  "text" : "If you want to have a look what I\u2019m actually sharing: https:\/\/t.co\/wSVBjB6hjv &amp; https:\/\/t.co\/6ZIpj013He \uD83D\uDE02 #BOSC2017 https:\/\/t.co\/bGbXws1y84",
  "id" : 888783736434774016,
  "in_reply_to_status_id" : 888781814906724354,
  "created_at" : "2017-07-22 15:32:10 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana #hcsm #OpenAPS",
      "screen_name" : "danamlewis",
      "indices" : [ 0, 11 ],
      "id_str" : "15165858",
      "id" : 15165858
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 12, 21 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888781404624089088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06208090351323, 14.42896968608434 ]
  },
  "id_str" : "888781907646976001",
  "in_reply_to_user_id" : 15165858,
  "text" : "@danamlewis @madprime you should watch the video that will be available after the conference!",
  "id" : 888781907646976001,
  "in_reply_to_status_id" : 888781404624089088,
  "created_at" : "2017-07-22 15:24:54 +0000",
  "in_reply_to_screen_name" : "danamlewis",
  "in_reply_to_user_id_str" : "15165858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/v14aXiTzKy",
      "expanded_url" : "https:\/\/twitter.com\/MalvikaSharan\/status\/888781150805688321",
      "display_url" : "twitter.com\/MalvikaSharan\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "888781083092946944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06208090351323, 14.42896968608434 ]
  },
  "id_str" : "888781814906724354",
  "in_reply_to_user_id" : 14286491,
  "text" : "Tell me about it \uD83D\uDE02 #BOSC2017 https:\/\/t.co\/v14aXiTzKy",
  "id" : 888781814906724354,
  "in_reply_to_status_id" : 888781083092946944,
  "created_at" : "2017-07-22 15:24:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888780690304765952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06201480846741, 14.42903567442565 ]
  },
  "id_str" : "888781083092946944",
  "in_reply_to_user_id" : 14286491,
  "text" : "Open* does not only make things more efficient\/reproducible, it empowers. It enables completely new and beautiful things. #BOSC2017",
  "id" : 888781083092946944,
  "in_reply_to_status_id" : 888780690304765952,
  "created_at" : "2017-07-22 15:21:37 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malvika Sharan",
      "screen_name" : "MalvikaSharan",
      "indices" : [ 0, 14 ],
      "id_str" : "1612233594",
      "id" : 1612233594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888780296430268416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06201480846741, 14.42903567442565 ]
  },
  "id_str" : "888780913756307456",
  "in_reply_to_user_id" : 1612233594,
  "text" : "@MalvikaSharan Well, all the other data is already out there. ;)",
  "id" : 888780913756307456,
  "in_reply_to_status_id" : 888780296430268416,
  "created_at" : "2017-07-22 15:20:57 +0000",
  "in_reply_to_screen_name" : "MalvikaSharan",
  "in_reply_to_user_id_str" : "1612233594",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/kFKgYCaBMJ",
      "expanded_url" : "https:\/\/www.openhumans.org\/jobs\/",
      "display_url" : "openhumans.org\/jobs\/"
    } ]
  },
  "in_reply_to_status_id_str" : "888780555529199617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06223753393053, 14.42905053509863 ]
  },
  "id_str" : "888780690304765952",
  "in_reply_to_user_id" : 14286491,
  "text" : "If you want to work on Open Humans as a developer, there\u2019s a job: https:\/\/t.co\/kFKgYCaBMJ #BOSC2017",
  "id" : 888780690304765952,
  "in_reply_to_status_id" : 888780555529199617,
  "created_at" : "2017-07-22 15:20:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/WTuUmaa5jv",
      "expanded_url" : "http:\/\/openhumans.org\/grants",
      "display_url" : "openhumans.org\/grants"
    } ]
  },
  "in_reply_to_status_id_str" : "888780063331799040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06223753393053, 14.42905053509863 ]
  },
  "id_str" : "888780555529199617",
  "in_reply_to_user_id" : 14286491,
  "text" : "You want to build something for Open Humans? There are small USD 5,000 grants! https:\/\/t.co\/WTuUmaa5jv #BOSC2017",
  "id" : 888780555529199617,
  "in_reply_to_status_id" : 888780063331799040,
  "created_at" : "2017-07-22 15:19:31 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana #hcsm #OpenAPS",
      "screen_name" : "danamlewis",
      "indices" : [ 14, 25 ],
      "id_str" : "15165858",
      "id" : 15165858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888779813506486273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06180650493402, 14.42905754180828 ]
  },
  "id_str" : "888780063331799040",
  "in_reply_to_user_id" : 14286491,
  "text" : "Hearing about @danamlewis hacked her own Open Artificial Pancreas. \uD83D\uDC96  #BOSC2017",
  "id" : 888780063331799040,
  "in_reply_to_status_id" : 888779813506486273,
  "created_at" : "2017-07-22 15:17:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/bGbXws1y84",
      "expanded_url" : "https:\/\/twitter.com\/GigaScience\/status\/888779332721803265",
      "display_url" : "twitter.com\/GigaScience\/st\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "888779653053382658",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06224319737372, 14.42905162730447 ]
  },
  "id_str" : "888779813506486273",
  "in_reply_to_user_id" : 14286491,
  "text" : "Please take my genome, my biological traits and my location data. But my Google Search History? \uD83E\uDD14 #BOSC2017 https:\/\/t.co\/bGbXws1y84",
  "id" : 888779813506486273,
  "in_reply_to_status_id" : 888779653053382658,
  "created_at" : "2017-07-22 15:16:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana #hcsm #OpenAPS",
      "screen_name" : "danamlewis",
      "indices" : [ 23, 34 ],
      "id_str" : "15165858",
      "id" : 15165858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Z0NOKy3q83",
      "expanded_url" : "https:\/\/openaps.org\/",
      "display_url" : "openaps.org"
    } ]
  },
  "in_reply_to_status_id_str" : "888778308678283265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06224319737372, 14.42905162730447 ]
  },
  "id_str" : "888779653053382658",
  "in_reply_to_user_id" : 14286491,
  "text" : "A big big shout-out to @danamlewis, who built the awesome openAPS! https:\/\/t.co\/Z0NOKy3q83 #BOSC2017",
  "id" : 888779653053382658,
  "in_reply_to_status_id" : 888778308678283265,
  "created_at" : "2017-07-22 15:15:56 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888777947213115393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06224710365775, 14.42905343208211 ]
  },
  "id_str" : "888778308678283265",
  "in_reply_to_user_id" : 14286491,
  "text" : "Open Humans allows sharing data between studies, facilitates re-use, can lighten the load on participants.  #BOSC2017",
  "id" : 888778308678283265,
  "in_reply_to_status_id" : 888777947213115393,
  "created_at" : "2017-07-22 15:10:36 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888777493272039424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06224710365775, 14.42905343208211 ]
  },
  "id_str" : "888777947213115393",
  "in_reply_to_user_id" : 14286491,
  "text" : "Great participants on Open Humans:  A data source was not supported, they coded the support for it themselves. #BOSC2017",
  "id" : 888777947213115393,
  "in_reply_to_status_id" : 888777493272039424,
  "created_at" : "2017-07-22 15:09:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888777231169970178",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06217591260185, 14.42903812103941 ]
  },
  "id_str" : "888777493272039424",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABData is not a zero sum game.\u00BB Word! #BOSC2017",
  "id" : 888777493272039424,
  "in_reply_to_status_id" : 888777231169970178,
  "created_at" : "2017-07-22 15:07:21 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888776996259602432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06217591260185, 14.42903812103941 ]
  },
  "id_str" : "888777231169970178",
  "in_reply_to_user_id" : 14286491,
  "text" : "The solution to end the gatekeeping: ask individuals, but they are hard to reach, standing on the sidewalk with a sign takes time. #BOSC2017",
  "id" : 888777231169970178,
  "in_reply_to_status_id" : 888776996259602432,
  "created_at" : "2017-07-22 15:06:19 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888776789660758016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06217591260185, 14.42903812103941 ]
  },
  "id_str" : "888776996259602432",
  "in_reply_to_user_id" : 14286491,
  "text" : "In the current model data holders (researchers + corporations) are ultimate gatekeepers. #BOSC2017",
  "id" : 888776996259602432,
  "in_reply_to_status_id" : 888776789660758016,
  "created_at" : "2017-07-22 15:05:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888776035986178048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06215429742083, 14.42902891441478 ]
  },
  "id_str" : "888776789660758016",
  "in_reply_to_user_id" : 14286491,
  "text" : "The idea of Open Humans: center data on individuals. #BOSC2017",
  "id" : 888776789660758016,
  "in_reply_to_status_id" : 888776035986178048,
  "created_at" : "2017-07-22 15:04:33 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 96, 105 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888775582321913856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06188633001028, 14.42906118954913 ]
  },
  "id_str" : "888776035986178048",
  "in_reply_to_user_id" : 14286491,
  "text" : "Amongst PGP + openSNP there are over 3,500 public data sets. #BOSC2017 (thanks for the shoutout @madprime!)",
  "id" : 888776035986178048,
  "in_reply_to_status_id" : 888775582321913856,
  "created_at" : "2017-07-22 15:01:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888775386808668161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0621529595295, 14.42903701852265 ]
  },
  "id_str" : "888775582321913856",
  "in_reply_to_user_id" : 14286491,
  "text" : "For some data types, only few people want to share their data. The more sensitive, the less people you\u2019ll find. #BOSC2017",
  "id" : 888775582321913856,
  "in_reply_to_status_id" : 888775386808668161,
  "created_at" : "2017-07-22 14:59:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888774440498200577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06189947246507, 14.42906142249821 ]
  },
  "id_str" : "888775386808668161",
  "in_reply_to_user_id" : 14286491,
  "text" : "Larger lessons from the PGP: It\u2019s not only genetic data, e.g. location data is a) super sensitive b) useful for research #BOSC2017",
  "id" : 888775386808668161,
  "in_reply_to_status_id" : 888774440498200577,
  "created_at" : "2017-07-22 14:58:59 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yoyehudi\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "yoyehudi",
      "indices" : [ 0, 9 ],
      "id_str" : "1073388199",
      "id" : 1073388199
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 10, 19 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/IVv8HGQmWB",
      "expanded_url" : "https:\/\/www.openhumans.org\/",
      "display_url" : "openhumans.org"
    }, {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/bdwjvS1Qxm",
      "expanded_url" : "https:\/\/opensnp.org",
      "display_url" : "opensnp.org"
    } ]
  },
  "in_reply_to_status_id_str" : "888773734101856256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0619084883846, 14.42906237588038 ]
  },
  "id_str" : "888774791578210304",
  "in_reply_to_user_id" : 1073388199,
  "text" : "@yoyehudi @madprime i\u2019m sure that\u2019ll come later. Otherwise you can head to https:\/\/t.co\/IVv8HGQmWB and https:\/\/t.co\/bdwjvS1Qxm right away. ;)",
  "id" : 888774791578210304,
  "in_reply_to_status_id" : 888773734101856256,
  "created_at" : "2017-07-22 14:56:37 +0000",
  "in_reply_to_screen_name" : "yoyehudi",
  "in_reply_to_user_id_str" : "1073388199",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888774159190380544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0619084883846, 14.42906237588038 ]
  },
  "id_str" : "888774440498200577",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u201EWe all are carriers for recessive diseases. It\u2019s not a big deal\u201C #BOSC2017",
  "id" : 888774440498200577,
  "in_reply_to_status_id" : 888774159190380544,
  "created_at" : "2017-07-22 14:55:13 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 82, 91 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888773852481847296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0619084883846, 14.42906237588038 ]
  },
  "id_str" : "888774159190380544",
  "in_reply_to_user_id" : 14286491,
  "text" : "Be thankful to your research participants. They do a lot of work to enable yours. @madprime #BOSC2017",
  "id" : 888774159190380544,
  "in_reply_to_status_id" : 888773852481847296,
  "created_at" : "2017-07-22 14:54:06 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888773623435210752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06223717267311, 14.42904941898911 ]
  },
  "id_str" : "888773852481847296",
  "in_reply_to_user_id" : 14286491,
  "text" : "The PGP community modulated their own interactions, a participant set up a forum to enable exchange between participants. #BOSC2017",
  "id" : 888773852481847296,
  "in_reply_to_status_id" : 888773623435210752,
  "created_at" : "2017-07-22 14:52:53 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888773355209457664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06223717267311, 14.42904941898911 ]
  },
  "id_str" : "888773623435210752",
  "in_reply_to_user_id" : 14286491,
  "text" : "One frequently asked questions by PGP participants: How can they give and receive data. #BOSC2017",
  "id" : 888773623435210752,
  "in_reply_to_status_id" : 888773355209457664,
  "created_at" : "2017-07-22 14:51:59 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888773138640666625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06223717267311, 14.42904941898911 ]
  },
  "id_str" : "888773355209457664",
  "in_reply_to_user_id" : 14286491,
  "text" : "Another rare thing: The PGP returned the genetic data they generated to participants, with reports. #BOSC2017",
  "id" : 888773355209457664,
  "in_reply_to_status_id" : 888773138640666625,
  "created_at" : "2017-07-22 14:50:55 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888772834432102400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0622302189204, 14.42904680806586 ]
  },
  "id_str" : "888773138640666625",
  "in_reply_to_user_id" : 14286491,
  "text" : "The PGP formed a close relationship with their participants, unlike most scientific projects. #BOSC2017",
  "id" : 888773138640666625,
  "in_reply_to_status_id" : 888772834432102400,
  "created_at" : "2017-07-22 14:50:03 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 71, 80 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888772218108465152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0622302189204, 14.42904680806586 ]
  },
  "id_str" : "888772834432102400",
  "in_reply_to_user_id" : 14286491,
  "text" : "#BOSC2017 is getting a brief history on the Personal Genome Project by @madprime. Biggest impact: Not genetic, but ethics, legal, societal.",
  "id" : 888772834432102400,
  "in_reply_to_status_id" : 888772218108465152,
  "created_at" : "2017-07-22 14:48:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888771905209192451",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06153368516984, 14.42907085169967 ]
  },
  "id_str" : "888772218108465152",
  "in_reply_to_user_id" : 14286491,
  "text" : "Sharing feels good, open systems can win. Lessons learned from contributing to Wikipedia #BOSC2017",
  "id" : 888772218108465152,
  "in_reply_to_status_id" : 888771905209192451,
  "created_at" : "2017-07-22 14:46:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888771456229933057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06158229420165, 14.4290233764834 ]
  },
  "id_str" : "888771905209192451",
  "in_reply_to_user_id" : 14286491,
  "text" : "Her most important contribution to open knowledge: uploading 3 cat pictures to Wikipedia. #BOSC2017",
  "id" : 888771905209192451,
  "in_reply_to_status_id" : 888771456229933057,
  "created_at" : "2017-07-22 14:45:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 66, 75 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06155824419923, 14.42902111189297 ]
  },
  "id_str" : "888771456229933057",
  "text" : "\u201CIt all started when I found something wrong on the internet\u201D how @madprime got into all of this. #BOSC2017",
  "id" : 888771456229933057,
  "created_at" : "2017-07-22 14:43:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 19, 28 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06153964496836, 14.42901797618404 ]
  },
  "id_str" : "888769789879037952",
  "text" : "Looking forward to @madprime\u2019s keynote about open sourcing ourselves. #BOSC2017",
  "id" : 888769789879037952,
  "created_at" : "2017-07-22 14:36:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Brueffer",
      "screen_name" : "cbrueffer",
      "indices" : [ 0, 10 ],
      "id_str" : "2475490934",
      "id" : 2475490934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888768947247603712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06144565659768, 14.42901564421188 ]
  },
  "id_str" : "888769453059715072",
  "in_reply_to_user_id" : 2475490934,
  "text" : "@cbrueffer I hear you! But I do have to agree that the scalability is better this way :)",
  "id" : 888769453059715072,
  "in_reply_to_status_id" : 888768947247603712,
  "created_at" : "2017-07-22 14:35:24 +0000",
  "in_reply_to_screen_name" : "cbrueffer",
  "in_reply_to_user_id_str" : "2475490934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/AuHezP7lTi",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888758550046138369",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "888758550046138369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06175864099281, 14.42875492926037 ]
  },
  "id_str" : "888759105682366464",
  "in_reply_to_user_id" : 14286491,
  "text" : "The cutest\/funniest part about the new logo: the long discussion about major\/minor grooves during the design process. #BOSC2017 https:\/\/t.co\/AuHezP7lTi",
  "id" : 888759105682366464,
  "in_reply_to_status_id" : 888758550046138369,
  "created_at" : "2017-07-22 13:54:17 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888758550046138369\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/fsZr5lpcbm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFWBLdjWAAAwZEn.jpg",
      "id_str" : "888758535386955776",
      "id" : 888758535386955776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFWBLdjWAAAwZEn.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/fsZr5lpcbm"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06149083498444, 14.42872316709597 ]
  },
  "id_str" : "888758550046138369",
  "text" : "The most important update about biopython: it has a beautiful new logo! #BOSC2017 https:\/\/t.co\/fsZr5lpcbm",
  "id" : 888758550046138369,
  "created_at" : "2017-07-22 13:52:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888751114958589952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06212464368539, 14.42905768936454 ]
  },
  "id_str" : "888751802279186433",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick It\u2019s \uD83D\uDC33s all the way down.",
  "id" : 888751802279186433,
  "in_reply_to_status_id" : 888751114958589952,
  "created_at" : "2017-07-22 13:25:16 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06224452663571, 14.42905332649222 ]
  },
  "id_str" : "888748687157022720",
  "text" : "#BOSC2017 is getting a German lesson: \u00ABDer Teufel ist ein Eichh\u00F6rnchen\u00BB (the devil is a squirrel).",
  "id" : 888748687157022720,
  "created_at" : "2017-07-22 13:12:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herv\u00E9 M\u00E9nager",
      "screen_name" : "rvmngr",
      "indices" : [ 0, 7 ],
      "id_str" : "632591287",
      "id" : 632591287
    }, {
      "name" : "Bj\u00F6rn Gr\u00FCning",
      "screen_name" : "bjoerngruening",
      "indices" : [ 8, 23 ],
      "id_str" : "117360280",
      "id" : 117360280
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888747567038779392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06224206827101, 14.42905278051406 ]
  },
  "id_str" : "888747758647201792",
  "in_reply_to_user_id" : 632591287,
  "text" : "@rvmngr @bjoerngruening somehow the CPAN logo reminds me vaguely of the \uD83D\uDCA9 emoji. #BOSC2017",
  "id" : 888747758647201792,
  "in_reply_to_status_id" : 888747567038779392,
  "created_at" : "2017-07-22 13:09:12 +0000",
  "in_reply_to_screen_name" : "rvmngr",
  "in_reply_to_user_id_str" : "632591287",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Gr\u00FCning",
      "screen_name" : "bjoerngruening",
      "indices" : [ 41, 56 ],
      "id_str" : "117360280",
      "id" : 117360280
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06242318797228, 14.42912561770085 ]
  },
  "id_str" : "888746786109706240",
  "text" : "Can we build a FAIR tool infrastructure? @bjoerngruening at #BOSC2017",
  "id" : 888746786109706240,
  "created_at" : "2017-07-22 13:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2018",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "BOSC2017",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/Grq2c9TrU1",
      "expanded_url" : "https:\/\/twitter.com\/kaiblin\/status\/888745278982979584",
      "display_url" : "twitter.com\/kaiblin\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06208321400926, 14.42908213838261 ]
  },
  "id_str" : "888745698719674368",
  "text" : "Also: What will we do with all the time we will suddenly have at #BOSC2018? #BOSC2017 \uD83D\uDE02 https:\/\/t.co\/Grq2c9TrU1",
  "id" : 888745698719674368,
  "created_at" : "2017-07-22 13:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Chapman",
      "screen_name" : "chapmanb",
      "indices" : [ 4, 13 ],
      "id_str" : "18284047",
      "id" : 18284047
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06191800781909, 14.42909240761719 ]
  },
  "id_str" : "888744168167788544",
  "text" : "Now @chapmanb about Interoperable, collaborative multi-platform variant calling. #BOSC2017",
  "id" : 888744168167788544,
  "created_at" : "2017-07-22 12:54:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Taylor \uD83E\uDD16 \uD83C\uDF39",
      "screen_name" : "jxtx",
      "indices" : [ 0, 5 ],
      "id_str" : "22023030",
      "id" : 22023030
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 6, 20 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 21, 29 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888739864149209088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0617108969072, 14.42903206825761 ]
  },
  "id_str" : "888740106894544899",
  "in_reply_to_user_id" : 22023030,
  "text" : "@jxtx @BioMickWatson @kaiblin well, let me put it like this: I\u2019m like 3 months away from finishing my PhD.",
  "id" : 888740106894544899,
  "in_reply_to_status_id" : 888739864149209088,
  "created_at" : "2017-07-22 12:38:48 +0000",
  "in_reply_to_screen_name" : "jxtx",
  "in_reply_to_user_id_str" : "22023030",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 0, 14 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 15, 23 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 154, 163 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888738488157392900",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06226178230035, 14.42905369283279 ]
  },
  "id_str" : "888739227218964480",
  "in_reply_to_user_id" : 228586748,
  "text" : "@BioMickWatson @kaiblin I\u2019m one of those people. My open source work is \u201Emy personal entertainment\u201C according to my PI, so need to take vacation days for #BOSC2017",
  "id" : 888739227218964480,
  "in_reply_to_status_id" : 888738488157392900,
  "created_at" : "2017-07-22 12:35:18 +0000",
  "in_reply_to_screen_name" : "BioMickWatson",
  "in_reply_to_user_id_str" : "228586748",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Ewels",
      "screen_name" : "tallphil",
      "indices" : [ 43, 52 ],
      "id_str" : "21199534",
      "id" : 21199534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC17",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/6ikXyLl9lt",
      "expanded_url" : "http:\/\/multiqc.info\/",
      "display_url" : "multiqc.info"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06224350686249, 14.42905287475851 ]
  },
  "id_str" : "888736364354838528",
  "text" : "MultiQC looks so cool, thanks for the talk @tallphil! #BOSC17 https:\/\/t.co\/6ikXyLl9lt",
  "id" : 888736364354838528,
  "created_at" : "2017-07-22 12:23:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malvika Sharan",
      "screen_name" : "MalvikaSharan",
      "indices" : [ 3, 17 ],
      "id_str" : "1612233594",
      "id" : 1612233594
    }, {
      "name" : "ISCB News",
      "screen_name" : "iscb",
      "indices" : [ 47, 52 ],
      "id_str" : "96111619",
      "id" : 96111619
    }, {
      "name" : "Kieran O'Neill",
      "screen_name" : "oneillkza",
      "indices" : [ 101, 111 ],
      "id_str" : "100371111",
      "id" : 100371111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BoF",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "888733987514064896",
  "text" : "RT @MalvikaSharan: Thanks every1 including the @iscb directors for attending the #BoF. Big thanks to @oneillkza for taking the minutes: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ISCB News",
        "screen_name" : "iscb",
        "indices" : [ 28, 33 ],
        "id_str" : "96111619",
        "id" : 96111619
      }, {
        "name" : "Kieran O'Neill",
        "screen_name" : "oneillkza",
        "indices" : [ 82, 92 ],
        "id_str" : "100371111",
        "id" : 100371111
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MalvikaSharan\/status\/888733382368272384\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/VRMsktywmE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DFVqS2NXYAAAoUg.jpg",
        "id_str" : "888733373497303040",
        "id" : 888733373497303040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFVqS2NXYAAAoUg.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/VRMsktywmE"
      } ],
      "hashtags" : [ {
        "text" : "BoF",
        "indices" : [ 62, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/37pFHoI7lt",
        "expanded_url" : "https:\/\/piratenpad.de\/p\/BoF_diversity",
        "display_url" : "piratenpad.de\/p\/BoF_diversity"
      } ]
    },
    "in_reply_to_status_id_str" : "888702309672288256",
    "geo" : { },
    "id_str" : "888733382368272384",
    "in_reply_to_user_id" : 1612233594,
    "text" : "Thanks every1 including the @iscb directors for attending the #BoF. Big thanks to @oneillkza for taking the minutes: https:\/\/t.co\/37pFHoI7lt https:\/\/t.co\/VRMsktywmE",
    "id" : 888733382368272384,
    "in_reply_to_status_id" : 888702309672288256,
    "created_at" : "2017-07-22 12:12:04 +0000",
    "in_reply_to_screen_name" : "MalvikaSharan",
    "in_reply_to_user_id_str" : "1612233594",
    "user" : {
      "name" : "Malvika Sharan",
      "screen_name" : "MalvikaSharan",
      "protected" : false,
      "id_str" : "1612233594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/901705228906614785\/H190YCTI_normal.jpg",
      "id" : 1612233594,
      "verified" : false
    }
  },
  "id" : 888733987514064896,
  "created_at" : "2017-07-22 12:14:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 0, 10 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888730750446706688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06244898158717, 14.42791066318368 ]
  },
  "id_str" : "888730818151108609",
  "in_reply_to_user_id" : 176024190,
  "text" : "@SCEdmunds Looks like it. It\u2019s still at the sticker table :)",
  "id" : 888730818151108609,
  "in_reply_to_status_id" : 888730750446706688,
  "created_at" : "2017-07-22 12:01:53 +0000",
  "in_reply_to_screen_name" : "SCEdmunds",
  "in_reply_to_user_id_str" : "176024190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Edmunds",
      "screen_name" : "SCEdmunds",
      "indices" : [ 52, 62 ],
      "id_str" : "176024190",
      "id" : 176024190
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888716116297744384\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/hNGX70ntMj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFVajikWsAA4HSO.jpg",
      "id_str" : "888716068096749568",
      "id" : 888716068096749568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFVajikWsAA4HSO.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/hNGX70ntMj"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0615562727438, 14.42902238130788 ]
  },
  "id_str" : "888716116297744384",
  "text" : "I did some time travel and ended up with a 80\u2032s era @SCEdmunds! #BOSC2017 https:\/\/t.co\/hNGX70ntMj",
  "id" : 888716116297744384,
  "created_at" : "2017-07-22 11:03:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888680741634179072\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/2uzbxJakkU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFU6aQoXUAIoxSL.jpg",
      "id_str" : "888680724290818050",
      "id" : 888680724290818050,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFU6aQoXUAIoxSL.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/2uzbxJakkU"
    } ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "BOSC2017",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06157566457652, 14.42901966747732 ]
  },
  "id_str" : "888680741634179072",
  "text" : "You enjoyed the #mozsprint? Have a look at the CodeFest. And the same vice versa. \u263A\uFE0F #BOSC2017 https:\/\/t.co\/2uzbxJakkU",
  "id" : 888680741634179072,
  "created_at" : "2017-07-22 08:42:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/8UDqBBhaG0",
      "expanded_url" : "https:\/\/github.com\/obf\/gsoc",
      "display_url" : "github.com\/obf\/gsoc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06158373633455, 14.42901898740265 ]
  },
  "id_str" : "888678585866874881",
  "text" : "People are already collecting ideas for a potential 2018 Google Summer of Code! https:\/\/t.co\/8UDqBBhaG0 #BOSC2017",
  "id" : 888678585866874881,
  "created_at" : "2017-07-22 08:34:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 3, 13 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HLWiencko\/status\/888678039781036033\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/C28TNNFS8k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFU3670XoAAgE1u.jpg",
      "id_str" : "888677987104825344",
      "id" : 888677987104825344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFU3670XoAAgE1u.jpg",
      "sizes" : [ {
        "h" : 417,
        "resize" : "fit",
        "w" : 449
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 449
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 449
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 449
      } ],
      "display_url" : "pic.twitter.com\/C28TNNFS8k"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "888678139936870400",
  "text" : "RT @HLWiencko: Well played. #BOSC2017 totally has wifi. https:\/\/t.co\/C28TNNFS8k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HLWiencko\/status\/888678039781036033\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/C28TNNFS8k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DFU3670XoAAgE1u.jpg",
        "id_str" : "888677987104825344",
        "id" : 888677987104825344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFU3670XoAAgE1u.jpg",
        "sizes" : [ {
          "h" : 417,
          "resize" : "fit",
          "w" : 449
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 449
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 449
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 449
        } ],
        "display_url" : "pic.twitter.com\/C28TNNFS8k"
      } ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 13, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "888678039781036033",
    "text" : "Well played. #BOSC2017 totally has wifi. https:\/\/t.co\/C28TNNFS8k",
    "id" : 888678039781036033,
    "created_at" : "2017-07-22 08:32:10 +0000",
    "user" : {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "protected" : false,
      "id_str" : "2657942712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/490274907117215746\/GBit7UNq_normal.jpeg",
      "id" : 2657942712,
      "verified" : false
    }
  },
  "id" : 888678139936870400,
  "created_at" : "2017-07-22 08:32:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 50, 58 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888677940468346881\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/f4cMsWFxD3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFU33Y3XkAQ7-Ql.jpg",
      "id_str" : "888677926182555652",
      "id" : 888677926182555652,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFU33Y3XkAQ7-Ql.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/f4cMsWFxD3"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06159456686049, 14.42902181784373 ]
  },
  "id_str" : "888677940468346881",
  "text" : "Hearing the 2016 Google Summer of Code wrap up by @kaiblin #BOSC2017 https:\/\/t.co\/f4cMsWFxD3",
  "id" : 888677940468346881,
  "created_at" : "2017-07-22 08:31:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/IsYrLU828c",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/888673455910137856",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06127521737588, 14.42899708783298 ]
  },
  "id_str" : "888674985396588545",
  "text" : "Bioinformaticians and Counting, two worlds collide. #BOSC2017 \uD83D\uDE09 https:\/\/t.co\/IsYrLU828c",
  "id" : 888674985396588545,
  "created_at" : "2017-07-22 08:20:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilmar Lapp",
      "screen_name" : "hlapp",
      "indices" : [ 48, 54 ],
      "id_str" : "19042414",
      "id" : 19042414
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888674669246779392\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/032xvQGpS3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFU049vXgAADMDE.jpg",
      "id_str" : "888674654726094848",
      "id" : 888674654726094848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFU049vXgAADMDE.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/032xvQGpS3"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0612740843743, 14.4289973326376 ]
  },
  "id_str" : "888674669246779392",
  "text" : "Introducing the Open Bioinformatics Foundation, @hlapp #BOSC2017 https:\/\/t.co\/032xvQGpS3",
  "id" : 888674669246779392,
  "created_at" : "2017-07-22 08:18:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06127353912876, 14.42899662562333 ]
  },
  "id_str" : "888674364702547969",
  "text" : "It\u2019s the first #BOSC2017 for more than half of the participants! Welcome! \uD83C\uDF89\uD83D\uDC96",
  "id" : 888674364702547969,
  "created_at" : "2017-07-22 08:17:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 5, 16 ],
      "id_str" : "351049850",
      "id" : 351049850
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888671381155696640\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/8a4QfISoF7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFUx5ivXcAEecA8.jpg",
      "id_str" : "888671366123319297",
      "id" : 888671366123319297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFUx5ivXcAEecA8.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8a4QfISoF7"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06127113013388, 14.42899677353501 ]
  },
  "id_str" : "888671381155696640",
  "text" : "Now: @NomiHarris kicking off #BOSC2017 https:\/\/t.co\/8a4QfISoF7",
  "id" : 888671381155696640,
  "created_at" : "2017-07-22 08:05:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888642318458384384\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/wx3uj8uNig",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFUXd08XkAAijuY.jpg",
      "id_str" : "888642302671032320",
      "id" : 888642302671032320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFUXd08XkAAijuY.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/wx3uj8uNig"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06276217202132, 14.42886018206442 ]
  },
  "id_str" : "888642318458384384",
  "text" : "And we\u2019re ready to present at #BOSC2017 \uD83D\uDE02 https:\/\/t.co\/wx3uj8uNig",
  "id" : 888642318458384384,
  "created_at" : "2017-07-22 06:10:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 9, 21 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Ethan White",
      "screen_name" : "ethanwhite",
      "indices" : [ 22, 33 ],
      "id_str" : "34540379",
      "id" : 34540379
    }, {
      "name" : "figshare",
      "screen_name" : "figshare",
      "indices" : [ 34, 43 ],
      "id_str" : "224631899",
      "id" : 224631899
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888423430273585152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06296832976157, 14.43194274443408 ]
  },
  "id_str" : "888516389367160833",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @ctitusbrown @ethanwhite @figshare Oh no, poor him. That\u2019s you got me as well. \uD83D\uDE02",
  "id" : 888516389367160833,
  "in_reply_to_status_id" : 888423430273585152,
  "created_at" : "2017-07-21 21:49:49 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/888427283249324032\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/IJzyVRcma9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DFRT5eaWsAAKSO6.jpg",
      "id_str" : "888427273380081664",
      "id" : 888427273380081664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DFRT5eaWsAAKSO6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IJzyVRcma9"
    } ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083133938782, 14.43164735663451 ]
  },
  "id_str" : "888427283249324032",
  "text" : "All set now. \uD83E\uDD89#BOSC2017 https:\/\/t.co\/IJzyVRcma9",
  "id" : 888427283249324032,
  "created_at" : "2017-07-21 15:55:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 3, 18 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    }, {
      "name" : "Mozilla Open Leaders",
      "screen_name" : "MozOpenLeaders",
      "indices" : [ 58, 73 ],
      "id_str" : "791070237949034496",
      "id" : 791070237949034496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "888313830505406468",
  "text" : "RT @MozillaScience: Working openly? Bring your project to @MozOpenLeaders for mentorship &amp; training on open practices \nhttps:\/\/t.co\/nJI1t8F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mozilla Open Leaders",
        "screen_name" : "MozOpenLeaders",
        "indices" : [ 38, 53 ],
        "id_str" : "791070237949034496",
        "id" : 791070237949034496
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/nJI1t8FppJ",
        "expanded_url" : "http:\/\/bit.ly\/2uG02UD",
        "display_url" : "bit.ly\/2uG02UD"
      } ]
    },
    "geo" : { },
    "id_str" : "888044723117580288",
    "text" : "Working openly? Bring your project to @MozOpenLeaders for mentorship &amp; training on open practices \nhttps:\/\/t.co\/nJI1t8FppJ #openscience",
    "id" : 888044723117580288,
    "created_at" : "2017-07-20 14:35:35 +0000",
    "user" : {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "protected" : false,
      "id_str" : "1428575976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687287790049034240\/lwIk-ZQT_normal.png",
      "id" : 1428575976,
      "verified" : false
    }
  },
  "id" : 888313830505406468,
  "created_at" : "2017-07-21 08:24:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 141, 164 ],
      "url" : "https:\/\/t.co\/EaVgHoanfD",
      "expanded_url" : "https:\/\/twitter.com\/dhimmel\/status\/888205662655852544",
      "display_url" : "twitter.com\/dhimmel\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04528029977764, 8.562470427960365 ]
  },
  "id_str" : "888313345530638336",
  "text" : "Who wouldn\u2019t want to collaborate with the person who\u2019s famous for running out of a bar, screaming \u201CI have to submit a preprint\u201D at #opencon? https:\/\/t.co\/EaVgHoanfD",
  "id" : 888313345530638336,
  "created_at" : "2017-07-21 08:23:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0475717372959, 8.560942732968932 ]
  },
  "id_str" : "888296192869883904",
  "text" : "Now: FRA \u2708\uFE0F PRG for #BOSC2017 \uD83C\uDF89",
  "id" : 888296192869883904,
  "created_at" : "2017-07-21 07:14:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "888286643597201408",
  "text" : "RT @gedankenstuecke: And here\u2019s the second pre-print\/article out for this day: Sci-Hub provides access to nearly all scholarly literature h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/zh0Gjs72AL",
        "expanded_url" : "https:\/\/peerj.com\/preprints\/3100\/",
        "display_url" : "peerj.com\/preprints\/3100\/"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.1139924764456, 8.753331087182044 ]
    },
    "id_str" : "888159151339311104",
    "text" : "And here\u2019s the second pre-print\/article out for this day: Sci-Hub provides access to nearly all scholarly literature https:\/\/t.co\/zh0Gjs72AL",
    "id" : 888159151339311104,
    "created_at" : "2017-07-20 22:10:17 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 888286643597201408,
  "created_at" : "2017-07-21 06:36:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/zh0Gjs72AL",
      "expanded_url" : "https:\/\/peerj.com\/preprints\/3100\/",
      "display_url" : "peerj.com\/preprints\/3100\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139924764456, 8.753331087182044 ]
  },
  "id_str" : "888159151339311104",
  "text" : "And here\u2019s the second pre-print\/article out for this day: Sci-Hub provides access to nearly all scholarly literature https:\/\/t.co\/zh0Gjs72AL",
  "id" : 888159151339311104,
  "created_at" : "2017-07-20 22:10:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "888109354834042880",
  "text" : "RT @gedankenstuecke: Look what just hit F1000Research: A multi-disciplinary perspective on emergent &amp; future innovations in peer review htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/ZILdBvLzNY",
        "expanded_url" : "https:\/\/f1000research.com\/articles\/6-1151\/v1",
        "display_url" : "f1000research.com\/articles\/6-115\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.17234172691566, 8.627524505319167 ]
    },
    "id_str" : "887968883788967936",
    "text" : "Look what just hit F1000Research: A multi-disciplinary perspective on emergent &amp; future innovations in peer review https:\/\/t.co\/ZILdBvLzNY",
    "id" : 887968883788967936,
    "created_at" : "2017-07-20 09:34:14 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 888109354834042880,
  "created_at" : "2017-07-20 18:52:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888105509953298432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392955111186, 8.753065791762575 ]
  },
  "id_str" : "888108767203663873",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam I think that\u2019s called a bruster-fuck.",
  "id" : 888108767203663873,
  "in_reply_to_status_id" : 888105509953298432,
  "created_at" : "2017-07-20 18:50:05 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lauren B. Collister",
      "screen_name" : "parnopaeus",
      "indices" : [ 15, 26 ],
      "id_str" : "76456521",
      "id" : 76456521
    }, {
      "name" : "Martin Paul Eve",
      "screen_name" : "martin_eve",
      "indices" : [ 27, 38 ],
      "id_str" : "118747590",
      "id" : 118747590
    }, {
      "name" : "F1000Research",
      "screen_name" : "F1000Research",
      "indices" : [ 39, 53 ],
      "id_str" : "59126394",
      "id" : 59126394
    }, {
      "name" : "Jonathan Dugan",
      "screen_name" : "JMDugan",
      "indices" : [ 54, 62 ],
      "id_str" : "14747526",
      "id" : 14747526
    }, {
      "name" : "Daniel Graziotin",
      "screen_name" : "dgraziotin",
      "indices" : [ 63, 74 ],
      "id_str" : "92842712",
      "id" : 92842712
    }, {
      "name" : "D\u24D0mien J\u24D0cques",
      "screen_name" : "jacques_damien",
      "indices" : [ 75, 90 ],
      "id_str" : "4866175114",
      "id" : 4866175114
    }, {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 91, 98 ],
      "id_str" : "15132914",
      "id" : 15132914
    }, {
      "name" : "Christina K. Pikas",
      "screen_name" : "cpikas",
      "indices" : [ 99, 106 ],
      "id_str" : "4761581",
      "id" : 4761581
    }, {
      "name" : "Prof. Tom Crick",
      "screen_name" : "ProfTomCrick",
      "indices" : [ 107, 120 ],
      "id_str" : "34956737",
      "id" : 34956737
    }, {
      "name" : "Paola Masuzzo",
      "screen_name" : "pcmasuzzo",
      "indices" : [ 121, 131 ],
      "id_str" : "438729858",
      "id" : 438729858
    }, {
      "name" : "Anthony Caravaggi \uD83C\uDF0E",
      "screen_name" : "thonoir",
      "indices" : [ 132, 140 ],
      "id_str" : "247426491",
      "id" : 247426491
    }, {
      "name" : "Devin Berg",
      "screen_name" : "devinberg",
      "indices" : [ 141, 151 ],
      "id_str" : "8133862",
      "id" : 8133862
    }, {
      "name" : "Kyle Niemeyer",
      "screen_name" : "kyleniemeyer",
      "indices" : [ 152, 165 ],
      "id_str" : "6607712",
      "id" : 6607712
    }, {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 166, 174 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Sara Mannheimer",
      "screen_name" : "saramannheimer",
      "indices" : [ 175, 190 ],
      "id_str" : "825610044",
      "id" : 825610044
    }, {
      "name" : "Lillian Rigling",
      "screen_name" : "lilyrglg",
      "indices" : [ 191, 200 ],
      "id_str" : "272099717",
      "id" : 272099717
    }, {
      "name" : "Daniel S. Katz",
      "screen_name" : "danielskatz",
      "indices" : [ 201, 213 ],
      "id_str" : "19238958",
      "id" : 19238958
    }, {
      "name" : "Josmel Pacheco",
      "screen_name" : "josmel1",
      "indices" : [ 214, 222 ],
      "id_str" : "54002739",
      "id" : 54002739
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 223, 237 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Marta Poblet \uD83C\uDF97\uFE0F",
      "screen_name" : "mpoblet",
      "indices" : [ 238, 246 ],
      "id_str" : "17893512",
      "id" : 17893512
    }, {
      "name" : "Marios Isaakidis",
      "screen_name" : "misaakidis",
      "indices" : [ 247, 258 ],
      "id_str" : "335255004",
      "id" : 335255004
    }, {
      "name" : "D\u24D0sapta Erwin Irawan",
      "screen_name" : "dasaptaerwin",
      "indices" : [ 259, 272 ],
      "id_str" : "225236194",
      "id" : 225236194
    }, {
      "name" : "sebastien renaut",
      "screen_name" : "seb_renaut",
      "indices" : [ 273, 284 ],
      "id_str" : "28158354",
      "id" : 28158354
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 285, 292 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 293, 303 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    }, {
      "name" : "Jesper N. Kjaer",
      "screen_name" : "JesperNKjaer",
      "indices" : [ 304, 317 ],
      "id_str" : "1460192682",
      "id" : 1460192682
    }, {
      "name" : "Daniel O'Donnell",
      "screen_name" : "DanielPaulOD",
      "indices" : [ 318, 331 ],
      "id_str" : "41965769",
      "id" : 41965769
    }, {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 332, 346 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "sarah k",
      "screen_name" : "annotated_sci",
      "indices" : [ 347, 361 ],
      "id_str" : "772816871179558913",
      "id" : 772816871179558913
    }, {
      "name" : "Manojkumar Selvaraju",
      "screen_name" : "manogenome",
      "indices" : [ 362, 373 ],
      "id_str" : "204877909",
      "id" : 204877909
    }, {
      "name" : "J. Colomb, @pen",
      "screen_name" : "j_colomb",
      "indices" : [ 374, 383 ],
      "id_str" : "9437692",
      "id" : 9437692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888064324509589506",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236530034485, 8.627491367239548 ]
  },
  "id_str" : "888064441446785024",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @parnopaeus @martin_eve @F1000Research @JMDugan @dgraziotin @jacques_damien @EvoMRI @cpikas @ProfTomCrick @pcmasuzzo @thonoir @devinberg @kyleniemeyer @tonyR_H @saramannheimer @lilyrglg @danielskatz @josmel1 @NazeefaFatima @mpoblet @misaakidis @dasaptaerwin @seb_renaut @cMadan @l_matthia @JesperNKjaer @DanielPaulOD @CameronNeylon @annotated_sci @manogenome @j_colomb on average everyone of us has 2 friends you mean? :P",
  "id" : 888064441446785024,
  "in_reply_to_status_id" : 888064324509589506,
  "created_at" : "2017-07-20 15:53:56 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren B. Collister",
      "screen_name" : "parnopaeus",
      "indices" : [ 0, 11 ],
      "id_str" : "76456521",
      "id" : 76456521
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 12, 26 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Martin Paul Eve",
      "screen_name" : "martin_eve",
      "indices" : [ 27, 38 ],
      "id_str" : "118747590",
      "id" : 118747590
    }, {
      "name" : "F1000Research",
      "screen_name" : "F1000Research",
      "indices" : [ 39, 53 ],
      "id_str" : "59126394",
      "id" : 59126394
    }, {
      "name" : "Jonathan Dugan",
      "screen_name" : "JMDugan",
      "indices" : [ 54, 62 ],
      "id_str" : "14747526",
      "id" : 14747526
    }, {
      "name" : "Daniel Graziotin",
      "screen_name" : "dgraziotin",
      "indices" : [ 63, 74 ],
      "id_str" : "92842712",
      "id" : 92842712
    }, {
      "name" : "D\u24D0mien J\u24D0cques",
      "screen_name" : "jacques_damien",
      "indices" : [ 75, 90 ],
      "id_str" : "4866175114",
      "id" : 4866175114
    }, {
      "name" : "D\u24D0niel Mietchen",
      "screen_name" : "EvoMRI",
      "indices" : [ 91, 98 ],
      "id_str" : "15132914",
      "id" : 15132914
    }, {
      "name" : "Christina K. Pikas",
      "screen_name" : "cpikas",
      "indices" : [ 99, 106 ],
      "id_str" : "4761581",
      "id" : 4761581
    }, {
      "name" : "Prof. Tom Crick",
      "screen_name" : "ProfTomCrick",
      "indices" : [ 107, 120 ],
      "id_str" : "34956737",
      "id" : 34956737
    }, {
      "name" : "Paola Masuzzo",
      "screen_name" : "pcmasuzzo",
      "indices" : [ 121, 131 ],
      "id_str" : "438729858",
      "id" : 438729858
    }, {
      "name" : "Anthony Caravaggi \uD83C\uDF0E",
      "screen_name" : "thonoir",
      "indices" : [ 132, 140 ],
      "id_str" : "247426491",
      "id" : 247426491
    }, {
      "name" : "Devin Berg",
      "screen_name" : "devinberg",
      "indices" : [ 141, 151 ],
      "id_str" : "8133862",
      "id" : 8133862
    }, {
      "name" : "Kyle Niemeyer",
      "screen_name" : "kyleniemeyer",
      "indices" : [ 152, 165 ],
      "id_str" : "6607712",
      "id" : 6607712
    }, {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 166, 174 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Sara Mannheimer",
      "screen_name" : "saramannheimer",
      "indices" : [ 175, 190 ],
      "id_str" : "825610044",
      "id" : 825610044
    }, {
      "name" : "Lillian Rigling",
      "screen_name" : "lilyrglg",
      "indices" : [ 191, 200 ],
      "id_str" : "272099717",
      "id" : 272099717
    }, {
      "name" : "Daniel S. Katz",
      "screen_name" : "danielskatz",
      "indices" : [ 201, 213 ],
      "id_str" : "19238958",
      "id" : 19238958
    }, {
      "name" : "Josmel Pacheco",
      "screen_name" : "josmel1",
      "indices" : [ 214, 222 ],
      "id_str" : "54002739",
      "id" : 54002739
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 223, 237 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Marta Poblet \uD83C\uDF97\uFE0F",
      "screen_name" : "mpoblet",
      "indices" : [ 238, 246 ],
      "id_str" : "17893512",
      "id" : 17893512
    }, {
      "name" : "Marios Isaakidis",
      "screen_name" : "misaakidis",
      "indices" : [ 247, 258 ],
      "id_str" : "335255004",
      "id" : 335255004
    }, {
      "name" : "D\u24D0sapta Erwin Irawan",
      "screen_name" : "dasaptaerwin",
      "indices" : [ 259, 272 ],
      "id_str" : "225236194",
      "id" : 225236194
    }, {
      "name" : "sebastien renaut",
      "screen_name" : "seb_renaut",
      "indices" : [ 273, 284 ],
      "id_str" : "28158354",
      "id" : 28158354
    }, {
      "name" : "Chris Madan \uD83E\uDDE0",
      "screen_name" : "cMadan",
      "indices" : [ 285, 292 ],
      "id_str" : "11383092",
      "id" : 11383092
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 293, 303 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    }, {
      "name" : "Jesper N. Kjaer",
      "screen_name" : "JesperNKjaer",
      "indices" : [ 304, 317 ],
      "id_str" : "1460192682",
      "id" : 1460192682
    }, {
      "name" : "Daniel O'Donnell",
      "screen_name" : "DanielPaulOD",
      "indices" : [ 318, 331 ],
      "id_str" : "41965769",
      "id" : 41965769
    }, {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 332, 346 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "sarah k",
      "screen_name" : "annotated_sci",
      "indices" : [ 347, 361 ],
      "id_str" : "772816871179558913",
      "id" : 772816871179558913
    }, {
      "name" : "Manojkumar Selvaraju",
      "screen_name" : "manogenome",
      "indices" : [ 362, 373 ],
      "id_str" : "204877909",
      "id" : 204877909
    }, {
      "name" : "J. Colomb, @pen",
      "screen_name" : "j_colomb",
      "indices" : [ 374, 383 ],
      "id_str" : "9437692",
      "id" : 9437692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "888063169188462593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235637039231, 8.627497618571292 ]
  },
  "id_str" : "888063525284925440",
  "in_reply_to_user_id" : 76456521,
  "text" : "@parnopaeus @Protohedgehog @martin_eve @F1000Research @JMDugan @dgraziotin @jacques_damien @EvoMRI @cpikas @ProfTomCrick @pcmasuzzo @thonoir @devinberg @kyleniemeyer @tonyR_H @saramannheimer @lilyrglg @danielskatz @josmel1 @NazeefaFatima @mpoblet @misaakidis @dasaptaerwin @seb_renaut @cMadan @l_matthia @JesperNKjaer @DanielPaulOD @CameronNeylon @annotated_sci @manogenome @j_colomb gaming the Altmetric score for beginners: Just add a million co-authors, each of them will tweet it\/post it on facebook etc. \uD83D\uDE09",
  "id" : 888063525284925440,
  "in_reply_to_status_id" : 888063169188462593,
  "created_at" : "2017-07-20 15:50:18 +0000",
  "in_reply_to_screen_name" : "parnopaeus",
  "in_reply_to_user_id_str" : "76456521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/AqUX6uycql",
      "expanded_url" : "https:\/\/twitter.com\/TheAllium\/status\/887982652267036672",
      "display_url" : "twitter.com\/TheAllium\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237442950602, 8.627488261663801 ]
  },
  "id_str" : "888004007679193092",
  "text" : "Makes sense. After all you need some strong beliefs if you want to trust many microbiome studies. \uD83D\uDE09 https:\/\/t.co\/AqUX6uycql",
  "id" : 888004007679193092,
  "created_at" : "2017-07-20 11:53:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 3, 13 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "Jan Hohner",
      "screen_name" : "janhohner",
      "indices" : [ 25, 35 ],
      "id_str" : "114832665",
      "id" : 114832665
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenInnovation",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/TgXynduFp8",
      "expanded_url" : "https:\/\/mozillafestival.org\/proposals",
      "display_url" : "mozillafestival.org\/proposals"
    } ]
  },
  "geo" : { },
  "id_str" : "887986069983174656",
  "text" : "RT @kirstie_j: Fantastic @janhohner! Everyone can join you by Aug 1st here https:\/\/t.co\/TgXynduFp8 &amp; join #OpenInnovation AMA today https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jan Hohner",
        "screen_name" : "janhohner",
        "indices" : [ 10, 20 ],
        "id_str" : "114832665",
        "id" : 114832665
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenInnovation",
        "indices" : [ 95, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/TgXynduFp8",
        "expanded_url" : "https:\/\/mozillafestival.org\/proposals",
        "display_url" : "mozillafestival.org\/proposals"
      }, {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/xuvxctNzMl",
        "expanded_url" : "https:\/\/public.etherpad-mozilla.org\/p\/openinnovation-mozfest-2017-ama",
        "display_url" : "public.etherpad-mozilla.org\/p\/openinnovati\u2026"
      }, {
        "indices" : [ 145, 168 ],
        "url" : "https:\/\/t.co\/lqqvqeFPpG",
        "expanded_url" : "https:\/\/twitter.com\/janhohner\/status\/887961860846342148",
        "display_url" : "twitter.com\/janhohner\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "887974580215742464",
    "text" : "Fantastic @janhohner! Everyone can join you by Aug 1st here https:\/\/t.co\/TgXynduFp8 &amp; join #OpenInnovation AMA today https:\/\/t.co\/xuvxctNzMl https:\/\/t.co\/lqqvqeFPpG",
    "id" : 887974580215742464,
    "created_at" : "2017-07-20 09:56:52 +0000",
    "user" : {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "protected" : false,
      "id_str" : "37989702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599173943405223937\/oNvZRB25_normal.jpg",
      "id" : 37989702,
      "verified" : false
    }
  },
  "id" : 887986069983174656,
  "created_at" : "2017-07-20 10:42:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/kjS0PUb3xA",
      "expanded_url" : "https:\/\/twitter.com\/cbrueffer\/status\/887960974694785025",
      "display_url" : "twitter.com\/cbrueffer\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232749400312, 8.627528273326357 ]
  },
  "id_str" : "887985714419380224",
  "text" : "Sad to miss the CodeFest! See you at #BOSC2017 though! https:\/\/t.co\/kjS0PUb3xA",
  "id" : 887985714419380224,
  "created_at" : "2017-07-20 10:41:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manojkumar Selvaraju",
      "screen_name" : "manogenome",
      "indices" : [ 0, 11 ],
      "id_str" : "204877909",
      "id" : 204877909
    }, {
      "name" : "Overleaf",
      "screen_name" : "overleaf",
      "indices" : [ 12, 21 ],
      "id_str" : "854581958",
      "id" : 854581958
    }, {
      "name" : "F1000Research",
      "screen_name" : "F1000Research",
      "indices" : [ 22, 36 ],
      "id_str" : "59126394",
      "id" : 59126394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887978333631283200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235776362435, 8.627491109164996 ]
  },
  "id_str" : "887978568889847808",
  "in_reply_to_user_id" : 204877909,
  "text" : "@manogenome @overleaf @F1000Research next step: getting those reviews \uD83D\uDE0A",
  "id" : 887978568889847808,
  "in_reply_to_status_id" : 887978333631283200,
  "created_at" : "2017-07-20 10:12:43 +0000",
  "in_reply_to_screen_name" : "manogenome",
  "in_reply_to_user_id_str" : "204877909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/887974989810585600\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/mMmvrxh7oN",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DFK4isbWsAILPy2.jpg",
      "id_str" : "887974982726365186",
      "id" : 887974982726365186,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DFK4isbWsAILPy2.jpg",
      "sizes" : [ {
        "h" : 116,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 116,
        "resize" : "crop",
        "w" : 116
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 220
      }, {
        "h" : 116,
        "resize" : "fit",
        "w" : 220
      } ],
      "display_url" : "pic.twitter.com\/mMmvrxh7oN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887972657257488384",
  "geo" : { },
  "id_str" : "887974989810585600",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog  https:\/\/t.co\/mMmvrxh7oN",
  "id" : 887974989810585600,
  "in_reply_to_status_id" : 887972657257488384,
  "created_at" : "2017-07-20 09:58:30 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 33, 47 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/bdkkWBspsm",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/887968883788967936",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "887968883788967936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234172691566, 8.627524505319167 ]
  },
  "id_str" : "887969456156278784",
  "in_reply_to_user_id" : 14286491,
  "text" : "And well done on the cat-herding @Protohedgehog! \uD83D\uDE02 https:\/\/t.co\/bdkkWBspsm",
  "id" : 887969456156278784,
  "in_reply_to_status_id" : 887968883788967936,
  "created_at" : "2017-07-20 09:36:30 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/ZILdBvLzNY",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/6-1151\/v1",
      "display_url" : "f1000research.com\/articles\/6-115\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234172691566, 8.627524505319167 ]
  },
  "id_str" : "887968883788967936",
  "text" : "Look what just hit F1000Research: A multi-disciplinary perspective on emergent &amp; future innovations in peer review https:\/\/t.co\/ZILdBvLzNY",
  "id" : 887968883788967936,
  "created_at" : "2017-07-20 09:34:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887908508578000897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.07600520625331, 8.875210208566749 ]
  },
  "id_str" : "887925584361172992",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage \uD83D\uDE4F",
  "id" : 887925584361172992,
  "in_reply_to_status_id" : 887908508578000897,
  "created_at" : "2017-07-20 06:42:10 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887844510956433412",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401055000953, 8.753345796569796 ]
  },
  "id_str" : "887905406722469890",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute Sure, drop me an email! :)",
  "id" : 887905406722469890,
  "in_reply_to_status_id" : 887844510956433412,
  "created_at" : "2017-07-20 05:22:00 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/PrGJcWbuCp",
      "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/Codefest_2017",
      "display_url" : "open-bio.org\/wiki\/Codefest_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "887765146138845184",
  "text" : "RT @OBF_BOSC: OpenBio Codefest kicks off tomorrow! https:\/\/t.co\/PrGJcWbuCp #BOSC2017",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/PrGJcWbuCp",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/Codefest_2017",
        "display_url" : "open-bio.org\/wiki\/Codefest_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "887728261769289728",
    "text" : "OpenBio Codefest kicks off tomorrow! https:\/\/t.co\/PrGJcWbuCp #BOSC2017",
    "id" : 887728261769289728,
    "created_at" : "2017-07-19 17:38:05 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 887765146138845184,
  "created_at" : "2017-07-19 20:04:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887722911104217092",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17113249427069, 8.614731084544774 ]
  },
  "id_str" : "887726435569479685",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute Any time! \uD83C\uDF31",
  "id" : 887726435569479685,
  "in_reply_to_status_id" : 887722911104217092,
  "created_at" : "2017-07-19 17:30:50 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887619952768888832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.15297662317063, 8.614519113343786 ]
  },
  "id_str" : "887702088079245313",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick \uD83D\uDC4D\uD83D\uDC4B see you there!",
  "id" : 887702088079245313,
  "in_reply_to_status_id" : 887619952768888832,
  "created_at" : "2017-07-19 15:54:05 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 9, 19 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/uZG69Ktxou",
      "expanded_url" : "https:\/\/twitter.com\/matkuzak\/status\/887697403209502721",
      "display_url" : "twitter.com\/matkuzak\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18356004999998, 8.614876169999997 ]
  },
  "id_str" : "887701740921008128",
  "text" : "Love how @kirstie_j\u2019s lab code of conduct is so easily adaptable and reusable thanks to CC BY. \uD83D\uDE0D https:\/\/t.co\/uZG69Ktxou",
  "id" : 887701740921008128,
  "created_at" : "2017-07-19 15:52:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mateusz Kuzak",
      "screen_name" : "matkuzak",
      "indices" : [ 0, 9 ],
      "id_str" : "2856932848",
      "id" : 2856932848
    }, {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 10, 18 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887697906966433792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232729334754, 8.627532413475546 ]
  },
  "id_str" : "887698134754889729",
  "in_reply_to_user_id" : 2856932848,
  "text" : "@matkuzak @cbahlai I can\u2019t take credit for it, I just found that some years ago in a tweet and found it a brilliant idea worth copying. :)",
  "id" : 887698134754889729,
  "in_reply_to_status_id" : 887697906966433792,
  "created_at" : "2017-07-19 15:38:22 +0000",
  "in_reply_to_screen_name" : "matkuzak",
  "in_reply_to_user_id_str" : "2856932848",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 61, 69 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/qHvY7yDV1G",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/citizen-science-salon\/2017\/07\/10\/stall-catchers-citizen-science-game-to-host-its-first-international-catchathon\/#.WW5qsidRU8p",
      "display_url" : "blogs.discovermagazine.com\/citizen-scienc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231953703789, 8.627533524244546 ]
  },
  "id_str" : "887667830052843520",
  "text" : "You\u2019re interested in citizen science &amp; Alzheimer\u2019s? Join @Seplute in the global \u2019Catchathon\u2019 on 22nd! https:\/\/t.co\/qHvY7yDV1G",
  "id" : 887667830052843520,
  "created_at" : "2017-07-19 13:37:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887591820858974208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235271171683, 8.627065541230726 ]
  },
  "id_str" : "887592702052896768",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe Safe travels!",
  "id" : 887592702052896768,
  "in_reply_to_status_id" : 887591820858974208,
  "created_at" : "2017-07-19 08:39:25 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    }, {
      "name" : "Lisa Pettibone",
      "screen_name" : "LisaPettibone",
      "indices" : [ 26, 40 ],
      "id_str" : "491639118",
      "id" : 491639118
    }, {
      "name" : "Katrin Vohland",
      "screen_name" : "vohlandii",
      "indices" : [ 41, 51 ],
      "id_str" : "3031127223",
      "id" : 3031127223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "887592058134908928",
  "text" : "RT @BPrainsack: Just out: @LisaPettibone @vohlandii &amp; David Ziegler: A survey of current citizen science in Germany and Austria https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lisa Pettibone",
        "screen_name" : "LisaPettibone",
        "indices" : [ 10, 24 ],
        "id_str" : "491639118",
        "id" : 491639118
      }, {
        "name" : "Katrin Vohland",
        "screen_name" : "vohlandii",
        "indices" : [ 25, 35 ],
        "id_str" : "3031127223",
        "id" : 3031127223
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/QhklSnqzbc",
        "expanded_url" : "http:\/\/buff.ly\/2vfOS73",
        "display_url" : "buff.ly\/2vfOS73"
      } ]
    },
    "geo" : { },
    "id_str" : "887588068160667648",
    "text" : "Just out: @LisaPettibone @vohlandii &amp; David Ziegler: A survey of current citizen science in Germany and Austria https:\/\/t.co\/QhklSnqzbc",
    "id" : 887588068160667648,
    "created_at" : "2017-07-19 08:21:00 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 887592058134908928,
  "created_at" : "2017-07-19 08:36:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BenjaminSchwessinger",
      "screen_name" : "schwessinger",
      "indices" : [ 30, 43 ],
      "id_str" : "1337118332",
      "id" : 1337118332
    }, {
      "name" : "Vin\u24EAdh Ilang\u24EAvan",
      "screen_name" : "InquisitiveVi",
      "indices" : [ 44, 58 ],
      "id_str" : "3443391621",
      "id" : 3443391621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/SmvioH4V83",
      "expanded_url" : "https:\/\/twitter.com\/eLifeCommunity\/status\/887577016907780096",
      "display_url" : "twitter.com\/eLifeCommunity\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18356004999998, 8.614876169999997 ]
  },
  "id_str" : "887589321372577792",
  "text" : "Oh, familiar faces! Well done @schwessinger @InquisitiveVi \uD83D\uDC4D https:\/\/t.co\/SmvioH4V83",
  "id" : 887589321372577792,
  "created_at" : "2017-07-19 08:25:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/tY0CVepuwh",
      "expanded_url" : "https:\/\/twitter.com\/sw1ayfe\/status\/887461107199332353",
      "display_url" : "twitter.com\/sw1ayfe\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399192390955, 8.753329242907016 ]
  },
  "id_str" : "887462207264567296",
  "text" : "Looking forward to meeting so many wonderful people! \uD83D\uDC96 https:\/\/t.co\/tY0CVepuwh",
  "id" : 887462207264567296,
  "created_at" : "2017-07-19 00:00:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 9, 16 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 17, 27 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/UMGdSxmiKP",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/FJ4FFIhMwJXdm\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/FJ4FFIhM\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "887311832662331398",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233565920835, 8.627517982957052 ]
  },
  "id_str" : "887312798816100353",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @sujaik @auremoser \uD83D\uDE0E https:\/\/t.co\/UMGdSxmiKP",
  "id" : 887312798816100353,
  "in_reply_to_status_id" : 887311832662331398,
  "created_at" : "2017-07-18 14:07:11 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 8, 16 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 17, 27 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/wN3D9iXYeZ",
      "expanded_url" : "https:\/\/gedankenstuecke.piratenpad.de\/nerdcator",
      "display_url" : "gedankenstuecke.piratenpad.de\/nerdcator"
    } ]
  },
  "in_reply_to_status_id_str" : "887303956518629382",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232197255436, 8.627519113644347 ]
  },
  "id_str" : "887306332713385986",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Seplute @auremoser here\u2019s the pad for drafting a proposal, taking notes etc. https:\/\/t.co\/wN3D9iXYeZ :)",
  "id" : 887306332713385986,
  "in_reply_to_status_id" : 887303956518629382,
  "created_at" : "2017-07-18 13:41:29 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 9, 16 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 28, 38 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231461912856, 8.627523333801705 ]
  },
  "id_str" : "887302991363149827",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @sujaik hey folks, @auremoser &amp; I are planning a follow-up session on Nerdcator at #mozfest this year. Do you want to join in? :)",
  "id" : 887302991363149827,
  "created_at" : "2017-07-18 13:28:13 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887276677486837760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234530700314, 8.627514425562001 ]
  },
  "id_str" : "887278462486097920",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb fingers crossed!",
  "id" : 887278462486097920,
  "in_reply_to_status_id" : 887276677486837760,
  "created_at" : "2017-07-18 11:50:44 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887264043584684032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234368901448, 8.627520669307689 ]
  },
  "id_str" : "887272126167887872",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb \uD83D\uDC4D let me know one can be of any service with that too!",
  "id" : 887272126167887872,
  "in_reply_to_status_id" : 887264043584684032,
  "created_at" : "2017-07-18 11:25:34 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887260114826211328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723757578023, 8.627510700846987 ]
  },
  "id_str" : "887261805709545472",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb Where can I put some \uD83D\uDCB0for you?",
  "id" : 887261805709545472,
  "in_reply_to_status_id" : 887260114826211328,
  "created_at" : "2017-07-18 10:44:33 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Xu",
      "screen_name" : "annathehybrid",
      "indices" : [ 0, 14 ],
      "id_str" : "2997606122",
      "id" : 2997606122
    }, {
      "name" : "Twitter",
      "screen_name" : "Twitter",
      "indices" : [ 15, 23 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887261090983415808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224906948411, 8.62734423951118 ]
  },
  "id_str" : "887261288979730434",
  "in_reply_to_user_id" : 2997606122,
  "text" : "@annathehybrid @Twitter Close, got a double barreled one now.",
  "id" : 887261288979730434,
  "in_reply_to_status_id" : 887261090983415808,
  "created_at" : "2017-07-18 10:42:30 +0000",
  "in_reply_to_screen_name" : "annathehybrid",
  "in_reply_to_user_id_str" : "2997606122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biotweeps - Brit",
      "screen_name" : "biotweeps",
      "indices" : [ 48, 58 ],
      "id_str" : "2561407350",
      "id" : 2561407350
    }, {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 63, 71 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/PYL59v5C0g",
      "expanded_url" : "https:\/\/twitter.com\/biotweeps\/status\/887089976982335490",
      "display_url" : "twitter.com\/biotweeps\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "887089976982335490",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388114876874, 8.753161154107262 ]
  },
  "id_str" : "887090655213891584",
  "in_reply_to_user_id" : 2561407350,
  "text" : "Can absolutely confirm. And make sure to follow @biotweeps, as @Seplute is one of the most awesome citizen science people I know! \uD83C\uDF89 https:\/\/t.co\/PYL59v5C0g",
  "id" : 887090655213891584,
  "in_reply_to_status_id" : 887089976982335490,
  "created_at" : "2017-07-17 23:24:28 +0000",
  "in_reply_to_screen_name" : "biotweeps",
  "in_reply_to_user_id_str" : "2561407350",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien de Vienne\uD83C\uDF32\uD83C\uDF33\uD83C\uDF34",
      "screen_name" : "damdevienne",
      "indices" : [ 0, 12 ],
      "id_str" : "2491928876",
      "id" : 2491928876
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 13, 21 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Rainer Melzer",
      "screen_name" : "UCDflowerpower",
      "indices" : [ 22, 37 ],
      "id_str" : "19333674",
      "id" : 19333674
    }, {
      "name" : "The ETE toolkit",
      "screen_name" : "etetoolkit",
      "indices" : [ 38, 49 ],
      "id_str" : "318548085",
      "id" : 318548085
    }, {
      "name" : "Jaime Huerta-Cepas",
      "screen_name" : "jhcepas",
      "indices" : [ 50, 58 ],
      "id_str" : "306248139",
      "id" : 306248139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887077347492601861",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11309775419972, 8.755226237551996 ]
  },
  "id_str" : "887077794890616833",
  "in_reply_to_user_id" : 2491928876,
  "text" : "@damdevienne @kaiblin @UCDflowerpower @etetoolkit @jhcepas I love ETE for manipulating trees, still prefer R for visualizing them though. ETE is still somewhat limited there.",
  "id" : 887077794890616833,
  "in_reply_to_status_id" : 887077347492601861,
  "created_at" : "2017-07-17 22:33:22 +0000",
  "in_reply_to_screen_name" : "damdevienne",
  "in_reply_to_user_id_str" : "2491928876",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/1SIe6nGeMX",
      "expanded_url" : "https:\/\/twitter.com\/Seplute\/status\/886906893595271168",
      "display_url" : "twitter.com\/Seplute\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723261036831, 8.62752705820508 ]
  },
  "id_str" : "886918973291450372",
  "text" : "Some of my most-used emoji to celebrate the day: \uD83D\uDE02\uD83D\uDE0D\uD83D\uDC96\uD83D\uDC4D\uD83D\uDC36\u2708\uFE0F\uD83C\uDF89\u2615\uFE0F\uD83E\uDD26\u200D\u2640\uFE0F\uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/1SIe6nGeMX",
  "id" : 886918973291450372,
  "created_at" : "2017-07-17 12:02:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/lzPXCbRb9T",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWpMvV9lk1B\/",
      "display_url" : "instagram.com\/p\/BWpMvV9lk1B\/"
    } ]
  },
  "geo" : { },
  "id_str" : "886890012549238784",
  "text" : "\uD83C\uDF35 https:\/\/t.co\/lzPXCbRb9T",
  "id" : 886890012549238784,
  "created_at" : "2017-07-17 10:07:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 14, 25 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886850548091244545",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232328935992, 8.627531615435219 ]
  },
  "id_str" : "886879851671695360",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @openSNPorg Nice, good luck! :)",
  "id" : 886879851671695360,
  "in_reply_to_status_id" : 886850548091244545,
  "created_at" : "2017-07-17 09:26:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886853053927895041",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396393759366, 8.75296843365231 ]
  },
  "id_str" : "886853105320591362",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess \uD83D\uDE02",
  "id" : 886853105320591362,
  "in_reply_to_status_id" : 886853053927895041,
  "created_at" : "2017-07-17 07:40:31 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 0, 16 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886852861535145984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396393759366, 8.75296843365231 ]
  },
  "id_str" : "886852955051347968",
  "in_reply_to_user_id" : 77216385,
  "text" : "@fireantprincess last name, post-wedding.",
  "id" : 886852955051347968,
  "in_reply_to_status_id" : 886852861535145984,
  "created_at" : "2017-07-17 07:39:56 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "Twitter",
      "indices" : [ 91, 99 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400750570375, 8.753343301323385 ]
  },
  "id_str" : "886852689694523393",
  "text" : "tfw you finally convinced the bureaucracy to change your name and then you figure out that @Twitter only accepts names &lt;20 characters.",
  "id" : 886852689694523393,
  "created_at" : "2017-07-17 07:38:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/wmVK9c0gqd",
      "expanded_url" : "https:\/\/twitter.com\/heyaudy\/status\/886340143518408704",
      "display_url" : "twitter.com\/heyaudy\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11309687449009, 8.755224607053643 ]
  },
  "id_str" : "886641584242135041",
  "text" : "The header is even short enough that you can convert it to the equally ridiculous Phylip format. https:\/\/t.co\/wmVK9c0gqd",
  "id" : 886641584242135041,
  "created_at" : "2017-07-16 17:40:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "indices" : [ 3, 12 ],
      "id_str" : "1096058449",
      "id" : 1096058449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "886640298042019840",
  "text" : "RT @itatiVCS: You have to actually Do Things other than recruit diverse students. You have to give them the support they need to thrive",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "886570772130648065",
    "geo" : { },
    "id_str" : "886570964238176256",
    "in_reply_to_user_id" : 1096058449,
    "text" : "You have to actually Do Things other than recruit diverse students. You have to give them the support they need to thrive",
    "id" : 886570964238176256,
    "in_reply_to_status_id" : 886570772130648065,
    "created_at" : "2017-07-16 12:59:24 +0000",
    "in_reply_to_screen_name" : "itatiVCS",
    "in_reply_to_user_id_str" : "1096058449",
    "user" : {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "protected" : false,
      "id_str" : "1096058449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932026012556181505\/DEpx6nxN_normal.jpg",
      "id" : 1096058449,
      "verified" : false
    }
  },
  "id" : 886640298042019840,
  "created_at" : "2017-07-16 17:34:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/zIve67cLYX",
      "expanded_url" : "https:\/\/twitter.com\/CameronNeylon\/status\/886598852077400066",
      "display_url" : "twitter.com\/CameronNeylon\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400684101512, 8.753340995674133 ]
  },
  "id_str" : "886607609389871104",
  "text" : "My money is on \u2018no\u2019. \uD83D\uDCB0\uD83C\uDFB2 https:\/\/t.co\/zIve67cLYX",
  "id" : 886607609389871104,
  "created_at" : "2017-07-16 15:25:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886590832391856129",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400684101512, 8.753340995674133 ]
  },
  "id_str" : "886607193625309185",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Yeah, personally I\u2019ll happily live with the weirdness for some more months\/years if the poll results are any indication. \uD83D\uDE1D",
  "id" : 886607193625309185,
  "in_reply_to_status_id" : 886590832391856129,
  "created_at" : "2017-07-16 15:23:21 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillaume Cabanac",
      "screen_name" : "gcabanac",
      "indices" : [ 3, 12 ],
      "id_str" : "237738266",
      "id" : 237738266
    }, {
      "name" : "Daniel Himmelstein",
      "screen_name" : "dhimmel",
      "indices" : [ 102, 110 ],
      "id_str" : "289107682",
      "id" : 289107682
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 120, 136 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/yUqLUrUesE",
      "expanded_url" : "https:\/\/greenelab.github.io\/scihub-manuscript\/",
      "display_url" : "greenelab.github.io\/scihub-manuscr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "886606704699363328",
  "text" : "RT @gcabanac: \u201CSci-Hub provides access to nearly all scholarly literature\u201D https:\/\/t.co\/yUqLUrUesE by @dhimmel arielsvn @gedankenstuecke @G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Himmelstein",
        "screen_name" : "dhimmel",
        "indices" : [ 88, 96 ],
        "id_str" : "289107682",
        "id" : 289107682
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 106, 122 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Casey Greene",
        "screen_name" : "GreeneScientist",
        "indices" : [ 123, 139 ],
        "id_str" : "95233492",
        "id" : 95233492
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/yUqLUrUesE",
        "expanded_url" : "https:\/\/greenelab.github.io\/scihub-manuscript\/",
        "display_url" : "greenelab.github.io\/scihub-manuscr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "886586757386579968",
    "text" : "\u201CSci-Hub provides access to nearly all scholarly literature\u201D https:\/\/t.co\/yUqLUrUesE by @dhimmel arielsvn @gedankenstuecke @GreeneScientist",
    "id" : 886586757386579968,
    "created_at" : "2017-07-16 14:02:09 +0000",
    "user" : {
      "name" : "Guillaume Cabanac",
      "screen_name" : "gcabanac",
      "protected" : false,
      "id_str" : "237738266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794644597855109120\/CyK0G40Z_normal.jpg",
      "id" : 237738266,
      "verified" : false
    }
  },
  "id" : 886606704699363328,
  "created_at" : "2017-07-16 15:21:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/eYZGEcLBtP",
      "expanded_url" : "https:\/\/twitter.com\/gcabanac\/status\/886586757386579968",
      "display_url" : "twitter.com\/gcabanac\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400684101512, 8.753340995674133 ]
  },
  "id_str" : "886606698840023041",
  "text" : "Completely done in the open on GitHub. https:\/\/t.co\/eYZGEcLBtP",
  "id" : 886606698840023041,
  "created_at" : "2017-07-16 15:21:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Wilson",
      "screen_name" : "gvwilson",
      "indices" : [ 0, 9 ],
      "id_str" : "21506708",
      "id" : 21506708
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 10, 25 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/HFqDJeQ0kS",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/posteverything\/wp\/2017\/02\/03\/canada-is-a-progressive-immigration-policy-dream-unless-you-have-a-disability\/?utm_term=.e60dd7b597fc",
      "display_url" : "washingtonpost.com\/posteverything\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "886587756008415232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400912578525, 8.753344877859417 ]
  },
  "id_str" : "886588751744552960",
  "in_reply_to_user_id" : 21506708,
  "text" : "@gvwilson @EmilyGorcenski Well, that\u2019s not the only reason to be banned from Canada. https:\/\/t.co\/HFqDJeQ0kS",
  "id" : 886588751744552960,
  "in_reply_to_status_id" : 886587756008415232,
  "created_at" : "2017-07-16 14:10:05 +0000",
  "in_reply_to_screen_name" : "gvwilson",
  "in_reply_to_user_id_str" : "21506708",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886571922993041408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397806115942, 8.7533400375609 ]
  },
  "id_str" : "886587700693938177",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Is that some advice on how to normalize it more quickly? :p",
  "id" : 886587700693938177,
  "in_reply_to_status_id" : 886571922993041408,
  "created_at" : "2017-07-16 14:05:54 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacques Fellay",
      "screen_name" : "jacquesfellay",
      "indices" : [ 3, 17 ],
      "id_str" : "106477433",
      "id" : 106477433
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 101, 110 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "886536196620529665",
  "text" : "RT @jacquesfellay: Our height prediction challenge based on genome-wide SNP data is in full swing on @crowd_ai. Join the fun! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CrowdAI",
        "screen_name" : "crowd_ai",
        "indices" : [ 82, 91 ],
        "id_str" : "706885331224813568",
        "id" : 706885331224813568
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/XBDoZ9Jw18",
        "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
        "display_url" : "crowdai.org\/challenges\/ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "884809076072468481",
    "text" : "Our height prediction challenge based on genome-wide SNP data is in full swing on @crowd_ai. Join the fun! https:\/\/t.co\/XBDoZ9Jw18",
    "id" : 884809076072468481,
    "created_at" : "2017-07-11 16:18:17 +0000",
    "user" : {
      "name" : "Jacques Fellay",
      "screen_name" : "jacquesfellay",
      "protected" : false,
      "id_str" : "106477433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261573502071\/57a4ae0f2488f00b7d58f9f1783df1df_normal.jpeg",
      "id" : 106477433,
      "verified" : false
    }
  },
  "id" : 886536196620529665,
  "created_at" : "2017-07-16 10:41:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konsta Happonen",
      "screen_name" : "Koalha",
      "indices" : [ 0, 7 ],
      "id_str" : "87993032",
      "id" : 87993032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886532632309268481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11384619400981, 8.753238752324936 ]
  },
  "id_str" : "886535391385452547",
  "in_reply_to_user_id" : 87993032,
  "text" : "@Koalha No I want to do field work too! \uD83D\uDE02",
  "id" : 886535391385452547,
  "in_reply_to_status_id" : 886532632309268481,
  "created_at" : "2017-07-16 10:38:02 +0000",
  "in_reply_to_screen_name" : "Koalha",
  "in_reply_to_user_id_str" : "87993032",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/jJKL7AJdJm",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/886245235801698304",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "886245235801698304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11386852716106, 8.753611156725094 ]
  },
  "id_str" : "886533466770350081",
  "in_reply_to_user_id" : 14286491,
  "text" : "So far, \u2018still weird after years\u2019 is in the lead. \uD83D\uDE02 https:\/\/t.co\/jJKL7AJdJm",
  "id" : 886533466770350081,
  "in_reply_to_status_id" : 886245235801698304,
  "created_at" : "2017-07-16 10:30:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886438936846925825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11381940920847, 8.753691874452636 ]
  },
  "id_str" : "886533225795006464",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Duh, that sounds weird, let me try that one again.\u201C",
  "id" : 886533225795006464,
  "in_reply_to_status_id" : 886438936846925825,
  "created_at" : "2017-07-16 10:29:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tuuli Lappalainen",
      "screen_name" : "tuuliel",
      "indices" : [ 3, 11 ],
      "id_str" : "575655913",
      "id" : 575655913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "886522510342336513",
  "text" : "RT @tuuliel: Dear fellow scientists. The next time you\u2019re going to google for info of the husband or wedding of a female colleague, think a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tuuliel\/status\/886272533154103296\/photo\/1",
        "indices" : [ 136, 159 ],
        "url" : "https:\/\/t.co\/vbk94Yhw8w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DEyrbR7UQAEFXrJ.jpg",
        "id_str" : "886271711842156545",
        "id" : 886271711842156545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DEyrbR7UQAEFXrJ.jpg",
        "sizes" : [ {
          "h" : 681,
          "resize" : "fit",
          "w" : 747
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 747
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 747
        } ],
        "display_url" : "pic.twitter.com\/vbk94Yhw8w"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "886272533154103296",
    "text" : "Dear fellow scientists. The next time you\u2019re going to google for info of the husband or wedding of a female colleague, think again. 1\/6 https:\/\/t.co\/vbk94Yhw8w",
    "id" : 886272533154103296,
    "created_at" : "2017-07-15 17:13:32 +0000",
    "user" : {
      "name" : "Tuuli Lappalainen",
      "screen_name" : "tuuliel",
      "protected" : false,
      "id_str" : "575655913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538804370867884032\/pWwK-tFY_normal.jpeg",
      "id" : 575655913,
      "verified" : false
    }
  },
  "id" : 886522510342336513,
  "created_at" : "2017-07-16 09:46:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/2u1g7MFnsN",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWmcAWNl57u\/",
      "display_url" : "instagram.com\/p\/BWmcAWNl57u\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113472516667, 8.7491891 ]
  },
  "id_str" : "886501361839419392",
  "text" : "Sky Crane @ Hafen Offenbach am Main https:\/\/t.co\/2u1g7MFnsN",
  "id" : 886501361839419392,
  "created_at" : "2017-07-16 08:22:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/FXrDM8JhUO",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWlUnJBF9mo\/",
      "display_url" : "instagram.com\/p\/BWlUnJBF9mo\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113472516667, 8.7491891 ]
  },
  "id_str" : "886344367350231040",
  "text" : "\uD83C\uDF05\uD83D\uDEA7 @ Hafen Offenbach am Main https:\/\/t.co\/FXrDM8JhUO",
  "id" : 886344367350231040,
  "created_at" : "2017-07-15 21:58:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "886321845905108992",
  "text" : "RT @gedankenstuecke: For how long after the wedding did it feel weird to refer to your partner as spouse\/husband\/wife? Asking for a friend.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "886245235801698304",
    "text" : "For how long after the wedding did it feel weird to refer to your partner as spouse\/husband\/wife? Asking for a friend. (contains a poll)",
    "id" : 886245235801698304,
    "created_at" : "2017-07-15 15:25:04 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 886321845905108992,
  "created_at" : "2017-07-15 20:29:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dixie",
      "screen_name" : "timiat",
      "indices" : [ 0, 7 ],
      "id_str" : "10388582",
      "id" : 10388582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886297393238605826",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11308851039673, 8.755234762833364 ]
  },
  "id_str" : "886301724872503296",
  "in_reply_to_user_id" : 10388582,
  "text" : "@timiat That\u2019s reassuring :)",
  "id" : 886301724872503296,
  "in_reply_to_status_id" : 886297393238605826,
  "created_at" : "2017-07-15 19:09:32 +0000",
  "in_reply_to_screen_name" : "timiat",
  "in_reply_to_user_id_str" : "10388582",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/E12aJaAJVF",
      "expanded_url" : "http:\/\/www.mdpi.com\/2075-4426\/7\/2\/3",
      "display_url" : "mdpi.com\/2075-4426\/7\/2\/3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11375352744955, 8.753169849523113 ]
  },
  "id_str" : "886287334102237184",
  "text" : "https:\/\/t.co\/E12aJaAJVF was the one I was looking for :)",
  "id" : 886287334102237184,
  "created_at" : "2017-07-15 18:12:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klak",
      "screen_name" : "KDKlak",
      "indices" : [ 0, 7 ],
      "id_str" : "508587668",
      "id" : 508587668
    }, {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 8, 22 ],
      "id_str" : "14177696",
      "id" : 14177696
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 130, 139 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886270195928637440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399767262639, 8.753348204791605 ]
  },
  "id_str" : "886276753559310336",
  "in_reply_to_user_id" : 508587668,
  "text" : "@KDKlak @marcelsalathe Read a study that the HR features of basically all consumer devices is pretty good, with Apple Watch best. @eramirez may know the link.",
  "id" : 886276753559310336,
  "in_reply_to_status_id" : 886270195928637440,
  "created_at" : "2017-07-15 17:30:18 +0000",
  "in_reply_to_screen_name" : "KDKlak",
  "in_reply_to_user_id_str" : "508587668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886260012288487425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10814599231827, 8.775189109154768 ]
  },
  "id_str" : "886263571348430849",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe My guess, given that it performs cont. measurements in workouts mode and how it impacts battery life: they can\u2019t get the power in the size.",
  "id" : 886263571348430849,
  "in_reply_to_status_id" : 886260012288487425,
  "created_at" : "2017-07-15 16:37:56 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886252796848328706",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11375939478177, 8.753306139268682 ]
  },
  "id_str" : "886257517164208129",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe that\u2019s why they are getting away with worse features, i.e. lack of continuous heart rate monitoring compared to Fitbit.",
  "id" : 886257517164208129,
  "in_reply_to_status_id" : 886252796848328706,
  "created_at" : "2017-07-15 16:13:52 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozFest",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/4YzKNwPsMC",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=c1IzS2oBBN0",
      "display_url" : "m.youtube.com\/watch?v=c1IzS2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "886256074881470464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11370780567162, 8.753397547412368 ]
  },
  "id_str" : "886256371603296262",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 What about doing https:\/\/t.co\/4YzKNwPsMC at #MozFest? :D",
  "id" : 886256371603296262,
  "in_reply_to_status_id" : 886256074881470464,
  "created_at" : "2017-07-15 16:09:19 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Horan",
      "screen_name" : "TiffanyHoran",
      "indices" : [ 3, 16 ],
      "id_str" : "312977141",
      "id" : 312977141
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 66, 74 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "23andMe",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/tMPzdC7W6F",
      "expanded_url" : "http:\/\/buff.ly\/2uWcBZT",
      "display_url" : "buff.ly\/2uWcBZT"
    } ]
  },
  "geo" : { },
  "id_str" : "886248975384403968",
  "text" : "RT @TiffanyHoran: My #23andMe experience: https:\/\/t.co\/tMPzdC7W6F @23andMe\u00A0is a personal genetic service that helps you understand what you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "23andMe",
        "screen_name" : "23andMe",
        "indices" : [ 48, 56 ],
        "id_str" : "14738561",
        "id" : 14738561
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "23andMe",
        "indices" : [ 3, 11 ]
      }, {
        "text" : "DNA",
        "indices" : [ 127, 131 ]
      }, {
        "text" : "Genetic",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/tMPzdC7W6F",
        "expanded_url" : "http:\/\/buff.ly\/2uWcBZT",
        "display_url" : "buff.ly\/2uWcBZT"
      } ]
    },
    "geo" : { },
    "id_str" : "886225843084824577",
    "text" : "My #23andMe experience: https:\/\/t.co\/tMPzdC7W6F @23andMe\u00A0is a personal genetic service that helps you understand what your ... #DNA #Genetic",
    "id" : 886225843084824577,
    "created_at" : "2017-07-15 14:08:00 +0000",
    "user" : {
      "name" : "Tiffany Horan",
      "screen_name" : "TiffanyHoran",
      "protected" : false,
      "id_str" : "312977141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783088965612036097\/QL41A04M_normal.jpg",
      "id" : 312977141,
      "verified" : false
    }
  },
  "id" : 886248975384403968,
  "created_at" : "2017-07-15 15:39:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "886245235801698304",
  "text" : "For how long after the wedding did it feel weird to refer to your partner as spouse\/husband\/wife? Asking for a friend. (contains a poll)",
  "id" : 886245235801698304,
  "created_at" : "2017-07-15 15:25:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/zwAYtEXOSW",
      "expanded_url" : "https:\/\/twitter.com\/manytypesoftea\/status\/886176819241680896",
      "display_url" : "twitter.com\/manytypesoftea\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11400670052497, 8.753342100679303 ]
  },
  "id_str" : "886226165828128769",
  "text" : "- It\u2019s okay to ask for help.\n- Create a special forces unit of skilled experts. https:\/\/t.co\/zwAYtEXOSW",
  "id" : 886226165828128769,
  "created_at" : "2017-07-15 14:09:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 8, 21 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 22, 30 ],
      "id_str" : "19843630",
      "id" : 19843630
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 31, 40 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886182216564436993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409076396227, 8.753321850161413 ]
  },
  "id_str" : "886182445883809792",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb @RaoOfPhysics @mbeisen @Senficon That sounds awesome!",
  "id" : 886182445883809792,
  "in_reply_to_status_id" : 886182216564436993,
  "created_at" : "2017-07-15 11:15:34 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 0, 7 ],
      "id_str" : "6069772",
      "id" : 6069772
    }, {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 8, 21 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "Michael Eisen",
      "screen_name" : "mbeisen",
      "indices" : [ 25, 33 ],
      "id_str" : "19843630",
      "id" : 19843630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "886180006803714048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409192740442, 8.753321757707246 ]
  },
  "id_str" : "886180365899096064",
  "in_reply_to_user_id" : 6069772,
  "text" : "@pennyb @RaoOfPhysics If @mbeisen joins we can finally get the OA ink! \uD83D\uDE02",
  "id" : 886180365899096064,
  "in_reply_to_status_id" : 886180006803714048,
  "created_at" : "2017-07-15 11:07:18 +0000",
  "in_reply_to_screen_name" : "pennyb",
  "in_reply_to_user_id_str" : "6069772",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 52, 65 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/886179600447004672\/photo\/1",
      "indices" : [ 132, 155 ],
      "url" : "https:\/\/t.co\/8nmIHiJAt4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DExXnXgW0AEa6rZ.jpg",
      "id_str" : "886179560521388033",
      "id" : 886179560521388033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DExXnXgW0AEa6rZ.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/8nmIHiJAt4"
    } ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 22, 29 ]
    }, {
      "text" : "opencon",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11408654231369, 8.753322139970214 ]
  },
  "id_str" : "886179600447004672",
  "text" : "Finally having a mini #mozwow #opencon reunion with @RaoOfPhysics, including South Indian food, jam sessions &amp; science ink. \uD83D\uDD2C\uD83C\uDFB8\uD83E\uDD59 https:\/\/t.co\/8nmIHiJAt4",
  "id" : 886179600447004672,
  "created_at" : "2017-07-15 11:04:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph McArthur",
      "screen_name" : "Mcarthur_Joe",
      "indices" : [ 0, 13 ],
      "id_str" : "478181304",
      "id" : 478181304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "885815659099246592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17224060376191, 8.627540376045394 ]
  },
  "id_str" : "885824895283859458",
  "in_reply_to_user_id" : 478181304,
  "text" : "@Mcarthur_Joe I\u2019ll happily offer a workshop on most effectively using Sci-Hub. \uD83D\uDE02",
  "id" : 885824895283859458,
  "in_reply_to_status_id" : 885815659099246592,
  "created_at" : "2017-07-14 11:34:47 +0000",
  "in_reply_to_screen_name" : "Mcarthur_Joe",
  "in_reply_to_user_id_str" : "478181304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISMBECCB",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "BOSC2017",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "885815876804644866",
  "text" : "RT @OBF_BOSC: If you want to breast-feed at #ISMBECCB \/ #BOSC2017 there's a dedicated nursing\/lactation room available (Room 2.2) https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISMBECCB",
        "indices" : [ 30, 39 ]
      }, {
        "text" : "BOSC2017",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/AJPBWLUaxi",
        "expanded_url" : "https:\/\/www.iscb.org\/ismbeccb2017general\/faq#nursing",
        "display_url" : "iscb.org\/ismbeccb2017ge\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "885812016543301632",
    "text" : "If you want to breast-feed at #ISMBECCB \/ #BOSC2017 there's a dedicated nursing\/lactation room available (Room 2.2) https:\/\/t.co\/AJPBWLUaxi",
    "id" : 885812016543301632,
    "created_at" : "2017-07-14 10:43:36 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 885815876804644866,
  "created_at" : "2017-07-14 10:58:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "885646002933211136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399215034002, 8.75332858493697 ]
  },
  "id_str" : "885646496649162753",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes I\u2019m waiting for \u201Ethree publishable tweets\u201C :D",
  "id" : 885646496649162753,
  "in_reply_to_status_id" : 885646002933211136,
  "created_at" : "2017-07-13 23:45:53 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "885635924473901056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399157669042, 8.753327724376266 ]
  },
  "id_str" : "885636220424007680",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab and yeah, I\u2019m a big believer in the philosophy of good enough, so no worries about perfectionism ;)",
  "id" : 885636220424007680,
  "in_reply_to_status_id" : 885635924473901056,
  "created_at" : "2017-07-13 23:05:03 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "885635741216378881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399176352833, 8.753328035503527 ]
  },
  "id_str" : "885636106670272513",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Well, I do have huge text bodies to choose from (papers, manuscripts, notes for reports,\u2026). Putting that in form is still work :D",
  "id" : 885636106670272513,
  "in_reply_to_status_id" : 885635741216378881,
  "created_at" : "2017-07-13 23:04:36 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "885629302552788992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401048098442, 8.753411141570298 ]
  },
  "id_str" : "885629410505785348",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience Worst tweet chain ever \uD83D\uDE18",
  "id" : 885629410505785348,
  "in_reply_to_status_id" : 885629302552788992,
  "created_at" : "2017-07-13 22:38:00 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396304181773, 8.753409806831884 ]
  },
  "id_str" : "885627433264852992",
  "text" : "Three full days and 10,000 words into the write-up of my thesis I so much wish I could do a tweet-based dissertation.",
  "id" : 885627433264852992,
  "created_at" : "2017-07-13 22:30:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "885525774572433408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229007478461, 8.627561930530312 ]
  },
  "id_str" : "885526036200529927",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim I already feel like a paranoid squirrel that\u2019s hiding backup drives everywhere. :D",
  "id" : 885526036200529927,
  "in_reply_to_status_id" : 885525774572433408,
  "created_at" : "2017-07-13 15:47:13 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "885181264780722178",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723406052265, 8.627513774558038 ]
  },
  "id_str" : "885182002118438913",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC (at least it\u2019s only the hallway for now, not over the server room yet \uD83D\uDE09)",
  "id" : 885182002118438913,
  "in_reply_to_status_id" : 885181264780722178,
  "created_at" : "2017-07-12 17:00:09 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "885181264780722178",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232016504233, 8.627544686264077 ]
  },
  "id_str" : "885181839882760196",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC they took two months to \u201Efix\u201C our roof. Today was the first big rain since then and it promptly started dripping through it again, same spot",
  "id" : 885181839882760196,
  "in_reply_to_status_id" : 885181264780722178,
  "created_at" : "2017-07-12 16:59:31 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/eud7nPxyYG",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWdBu7LF7sn\/",
      "display_url" : "instagram.com\/p\/BWdBu7LF7sn\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17292, 8.6321999 ]
  },
  "id_str" : "885176950335037440",
  "text" : "\uD83C\uDF31 If it continues to \u2614\uFE0F into our office my \uD83D\uDCBB will soon look like this too. @ Goethe-Universit\u00E4t\u2026 https:\/\/t.co\/eud7nPxyYG",
  "id" : 885176950335037440,
  "created_at" : "2017-07-12 16:40:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 3, 13 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "OHBM",
      "screen_name" : "OHBM",
      "indices" : [ 78, 83 ],
      "id_str" : "146567174",
      "id" : 146567174
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenScience",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "884895327517540352",
  "text" : "RT @kirstie_j: Hey tweeple! I'm delighted to be running for 2019 chair of the @OHBM #OpenScience special interest group. Pls vote! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OHBM",
        "screen_name" : "OHBM",
        "indices" : [ 63, 68 ],
        "id_str" : "146567174",
        "id" : 146567174
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenScience",
        "indices" : [ 69, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/uJvG1JaK7Y",
        "expanded_url" : "https:\/\/docs.google.com\/forms\/d\/e\/1FAIpQLSfpgG8nnbdhXUXeze4RLke0LQYi6wh1RZNGO4rFYmHPxctAXA\/viewform",
        "display_url" : "docs.google.com\/forms\/d\/e\/1FAI\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "884830658614497281",
    "text" : "Hey tweeple! I'm delighted to be running for 2019 chair of the @OHBM #OpenScience special interest group. Pls vote! https:\/\/t.co\/uJvG1JaK7Y",
    "id" : 884830658614497281,
    "created_at" : "2017-07-11 17:44:03 +0000",
    "user" : {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "protected" : false,
      "id_str" : "37989702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599173943405223937\/oNvZRB25_normal.jpg",
      "id" : 37989702,
      "verified" : false
    }
  },
  "id" : 884895327517540352,
  "created_at" : "2017-07-11 22:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 5, 12 ],
      "id_str" : "99586343",
      "id" : 99586343
    }, {
      "name" : "Diego Gomez",
      "screen_name" : "diegogomezhoyos",
      "indices" : [ 49, 65 ],
      "id_str" : "402519372",
      "id" : 402519372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozsprint",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "force2017",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/62ct7rJpoK",
      "expanded_url" : "https:\/\/twitter.com\/mfenner\/status\/884760420636078082",
      "display_url" : "twitter.com\/mfenner\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140021679403, 8.75333900733326 ]
  },
  "id_str" : "884893138506182659",
  "text" : "Wow, @lu_cyP (of DIYScience #mozsprint fame) and @diegogomezhoyos are keynoting #force2017! \uD83D\uDE0D https:\/\/t.co\/62ct7rJpoK",
  "id" : 884893138506182659,
  "created_at" : "2017-07-11 21:52:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/AUEworutT9",
      "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/884459082769453056",
      "display_url" : "twitter.com\/abbycabs\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "884740482135445504",
  "text" : "RT @gedankenstuecke: It\u2019s an awesome program, you should join! https:\/\/t.co\/AUEworutT9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/AUEworutT9",
        "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/884459082769453056",
        "display_url" : "twitter.com\/abbycabs\/statu\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 50.11393136097154, 8.753299507357065 ]
    },
    "id_str" : "884531564595564544",
    "text" : "It\u2019s an awesome program, you should join! https:\/\/t.co\/AUEworutT9",
    "id" : 884531564595564544,
    "created_at" : "2017-07-10 21:55:33 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 884740482135445504,
  "created_at" : "2017-07-11 11:45:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SciHub",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ZYrX1oIuA6",
      "expanded_url" : "http:\/\/crln.acrl.org\/index.php\/crlnews\/article\/viewFile\/16699\/18180",
      "display_url" : "crln.acrl.org\/index.php\/crln\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236339673867, 8.627504737240598 ]
  },
  "id_str" : "884695903382237184",
  "text" : "\u00ABLike water through the cracks, information will find a path of least resistance\u00BB #SciHub https:\/\/t.co\/ZYrX1oIuA6",
  "id" : 884695903382237184,
  "created_at" : "2017-07-11 08:48:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Drashti",
      "screen_name" : "drashtipandya1",
      "indices" : [ 10, 25 ],
      "id_str" : "463746645",
      "id" : 463746645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "884464951838035968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399356064103, 8.753333043994783 ]
  },
  "id_str" : "884534216641441792",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @drashtipandya1 Yes, more sprints please! \uD83D\uDE0D",
  "id" : 884534216641441792,
  "in_reply_to_status_id" : 884464951838035968,
  "created_at" : "2017-07-10 22:06:05 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/AUEworutT9",
      "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/884459082769453056",
      "display_url" : "twitter.com\/abbycabs\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393136097154, 8.753299507357065 ]
  },
  "id_str" : "884531564595564544",
  "text" : "It\u2019s an awesome program, you should join! https:\/\/t.co\/AUEworutT9",
  "id" : 884531564595564544,
  "created_at" : "2017-07-10 21:55:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 3, 12 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "internethealth",
      "indices" : [ 67, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "884531380398456833",
  "text" : "RT @abbycabs: Apply now! Join a cohort of project leaders fuelling #internethealth movement in a 12-week online mentorship program https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abbycabs\/status\/884459082769453056\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/n0NpjMxIb8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DEY62LsWsAAFYf9.jpg",
        "id_str" : "884459079351054336",
        "id" : 884459079351054336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DEY62LsWsAAFYf9.jpg",
        "sizes" : [ {
          "h" : 629,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/n0NpjMxIb8"
      } ],
      "hashtags" : [ {
        "text" : "internethealth",
        "indices" : [ 53, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1MT9YgCa9B",
        "expanded_url" : "https:\/\/medium.com\/@MozOpenLeaders\/work-in-the-open-with-mozilla-1410be0a83b2#---0-285",
        "display_url" : "medium.com\/@MozOpenLeader\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "884459082769453056",
    "text" : "Apply now! Join a cohort of project leaders fuelling #internethealth movement in a 12-week online mentorship program https:\/\/t.co\/1MT9YgCa9B https:\/\/t.co\/n0NpjMxIb8",
    "id" : 884459082769453056,
    "created_at" : "2017-07-10 17:07:32 +0000",
    "user" : {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "protected" : false,
      "id_str" : "395367768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789110152070823938\/O_ena-j7_normal.jpg",
      "id" : 395367768,
      "verified" : false
    }
  },
  "id" : 884531380398456833,
  "created_at" : "2017-07-10 21:54:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 55, 64 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 68, 82 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "884474093529116676",
  "text" : "RT @OBF_BOSC: Don't miss the #BOSC2017 keynote talk by @madprime of @OpenHumansOrg: \"Open Sourcing Ourselves\". BOSC schedule: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Madeleine Price Ball",
        "screen_name" : "madprime",
        "indices" : [ 41, 50 ],
        "id_str" : "71557700",
        "id" : 71557700
      }, {
        "name" : "OpenHumansOrg",
        "screen_name" : "OpenHumansOrg",
        "indices" : [ 54, 68 ],
        "id_str" : "2282943410",
        "id" : 2282943410
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 15, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/6fJ7Dm6LZH",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/BOSC_2017_Schedule",
        "display_url" : "open-bio.org\/wiki\/BOSC_2017\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "884449522000076801",
    "text" : "Don't miss the #BOSC2017 keynote talk by @madprime of @OpenHumansOrg: \"Open Sourcing Ourselves\". BOSC schedule: https:\/\/t.co\/6fJ7Dm6LZH",
    "id" : 884449522000076801,
    "created_at" : "2017-07-10 16:29:32 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 884474093529116676,
  "created_at" : "2017-07-10 18:07:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/J94XDoR7QL",
      "expanded_url" : "http:\/\/existentialcomics.com\/comic\/190",
      "display_url" : "existentialcomics.com\/comic\/190"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723185232474, 8.627524027534852 ]
  },
  "id_str" : "884438863862796288",
  "text" : "The Philosophy Force Five vs the Scientismists https:\/\/t.co\/J94XDoR7QL",
  "id" : 884438863862796288,
  "created_at" : "2017-07-10 15:47:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245287545973, 8.62740291283338 ]
  },
  "id_str" : "884365274845245440",
  "text" : "@kopshtik 5\/5 would buy again.",
  "id" : 884365274845245440,
  "created_at" : "2017-07-10 10:54:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 3, 14 ],
      "id_str" : "397518511",
      "id" : 397518511
    }, {
      "name" : "Matthias Egger",
      "screen_name" : "eggersnsf",
      "indices" : [ 65, 75 ],
      "id_str" : "722338038",
      "id" : 722338038
    }, {
      "name" : "SNSF",
      "screen_name" : "snsf_ch",
      "indices" : [ 76, 84 ],
      "id_str" : "835594501",
      "id" : 835594501
    }, {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 105, 119 ],
      "id_str" : "14177696",
      "id" : 14177696
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 120, 136 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/JWfax9ajr5",
      "expanded_url" : "http:\/\/www.snf.ch\/en\/researchinFocus\/newsroom\/Pages\/news-170714-horizons-fake-news-sherlock-among-the-tulips.aspx",
      "display_url" : "snf.ch\/en\/researchinF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "884360171404898305",
  "text" : "RT @EffyVayena: Succinct and spot on: https:\/\/t.co\/JWfax9ajr5 by @eggersnsf @snsf_ch #openaccess tagging @marcelsalathe @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthias Egger",
        "screen_name" : "eggersnsf",
        "indices" : [ 49, 59 ],
        "id_str" : "722338038",
        "id" : 722338038
      }, {
        "name" : "SNSF",
        "screen_name" : "snsf_ch",
        "indices" : [ 60, 68 ],
        "id_str" : "835594501",
        "id" : 835594501
      }, {
        "name" : "Marcel Salathe",
        "screen_name" : "marcelsalathe",
        "indices" : [ 89, 103 ],
        "id_str" : "14177696",
        "id" : 14177696
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 104, 120 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 69, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/JWfax9ajr5",
        "expanded_url" : "http:\/\/www.snf.ch\/en\/researchinFocus\/newsroom\/Pages\/news-170714-horizons-fake-news-sherlock-among-the-tulips.aspx",
        "display_url" : "snf.ch\/en\/researchinF\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "884354390781550593",
    "text" : "Succinct and spot on: https:\/\/t.co\/JWfax9ajr5 by @eggersnsf @snsf_ch #openaccess tagging @marcelsalathe @gedankenstuecke",
    "id" : 884354390781550593,
    "created_at" : "2017-07-10 10:11:31 +0000",
    "user" : {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "protected" : false,
      "id_str" : "397518511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837580905615085568\/EBU1zR7D_normal.jpg",
      "id" : 397518511,
      "verified" : false
    }
  },
  "id" : 884360171404898305,
  "created_at" : "2017-07-10 10:34:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozfest",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/C34IuQiAqf",
      "expanded_url" : "https:\/\/twitter.com\/kirstie_j\/status\/884300532655022090",
      "display_url" : "twitter.com\/kirstie_j\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233627147711, 8.627515403166601 ]
  },
  "id_str" : "884326754642526208",
  "text" : "Great thread on what awaits you at #mozfest and where you can contribute your own projects and ideas! https:\/\/t.co\/C34IuQiAqf",
  "id" : 884326754642526208,
  "created_at" : "2017-07-10 08:21:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/GNJXdSb2JU",
      "expanded_url" : "https:\/\/twitter.com\/timtriche\/status\/884234693985488896",
      "display_url" : "twitter.com\/timtriche\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17243355166364, 8.627491693351592 ]
  },
  "id_str" : "884299535673110528",
  "text" : "First you have to come in on the weekend to feed your cells and then you have to provide for their executives as well?! \uD83D\uDE02 https:\/\/t.co\/GNJXdSb2JU",
  "id" : 884299535673110528,
  "created_at" : "2017-07-10 06:33:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/TzoQk2GrDp",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/S912wDrZnYK8E\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/S912wDrZ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113997493679, 8.753325059228478 ]
  },
  "id_str" : "884127980150288384",
  "text" : "the magic of the world wide web https:\/\/t.co\/TzoQk2GrDp",
  "id" : 884127980150288384,
  "created_at" : "2017-07-09 19:11:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/BoeQXBrS2D",
      "expanded_url" : "https:\/\/twitter.com\/blahah404\/status\/884100486000988161",
      "display_url" : "twitter.com\/blahah404\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11397863197423, 8.75340233364082 ]
  },
  "id_str" : "884100857175977986",
  "text" : "The only reason people are seriously against preprints are based in appeasing commercial publishers for one owns prestige as far as I see. https:\/\/t.co\/BoeQXBrS2D",
  "id" : 884100857175977986,
  "created_at" : "2017-07-09 17:24:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/FBNFm6FkSb",
      "expanded_url" : "https:\/\/twitter.com\/WIRED\/status\/883794817750360064",
      "display_url" : "twitter.com\/WIRED\/status\/8\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398000810364, 8.75340292730483 ]
  },
  "id_str" : "884100252734717952",
  "text" : "Don\u2019t see how there\u2019s a convincing side against preprints life sciences these days. https:\/\/t.co\/FBNFm6FkSb",
  "id" : 884100252734717952,
  "created_at" : "2017-07-09 17:21:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "884058700301971458",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396908204339, 8.753373414026743 ]
  },
  "id_str" : "884059953425731584",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics Awww! \uD83D\uDC96\uD83D\uDE0D",
  "id" : 884059953425731584,
  "in_reply_to_status_id" : 884058700301971458,
  "created_at" : "2017-07-09 14:41:32 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "884056802702262272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139926710393, 8.753331658630284 ]
  },
  "id_str" : "884057129216352256",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics That\u2019s how I\u2019ve been walking through \uD83C\uDDEC\uD83C\uDDF7 for a week now. One feels a bit ridiculous. \uD83D\uDE02 and feeling honored! What\u2019s the change in design? \uD83D\uDE0D",
  "id" : 884057129216352256,
  "in_reply_to_status_id" : 884056802702262272,
  "created_at" : "2017-07-09 14:30:19 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 14, 25 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/yQBLeuKOXS",
      "expanded_url" : "https:\/\/instagram.com\/p\/BVkdPmuFjAi\/",
      "display_url" : "instagram.com\/p\/BVkdPmuFjAi\/"
    } ]
  },
  "in_reply_to_status_id_str" : "883707743714111489",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1139926129481, 8.753331016391448 ]
  },
  "id_str" : "884049845547393024",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics @carlzimmer That\u2019s awesome! Welcome to the club of the forced-long-sleeve wearer for a while. https:\/\/t.co\/yQBLeuKOXS \uD83D\uDE02",
  "id" : 884049845547393024,
  "in_reply_to_status_id" : 883707743714111489,
  "created_at" : "2017-07-09 14:01:22 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/YnE2HwC5Vg",
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/884002814883770368",
      "display_url" : "twitter.com\/haaretzcom\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388711971711, 8.753262515819412 ]
  },
  "id_str" : "884029719649374209",
  "text" : "Donating swastika flags to museums: \u00ABwhat I have, besides an unambiguous symbol of evil incarnate, is a classic supply and demand problem.\u00BB https:\/\/t.co\/YnE2HwC5Vg",
  "id" : 884029719649374209,
  "created_at" : "2017-07-09 12:41:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abdelazeem\uD83C\uDF39",
      "screen_name" : "AElhabyan",
      "indices" : [ 0, 10 ],
      "id_str" : "4251126076",
      "id" : 4251126076
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 55, 62 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "883786650379223040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399670208158, 8.753331526750094 ]
  },
  "id_str" : "883810273810952192",
  "in_reply_to_user_id" : 4251126076,
  "text" : "@AElhabyan Thanks! \uD83D\uDE02. I have the WiFi-enabled scale by @fitbit.",
  "id" : 883810273810952192,
  "in_reply_to_status_id" : 883786650379223040,
  "created_at" : "2017-07-08 22:09:24 +0000",
  "in_reply_to_screen_name" : "AElhabyan",
  "in_reply_to_user_id_str" : "4251126076",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 2, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/V6A4LPAm3t",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWTIrFpFx0Q\/",
      "display_url" : "instagram.com\/p\/BWTIrFpFx0Q\/"
    } ]
  },
  "geo" : { },
  "id_str" : "883784849093345280",
  "text" : "\uD83D\uDC4B #latergram https:\/\/t.co\/V6A4LPAm3t",
  "id" : 883784849093345280,
  "created_at" : "2017-07-08 20:28:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11398337332148, 8.753400382934013 ]
  },
  "id_str" : "883756062163316737",
  "text" : "\u00ABI gained 2 kg during that one week, but my body fat percentage didn\u2019t change?!\u00BB \u2014 \u00ABThat\u2019s because you trained your Greek eating muscles!\u00BB",
  "id" : 883756062163316737,
  "created_at" : "2017-07-08 18:33:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "883627447597576193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.93708631332009, 23.9491850240198 ]
  },
  "id_str" : "883629173604069376",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Looks good! :)",
  "id" : 883629173604069376,
  "in_reply_to_status_id" : 883627447597576193,
  "created_at" : "2017-07-08 10:09:46 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/GqQHWKLTZV",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWR-Neclb0Y\/",
      "display_url" : "instagram.com\/p\/BWR-Neclb0Y\/"
    } ]
  },
  "geo" : { },
  "id_str" : "883621097563926529",
  "text" : "The blue in the distance #latergram https:\/\/t.co\/GqQHWKLTZV",
  "id" : 883621097563926529,
  "created_at" : "2017-07-08 09:37:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran O'Neill",
      "screen_name" : "oneillkza",
      "indices" : [ 3, 13 ],
      "id_str" : "100371111",
      "id" : 100371111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISMB2017",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "883441668640428032",
  "text" : "RT @oneillkza: At #ISMB2017, an intersectional discussion of Equity, Diversity and Inclusion in bioinformatics on Monday: https:\/\/t.co\/9wOw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISMB2017",
        "indices" : [ 3, 12 ]
      }, {
        "text" : "iscb_edi",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/9wOweOuPVf",
        "expanded_url" : "https:\/\/www.iscb.org\/ismbeccb2017-program\/ismbeccb2017-bof",
        "display_url" : "iscb.org\/ismbeccb2017-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "883422532526678016",
    "text" : "At #ISMB2017, an intersectional discussion of Equity, Diversity and Inclusion in bioinformatics on Monday: https:\/\/t.co\/9wOweOuPVf #iscb_edi",
    "id" : 883422532526678016,
    "created_at" : "2017-07-07 20:28:39 +0000",
    "user" : {
      "name" : "Kieran O'Neill",
      "screen_name" : "oneillkza",
      "protected" : false,
      "id_str" : "100371111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620262526580883457\/7WEBO8wV_normal.jpg",
      "id" : 100371111,
      "verified" : false
    }
  },
  "id" : 883441668640428032,
  "created_at" : "2017-07-07 21:44:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Boyden",
      "screen_name" : "eboyden3",
      "indices" : [ 3, 12 ],
      "id_str" : "17230461",
      "id" : 17230461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/2qRLfMGR8i",
      "expanded_url" : "https:\/\/www.media.mit.edu\/posts\/adventurous-science-fellows\/",
      "display_url" : "media.mit.edu\/posts\/adventur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "883439612470988800",
  "text" : "RT @eboyden3: Know someone who would benefit from $150k to have the freedom to do some adventurous science? https:\/\/t.co\/2qRLfMGR8i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/2qRLfMGR8i",
        "expanded_url" : "https:\/\/www.media.mit.edu\/posts\/adventurous-science-fellows\/",
        "display_url" : "media.mit.edu\/posts\/adventur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "883186427487498240",
    "text" : "Know someone who would benefit from $150k to have the freedom to do some adventurous science? https:\/\/t.co\/2qRLfMGR8i",
    "id" : 883186427487498240,
    "created_at" : "2017-07-07 04:50:27 +0000",
    "user" : {
      "name" : "Ed Boyden",
      "screen_name" : "eboyden3",
      "protected" : false,
      "id_str" : "17230461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/858710546589396994\/enwrb3cB_normal.jpg",
      "id" : 17230461,
      "verified" : true
    }
  },
  "id" : 883439612470988800,
  "created_at" : "2017-07-07 21:36:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mozwow",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/MCYiRxSDsI",
      "expanded_url" : "https:\/\/twitter.com\/foss4g\/status\/883430542175350784",
      "display_url" : "twitter.com\/foss4g\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "883437841224806400",
  "text" : "RT @auremoser: Hey all, this is circa our #mozwow in Boston, geo-folks should join in! https:\/\/t.co\/MCYiRxSDsI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mozwow",
        "indices" : [ 27, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/MCYiRxSDsI",
        "expanded_url" : "https:\/\/twitter.com\/foss4g\/status\/883430542175350784",
        "display_url" : "twitter.com\/foss4g\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "883432975802785793",
    "text" : "Hey all, this is circa our #mozwow in Boston, geo-folks should join in! https:\/\/t.co\/MCYiRxSDsI",
    "id" : 883432975802785793,
    "created_at" : "2017-07-07 21:10:09 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 883437841224806400,
  "created_at" : "2017-07-07 21:29:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "883390564237950976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05871017883842, 23.79562592645943 ]
  },
  "id_str" : "883435386520973312",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime Let\u2019s see. Having an appointment to fix things on the 17th.",
  "id" : 883435386520973312,
  "in_reply_to_status_id" : 883390564237950976,
  "created_at" : "2017-07-07 21:19:44 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/zu8PMpek0u",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWQDWzCluVI\/",
      "display_url" : "instagram.com\/p\/BWQDWzCluVI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "883350929243750400",
  "text" : "\uD83C\uDFCA \u2705. Just in time before heading back. https:\/\/t.co\/zu8PMpek0u",
  "id" : 883350929243750400,
  "created_at" : "2017-07-07 15:44:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/TsOTIJgi4C",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWP8YT1lC9z\/",
      "display_url" : "instagram.com\/p\/BWP8YT1lC9z\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.9294824677, 23.7003904154 ]
  },
  "id_str" : "883335604330745856",
  "text" : "Landlocked \uD83D\uDEA4\u2693\uFE0F @ Palai\u00F3n F\u00E1liron, Attiki, Greece https:\/\/t.co\/TsOTIJgi4C",
  "id" : 883335604330745856,
  "created_at" : "2017-07-07 14:43:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/fBuA8Dhv0R",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWPxzKylmw1\/",
      "display_url" : "instagram.com\/p\/BWPxzKylmw1\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.929870750255, 23.68529236952 ]
  },
  "id_str" : "883312326727913472",
  "text" : "\uD83C\uDF0A @ \u039C\u03B1\u03C1\u03AF\u03BD\u03B1 \u03A6\u03BB\u03BF\u03AF\u03C3\u03B2\u03BF\u03C5 - Flisvos Marina https:\/\/t.co\/fBuA8Dhv0R",
  "id" : 883312326727913472,
  "created_at" : "2017-07-07 13:10:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/kdrKPXzECb",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/883251532157898752",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "883251532157898752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.96731221027483, 23.73416718097751 ]
  },
  "id_str" : "883275909628932096",
  "in_reply_to_user_id" : 14286491,
  "text" : "Sending a single email to my own vital records office was more helpful than all of these combined. \uD83D\uDE02\uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/kdrKPXzECb",
  "id" : 883275909628932096,
  "in_reply_to_status_id" : 883251532157898752,
  "created_at" : "2017-07-07 10:46:01 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05863931717537, 23.79563966459487 ]
  },
  "id_str" : "883251532157898752",
  "text" : "Now spent 4 out of 5 days at the local city hall in order to figure out the bureaucracy. To no avail.",
  "id" : 883251532157898752,
  "created_at" : "2017-07-07 09:09:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Eckmeier, not that kind of Dr.",
      "screen_name" : "DennisEckmeier",
      "indices" : [ 3, 18 ],
      "id_str" : "595982444",
      "id" : 595982444
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "883243188575764480",
  "text" : "RT @DennisEckmeier: I had to lend a PhD student money because our admins didn't give her the 'advance' before she had to pay for a while co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 134, 157 ],
        "url" : "https:\/\/t.co\/t8LCFHR3JQ",
        "expanded_url" : "https:\/\/twitter.com\/chartgerink\/status\/883220584049635328",
        "display_url" : "twitter.com\/chartgerink\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "883222021307551744",
    "text" : "I had to lend a PhD student money because our admins didn't give her the 'advance' before she had to pay for a while conference trip. https:\/\/t.co\/t8LCFHR3JQ",
    "id" : 883222021307551744,
    "created_at" : "2017-07-07 07:11:54 +0000",
    "user" : {
      "name" : "Dennis Eckmeier, not that kind of Dr.",
      "screen_name" : "DennisEckmeier",
      "protected" : false,
      "id_str" : "595982444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929491062569209856\/bUhldb3h_normal.jpg",
      "id" : 595982444,
      "verified" : false
    }
  },
  "id" : 883243188575764480,
  "created_at" : "2017-07-07 08:36:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael",
      "screen_name" : "The_Smoking_GNU",
      "indices" : [ 0, 16 ],
      "id_str" : "14535787",
      "id" : 14535787
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "883210354188333056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05912988263933, 23.79627574237417 ]
  },
  "id_str" : "883217354397802496",
  "in_reply_to_user_id" : 14535787,
  "text" : "@The_Smoking_GNU Danke! :)",
  "id" : 883217354397802496,
  "in_reply_to_status_id" : 883210354188333056,
  "created_at" : "2017-07-07 06:53:21 +0000",
  "in_reply_to_screen_name" : "The_Smoking_GNU",
  "in_reply_to_user_id_str" : "14535787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 3, 17 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/y2bOE8T2MK",
      "expanded_url" : "https:\/\/twitter.com\/nyashajunior\/status\/883029962688786432",
      "display_url" : "twitter.com\/nyashajunior\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "883205271413301248",
  "text" : "RT @AprilHathcock: I want to revisit this for a moment. https:\/\/t.co\/y2bOE8T2MK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/y2bOE8T2MK",
        "expanded_url" : "https:\/\/twitter.com\/nyashajunior\/status\/883029962688786432",
        "display_url" : "twitter.com\/nyashajunior\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "883191029381431296",
    "text" : "I want to revisit this for a moment. https:\/\/t.co\/y2bOE8T2MK",
    "id" : 883191029381431296,
    "created_at" : "2017-07-07 05:08:44 +0000",
    "user" : {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "protected" : false,
      "id_str" : "3209949862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925100168277618693\/8UJUY3i2_normal.jpg",
      "id" : 3209949862,
      "verified" : false
    }
  },
  "id" : 883205271413301248,
  "created_at" : "2017-07-07 06:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    }, {
      "name" : "Hackerspace Prague",
      "screen_name" : "brmlab",
      "indices" : [ 83, 90 ],
      "id_str" : "163493365",
      "id" : 163493365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/PrGJcWbuCp",
      "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/Codefest_2017",
      "display_url" : "open-bio.org\/wiki\/Codefest_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "883030984584822784",
  "text" : "RT @OBF_BOSC: Codefest, the FREE pre-BOSC collaborative coding event, kicks off at @brmlab in 2 weeks! Sign up at https:\/\/t.co\/PrGJcWbuCp!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hackerspace Prague",
        "screen_name" : "brmlab",
        "indices" : [ 69, 76 ],
        "id_str" : "163493365",
        "id" : 163493365
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2017",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/PrGJcWbuCp",
        "expanded_url" : "https:\/\/www.open-bio.org\/wiki\/Codefest_2017",
        "display_url" : "open-bio.org\/wiki\/Codefest_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "883030888358871041",
    "text" : "Codefest, the FREE pre-BOSC collaborative coding event, kicks off at @brmlab in 2 weeks! Sign up at https:\/\/t.co\/PrGJcWbuCp!  #BOSC2017",
    "id" : 883030888358871041,
    "created_at" : "2017-07-06 18:32:24 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 883030984584822784,
  "created_at" : "2017-07-06 18:32:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 0, 11 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "883028129002008582",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06207653011984, 23.79609354995362 ]
  },
  "id_str" : "883030412297199618",
  "in_reply_to_user_id" : 971867420,
  "text" : "@alibi_rage 10\/11 \uD83D\uDE02",
  "id" : 883030412297199618,
  "in_reply_to_status_id" : 883028129002008582,
  "created_at" : "2017-07-06 18:30:30 +0000",
  "in_reply_to_screen_name" : "alibi_rage",
  "in_reply_to_user_id_str" : "971867420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/qGIQPBX65x",
      "expanded_url" : "https:\/\/dynamicecology.wordpress.com\/2017\/07\/06\/guest-post-the-day-i-broke-some-twitter-feeds-insights-into-sexism-in-academia-part-1\/",
      "display_url" : "dynamicecology.wordpress.com\/2017\/07\/06\/gue\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05866840308711, 23.79571382156603 ]
  },
  "id_str" : "883011401144557568",
  "text" : "\u00ABThe day I broke some twitter feeds: insights into sexism in academia\u00BB https:\/\/t.co\/qGIQPBX65x",
  "id" : 883011401144557568,
  "created_at" : "2017-07-06 17:14:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/VizHSjVNuB",
      "expanded_url" : "https:\/\/twitter.com\/jamesheathers\/status\/882949874949509120",
      "display_url" : "twitter.com\/jamesheathers\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "883002387052548096",
  "text" : "Both depression and anxiety. https:\/\/t.co\/VizHSjVNuB",
  "id" : 883002387052548096,
  "created_at" : "2017-07-06 16:39:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 3, 13 ],
      "id_str" : "267256091",
      "id" : 267256091
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 40, 49 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/oC766PPWjM",
      "expanded_url" : "https:\/\/ropensci.org\/blog\/blog\/2017\/07\/06\/ropensci-fellowships",
      "display_url" : "ropensci.org\/blog\/blog\/2017\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "883001778324877312",
  "text" : "RT @_inundata: Very excited to announce @rOpenSci\u2019s fellowship program! Apply for funding by Sep 1. https:\/\/t.co\/oC766PPWjM #openscience",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "rOpenSci",
        "screen_name" : "rOpenSci",
        "indices" : [ 25, 34 ],
        "id_str" : "342250615",
        "id" : 342250615
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/oC766PPWjM",
        "expanded_url" : "https:\/\/ropensci.org\/blog\/blog\/2017\/07\/06\/ropensci-fellowships",
        "display_url" : "ropensci.org\/blog\/blog\/2017\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "882996545741651968",
    "text" : "Very excited to announce @rOpenSci\u2019s fellowship program! Apply for funding by Sep 1. https:\/\/t.co\/oC766PPWjM #openscience",
    "id" : 882996545741651968,
    "created_at" : "2017-07-06 16:15:56 +0000",
    "user" : {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "protected" : false,
      "id_str" : "267256091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520412914046345216\/Kwa3J7yn_normal.jpeg",
      "id" : 267256091,
      "verified" : false
    }
  },
  "id" : 883001778324877312,
  "created_at" : "2017-07-06 16:36:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clue",
      "screen_name" : "clue",
      "indices" : [ 3, 8 ],
      "id_str" : "1055079392",
      "id" : 1055079392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/vfeiJ0Ejfq",
      "expanded_url" : "http:\/\/www.helloclue.com\/jobs.html",
      "display_url" : "helloclue.com\/jobs.html"
    } ]
  },
  "geo" : { },
  "id_str" : "883000335597543426",
  "text" : "RT @clue: We're hiring! Help Clue push female health forward and join our team in Berlin. \uD83D\uDC4B\uD83C\uDFFB \uD83D\uDC4B\uD83C\uDFFC \uD83D\uDC4B\uD83C\uDFFD \uD83D\uDC4B\uD83C\uDFFE \uD83D\uDC4B\uD83C\uDFFF\nhttps:\/\/t.co\/vfeiJ0Ejfq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/vfeiJ0Ejfq",
        "expanded_url" : "http:\/\/www.helloclue.com\/jobs.html",
        "display_url" : "helloclue.com\/jobs.html"
      } ]
    },
    "geo" : { },
    "id_str" : "882986814599987200",
    "text" : "We're hiring! Help Clue push female health forward and join our team in Berlin. \uD83D\uDC4B\uD83C\uDFFB \uD83D\uDC4B\uD83C\uDFFC \uD83D\uDC4B\uD83C\uDFFD \uD83D\uDC4B\uD83C\uDFFE \uD83D\uDC4B\uD83C\uDFFF\nhttps:\/\/t.co\/vfeiJ0Ejfq",
    "id" : 882986814599987200,
    "created_at" : "2017-07-06 15:37:16 +0000",
    "user" : {
      "name" : "Clue",
      "screen_name" : "clue",
      "protected" : false,
      "id_str" : "1055079392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826816897899515906\/EZ278Jjj_normal.jpg",
      "id" : 1055079392,
      "verified" : true
    }
  },
  "id" : 883000335597543426,
  "created_at" : "2017-07-06 16:31:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hexing Decimals",
      "screen_name" : "CoralineAda",
      "indices" : [ 3, 15 ],
      "id_str" : "9526722",
      "id" : 9526722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/HDYofXS82o",
      "expanded_url" : "http:\/\/where.coraline.codes\/blog\/my-year-at-github\/",
      "display_url" : "where.coraline.codes\/blog\/my-year-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "882994023736233984",
  "text" : "RT @CoralineAda: I am finally ready tell my story.\n\n\u201CAntisocial Coding: My Year at GitHub\u201D\n\nhttps:\/\/t.co\/HDYofXS82o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/HDYofXS82o",
        "expanded_url" : "http:\/\/where.coraline.codes\/blog\/my-year-at-github\/",
        "display_url" : "where.coraline.codes\/blog\/my-year-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "882627909118304256",
    "text" : "I am finally ready tell my story.\n\n\u201CAntisocial Coding: My Year at GitHub\u201D\n\nhttps:\/\/t.co\/HDYofXS82o",
    "id" : 882627909118304256,
    "created_at" : "2017-07-05 15:51:06 +0000",
    "user" : {
      "name" : "Hexing Decimals",
      "screen_name" : "CoralineAda",
      "protected" : false,
      "id_str" : "9526722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927212875797745665\/mzQ2WVxK_normal.jpg",
      "id" : 9526722,
      "verified" : true
    }
  },
  "id" : 882994023736233984,
  "created_at" : "2017-07-06 16:05:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882950760035700736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.04939606230524, 23.79981902430188 ]
  },
  "id_str" : "882970932012306436",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Wrote to the consulate, just to get their interpretation. \uD83D\uDE02",
  "id" : 882970932012306436,
  "in_reply_to_status_id" : 882950760035700736,
  "created_at" : "2017-07-06 14:34:09 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naim Matasci",
      "screen_name" : "nmatasci",
      "indices" : [ 0, 9 ],
      "id_str" : "322061462",
      "id" : 322061462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882959936979779584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.04940108206337, 23.79979590983439 ]
  },
  "id_str" : "882970740953403394",
  "in_reply_to_user_id" : 322061462,
  "text" : "@nmatasci All the fun. I think in principle we can follow \uD83C\uDDEC\uD83C\uDDF7law these days. But they don\u2019t feel responsible at all.",
  "id" : 882970740953403394,
  "in_reply_to_status_id" : 882959936979779584,
  "created_at" : "2017-07-06 14:33:24 +0000",
  "in_reply_to_screen_name" : "nmatasci",
  "in_reply_to_user_id_str" : "322061462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882949385327435776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.04935796655533, 23.79976538012158 ]
  },
  "id_str" : "882970038613008384",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps Oh, right. I wasn\u2019t outright in \u2018look who\u2019s getting married\u2019! \uD83D\uDE02",
  "id" : 882970038613008384,
  "in_reply_to_status_id" : 882949385327435776,
  "created_at" : "2017-07-06 14:30:36 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882947839210532865",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05869670588342, 23.79562002608906 ]
  },
  "id_str" : "882948260662583296",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps Thanks! (And didn\u2019t I write into Tuesday\u2019s agenda that I\u2019d be missing it due to a wedding? ;))",
  "id" : 882948260662583296,
  "in_reply_to_status_id" : 882947839210532865,
  "created_at" : "2017-07-06 13:04:04 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882942672562003969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05873082022933, 23.79574131222795 ]
  },
  "id_str" : "882946884742127619",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon as all the sources from German consulates seem to be very clear: \uD83C\uDDE9\uD83C\uDDEA accepts whatever other law is dictated through the second nationality.",
  "id" : 882946884742127619,
  "in_reply_to_status_id" : 882942672562003969,
  "created_at" : "2017-07-06 12:58:36 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Gwen Franck",
      "screen_name" : "g_fra",
      "indices" : [ 10, 16 ],
      "id_str" : "200122481",
      "id" : 200122481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882942672562003969",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05873082022933, 23.79574131222795 ]
  },
  "id_str" : "882946480964874241",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @g_fra Instead we now read up on international family law and will try our luck at the vital records office again tomorrow.",
  "id" : 882946480964874241,
  "in_reply_to_status_id" : 882942672562003969,
  "created_at" : "2017-07-06 12:57:00 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 11, 19 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882927070569013248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05897683598725, 23.79575663176151 ]
  },
  "id_str" : "882941612506140672",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @pjacock Yep, apparently. At least there\u2019s one woman who\u2019s heading a family now.",
  "id" : 882941612506140672,
  "in_reply_to_status_id" : 882927070569013248,
  "created_at" : "2017-07-06 12:37:39 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwen Franck",
      "screen_name" : "g_fra",
      "indices" : [ 0, 6 ],
      "id_str" : "200122481",
      "id" : 200122481
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 73, 82 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882926210472398848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06207091025684, 23.79609274262711 ]
  },
  "id_str" : "882941407652196352",
  "in_reply_to_user_id" : 200122481,
  "text" : "@g_fra Damn, you\u2019re too late. We could have caught a ride to Patras with @Senficon this noon but she already left now!",
  "id" : 882941407652196352,
  "in_reply_to_status_id" : 882926210472398848,
  "created_at" : "2017-07-06 12:36:50 +0000",
  "in_reply_to_screen_name" : "g_fra",
  "in_reply_to_user_id_str" : "200122481",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 11, 19 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882923345716662273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05883859024835, 23.79556431708574 ]
  },
  "id_str" : "882924829384552448",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @pjacock Seems we\u2019re creating legal edge cases left and right.",
  "id" : 882924829384552448,
  "in_reply_to_status_id" : 882923345716662273,
  "created_at" : "2017-07-06 11:30:57 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 11, 19 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882923345716662273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05883859024835, 23.79556431708574 ]
  },
  "id_str" : "882924740922552320",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko @pjacock \uD83C\uDDEC\uD83C\uDDF7 law is very patriarchic in that sense too. Had to re-gender all forms today as I can\u2019t be \u201Chead of the family\u201D as a non-citizen. \uD83D\uDE02",
  "id" : 882924740922552320,
  "in_reply_to_status_id" : 882923345716662273,
  "created_at" : "2017-07-06 11:30:36 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882913874634211329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06969790483887, 23.79082083250195 ]
  },
  "id_str" : "882915959203401728",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock What about both partners changing to a combined name?",
  "id" : 882915959203401728,
  "in_reply_to_status_id" : 882913874634211329,
  "created_at" : "2017-07-06 10:55:43 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Galardini",
      "screen_name" : "mgalactus",
      "indices" : [ 0, 10 ],
      "id_str" : "531045394",
      "id" : 531045394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882909401241321472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06928625968212, 23.79118708412207 ]
  },
  "id_str" : "882910289859162113",
  "in_reply_to_user_id" : 531045394,
  "text" : "@mgalactus No actual need to but we want to.",
  "id" : 882910289859162113,
  "in_reply_to_status_id" : 882909401241321472,
  "created_at" : "2017-07-06 10:33:11 +0000",
  "in_reply_to_screen_name" : "mgalactus",
  "in_reply_to_user_id_str" : "531045394",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05877529479695, 23.79560717792256 ]
  },
  "id_str" : "882908855486873600",
  "text" : "A matter for international law experts: name changes between \uD83C\uDDEC\uD83C\uDDF7 &amp; \uD83C\uDDE9\uD83C\uDDEA citizens, living in \uD83C\uDDE8\uD83C\uDDED &amp; \uD83C\uDDE9\uD83C\uDDEA when the wedding is done in \uD83C\uDDEC\uD83C\uDDF7. \uD83E\uDD37\u200D\u2640\uFE0F\uD83E\uDD26\u200D\u2640\uFE0F",
  "id" : 882908855486873600,
  "created_at" : "2017-07-06 10:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bev acreman",
      "screen_name" : "bev_a",
      "indices" : [ 0, 6 ],
      "id_str" : "27021802",
      "id" : 27021802
    }, {
      "name" : "F1000",
      "screen_name" : "F1000",
      "indices" : [ 7, 13 ],
      "id_str" : "748543945823633408",
      "id" : 748543945823633408
    }, {
      "name" : "bioRxiv",
      "screen_name" : "biorxivpreprint",
      "indices" : [ 67, 83 ],
      "id_str" : "1949132852",
      "id" : 1949132852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882881703630577664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05886694233683, 23.79550628366302 ]
  },
  "id_str" : "882907993074958336",
  "in_reply_to_user_id" : 27021802,
  "text" : "@bev_a @F1000 To that come the views for the preprint deposited to @biorxivpreprint :)",
  "id" : 882907993074958336,
  "in_reply_to_status_id" : 882881703630577664,
  "created_at" : "2017-07-06 10:24:03 +0000",
  "in_reply_to_screen_name" : "bev_a",
  "in_reply_to_user_id_str" : "27021802",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06173679999998, 23.79937615999999 ]
  },
  "id_str" : "882868391354171392",
  "text" : "By now I\u2019m wholly convinced that the Greek bureaucracy mistook Kafka\u2019s corpus as an instruction manual.",
  "id" : 882868391354171392,
  "created_at" : "2017-07-06 07:46:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Munoz-Torres",
      "screen_name" : "monimunozto",
      "indices" : [ 0, 12 ],
      "id_str" : "538714687",
      "id" : 538714687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882747833752801280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05886153600929, 23.79543411547672 ]
  },
  "id_str" : "882823835514540034",
  "in_reply_to_user_id" : 538714687,
  "text" : "@monimunozto Thanks! :)",
  "id" : 882823835514540034,
  "in_reply_to_status_id" : 882747833752801280,
  "created_at" : "2017-07-06 04:49:39 +0000",
  "in_reply_to_screen_name" : "monimunozto",
  "in_reply_to_user_id_str" : "538714687",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nomi Harris",
      "screen_name" : "NomiHarris",
      "indices" : [ 0, 11 ],
      "id_str" : "351049850",
      "id" : 351049850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882668675945209856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.96759300403107, 23.73295834290211 ]
  },
  "id_str" : "882672216701358080",
  "in_reply_to_user_id" : 351049850,
  "text" : "@NomiHarris I did! Thanks! \uD83C\uDF89",
  "id" : 882672216701358080,
  "in_reply_to_status_id" : 882668675945209856,
  "created_at" : "2017-07-05 18:47:10 +0000",
  "in_reply_to_screen_name" : "NomiHarris",
  "in_reply_to_user_id_str" : "351049850",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "indices" : [ 3, 16 ],
      "id_str" : "7841792",
      "id" : 7841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "882649270310064130",
  "text" : "RT @SteveMcLaugh: For those following the American Chemical Society's case against Sci-Hub, I've started collecting legal docs here: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/oy5fx3tOP0",
        "expanded_url" : "http:\/\/www.stephenmclaughlin.net\/American_Chemical_Society_v_Does_1-99\/",
        "display_url" : "stephenmclaughlin.net\/American_Chemi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "882634536202457088",
    "text" : "For those following the American Chemical Society's case against Sci-Hub, I've started collecting legal docs here: https:\/\/t.co\/oy5fx3tOP0",
    "id" : 882634536202457088,
    "created_at" : "2017-07-05 16:17:26 +0000",
    "user" : {
      "name" : "Steve McLaughlin\uD83C\uDF3E\uD83D\uDCBE",
      "screen_name" : "SteveMcLaugh",
      "protected" : false,
      "id_str" : "7841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776533899555909633\/MvNi9Ve5_normal.jpg",
      "id" : 7841792,
      "verified" : false
    }
  },
  "id" : 882649270310064130,
  "created_at" : "2017-07-05 17:15:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882600680296292352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05873702548968, 23.79571885543079 ]
  },
  "id_str" : "882613202768539648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer So local support is possible if needed. :)",
  "id" : 882613202768539648,
  "in_reply_to_status_id" : 882600680296292352,
  "created_at" : "2017-07-05 14:52:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882600625573289984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05869112990385, 23.79569961849497 ]
  },
  "id_str" : "882613120082087937",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I needed to get one for the Greeks. The Germans didn\u2019t want one I think. But my spouse\u2019s parents live 20 mins from city hall here.",
  "id" : 882613120082087937,
  "in_reply_to_status_id" : 882600625573289984,
  "created_at" : "2017-07-05 14:52:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882597501492019200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05338706359086, 23.82404817270471 ]
  },
  "id_str" : "882598582888607744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u2026i needed to get one translated so that they\u2019d see my name in Greek characters instead of Latin.",
  "id" : 882598582888607744,
  "in_reply_to_status_id" : 882597501492019200,
  "created_at" : "2017-07-05 13:54:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882597501492019200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0514105892423, 23.83905576231386 ]
  },
  "id_str" : "882598500961267712",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Not sure how it\u2019ll work in this case. My Ehef\u00E4higkeitszeugnis and birth certificate are European in principle. But due to character sets\u2026",
  "id" : 882598500961267712,
  "in_reply_to_status_id" : 882597501492019200,
  "created_at" : "2017-07-05 13:54:15 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Pablo Alperin",
      "screen_name" : "juancommander",
      "indices" : [ 0, 14 ],
      "id_str" : "388503174",
      "id" : 388503174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882580640713060354",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.04890211215801, 23.83979946175614 ]
  },
  "id_str" : "882597352367902720",
  "in_reply_to_user_id" : 388503174,
  "text" : "@juancommander Thanks!",
  "id" : 882597352367902720,
  "in_reply_to_status_id" : 882580640713060354,
  "created_at" : "2017-07-05 13:49:41 +0000",
  "in_reply_to_screen_name" : "juancommander",
  "in_reply_to_user_id_str" : "388503174",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882553093887373314",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05231962822196, 23.85055694731311 ]
  },
  "id_str" : "882597130883543044",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer German, English, Japanese? We had to invoke German, Swiss and Greek authorities. Was already fun enough.",
  "id" : 882597130883543044,
  "in_reply_to_status_id" : 882553093887373314,
  "created_at" : "2017-07-05 13:48:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liber2017",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05216308750533, 23.86559081738801 ]
  },
  "id_str" : "882590682019491840",
  "text" : "Let\u2019s say we\u2019d like to have an extremely nerdy honeymoon. Are any of my library friends at #liber2017? \uD83D\uDE02 \uD83D\uDCDA",
  "id" : 882590682019491840,
  "created_at" : "2017-07-05 13:23:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882551596843847681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0505610349762, 23.84490026673129 ]
  },
  "id_str" : "882552094720479232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Just register it there. We went through all the kafkaesque international paperwork here, so no big wish to do that a second time.",
  "id" : 882552094720479232,
  "in_reply_to_status_id" : 882551596843847681,
  "created_at" : "2017-07-05 10:49:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882550478978076672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.04340195379969, 23.83510163987413 ]
  },
  "id_str" : "882551284791947265",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena We will have to celebrate in Z\u00FCrich after our return!",
  "id" : 882551284791947265,
  "in_reply_to_status_id" : 882550478978076672,
  "created_at" : "2017-07-05 10:46:37 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882550657038864384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.04246741350558, 23.83376874963179 ]
  },
  "id_str" : "882550990137958401",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ Danke!",
  "id" : 882550990137958401,
  "in_reply_to_status_id" : 882550657038864384,
  "created_at" : "2017-07-05 10:45:27 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882549803187490816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.04151732478108, 23.83234231735005 ]
  },
  "id_str" : "882550970902884353",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Thanks!",
  "id" : 882550970902884353,
  "in_reply_to_status_id" : 882549803187490816,
  "created_at" : "2017-07-05 10:45:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LabWorm",
      "screen_name" : "TheLabWorm",
      "indices" : [ 3, 14 ],
      "id_str" : "2512604281",
      "id" : 2512604281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/RJgr9zc8kp",
      "expanded_url" : "http:\/\/Labworm.com",
      "display_url" : "Labworm.com"
    } ]
  },
  "geo" : { },
  "id_str" : "882548714061090816",
  "text" : "RT @TheLabWorm: Featured now: openSNP, crowdsourcing genome wide association studies. Vote it up at https:\/\/t.co\/RJgr9zc8kp! Top 5 voted an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheLabWorm\/status\/882547538972291073\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/Eg5V24i9o5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DD9wIbmXcAAuc1H.jpg",
        "id_str" : "882547342137847808",
        "id" : 882547342137847808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DD9wIbmXcAAuc1H.jpg",
        "sizes" : [ {
          "h" : 395,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 650
        } ],
        "display_url" : "pic.twitter.com\/Eg5V24i9o5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/RJgr9zc8kp",
        "expanded_url" : "http:\/\/Labworm.com",
        "display_url" : "Labworm.com"
      } ]
    },
    "geo" : { },
    "id_str" : "882547538972291073",
    "text" : "Featured now: openSNP, crowdsourcing genome wide association studies. Vote it up at https:\/\/t.co\/RJgr9zc8kp! Top 5 voted announced next week https:\/\/t.co\/Eg5V24i9o5",
    "id" : 882547538972291073,
    "created_at" : "2017-07-05 10:31:44 +0000",
    "user" : {
      "name" : "LabWorm",
      "screen_name" : "TheLabWorm",
      "protected" : false,
      "id_str" : "2512604281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876336468234563588\/DRP37Eqh_normal.jpg",
      "id" : 2512604281,
      "verified" : false
    }
  },
  "id" : 882548714061090816,
  "created_at" : "2017-07-05 10:36:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 3, 12 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 84, 95 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenData",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "openscience",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "882548174665261056",
  "text" : "RT @crowd_ai: Delighted to launch the first genetic Machine Learning challenge with @openSNPorg! #OpenData #openscience https:\/\/t.co\/gpHYrv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 70, 81 ],
        "id_str" : "380205172",
        "id" : 380205172
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crowd_ai\/status\/882529266738622465\/photo\/1",
        "indices" : [ 130, 153 ],
        "url" : "https:\/\/t.co\/pWQ83KGZAc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DD9frQOXYAE7q2x.jpg",
        "id_str" : "882529248682139649",
        "id" : 882529248682139649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DD9frQOXYAE7q2x.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1242,
          "resize" : "fit",
          "w" : 2208
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/pWQ83KGZAc"
      } ],
      "hashtags" : [ {
        "text" : "OpenData",
        "indices" : [ 83, 92 ]
      }, {
        "text" : "openscience",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/gpHYrvV6mT",
        "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
        "display_url" : "crowdai.org\/challenges\/ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "882529266738622465",
    "text" : "Delighted to launch the first genetic Machine Learning challenge with @openSNPorg! #OpenData #openscience https:\/\/t.co\/gpHYrvV6mT https:\/\/t.co\/pWQ83KGZAc",
    "id" : 882529266738622465,
    "created_at" : "2017-07-05 09:19:08 +0000",
    "user" : {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "protected" : false,
      "id_str" : "706885331224813568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710716318849363968\/JG-XbwBL_normal.jpg",
      "id" : 706885331224813568,
      "verified" : false
    }
  },
  "id" : 882548174665261056,
  "created_at" : "2017-07-05 10:34:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/nwUjxZRQVG",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWKWMJClLAE\/",
      "display_url" : "instagram.com\/p\/BWKWMJClLAE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0604648, 23.7892798 ]
  },
  "id_str" : "882547934956593152",
  "text" : "\uD83D\uDC8D\uD83D\uDD04\uD83D\uDC8D\u2705 @ \u03A0\u03B5\u03C5\u03BA\u03B7,\u03B1\u03C4\u03C4\u03B9\u03BA\u03B7 https:\/\/t.co\/nwUjxZRQVG",
  "id" : 882547934956593152,
  "created_at" : "2017-07-05 10:33:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Xy7h0fM2fb",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWKVI3hF5II\/",
      "display_url" : "instagram.com\/p\/BWKVI3hF5II\/"
    } ]
  },
  "geo" : { },
  "id_str" : "882545609835786240",
  "text" : "Nothing says 'statistically significant other' like a split normal distribution on the \uD83D\uDC8D. https:\/\/t.co\/Xy7h0fM2fb",
  "id" : 882545609835786240,
  "created_at" : "2017-07-05 10:24:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/882488425143783424\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/24LiKAArLI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DD86ie9WsAAY2FS.jpg",
      "id_str" : "882488416088272896",
      "id" : 882488416088272896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DD86ie9WsAAY2FS.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 272
      } ],
      "display_url" : "pic.twitter.com\/24LiKAArLI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0588272121158, 23.7959045078827 ]
  },
  "id_str" : "882488425143783424",
  "text" : "Oversleeping and being woken up by a calendar reminder like\u2026 https:\/\/t.co\/24LiKAArLI",
  "id" : 882488425143783424,
  "created_at" : "2017-07-05 06:36:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 0, 8 ],
      "id_str" : "748130881",
      "id" : 748130881
    }, {
      "name" : "VALIUM",
      "screen_name" : "alibi_rage",
      "indices" : [ 9, 20 ],
      "id_str" : "971867420",
      "id" : 971867420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882304726230073345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06210509916419, 23.79609685982654 ]
  },
  "id_str" : "882305745236221952",
  "in_reply_to_user_id" : 748130881,
  "text" : "@rantleb @alibi_rage Ich denke der Kater hat bald seinen eigenen Wiki-Artikel. Weiterleitung von \u2018Das Wunder von Offenbach\u2019 zu \u2018Miller (Kater)\u2019.",
  "id" : 882305745236221952,
  "in_reply_to_status_id" : 882304726230073345,
  "created_at" : "2017-07-04 18:30:56 +0000",
  "in_reply_to_screen_name" : "rantleb",
  "in_reply_to_user_id_str" : "748130881",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/zI04tozN2k",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWIatnFlIml\/",
      "display_url" : "instagram.com\/p\/BWIatnFlIml\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.9693276, 23.7283319 ]
  },
  "id_str" : "882276396877234176",
  "text" : "\uD83E\uDD89 @ Akropolis Parthenon - \u0391\u03BA\u03C1\u03CC\u03C0\u03BF\u03BB\u03B7 \u03A0\u03B1\u03C1\u03B8\u03B5\u03BD\u03CE\u03BD\u03B1\u03C2 https:\/\/t.co\/zI04tozN2k",
  "id" : 882276396877234176,
  "created_at" : "2017-07-04 16:34:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/JyBLMnACmV",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWIBNcal7vn\/",
      "display_url" : "instagram.com\/p\/BWIBNcal7vn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "882220316172398592",
  "text" : "Tourism-part \u2705 https:\/\/t.co\/JyBLMnACmV",
  "id" : 882220316172398592,
  "created_at" : "2017-07-04 12:51:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Charlesworth",
      "screen_name" : "janepipistrelle",
      "indices" : [ 3, 19 ],
      "id_str" : "328098087",
      "id" : 328098087
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 21, 37 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "882171448361537537",
  "text" : "RT @janepipistrelle: @gedankenstuecke yes, all of that is so true.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "882111383311187968",
    "geo" : { },
    "id_str" : "882138734929600512",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke yes, all of that is so true.",
    "id" : 882138734929600512,
    "in_reply_to_status_id" : 882111383311187968,
    "created_at" : "2017-07-04 07:27:18 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Jane Charlesworth",
      "screen_name" : "janepipistrelle",
      "protected" : false,
      "id_str" : "328098087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/818557189409357826\/VTthkQD2_normal.jpg",
      "id" : 328098087,
      "verified" : false
    }
  },
  "id" : 882171448361537537,
  "created_at" : "2017-07-04 09:37:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/pstnYB2DOU",
      "expanded_url" : "https:\/\/twitter.com\/Julie_B92\/status\/882109264797589505",
      "display_url" : "twitter.com\/Julie_B92\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05867024470739, 23.79569521332624 ]
  },
  "id_str" : "882111383311187968",
  "text" : "A thread worth reading if you\u2019re a struggling PhD student too. https:\/\/t.co\/pstnYB2DOU",
  "id" : 882111383311187968,
  "created_at" : "2017-07-04 05:38:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin\u24D0 Logan",
      "screen_name" : "LoganCorina",
      "indices" : [ 3, 15 ],
      "id_str" : "840002166",
      "id" : 840002166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BulliedIntoBadScience",
      "indices" : [ 17, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Rjrm0p6x70",
      "expanded_url" : "http:\/\/bulliedintobadscience.org",
      "display_url" : "bulliedintobadscience.org"
    } ]
  },
  "geo" : { },
  "id_str" : "882099472351858689",
  "text" : "RT @LoganCorina: #BulliedIntoBadScience website launched! https:\/\/t.co\/Rjrm0p6x70 ECRs can sign the petition, non-ECRs can join as supporte\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BulliedIntoBadScience",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/Rjrm0p6x70",
        "expanded_url" : "http:\/\/bulliedintobadscience.org",
        "display_url" : "bulliedintobadscience.org"
      } ]
    },
    "geo" : { },
    "id_str" : "881847373537964033",
    "text" : "#BulliedIntoBadScience website launched! https:\/\/t.co\/Rjrm0p6x70 ECRs can sign the petition, non-ECRs can join as supporters, plus updates",
    "id" : 881847373537964033,
    "created_at" : "2017-07-03 12:09:32 +0000",
    "user" : {
      "name" : "Corin\u24D0 Logan",
      "screen_name" : "LoganCorina",
      "protected" : false,
      "id_str" : "840002166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/868896866473259009\/GxuCdDln_normal.jpg",
      "id" : 840002166,
      "verified" : false
    }
  },
  "id" : 882099472351858689,
  "created_at" : "2017-07-04 04:51:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882098427437428737",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05866766258893, 23.79566746766101 ]
  },
  "id_str" : "882098738663227392",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice Hope so too! Just couldn\u2019t fit it into my schedule this year. Next stop for me is #BOSC2017 in Prague later this month.",
  "id" : 882098738663227392,
  "in_reply_to_status_id" : 882098427437428737,
  "created_at" : "2017-07-04 04:48:22 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882015076705849345",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05873535062864, 23.79565922438325 ]
  },
  "id_str" : "882096179382824961",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice Sorry to miss it this year!",
  "id" : 882096179382824961,
  "in_reply_to_status_id" : 882015076705849345,
  "created_at" : "2017-07-04 04:38:12 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maura \"are jack and biz nazis?\" quint",
      "screen_name" : "behindyourback",
      "indices" : [ 3, 18 ],
      "id_str" : "31455711",
      "id" : 31455711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "882091590042476544",
  "text" : "RT @behindyourback: *at my funeral*\nFriend crying over my casket: look they're burying her in her favorite dress\nMe, still dead: it haaasss\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "881973216398409729",
    "text" : "*at my funeral*\nFriend crying over my casket: look they're burying her in her favorite dress\nMe, still dead: it haaasss pockets",
    "id" : 881973216398409729,
    "created_at" : "2017-07-03 20:29:35 +0000",
    "user" : {
      "name" : "maura \"are jack and biz nazis?\" quint",
      "screen_name" : "behindyourback",
      "protected" : false,
      "id_str" : "31455711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617123223101018113\/rRf4L1ai_normal.jpg",
      "id" : 31455711,
      "verified" : true
    }
  },
  "id" : 882091590042476544,
  "created_at" : "2017-07-04 04:19:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/E8pstdcOq3",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BWF5vOyFfTj\/",
      "display_url" : "instagram.com\/p\/BWF5vOyFfTj\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0604648, 23.7892798 ]
  },
  "id_str" : "881922417324687360",
  "text" : "\u2026where the sun d\u0335o\u0335n\u0335'\u0335t\u0335 \u0335e\u0335v\u0335e\u0335r\u0335 \u0335s\u0335h\u0335i\u0335n\u0335e\u0335 shines all day and it's 42 \u00B0C. @ \u03A0\u03B5\u03C5\u03BA\u03B7,\u03B1\u03C4\u03C4\u03B9\u03BA\u03B7 https:\/\/t.co\/E8pstdcOq3",
  "id" : 881922417324687360,
  "created_at" : "2017-07-03 17:07:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eLife Innovation",
      "screen_name" : "eLifeInnovation",
      "indices" : [ 3, 19 ],
      "id_str" : "819927704850038785",
      "id" : 819927704850038785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MozSprint",
      "indices" : [ 50, 60 ]
    }, {
      "text" : "opensource",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "openscience",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "881906423814336512",
  "text" : "RT @eLifeInnovation: Looking back on last month's #MozSprint with over 130 #opensource projects for #openscience and a healthier internet h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/eLifeInnovation\/status\/881902364390821889\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/AVmG3zPQSa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DD0keZ1WAAAt6nQ.png",
        "id_str" : "881901206783787008",
        "id" : 881901206783787008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DD0keZ1WAAAt6nQ.png",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/AVmG3zPQSa"
      } ],
      "hashtags" : [ {
        "text" : "MozSprint",
        "indices" : [ 29, 39 ]
      }, {
        "text" : "opensource",
        "indices" : [ 54, 65 ]
      }, {
        "text" : "openscience",
        "indices" : [ 79, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/hybtLqpzTJ",
        "expanded_url" : "https:\/\/elifesciences.org\/inside-elife\/fbf4f42e\/innovation-supporting-online-collaboration-at-the-mozilla-global-sprint-2017",
        "display_url" : "elifesciences.org\/inside-elife\/f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "881902364390821889",
    "text" : "Looking back on last month's #MozSprint with over 130 #opensource projects for #openscience and a healthier internet https:\/\/t.co\/hybtLqpzTJ https:\/\/t.co\/AVmG3zPQSa",
    "id" : 881902364390821889,
    "created_at" : "2017-07-03 15:48:03 +0000",
    "user" : {
      "name" : "eLife Innovation",
      "screen_name" : "eLifeInnovation",
      "protected" : false,
      "id_str" : "819927704850038785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827126818113196032\/SZP2Wufk_normal.jpg",
      "id" : 819927704850038785,
      "verified" : false
    }
  },
  "id" : 881906423814336512,
  "created_at" : "2017-07-03 16:04:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 53, 69 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/WxIw8BL0oU",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/879340345955409920",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "881852557416640512",
  "text" : "RT @ctitusbrown: This is a pretty nice study! Thanks @gedankenstuecke! https:\/\/t.co\/WxIw8BL0oU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 36, 52 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/WxIw8BL0oU",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/879340345955409920",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "881852178847064071",
    "text" : "This is a pretty nice study! Thanks @gedankenstuecke! https:\/\/t.co\/WxIw8BL0oU",
    "id" : 881852178847064071,
    "created_at" : "2017-07-03 12:28:38 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 881852557416640512,
  "created_at" : "2017-07-03 12:30:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 0, 12 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881852178847064071",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.03647469214922, 23.79935449886062 ]
  },
  "id_str" : "881852538596859905",
  "in_reply_to_user_id" : 26616462,
  "text" : "@ctitusbrown Thanks for sharing!",
  "id" : 881852538596859905,
  "in_reply_to_status_id" : 881852178847064071,
  "created_at" : "2017-07-03 12:30:03 +0000",
  "in_reply_to_screen_name" : "ctitusbrown",
  "in_reply_to_user_id_str" : "26616462",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 9, 19 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881816485492137985",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06380314974233, 23.7994142534324 ]
  },
  "id_str" : "881817512630824960",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @blahah404 Rather a long blogpost about the hoops you have to jump through to get to that stage.",
  "id" : 881817512630824960,
  "in_reply_to_status_id" : 881816485492137985,
  "created_at" : "2017-07-03 10:10:53 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/bm6CzCOSSb",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/881775071605522432",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "881775071605522432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.06384360318574, 23.79951770560124 ]
  },
  "id_str" : "881815742735425536",
  "in_reply_to_user_id" : 14286491,
  "text" : "Depositing worked out. We got a date with the mayor on Wednesday! \uD83C\uDF89 https:\/\/t.co\/bm6CzCOSSb",
  "id" : 881815742735425536,
  "in_reply_to_status_id" : 881775071605522432,
  "created_at" : "2017-07-03 10:03:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 11, 19 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881814036161187841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.0638440241455, 23.79942922192364 ]
  },
  "id_str" : "881815246599589889",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 @betatim Should deposit the final documents on Zenodo or Figshare. :p",
  "id" : 881815246599589889,
  "in_reply_to_status_id" : 881814036161187841,
  "created_at" : "2017-07-03 10:01:52 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881778404290330624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05613812450846, 23.79283818892485 ]
  },
  "id_str" : "881783311630295041",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim It\u2019s called \u201CEhef\u00E4higkeitszeugnis\u201D for a reason!",
  "id" : 881783311630295041,
  "in_reply_to_status_id" : 881778404290330624,
  "created_at" : "2017-07-03 07:54:58 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881777672401145858",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05633851362672, 23.79286278797473 ]
  },
  "id_str" : "881777963037077505",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim That\u2019s a two level procedure. Today it\u2019s just depositing the paper work that took weeks to acquire.",
  "id" : 881777963037077505,
  "in_reply_to_status_id" : 881777672401145858,
  "created_at" : "2017-07-03 07:33:43 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.05624548412607, 23.79279294045522 ]
  },
  "id_str" : "881775071605522432",
  "text" : "Let\u2019s see whether depositing all those documents will work. \uD83D\uDE02 \uD83D\uDC70\uD83C\uDFFC",
  "id" : 881775071605522432,
  "created_at" : "2017-07-03 07:22:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/881611021277966336\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/WI7hjR5OIP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DDwciqLXoAA9wn_.jpg",
      "id_str" : "881611008820879360",
      "id" : 881611008820879360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDwciqLXoAA9wn_.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/WI7hjR5OIP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.93735485873451, 23.94783814073023 ]
  },
  "id_str" : "881611021277966336",
  "text" : "Out of the \u2708\uFE0F for 5 minutes and I already made a new friend. It\u2019s not an alpaca, but what have you. \uD83D\uDC36 https:\/\/t.co\/WI7hjR5OIP",
  "id" : 881611021277966336,
  "created_at" : "2017-07-02 20:30:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881599120632418305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.94122081253486, 23.95432029853012 ]
  },
  "id_str" : "881602643923271681",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena Will do :)",
  "id" : 881602643923271681,
  "in_reply_to_status_id" : 881599120632418305,
  "created_at" : "2017-07-02 19:57:04 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881544051505475586",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.28064617007598, 6.764708756925733 ]
  },
  "id_str" : "881557768473391104",
  "in_reply_to_user_id" : 14286491,
  "text" : "Got a plane now! \uD83D\uDC4B",
  "id" : 881557768473391104,
  "in_reply_to_status_id" : 881544051505475586,
  "created_at" : "2017-07-02 16:58:45 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/2zv32zmtVC",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/881439390177906688",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "881439390177906688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.27992896298106, 6.762995212114129 ]
  },
  "id_str" : "881544051505475586",
  "in_reply_to_user_id" : 14286491,
  "text" : "Already two hours late and the plane hasn\u2019t even arrived yet. Reminds me too much of my last YYZ adventure. \uD83E\uDD37\u200D\u2640\uFE0F https:\/\/t.co\/2zv32zmtVC",
  "id" : 881544051505475586,
  "in_reply_to_status_id" : 881439390177906688,
  "created_at" : "2017-07-02 16:04:14 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernhard Mittermaier",
      "screen_name" : "BMittermaier",
      "indices" : [ 0, 13 ],
      "id_str" : "152791124",
      "id" : 152791124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881500852715966464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.2788517285062, 6.766131003103682 ]
  },
  "id_str" : "881508102465609728",
  "in_reply_to_user_id" : 152791124,
  "text" : "@BMittermaier Too bad. Enjoy the trip!",
  "id" : 881508102465609728,
  "in_reply_to_status_id" : 881500852715966464,
  "created_at" : "2017-07-02 13:41:23 +0000",
  "in_reply_to_screen_name" : "BMittermaier",
  "in_reply_to_user_id_str" : "152791124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernhard Mittermaier",
      "screen_name" : "BMittermaier",
      "indices" : [ 0, 13 ],
      "id_str" : "152791124",
      "id" : 152791124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881450172013740033",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.27588329781697, 6.791715750778972 ]
  },
  "id_str" : "881480453781377024",
  "in_reply_to_user_id" : 152791124,
  "text" : "@BMittermaier Safe travels too, see you at the airport? :p",
  "id" : 881480453781377024,
  "in_reply_to_status_id" : 881450172013740033,
  "created_at" : "2017-07-02 11:51:31 +0000",
  "in_reply_to_screen_name" : "BMittermaier",
  "in_reply_to_user_id_str" : "152791124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11393625293869, 8.753245789565847 ]
  },
  "id_str" : "881439390177906688",
  "text" : "Today\u2019s plan: FRA \uD83D\uDE97DUS \u2708\uFE0F ATH.",
  "id" : 881439390177906688,
  "created_at" : "2017-07-02 09:08:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Jane Burpee",
      "screen_name" : "kjane",
      "indices" : [ 18, 24 ],
      "id_str" : "772689",
      "id" : 772689
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 25, 34 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "881410191216050176",
  "text" : "RT @petergrabitz: @kjane @open_con . I translated the German press release on reasons why major Berlin institutions cancel all Elsevier sub\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "K. Jane Burpee",
        "screen_name" : "kjane",
        "indices" : [ 0, 6 ],
        "id_str" : "772689",
        "id" : 772689
      }, {
        "name" : "OpenCon",
        "screen_name" : "open_con",
        "indices" : [ 7, 16 ],
        "id_str" : "2452073258",
        "id" : 2452073258
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petergrabitz\/status\/880862616624693249\/photo\/1",
        "indices" : [ 157, 180 ],
        "url" : "https:\/\/t.co\/O0lnnsm87I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DDlzUvnW0AI6mzN.jpg",
        "id_str" : "880862002343759874",
        "id" : 880862002343759874,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDlzUvnW0AI6mzN.jpg",
        "sizes" : [ {
          "h" : 820,
          "resize" : "fit",
          "w" : 725
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 725
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 725
        } ],
        "display_url" : "pic.twitter.com\/O0lnnsm87I"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 133, 156 ],
        "url" : "https:\/\/t.co\/UnB23VTkHn",
        "expanded_url" : "http:\/\/www.fu-berlin.de\/presse\/informationen\/fup\/2017\/fup_17_180-charite-hu-fu-tu-kuendigen-vertrag-elsevier\/index.html",
        "display_url" : "fu-berlin.de\/presse\/informa\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "880855629589557248",
    "geo" : { },
    "id_str" : "880862616624693249",
    "in_reply_to_user_id" : 2396006202,
    "text" : "@kjane @open_con . I translated the German press release on reasons why major Berlin institutions cancel all Elsevier subscribtions: https:\/\/t.co\/UnB23VTkHn https:\/\/t.co\/O0lnnsm87I",
    "id" : 880862616624693249,
    "in_reply_to_status_id" : 880855629589557248,
    "created_at" : "2017-06-30 18:56:28 +0000",
    "in_reply_to_screen_name" : "PeterRolandG",
    "in_reply_to_user_id_str" : "2396006202",
    "user" : {
      "name" : "Peter",
      "screen_name" : "PeterRolandG",
      "protected" : false,
      "id_str" : "2396006202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636115977894260736\/ZadNq2eK_normal.jpg",
      "id" : 2396006202,
      "verified" : false
    }
  },
  "id" : 881410191216050176,
  "created_at" : "2017-07-02 07:12:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/t7sNDG5dua",
      "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/881300480923541504",
      "display_url" : "twitter.com\/lteytelman\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "881392603924758528",
  "text" : "RT @bella_velo: To sexual harassers EVERYWHERE https:\/\/t.co\/t7sNDG5dua",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/t7sNDG5dua",
        "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/881300480923541504",
        "display_url" : "twitter.com\/lteytelman\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "881304503567474688",
    "text" : "To sexual harassers EVERYWHERE https:\/\/t.co\/t7sNDG5dua",
    "id" : 881304503567474688,
    "created_at" : "2017-07-02 00:12:22 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 881392603924758528,
  "created_at" : "2017-07-02 06:02:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/YfyGfBWbxF",
      "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
      "display_url" : "crowdai.org\/challenges\/ope\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "881299195499622400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399227157796, 8.753330874384556 ]
  },
  "id_str" : "881299939988566016",
  "in_reply_to_user_id" : 14286491,
  "text" : "And: There are already 27 submissions by 9 participants for the \u201Cpredicting height\u201D-challenge! https:\/\/t.co\/YfyGfBWbxF",
  "id" : 881299939988566016,
  "in_reply_to_status_id" : 881299195499622400,
  "created_at" : "2017-07-01 23:54:14 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 54, 63 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/2qBFhBWH8Z",
      "expanded_url" : "https:\/\/github.com\/crowdAI\/crowdai-client-py\/pull\/12",
      "display_url" : "github.com\/crowdAI\/crowda\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399203472239, 8.753331220100069 ]
  },
  "id_str" : "881299195499622400",
  "text" : "How OSS works: After &lt;1 day of posting the openSNP\/@crowd_ai challenge on FB one of my friends added python3 support https:\/\/t.co\/2qBFhBWH8Z",
  "id" : 881299195499622400,
  "created_at" : "2017-07-01 23:51:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 48, 61 ],
      "id_str" : "67529128",
      "id" : 67529128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11382482242495, 8.753476325925151 ]
  },
  "id_str" : "881266922821750785",
  "text" : "Had dinner at Saravanaa Bhavan, you were missed @RaoOfPhysics!",
  "id" : 881266922821750785,
  "created_at" : "2017-07-01 21:43:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katha",
      "screen_name" : "kathakatze",
      "indices" : [ 0, 11 ],
      "id_str" : "541170257",
      "id" : 541170257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881212452612059136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11873051242532, 8.685118809172863 ]
  },
  "id_str" : "881214720732262400",
  "in_reply_to_user_id" : 541170257,
  "text" : "@kathakatze Der Vorteil wenn Partner*innen einen \u00E4hnlichen Body Type haben: eins kann gegenseitig den Kleiderschrank pl\u00FCndern. \uD83D\uDE0D",
  "id" : 881214720732262400,
  "in_reply_to_status_id" : 881212452612059136,
  "created_at" : "2017-07-01 18:15:36 +0000",
  "in_reply_to_screen_name" : "kathakatze",
  "in_reply_to_user_id_str" : "541170257",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/14I69mLW2q",
      "expanded_url" : "https:\/\/instagram.com\/p\/BWAzOZ3g-0N\/",
      "display_url" : "instagram.com\/p\/BWAzOZ3g-0N\/"
    } ]
  },
  "geo" : { },
  "id_str" : "881209558215143426",
  "text" : "Side eye for the potential wedding dress. \uD83D\uDC70\uD83C\uDFFC\uD83D\uDC57\uD83D\uDE12 https:\/\/t.co\/14I69mLW2q",
  "id" : 881209558215143426,
  "created_at" : "2017-07-01 17:55:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881146502898429953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11374044473895, 8.753426847215707 ]
  },
  "id_str" : "881146589204631553",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Versp\u00E4teter Fr\u00FChjahrsputz-High Five!",
  "id" : 881146589204631553,
  "in_reply_to_status_id" : 881146502898429953,
  "created_at" : "2017-07-01 13:44:52 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "881146273163862016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11374044473895, 8.753426847215707 ]
  },
  "id_str" : "881146464122142721",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Auch beim aufr\u00E4umen um die Ironie perfekt zu machen? :D",
  "id" : 881146464122142721,
  "in_reply_to_status_id" : 881146273163862016,
  "created_at" : "2017-07-01 13:44:22 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/881144134094004224\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/xW9uUwHziP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DDpz61zWsAAd-AD.jpg",
      "id_str" : "881144131816435712",
      "id" : 881144131816435712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDpz61zWsAAd-AD.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xW9uUwHziP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "881144134094004224",
  "text" : "Found some fun archeological stickers while cleaning up. https:\/\/t.co\/xW9uUwHziP",
  "id" : 881144134094004224,
  "created_at" : "2017-07-01 13:35:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399208900701, 8.753330685730866 ]
  },
  "id_str" : "881125530623516672",
  "text" : "New crafting project: Making a Purrple Heart to award it to the cat for surviving all his injuries. \uD83D\uDC08\uD83D\uDC9C",
  "id" : 881125530623516672,
  "created_at" : "2017-07-01 12:21:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Canada150",
      "indices" : [ 31, 41 ]
    }, {
      "text" : "Resist150",
      "indices" : [ 108, 118 ]
    }, {
      "text" : "Colonialism150",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "881087695161896960",
  "text" : "RT @lorrainechu3n: Celebrating #Canada150 means celebrating colonialism, violence, white supremacy, erasure #Resist150 #Colonialism150 \nhtt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Canada150",
        "indices" : [ 12, 22 ]
      }, {
        "text" : "Resist150",
        "indices" : [ 89, 99 ]
      }, {
        "text" : "Colonialism150",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/sCor3uDs6Z",
        "expanded_url" : "http:\/\/www.intersectionalanalyst.com\/intersectional-analyst\/150-years-of-colonialism-violence-and-erasure-in-canada",
        "display_url" : "intersectionalanalyst.com\/intersectional\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "881013330005041153",
    "text" : "Celebrating #Canada150 means celebrating colonialism, violence, white supremacy, erasure #Resist150 #Colonialism150 \nhttps:\/\/t.co\/sCor3uDs6Z",
    "id" : 881013330005041153,
    "created_at" : "2017-07-01 04:55:20 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 881087695161896960,
  "created_at" : "2017-07-01 09:50:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana #hcsm #OpenAPS",
      "screen_name" : "danamlewis",
      "indices" : [ 3, 14 ],
      "id_str" : "15165858",
      "id" : 15165858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/7tY0DJXH9B",
      "expanded_url" : "https:\/\/twitter.com\/sabrak\/status\/881011738761510912",
      "display_url" : "twitter.com\/sabrak\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "881087385433513986",
  "text" : "RT @danamlewis: Headline of the day? https:\/\/t.co\/7tY0DJXH9B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/7tY0DJXH9B",
        "expanded_url" : "https:\/\/twitter.com\/sabrak\/status\/881011738761510912",
        "display_url" : "twitter.com\/sabrak\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "881012023592603648",
    "text" : "Headline of the day? https:\/\/t.co\/7tY0DJXH9B",
    "id" : 881012023592603648,
    "created_at" : "2017-07-01 04:50:09 +0000",
    "user" : {
      "name" : "Dana #hcsm #OpenAPS",
      "screen_name" : "danamlewis",
      "protected" : false,
      "id_str" : "15165858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546092883736940544\/7RNgEjQM_normal.jpeg",
      "id" : 15165858,
      "verified" : true
    }
  },
  "id" : 881087385433513986,
  "created_at" : "2017-07-01 09:49:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 19, 30 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "CrowdAI",
      "screen_name" : "crowd_ai",
      "indices" : [ 55, 64 ],
      "id_str" : "706885331224813568",
      "id" : 706885331224813568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/OBjP3xAOtP",
      "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
      "display_url" : "crowdai.org\/challenges\/ope\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "881086766068977664",
  "text" : "RT @PhilippBayer: .@openSNPorg's data is now part of a @crowd_ai challenge! predict height using human SNPs https:\/\/t.co\/OBjP3xAOtP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "openSNP team",
        "screen_name" : "openSNPorg",
        "indices" : [ 1, 12 ],
        "id_str" : "380205172",
        "id" : 380205172
      }, {
        "name" : "CrowdAI",
        "screen_name" : "crowd_ai",
        "indices" : [ 37, 46 ],
        "id_str" : "706885331224813568",
        "id" : 706885331224813568
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/OBjP3xAOtP",
        "expanded_url" : "https:\/\/www.crowdai.org\/challenges\/opensnp-height-prediction",
        "display_url" : "crowdai.org\/challenges\/ope\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "881003866065588224",
    "text" : ".@openSNPorg's data is now part of a @crowd_ai challenge! predict height using human SNPs https:\/\/t.co\/OBjP3xAOtP",
    "id" : 881003866065588224,
    "created_at" : "2017-07-01 04:17:44 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 881086766068977664,
  "created_at" : "2017-07-01 09:47:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Cenzer",
      "screen_name" : "MeredithCenzer",
      "indices" : [ 3, 18 ],
      "id_str" : "1936282274",
      "id" : 1936282274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evol2017",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "881083556671275008",
  "text" : "RT @MeredithCenzer: 1\/n I had a wonderful time at #evol2017, but I had several painful experiences with sexist behavior and bigotry I feel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "evol2017",
        "indices" : [ 30, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "880904449438261248",
    "text" : "1\/n I had a wonderful time at #evol2017, but I had several painful experiences with sexist behavior and bigotry I feel compelled to share.",
    "id" : 880904449438261248,
    "created_at" : "2017-06-30 21:42:41 +0000",
    "user" : {
      "name" : "Meredith Cenzer",
      "screen_name" : "MeredithCenzer",
      "protected" : false,
      "id_str" : "1936282274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000550207172\/2e843efb97122f16addb2e719275f38a_normal.jpeg",
      "id" : 1936282274,
      "verified" : false
    }
  },
  "id" : 881083556671275008,
  "created_at" : "2017-07-01 09:34:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galaxy Project",
      "screen_name" : "galaxyproject",
      "indices" : [ 3, 17 ],
      "id_str" : "39351968",
      "id" : 39351968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2018",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "881082120554328065",
  "text" : "RT @galaxyproject: We are pleased to *officially* announce: GCC2018 &amp; #BOSC2018 will be co-located in Portland, Oregon, US, June 25-30 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/galaxyproject\/status\/880813175821680640\/photo\/1",
        "indices" : [ 144, 167 ],
        "url" : "https:\/\/t.co\/6vAgigiiLo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DDKe7ETXsAAU61T.jpg",
        "id_str" : "878939614895124480",
        "id" : 878939614895124480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DDKe7ETXsAAU61T.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/6vAgigiiLo"
      } ],
      "hashtags" : [ {
        "text" : "BOSC2018",
        "indices" : [ 55, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/lunWtXycWq",
        "expanded_url" : "https:\/\/gccbosc2018.sched.com\/",
        "display_url" : "gccbosc2018.sched.com"
      } ]
    },
    "geo" : { },
    "id_str" : "880813175821680640",
    "text" : "We are pleased to *officially* announce: GCC2018 &amp; #BOSC2018 will be co-located in Portland, Oregon, US, June 25-30 https:\/\/t.co\/lunWtXycWq https:\/\/t.co\/6vAgigiiLo",
    "id" : 880813175821680640,
    "created_at" : "2017-06-30 15:40:00 +0000",
    "user" : {
      "name" : "Galaxy Project",
      "screen_name" : "galaxyproject",
      "protected" : false,
      "id_str" : "39351968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580742252043100161\/x64IwBFv_normal.png",
      "id" : 39351968,
      "verified" : false
    }
  },
  "id" : 881082120554328065,
  "created_at" : "2017-07-01 09:28:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]