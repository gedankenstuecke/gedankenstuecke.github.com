Grailbird.data.tweets_2015_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erich M. Schwarz",
      "screen_name" : "ErichMSchwarz",
      "indices" : [ 0, 14 ],
      "id_str" : "585949808",
      "id" : 585949808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593893690181038081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140930175781, 8.753290506656217 ]
  },
  "id_str" : "593894763352498176",
  "in_reply_to_user_id" : 585949808,
  "text" : "@ErichMSchwarz ah, thanks!",
  "id" : 593894763352498176,
  "in_reply_to_status_id" : 593893690181038081,
  "created_at" : "2015-04-30 21:48:40 +0000",
  "in_reply_to_screen_name" : "ErichMSchwarz",
  "in_reply_to_user_id_str" : "585949808",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arun Durvasula",
      "screen_name" : "arundurvasula",
      "indices" : [ 0, 14 ],
      "id_str" : "17111287",
      "id" : 17111287
    }, {
      "name" : "Vince Buffalo",
      "screen_name" : "vsbuffalo",
      "indices" : [ 15, 25 ],
      "id_str" : "62183077",
      "id" : 62183077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593494149376155649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409351789948, 8.753293854039871 ]
  },
  "id_str" : "593883015677370368",
  "in_reply_to_user_id" : 17111287,
  "text" : "@arundurvasula @vsbuffalo glad to see you are putting the data to use. :)",
  "id" : 593883015677370368,
  "in_reply_to_status_id" : 593494149376155649,
  "created_at" : "2015-04-30 21:01:59 +0000",
  "in_reply_to_screen_name" : "arundurvasula",
  "in_reply_to_user_id_str" : "17111287",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "indices" : [ 3, 14 ],
      "id_str" : "14257211",
      "id" : 14257211
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 58, 63 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "metro fnord",
      "screen_name" : "linse",
      "indices" : [ 65, 71 ],
      "id_str" : "2206871",
      "id" : 2206871
    }, {
      "name" : "C. Haupt",
      "screen_name" : "caha42",
      "indices" : [ 73, 80 ],
      "id_str" : "397120166",
      "id" : 397120166
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 85, 101 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CR211",
      "indices" : [ 23, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/MHY7VpCXN0",
      "expanded_url" : "http:\/\/chaosradio.ccc.de\/cr211.html",
      "display_url" : "chaosradio.ccc.de\/cr211.html"
    } ]
  },
  "geo" : { },
  "id_str" : "593865972387287042",
  "text" : "RT @chaosradio: Gleich #CR211 zum Thema Bioinformatik mit @li5a, @linse, @caha42 und @gedankenstuecke: http:\/\/t.co\/MHY7VpCXN0 , live: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "li5a",
        "screen_name" : "li5a",
        "indices" : [ 42, 47 ],
        "id_str" : "11712822",
        "id" : 11712822
      }, {
        "name" : "metro fnord",
        "screen_name" : "linse",
        "indices" : [ 49, 55 ],
        "id_str" : "2206871",
        "id" : 2206871
      }, {
        "name" : "C. Haupt",
        "screen_name" : "caha42",
        "indices" : [ 57, 64 ],
        "id_str" : "397120166",
        "id" : 397120166
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 69, 85 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CR211",
        "indices" : [ 7, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/MHY7VpCXN0",
        "expanded_url" : "http:\/\/chaosradio.ccc.de\/cr211.html",
        "display_url" : "chaosradio.ccc.de\/cr211.html"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/tCztMoiBsi",
        "expanded_url" : "http:\/\/streaming.media.ccc.de",
        "display_url" : "streaming.media.ccc.de"
      } ]
    },
    "geo" : { },
    "id_str" : "593865521554190337",
    "text" : "Gleich #CR211 zum Thema Bioinformatik mit @li5a, @linse, @caha42 und @gedankenstuecke: http:\/\/t.co\/MHY7VpCXN0 , live: http:\/\/t.co\/tCztMoiBsi",
    "id" : 593865521554190337,
    "created_at" : "2015-04-30 19:52:28 +0000",
    "user" : {
      "name" : "Chaosradio",
      "screen_name" : "chaosradio",
      "protected" : false,
      "id_str" : "14257211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52233040\/chaosradio-icon-300_normal.jpg",
      "id" : 14257211,
      "verified" : false
    }
  },
  "id" : 593865972387287042,
  "created_at" : "2015-04-30 19:54:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erich M. Schwarz",
      "screen_name" : "ErichMSchwarz",
      "indices" : [ 0, 14 ],
      "id_str" : "585949808",
      "id" : 585949808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593812781088043009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409301757811, 8.753291112491569 ]
  },
  "id_str" : "593838306674237440",
  "in_reply_to_user_id" : 585949808,
  "text" : "@ErichMSchwarz Is there information which species were used for the different datasets?",
  "id" : 593838306674237440,
  "in_reply_to_status_id" : 593812781088043009,
  "created_at" : "2015-04-30 18:04:19 +0000",
  "in_reply_to_screen_name" : "ErichMSchwarz",
  "in_reply_to_user_id_str" : "585949808",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/CRhLdrIFjv",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/04\/30\/activist-deray-mckesson-master.html",
      "display_url" : "boingboing.net\/2015\/04\/30\/act\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593768690941894656",
  "text" : "Activist DeRay McKesson masterfully shuts down Wolf\u00A0Blitzer http:\/\/t.co\/CRhLdrIFjv",
  "id" : 593768690941894656,
  "created_at" : "2015-04-30 13:27:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593758063271751680",
  "text" : "RT @wilbanks: Doctors on why you (generally) don\u2019t get to take your organs home after surgery.  Bonus black market price chart. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/EmgV83I4l4",
        "expanded_url" : "http:\/\/www.hopesandfears.com\/hopes\/now\/question\/168921-can-you-keep-a-removed-organ-where-does-it-go",
        "display_url" : "hopesandfears.com\/hopes\/now\/ques\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "593740472889270272",
    "text" : "Doctors on why you (generally) don\u2019t get to take your organs home after surgery.  Bonus black market price chart. http:\/\/t.co\/EmgV83I4l4",
    "id" : 593740472889270272,
    "created_at" : "2015-04-30 11:35:34 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 593758063271751680,
  "created_at" : "2015-04-30 12:45:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Scholz",
      "screen_name" : "svenscholz",
      "indices" : [ 0, 11 ],
      "id_str" : "8818872",
      "id" : 8818872
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 26, 38 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593713014689419266",
  "geo" : { },
  "id_str" : "593732562809413632",
  "in_reply_to_user_id" : 8818872,
  "text" : "@svenscholz fragt mal den @herr_schrat :)",
  "id" : 593732562809413632,
  "in_reply_to_status_id" : 593713014689419266,
  "created_at" : "2015-04-30 11:04:08 +0000",
  "in_reply_to_screen_name" : "svenscholz",
  "in_reply_to_user_id_str" : "8818872",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593717045902049280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1741613975325, 8.619539641682163 ]
  },
  "id_str" : "593725405535830016",
  "in_reply_to_user_id" : 14286491,
  "text" : "@TanteSilke oh, und 01.07. sind Of Monsters and Men in Frankfurt.",
  "id" : 593725405535830016,
  "in_reply_to_status_id" : 593717045902049280,
  "created_at" : "2015-04-30 10:35:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593712150092320768",
  "geo" : { },
  "id_str" : "593717045902049280",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke o\/",
  "id" : 593717045902049280,
  "in_reply_to_status_id" : 593712150092320768,
  "created_at" : "2015-04-30 10:02:29 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593713809732276224",
  "geo" : { },
  "id_str" : "593714416354484224",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 it just works!",
  "id" : 593714416354484224,
  "in_reply_to_status_id" : 593713809732276224,
  "created_at" : "2015-04-30 09:52:02 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593709010446069760",
  "geo" : { },
  "id_str" : "593714299425685504",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv Okay, I\u2019ll have a look myself in that case :)",
  "id" : 593714299425685504,
  "in_reply_to_status_id" : 593709010446069760,
  "created_at" : "2015-04-30 09:51:34 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593700209462530048",
  "geo" : { },
  "id_str" : "593700895533211648",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv Lights would be nicer, but beamer is what we\u2019re having right now.",
  "id" : 593700895533211648,
  "in_reply_to_status_id" : 593700209462530048,
  "created_at" : "2015-04-30 08:58:18 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593698450069389312",
  "geo" : { },
  "id_str" : "593698586396876801",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv too bad, I already have a occasion where I would like to run it. :D",
  "id" : 593698586396876801,
  "in_reply_to_status_id" : 593698450069389312,
  "created_at" : "2015-04-30 08:49:08 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593697916595875841",
  "geo" : { },
  "id_str" : "593698316535345152",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 Wenn du was bastelst h\u00E4tte ich gern das Ergebnis. :)",
  "id" : 593698316535345152,
  "in_reply_to_status_id" : 593697916595875841,
  "created_at" : "2015-04-30 08:48:03 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593694960563675136",
  "geo" : { },
  "id_str" : "593695129933873154",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 Danke. Das w\u00E4re mir auch ziemlich egal wenn nicht jeder reboot mit Neuinstallation der Tastaturen enden w\u00FCrde\u2026",
  "id" : 593695129933873154,
  "in_reply_to_status_id" : 593694960563675136,
  "created_at" : "2015-04-30 08:35:23 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593694211570081792",
  "geo" : { },
  "id_str" : "593694527946432512",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 Nein, aber das Recovery Update will sich gerade zum zweiten Mal installieren lassen.",
  "id" : 593694527946432512,
  "in_reply_to_status_id" : 593694211570081792,
  "created_at" : "2015-04-30 08:33:00 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593681868245102592",
  "geo" : { },
  "id_str" : "593682025338515456",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 meh\u2026",
  "id" : 593682025338515456,
  "in_reply_to_status_id" : 593681868245102592,
  "created_at" : "2015-04-30 07:43:19 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593672827749957632",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 Aus aktuellem Anlass: Hat das Permissions fixen eigentlich beim Keyboard-Problem geholfen?",
  "id" : 593672827749957632,
  "created_at" : "2015-04-30 07:06:46 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Ez0D7Z5Qjt",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Tilly_Edinger",
      "display_url" : "en.m.wikipedia.org\/wiki\/Tilly_Edi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18092649530551, 8.620577425781285 ]
  },
  "id_str" : "593669314584125441",
  "text" : "I didn\u2019t know about this part of the history of the University of Frankfurt \/ the Senckenberg. http:\/\/t.co\/Ez0D7Z5Qjt",
  "id" : 593669314584125441,
  "created_at" : "2015-04-30 06:52:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593544873896185856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409333843403, 8.753291049334484 ]
  },
  "id_str" : "593545980710125568",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv btw. do you have any experience in doing light-based installations along with the sonification?",
  "id" : 593545980710125568,
  "in_reply_to_status_id" : 593544873896185856,
  "created_at" : "2015-04-29 22:42:44 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593539234381824001",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409365043949, 8.753292864951362 ]
  },
  "id_str" : "593539479245365249",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke in which ways then?",
  "id" : 593539479245365249,
  "in_reply_to_status_id" : 593539234381824001,
  "created_at" : "2015-04-29 22:16:53 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593535524167557125",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409333824289, 8.753291034042798 ]
  },
  "id_str" : "593536534885851136",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke but maybe that\u2019s also influenced by some cycle. Could claim astrological ones for a change. :p",
  "id" : 593536534885851136,
  "in_reply_to_status_id" : 593535524167557125,
  "created_at" : "2015-04-29 22:05:11 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593535170839334913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409333824226, 8.753291033992904 ]
  },
  "id_str" : "593535517091729408",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab I haven\u2019t followed EP too closely lately, but from outside it seems the claims keep getting more ridiculous.",
  "id" : 593535517091729408,
  "in_reply_to_status_id" : 593535170839334913,
  "created_at" : "2015-04-29 22:01:09 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/7epqV0bqaO",
      "expanded_url" : "http:\/\/journals.plos.org\/plosone\/article?id=10.1371\/journal.pone.0112042",
      "display_url" : "journals.plos.org\/plosone\/articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409332941302, 8.753290327653229 ]
  },
  "id_str" : "593534180337668096",
  "text" : "Refuting Evolutionary Psychology claims: \u00ABMenstrual Cycle Phase Does Not Predict Political Conservatism\u00BB http:\/\/t.co\/7epqV0bqaO",
  "id" : 593534180337668096,
  "created_at" : "2015-04-29 21:55:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ypMvJzSIws",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/borgarnes-to-akureyri-lets-take-the-bus-part-two-the-sleeping-giant",
      "display_url" : "mcsweeneys.net\/articles\/borga\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409333356747, 8.753290660009085 ]
  },
  "id_str" : "593532703636492289",
  "text" : "\u00ABIt\u2019s a wonder any of [the trolls] make it past those teen angst years without being turned to stone.\u00BB http:\/\/t.co\/ypMvJzSIws",
  "id" : 593532703636492289,
  "created_at" : "2015-04-29 21:49:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Stutchbury",
      "screen_name" : "Benstutchbury",
      "indices" : [ 3, 17 ],
      "id_str" : "1119044228",
      "id" : 1119044228
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatsnotaknife",
      "indices" : [ 62, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/UwWwnPXRf6",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC1322240\/",
      "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593531945813835777",
  "text" : "RT @Benstutchbury: Best. Paper. Ever. http:\/\/t.co\/UwWwnPXRf6 \n#thatsnotaknife",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thatsnotaknife",
        "indices" : [ 43, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/UwWwnPXRf6",
        "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pmc\/articles\/PMC1322240\/",
        "display_url" : "ncbi.nlm.nih.gov\/pmc\/articles\/P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "523029781777244160",
    "text" : "Best. Paper. Ever. http:\/\/t.co\/UwWwnPXRf6 \n#thatsnotaknife",
    "id" : 523029781777244160,
    "created_at" : "2014-10-17 08:36:32 +0000",
    "user" : {
      "name" : "Ben Stutchbury",
      "screen_name" : "Benstutchbury",
      "protected" : false,
      "id_str" : "1119044228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906064546334478337\/aRdjG0J8_normal.jpg",
      "id" : 1119044228,
      "verified" : false
    }
  },
  "id" : 593531945813835777,
  "created_at" : "2015-04-29 21:46:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/euhy1MaZZn",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/StjDZBiLbdRUQ\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/StjDZBiL\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "593520152475344896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409333373182, 8.753290673154538 ]
  },
  "id_str" : "593520343601451009",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat http:\/\/t.co\/euhy1MaZZn :D",
  "id" : 593520343601451009,
  "in_reply_to_status_id" : 593520152475344896,
  "created_at" : "2015-04-29 21:00:51 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593519444405526530",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409333373182, 8.753290673154538 ]
  },
  "id_str" : "593519939035598851",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat weil wir Meister des vorausschauend Planens sind. ;)",
  "id" : 593519939035598851,
  "in_reply_to_status_id" : 593519444405526530,
  "created_at" : "2015-04-29 20:59:15 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593516925424021505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409373517433, 8.753322782417786 ]
  },
  "id_str" : "593519265971507201",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat na gut, dann gibt es das n\u00E4chste mal halt doch eigenh\u00E4ndiges Katerfr\u00FChst\u00FCck :)",
  "id" : 593519265971507201,
  "in_reply_to_status_id" : 593516925424021505,
  "created_at" : "2015-04-29 20:56:34 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie Tenenbaum",
      "screen_name" : "jessiet1023",
      "indices" : [ 3, 15 ],
      "id_str" : "215420646",
      "id" : 215420646
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataSharing",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/nqjOm9aQ3D",
      "expanded_url" : "http:\/\/www.nature.com\/news\/thank-you-for-sharing-1.17417",
      "display_url" : "nature.com\/news\/thank-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593518014269534209",
  "text" : "RT @jessiet1023: #DataSharing http:\/\/t.co\/nqjOm9aQ3D \"though all parties recognize the value, many choose not to share. this holds back med\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DataSharing",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/nqjOm9aQ3D",
        "expanded_url" : "http:\/\/www.nature.com\/news\/thank-you-for-sharing-1.17417",
        "display_url" : "nature.com\/news\/thank-you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "593517804797624320",
    "text" : "#DataSharing http:\/\/t.co\/nqjOm9aQ3D \"though all parties recognize the value, many choose not to share. this holds back medical progress.\"",
    "id" : 593517804797624320,
    "created_at" : "2015-04-29 20:50:46 +0000",
    "user" : {
      "name" : "Jessie Tenenbaum",
      "screen_name" : "jessiet1023",
      "protected" : false,
      "id_str" : "215420646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658815462914981888\/lJbOxIVU_normal.jpg",
      "id" : 215420646,
      "verified" : false
    }
  },
  "id" : 593518014269534209,
  "created_at" : "2015-04-29 20:51:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/5fmrdYzTBG",
      "expanded_url" : "http:\/\/www.quora.com\/Why-did-Eva-Kor-shake-hands-with-a-former-Auschwitz-guard\/answer\/Eva-Kor?share=1",
      "display_url" : "quora.com\/Why-did-Eva-Ko\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409330167079, 8.753288108130372 ]
  },
  "id_str" : "593516546737111042",
  "text" : "\u00ABThis was not the interaction I was hoping for. I knocked out an old Nazi.\u00BB http:\/\/t.co\/5fmrdYzTBG",
  "id" : 593516546737111042,
  "created_at" : "2015-04-29 20:45:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593505643094364160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409332195566, 8.753290116637258 ]
  },
  "id_str" : "593515020006227969",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat ich hoffe da gibt es ein Waschbar-\u00C4quivalent ;)",
  "id" : 593515020006227969,
  "in_reply_to_status_id" : 593505643094364160,
  "created_at" : "2015-04-29 20:39:42 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593505139534606337",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409332940547, 8.753290324196989 ]
  },
  "id_str" : "593505498625810435",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat sehr sch\u00F6n. Schritt f\u00FCr Schritt gen Norden, eh? ;)",
  "id" : 593505498625810435,
  "in_reply_to_status_id" : 593505139534606337,
  "created_at" : "2015-04-29 20:01:52 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593504583105650688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409328398591, 8.753290256751308 ]
  },
  "id_str" : "593504917093879810",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat was ist\u2019s geworden?",
  "id" : 593504917093879810,
  "in_reply_to_status_id" : 593504583105650688,
  "created_at" : "2015-04-29 19:59:33 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoav Gilad",
      "screen_name" : "Y_Gilad",
      "indices" : [ 0, 8 ],
      "id_str" : "2802558480",
      "id" : 2802558480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593499732405694464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409325348499, 8.75329000864855 ]
  },
  "id_str" : "593499931534458880",
  "in_reply_to_user_id" : 2802558480,
  "text" : "@Y_Gilad thanks a lot. Close, but could work. I\u2019ll keep my fingers crossed!",
  "id" : 593499931534458880,
  "in_reply_to_status_id" : 593499732405694464,
  "created_at" : "2015-04-29 19:39:45 +0000",
  "in_reply_to_screen_name" : "Y_Gilad",
  "in_reply_to_user_id_str" : "2802558480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matus Sotak",
      "screen_name" : "biomatushiq",
      "indices" : [ 0, 12 ],
      "id_str" : "122310304",
      "id" : 122310304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593495889769037825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409321249359, 8.753290073755764 ]
  },
  "id_str" : "593497177143549952",
  "in_reply_to_user_id" : 122310304,
  "text" : "@biomatushiq hitting close to home there. ;)",
  "id" : 593497177143549952,
  "in_reply_to_status_id" : 593495889769037825,
  "created_at" : "2015-04-29 19:28:48 +0000",
  "in_reply_to_screen_name" : "biomatushiq",
  "in_reply_to_user_id_str" : "122310304",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matus Sotak",
      "screen_name" : "biomatushiq",
      "indices" : [ 3, 15 ],
      "id_str" : "122310304",
      "id" : 122310304
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 103, 109 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/ujqabKf8Zd",
      "expanded_url" : "http:\/\/wrd.cm\/1GwWQpH",
      "display_url" : "wrd.cm\/1GwWQpH"
    } ]
  },
  "geo" : { },
  "id_str" : "593497003990061059",
  "text" : "RT @biomatushiq: 7 Hand Gestures That Make You Look Like a Real Intellectual http:\/\/t.co\/ujqabKf8Zd by @WIRED",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 86, 92 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/ujqabKf8Zd",
        "expanded_url" : "http:\/\/wrd.cm\/1GwWQpH",
        "display_url" : "wrd.cm\/1GwWQpH"
      } ]
    },
    "geo" : { },
    "id_str" : "593495889769037825",
    "text" : "7 Hand Gestures That Make You Look Like a Real Intellectual http:\/\/t.co\/ujqabKf8Zd by @WIRED",
    "id" : 593495889769037825,
    "created_at" : "2015-04-29 19:23:41 +0000",
    "user" : {
      "name" : "Matus Sotak",
      "screen_name" : "biomatushiq",
      "protected" : false,
      "id_str" : "122310304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2481824929\/qsqbsbw5o2vhe404u7f5_normal.jpeg",
      "id" : 122310304,
      "verified" : false
    }
  },
  "id" : 593497003990061059,
  "created_at" : "2015-04-29 19:28:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle N. Meyer",
      "screen_name" : "MichelleNMeyer",
      "indices" : [ 3, 18 ],
      "id_str" : "59518694",
      "id" : 59518694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FWApbdGQKC",
      "expanded_url" : "http:\/\/online.liebertpub.com\/doi\/abs\/10.1089\/bio.2014.0032?journalCode=bio",
      "display_url" : "online.liebertpub.com\/doi\/abs\/10.108\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593485184093310979",
  "text" : "RT @MichelleNMeyer: Unsurprising differences in willingness to particip in biobank rsrch w\/narrow vs broad consent http:\/\/t.co\/FWApbdGQKC h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MichelleNMeyer\/status\/593484012334804992\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/J0rNl5pnkR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDx6jHNWMAAnL1M.jpg",
        "id_str" : "593483994555101184",
        "id" : 593483994555101184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDx6jHNWMAAnL1M.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 596
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 396
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 596
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 596
        } ],
        "display_url" : "pic.twitter.com\/J0rNl5pnkR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/FWApbdGQKC",
        "expanded_url" : "http:\/\/online.liebertpub.com\/doi\/abs\/10.1089\/bio.2014.0032?journalCode=bio",
        "display_url" : "online.liebertpub.com\/doi\/abs\/10.108\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "593484012334804992",
    "text" : "Unsurprising differences in willingness to particip in biobank rsrch w\/narrow vs broad consent http:\/\/t.co\/FWApbdGQKC http:\/\/t.co\/J0rNl5pnkR",
    "id" : 593484012334804992,
    "created_at" : "2015-04-29 18:36:29 +0000",
    "user" : {
      "name" : "Michelle N. Meyer",
      "screen_name" : "MichelleNMeyer",
      "protected" : false,
      "id_str" : "59518694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660800998177415168\/uCbNVkPf_normal.jpg",
      "id" : 59518694,
      "verified" : false
    }
  },
  "id" : 593485184093310979,
  "created_at" : "2015-04-29 18:41:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoav Gilad",
      "screen_name" : "Y_Gilad",
      "indices" : [ 0, 8 ],
      "id_str" : "2802558480",
      "id" : 2802558480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593193927190032384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409358828796, 8.753290248574604 ]
  },
  "id_str" : "593484873135947776",
  "in_reply_to_user_id" : 2802558480,
  "text" : "@Y_Gilad do you have a rough estimate for when the preprint will be posted? Would be a nice paper for my next journal club I guess. :)",
  "id" : 593484873135947776,
  "in_reply_to_status_id" : 593193927190032384,
  "created_at" : "2015-04-29 18:39:54 +0000",
  "in_reply_to_screen_name" : "Y_Gilad",
  "in_reply_to_user_id_str" : "2802558480",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 37, 43 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/OBRQeSWcCS",
      "expanded_url" : "http:\/\/djmag.ca\/blog\/2015\/04\/27\/music-recorded-dna-molecule\/",
      "display_url" : "djmag.ca\/blog\/2015\/04\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593381541734154240",
  "text" : "music recorded onto DNA molecule \/cc @dvzrv http:\/\/t.co\/OBRQeSWcCS",
  "id" : 593381541734154240,
  "created_at" : "2015-04-29 11:49:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Medina",
      "screen_name" : "bryomedina",
      "indices" : [ 3, 14 ],
      "id_str" : "2208151837",
      "id" : 2208151837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bryomedina\/status\/593203096815304705\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/zFHsDmX3Tg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDt7EqsWEAAx8vv.png",
      "id_str" : "593203096039329792",
      "id" : 593203096039329792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDt7EqsWEAAx8vv.png",
      "sizes" : [ {
        "h" : 429,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 429,
        "resize" : "fit",
        "w" : 670
      } ],
      "display_url" : "pic.twitter.com\/zFHsDmX3Tg"
    } ],
    "hashtags" : [ {
      "text" : "species",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "Darwin",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593286829417373696",
  "text" : "RT @bryomedina: Does #species delimitation drive you crazy? You are not alone (my favourite #Darwin's quote ever) http:\/\/t.co\/zFHsDmX3Tg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bryomedina\/status\/593203096815304705\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/zFHsDmX3Tg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDt7EqsWEAAx8vv.png",
        "id_str" : "593203096039329792",
        "id" : 593203096039329792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDt7EqsWEAAx8vv.png",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 429,
          "resize" : "fit",
          "w" : 670
        } ],
        "display_url" : "pic.twitter.com\/zFHsDmX3Tg"
      } ],
      "hashtags" : [ {
        "text" : "species",
        "indices" : [ 5, 13 ]
      }, {
        "text" : "Darwin",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593203096815304705",
    "text" : "Does #species delimitation drive you crazy? You are not alone (my favourite #Darwin's quote ever) http:\/\/t.co\/zFHsDmX3Tg",
    "id" : 593203096815304705,
    "created_at" : "2015-04-29 00:00:14 +0000",
    "user" : {
      "name" : "Rafael Medina",
      "screen_name" : "bryomedina",
      "protected" : false,
      "id_str" : "2208151837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566689300939411456\/XtjtlKsu_normal.jpeg",
      "id" : 2208151837,
      "verified" : false
    }
  },
  "id" : 593286829417373696,
  "created_at" : "2015-04-29 05:32:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "593147543569195008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409328611654, 8.7532869346785 ]
  },
  "id_str" : "593149051027226624",
  "in_reply_to_user_id" : 14286491,
  "text" : "Given the current prices for a single genotyping that\u2019s open data worth ~ USD 183,000.",
  "id" : 593149051027226624,
  "in_reply_to_status_id" : 593147543569195008,
  "created_at" : "2015-04-28 20:25:28 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/593147543569195008\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/qhHLJKx3cw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDtIjBjWYAEa7-L.png",
      "id_str" : "593147542478675969",
      "id" : 593147542478675969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDtIjBjWYAEa7-L.png",
      "sizes" : [ {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 726,
        "resize" : "fit",
        "w" : 704
      } ],
      "display_url" : "pic.twitter.com\/qhHLJKx3cw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409328611654, 8.7532869346785 ]
  },
  "id_str" : "593147543569195008",
  "text" : "If the trajectory continues: 2 1\/2 years for getting the first 1k genotypings on openSNP, 1 more for going to 2k. http:\/\/t.co\/qhHLJKx3cw",
  "id" : 593147543569195008,
  "created_at" : "2015-04-28 20:19:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/5nCIgAANwm",
      "expanded_url" : "http:\/\/ccdb.tau.ac.il\/",
      "display_url" : "ccdb.tau.ac.il"
    } ]
  },
  "geo" : { },
  "id_str" : "592981284055556096",
  "text" : "Is there a database on the number of chromosomes for fungi? Similar to http:\/\/t.co\/5nCIgAANwm",
  "id" : 592981284055556096,
  "created_at" : "2015-04-28 09:18:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 62, 71 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/0A5vN6E6s7",
      "expanded_url" : "https:\/\/medium.com\/vantage\/insta-of-the-week-blade-runner-in-real-life-1c441b6dcd8d?section=%5Bobject%20Object%5D",
      "display_url" : "medium.com\/vantage\/insta-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592971045436522496",
  "text" : "Blade Runner Reality on Instagram https:\/\/t.co\/0A5vN6E6s7 \/cc @JP_Stich",
  "id" : 592971045436522496,
  "created_at" : "2015-04-28 08:38:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/OBwXBJmhEQ",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/6hG75nHladQhW\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/6hG75nHl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "592968294493192192",
  "geo" : { },
  "id_str" : "592969171165646848",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke opening your inbox on a given day. http:\/\/t.co\/OBwXBJmhEQ",
  "id" : 592969171165646848,
  "in_reply_to_status_id" : 592968294493192192,
  "created_at" : "2015-04-28 08:30:41 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592965616585289728",
  "geo" : { },
  "id_str" : "592967623333249024",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke that\u2019s a shame :D",
  "id" : 592967623333249024,
  "in_reply_to_status_id" : 592965616585289728,
  "created_at" : "2015-04-28 08:24:32 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/afokj2DMO1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=jjh_LaRNqiY",
      "display_url" : "youtube.com\/watch?v=jjh_La\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592965488407351296",
  "text" : "allow yourself to get lost https:\/\/t.co\/afokj2DMO1",
  "id" : 592965488407351296,
  "created_at" : "2015-04-28 08:16:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592963919016292352",
  "geo" : { },
  "id_str" : "592965344714739713",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke that\u2019s a nice gift to make to whomever will follow ;)",
  "id" : 592965344714739713,
  "in_reply_to_status_id" : 592963919016292352,
  "created_at" : "2015-04-28 08:15:29 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592950724318928897",
  "geo" : { },
  "id_str" : "592960422027927552",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke move everything into some folder and all of a sudden it\u2019s easy to keep inbox zero.",
  "id" : 592960422027927552,
  "in_reply_to_status_id" : 592950724318928897,
  "created_at" : "2015-04-28 07:55:55 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592959379256811520",
  "text" : "RT @Danitni: \u05D7\u05DE\u05D9\u05E9\u05D4 \u05DE\u05E2\u05E0\u05E7\u05D9\u05DD \u05E9\u05DC 50,000 \u05D0\u05D9\u05E8\u05D5 + \u05D7\u05DE\u05D9\u05E9\u05D4 \u05D7\u05D5\u05D3\u05E9\u05D9 \u05D4\u05D3\u05E8\u05DB\u05D4 \u05D5\u05D7\u05E0\u05D9\u05DB\u05D4 \u05D1\u05D1\u05D0\u05D9\u05D9\u05E8 \u05D1\u05E8\u05DC\u05D9\u05DF . \u05D9\u05E9 \u05DC\u05DB\u05DD \u05E8\u05E2\u05D9\u05D5\u05DF \u05D1\u05EA\u05D7\u05D5\u05DD \u05D8\u05DB\u05E0\u05D5\u05DC\u05D5\u05D2\u05D9\u05D5\u05EA \u05D1\u05E8\u05D9\u05D0\u05D5\u05EA? \u05DB\u05E0\u05E1\u05D5! https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/2vcvhkXBSa",
        "expanded_url" : "https:\/\/twitter.com\/grants4apps\/status\/592282323908960258",
        "display_url" : "twitter.com\/grants4apps\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592939126648926208",
    "text" : "\u05D7\u05DE\u05D9\u05E9\u05D4 \u05DE\u05E2\u05E0\u05E7\u05D9\u05DD \u05E9\u05DC 50,000 \u05D0\u05D9\u05E8\u05D5 + \u05D7\u05DE\u05D9\u05E9\u05D4 \u05D7\u05D5\u05D3\u05E9\u05D9 \u05D4\u05D3\u05E8\u05DB\u05D4 \u05D5\u05D7\u05E0\u05D9\u05DB\u05D4 \u05D1\u05D1\u05D0\u05D9\u05D9\u05E8 \u05D1\u05E8\u05DC\u05D9\u05DF . \u05D9\u05E9 \u05DC\u05DB\u05DD \u05E8\u05E2\u05D9\u05D5\u05DF \u05D1\u05EA\u05D7\u05D5\u05DD \u05D8\u05DB\u05E0\u05D5\u05DC\u05D5\u05D2\u05D9\u05D5\u05EA \u05D1\u05E8\u05D9\u05D0\u05D5\u05EA? \u05DB\u05E0\u05E1\u05D5! https:\/\/t.co\/2vcvhkXBSa",
    "id" : 592939126648926208,
    "created_at" : "2015-04-28 06:31:18 +0000",
    "user" : {
      "name" : "SoThere",
      "screen_name" : "greatendsmall",
      "protected" : false,
      "id_str" : "431594700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/823796015522283521\/PVlz3Cos_normal.jpg",
      "id" : 431594700,
      "verified" : false
    }
  },
  "id" : 592959379256811520,
  "created_at" : "2015-04-28 07:51:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Francois Grey",
      "screen_name" : "FrancoisGrey",
      "indices" : [ 3, 16 ],
      "id_str" : "16110315",
      "id" : 16110315
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 22, 31 ],
      "id_str" : "87818409",
      "id" : 87818409
    }, {
      "name" : "Crowdcrafting",
      "screen_name" : "crowdcrafting",
      "indices" : [ 55, 69 ],
      "id_str" : "2281995839",
      "id" : 2281995839
    }, {
      "name" : "Rufus Pollock",
      "screen_name" : "rufuspollock",
      "indices" : [ 93, 106 ],
      "id_str" : "107722135",
      "id" : 107722135
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 107, 118 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Muki Haklay",
      "screen_name" : "mhaklay",
      "indices" : [ 119, 127 ],
      "id_str" : "16080324",
      "id" : 16080324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/GswZAnjIif",
      "expanded_url" : "http:\/\/bit.ly\/1A7EtFj",
      "display_url" : "bit.ly\/1A7EtFj"
    } ]
  },
  "geo" : { },
  "id_str" : "592958386754473984",
  "text" : "RT @FrancoisGrey: The @Guardian tracks corruption with @Crowdcrafting http:\/\/t.co\/GswZAnjIif @rufuspollock @bella_velo @mhaklay @FrancoisTa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 4, 13 ],
        "id_str" : "87818409",
        "id" : 87818409
      }, {
        "name" : "Crowdcrafting",
        "screen_name" : "crowdcrafting",
        "indices" : [ 37, 51 ],
        "id_str" : "2281995839",
        "id" : 2281995839
      }, {
        "name" : "Rufus Pollock",
        "screen_name" : "rufuspollock",
        "indices" : [ 75, 88 ],
        "id_str" : "107722135",
        "id" : 107722135
      }, {
        "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
        "screen_name" : "bella_velo",
        "indices" : [ 89, 100 ],
        "id_str" : "6745972",
        "id" : 6745972
      }, {
        "name" : "Muki Haklay",
        "screen_name" : "mhaklay",
        "indices" : [ 101, 109 ],
        "id_str" : "16080324",
        "id" : 16080324
      }, {
        "name" : "Fran\u00E7ois Taddei",
        "screen_name" : "FrancoisTaddei",
        "indices" : [ 110, 125 ],
        "id_str" : "89894871",
        "id" : 89894871
      }, {
        "name" : "D\u24D0niel Mietchen",
        "screen_name" : "EvoMRI",
        "indices" : [ 126, 133 ],
        "id_str" : "15132914",
        "id" : 15132914
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/GswZAnjIif",
        "expanded_url" : "http:\/\/bit.ly\/1A7EtFj",
        "display_url" : "bit.ly\/1A7EtFj"
      } ]
    },
    "geo" : { },
    "id_str" : "592810876283006976",
    "text" : "The @Guardian tracks corruption with @Crowdcrafting http:\/\/t.co\/GswZAnjIif @rufuspollock @bella_velo @mhaklay @FrancoisTaddei @EvoMRI",
    "id" : 592810876283006976,
    "created_at" : "2015-04-27 22:01:41 +0000",
    "user" : {
      "name" : "Francois Grey",
      "screen_name" : "FrancoisGrey",
      "protected" : false,
      "id_str" : "16110315",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2192498915\/FrancoisITPsquare_normal.png",
      "id" : 16110315,
      "verified" : false
    }
  },
  "id" : 592958386754473984,
  "created_at" : "2015-04-28 07:47:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399244026826, 8.753470218786882 ]
  },
  "id_str" : "592754121880502272",
  "text" : "Submitting always gives one a good excuse to sweep through the working directories. Went down from big data (5.5 TB) to data (~1 TB).",
  "id" : 592754121880502272,
  "created_at" : "2015-04-27 18:16:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409243187779, 8.753293700387786 ]
  },
  "id_str" : "592736492742713344",
  "text" : "Submitted yet another paper!\uD83D\uDC83\uD83C\uDFFD",
  "id" : 592736492742713344,
  "created_at" : "2015-04-27 17:06:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/kWuKNvaw7O",
      "expanded_url" : "https:\/\/medium.com\/message\/the-words-the-media-industry-prefers-5d33e5b021e0",
      "display_url" : "medium.com\/message\/the-wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592701890430955520",
  "text" : "RT @wilbanks: \u201CNo, these terms are perfectly chosen and language is never ambiguous.\u201D https:\/\/t.co\/kWuKNvaw7O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/kWuKNvaw7O",
        "expanded_url" : "https:\/\/medium.com\/message\/the-words-the-media-industry-prefers-5d33e5b021e0",
        "display_url" : "medium.com\/message\/the-wo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592696173762338817",
    "text" : "\u201CNo, these terms are perfectly chosen and language is never ambiguous.\u201D https:\/\/t.co\/kWuKNvaw7O",
    "id" : 592696173762338817,
    "created_at" : "2015-04-27 14:25:54 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 592701890430955520,
  "created_at" : "2015-04-27 14:48:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592618168813752320",
  "geo" : { },
  "id_str" : "592618271016427520",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABThe Law of Unintended Consequences. Have you heard of that theory? If not, I\u2019m sure Malcolm Gladwell wrote about it somewhere.\u00BB",
  "id" : 592618271016427520,
  "in_reply_to_status_id" : 592618168813752320,
  "created_at" : "2015-04-27 09:16:20 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/MHrlVzhxJj",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/an-open-letter-to-the-guy-who-discovered-the-10-000-hour-rule",
      "display_url" : "mcsweeneys.net\/articles\/an-op\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592618168813752320",
  "text" : "An Open Letter to the Guy Who Discovered the 10,000 Hour Rule http:\/\/t.co\/MHrlVzhxJj",
  "id" : 592618168813752320,
  "created_at" : "2015-04-27 09:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/JV91qalcib",
      "expanded_url" : "http:\/\/danmaclean.github.io\/sadist-or-stasitician\/",
      "display_url" : "danmaclean.github.io\/sadist-or-stas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592604846378897409",
  "text" : "Lies, damn lies and statistics http:\/\/t.co\/JV91qalcib",
  "id" : 592604846378897409,
  "created_at" : "2015-04-27 08:23:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/A66b0UUAjX",
      "expanded_url" : "http:\/\/smbc-comics.com\/index.php?id=3717",
      "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592434481962885120",
  "text" : "RT @JBYoder: \u201CEveryone knows ethics was finally worked out in summer, 2013.\u201D http:\/\/t.co\/A66b0UUAjX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/A66b0UUAjX",
        "expanded_url" : "http:\/\/smbc-comics.com\/index.php?id=3717",
        "display_url" : "smbc-comics.com\/index.php?id=3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592381966432927744",
    "text" : "\u201CEveryone knows ethics was finally worked out in summer, 2013.\u201D http:\/\/t.co\/A66b0UUAjX",
    "id" : 592381966432927744,
    "created_at" : "2015-04-26 17:37:21 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 592434481962885120,
  "created_at" : "2015-04-26 21:06:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592378073200336897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10768125769692, 8.767948150642932 ]
  },
  "id_str" : "592433273172848640",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek gratulations to her!",
  "id" : 592433273172848640,
  "in_reply_to_status_id" : 592378073200336897,
  "created_at" : "2015-04-26 21:01:13 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/hiir0lcD6R",
      "expanded_url" : "http:\/\/publiceditor.blogs.nytimes.com\/2013\/04\/01\/gender-questions-arise-in-obituary-of-rocket-scientist-and-her-beef-stroganoff\/?_r=0",
      "display_url" : "publiceditor.blogs.nytimes.com\/2013\/04\/01\/gen\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409395446051, 8.753290120798377 ]
  },
  "id_str" : "592276781513764865",
  "text" : "\u201952 Women Who Changed Science &amp; the World\u2019 begins with \u2018This book about scientists began with Beef Stroganoff\u2026\u2019 http:\/\/t.co\/hiir0lcD6R",
  "id" : 592276781513764865,
  "created_at" : "2015-04-26 10:39:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/B3P7CpaQpX",
      "expanded_url" : "https:\/\/placesjournal.org\/article\/the-association-of-gay-suburban-people\/",
      "display_url" : "placesjournal.org\/article\/the-as\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592232146456211457",
  "text" : "The Association of (Gay) Suburban People https:\/\/t.co\/B3P7CpaQpX",
  "id" : 592232146456211457,
  "created_at" : "2015-04-26 07:42:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/HGqtXq92Zi",
      "expanded_url" : "https:\/\/plus.google.com\/+MichaelNielsen\/posts\/QXchS6wfp8V",
      "display_url" : "plus.google.com\/+MichaelNielse\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409395203288, 8.753290312325095 ]
  },
  "id_str" : "592083742321156096",
  "text" : "Some nice ideas on generative travel, also in the comments https:\/\/t.co\/HGqtXq92Zi",
  "id" : 592083742321156096,
  "created_at" : "2015-04-25 21:52:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/WlFHFuzfQa",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/phone-cell-dog-dtBi0s3hndz7q",
      "display_url" : "giphy.com\/gifs\/phone-cel\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "592080215481982976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409351445086, 8.753293553824784 ]
  },
  "id_str" : "592081271049846784",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon https:\/\/t.co\/WlFHFuzfQa",
  "id" : 592081271049846784,
  "in_reply_to_status_id" : 592080215481982976,
  "created_at" : "2015-04-25 21:42:30 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592077016700190720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409279700613, 8.75329418362794 ]
  },
  "id_str" : "592077427939135488",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon daf\u00FCr musst du mal wieder zum Katzenyoga kommen. :3",
  "id" : 592077427939135488,
  "in_reply_to_status_id" : 592077016700190720,
  "created_at" : "2015-04-25 21:27:13 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 15, 24 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592076913805553664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409279700613, 8.75329418362794 ]
  },
  "id_str" : "592077222812512256",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @Senficon by now everyone wishes he would opt for the dark side of the moon.",
  "id" : 592077222812512256,
  "in_reply_to_status_id" : 592076913805553664,
  "created_at" : "2015-04-25 21:26:24 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592076354469912577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409388328325, 8.753295056681589 ]
  },
  "id_str" : "592076576843550720",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon das ist eine sch\u00F6ne Kurzform von \u2018angry old white man\u2019.",
  "id" : 592076576843550720,
  "in_reply_to_status_id" : 592076354469912577,
  "created_at" : "2015-04-25 21:23:50 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592073572132192256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409353554203, 8.75329367939014 ]
  },
  "id_str" : "592075938118168576",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Du Dawkins-Fan :D",
  "id" : 592075938118168576,
  "in_reply_to_status_id" : 592073572132192256,
  "created_at" : "2015-04-25 21:21:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/T4HEiSUv8n",
      "expanded_url" : "https:\/\/instagram.com\/p\/16LEuiBwq5\/",
      "display_url" : "instagram.com\/p\/16LEuiBwq5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "592041294584782848",
  "text" : "push me, pull me https:\/\/t.co\/T4HEiSUv8n",
  "id" : 592041294584782848,
  "created_at" : "2015-04-25 19:03:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/592024557692788736\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/kPZKMkeeyX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDdLMkFW0AAylgd.jpg",
      "id_str" : "592024555239165952",
      "id" : 592024555239165952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDdLMkFW0AAylgd.jpg",
      "sizes" : [ {
        "h" : 935,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1898,
        "resize" : "fit",
        "w" : 2435
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1596,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/kPZKMkeeyX"
    } ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 77, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11071470733587, 8.759808415691618 ]
  },
  "id_str" : "592024557692788736",
  "text" : "Seen in a museum in Frankfurt today: what H\u00F4tel de Ville looked like in 1871 #sageparisassembly http:\/\/t.co\/kPZKMkeeyX",
  "id" : 592024557692788736,
  "created_at" : "2015-04-25 17:57:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Assemblathon",
      "screen_name" : "assemblathon",
      "indices" : [ 0, 13 ],
      "id_str" : "216793572",
      "id" : 216793572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591992824934989824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409393953416, 8.753291042456443 ]
  },
  "id_str" : "591994282715828224",
  "in_reply_to_user_id" : 216793572,
  "text" : "@assemblathon aren\u2019t you afraid that it might be too repetitive?",
  "id" : 591994282715828224,
  "in_reply_to_status_id" : 591992824934989824,
  "created_at" : "2015-04-25 15:56:50 +0000",
  "in_reply_to_screen_name" : "assemblathon",
  "in_reply_to_user_id_str" : "216793572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Alloza",
      "screen_name" : "EvaAlloza",
      "indices" : [ 0, 10 ],
      "id_str" : "531789491",
      "id" : 531789491
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 11, 16 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "Ajuntament de BCN",
      "screen_name" : "bcn_ajuntament",
      "indices" : [ 17, 32 ],
      "id_str" : "423369901",
      "id" : 423369901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591948404995072000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11229198409324, 8.74929884124068 ]
  },
  "id_str" : "591950669961142272",
  "in_reply_to_user_id" : 531789491,
  "text" : "@EvaAlloza @johl @bcn_ajuntament sweet! Thanks a lot!",
  "id" : 591950669961142272,
  "in_reply_to_status_id" : 591948404995072000,
  "created_at" : "2015-04-25 13:03:32 +0000",
  "in_reply_to_screen_name" : "EvaAlloza",
  "in_reply_to_user_id_str" : "531789491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 101, 106 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591595597716709376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11241120756614, 8.740641083576474 ]
  },
  "id_str" : "591947136562012160",
  "in_reply_to_user_id" : 1147751,
  "text" : "Regarding open data on trees in Berlin: \u00AB30 trees is good for a start. I found 300,000 for New York\u00BB @johl",
  "id" : 591947136562012160,
  "in_reply_to_status_id" : 591595597716709376,
  "created_at" : "2015-04-25 12:49:29 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T. Ryan Gregory",
      "screen_name" : "TRyanGregory",
      "indices" : [ 3, 16 ],
      "id_str" : "151257881",
      "id" : 151257881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591696612558315521",
  "text" : "RT @TRyanGregory: Student: \"They spent entire lectures trying to teach us how to think instead of teaching us something useful.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591687009523085312",
    "text" : "Student: \"They spent entire lectures trying to teach us how to think instead of teaching us something useful.\"",
    "id" : 591687009523085312,
    "created_at" : "2015-04-24 19:35:50 +0000",
    "user" : {
      "name" : "T. Ryan Gregory",
      "screen_name" : "TRyanGregory",
      "protected" : false,
      "id_str" : "151257881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/954599622\/TRGDNA_normal.jpg",
      "id" : 151257881,
      "verified" : false
    }
  },
  "id" : 591696612558315521,
  "created_at" : "2015-04-24 20:14:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591652363527589888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11407887939639, 8.753322806273989 ]
  },
  "id_str" : "591694274800025602",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam is CEGMA among that list? :p",
  "id" : 591694274800025602,
  "in_reply_to_status_id" : 591652363527589888,
  "created_at" : "2015-04-24 20:04:42 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mundraub",
      "screen_name" : "mundraub_org",
      "indices" : [ 0, 13 ],
      "id_str" : "247921398",
      "id" : 247921398
    }, {
      "name" : "Manu",
      "screen_name" : "manubloggt",
      "indices" : [ 14, 25 ],
      "id_str" : "39963826",
      "id" : 39963826
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 26, 31 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591685191942459392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140934230267, 8.753295550049375 ]
  },
  "id_str" : "591688633503059969",
  "in_reply_to_user_id" : 247921398,
  "text" : "@mundraub_org @manubloggt @johl die kurze Antwort ist also: Freies Obst wie in Freibier, nicht wie in gemeinfrei. Hat sich damit erledigt.",
  "id" : 591688633503059969,
  "in_reply_to_status_id" : 591685191942459392,
  "created_at" : "2015-04-24 19:42:17 +0000",
  "in_reply_to_screen_name" : "mundraub_org",
  "in_reply_to_user_id_str" : "247921398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mundraub",
      "screen_name" : "mundraub_org",
      "indices" : [ 0, 13 ],
      "id_str" : "247921398",
      "id" : 247921398
    }, {
      "name" : "Manu",
      "screen_name" : "manubloggt",
      "indices" : [ 14, 25 ],
      "id_str" : "39963826",
      "id" : 39963826
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 26, 31 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591683621217574912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10537665125266, 8.76523092872364 ]
  },
  "id_str" : "591683952890503168",
  "in_reply_to_user_id" : 247921398,
  "text" : "@mundraub_org @manubloggt @johl und offen verf\u00FCgbar zum Download und Remix?",
  "id" : 591683952890503168,
  "in_reply_to_status_id" : 591683621217574912,
  "created_at" : "2015-04-24 19:23:41 +0000",
  "in_reply_to_screen_name" : "mundraub_org",
  "in_reply_to_user_id_str" : "247921398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591618642971852800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10384175708425, 8.766711207408939 ]
  },
  "id_str" : "591674280364085251",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur could also be some species of Cladonia?",
  "id" : 591674280364085251,
  "in_reply_to_status_id" : 591618642971852800,
  "created_at" : "2015-04-24 18:45:15 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mundraub",
      "screen_name" : "mundraub_org",
      "indices" : [ 0, 13 ],
      "id_str" : "247921398",
      "id" : 247921398
    }, {
      "name" : "Manu",
      "screen_name" : "manubloggt",
      "indices" : [ 14, 25 ],
      "id_str" : "39963826",
      "id" : 39963826
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 26, 31 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591620799892692992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409368577861, 8.753295938907717 ]
  },
  "id_str" : "591621089735876610",
  "in_reply_to_user_id" : 247921398,
  "text" : "@mundraub_org @manubloggt @johl aber was ist mit den Daten die ihr per Crowdsourcing bekommt. Sind die offen?",
  "id" : 591621089735876610,
  "in_reply_to_status_id" : 591620799892692992,
  "created_at" : "2015-04-24 15:13:54 +0000",
  "in_reply_to_screen_name" : "mundraub_org",
  "in_reply_to_user_id_str" : "247921398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "synapsenquerschl\u00E4ger",
      "screen_name" : "Cocktailrent",
      "indices" : [ 0, 13 ],
      "id_str" : "251644391",
      "id" : 251644391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591599598172565506",
  "geo" : { },
  "id_str" : "591602222254968832",
  "in_reply_to_user_id" : 251644391,
  "text" : "@Cocktailrent Danke, werde auch mal in die Richtung schauen. :)",
  "id" : 591602222254968832,
  "in_reply_to_status_id" : 591599598172565506,
  "created_at" : "2015-04-24 13:58:55 +0000",
  "in_reply_to_screen_name" : "Cocktailrent",
  "in_reply_to_user_id_str" : "251644391",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DigitaleLaBi@zlb.de",
      "screen_name" : "zlb_digital",
      "indices" : [ 0, 12 ],
      "id_str" : "843591000",
      "id" : 843591000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591601964665982977",
  "geo" : { },
  "id_str" : "591602183562469376",
  "in_reply_to_user_id" : 843591000,
  "text" : "@zlb_digital Thanks a lot, those two will be useful to him I hope. :-)",
  "id" : 591602183562469376,
  "in_reply_to_status_id" : 591601964665982977,
  "created_at" : "2015-04-24 13:58:46 +0000",
  "in_reply_to_screen_name" : "zlb_digital",
  "in_reply_to_user_id_str" : "843591000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dynamic Ecology",
      "screen_name" : "DynamicEcology",
      "indices" : [ 3, 18 ],
      "id_str" : "633095212",
      "id" : 633095212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Y7OAEcZXdy",
      "expanded_url" : "http:\/\/wp.me\/p2wMuW-3mu",
      "display_url" : "wp.me\/p2wMuW-3mu"
    } ]
  },
  "geo" : { },
  "id_str" : "591601627167117312",
  "text" : "RT @DynamicEcology: Ecologists disagree on whether co-authors should\u00A0agree http:\/\/t.co\/Y7OAEcZXdy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/Y7OAEcZXdy",
        "expanded_url" : "http:\/\/wp.me\/p2wMuW-3mu",
        "display_url" : "wp.me\/p2wMuW-3mu"
      } ]
    },
    "geo" : { },
    "id_str" : "590842368460345344",
    "text" : "Ecologists disagree on whether co-authors should\u00A0agree http:\/\/t.co\/Y7OAEcZXdy",
    "id" : 590842368460345344,
    "created_at" : "2015-04-22 11:39:32 +0000",
    "user" : {
      "name" : "Dynamic Ecology",
      "screen_name" : "DynamicEcology",
      "protected" : false,
      "id_str" : "633095212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2388748514\/twitter_image_normal.jpg",
      "id" : 633095212,
      "verified" : false
    }
  },
  "id" : 591601627167117312,
  "created_at" : "2015-04-24 13:56:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manu",
      "screen_name" : "manubloggt",
      "indices" : [ 0, 11 ],
      "id_str" : "39963826",
      "id" : 39963826
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 12, 17 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "mundraub",
      "screen_name" : "mundraub_org",
      "indices" : [ 18, 31 ],
      "id_str" : "247921398",
      "id" : 247921398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591600559540596736",
  "geo" : { },
  "id_str" : "591600740302508032",
  "in_reply_to_user_id" : 39963826,
  "text" : "@manubloggt @johl @mundraub_org yeah, they somehow seem keen on giving the \u201Copen\u201D impression without actually doing sharing\u2026",
  "id" : 591600740302508032,
  "in_reply_to_status_id" : 591600559540596736,
  "created_at" : "2015-04-24 13:53:02 +0000",
  "in_reply_to_screen_name" : "manubloggt",
  "in_reply_to_user_id_str" : "39963826",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manu",
      "screen_name" : "manubloggt",
      "indices" : [ 0, 11 ],
      "id_str" : "39963826",
      "id" : 39963826
    }, {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 12, 17 ],
      "id_str" : "1147751",
      "id" : 1147751
    }, {
      "name" : "mundraub",
      "screen_name" : "mundraub_org",
      "indices" : [ 78, 91 ],
      "id_str" : "247921398",
      "id" : 247921398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591597288872660993",
  "geo" : { },
  "id_str" : "591598826034700288",
  "in_reply_to_user_id" : 39963826,
  "text" : "@manubloggt @johl nice idea, but is it just me being unable to find it, or is @mundraub_org not actually open data?",
  "id" : 591598826034700288,
  "in_reply_to_status_id" : 591597288872660993,
  "created_at" : "2015-04-24 13:45:26 +0000",
  "in_reply_to_screen_name" : "manubloggt",
  "in_reply_to_user_id_str" : "39963826",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 0, 5 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/cgdd18h2VK",
      "expanded_url" : "http:\/\/daten.berlin.de\/datensaetze\/als-naturdenkmale-gesch%C3%BCtzte-b%C3%A4ume-charlottenburg-wilmersdorf-0",
      "display_url" : "daten.berlin.de\/datensaetze\/al\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "591595597716709376",
  "geo" : { },
  "id_str" : "591595791090900993",
  "in_reply_to_user_id" : 1147751,
  "text" : "@johl there are also 27 trees having their own API: http:\/\/t.co\/cgdd18h2VK",
  "id" : 591595791090900993,
  "in_reply_to_status_id" : 591595597716709376,
  "created_at" : "2015-04-24 13:33:22 +0000",
  "in_reply_to_screen_name" : "johl",
  "in_reply_to_user_id_str" : "1147751",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591595233042964480",
  "text" : "Hey Berlin, a friend of mine is working on a virtual tree hugging project. Are there open data sets on Berlin\u2019s trees &amp; their locations?",
  "id" : 591595233042964480,
  "created_at" : "2015-04-24 13:31:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 96, 108 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591580047422726144",
  "geo" : { },
  "id_str" : "591580237781192705",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Klar, das kriege ich hin. Und eventuell kann ich ja noch was tricksen um vor Ort zu sein. @helgerausch",
  "id" : 591580237781192705,
  "in_reply_to_status_id" : 591580047422726144,
  "created_at" : "2015-04-24 12:31:34 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 13, 18 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591574503387492352",
  "geo" : { },
  "id_str" : "591578664573231104",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @li5a prinzipiell ja. Aber hab Donnerstag Mittag noch ein Meeting und ich bin nach 1 1\/2 Monaten gerade 4 Tage wieder vor Ort.",
  "id" : 591578664573231104,
  "in_reply_to_status_id" : 591574503387492352,
  "created_at" : "2015-04-24 12:25:19 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591570008972615680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.15503588347928, 8.600307403860269 ]
  },
  "id_str" : "591573041798389762",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a ne, das wird leider nicht klappen. Daf\u00FCr ist es zu weit. Gibt\u2019s eine Chance es zu verschieben?",
  "id" : 591573041798389762,
  "in_reply_to_status_id" : 591570008972615680,
  "created_at" : "2015-04-24 12:02:58 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591566752317865984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17222753068744, 8.62767418339777 ]
  },
  "id_str" : "591567320906145792",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a vermutlich um eine Uhrzeit die mir nicht erlaubt nach der Arbeit loszufahren, Right? ;)",
  "id" : 591567320906145792,
  "in_reply_to_status_id" : 591566752317865984,
  "created_at" : "2015-04-24 11:40:14 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591565678894800896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236126125806, 8.62770734355657 ]
  },
  "id_str" : "591565858499121152",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a nope, aber g\u00E4be es einen guten Grund dort zu sein?",
  "id" : 591565858499121152,
  "in_reply_to_status_id" : 591565678894800896,
  "created_at" : "2015-04-24 11:34:26 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591559979104088064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12985341866919, 8.614502048081851 ]
  },
  "id_str" : "591560463521034241",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng ich hab da noch einen Sack voll bei mir stehen. :)",
  "id" : 591560463521034241,
  "in_reply_to_status_id" : 591559979104088064,
  "created_at" : "2015-04-24 11:12:59 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ZdBBgQOSdE",
      "expanded_url" : "https:\/\/github.com\/mw55309\/phix_check",
      "display_url" : "github.com\/mw55309\/phix_c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591558902602399744",
  "text" : "RT @BioMickWatson: A simple tool for all those people who can't tell if they have PhiX in their data: https:\/\/t.co\/ZdBBgQOSdE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/ZdBBgQOSdE",
        "expanded_url" : "https:\/\/github.com\/mw55309\/phix_check",
        "display_url" : "github.com\/mw55309\/phix_c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591553467304534016",
    "text" : "A simple tool for all those people who can't tell if they have PhiX in their data: https:\/\/t.co\/ZdBBgQOSdE",
    "id" : 591553467304534016,
    "created_at" : "2015-04-24 10:45:11 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 591558902602399744,
  "created_at" : "2015-04-24 11:06:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/gJDlqF8qii",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1004191",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591503854451097600",
  "text" : "That\u2019s actually a nice \u201810 simple rules\u2019 idea: Reducing Overoptimistic Reporting in Methodological Comp. Research http:\/\/t.co\/gJDlqF8qii",
  "id" : 591503854451097600,
  "created_at" : "2015-04-24 07:28:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591470894301585410",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1240530843382, 8.91767911613818 ]
  },
  "id_str" : "591474109986406400",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke yeah, I also have other preferences for starting the day. ;)",
  "id" : 591474109986406400,
  "in_reply_to_status_id" : 591470894301585410,
  "created_at" : "2015-04-24 05:29:51 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "591466151562989569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.12402207129647, 8.917673500263055 ]
  },
  "id_str" : "591470614445064192",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke can\u2019t be to bad if you can still hum along the battle hymn of the republic. ;)",
  "id" : 591470614445064192,
  "in_reply_to_status_id" : 591466151562989569,
  "created_at" : "2015-04-24 05:15:58 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1107153939283, 8.759806753959193 ]
  },
  "id_str" : "591460794186870786",
  "text" : "Hitting my head on the kitchen cabinet\u2019s door: Blood upon the early riser\u2026",
  "id" : 591460794186870786,
  "created_at" : "2015-04-24 04:36:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/BHRGBJlcLv",
      "expanded_url" : "https:\/\/instagram.com\/p\/11FX2Xhwvr\/",
      "display_url" : "instagram.com\/p\/11FX2Xhwvr\/"
    } ]
  },
  "geo" : { },
  "id_str" : "591325068694695937",
  "text" : "Wait a sec\u2026 https:\/\/t.co\/BHRGBJlcLv",
  "id" : 591325068694695937,
  "created_at" : "2015-04-23 19:37:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Doria",
      "screen_name" : "Dorialexander",
      "indices" : [ 3, 17 ],
      "id_str" : "276508048",
      "id" : 276508048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/YMewid4hOd",
      "expanded_url" : "http:\/\/ec.europa.eu\/research\/consultations\/science-2.0\/science_2_0_final_report.pdf",
      "display_url" : "ec.europa.eu\/research\/consu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591222897894674433",
  "text" : "RT @Dorialexander: The European Commission has just published its report on the Science 2.0 consultation: http:\/\/t.co\/YMewid4hOd #OpenSci4D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenSci4Doc",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/YMewid4hOd",
        "expanded_url" : "http:\/\/ec.europa.eu\/research\/consultations\/science-2.0\/science_2_0_final_report.pdf",
        "display_url" : "ec.europa.eu\/research\/consu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591214053227388931",
    "text" : "The European Commission has just published its report on the Science 2.0 consultation: http:\/\/t.co\/YMewid4hOd #OpenSci4Doc",
    "id" : 591214053227388931,
    "created_at" : "2015-04-23 12:16:29 +0000",
    "user" : {
      "name" : "Alexander Doria",
      "screen_name" : "Dorialexander",
      "protected" : false,
      "id_str" : "276508048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433528307896688641\/lsEOefYh_normal.jpeg",
      "id" : 276508048,
      "verified" : false
    }
  },
  "id" : 591222897894674433,
  "created_at" : "2015-04-23 12:51:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "indices" : [ 3, 17 ],
      "id_str" : "16736320",
      "id" : 16736320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StGeorgesDay",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591215867242926080",
  "text" : "RT @kai_arzheimer: Fun fact: St George is an (undocumented) migrant from the Middle East #StGeorgesDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StGeorgesDay",
        "indices" : [ 70, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591213267562926080",
    "text" : "Fun fact: St George is an (undocumented) migrant from the Middle East #StGeorgesDay",
    "id" : 591213267562926080,
    "created_at" : "2015-04-23 12:13:21 +0000",
    "user" : {
      "name" : "Kai Arzheimer",
      "screen_name" : "kai_arzheimer",
      "protected" : false,
      "id_str" : "16736320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74112233\/kai_1_normal.jpg",
      "id" : 16736320,
      "verified" : false
    }
  },
  "id" : 591215867242926080,
  "created_at" : "2015-04-23 12:23:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H\u24D0ckYourPhd",
      "screen_name" : "HackYourPhd",
      "indices" : [ 3, 15 ],
      "id_str" : "1257618596",
      "id" : 1257618596
    }, {
      "name" : "Sage Bionetworks",
      "screen_name" : "Sagebio",
      "indices" : [ 28, 36 ],
      "id_str" : "130579391",
      "id" : 130579391
    }, {
      "name" : "Lesa Heraty",
      "screen_name" : "aiderpasteur",
      "indices" : [ 49, 62 ],
      "id_str" : "715165761313046530",
      "id" : 715165761313046530
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenScience",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Wvjm8cElo5",
      "expanded_url" : "http:\/\/hackyourphd.org\/en\/2015\/04\/sage-bionetworks-assembly-2015-at-institut-pasteur-paris-open-science-social-innovation-and-education-deconstructing-silos-and-anchoring-in-the-city\/",
      "display_url" : "hackyourphd.org\/en\/2015\/04\/sag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591208957106118656",
  "text" : "RT @HackYourPhd: Debrief of @Sagebio Assembly at @aiderPasteur\u2014#OpenScience\/Education &amp; Social Innovation http:\/\/t.co\/Wvjm8cElo5 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sage Bionetworks",
        "screen_name" : "Sagebio",
        "indices" : [ 11, 19 ],
        "id_str" : "130579391",
        "id" : 130579391
      }, {
        "name" : "Lesa Heraty",
        "screen_name" : "aiderpasteur",
        "indices" : [ 32, 45 ],
        "id_str" : "715165761313046530",
        "id" : 715165761313046530
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HackYourPhd\/status\/591184678499045376\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/T7z05AdNI6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDRPVQzWgAE_F5n.jpg",
        "id_str" : "591184677798576129",
        "id" : 591184677798576129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDRPVQzWgAE_F5n.jpg",
        "sizes" : [ {
          "h" : 168,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 1994
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 1994
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/T7z05AdNI6"
      } ],
      "hashtags" : [ {
        "text" : "OpenScience",
        "indices" : [ 46, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/Wvjm8cElo5",
        "expanded_url" : "http:\/\/hackyourphd.org\/en\/2015\/04\/sage-bionetworks-assembly-2015-at-institut-pasteur-paris-open-science-social-innovation-and-education-deconstructing-silos-and-anchoring-in-the-city\/",
        "display_url" : "hackyourphd.org\/en\/2015\/04\/sag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591184678499045376",
    "text" : "Debrief of @Sagebio Assembly at @aiderPasteur\u2014#OpenScience\/Education &amp; Social Innovation http:\/\/t.co\/Wvjm8cElo5 http:\/\/t.co\/T7z05AdNI6",
    "id" : 591184678499045376,
    "created_at" : "2015-04-23 10:19:45 +0000",
    "user" : {
      "name" : "H\u24D0ckYourPhd",
      "screen_name" : "HackYourPhd",
      "protected" : false,
      "id_str" : "1257618596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3542671950\/e1dd484c3a0bca77cd19a0ab9dbe4a71_normal.png",
      "id" : 1257618596,
      "verified" : false
    }
  },
  "id" : 591208957106118656,
  "created_at" : "2015-04-23 11:56:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9nuOYo64cO",
      "expanded_url" : "https:\/\/medium.com\/human-parts\/the-claustrophobia-of-fear-d7cbb484b512",
      "display_url" : "medium.com\/human-parts\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591168516348321792",
  "text" : "\u00ABYou try to give yourself a break, but that\u2019s a language you\u2019ve never spoken\u00BB https:\/\/t.co\/9nuOYo64cO",
  "id" : 591168516348321792,
  "created_at" : "2015-04-23 09:15:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/sl7OaSAYm1",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/04\/22\/awesome-nonprofit-wings-of-res.html",
      "display_url" : "boingboing.net\/2015\/04\/22\/awe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591152368609320961",
  "text" : "now i really want to get a pilot\u2019s license http:\/\/t.co\/sl7OaSAYm1",
  "id" : 591152368609320961,
  "created_at" : "2015-04-23 08:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/m8FdSmKdLU",
      "expanded_url" : "http:\/\/crosstech.crossref.org\/2015\/03\/january-2015-doi-outage-followup-report.html",
      "display_url" : "crosstech.crossref.org\/2015\/03\/januar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591147611836514304",
  "text" : "All the details of the DOI outage. In short: \u00ABwe got off relatively easy. The domain name is now on auto-renew.\u00BB http:\/\/t.co\/m8FdSmKdLU",
  "id" : 591147611836514304,
  "created_at" : "2015-04-23 07:52:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dobbs",
      "screen_name" : "David_Dobbs",
      "indices" : [ 3, 15 ],
      "id_str" : "14043142",
      "id" : 14043142
    }, {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 22, 33 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591144246989737985",
  "text" : "RT @David_Dobbs: Here @carlzimmer provides excellent, essential context on Crispr editing of human embryo. Excellent starting point. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carl Zimmer",
        "screen_name" : "carlzimmer",
        "indices" : [ 5, 16 ],
        "id_str" : "14085070",
        "id" : 14085070
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/lSETRLL64o",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2015\/04\/22\/editing-human-embryos-so-this-happened\/#.VTgskiAYtYY.twitter",
        "display_url" : "phenomena.nationalgeographic.com\/2015\/04\/22\/edi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591045539057311745",
    "text" : "Here @carlzimmer provides excellent, essential context on Crispr editing of human embryo. Excellent starting point. http:\/\/t.co\/lSETRLL64o",
    "id" : 591045539057311745,
    "created_at" : "2015-04-23 01:06:52 +0000",
    "user" : {
      "name" : "David Dobbs",
      "screen_name" : "David_Dobbs",
      "protected" : false,
      "id_str" : "14043142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798905999398735872\/eTLRoBTT_normal.jpg",
      "id" : 14043142,
      "verified" : true
    }
  },
  "id" : 591144246989737985,
  "created_at" : "2015-04-23 07:39:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominik Grimm",
      "screen_name" : "dg_grimm",
      "indices" : [ 3, 12 ],
      "id_str" : "2869039537",
      "id" : 2869039537
    }, {
      "name" : "MLCB",
      "screen_name" : "AGKBorgwardt",
      "indices" : [ 32, 45 ],
      "id_str" : "1543540112",
      "id" : 1543540112
    }, {
      "name" : "ETH Z\u00FCrich",
      "screen_name" : "ETH",
      "indices" : [ 46, 50 ],
      "id_str" : "202806809",
      "id" : 202806809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/b8sUQDngJM",
      "expanded_url" : "https:\/\/pub.refline.ch\/845721\/3879\/++publications++\/1\/index.html",
      "display_url" : "pub.refline.ch\/845721\/3879\/++\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590893247356149761",
  "text" : "RT @dg_grimm: Postdoc positions @AGKBorgwardt @ETH available: https:\/\/t.co\/b8sUQDngJM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MLCB",
        "screen_name" : "AGKBorgwardt",
        "indices" : [ 18, 31 ],
        "id_str" : "1543540112",
        "id" : 1543540112
      }, {
        "name" : "ETH Z\u00FCrich",
        "screen_name" : "ETH",
        "indices" : [ 32, 36 ],
        "id_str" : "202806809",
        "id" : 202806809
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/b8sUQDngJM",
        "expanded_url" : "https:\/\/pub.refline.ch\/845721\/3879\/++publications++\/1\/index.html",
        "display_url" : "pub.refline.ch\/845721\/3879\/++\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590890467958640640",
    "text" : "Postdoc positions @AGKBorgwardt @ETH available: https:\/\/t.co\/b8sUQDngJM",
    "id" : 590890467958640640,
    "created_at" : "2015-04-22 14:50:40 +0000",
    "user" : {
      "name" : "Dominik Grimm",
      "screen_name" : "dg_grimm",
      "protected" : false,
      "id_str" : "2869039537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/910896751577632769\/Quj-dRXl_normal.jpg",
      "id" : 2869039537,
      "verified" : false
    }
  },
  "id" : 590893247356149761,
  "created_at" : "2015-04-22 15:01:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 14, 19 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590889266126974976",
  "geo" : { },
  "id_str" : "590893074915680256",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @li5a \u201Cblue-green eyes with a sparkle of brown in the upper part of the left eye.\u201D",
  "id" : 590893074915680256,
  "in_reply_to_status_id" : 590889266126974976,
  "created_at" : "2015-04-22 15:01:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Stairs",
      "screen_name" : "AllenStairs",
      "indices" : [ 3, 15 ],
      "id_str" : "17176889",
      "id" : 17176889
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BumbleWard\/status\/590219663268679680\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/4Ob6Pu7Vle",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDholvUEAEqjNm.jpg",
      "id_str" : "590219638627110913",
      "id" : 590219638627110913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDholvUEAEqjNm.jpg",
      "sizes" : [ {
        "h" : 548,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4Ob6Pu7Vle"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590881219375685632",
  "text" : "RT @AllenStairs: That\u2019s the trouble with philosophers. They can\u2019t tell you what it\u2019s all about. http:\/\/t.co\/4Ob6Pu7Vle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BumbleWard\/status\/590219663268679680\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/4Ob6Pu7Vle",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDholvUEAEqjNm.jpg",
        "id_str" : "590219638627110913",
        "id" : 590219638627110913,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDholvUEAEqjNm.jpg",
        "sizes" : [ {
          "h" : 548,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4Ob6Pu7Vle"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590818338986663937",
    "text" : "That\u2019s the trouble with philosophers. They can\u2019t tell you what it\u2019s all about. http:\/\/t.co\/4Ob6Pu7Vle",
    "id" : 590818338986663937,
    "created_at" : "2015-04-22 10:04:03 +0000",
    "user" : {
      "name" : "Allen Stairs",
      "screen_name" : "AllenStairs",
      "protected" : false,
      "id_str" : "17176889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842762189668831232\/apI3Zsj5_normal.jpg",
      "id" : 17176889,
      "verified" : false
    }
  },
  "id" : 590881219375685632,
  "created_at" : "2015-04-22 14:13:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ludwig Kietzmann \u2615",
      "screen_name" : "LudwigK",
      "indices" : [ 3, 11 ],
      "id_str" : "16458937",
      "id" : 16458937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590854233659965440",
  "text" : "RT @LudwigK: Son, I want you to have this watch. The firmware is outdated, the OS is slow and it only runs Yelp, but it's been in our famil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "589527307410284544",
    "text" : "Son, I want you to have this watch. The firmware is outdated, the OS is slow and it only runs Yelp, but it's been in our family for 3 years.",
    "id" : 589527307410284544,
    "created_at" : "2015-04-18 20:33:57 +0000",
    "user" : {
      "name" : "Ludwig Kietzmann \u2615",
      "screen_name" : "LudwigK",
      "protected" : false,
      "id_str" : "16458937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930267620498014208\/8nObesJK_normal.jpg",
      "id" : 16458937,
      "verified" : false
    }
  },
  "id" : 590854233659965440,
  "created_at" : "2015-04-22 12:26:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "InBabyAttachMode",
      "screen_name" : "BabyAttachMode",
      "indices" : [ 3, 18 ],
      "id_str" : "482500305",
      "id" : 482500305
    }, {
      "name" : "TwistedDoodles",
      "screen_name" : "twisteddoodles",
      "indices" : [ 21, 36 ],
      "id_str" : "487584390",
      "id" : 487584390
    }, {
      "name" : "Dr Becca, PhD \uD83D\uDC18",
      "screen_name" : "doc_becca",
      "indices" : [ 113, 123 ],
      "id_str" : "30233007",
      "id" : 30233007
    }, {
      "name" : "NatC",
      "screen_name" : "SciTriGrrl",
      "indices" : [ 124, 135 ],
      "id_str" : "59603956",
      "id" : 59603956
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/571031036227928064\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/uCTyJGTo26",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y1sdiXAAEtfM_.jpg",
      "id_str" : "571031028216823809",
      "id" : 571031028216823809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y1sdiXAAEtfM_.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 449
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 676
      } ],
      "display_url" : "pic.twitter.com\/uCTyJGTo26"
    } ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590854017682640897",
  "text" : "RT @BabyAttachMode: \u201C@twisteddoodles: Scientific research is like owning a cat! #science http:\/\/t.co\/uCTyJGTo26\u201D @doc_becca @SciTriGrrl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TwistedDoodles",
        "screen_name" : "twisteddoodles",
        "indices" : [ 1, 16 ],
        "id_str" : "487584390",
        "id" : 487584390
      }, {
        "name" : "Dr Becca, PhD \uD83D\uDC18",
        "screen_name" : "doc_becca",
        "indices" : [ 93, 103 ],
        "id_str" : "30233007",
        "id" : 30233007
      }, {
        "name" : "NatC",
        "screen_name" : "SciTriGrrl",
        "indices" : [ 104, 115 ],
        "id_str" : "59603956",
        "id" : 59603956
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/twisteddoodles\/status\/571031036227928064\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/uCTyJGTo26",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y1sdiXAAEtfM_.jpg",
        "id_str" : "571031028216823809",
        "id" : 571031028216823809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y1sdiXAAEtfM_.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 449
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 676
        } ],
        "display_url" : "pic.twitter.com\/uCTyJGTo26"
      } ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 60, 68 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "571221176569208833",
    "geo" : { },
    "id_str" : "571224669157789697",
    "in_reply_to_user_id" : 487584390,
    "text" : "\u201C@twisteddoodles: Scientific research is like owning a cat! #science http:\/\/t.co\/uCTyJGTo26\u201D @doc_becca @SciTriGrrl",
    "id" : 571224669157789697,
    "in_reply_to_status_id" : 571221176569208833,
    "created_at" : "2015-02-27 08:25:48 +0000",
    "in_reply_to_screen_name" : "twisteddoodles",
    "in_reply_to_user_id_str" : "487584390",
    "user" : {
      "name" : "InBabyAttachMode",
      "screen_name" : "BabyAttachMode",
      "protected" : false,
      "id_str" : "482500305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1802231446\/BabyAttachMode_normal.jpg",
      "id" : 482500305,
      "verified" : false
    }
  },
  "id" : 590854017682640897,
  "created_at" : "2015-04-22 12:25:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/AbvNegyWFP",
      "expanded_url" : "http:\/\/www.vitavonni.de\/blog\/201503\/2015031201-the-sad-state-of-sysadmin-in-the-age-of-containers.html",
      "display_url" : "vitavonni.de\/blog\/201503\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590843111431139328",
  "text" : "RT @PhilippBayer: My old sysadmin prof would probably sign this: \"The sad state of sysadmin in the age of containers\" http:\/\/t.co\/AbvNegyWFP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/AbvNegyWFP",
        "expanded_url" : "http:\/\/www.vitavonni.de\/blog\/201503\/2015031201-the-sad-state-of-sysadmin-in-the-age-of-containers.html",
        "display_url" : "vitavonni.de\/blog\/201503\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590839206672465920",
    "text" : "My old sysadmin prof would probably sign this: \"The sad state of sysadmin in the age of containers\" http:\/\/t.co\/AbvNegyWFP",
    "id" : 590839206672465920,
    "created_at" : "2015-04-22 11:26:58 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 590843111431139328,
  "created_at" : "2015-04-22 11:42:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590787927283736577",
  "geo" : { },
  "id_str" : "590789146865700864",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Uh, danke! Mal meinen Kalender checken ob da schon was anliegt.",
  "id" : 590789146865700864,
  "in_reply_to_status_id" : 590787927283736577,
  "created_at" : "2015-04-22 08:08:03 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/LOxXnOVKbI",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/the-woman-who-ate-chernobyl-s-apples",
      "display_url" : "atlasobscura.com\/articles\/the-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590780196153856000",
  "text" : "The Woman Who Ate Chernobyl\u2019s Apples http:\/\/t.co\/LOxXnOVKbI",
  "id" : 590780196153856000,
  "created_at" : "2015-04-22 07:32:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/4MKFK4pq25",
      "expanded_url" : "https:\/\/twitter.com\/PeterSinger\/status\/590670843593809920",
      "display_url" : "twitter.com\/PeterSinger\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590768818089254912",
  "text" : "RT @madprime: Scientists noting \"we're better now\" maybe miss a point\n(that is, an apology for injustice)\nhttps:\/\/t.co\/4MKFK4pq25",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/4MKFK4pq25",
        "expanded_url" : "https:\/\/twitter.com\/PeterSinger\/status\/590670843593809920",
        "display_url" : "twitter.com\/PeterSinger\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590682279690838018",
    "text" : "Scientists noting \"we're better now\" maybe miss a point\n(that is, an apology for injustice)\nhttps:\/\/t.co\/4MKFK4pq25",
    "id" : 590682279690838018,
    "created_at" : "2015-04-22 01:03:24 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 590768818089254912,
  "created_at" : "2015-04-22 06:47:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Worth",
      "screen_name" : "jonworth",
      "indices" : [ 89, 98 ],
      "id_str" : "17442320",
      "id" : 17442320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/an9TIjWGfL",
      "expanded_url" : "https:\/\/jonworth.eu\/slave-to-the-freelance-life\/",
      "display_url" : "jonworth.eu\/slave-to-the-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590762800160575488",
  "text" : "\u00ABI am a slave to this freelance life, and I do not know how to escape my enslavement.\u00BB \u2013 @jonworth https:\/\/t.co\/an9TIjWGfL",
  "id" : 590762800160575488,
  "created_at" : "2015-04-22 06:23:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PacBio",
      "screen_name" : "PacBio",
      "indices" : [ 27, 34 ],
      "id_str" : "39694489",
      "id" : 39694489
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/QlJw0vPyxZ",
      "expanded_url" : "https:\/\/github.com\/PacificBiosciences\/FALCON\/blob\/master\/doc\/falcon_manual.md",
      "display_url" : "github.com\/PacificBioscie\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409351537201, 8.753290438130428 ]
  },
  "id_str" : "590634847720333313",
  "text" : "Ran my first assembly with @PacBio &amp; FALCON. Deeply impressed by the results so far. https:\/\/t.co\/QlJw0vPyxZ",
  "id" : 590634847720333313,
  "created_at" : "2015-04-21 21:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/gZtt1RaYrA",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/perfect-security\/",
      "display_url" : "99percentinvisible.org\/episode\/perfec\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409351469862, 8.753290404234644 ]
  },
  "id_str" : "590626923434401795",
  "text" : "99PI with a great episode on security &amp; the history of lock(-picking) http:\/\/t.co\/gZtt1RaYrA",
  "id" : 590626923434401795,
  "created_at" : "2015-04-21 21:23:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/EwwcZS2hRt",
      "expanded_url" : "http:\/\/www.newyorker.com\/magazine\/2015\/02\/16\/last-trial",
      "display_url" : "newyorker.com\/magazine\/2015\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409353294593, 8.753291322742612 ]
  },
  "id_str" : "590625881640566784",
  "text" : "The Last Trial http:\/\/t.co\/EwwcZS2hRt",
  "id" : 590625881640566784,
  "created_at" : "2015-04-21 21:19:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590611301140983808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409355076745, 8.753292219818109 ]
  },
  "id_str" : "590611848560582656",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich go for it. A new life awaits you in the off-world colonies! A chance to begin again in a golden land of opportunity and adventure!",
  "id" : 590611848560582656,
  "in_reply_to_status_id" : 590611301140983808,
  "created_at" : "2015-04-21 20:23:32 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/yCkWTCTctt",
      "expanded_url" : "http:\/\/boingboing.net\/2015\/04\/21\/liberland-is-a-new-micronation.html",
      "display_url" : "boingboing.net\/2015\/04\/21\/lib\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409350318441, 8.753289824647064 ]
  },
  "id_str" : "590610080694931456",
  "text" : "A new micronation: Liberland http:\/\/t.co\/yCkWTCTctt",
  "id" : 590610080694931456,
  "created_at" : "2015-04-21 20:16:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/JNra3bu7cD",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/32wr0v\/serious_scientists_of_reddit_what_is_the_worst\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409349684666, 8.753289505626503 ]
  },
  "id_str" : "590608158512570368",
  "text" : "\u00ABwhat is the worst thing that has happened in your lab?\u00BB Ever wondered why people go into bioinformatics? http:\/\/t.co\/JNra3bu7cD",
  "id" : 590608158512570368,
  "created_at" : "2015-04-21 20:08:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/VVE35eI0je",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/indiana-jones-HZPN3pggjKhz2",
      "display_url" : "giphy.com\/gifs\/indiana-j\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409363325385, 8.75329217699692 ]
  },
  "id_str" : "590598639191465984",
  "text" : "Searching for invoices on my desk in order to get travel reimbursement. https:\/\/t.co\/VVE35eI0je",
  "id" : 590598639191465984,
  "created_at" : "2015-04-21 19:31:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Krennmair",
      "screen_name" : "der_ak",
      "indices" : [ 0, 7 ],
      "id_str" : "26962623",
      "id" : 26962623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590576390619197443",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409346232325, 8.753293169602788 ]
  },
  "id_str" : "590581921765285888",
  "in_reply_to_user_id" : 26962623,
  "text" : "@der_ak barely ;)",
  "id" : 590581921765285888,
  "in_reply_to_status_id" : 590576390619197443,
  "created_at" : "2015-04-21 18:24:37 +0000",
  "in_reply_to_screen_name" : "der_ak",
  "in_reply_to_user_id_str" : "26962623",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/590574901473452032\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/hq5db93oDi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDIkvc8W0AEvrOX.png",
      "id_str" : "590574898780753921",
      "id" : 590574898780753921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDIkvc8W0AEvrOX.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/hq5db93oDi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409222855945, 8.75329714552405 ]
  },
  "id_str" : "590574901473452032",
  "text" : "Near Miss http:\/\/t.co\/hq5db93oDi",
  "id" : 590574901473452032,
  "created_at" : "2015-04-21 17:56:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Jack A Gilbert",
      "screen_name" : "gilbertjacka",
      "indices" : [ 14, 27 ],
      "id_str" : "223529798",
      "id" : 223529798
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 28, 38 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590529439110402049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17959642002977, 8.612424137422254 ]
  },
  "id_str" : "590540944728072193",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @gilbertjacka @edyong209 @RobRDunn +1 for The Price of Altruism &amp; Thinking, Fast &amp; Slow.",
  "id" : 590540944728072193,
  "in_reply_to_status_id" : 590529439110402049,
  "created_at" : "2015-04-21 15:41:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.18041529799996, 8.60342708075571 ]
  },
  "id_str" : "590540605681442816",
  "text" : "First day back in the office and I already crashed parts of the grid engine. \uD83D\uDE48",
  "id" : 590540605681442816,
  "created_at" : "2015-04-21 15:40:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/bznVpLDKIZ",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/11a5sjSAspbVi8\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/11a5sjSA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590501343934226432",
  "text" : "installing packages all day http:\/\/t.co\/bznVpLDKIZ",
  "id" : 590501343934226432,
  "created_at" : "2015-04-21 13:04:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/uUtYnZ2s9T",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/LGIETjnhvhsFq\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/LGIETjnh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590486294913884161",
  "geo" : { },
  "id_str" : "590488807256023040",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke http:\/\/t.co\/uUtYnZ2s9T",
  "id" : 590488807256023040,
  "in_reply_to_status_id" : 590486294913884161,
  "created_at" : "2015-04-21 12:14:37 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 12, 19 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 20, 28 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "HRZ Goethe-Uni",
      "screen_name" : "goetheuni_hrz",
      "indices" : [ 29, 43 ],
      "id_str" : "1485059635",
      "id" : 1485059635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590487315555819520",
  "geo" : { },
  "id_str" : "590488501315051522",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke @Seb666 @branleb @goetheuni_hrz Das war nun auch mehr konservativ gerechnet f\u00FCr die Devices die ich mit mir rumtrage. ;)",
  "id" : 590488501315051522,
  "in_reply_to_status_id" : 590487315555819520,
  "created_at" : "2015-04-21 12:13:24 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "HRZ Goethe-Uni",
      "screen_name" : "goetheuni_hrz",
      "indices" : [ 9, 23 ],
      "id_str" : "1485059635",
      "id" : 1485059635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590484984516874240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17799973052197, 8.614582808589542 ]
  },
  "id_str" : "590486935669514240",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb @goetheuni_hrz die Mailserver sind \u00FCbrigens auch damit \u00FCberfordert wenn man 3 IMAP-f\u00E4hige Endger\u00E4te hat\u2026",
  "id" : 590486935669514240,
  "in_reply_to_status_id" : 590484984516874240,
  "created_at" : "2015-04-21 12:07:10 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 116, 129 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590470703020933120",
  "geo" : { },
  "id_str" : "590471648026976256",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a but you are right: we could\/should(?) point out that re-ID gets easier the more explicit your phenotypes are. @PhilippBayer",
  "id" : 590471648026976256,
  "in_reply_to_status_id" : 590470703020933120,
  "created_at" : "2015-04-21 11:06:25 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590470703020933120",
  "geo" : { },
  "id_str" : "590471267104468992",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a we are already telling people that their data is not anonymous when they register. :p",
  "id" : 590471267104468992,
  "in_reply_to_status_id" : 590470703020933120,
  "created_at" : "2015-04-21 11:04:55 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590467576192458752",
  "geo" : { },
  "id_str" : "590468171330674688",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a the results for supervised are impressive, but require you to have a well defined prior.",
  "id" : 590468171330674688,
  "in_reply_to_status_id" : 590467576192458752,
  "created_at" : "2015-04-21 10:52:37 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590467576192458752",
  "geo" : { },
  "id_str" : "590468071489462272",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a jk. but my point is: the unsupervised approach is better than chance but performs not too good as n of genotypes grows.",
  "id" : 590468071489462272,
  "in_reply_to_status_id" : 590467576192458752,
  "created_at" : "2015-04-21 10:52:13 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590459935294672897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226855740898, 8.627535095446396 ]
  },
  "id_str" : "590462687445921792",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a that would be cool, finally perfect matches for dating ;)",
  "id" : 590462687445921792,
  "in_reply_to_status_id" : 590459935294672897,
  "created_at" : "2015-04-21 10:30:49 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590452539461672960",
  "geo" : { },
  "id_str" : "590452947923927040",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a yes it would, though the unsupervised version is much weaker. Guess i\u2019m a \u00B1unsurprised cause if GWAS are 2 work at all has to be 2way",
  "id" : 590452947923927040,
  "in_reply_to_status_id" : 590452539461672960,
  "created_at" : "2015-04-21 09:52:07 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590450861031161856",
  "geo" : { },
  "id_str" : "590451224148836352",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a right, but you need a set of phenotypes for it to work.",
  "id" : 590451224148836352,
  "in_reply_to_status_id" : 590450861031161856,
  "created_at" : "2015-04-21 09:45:16 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590449206034305024",
  "geo" : { },
  "id_str" : "590450084657115136",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a doing the association from \u201Cset of data points I know\u201D to \u201Cdata points of so far unknown origin\u201D.",
  "id" : 590450084657115136,
  "in_reply_to_status_id" : 590449206034305024,
  "created_at" : "2015-04-21 09:40:44 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/L1c5U9Ojly",
      "expanded_url" : "http:\/\/wp.me\/p1PnkE-dP",
      "display_url" : "wp.me\/p1PnkE-dP"
    } ]
  },
  "geo" : { },
  "id_str" : "590448825476784128",
  "text" : "RT @BioMickWatson: On publishing software http:\/\/t.co\/L1c5U9Ojly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/L1c5U9Ojly",
        "expanded_url" : "http:\/\/wp.me\/p1PnkE-dP",
        "display_url" : "wp.me\/p1PnkE-dP"
      } ]
    },
    "geo" : { },
    "id_str" : "590447804155310080",
    "text" : "On publishing software http:\/\/t.co\/L1c5U9Ojly",
    "id" : 590447804155310080,
    "created_at" : "2015-04-21 09:31:41 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 590448825476784128,
  "created_at" : "2015-04-21 09:35:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590444501489029121",
  "geo" : { },
  "id_str" : "590444891332857856",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a sorry for being confusing, my point is: the re-ID is performed by the public phenotype data, not through genotype data.",
  "id" : 590444891332857856,
  "in_reply_to_status_id" : 590444501489029121,
  "created_at" : "2015-04-21 09:20:06 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590425349772673024",
  "geo" : { },
  "id_str" : "590430991027720192",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a so far I haven\u2019t seen a single case where the main vector of attack was the genetic data and not the meta data associated with it.",
  "id" : 590430991027720192,
  "in_reply_to_status_id" : 590425349772673024,
  "created_at" : "2015-04-21 08:24:52 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590402157062553600",
  "geo" : { },
  "id_str" : "590406797195870208",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @wilbanks do you happen to have a link to it? :-)",
  "id" : 590406797195870208,
  "in_reply_to_status_id" : 590402157062553600,
  "created_at" : "2015-04-21 06:48:44 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 3, 10 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "Mike T\u24D0ylor",
      "screen_name" : "MikeTaylor",
      "indices" : [ 25, 36 ],
      "id_str" : "278930750",
      "id" : 278930750
    }, {
      "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
      "screen_name" : "Villavelius",
      "indices" : [ 66, 78 ],
      "id_str" : "72249574",
      "id" : 72249574
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/McDawg\/status\/590188299769217024\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HdXfeuyaVP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDFIW6WgAAVW77.png",
      "id_str" : "590188298565484544",
      "id" : 590188298565484544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDFIW6WgAAVW77.png",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 759
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 759
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 759
      } ],
      "display_url" : "pic.twitter.com\/HdXfeuyaVP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/hAgKCKbibd",
      "expanded_url" : "http:\/\/svpow.com\/2015\/04\/20\/live-blog-the-future-of-scholarly-scientific-communication\/#comment-117282",
      "display_url" : "svpow.com\/2015\/04\/20\/liv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590403180057522176",
  "text" : "RT @McDawg: Snippet from @MikeTaylor's fab live-blog of today f\/t @Villavelius http:\/\/t.co\/hAgKCKbibd http:\/\/t.co\/HdXfeuyaVP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike T\u24D0ylor",
        "screen_name" : "MikeTaylor",
        "indices" : [ 13, 24 ],
        "id_str" : "278930750",
        "id" : 278930750
      }, {
        "name" : "Velterop \u24D0 \uD83C\uDDEA\uD83C\uDDFA\uD83D\uDD36",
        "screen_name" : "Villavelius",
        "indices" : [ 54, 66 ],
        "id_str" : "72249574",
        "id" : 72249574
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/McDawg\/status\/590188299769217024\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/HdXfeuyaVP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDFIW6WgAAVW77.png",
        "id_str" : "590188298565484544",
        "id" : 590188298565484544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDFIW6WgAAVW77.png",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 759
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 759
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 759
        } ],
        "display_url" : "pic.twitter.com\/HdXfeuyaVP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/hAgKCKbibd",
        "expanded_url" : "http:\/\/svpow.com\/2015\/04\/20\/live-blog-the-future-of-scholarly-scientific-communication\/#comment-117282",
        "display_url" : "svpow.com\/2015\/04\/20\/liv\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590188299769217024",
    "text" : "Snippet from @MikeTaylor's fab live-blog of today f\/t @Villavelius http:\/\/t.co\/hAgKCKbibd http:\/\/t.co\/HdXfeuyaVP",
    "id" : 590188299769217024,
    "created_at" : "2015-04-20 16:20:30 +0000",
    "user" : {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "protected" : false,
      "id_str" : "12432262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708707066026860544\/LnGGYNw1_normal.jpg",
      "id" : 12432262,
      "verified" : false
    }
  },
  "id" : 590403180057522176,
  "created_at" : "2015-04-21 06:34:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 107, 116 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/tTcLbnBCn1",
      "expanded_url" : "http:\/\/infoscience.epfl.ch\/record\/207479\/files\/Humbert2015PETS.pdf",
      "display_url" : "infoscience.epfl.ch\/record\/207479\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590400967507599360",
  "text" : "\u2018de-anonymizing genomic databases using phenotypic traits\u2019 again it\u2019s the metadata http:\/\/t.co\/tTcLbnBCn1 \/@wilbanks",
  "id" : 590400967507599360,
  "created_at" : "2015-04-21 06:25:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 20, 33 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/N013itpGqj",
      "expanded_url" : "http:\/\/bit.ly\/1D8uwZC",
      "display_url" : "bit.ly\/1D8uwZC"
    } ]
  },
  "geo" : { },
  "id_str" : "590263394525024256",
  "text" : "RT @openAwakening: .@MaliciaRogue --&gt; \"Our otherness: imagining Balkan &amp; mid-Eastern identities\"|openDemocracy http:\/\/t.co\/N013itpGqj #Bulg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rayna",
        "screen_name" : "MaliciaRogue",
        "indices" : [ 1, 14 ],
        "id_str" : "189118361",
        "id" : 189118361
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bulgaria",
        "indices" : [ 122, 131 ]
      }, {
        "text" : "France",
        "indices" : [ 132, 139 ]
      }, {
        "text" : "Egypt",
        "indices" : [ 140, 146 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/N013itpGqj",
        "expanded_url" : "http:\/\/bit.ly\/1D8uwZC",
        "display_url" : "bit.ly\/1D8uwZC"
      } ]
    },
    "geo" : { },
    "id_str" : "590245784274280448",
    "text" : ".@MaliciaRogue --&gt; \"Our otherness: imagining Balkan &amp; mid-Eastern identities\"|openDemocracy http:\/\/t.co\/N013itpGqj #Bulgaria #France #Egypt",
    "id" : 590245784274280448,
    "created_at" : "2015-04-20 20:08:55 +0000",
    "user" : {
      "name" : "openDemocracy NAWA",
      "screen_name" : "NAWAoD",
      "protected" : false,
      "id_str" : "427692286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867305403855630336\/khsZ4mWH_normal.jpg",
      "id" : 427692286,
      "verified" : false
    }
  },
  "id" : 590263394525024256,
  "created_at" : "2015-04-20 21:18:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/FIvJxBbIxs",
      "expanded_url" : "https:\/\/twitter.com\/stx\/status\/585429718004068352",
      "display_url" : "twitter.com\/stx\/status\/585\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590249433654136832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409315582202, 8.753294286392244 ]
  },
  "id_str" : "590249744171171841",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan you\u2019re not alone. https:\/\/t.co\/FIvJxBbIxs",
  "id" : 590249744171171841,
  "in_reply_to_status_id" : 590249433654136832,
  "created_at" : "2015-04-20 20:24:39 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Nick Shockey",
      "screen_name" : "nshockey",
      "indices" : [ 12, 21 ],
      "id_str" : "16728620",
      "id" : 16728620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/AaU8cPGws7",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/Q445d1oeGJU0E\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/Q445d1oe\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590242616387698689",
  "geo" : { },
  "id_str" : "590243696190291968",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @nshockey fitting to what started this whole thing http:\/\/t.co\/AaU8cPGws7",
  "id" : 590243696190291968,
  "in_reply_to_status_id" : 590242616387698689,
  "created_at" : "2015-04-20 20:00:38 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 12, 21 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/akCHz07OCA",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/1FRxA3GDUN0AM\/200.gif",
      "display_url" : "media3.giphy.com\/media\/1FRxA3GD\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590241638397702146",
  "geo" : { },
  "id_str" : "590241949854105601",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @wilbanks wheeeee! https:\/\/t.co\/akCHz07OCA",
  "id" : 590241949854105601,
  "in_reply_to_status_id" : 590241638397702146,
  "created_at" : "2015-04-20 19:53:41 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590236649726050306",
  "geo" : { },
  "id_str" : "590237592291045376",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo hope we go for that again rather soonish.",
  "id" : 590237592291045376,
  "in_reply_to_status_id" : 590236649726050306,
  "created_at" : "2015-04-20 19:36:22 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 10, 21 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/FDhNeHujUD",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/ighbPR8343lL2\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/ighbPR83\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590233914142240768",
  "geo" : { },
  "id_str" : "590235770146938881",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @bella_velo http:\/\/t.co\/FDhNeHujUD",
  "id" : 590235770146938881,
  "in_reply_to_status_id" : 590233914142240768,
  "created_at" : "2015-04-20 19:29:08 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 8, 19 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590217429411831809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409368384464, 8.753291616644688 ]
  },
  "id_str" : "590217837752487936",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg @bella_velo to the national library, as it deserves to be kept for future generations. Or so I hope.",
  "id" : 590217837752487936,
  "in_reply_to_status_id" : 590217429411831809,
  "created_at" : "2015-04-20 18:17:52 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 8, 19 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590215465718444032",
  "geo" : { },
  "id_str" : "590216175612735488",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg @bella_velo i tried to get a perfect loop but couldn\u2019t fine-tune it enough.",
  "id" : 590216175612735488,
  "in_reply_to_status_id" : 590215465718444032,
  "created_at" : "2015-04-20 18:11:16 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 8, 19 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/W3DvYHjxZx",
      "expanded_url" : "http:\/\/share.gifyoutube.com\/vqDxd2.gif",
      "display_url" : "share.gifyoutube.com\/vqDxd2.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "590213472035725312",
  "geo" : { },
  "id_str" : "590214901131522049",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg @bella_velo wasn\u2019t me http:\/\/t.co\/W3DvYHjxZx",
  "id" : 590214901131522049,
  "in_reply_to_status_id" : 590213472035725312,
  "created_at" : "2015-04-20 18:06:12 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    }, {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 8, 19 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590213022255357953",
  "geo" : { },
  "id_str" : "590213627061395456",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg @bella_velo it made me love him even more.",
  "id" : 590213627061395456,
  "in_reply_to_status_id" : 590213022255357953,
  "created_at" : "2015-04-20 18:01:08 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/kIDTb3xWhO",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=7wDsDlf5m1A",
      "display_url" : "youtube.com\/watch?v=7wDsDl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "590211952997183492",
  "geo" : { },
  "id_str" : "590212678699896832",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo that\u2019s only partially true! https:\/\/t.co\/kIDTb3xWhO",
  "id" : 590212678699896832,
  "in_reply_to_status_id" : 590211952997183492,
  "created_at" : "2015-04-20 17:57:22 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 58, 67 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590211502000513024",
  "geo" : { },
  "id_str" : "590211719156338688",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo because virtually everything can benefit from @wilbanks doing it?",
  "id" : 590211719156338688,
  "in_reply_to_status_id" : 590211502000513024,
  "created_at" : "2015-04-20 17:53:34 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 100, 111 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qLUU1iowoM",
      "expanded_url" : "http:\/\/thegoodfight.fm\/episodes\/38-how-the-kid-with-two-moms-saved-the-boy-scouts",
      "display_url" : "thegoodfight.fm\/episodes\/38-ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590211387391086593",
  "text" : "\u00ABHow the kid with two moms saved the Boy Scouts\u00BB Great! Finally came around to listen to it. Thanks @bella_velo! http:\/\/t.co\/qLUU1iowoM",
  "id" : 590211387391086593,
  "created_at" : "2015-04-20 17:52:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 3, 16 ],
      "id_str" : "189118361",
      "id" : 189118361
    }, {
      "name" : "Open MENA",
      "screen_name" : "OpenMENA",
      "indices" : [ 46, 55 ],
      "id_str" : "2228477208",
      "id" : 2228477208
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenData",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "OpenGov",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "OpenScience",
      "indices" : [ 104, 116 ]
    }, {
      "text" : "OpenEducation",
      "indices" : [ 117, 131 ]
    }, {
      "text" : "MENA",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/9xV1FcwQoQ",
      "expanded_url" : "http:\/\/openmena.net\/en\/",
      "display_url" : "openmena.net\/en\/"
    } ]
  },
  "geo" : { },
  "id_str" : "590186473556705280",
  "text" : "RT @MaliciaRogue: Ladies &amp; gents, welcome @OpenMENA v2 :) http:\/\/t.co\/9xV1FcwQoQ #OpenData #OpenGov #OpenScience #OpenEducation #MENA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Open MENA",
        "screen_name" : "OpenMENA",
        "indices" : [ 28, 37 ],
        "id_str" : "2228477208",
        "id" : 2228477208
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenData",
        "indices" : [ 67, 76 ]
      }, {
        "text" : "OpenGov",
        "indices" : [ 77, 85 ]
      }, {
        "text" : "OpenScience",
        "indices" : [ 86, 98 ]
      }, {
        "text" : "OpenEducation",
        "indices" : [ 99, 113 ]
      }, {
        "text" : "MENA",
        "indices" : [ 114, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/9xV1FcwQoQ",
        "expanded_url" : "http:\/\/openmena.net\/en\/",
        "display_url" : "openmena.net\/en\/"
      } ]
    },
    "geo" : { },
    "id_str" : "590184493643882497",
    "text" : "Ladies &amp; gents, welcome @OpenMENA v2 :) http:\/\/t.co\/9xV1FcwQoQ #OpenData #OpenGov #OpenScience #OpenEducation #MENA",
    "id" : 590184493643882497,
    "created_at" : "2015-04-20 16:05:23 +0000",
    "user" : {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "protected" : false,
      "id_str" : "189118361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837584473843712000\/2Av32bxZ_normal.jpg",
      "id" : 189118361,
      "verified" : true
    }
  },
  "id" : 590186473556705280,
  "created_at" : "2015-04-20 16:13:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590183393415012352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10768562998512, 8.774894740744623 ]
  },
  "id_str" : "590183609371336705",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch your own personal hedge fund?",
  "id" : 590183609371336705,
  "in_reply_to_status_id" : 590183393415012352,
  "created_at" : "2015-04-20 16:01:52 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590176252096606208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10767884153727, 8.774613871246936 ]
  },
  "id_str" : "590183087142805506",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch helga?",
  "id" : 590183087142805506,
  "in_reply_to_status_id" : 590176252096606208,
  "created_at" : "2015-04-20 15:59:47 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Urban",
      "screen_name" : "pikarl",
      "indices" : [ 0, 7 ],
      "id_str" : "12514272",
      "id" : 12514272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "590102694972502017",
  "geo" : { },
  "id_str" : "590128837171793920",
  "in_reply_to_user_id" : 12514272,
  "text" : "@pikarl willkommen in meiner Heimat. :D",
  "id" : 590128837171793920,
  "in_reply_to_status_id" : 590102694972502017,
  "created_at" : "2015-04-20 12:24:13 +0000",
  "in_reply_to_screen_name" : "pikarl",
  "in_reply_to_user_id_str" : "12514272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Terry McGlynn",
      "screen_name" : "hormiga",
      "indices" : [ 100, 108 ],
      "id_str" : "10328012",
      "id" : 10328012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/K0ToLqKCeW",
      "expanded_url" : "http:\/\/smallpondscience.com\/2015\/04\/15\/portable-peer-review-and-the-manuscript-cascade\/",
      "display_url" : "smallpondscience.com\/2015\/04\/15\/por\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590117769288507393",
  "text" : "RT @ctitusbrown: On portable peer review &amp; the manuscript cascade: re-reviewing same papers. By @hormiga: http:\/\/t.co\/K0ToLqKCeW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Terry McGlynn",
        "screen_name" : "hormiga",
        "indices" : [ 83, 91 ],
        "id_str" : "10328012",
        "id" : 10328012
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/K0ToLqKCeW",
        "expanded_url" : "http:\/\/smallpondscience.com\/2015\/04\/15\/portable-peer-review-and-the-manuscript-cascade\/",
        "display_url" : "smallpondscience.com\/2015\/04\/15\/por\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "589766709038448640",
    "text" : "On portable peer review &amp; the manuscript cascade: re-reviewing same papers. By @hormiga: http:\/\/t.co\/K0ToLqKCeW",
    "id" : 589766709038448640,
    "created_at" : "2015-04-19 12:25:15 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 590117769288507393,
  "created_at" : "2015-04-20 11:40:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590108906480861184",
  "text" : "Thanks to @PhilippBayer for fixing the previously broken core-functionally of openSNP, namely the download of all data as a single ZIP file.",
  "id" : 590108906480861184,
  "created_at" : "2015-04-20 11:05:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11409309528288, 8.753288175012374 ]
  },
  "id_str" : "589837829129314304",
  "text" : "23,000 km later this spring edition of joint conference circus\/vacation comes to an end.",
  "id" : 589837829129314304,
  "created_at" : "2015-04-19 17:07:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 10, 19 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Sage Bionetworks",
      "screen_name" : "Sagebio",
      "indices" : [ 38, 46 ],
      "id_str" : "130579391",
      "id" : 130579391
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 49, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.83437666063272, 2.309529314083496 ]
  },
  "id_str" : "589722883682873344",
  "text" : "Thanks to @wilbanks &amp; everyone at @Sagebio \/ #sageparisassembly. A truly inspiring conference, I hate leaving Paris even more now.",
  "id" : 589722883682873344,
  "created_at" : "2015-04-19 09:31:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/589703141173698560\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/lhAzXlobh4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC8L4eXW4AA6eNN.jpg",
      "id_str" : "589703141060435968",
      "id" : 589703141060435968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC8L4eXW4AA6eNN.jpg",
      "sizes" : [ {
        "h" : 982,
        "resize" : "fit",
        "w" : 982
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 982,
        "resize" : "fit",
        "w" : 982
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 982,
        "resize" : "fit",
        "w" : 982
      } ],
      "display_url" : "pic.twitter.com\/lhAzXlobh4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.83445, 2.309434 ]
  },
  "id_str" : "589703141173698560",
  "text" : "\u00ABWhen exactly did you become Canadian?!\u00BB \u2014 \u00ABI guess at some point last night, but I don't know why!\u00BB http:\/\/t.co\/lhAzXlobh4",
  "id" : 589703141173698560,
  "created_at" : "2015-04-19 08:12:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/pB8DkrX2zd",
      "expanded_url" : "https:\/\/instagram.com\/p\/1n8FQ6BwmZ\/",
      "display_url" : "instagram.com\/p\/1n8FQ6BwmZ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.853611111, 2.349166667 ]
  },
  "id_str" : "589475051923234816",
  "text" : "And another standard sight. @ Notre Dame de Paris https:\/\/t.co\/pB8DkrX2zd",
  "id" : 589475051923234816,
  "created_at" : "2015-04-18 17:06:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie Tenenbaum",
      "screen_name" : "jessiet1023",
      "indices" : [ 3, 15 ],
      "id_str" : "215420646",
      "id" : 215420646
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 58, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ArexuFNmYI",
      "expanded_url" : "http:\/\/www.ejnet.org\/ej\/jemez.pdf",
      "display_url" : "ejnet.org\/ej\/jemez.pdf"
    } ]
  },
  "geo" : { },
  "id_str" : "589395564783132672",
  "text" : "RT @jessiet1023: Jemez principles  http:\/\/t.co\/ArexuFNmYI #sageparisassembly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sageparisassembly",
        "indices" : [ 41, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/ArexuFNmYI",
        "expanded_url" : "http:\/\/www.ejnet.org\/ej\/jemez.pdf",
        "display_url" : "ejnet.org\/ej\/jemez.pdf"
      } ]
    },
    "geo" : { },
    "id_str" : "589394643273588736",
    "text" : "Jemez principles  http:\/\/t.co\/ArexuFNmYI #sageparisassembly",
    "id" : 589394643273588736,
    "created_at" : "2015-04-18 11:46:48 +0000",
    "user" : {
      "name" : "Jessie Tenenbaum",
      "screen_name" : "jessiet1023",
      "protected" : false,
      "id_str" : "215420646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658815462914981888\/lJbOxIVU_normal.jpg",
      "id" : 215420646,
      "verified" : false
    }
  },
  "id" : 589395564783132672,
  "created_at" : "2015-04-18 11:50:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 104, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84082993727998, 2.311169614307389 ]
  },
  "id_str" : "589392573166440448",
  "text" : "predictive, preventive, precision and personal medicine needs to be participatory to become affordable. #sageparisassembly",
  "id" : 589392573166440448,
  "created_at" : "2015-04-18 11:38:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ZIRJPLyJ1h",
      "expanded_url" : "http:\/\/www.nature.com\/nclimate\/journal\/v1\/n2\/images\/nclimate1093-f1.jpg",
      "display_url" : "nature.com\/nclimate\/journ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84054884760602, 2.31071064390269 ]
  },
  "id_str" : "589360900680900608",
  "text" : "When looking at rise of retractions you should also look at the rise of scientific publishing: http:\/\/t.co\/ZIRJPLyJ1h #sageparisassembly",
  "id" : 589360900680900608,
  "created_at" : "2015-04-18 09:32:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 49, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/7pe9Hjs7H0",
      "expanded_url" : "http:\/\/nanocrafter.org",
      "display_url" : "nanocrafter.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84068048847619, 2.31085865958135 ]
  },
  "id_str" : "589359472558137344",
  "text" : "Playing synthetic biology http:\/\/t.co\/7pe9Hjs7H0 #sageparisassembly",
  "id" : 589359472558137344,
  "created_at" : "2015-04-18 09:27:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 8, 17 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/JhssvEXivN",
      "expanded_url" : "https:\/\/giphy.com\/gifs\/cat-day-office-5r5J4JD9miis",
      "display_url" : "giphy.com\/gifs\/cat-day-o\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84060927853229, 2.310810474437624 ]
  },
  "id_str" : "589329101565124608",
  "text" : "I think @wilbanks is doing a good job of using GIFs to make literacy somewhat unnecessary. https:\/\/t.co\/JhssvEXivN #sageparisassembly",
  "id" : 589329101565124608,
  "created_at" : "2015-04-18 07:26:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8406411466796, 2.31079876690466 ]
  },
  "id_str" : "589328460780326912",
  "text" : "\u00ABIf you had to give up one access, the access to Internet or literacy, what would you choose?\u00BB Long,hard contemplation at #sageparisassembly",
  "id" : 589328460780326912,
  "created_at" : "2015-04-18 07:23:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/RrtkGoVwgD",
      "expanded_url" : "http:\/\/www.belfasttelegraph.co.uk\/technology\/robot-that-bought-mdma-passport-and-baseball-cap-released-by-authorities-31150495.html",
      "display_url" : "belfasttelegraph.co.uk\/technology\/rob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "589327808373088256",
  "text" : "RT @arikia: Headline. Of. The. Year. http:\/\/t.co\/RrtkGoVwgD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/RrtkGoVwgD",
        "expanded_url" : "http:\/\/www.belfasttelegraph.co.uk\/technology\/robot-that-bought-mdma-passport-and-baseball-cap-released-by-authorities-31150495.html",
        "display_url" : "belfasttelegraph.co.uk\/technology\/rob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "589325969812389888",
    "text" : "Headline. Of. The. Year. http:\/\/t.co\/RrtkGoVwgD",
    "id" : 589325969812389888,
    "created_at" : "2015-04-18 07:13:55 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 589327808373088256,
  "created_at" : "2015-04-18 07:21:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/589145759829913601\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/SmcogX5AkJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC0Q8nNW8AAvnK5.jpg",
      "id_str" : "589145759758610432",
      "id" : 589145759758610432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC0Q8nNW8AAvnK5.jpg",
      "sizes" : [ {
        "h" : 1215,
        "resize" : "fit",
        "w" : 911
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1215,
        "resize" : "fit",
        "w" : 911
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/SmcogX5AkJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.85206, 2.348256 ]
  },
  "id_str" : "589145759829913601",
  "text" : "\u00ABImagine, 100 years ago we wouldn't have been here.\u00BB \u2014 \u00ABA 100 years ago my people tried really hard being here.\u00BB http:\/\/t.co\/SmcogX5AkJ",
  "id" : 589145759829913601,
  "created_at" : "2015-04-17 19:17:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SageParisAsembly",
      "indices" : [ 65, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/XZDA0djeX2",
      "expanded_url" : "http:\/\/www.quaibranly.fr\/en\/musee\/areas\/the-ramp.html",
      "display_url" : "quaibranly.fr\/en\/musee\/areas\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.85628136592683, 2.353377813289607 ]
  },
  "id_str" : "589106511005220864",
  "text" : "Some idea for the word cloud\/mapping team:http:\/\/t.co\/XZDA0djeX2 #SageParisAsembly",
  "id" : 589106511005220864,
  "created_at" : "2015-04-17 16:41:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589101263494766592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.85619758557312, 2.353361461086988 ]
  },
  "id_str" : "589101874734825473",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke yes, absolutely. :)",
  "id" : 589101874734825473,
  "in_reply_to_status_id" : 589101263494766592,
  "created_at" : "2015-04-17 16:23:26 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "589099972215365632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.85626220599062, 2.353369231538113 ]
  },
  "id_str" : "589100211705896960",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke I definitely have seen worse conference venues ;)",
  "id" : 589100211705896960,
  "in_reply_to_status_id" : 589099972215365632,
  "created_at" : "2015-04-17 16:16:50 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 4, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/F791L5ip1y",
      "expanded_url" : "https:\/\/instagram.com\/p\/1lRaswBwhr\/",
      "display_url" : "instagram.com\/p\/1lRaswBwhr\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.857031621, 2.355724111 ]
  },
  "id_str" : "589099756930072576",
  "text" : "omg #sageparisassembly @ H\u00F4tel de Ville https:\/\/t.co\/F791L5ip1y",
  "id" : 589099756930072576,
  "created_at" : "2015-04-17 16:15:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Keating",
      "screen_name" : "stevenkeating",
      "indices" : [ 86, 100 ],
      "id_str" : "19216179",
      "id" : 19216179
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84076442555629, 2.31094418791049 ]
  },
  "id_str" : "589005271030194176",
  "text" : "Having people rather read his genome than his Twitter, as the former is less damning, @stevenkeating. I know that! #sageparisassembly",
  "id" : 589005271030194176,
  "created_at" : "2015-04-17 09:59:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 38, 49 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SageParisAssembly",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588999358475042816",
  "text" : "On getting your data from your MD: RT @bella_velo: \u2018Wearing a smile as a patient seemed to be my most effective tool\u2019 #SageParisAssembly",
  "id" : 588999358475042816,
  "created_at" : "2015-04-17 09:36:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jez Cope",
      "screen_name" : "jezcope",
      "indices" : [ 3, 11 ],
      "id_str" : "20049102",
      "id" : 20049102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Rh7XoK73Dz",
      "expanded_url" : "http:\/\/bit.ly\/1DL3MlB",
      "display_url" : "bit.ly\/1DL3MlB"
    } ]
  },
  "geo" : { },
  "id_str" : "588998772627243008",
  "text" : "RT @jezcope: You don't always have to be doing everything the best way possible: Good Enough Practices http:\/\/t.co\/Rh7XoK73Dz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Rh7XoK73Dz",
        "expanded_url" : "http:\/\/bit.ly\/1DL3MlB",
        "display_url" : "bit.ly\/1DL3MlB"
      } ]
    },
    "geo" : { },
    "id_str" : "588971912220520448",
    "text" : "You don't always have to be doing everything the best way possible: Good Enough Practices http:\/\/t.co\/Rh7XoK73Dz",
    "id" : 588971912220520448,
    "created_at" : "2015-04-17 07:47:01 +0000",
    "user" : {
      "name" : "Jez Cope",
      "screen_name" : "jezcope",
      "protected" : false,
      "id_str" : "20049102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925686963633520640\/1ya9dh_4_normal.jpg",
      "id" : 20049102,
      "verified" : false
    }
  },
  "id" : 588998772627243008,
  "created_at" : "2015-04-17 09:33:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie Tenenbaum",
      "screen_name" : "jessiet1023",
      "indices" : [ 3, 15 ],
      "id_str" : "215420646",
      "id" : 215420646
    }, {
      "name" : "Nilofer Merchant",
      "screen_name" : "nilofer",
      "indices" : [ 34, 42 ],
      "id_str" : "12354252",
      "id" : 12354252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "onlyness",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "sageparisassembly",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588994910386262016",
  "text" : "RT @jessiet1023: Great slide from @nilofer summing up shifts we're seeing in modern world  #onlyness #sageparisassembly http:\/\/t.co\/tSPJB0G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nilofer Merchant",
        "screen_name" : "nilofer",
        "indices" : [ 17, 25 ],
        "id_str" : "12354252",
        "id" : 12354252
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jessiet1023\/status\/588994778907443200\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/tSPJB0G5Au",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCyHn9tWIAELs92.jpg",
        "id_str" : "588994771928096769",
        "id" : 588994771928096769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCyHn9tWIAELs92.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tSPJB0G5Au"
      } ],
      "hashtags" : [ {
        "text" : "onlyness",
        "indices" : [ 74, 83 ]
      }, {
        "text" : "sageparisassembly",
        "indices" : [ 84, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588994778907443200",
    "text" : "Great slide from @nilofer summing up shifts we're seeing in modern world  #onlyness #sageparisassembly http:\/\/t.co\/tSPJB0G5Au",
    "id" : 588994778907443200,
    "created_at" : "2015-04-17 09:17:52 +0000",
    "user" : {
      "name" : "Jessie Tenenbaum",
      "screen_name" : "jessiet1023",
      "protected" : false,
      "id_str" : "215420646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658815462914981888\/lJbOxIVU_normal.jpg",
      "id" : 215420646,
      "verified" : false
    }
  },
  "id" : 588994910386262016,
  "created_at" : "2015-04-17 09:18:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Change.org",
      "screen_name" : "Change",
      "indices" : [ 26, 33 ],
      "id_str" : "15947602",
      "id" : 15947602
    }, {
      "name" : "The Good Fight",
      "screen_name" : "TeamGoodFight",
      "indices" : [ 41, 55 ],
      "id_str" : "1964920110",
      "id" : 1964920110
    }, {
      "name" : "Nilofer Merchant",
      "screen_name" : "nilofer",
      "indices" : [ 82, 90 ],
      "id_str" : "12354252",
      "id" : 12354252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ES4Bs1Cojh",
      "expanded_url" : "http:\/\/thegoodfight.fm\/episodes\/38-how-the-kid-with-two-moms-saved-the-boy-scouts",
      "display_url" : "thegoodfight.fm\/episodes\/38-ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588993607467663360",
  "text" : "RT @bella_velo: Check out @Change &amp;  @TeamGoodFight for an awesome podcast on @nilofer story of the Eagle Scout http:\/\/t.co\/ES4Bs1Cojh #Sag\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Change.org",
        "screen_name" : "Change",
        "indices" : [ 10, 17 ],
        "id_str" : "15947602",
        "id" : 15947602
      }, {
        "name" : "The Good Fight",
        "screen_name" : "TeamGoodFight",
        "indices" : [ 25, 39 ],
        "id_str" : "1964920110",
        "id" : 1964920110
      }, {
        "name" : "Nilofer Merchant",
        "screen_name" : "nilofer",
        "indices" : [ 66, 74 ],
        "id_str" : "12354252",
        "id" : 12354252
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SageParisAssembly",
        "indices" : [ 123, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/ES4Bs1Cojh",
        "expanded_url" : "http:\/\/thegoodfight.fm\/episodes\/38-how-the-kid-with-two-moms-saved-the-boy-scouts",
        "display_url" : "thegoodfight.fm\/episodes\/38-ho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588991914550112256",
    "text" : "Check out @Change &amp;  @TeamGoodFight for an awesome podcast on @nilofer story of the Eagle Scout http:\/\/t.co\/ES4Bs1Cojh #SageParisAssembly",
    "id" : 588991914550112256,
    "created_at" : "2015-04-17 09:06:30 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 588993607467663360,
  "created_at" : "2015-04-17 09:13:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sageparisassembly",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84088751689357, 2.310969385287768 ]
  },
  "id_str" : "588992958071975937",
  "text" : "Boy Scouts of America now allow for gay Eagle Scouts. But being openly gay still bans you from being a group leader.  #sageparisassembly",
  "id" : 588992958071975937,
  "created_at" : "2015-04-17 09:10:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Nilofer Merchant",
      "screen_name" : "nilofer",
      "indices" : [ 83, 91 ],
      "id_str" : "12354252",
      "id" : 12354252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SageParisAssembly",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588990609886748672",
  "text" : "RT @bella_velo: 'We don't get one through the pipeline but we change the pipeline' @nilofer #SageParisAssembly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nilofer Merchant",
        "screen_name" : "nilofer",
        "indices" : [ 67, 75 ],
        "id_str" : "12354252",
        "id" : 12354252
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SageParisAssembly",
        "indices" : [ 76, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588990204524027904",
    "text" : "'We don't get one through the pipeline but we change the pipeline' @nilofer #SageParisAssembly",
    "id" : 588990204524027904,
    "created_at" : "2015-04-17 08:59:42 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 588990609886748672,
  "created_at" : "2015-04-17 09:01:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessie Tenenbaum",
      "screen_name" : "jessiet1023",
      "indices" : [ 0, 12 ],
      "id_str" : "215420646",
      "id" : 215420646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/YLwcfrqgHY",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/The_Doctor%27s_Dilemma_(play)",
      "display_url" : "en.m.wikipedia.org\/wiki\/The_Docto\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "588724429204652032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84213772126196, 2.31074317916128 ]
  },
  "id_str" : "588725030441373696",
  "in_reply_to_user_id" : 215420646,
  "text" : "@jessiet1023 quote from http:\/\/t.co\/YLwcfrqgHY",
  "id" : 588725030441373696,
  "in_reply_to_status_id" : 588724429204652032,
  "created_at" : "2015-04-16 15:25:59 +0000",
  "in_reply_to_screen_name" : "jessiet1023",
  "in_reply_to_user_id_str" : "215420646",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 12, 21 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 22, 31 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588720308904992768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84076554820074, 2.310943432803854 ]
  },
  "id_str" : "588720507404550144",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo @podehaye @wilbanks esp. when doing it part-time, having to justify spending spare time for it.",
  "id" : 588720507404550144,
  "in_reply_to_status_id" : 588720308904992768,
  "created_at" : "2015-04-16 15:08:01 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588717928524177408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84238012600126, 2.310521525468745 ]
  },
  "id_str" : "588719084784726016",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo i was not aware that you didn\u2019t know tbh :D",
  "id" : 588719084784726016,
  "in_reply_to_status_id" : 588717928524177408,
  "created_at" : "2015-04-16 15:02:22 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588717559639367680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.84076495749814, 2.310943620206301 ]
  },
  "id_str" : "588717764233265152",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo so close: BastiAn ;-)",
  "id" : 588717764233265152,
  "in_reply_to_status_id" : 588717559639367680,
  "created_at" : "2015-04-16 14:57:07 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 64, 73 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SageParisAssembly",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588716905319510018",
  "text" : "RT @bella_velo: -&gt; + 'relationships protect us from burnout' @wilbanks (who's also great at emergency kitten gifs) #SageParisAssembly http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Wilbanks",
        "screen_name" : "wilbanks",
        "indices" : [ 48, 57 ],
        "id_str" : "14245811",
        "id" : 14245811
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bella_velo\/status\/588715958451208192\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/lYOwwoMdkm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCuKCfdW4AAsZ8S.jpg",
        "id_str" : "588715951710986240",
        "id" : 588715951710986240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCuKCfdW4AAsZ8S.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/lYOwwoMdkm"
      } ],
      "hashtags" : [ {
        "text" : "SageParisAssembly",
        "indices" : [ 102, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588715958451208192",
    "text" : "-&gt; + 'relationships protect us from burnout' @wilbanks (who's also great at emergency kitten gifs) #SageParisAssembly http:\/\/t.co\/lYOwwoMdkm",
    "id" : 588715958451208192,
    "created_at" : "2015-04-16 14:49:56 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 588716905319510018,
  "created_at" : "2015-04-16 14:53:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mus\u00E9e du quai Branly \u2013 Jacques Chirac",
      "screen_name" : "quaibranly",
      "indices" : [ 32, 43 ],
      "id_str" : "188411214",
      "id" : 188411214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tatoueurs",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.83564150242435, 2.310225434046583 ]
  },
  "id_str" : "588409111601111040",
  "text" : "Also: the #Tatoueurs exhibit at @quaibranly is worth a visit.",
  "id" : 588409111601111040,
  "created_at" : "2015-04-15 18:30:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/xhaNP4Y3eU",
      "expanded_url" : "https:\/\/instagram.com\/p\/1gWP2NBwgD\/",
      "display_url" : "instagram.com\/p\/1gWP2NBwgD\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.859025596, 2.298117144 ]
  },
  "id_str" : "588406690799812610",
  "text" : "Tourism \u2714\uFE0F @ Tour Eiffel https:\/\/t.co\/xhaNP4Y3eU",
  "id" : 588406690799812610,
  "created_at" : "2015-04-15 18:21:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.83446764320517, 2.309543465394044 ]
  },
  "id_str" : "588331237795885057",
  "text" : "\u00ABThank god, our host is French after all. This means: no paper plates this time!\u00BB",
  "id" : 588331237795885057,
  "created_at" : "2015-04-15 13:21:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588210826361835521",
  "text" : "Before going to sleep I read apocalyptical fiction. Then I dream of airport security. How fitting.",
  "id" : 588210826361835521,
  "created_at" : "2015-04-15 05:22:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 101, 117 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Z74ZPVG5jJ",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002112",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587950850598907904",
  "text" : "RT @PhilippBayer: \"Natural Selection Constrains Neutral Diversity across A Wide Range of Species\" cc @gedankenstuecke http:\/\/t.co\/Z74ZPVG5jJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 83, 99 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/Z74ZPVG5jJ",
        "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371\/journal.pbio.1002112",
        "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "587603549393186816",
    "text" : "\"Natural Selection Constrains Neutral Diversity across A Wide Range of Species\" cc @gedankenstuecke http:\/\/t.co\/Z74ZPVG5jJ",
    "id" : 587603549393186816,
    "created_at" : "2015-04-13 13:09:37 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 587950850598907904,
  "created_at" : "2015-04-14 12:09:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587908589790068736",
  "text" : "Debugging Status: How did this ever work?!",
  "id" : 587908589790068736,
  "created_at" : "2015-04-14 09:21:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 11, 22 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587696352559267840",
  "geo" : { },
  "id_str" : "587696700950708224",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro @openSNPorg @DellHealth Oh, isn\u2019t it right now?",
  "id" : 587696700950708224,
  "in_reply_to_status_id" : 587696352559267840,
  "created_at" : "2015-04-13 19:19:47 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11458074802829, 8.753191643087733 ]
  },
  "id_str" : "587685316267499520",
  "text" : "Finally a first draft for this talk. \\o\/",
  "id" : 587685316267499520,
  "created_at" : "2015-04-13 18:34:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/u44CKvoD65",
      "expanded_url" : "http:\/\/bioinformatics.oxfordjournals.org\/content\/early\/2014\/10\/20\/bioinformatics.btu690.full.pdf",
      "display_url" : "bioinformatics.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587637982166962176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Maybe we should try to get eUcoMaps into Bioinformatics :D http:\/\/t.co\/u44CKvoD65",
  "id" : 587637982166962176,
  "created_at" : "2015-04-13 15:26:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587603549393186816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17794717752736, 8.62397926443255 ]
  },
  "id_str" : "587606491663880192",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, has been on my reading list for a couple of days now :D",
  "id" : 587606491663880192,
  "in_reply_to_status_id" : 587603549393186816,
  "created_at" : "2015-04-13 13:21:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587578289910378496",
  "geo" : { },
  "id_str" : "587583289805930496",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke ack.",
  "id" : 587583289805930496,
  "in_reply_to_status_id" : 587578289910378496,
  "created_at" : "2015-04-13 11:49:07 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/587580201212706816\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/5OBRt9tYnJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCeBE72W4AEcLCZ.jpg",
      "id_str" : "587580198180282369",
      "id" : 587580198180282369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCeBE72W4AEcLCZ.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/5OBRt9tYnJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16703796386697, 8.631820678711433 ]
  },
  "id_str" : "587580201212706816",
  "text" : "I wonder whether the people pronounce it \u2018creepy\u2019 or \u2018crappy\u2019 crepes. http:\/\/t.co\/5OBRt9tYnJ",
  "id" : 587580201212706816,
  "created_at" : "2015-04-13 11:36:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587563460671725568",
  "geo" : { },
  "id_str" : "587573965717164033",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke that is what\u2019s perceived as the easy way out.",
  "id" : 587573965717164033,
  "in_reply_to_status_id" : 587563460671725568,
  "created_at" : "2015-04-13 11:12:04 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587546539888926722",
  "geo" : { },
  "id_str" : "587547512124395520",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke well, history shows how well people get along with each other\u2026",
  "id" : 587547512124395520,
  "in_reply_to_status_id" : 587546539888926722,
  "created_at" : "2015-04-13 09:26:57 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/xYBXSfmvdE",
      "expanded_url" : "http:\/\/www.theguardian.com\/lifeandstyle\/2015\/apr\/12\/tell-fiancee-i-am-bisexual-and-had-sex-with-her-dad-mariella-frostrup?CMP=fb_gu",
      "display_url" : "theguardian.com\/lifeandstyle\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587545801271996416",
  "text" : "\u00ABShould I tell my fianc\u00E9e that I\u2019m bisexual and had sex with her dad?\u00BB http:\/\/t.co\/xYBXSfmvdE",
  "id" : 587545801271996416,
  "created_at" : "2015-04-13 09:20:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/F9FS7hHG8V",
      "expanded_url" : "https:\/\/www.google.de\/maps\/place\/53%C2%B040'39.2%22N+11%C2%B034'12.5%22E\/@53.677552,11.57014,17z\/data=!3m1!4b1!4m2!3m1!1s0x0:0x0",
      "display_url" : "google.de\/maps\/place\/53%\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "587350211573522432",
  "geo" : { },
  "id_str" : "587351111201325058",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 https:\/\/t.co\/F9FS7hHG8V",
  "id" : 587351111201325058,
  "in_reply_to_status_id" : 587350211573522432,
  "created_at" : "2015-04-12 20:26:32 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/KSMBY89hig",
      "expanded_url" : "https:\/\/instagram.com\/p\/1YzmjOhwlf\/",
      "display_url" : "instagram.com\/p\/1YzmjOhwlf\/"
    } ]
  },
  "geo" : { },
  "id_str" : "587345344599461889",
  "text" : "water under the bridge https:\/\/t.co\/KSMBY89hig",
  "id" : 587345344599461889,
  "created_at" : "2015-04-12 20:03:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62347623215648, 7.199601307406888 ]
  },
  "id_str" : "586993786145873922",
  "text" : "\u00AB\u26EA\uD83C\uDFB6\u2614?\u00BB \u2014 \u00ABM\u00FCnster on Sundays\u2019\u00BB",
  "id" : 586993786145873922,
  "created_at" : "2015-04-11 20:46:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Th81zeuBeO",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/culture\/the-high-tech-resurgence-of-new-age-beliefs\/",
      "display_url" : "aeon.co\/magazine\/cultu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586944594539110400",
  "text" : "\u00ABhow technology nurtured New Age ideas in a world supposedly stripped of its magic\u00BB http:\/\/t.co\/Th81zeuBeO",
  "id" : 586944594539110400,
  "created_at" : "2015-04-11 17:31:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/cO0j0MfbJB",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/04\/09\/magazine\/if-we-cant-prevent-wrongful-convictions-can-we-at-least-pay-for-them.html?_r=0",
      "display_url" : "nytimes.com\/2015\/04\/09\/mag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586942546141667329",
  "text" : "If We Can\u2019t Prevent Wrongful Convictions, Can We at Least Pay for Them? http:\/\/t.co\/cO0j0MfbJB",
  "id" : 586942546141667329,
  "created_at" : "2015-04-11 17:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/1qIGquVZ8U",
      "expanded_url" : "https:\/\/instagram.com\/p\/1V6N-WBwo-\/",
      "display_url" : "instagram.com\/p\/1V6N-WBwo-\/"
    } ]
  },
  "geo" : { },
  "id_str" : "586937679209562115",
  "text" : "soccer practice #latergram https:\/\/t.co\/1qIGquVZ8U",
  "id" : 586937679209562115,
  "created_at" : "2015-04-11 17:03:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/kTyZHEhX4c",
      "expanded_url" : "https:\/\/instagram.com\/p\/1VOs0ihwi0\/",
      "display_url" : "instagram.com\/p\/1VOs0ihwi0\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.41346133, 7.25434116 ]
  },
  "id_str" : "586841982158430208",
  "text" : "Wehrhaft @ Kemnader Stausee am Wehr https:\/\/t.co\/kTyZHEhX4c",
  "id" : 586841982158430208,
  "created_at" : "2015-04-11 10:43:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/mYeRg4BtUs",
      "expanded_url" : "https:\/\/instagram.com\/p\/1Tf9tqhwtA\/",
      "display_url" : "instagram.com\/p\/1Tf9tqhwtA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "586598471202836481",
  "text" : "North Sea for a change https:\/\/t.co\/mYeRg4BtUs",
  "id" : 586598471202836481,
  "created_at" : "2015-04-10 18:35:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u262E MenschZwoNull \u262E",
      "screen_name" : "MenschZwoNull",
      "indices" : [ 0, 14 ],
      "id_str" : "36943219",
      "id" : 36943219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586510546582798336",
  "geo" : { },
  "id_str" : "586511705259319296",
  "in_reply_to_user_id" : 36943219,
  "text" : "@MenschZwoNull wird zwar NL, aber nicht daf\u00FCr ;)",
  "id" : 586511705259319296,
  "in_reply_to_status_id" : 586510546582798336,
  "created_at" : "2015-04-10 12:51:02 +0000",
  "in_reply_to_screen_name" : "MenschZwoNull",
  "in_reply_to_user_id_str" : "36943219",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u262E MenschZwoNull \u262E",
      "screen_name" : "MenschZwoNull",
      "indices" : [ 0, 14 ],
      "id_str" : "36943219",
      "id" : 36943219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586510176762650626",
  "geo" : { },
  "id_str" : "586510341703655424",
  "in_reply_to_user_id" : 36943219,
  "text" : "@MenschZwoNull w\u00FCrde ich glatt machen, aber ich bin nur auf der Durchreise. Nachher geht\u2019s weiter ans Meer. :)",
  "id" : 586510341703655424,
  "in_reply_to_status_id" : 586510176762650626,
  "created_at" : "2015-04-10 12:45:36 +0000",
  "in_reply_to_screen_name" : "MenschZwoNull",
  "in_reply_to_user_id_str" : "36943219",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586509147081945088",
  "geo" : { },
  "id_str" : "586509756094926848",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 okay, normales rebooting mach ich zu selten um es da schon bemerkt zu haben.",
  "id" : 586509756094926848,
  "in_reply_to_status_id" : 586509147081945088,
  "created_at" : "2015-04-10 12:43:17 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586506465675993088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62317096707419, 7.200077730185179 ]
  },
  "id_str" : "586508182954074112",
  "in_reply_to_user_id" : 2365333778,
  "text" : "@Seb666 bei jedem OS-Update wieder.",
  "id" : 586508182954074112,
  "in_reply_to_status_id" : 586506465675993088,
  "created_at" : "2015-04-10 12:37:02 +0000",
  "in_reply_to_screen_name" : "Seb666",
  "in_reply_to_user_id_str" : "2365333778",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586501202499756032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61192181451509, 7.197794042044719 ]
  },
  "id_str" : "586502596648665088",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv \u2018most deviant genotype\u2019-awards?",
  "id" : 586502596648665088,
  "in_reply_to_status_id" : 586501202499756032,
  "created_at" : "2015-04-10 12:14:50 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thesoundofpeople",
      "indices" : [ 64, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586499750356250624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61275031331559, 7.195176996542556 ]
  },
  "id_str" : "586501861689184257",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv I won\u2019t, as at the same time I\u2019m touring the globe using #thesoundofpeople as exhibit A for creative data use. ;-)",
  "id" : 586501861689184257,
  "in_reply_to_status_id" : 586499750356250624,
  "created_at" : "2015-04-10 12:11:55 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586497826236063744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61954885379387, 7.200369295067136 ]
  },
  "id_str" : "586499049081176065",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv sweet. It is somewhat strange that you are touring with me :D",
  "id" : 586499049081176065,
  "in_reply_to_status_id" : 586497826236063744,
  "created_at" : "2015-04-10 12:00:44 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586493397965393923",
  "geo" : { },
  "id_str" : "586495504441339904",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv gratz :)",
  "id" : 586495504441339904,
  "in_reply_to_status_id" : 586493397965393923,
  "created_at" : "2015-04-10 11:46:39 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/jkp7H0a0A6",
      "expanded_url" : "http:\/\/www.theallium.com\/biology\/people-who-dont-care-about-gwas-a-threat-to-civilization\/",
      "display_url" : "theallium.com\/biology\/people\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586493865349222400",
  "text" : "RT @genetics_blog: Obama: \u2018People Who Don\u2019t Care About GWAS \u201CA Threat To Civilization\u201D\u2018 http:\/\/t.co\/jkp7H0a0A6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/jkp7H0a0A6",
        "expanded_url" : "http:\/\/www.theallium.com\/biology\/people-who-dont-care-about-gwas-a-threat-to-civilization\/",
        "display_url" : "theallium.com\/biology\/people\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "586490236705705985",
    "text" : "Obama: \u2018People Who Don\u2019t Care About GWAS \u201CA Threat To Civilization\u201D\u2018 http:\/\/t.co\/jkp7H0a0A6",
    "id" : 586490236705705985,
    "created_at" : "2015-04-10 11:25:43 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 586493865349222400,
  "created_at" : "2015-04-10 11:40:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586298526595997696",
  "geo" : { },
  "id_str" : "586298836198543363",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam great, I like how it\u2019s not only doing a bogus acronym but also using an already taken name.",
  "id" : 586298836198543363,
  "in_reply_to_status_id" : 586298526595997696,
  "created_at" : "2015-04-09 22:45:10 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/ZvEqVV82Gn",
      "expanded_url" : "http:\/\/theconversation.com\/unlike-a-rolling-stone-is-science-really-better-than-journalism-at-self-correction-39849",
      "display_url" : "theconversation.com\/unlike-a-rolli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586289324515323904",
  "text" : "Unlike a Rolling Stone: is science really better than journalism at\u00A0self-correction? http:\/\/t.co\/ZvEqVV82Gn",
  "id" : 586289324515323904,
  "created_at" : "2015-04-09 22:07:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/bpSDfoYY5n",
      "expanded_url" : "http:\/\/jasonya.com\/wp\/another-word-about-balance\/",
      "display_url" : "jasonya.com\/wp\/another-wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586287904248504320",
  "text" : "Balance &amp; Binary Classifiers http:\/\/t.co\/bpSDfoYY5n",
  "id" : 586287904248504320,
  "created_at" : "2015-04-09 22:01:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 8, 17 ],
      "id_str" : "17061155",
      "id" : 17061155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/DHtLafLiKw",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1004120",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586285185865506818",
  "text" : "One for @kbradnam: DIseAse MOdule Detection http:\/\/t.co\/DHtLafLiKw",
  "id" : 586285185865506818,
  "created_at" : "2015-04-09 21:50:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586232737192927232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62348807179201, 7.199690774072582 ]
  },
  "id_str" : "586233070375858176",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer what I would love to add: reply to email to answer messages.",
  "id" : 586233070375858176,
  "in_reply_to_status_id" : 586232737192927232,
  "created_at" : "2015-04-09 18:23:50 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586232737192927232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62358436497367, 7.199771183060832 ]
  },
  "id_str" : "586232960594157568",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer sounds like a good idea. Our system is indeed somewhat old fashioned and overly complex.",
  "id" : 586232960594157568,
  "in_reply_to_status_id" : 586232737192927232,
  "created_at" : "2015-04-09 18:23:24 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586231266619613184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.62361910994289, 7.199825544487545 ]
  },
  "id_str" : "586231453362610176",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yes, that sounds like a good idea as well. :D",
  "id" : 586231453362610176,
  "in_reply_to_status_id" : 586231266619613184,
  "created_at" : "2015-04-09 18:17:24 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586215702517964801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6235708906454, 7.19978159373176 ]
  },
  "id_str" : "586229934596685825",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I guess you could, if you make it through the submission process. ;-)",
  "id" : 586229934596685825,
  "in_reply_to_status_id" : 586215702517964801,
  "created_at" : "2015-04-09 18:11:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "586187091077365760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6237460073871, 7.199581213298306 ]
  },
  "id_str" : "586213192642256896",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch should work on that some time. Maybe at the hack day in Zurich ;-)",
  "id" : 586213192642256896,
  "in_reply_to_status_id" : 586187091077365760,
  "created_at" : "2015-04-09 17:04:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586180400554344450",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I just renewed our privacy policy thingy for another year. :-)",
  "id" : 586180400554344450,
  "created_at" : "2015-04-09 14:54:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Nje4gjWaIX",
      "expanded_url" : "http:\/\/m.thisamericanlife.org\/radio-archives\/episode\/553\/stuck-in-the-middle-2015?act=3#act-3",
      "display_url" : "m.thisamericanlife.org\/radio-archives\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.588051, 7.22295 ]
  },
  "id_str" : "586172789591244801",
  "text" : "Apparently I'm not alone in my crying-behavior when mid-air http:\/\/t.co\/Nje4gjWaIX",
  "id" : 586172789591244801,
  "created_at" : "2015-04-09 14:24:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.39366750279368, 13.03447417392389 ]
  },
  "id_str" : "585877054203289600",
  "text" : "\u00ABUsually when traveling I feel bad for having to leave soon. In Berlin I think: when\u2019s the next train to Offenbach leaving.\u00BB",
  "id" : 585877054203289600,
  "created_at" : "2015-04-08 18:49:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 16, 21 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Lucy Patterson",
      "screen_name" : "lu_cyP",
      "indices" : [ 22, 29 ],
      "id_str" : "99586343",
      "id" : 99586343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585797191253516288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.39373379046062, 13.0345365366915 ]
  },
  "id_str" : "585876570226720770",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall @li5a @lu_cyP ah, thanks :-)",
  "id" : 585876570226720770,
  "in_reply_to_status_id" : 585797191253516288,
  "created_at" : "2015-04-08 18:47:14 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585745560071761921",
  "text" : "Phew, condensing 4 years of openSNP into an appealing 3-minute talk is even harder than expected.",
  "id" : 585745560071761921,
  "created_at" : "2015-04-08 10:06:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 5, 17 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 18, 31 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.51480838500563, 13.38164139446062 ]
  },
  "id_str" : "585522188889026562",
  "text" : "@stx @helgerausch @PhilippBayer haha, thanks. The U.K. SNP always confused me!",
  "id" : 585522188889026562,
  "created_at" : "2015-04-07 19:19:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 37, 50 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585521769949372418",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.51483548640529, 13.38159051726269 ]
  },
  "id_str" : "585521934080856064",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch thx &lt;3 a missing gem?@PhilippBayer",
  "id" : 585521934080856064,
  "in_reply_to_status_id" : 585521769949372418,
  "created_at" : "2015-04-07 19:18:02 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585515822023577603",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50775608475998, 13.37290406998288 ]
  },
  "id_str" : "585515954018394113",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch uh oh!",
  "id" : 585515954018394113,
  "in_reply_to_status_id" : 585515822023577603,
  "created_at" : "2015-04-07 18:54:16 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585482197001469954",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.50067888908117, 13.37111560443947 ]
  },
  "id_str" : "585512342936498176",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer uh, could one of you restart the web server? :D",
  "id" : 585512342936498176,
  "in_reply_to_status_id" : 585482197001469954,
  "created_at" : "2015-04-07 18:39:55 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585438988892241921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.54093583013563, 13.36900986803812 ]
  },
  "id_str" : "585439915317551105",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer i did get one now. For the denisova data.",
  "id" : 585439915317551105,
  "in_reply_to_status_id" : 585438988892241921,
  "created_at" : "2015-04-07 13:52:07 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/kYHLTlvvWP",
      "expanded_url" : "http:\/\/wp.me\/p1PnkE-2g",
      "display_url" : "wp.me\/p1PnkE-2g"
    } ]
  },
  "geo" : { },
  "id_str" : "585415829015113729",
  "text" : "RT @BioMickWatson: I stand by this: GATK - why it matters http:\/\/t.co\/kYHLTlvvWP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/kYHLTlvvWP",
        "expanded_url" : "http:\/\/wp.me\/p1PnkE-2g",
        "display_url" : "wp.me\/p1PnkE-2g"
      } ]
    },
    "geo" : { },
    "id_str" : "585361424249159680",
    "text" : "I stand by this: GATK - why it matters http:\/\/t.co\/kYHLTlvvWP",
    "id" : 585361424249159680,
    "created_at" : "2015-04-07 08:40:13 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 585415829015113729,
  "created_at" : "2015-04-07 12:16:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585413068118740992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.49576090839923, 13.36580098607891 ]
  },
  "id_str" : "585415026023989248",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch that would have been too funny :D",
  "id" : 585415026023989248,
  "in_reply_to_status_id" : 585413068118740992,
  "created_at" : "2015-04-07 12:13:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 24, 29 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585397375562285056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.49389713191977, 13.35633818008496 ]
  },
  "id_str" : "585398149814079488",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @gedankenabfall @li5a super, Ich freu mich drauf. :-)",
  "id" : 585398149814079488,
  "in_reply_to_status_id" : 585397375562285056,
  "created_at" : "2015-04-07 11:06:09 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 16, 21 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 22, 29 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585380240467329024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.49536301903272, 13.36604426237533 ]
  },
  "id_str" : "585386108764160000",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall @li5a @ewyler cool, ich bring auch noch eine weitere Wissenschaftlerin mit. :)",
  "id" : 585386108764160000,
  "in_reply_to_status_id" : 585380240467329024,
  "created_at" : "2015-04-07 10:18:18 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585379397026320384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.4955250835535, 13.36466180161886 ]
  },
  "id_str" : "585385931521269760",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a klar, ich kann dich einsammeln. Dann brauch ich nur noch die Koordinaten daf\u00FCr irgendwann. :-)",
  "id" : 585385931521269760,
  "in_reply_to_status_id" : 585379397026320384,
  "created_at" : "2015-04-07 10:17:36 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 0, 11 ],
      "id_str" : "6745972",
      "id" : 6745972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585375476199333888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.65880557555974, 13.24348102030693 ]
  },
  "id_str" : "585376781223464960",
  "in_reply_to_user_id" : 6745972,
  "text" : "@bella_velo yes, finally meeting each other! Looking forward to it!",
  "id" : 585376781223464960,
  "in_reply_to_status_id" : 585375476199333888,
  "created_at" : "2015-04-07 09:41:15 +0000",
  "in_reply_to_screen_name" : "bella_velo",
  "in_reply_to_user_id_str" : "6745972",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 6, 13 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 37, 52 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585371908843110401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.66669885358149, 13.23973128746554 ]
  },
  "id_str" : "585376645302845441",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @ewyler ok, super. Was ist mit @gedankenabfall? :)",
  "id" : 585376645302845441,
  "in_reply_to_status_id" : 585371908843110401,
  "created_at" : "2015-04-07 09:40:42 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 24, 29 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585357438817304576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.35987605796031, 11.75774632944529 ]
  },
  "id_str" : "585359404725379072",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @gedankenabfall @li5a f\u00FCr mich ok. Bin aber auch Kfz-mobil und muss um 1400 Kreuzberg sein.",
  "id" : 585359404725379072,
  "in_reply_to_status_id" : 585357438817304576,
  "created_at" : "2015-04-07 08:32:12 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 24, 29 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 53, 58 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585353516841046016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.53368188024427, 11.45043154970507 ]
  },
  "id_str" : "585353816767344640",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @gedankenabfall @li5a ich bin mobil und kann @li5a mitnehmen wenn sie will.",
  "id" : 585353816767344640,
  "in_reply_to_status_id" : 585353516841046016,
  "created_at" : "2015-04-07 08:09:59 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 3, 13 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweet",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585340102500610048",
  "text" : "RT @yokofakun: [delicious] Markov Chain Monte Carlo Without all the Bullshit #tweet: I have a little secret: I don\u2019t like the... http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tweet",
        "indices" : [ 62, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/UjZxafV4yC",
        "expanded_url" : "http:\/\/bit.ly\/1C9mbEs",
        "display_url" : "bit.ly\/1C9mbEs"
      } ]
    },
    "geo" : { },
    "id_str" : "585339348175855616",
    "text" : "[delicious] Markov Chain Monte Carlo Without all the Bullshit #tweet: I have a little secret: I don\u2019t like the... http:\/\/t.co\/UjZxafV4yC",
    "id" : 585339348175855616,
    "created_at" : "2015-04-07 07:12:30 +0000",
    "user" : {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "protected" : false,
      "id_str" : "7431072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667105051664609280\/jQ6Ile6W_normal.jpg",
      "id" : 7431072,
      "verified" : false
    }
  },
  "id" : 585340102500610048,
  "created_at" : "2015-04-07 07:15:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585195633851633665",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61645049264673, 11.43440276791952 ]
  },
  "id_str" : "585197532508250113",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer didn\u2019t test it. Was still on the move today.",
  "id" : 585197532508250113,
  "in_reply_to_status_id" : 585195633851633665,
  "created_at" : "2015-04-06 21:48:58 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/Bd9LsFAIqz",
      "expanded_url" : "https:\/\/instagram.com\/p\/1JZYCWBwmL\/",
      "display_url" : "instagram.com\/p\/1JZYCWBwmL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "585176607452725248",
  "text" : "Formica rufa https:\/\/t.co\/Bd9LsFAIqz",
  "id" : 585176607452725248,
  "created_at" : "2015-04-06 20:25:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/9bnIs48yzn",
      "expanded_url" : "http:\/\/www.molecularecologist.com\/2015\/04\/a-transcriptomic-approach-for-reduced-representation-in-population-genomics\/",
      "display_url" : "molecularecologist.com\/2015\/04\/a-tran\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "585168332065808384",
  "text" : "A transcriptomic approach for reduced representation in population genomics http:\/\/t.co\/9bnIs48yzn",
  "id" : 585168332065808384,
  "created_at" : "2015-04-06 19:52:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 111, 116 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585167972043468802",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler @gedankenabfall komme morgen Nachmittag irgendwann in B an. Im Laufe des Tages ein Treffen mit mir und @li5a?",
  "id" : 585167972043468802,
  "created_at" : "2015-04-06 19:51:31 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585162814878326784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61628783871756, 11.4335114602106 ]
  },
  "id_str" : "585162980293222400",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy a Fitbit Charge HR.",
  "id" : 585162980293222400,
  "in_reply_to_status_id" : 585162814878326784,
  "created_at" : "2015-04-06 19:31:40 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/585161791140933633\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/OcLQLhC2IN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB7pixUXIAAK4yk.jpg",
      "id_str" : "585161785168306176",
      "id" : 585161785168306176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB7pixUXIAAK4yk.jpg",
      "sizes" : [ {
        "h" : 477,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/OcLQLhC2IN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.6164195846461, 11.43425372040363 ]
  },
  "id_str" : "585161791140933633",
  "text" : "The result of intercontinental travel and jet lag I presume. http:\/\/t.co\/OcLQLhC2IN",
  "id" : 585161791140933633,
  "created_at" : "2015-04-06 19:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "585053454130905089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.56307036399966, 9.96909550513617 ]
  },
  "id_str" : "585064231445344256",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy i want to see that. And be acknowledged ;)",
  "id" : 585064231445344256,
  "in_reply_to_status_id" : 585053454130905089,
  "created_at" : "2015-04-06 12:59:17 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "indices" : [ 3, 17 ],
      "id_str" : "2315551122",
      "id" : 2315551122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/nzat898RFE",
      "expanded_url" : "http:\/\/wp.me\/p4ik2k-4s",
      "display_url" : "wp.me\/p4ik2k-4s"
    } ]
  },
  "geo" : { },
  "id_str" : "585022926480617473",
  "text" : "RT @TheScienceWeb: Only three gel images ever made, admit scientists http:\/\/t.co\/nzat898RFE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/nzat898RFE",
        "expanded_url" : "http:\/\/wp.me\/p4ik2k-4s",
        "display_url" : "wp.me\/p4ik2k-4s"
      } ]
    },
    "geo" : { },
    "id_str" : "585002372163833856",
    "text" : "Only three gel images ever made, admit scientists http:\/\/t.co\/nzat898RFE",
    "id" : 585002372163833856,
    "created_at" : "2015-04-06 08:53:28 +0000",
    "user" : {
      "name" : "The Science Web",
      "screen_name" : "TheScienceWeb",
      "protected" : false,
      "id_str" : "2315551122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428172546672824320\/1lZmC7lz_normal.jpeg",
      "id" : 2315551122,
      "verified" : false
    }
  },
  "id" : 585022926480617473,
  "created_at" : "2015-04-06 10:15:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/3nMqAZzSYE",
      "expanded_url" : "https:\/\/instagram.com\/p\/1INzRmBwnH\/",
      "display_url" : "instagram.com\/p\/1INzRmBwnH\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.553502609, 9.992888458 ]
  },
  "id_str" : "585010417543426048",
  "text" : "Perle @ Alster Jungfernstieg https:\/\/t.co\/3nMqAZzSYE",
  "id" : 585010417543426048,
  "created_at" : "2015-04-06 09:25:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584855204476153856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61632841175818, 11.43385603789896 ]
  },
  "id_str" : "584951519902097408",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy microbiomolome!",
  "id" : 584951519902097408,
  "in_reply_to_status_id" : 584855204476153856,
  "created_at" : "2015-04-06 05:31:24 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/pIrB42ea2H",
      "expanded_url" : "http:\/\/currents.plos.org\/treeoflife\/article\/best-practices-for-data-sharing-in-phylogenetic-research\/",
      "display_url" : "currents.plos.org\/treeoflife\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584829445795672066",
  "text" : "Totally missed that it\u2019s out since June last year: \u00ABBest Practices for Data Sharing in Phylogenetic Research\u00BB http:\/\/t.co\/pIrB42ea2H",
  "id" : 584829445795672066,
  "created_at" : "2015-04-05 21:26:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/SJYRZh6LV2",
      "expanded_url" : "http:\/\/www.theguardian.com\/society\/2015\/apr\/01\/future-of-loneliness-internet-isolation",
      "display_url" : "theguardian.com\/society\/2015\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584793320221716480",
  "text" : "The future of loneliness http:\/\/t.co\/SJYRZh6LV2",
  "id" : 584793320221716480,
  "created_at" : "2015-04-05 19:02:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luciano Floridi",
      "screen_name" : "Floridi",
      "indices" : [ 3, 11 ],
      "id_str" : "51734793",
      "id" : 51734793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584792621106728960",
  "text" : "RT @Floridi: \"Philosophy from the Zettabyte\", interview on the philosophy of information and much, much more... for 3:AM Magazine http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tMeZhLI3kx",
        "expanded_url" : "http:\/\/ow.ly\/LdzCg",
        "display_url" : "ow.ly\/LdzCg"
      } ]
    },
    "geo" : { },
    "id_str" : "584734554742751232",
    "text" : "\"Philosophy from the Zettabyte\", interview on the philosophy of information and much, much more... for 3:AM Magazine http:\/\/t.co\/tMeZhLI3kx",
    "id" : 584734554742751232,
    "created_at" : "2015-04-05 15:09:16 +0000",
    "user" : {
      "name" : "Luciano Floridi",
      "screen_name" : "Floridi",
      "protected" : false,
      "id_str" : "51734793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805207606327447552\/rFgtmCtI_normal.jpg",
      "id" : 51734793,
      "verified" : false
    }
  },
  "id" : 584792621106728960,
  "created_at" : "2015-04-05 19:00:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 3, 12 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Sam Dean",
      "screen_name" : "SamAugustDean",
      "indices" : [ 37, 51 ],
      "id_str" : "82670189",
      "id" : 82670189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/zeAyNgyLti",
      "expanded_url" : "https:\/\/medium.com\/re-form\/light-from-a-pipe-fa3ddcb5e6f2?source=tw-a02f6af7c740-1428257147142",
      "display_url" : "medium.com\/re-form\/light-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584787388532129793",
  "text" : "RT @eramirez: \u201CLight From a Pipe\u201D by @SamAugustDean https:\/\/t.co\/zeAyNgyLti",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Dean",
        "screen_name" : "SamAugustDean",
        "indices" : [ 23, 37 ],
        "id_str" : "82670189",
        "id" : 82670189
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/zeAyNgyLti",
        "expanded_url" : "https:\/\/medium.com\/re-form\/light-from-a-pipe-fa3ddcb5e6f2?source=tw-a02f6af7c740-1428257147142",
        "display_url" : "medium.com\/re-form\/light-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "584779000385445889",
    "text" : "\u201CLight From a Pipe\u201D by @SamAugustDean https:\/\/t.co\/zeAyNgyLti",
    "id" : 584779000385445889,
    "created_at" : "2015-04-05 18:05:53 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/866822214267666432\/IYzsQHYG_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 584787388532129793,
  "created_at" : "2015-04-05 18:39:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/qe3cNFT5M2",
      "expanded_url" : "http:\/\/buff.ly\/1GeRS5C",
      "display_url" : "buff.ly\/1GeRS5C"
    } ]
  },
  "geo" : { },
  "id_str" : "584767143230726144",
  "text" : "RT @brainpicker: Kurt Cobain died on this day in 1994 \u2013\u00A0here is a bittersweet look at his letters and journals http:\/\/t.co\/qe3cNFT5M2 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brainpicker\/status\/584755163778416641\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/uBMmjc5nKr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB13uSRWIAA8bt8.jpg",
        "id_str" : "584755163690311680",
        "id" : 584755163690311680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB13uSRWIAA8bt8.jpg",
        "sizes" : [ {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uBMmjc5nKr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/qe3cNFT5M2",
        "expanded_url" : "http:\/\/buff.ly\/1GeRS5C",
        "display_url" : "buff.ly\/1GeRS5C"
      } ]
    },
    "geo" : { },
    "id_str" : "584755163778416641",
    "text" : "Kurt Cobain died on this day in 1994 \u2013\u00A0here is a bittersweet look at his letters and journals http:\/\/t.co\/qe3cNFT5M2 http:\/\/t.co\/uBMmjc5nKr",
    "id" : 584755163778416641,
    "created_at" : "2015-04-05 16:31:09 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577255253852065794\/qGnSwsBR_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 584767143230726144,
  "created_at" : "2015-04-05 17:18:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/vhNO5R7l6r",
      "expanded_url" : "https:\/\/instagram.com\/p\/1Gd0QzhwuU\/",
      "display_url" : "instagram.com\/p\/1Gd0QzhwuU\/"
    } ]
  },
  "geo" : { },
  "id_str" : "584764160912785408",
  "text" : "Hiking https:\/\/t.co\/vhNO5R7l6r",
  "id" : 584764160912785408,
  "created_at" : "2015-04-05 17:06:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renamed @sckottie",
      "screen_name" : "recology_",
      "indices" : [ 0, 10 ],
      "id_str" : "4465848374",
      "id" : 4465848374
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 78, 91 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 92, 104 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584742187209924609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61639450962682, 11.43425214273544 ]
  },
  "id_str" : "584753666416074752",
  "in_reply_to_user_id" : 103004948,
  "text" : "@recology_ might be a side effect of the transition to a never rails version. @PhilippBayer @helgerausch",
  "id" : 584753666416074752,
  "in_reply_to_status_id" : 584742187209924609,
  "created_at" : "2015-04-05 16:25:12 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584648629685788672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61639123746996, 11.43424814113781 ]
  },
  "id_str" : "584651419778686976",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer btw: Fitbit keeps failing, but I\u2019m on a hike right now, can\u2019t look into it closer. Just to keep in mind.",
  "id" : 584651419778686976,
  "in_reply_to_status_id" : 584648629685788672,
  "created_at" : "2015-04-05 09:38:55 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584503750011838464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61639290685392, 11.43426471325579 ]
  },
  "id_str" : "584640815496040448",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer doesn\u2019t sound too complicated. I agree.",
  "id" : 584640815496040448,
  "in_reply_to_status_id" : 584503750011838464,
  "created_at" : "2015-04-05 08:56:47 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584474827160997889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61650082287715, 11.43427823671273 ]
  },
  "id_str" : "584475404683108352",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch okay :)",
  "id" : 584475404683108352,
  "in_reply_to_status_id" : 584474827160997889,
  "created_at" : "2015-04-04 21:59:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584473208381931520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61648826377006, 11.43453164050046 ]
  },
  "id_str" : "584474700358746112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch now we only need a way to send out the last 3k mails? :D",
  "id" : 584474700358746112,
  "in_reply_to_status_id" : 584473208381931520,
  "created_at" : "2015-04-04 21:56:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/gd6VkGcVG8",
      "expanded_url" : "http:\/\/anticache.img0.joyreactor.com\/pics\/post\/gif-jesus-fail-335404.gif",
      "display_url" : "anticache.img0.joyreactor.com\/pics\/post\/gif-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584472311606202368",
  "geo" : { },
  "id_str" : "584472561163075584",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch http:\/\/t.co\/gd6VkGcVG8",
  "id" : 584472561163075584,
  "in_reply_to_status_id" : 584472311606202368,
  "created_at" : "2015-04-04 21:48:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialmediadreamteam",
      "indices" : [ 66, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/nRRg2MFpcH",
      "expanded_url" : "http:\/\/31.media.tumblr.com\/tumblr_m8zeuazoTm1rt28efo1_500.gif",
      "display_url" : "31.media.tumblr.com\/tumblr_m8zeuaz\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584471701871841280",
  "geo" : { },
  "id_str" : "584472006558687232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch Let me put it on Facebook and Twitter. #socialmediadreamteam http:\/\/t.co\/nRRg2MFpcH",
  "id" : 584472006558687232,
  "in_reply_to_status_id" : 584471701871841280,
  "created_at" : "2015-04-04 21:45:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/cECAEMdPtO",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/aKxgKnrWieIrm\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/aKxgKnrW\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584470567400660992",
  "geo" : { },
  "id_str" : "584470826004705280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch got myself the easiest part :D http:\/\/t.co\/cECAEMdPtO",
  "id" : 584470826004705280,
  "in_reply_to_status_id" : 584470567400660992,
  "created_at" : "2015-04-04 21:41:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/urUenSRy0o",
      "expanded_url" : "https:\/\/opensnp.wordpress.com\/2015\/04\/04\/thedress-ethics-for-participant-lead-research-research-hack-days\/",
      "display_url" : "opensnp.wordpress.com\/2015\/04\/04\/the\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584468790626365440",
  "geo" : { },
  "id_str" : "584469911977783296",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch and here it is! https:\/\/t.co\/urUenSRy0o",
  "id" : 584469911977783296,
  "in_reply_to_status_id" : 584468790626365440,
  "created_at" : "2015-04-04 21:37:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584467269755006976",
  "geo" : { },
  "id_str" : "584467874741411840",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch shall I put it up as a blogpost?",
  "id" : 584467874741411840,
  "in_reply_to_status_id" : 584467269755006976,
  "created_at" : "2015-04-04 21:29:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584467269755006976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61639120922688, 11.43425266625426 ]
  },
  "id_str" : "584467545752764418",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I got the mail. But then I\u2019m ID=1 and it\u2019s prob. sorted by that.",
  "id" : 584467545752764418,
  "in_reply_to_status_id" : 584467269755006976,
  "created_at" : "2015-04-04 21:28:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584463014889447424",
  "geo" : { },
  "id_str" : "584463339226537985",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I\u2019ve done it once and the little sanity that was left afterwards I\u2019d love to keep.",
  "id" : 584463339226537985,
  "in_reply_to_status_id" : 584463014889447424,
  "created_at" : "2015-04-04 21:11:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harpistkat",
      "screen_name" : "harpistkat",
      "indices" : [ 3, 14 ],
      "id_str" : "921330518737739776",
      "id" : 921330518737739776
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/k2hqPcQXBi",
      "expanded_url" : "http:\/\/ije.oxfordjournals.org\/content\/37\/3\/435.full",
      "display_url" : "ije.oxfordjournals.org\/content\/37\/3\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584462009766436864",
  "text" : "RT @harpistkat: I fucking love JBS Haldane: http:\/\/t.co\/k2hqPcQXBi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/k2hqPcQXBi",
        "expanded_url" : "http:\/\/ije.oxfordjournals.org\/content\/37\/3\/435.full",
        "display_url" : "ije.oxfordjournals.org\/content\/37\/3\/4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "584008003814301696",
    "text" : "I fucking love JBS Haldane: http:\/\/t.co\/k2hqPcQXBi",
    "id" : 584008003814301696,
    "created_at" : "2015-04-03 15:02:13 +0000",
    "user" : {
      "name" : "Kat Arney",
      "screen_name" : "Kat_Arney",
      "protected" : false,
      "id_str" : "32588979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875377578529488896\/p1zR7IWI_normal.jpg",
      "id" : 32588979,
      "verified" : true
    }
  },
  "id" : 584462009766436864,
  "created_at" : "2015-04-04 21:06:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584461682375847936",
  "geo" : { },
  "id_str" : "584461827523932160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch please let us just pay for the problem to disappear instead of doing mailserver administration. :D",
  "id" : 584461827523932160,
  "in_reply_to_status_id" : 584461682375847936,
  "created_at" : "2015-04-04 21:05:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584460336125911040",
  "geo" : { },
  "id_str" : "584460447245606912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I\u2019m not sure whether a short one will actually help. One day we should figure out a better way to do this. :D",
  "id" : 584460447245606912,
  "in_reply_to_status_id" : 584460336125911040,
  "created_at" : "2015-04-04 21:00:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584459178338562050",
  "geo" : { },
  "id_str" : "584459574142496770",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch because we have too many users: will lock us out of our email-account rather quickly as it\u2019s flagged spam. :D",
  "id" : 584459574142496770,
  "in_reply_to_status_id" : 584459178338562050,
  "created_at" : "2015-04-04 20:56:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/rUYcPyvaKl",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/snpr\/blob\/master\/lib\/tasks\/send_newsletter.rake",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584459178338562050",
  "geo" : { },
  "id_str" : "584459462381072384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch used(!) to be like this https:\/\/t.co\/rUYcPyvaKl but should not be done like this anymore.",
  "id" : 584459462381072384,
  "in_reply_to_status_id" : 584459178338562050,
  "created_at" : "2015-04-04 20:56:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584457046470307840",
  "geo" : { },
  "id_str" : "584457185901568000",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch i must admit I\u2019m running out of them. There\u2019s a shocking lack of those!",
  "id" : 584457185901568000,
  "in_reply_to_status_id" : 584457046470307840,
  "created_at" : "2015-04-04 20:47:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/4O7pDrzJiL",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/G3vioySdTcvPW\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/G3vioySd\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584456774712975361",
  "geo" : { },
  "id_str" : "584456864332652544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch http:\/\/t.co\/4O7pDrzJiL :3",
  "id" : 584456864332652544,
  "in_reply_to_status_id" : 584456774712975361,
  "created_at" : "2015-04-04 20:45:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/WbUX38BR10",
      "expanded_url" : "http:\/\/media.giphy.com\/media\/P6mCRUMopQ1t6\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/P6mCRUMo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "584453341784178690",
  "geo" : { },
  "id_str" : "584454731889778688",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch please, database &amp; website, come back! http:\/\/t.co\/WbUX38BR10",
  "id" : 584454731889778688,
  "in_reply_to_status_id" : 584453341784178690,
  "created_at" : "2015-04-04 20:37:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/tDe9dRQ5CY",
      "expanded_url" : "https:\/\/medium.com\/re-form\/design-for-south-paws-d111a61871db",
      "display_url" : "medium.com\/re-form\/design\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584453324147163137",
  "text" : "Aye! \u00ABthere\u2019s a kind of solidarity among left handed people that feels almost like a secret handshake\u00BB https:\/\/t.co\/tDe9dRQ5CY",
  "id" : 584453324147163137,
  "created_at" : "2015-04-04 20:31:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584448807397621760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61636995140145, 11.43448124994284 ]
  },
  "id_str" : "584450048911638528",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch awesome, thanks!",
  "id" : 584450048911638528,
  "in_reply_to_status_id" : 584448807397621760,
  "created_at" : "2015-04-04 20:18:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584437996474261504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61641201661305, 11.43444528804294 ]
  },
  "id_str" : "584448257276960768",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch best of luck. Let\u2019s hope the resurrection works out :D",
  "id" : 584448257276960768,
  "in_reply_to_status_id" : 584437996474261504,
  "created_at" : "2015-04-04 20:11:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584438927609700352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.6167517387967, 11.43415660610417 ]
  },
  "id_str" : "584446988990738433",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer only saw bits of the show. But the analysis in itself is nice. Use it for your favorite book series ;)",
  "id" : 584446988990738433,
  "in_reply_to_status_id" : 584438927609700352,
  "created_at" : "2015-04-04 20:06:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 57, 70 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/vREQ2LZWTD",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/4\/4\/8339605\/bayesian-survival-analysis-game-of-thrones",
      "display_url" : "vox.com\/2015\/4\/4\/83396\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584430162055454721",
  "text" : "Bayesian survival analysis in A Song of Ice and Fire \/cc @PhilippBayer  http:\/\/t.co\/vREQ2LZWTD",
  "id" : 584430162055454721,
  "created_at" : "2015-04-04 18:59:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/PObTofxC0J",
      "expanded_url" : "https:\/\/instagram.com\/p\/1EBkGshwjG\/",
      "display_url" : "instagram.com\/p\/1EBkGshwjG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "584420557707415552",
  "text" : "I think just TIL that Westphalia is the odd one out for doing this on Sunday. https:\/\/t.co\/PObTofxC0J",
  "id" : 584420557707415552,
  "created_at" : "2015-04-04 18:21:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/Jkym0U4ued",
      "expanded_url" : "https:\/\/instagram.com\/p\/1D-uYUhwrZ\/",
      "display_url" : "instagram.com\/p\/1D-uYUhwrZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "584414314263547905",
  "text" : "Friendly faces https:\/\/t.co\/Jkym0U4ued",
  "id" : 584414314263547905,
  "created_at" : "2015-04-04 17:56:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Song Exploder",
      "screen_name" : "SongExploder",
      "indices" : [ 0, 13 ],
      "id_str" : "2249590315",
      "id" : 2249590315
    }, {
      "name" : "Aaron Dessner",
      "screen_name" : "aaron_dessner",
      "indices" : [ 14, 28 ],
      "id_str" : "2923474228",
      "id" : 2923474228
    }, {
      "name" : "Bryce Dessner",
      "screen_name" : "bryce_dessner",
      "indices" : [ 29, 43 ],
      "id_str" : "2792550554",
      "id" : 2792550554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584387492670877697",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.8944161605087, 11.44022220759002 ]
  },
  "id_str" : "584387675987255297",
  "in_reply_to_user_id" : 2249590315,
  "text" : "@SongExploder @aaron_dessner @bryce_dessner that\u2019s even better. Thanks!",
  "id" : 584387675987255297,
  "in_reply_to_status_id" : 584387492670877697,
  "created_at" : "2015-04-04 16:10:54 +0000",
  "in_reply_to_screen_name" : "SongExploder",
  "in_reply_to_user_id_str" : "2249590315",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.59866622999998, 11.39284014 ]
  },
  "id_str" : "584302539845283841",
  "text" : "\u00ABWhy are there so many people here in the supermarket?!\u00BB \u2014 \u00ABIt\u2019s an old Easter tradition: an aisle for an aisle, a tooth for a tooth.\u00BB",
  "id" : 584302539845283841,
  "created_at" : "2015-04-04 10:32:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Song Exploder",
      "screen_name" : "SongExploder",
      "indices" : [ 122, 135 ],
      "id_str" : "2249590315",
      "id" : 2249590315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61641220649091, 11.43432129370788 ]
  },
  "id_str" : "584276318998630401",
  "text" : "Just me or is the electrical guitar of the last third of Start A War by The National inspired by The Doors' The End? Help @SongExploder!",
  "id" : 584276318998630401,
  "created_at" : "2015-04-04 08:48:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 3, 18 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "T. Ryan Gregory",
      "screen_name" : "TRyanGregory",
      "indices" : [ 123, 136 ],
      "id_str" : "151257881",
      "id" : 151257881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584255821493710848",
  "text" : "RT @torstenseemann: Ten of the most common misconceptions about phylogenetic trees: \n\"Understanding Evolutionary Trees\" by @TRyanGregory ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "T. Ryan Gregory",
        "screen_name" : "TRyanGregory",
        "indices" : [ 103, 116 ],
        "id_str" : "151257881",
        "id" : 151257881
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/RmixwWcTxO",
        "expanded_url" : "http:\/\/link.springer.com\/article\/10.1007%2Fs12052-008-0035-x",
        "display_url" : "link.springer.com\/article\/10.100\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "584189445617790976",
    "text" : "Ten of the most common misconceptions about phylogenetic trees: \n\"Understanding Evolutionary Trees\" by @TRyanGregory http:\/\/t.co\/RmixwWcTxO",
    "id" : 584189445617790976,
    "created_at" : "2015-04-04 03:03:12 +0000",
    "user" : {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "protected" : false,
      "id_str" : "42558652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720526185361510400\/dA-svJxC_normal.jpg",
      "id" : 42558652,
      "verified" : false
    }
  },
  "id" : 584255821493710848,
  "created_at" : "2015-04-04 07:26:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/eXMBtUHNCe",
      "expanded_url" : "https:\/\/instagram.com\/p\/1BwKOzhwkF\/",
      "display_url" : "instagram.com\/p\/1BwKOzhwkF\/"
    } ]
  },
  "geo" : { },
  "id_str" : "584100809396346881",
  "text" : "on watch https:\/\/t.co\/eXMBtUHNCe",
  "id" : 584100809396346881,
  "created_at" : "2015-04-03 21:10:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584096635464089601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61639021145265, 11.43425532406239 ]
  },
  "id_str" : "584097452371943426",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher we\u2019ll never know!",
  "id" : 584097452371943426,
  "in_reply_to_status_id" : 584096635464089601,
  "created_at" : "2015-04-03 20:57:39 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PLOSBuzzFeed",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.61639165356756, 11.43426137607914 ]
  },
  "id_str" : "584096514584227840",
  "text" : "20 Ways to be Off-By-One, with BED and SAM. #PLOSBuzzFeed",
  "id" : 584096514584227840,
  "created_at" : "2015-04-03 20:53:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/BouX2f3V05",
      "expanded_url" : "https:\/\/instagram.com\/p\/1BWV-2BwpH\/",
      "display_url" : "instagram.com\/p\/1BWV-2BwpH\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.633333, 11.466667 ]
  },
  "id_str" : "584044038279585792",
  "text" : "\u00ABOf course, there's a beautiful castle in the background and you take pictures of fungi\u2026\u00BB @ Lake\u2026 https:\/\/t.co\/BouX2f3V05",
  "id" : 584044038279585792,
  "created_at" : "2015-04-03 17:25:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "nevercube",
      "indices" : [ 0, 10 ],
      "id_str" : "222409931",
      "id" : 222409931
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 11, 27 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583900676520042498",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.34434830280657, 12.36934248531782 ]
  },
  "id_str" : "583901364008394752",
  "in_reply_to_user_id" : 222409931,
  "text" : "@nevercube @pathogenomenick a joke a day too late?",
  "id" : 583901364008394752,
  "in_reply_to_status_id" : 583900676520042498,
  "created_at" : "2015-04-03 07:58:28 +0000",
  "in_reply_to_screen_name" : "nevercube",
  "in_reply_to_user_id_str" : "222409931",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583899405222281216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.34431073411277, 12.36943816801587 ]
  },
  "id_str" : "583899685292797952",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick let\u2019s write \u201Eten simple rules to tell that ten simple rules have gone to far\u201C.",
  "id" : 583899685292797952,
  "in_reply_to_status_id" : 583899405222281216,
  "created_at" : "2015-04-03 07:51:47 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/wVDj9f29dD",
      "expanded_url" : "http:\/\/journals.plos.org\/ploscompbiol\/article?id=10.1371\/journal.pcbi.1004084",
      "display_url" : "journals.plos.org\/ploscompbiol\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583891032942768128",
  "text" : "Ten Simple Rules to Win a Nobel Prize http:\/\/t.co\/wVDj9f29dD",
  "id" : 583891032942768128,
  "created_at" : "2015-04-03 07:17:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.34421178959753, 12.36954969583394 ]
  },
  "id_str" : "583752975983710209",
  "text" : "\u00ABHow do you call it?\u00BB \u2014 \u00ABKofferraum.\u00BB \u2014 \u00ABI see, we need more Kofferraum in the east of the car!\u00BB",
  "id" : 583752975983710209,
  "created_at" : "2015-04-02 22:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/IOBGfVcqM3",
      "expanded_url" : "http:\/\/timotheepoisot.fr\/2015\/04\/02\/do-not-enforce-R\/",
      "display_url" : "timotheepoisot.fr\/2015\/04\/02\/do-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583687668317433857",
  "text" : "\u00ABbecause of this \u201CR or bust\u201D mentality that some people are so vocal about, cool things are not properly released.\u00BB http:\/\/t.co\/IOBGfVcqM3",
  "id" : 583687668317433857,
  "created_at" : "2015-04-02 17:49:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Derek Lowe",
      "screen_name" : "Dereklowe",
      "indices" : [ 80, 90 ],
      "id_str" : "17393219",
      "id" : 17393219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583686301469302784",
  "text" : "RT @wilbanks: \"the biology of disease is an away game if there ever was one.\u201D - @Dereklowe on the biopharma\/SV dichotomy. http:\/\/t.co\/oSEUS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Derek Lowe",
        "screen_name" : "Dereklowe",
        "indices" : [ 66, 76 ],
        "id_str" : "17393219",
        "id" : 17393219
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/oSEUSr9L8J",
        "expanded_url" : "http:\/\/pipeline.corante.com\/archives\/2015\/04\/02\/silicon_valley_sunglasses.php",
        "display_url" : "pipeline.corante.com\/archives\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "583678112644202496",
    "text" : "\"the biology of disease is an away game if there ever was one.\u201D - @Dereklowe on the biopharma\/SV dichotomy. http:\/\/t.co\/oSEUSr9L8J",
    "id" : 583678112644202496,
    "created_at" : "2015-04-02 17:11:20 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 583686301469302784,
  "created_at" : "2015-04-02 17:43:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "indices" : [ 3, 12 ],
      "id_str" : "583180584",
      "id" : 583180584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2015",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583682675682234368",
  "text" : "RT @OBF_BOSC: Interested in free or half-price admission to #BOSC2015? Ask in the Comments section in your abstract submission. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BOSC2015",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Q6Ru4ZtnMG",
        "expanded_url" : "http:\/\/www.open-bio.org\/wiki\/BOSC_2015",
        "display_url" : "open-bio.org\/wiki\/BOSC_2015"
      } ]
    },
    "geo" : { },
    "id_str" : "583661783090466818",
    "text" : "Interested in free or half-price admission to #BOSC2015? Ask in the Comments section in your abstract submission. http:\/\/t.co\/Q6Ru4ZtnMG",
    "id" : 583661783090466818,
    "created_at" : "2015-04-02 16:06:27 +0000",
    "user" : {
      "name" : "BOSC",
      "screen_name" : "OBF_BOSC",
      "protected" : false,
      "id_str" : "583180584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227105401\/BOSC-logo-square_normal.jpg",
      "id" : 583180584,
      "verified" : false
    }
  },
  "id" : 583682675682234368,
  "created_at" : "2015-04-02 17:29:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583591141704130560",
  "geo" : { },
  "id_str" : "583681701563469825",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw. any chance you read the newsletter draft by now? :&gt;",
  "id" : 583681701563469825,
  "in_reply_to_status_id" : 583591141704130560,
  "created_at" : "2015-04-02 17:25:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/583681419249065984\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/qTsqbqYl4i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBmnKIJW4AEjjuL.jpg",
      "id_str" : "583681419148451841",
      "id" : 583681419148451841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBmnKIJW4AEjjuL.jpg",
      "sizes" : [ {
        "h" : 469,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/qTsqbqYl4i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.34438, 12.369201 ]
  },
  "id_str" : "583681419249065984",
  "text" : "Doh! \/cc @senficon http:\/\/t.co\/qTsqbqYl4i",
  "id" : 583681419249065984,
  "created_at" : "2015-04-02 17:24:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/PrH7ztRuNt",
      "expanded_url" : "https:\/\/instagram.com\/p\/0-wo6vBwkP\/",
      "display_url" : "instagram.com\/p\/0-wo6vBwkP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "583679652377579520",
  "text" : "After (and before) the rain\/hail\/snow https:\/\/t.co\/PrH7ztRuNt",
  "id" : 583679652377579520,
  "created_at" : "2015-04-02 17:17:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.06518854513816, 13.74445531608798 ]
  },
  "id_str" : "583528983750389760",
  "text" : "\u00ABQuick, you need to look out of the window!\u00BB \u2014 \u00ABIt\u2019s only snow, I expected nazis!\u00BB \u2014 \u00ABWell, it is mindlessly white\u2026\u00BB",
  "id" : 583528983750389760,
  "created_at" : "2015-04-02 07:18:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.0721552949478, 13.74744350951758 ]
  },
  "id_str" : "583321778925223936",
  "text" : "\u00ABI haven\u2019t seen a single Nazi or PEGIDA-guy since we arrived. I start suspecting you make them up, so you can print new stickers.\u00BB",
  "id" : 583321778925223936,
  "created_at" : "2015-04-01 17:35:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583221133979308032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.07220116378833, 13.74745460458002 ]
  },
  "id_str" : "583320884708016129",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer do want. We would be dating then :D",
  "id" : 583320884708016129,
  "in_reply_to_status_id" : 583221133979308032,
  "created_at" : "2015-04-01 17:31:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 86, 102 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Py3OQ0fkJY",
      "expanded_url" : "http:\/\/blog.oup.com\/2015\/04\/dna-and-the-dress\/",
      "display_url" : "blog.oup.com\/2015\/04\/dna-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583257340952100864",
  "text" : "RT @PhilippBayer: \"DNA, colour perception, and \u2018The Dress\u2019\" http:\/\/t.co\/Py3OQ0fkJY cc @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 68, 84 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/Py3OQ0fkJY",
        "expanded_url" : "http:\/\/blog.oup.com\/2015\/04\/dna-and-the-dress\/",
        "display_url" : "blog.oup.com\/2015\/04\/dna-an\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "583246214797402112",
    "text" : "\"DNA, colour perception, and \u2018The Dress\u2019\" http:\/\/t.co\/Py3OQ0fkJY cc @gedankenstuecke",
    "id" : 583246214797402112,
    "created_at" : "2015-04-01 12:35:08 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 583257340952100864,
  "created_at" : "2015-04-01 13:19:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583205864879890432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.04924076544626, 13.3505581491145 ]
  },
  "id_str" : "583240511676391424",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a super. Ist nur eine :)",
  "id" : 583240511676391424,
  "in_reply_to_status_id" : 583205864879890432,
  "created_at" : "2015-04-01 12:12:28 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583190704421240832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.88354769632247, 9.805151569391588 ]
  },
  "id_str" : "583204205374128128",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a ja, das w\u00E4re cool.",
  "id" : 583204205374128128,
  "in_reply_to_status_id" : 583190704421240832,
  "created_at" : "2015-04-01 09:48:12 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 87, 103 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/pVeBV4oFGu",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/04\/01\/technology\/the-healing-power-of-your-own-medical-data.html",
      "display_url" : "nytimes.com\/2015\/04\/01\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583157230377299968",
  "text" : "RT @PhilippBayer: The Healing Power Of Your Own Medical Data http:\/\/t.co\/pVeBV4oFGu cc @gedankenstuecke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 69, 85 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/pVeBV4oFGu",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/04\/01\/technology\/the-healing-power-of-your-own-medical-data.html",
        "display_url" : "nytimes.com\/2015\/04\/01\/tec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "583069422518190080",
    "text" : "The Healing Power Of Your Own Medical Data http:\/\/t.co\/pVeBV4oFGu cc @gedankenstuecke",
    "id" : 583069422518190080,
    "created_at" : "2015-04-01 00:52:37 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 583157230377299968,
  "created_at" : "2015-04-01 06:41:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583064241000693761",
  "geo" : { },
  "id_str" : "583157198324367361",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, which parts about Gould?",
  "id" : 583157198324367361,
  "in_reply_to_status_id" : 583064241000693761,
  "created_at" : "2015-04-01 06:41:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "583024785103446017",
  "geo" : { },
  "id_str" : "583026072972853248",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich ok, dann schauen wir danach mal und ich dr\u00FCck dir solange die Daumen :)",
  "id" : 583026072972853248,
  "in_reply_to_status_id" : 583024785103446017,
  "created_at" : "2015-03-31 22:00:22 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]