Grailbird.data.tweets_2017_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/66VSLTZGLr",
      "expanded_url" : "https:\/\/twitter.com\/madprime\/status\/902935247146254336",
      "display_url" : "twitter.com\/madprime\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903333504779419648",
  "text" : "RT @madprime: Yes, this is open to international folks! https:\/\/t.co\/66VSLTZGLr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/66VSLTZGLr",
        "expanded_url" : "https:\/\/twitter.com\/madprime\/status\/902935247146254336",
        "display_url" : "twitter.com\/madprime\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "903231135244681216",
    "text" : "Yes, this is open to international folks! https:\/\/t.co\/66VSLTZGLr",
    "id" : 903231135244681216,
    "created_at" : "2017-08-31 12:20:58 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 903333504779419648,
  "created_at" : "2017-08-31 19:07:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 0, 6 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/mmoj7jSUMx",
      "expanded_url" : "http:\/\/i0.kym-cdn.com\/entries\/icons\/mobile\/000\/001\/781\/16798.jpg",
      "display_url" : "i0.kym-cdn.com\/entries\/icons\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "903157981075959809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17263204277638, 8.627301943871903 ]
  },
  "id_str" : "903160778987012096",
  "in_reply_to_user_id" : 753358633593925632,
  "text" : "@aath0 https:\/\/t.co\/mmoj7jSUMx",
  "id" : 903160778987012096,
  "in_reply_to_status_id" : 903157981075959809,
  "created_at" : "2017-08-31 07:41:24 +0000",
  "in_reply_to_screen_name" : "aath0",
  "in_reply_to_user_id_str" : "753358633593925632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Unicode \u2199",
      "screen_name" : "FakeUnicode",
      "indices" : [ 0, 12 ],
      "id_str" : "2183231114",
      "id" : 2183231114
    }, {
      "name" : "99 Percent Invisible",
      "screen_name" : "99piorg",
      "indices" : [ 13, 21 ],
      "id_str" : "3712590975",
      "id" : 3712590975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903017821176610816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404115530308, 8.753375000977174 ]
  },
  "id_str" : "903018628152483841",
  "in_reply_to_user_id" : 2183231114,
  "text" : "@FakeUnicode @99piorg Shit, I was too late with that.",
  "id" : 903018628152483841,
  "in_reply_to_status_id" : 903017821176610816,
  "created_at" : "2017-08-30 22:16:32 +0000",
  "in_reply_to_screen_name" : "FakeUnicode",
  "in_reply_to_user_id_str" : "2183231114",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "99 Percent Invisible",
      "screen_name" : "99piorg",
      "indices" : [ 23, 31 ],
      "id_str" : "3712590975",
      "id" : 3712590975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140318499479, 8.753396986260595 ]
  },
  "id_str" : "903004943610777603",
  "text" : "Unicode idea thanks to @99piorg: Bristol Stool Chart modifiers for \uD83D\uDCA9",
  "id" : 903004943610777603,
  "created_at" : "2017-08-30 21:22:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 0, 6 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903001081244000256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403867553447, 8.753371911498203 ]
  },
  "id_str" : "903003731276566529",
  "in_reply_to_user_id" : 753358633593925632,
  "text" : "@aath0 \u201CEvolutionary biologists are behind many popular theories\u201D hey, that\u2019s not us, that\u2019s the evolutionary psychologists!",
  "id" : 903003731276566529,
  "in_reply_to_status_id" : 903001081244000256,
  "created_at" : "2017-08-30 21:17:21 +0000",
  "in_reply_to_screen_name" : "aath0",
  "in_reply_to_user_id_str" : "753358633593925632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "indices" : [ 3, 9 ],
      "id_str" : "753358633593925632",
      "id" : 753358633593925632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/2e98tw7Wtw",
      "expanded_url" : "https:\/\/qz.com\/1057494\/the-biggest-myth-about-our-brains-is-that-theyre-male-or-female\/",
      "display_url" : "qz.com\/1057494\/the-bi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "903003223728033813",
  "text" : "RT @aath0: Should neuroscience ditch the quest for gendered brains? https:\/\/t.co\/2e98tw7Wtw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/2e98tw7Wtw",
        "expanded_url" : "https:\/\/qz.com\/1057494\/the-biggest-myth-about-our-brains-is-that-theyre-male-or-female\/",
        "display_url" : "qz.com\/1057494\/the-bi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "903001081244000256",
    "text" : "Should neuroscience ditch the quest for gendered brains? https:\/\/t.co\/2e98tw7Wtw",
    "id" : 903001081244000256,
    "created_at" : "2017-08-30 21:06:49 +0000",
    "user" : {
      "name" : "Athina Tzovara",
      "screen_name" : "aath0",
      "protected" : false,
      "id_str" : "753358633593925632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918218018500595713\/0-LcTq1y_normal.jpg",
      "id" : 753358633593925632,
      "verified" : false
    }
  },
  "id" : 903003223728033813,
  "created_at" : "2017-08-30 21:15:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    }, {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 10, 20 ],
      "id_str" : "75261668",
      "id" : 75261668
    }, {
      "name" : "Charlotte Guzzo",
      "screen_name" : "Charlotte_Guzzo",
      "indices" : [ 21, 37 ],
      "id_str" : "3448272921",
      "id" : 3448272921
    }, {
      "name" : "Heterogeneous",
      "screen_name" : "hetegene",
      "indices" : [ 38, 47 ],
      "id_str" : "894645101435269120",
      "id" : 894645101435269120
    }, {
      "name" : "Ernst Hafen",
      "screen_name" : "ehafen",
      "indices" : [ 57, 64 ],
      "id_str" : "159891548",
      "id" : 159891548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "903000586311745536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403771210033, 8.753370997153988 ]
  },
  "id_str" : "903000909994741760",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime @npscience @Charlotte_Guzzo @hetegene I\u2019m sure @ehafen has some ideas on that one too. \u263A\uFE0F",
  "id" : 903000909994741760,
  "in_reply_to_status_id" : 903000586311745536,
  "created_at" : "2017-08-30 21:06:08 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 11, 20 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/c1gxGkc7eO",
      "expanded_url" : "http:\/\/DNA.land",
      "display_url" : "DNA.land"
    } ]
  },
  "in_reply_to_status_id_str" : "902999546917261314",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11404362585458, 8.753379547196147 ]
  },
  "id_str" : "902999859803951105",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience @madprime Don\u2019t see how PGP, Open Humans and openSNP aren\u2019t user centric. Or https:\/\/t.co\/c1gxGkc7eO for that matter. But what do I know. \uD83D\uDE02",
  "id" : 902999859803951105,
  "in_reply_to_status_id" : 902999546917261314,
  "created_at" : "2017-08-30 21:01:58 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Penfold",
      "screen_name" : "npscience",
      "indices" : [ 0, 10 ],
      "id_str" : "75261668",
      "id" : 75261668
    }, {
      "name" : "Charlotte Guzzo",
      "screen_name" : "Charlotte_Guzzo",
      "indices" : [ 11, 27 ],
      "id_str" : "3448272921",
      "id" : 3448272921
    }, {
      "name" : "Heterogeneous",
      "screen_name" : "hetegene",
      "indices" : [ 28, 37 ],
      "id_str" : "894645101435269120",
      "id" : 894645101435269120
    }, {
      "name" : "OpenHumansOrg",
      "screen_name" : "OpenHumansOrg",
      "indices" : [ 38, 52 ],
      "id_str" : "2282943410",
      "id" : 2282943410
    }, {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 127, 136 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "902996503664496645",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403862736729, 8.753371823857773 ]
  },
  "id_str" : "902998915024289793",
  "in_reply_to_user_id" : 75261668,
  "text" : "@npscience @Charlotte_Guzzo @hetegene @OpenHumansOrg Well, it\u2019s not the first time one sees wrong\/misleading \u201Cfirst\u201D claims. \uD83D\uDE09 @madprime",
  "id" : 902998915024289793,
  "in_reply_to_status_id" : 902996503664496645,
  "created_at" : "2017-08-30 20:58:12 +0000",
  "in_reply_to_screen_name" : "npscience",
  "in_reply_to_user_id_str" : "75261668",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javier Qu\u00EDlez",
      "screen_name" : "jaquol",
      "indices" : [ 3, 10 ],
      "id_str" : "225349973",
      "id" : 225349973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sequencing",
      "indices" : [ 47, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/F8yKLErHSh",
      "expanded_url" : "http:\/\/www.biorxiv.org\/content\/early\/2017\/05\/10\/136358",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "902837539807133697",
  "text" : "RT @jaquol: Reading best practices in managing #sequencing data is dull (https:\/\/t.co\/F8yKLErHSh) so we tried to make it amusing https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sequencing",
        "indices" : [ 35, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/F8yKLErHSh",
        "expanded_url" : "http:\/\/www.biorxiv.org\/content\/early\/2017\/05\/10\/136358",
        "display_url" : "biorxiv.org\/content\/early\/\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/BVKXE1CjVk",
        "expanded_url" : "http:\/\/www.biorxiv.org\/content\/early\/2017\/08\/29\/136358",
        "display_url" : "biorxiv.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "902624624004956160",
    "text" : "Reading best practices in managing #sequencing data is dull (https:\/\/t.co\/F8yKLErHSh) so we tried to make it amusing https:\/\/t.co\/BVKXE1CjVk",
    "id" : 902624624004956160,
    "created_at" : "2017-08-29 20:10:54 +0000",
    "user" : {
      "name" : "Javier Qu\u00EDlez",
      "screen_name" : "jaquol",
      "protected" : false,
      "id_str" : "225349973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911270216352616448\/t3cYJa4e_normal.jpg",
      "id" : 225349973,
      "verified" : false
    }
  },
  "id" : 902837539807133697,
  "created_at" : "2017-08-30 10:16:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastien Chevreux",
      "screen_name" : "BaCh_mira",
      "indices" : [ 3, 13 ],
      "id_str" : "360258516",
      "id" : 360258516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 69, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902772660421185538",
  "text" : "RT @BaCh_mira: \"Good\" high-throughput annotation has become a major  #bioinformatics problem, and will remain in the next few years. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 54, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/yW59KdGRpB",
        "expanded_url" : "https:\/\/twitter.com\/OmicsOmicsBlog\/status\/902728823330017284",
        "display_url" : "twitter.com\/OmicsOmicsBlog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "902733131261861894",
    "text" : "\"Good\" high-throughput annotation has become a major  #bioinformatics problem, and will remain in the next few years. https:\/\/t.co\/yW59KdGRpB",
    "id" : 902733131261861894,
    "created_at" : "2017-08-30 03:22:05 +0000",
    "user" : {
      "name" : "Bastien Chevreux",
      "screen_name" : "BaCh_mira",
      "protected" : false,
      "id_str" : "360258516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2963685436\/3926a3f2b36cfa7843d5227962af7de3_normal.jpeg",
      "id" : 360258516,
      "verified" : false
    }
  },
  "id" : 902772660421185538,
  "created_at" : "2017-08-30 05:59:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mika McKinnon",
      "screen_name" : "mikamckinnon",
      "indices" : [ 3, 16 ],
      "id_str" : "44562973",
      "id" : 44562973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "902280557777874945",
  "text" : "RT @mikamckinnon: Q: How can I support diversity in [my field]?\nA: Have the dedication to step aside on a desired gig. \n\nHuge respect: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/32Sf1NZrdD",
        "expanded_url" : "https:\/\/twitter.com\/edskrein\/status\/902244967296491520",
        "display_url" : "twitter.com\/edskrein\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "902256335374344194",
    "text" : "Q: How can I support diversity in [my field]?\nA: Have the dedication to step aside on a desired gig. \n\nHuge respect: https:\/\/t.co\/32Sf1NZrdD",
    "id" : 902256335374344194,
    "created_at" : "2017-08-28 19:47:28 +0000",
    "user" : {
      "name" : "Mika McKinnon",
      "screen_name" : "mikamckinnon",
      "protected" : false,
      "id_str" : "44562973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746073510838050816\/v7nEdWx8_normal.jpg",
      "id" : 44562973,
      "verified" : true
    }
  },
  "id" : 902280557777874945,
  "created_at" : "2017-08-28 21:23:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "indices" : [ 3, 13 ],
      "id_str" : "11385492",
      "id" : 11385492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/clwZNhYMVt",
      "expanded_url" : "https:\/\/twitter.com\/nicolelzhu\/status\/901471845173661696",
      "display_url" : "twitter.com\/nicolelzhu\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "901901177486499842",
  "text" : "RT @jillemery: Please read this thread librarians, this is important https:\/\/t.co\/clwZNhYMVt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/clwZNhYMVt",
        "expanded_url" : "https:\/\/twitter.com\/nicolelzhu\/status\/901471845173661696",
        "display_url" : "twitter.com\/nicolelzhu\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "901838344979496961",
    "text" : "Please read this thread librarians, this is important https:\/\/t.co\/clwZNhYMVt",
    "id" : 901838344979496961,
    "created_at" : "2017-08-27 16:06:31 +0000",
    "user" : {
      "name" : "jillemery",
      "screen_name" : "jillemery",
      "protected" : false,
      "id_str" : "11385492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721430293668704256\/uuScw2u1_normal.jpg",
      "id" : 11385492,
      "verified" : false
    }
  },
  "id" : 901901177486499842,
  "created_at" : "2017-08-27 20:16:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LSATgunner",
      "screen_name" : "LSATgunner",
      "indices" : [ 0, 11 ],
      "id_str" : "799523988615680000",
      "id" : 799523988615680000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/NvxSBXqGhR",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/20695856",
      "display_url" : "goodreads.com\/book\/show\/2069\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "901814396438986752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35934075954176, 8.58785805059788 ]
  },
  "id_str" : "901829094324699136",
  "in_reply_to_user_id" : 799523988615680000,
  "text" : "@LSATgunner It\u2019s Weindling, see https:\/\/t.co\/NvxSBXqGhR",
  "id" : 901829094324699136,
  "in_reply_to_status_id" : 901814396438986752,
  "created_at" : "2017-08-27 15:29:45 +0000",
  "in_reply_to_screen_name" : "LSATgunner",
  "in_reply_to_user_id_str" : "799523988615680000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "indices" : [ 3, 19 ],
      "id_str" : "77216385",
      "id" : 77216385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/hRq2P7ZgeU",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/901809968839610368",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "901811911825772544",
  "text" : "RT @fireantprincess: science is and has always been political https:\/\/t.co\/hRq2P7ZgeU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/hRq2P7ZgeU",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/901809968839610368",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "901811065079697412",
    "text" : "science is and has always been political https:\/\/t.co\/hRq2P7ZgeU",
    "id" : 901811065079697412,
    "created_at" : "2017-08-27 14:18:07 +0000",
    "user" : {
      "name" : "\uD83D\uDD25\uD83D\uDC1C\uD83D\uDC78\uD83C\uDFFC",
      "screen_name" : "fireantprincess",
      "protected" : false,
      "id_str" : "77216385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791952428648148992\/xNKfrFl1_normal.jpg",
      "id" : 77216385,
      "verified" : false
    }
  },
  "id" : 901811911825772544,
  "created_at" : "2017-08-27 14:21:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/901809968839610368\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/asgPqNszzh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DIPfYuzXcAIJDXJ.jpg",
      "id_str" : "901809966377562114",
      "id" : 901809966377562114,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DIPfYuzXcAIJDXJ.jpg",
      "sizes" : [ {
        "h" : 560,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 843,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/asgPqNszzh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "901809968839610368",
  "text" : "This month it's 70 years since the Nuremberg Medical Trial ended. This book was published in 2015 and it's still true https:\/\/t.co\/asgPqNszzh",
  "id" : 901809968839610368,
  "created_at" : "2017-08-27 14:13:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Williams",
      "screen_name" : "JasonWilliamsNY",
      "indices" : [ 0, 16 ],
      "id_str" : "1692248610",
      "id" : 1692248610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901565058475450368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35934771612789, 8.587810647801474 ]
  },
  "id_str" : "901716148483436544",
  "in_reply_to_user_id" : 1692248610,
  "text" : "@JasonWilliamsNY That\u2019s perfect! \uD83D\uDE02",
  "id" : 901716148483436544,
  "in_reply_to_status_id" : 901565058475450368,
  "created_at" : "2017-08-27 08:00:57 +0000",
  "in_reply_to_screen_name" : "JasonWilliamsNY",
  "in_reply_to_user_id_str" : "1692248610",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "Ragetina",
      "screen_name" : "Ragetina",
      "indices" : [ 9, 18 ],
      "id_str" : "819601236",
      "id" : 819601236
    }, {
      "name" : "Ranting @branleb",
      "screen_name" : "rantleb",
      "indices" : [ 19, 27 ],
      "id_str" : "748130881",
      "id" : 748130881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901697482375262208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35934771612789, 8.587810647801474 ]
  },
  "id_str" : "901715841577865216",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @Ragetina @rantleb \uD83D\uDE0D",
  "id" : 901715841577865216,
  "in_reply_to_status_id" : 901697482375262208,
  "created_at" : "2017-08-27 07:59:44 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901539527570984960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933816663998, 8.587853845849775 ]
  },
  "id_str" : "901552586947530753",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Nope, but tracked the route and time in the activity tracker :p",
  "id" : 901552586947530753,
  "in_reply_to_status_id" : 901539527570984960,
  "created_at" : "2017-08-26 21:11:01 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901525812884668416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35927657592207, 8.587723117434866 ]
  },
  "id_str" : "901527093544198144",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD Walked around the lake for ~10 km and my legs are totally not used to this anymore!",
  "id" : 901527093544198144,
  "in_reply_to_status_id" : 901525812884668416,
  "created_at" : "2017-08-26 19:29:43 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "rant_a_sparta",
      "screen_name" : "trollektiv",
      "indices" : [ 9, 20 ],
      "id_str" : "973640942",
      "id" : 973640942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901526090082115586",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35906555091769, 8.587537553114624 ]
  },
  "id_str" : "901526148164853761",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @trollektiv \uD83D\uDE02",
  "id" : 901526148164853761,
  "in_reply_to_status_id" : 901526090082115586,
  "created_at" : "2017-08-26 19:25:57 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    }, {
      "name" : "rant_a_sparta",
      "screen_name" : "trollektiv",
      "indices" : [ 9, 20 ],
      "id_str" : "973640942",
      "id" : 973640942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901522067350310913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35906555091769, 8.587537553114624 ]
  },
  "id_str" : "901525776973127680",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg @trollektiv \uD83D\uDC4D take pictures of him in his best hiding places!",
  "id" : 901525776973127680,
  "in_reply_to_status_id" : 901522067350310913,
  "created_at" : "2017-08-26 19:24:29 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901449436206858240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35900435929221, 8.587512793262354 ]
  },
  "id_str" : "901521286236647426",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg Did he leave it by now? :(",
  "id" : 901521286236647426,
  "in_reply_to_status_id" : 901449436206858240,
  "created_at" : "2017-08-26 19:06:38 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901520480510914561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35900435929221, 8.587512793262354 ]
  },
  "id_str" : "901520948137951232",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg I hope that\u2019s not the decline I have to expect for the next two months! \uD83D\uDE02",
  "id" : 901520948137951232,
  "in_reply_to_status_id" : 901520480510914561,
  "created_at" : "2017-08-26 19:05:18 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933870464571, 8.587854998978887 ]
  },
  "id_str" : "901513333534273536",
  "text" : "Walked around in the sun for the first time in 3 weeks. \uD83D\uDE0D\u2600\uFE0F\uD83D\uDEB6",
  "id" : 901513333534273536,
  "created_at" : "2017-08-26 18:35:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901499962957209600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35933885179392, 8.58785500983755 ]
  },
  "id_str" : "901512960455081985",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \uD83D\uDE02 will have to add one after actually finishing it!",
  "id" : 901512960455081985,
  "in_reply_to_status_id" : 901499962957209600,
  "created_at" : "2017-08-26 18:33:33 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901491389309038592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35971022253585, 8.54596852132913 ]
  },
  "id_str" : "901491542505947138",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD Congratulations! \uD83C\uDF88\uD83C\uDF89",
  "id" : 901491542505947138,
  "in_reply_to_status_id" : 901491389309038592,
  "created_at" : "2017-08-26 17:08:27 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901489066461581312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35956059559561, 8.546096053699223 ]
  },
  "id_str" : "901491328294547456",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD Given how many days I\u2019ve sustained myself on cliff bars that sounds excellent. \uD83D\uDE09",
  "id" : 901491328294547456,
  "in_reply_to_status_id" : 901489066461581312,
  "created_at" : "2017-08-26 17:07:36 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Czaplicki",
      "screen_name" : "LCzaplickiD",
      "indices" : [ 0, 12 ],
      "id_str" : "771345893341691904",
      "id" : 771345893341691904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901484151236329472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35559646510273, 8.549453811727975 ]
  },
  "id_str" : "901485884985495553",
  "in_reply_to_user_id" : 771345893341691904,
  "text" : "@LCzaplickiD That\u2019s the first time I heard of meal trains, but that\u2019s a brilliant idea!",
  "id" : 901485884985495553,
  "in_reply_to_status_id" : 901484151236329472,
  "created_at" : "2017-08-26 16:45:58 +0000",
  "in_reply_to_screen_name" : "LCzaplickiD",
  "in_reply_to_user_id_str" : "771345893341691904",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/T8is5i3y33",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/901365456505884672",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "901365456505884672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35903517055148, 8.587582811700955 ]
  },
  "id_str" : "901417658222092288",
  "in_reply_to_user_id" : 14286491,
  "text" : "Just noticed: This equally well works for \u2018before getting the DS-2019, I-901, DS-160, A-38 and after\u2019. https:\/\/t.co\/T8is5i3y33",
  "id" : 901417658222092288,
  "in_reply_to_status_id" : 901365456505884672,
  "created_at" : "2017-08-26 12:14:51 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biolojical",
      "screen_name" : "biolojical",
      "indices" : [ 0, 11 ],
      "id_str" : "801614917002375168",
      "id" : 801614917002375168
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 12, 22 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901142413456007168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3589209541013, 8.587513652948303 ]
  },
  "id_str" : "901385078013661184",
  "in_reply_to_user_id" : 801614917002375168,
  "text" : "@biolojical @kirstie_j &gt;2 million: \uD83C\uDF44",
  "id" : 901385078013661184,
  "in_reply_to_status_id" : 901142413456007168,
  "created_at" : "2017-08-26 10:05:24 +0000",
  "in_reply_to_screen_name" : "biolojical",
  "in_reply_to_user_id_str" : "801614917002375168",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Liner",
      "screen_name" : "MsEmilyLiner",
      "indices" : [ 3, 16 ],
      "id_str" : "828025928",
      "id" : 828025928
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MsEmilyLiner\/status\/901072519070875648\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/DCSE0DLObG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DIFApEKXsAAYVnM.jpg",
      "id_str" : "901072474686861312",
      "id" : 901072474686861312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DIFApEKXsAAYVnM.jpg",
      "sizes" : [ {
        "h" : 490,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 310
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/DCSE0DLObG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "901384536403083264",
  "text" : "RT @MsEmilyLiner: The best (and by best I mean worst) part: https:\/\/t.co\/DCSE0DLObG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MsEmilyLiner\/status\/901072519070875648\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/DCSE0DLObG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DIFApEKXsAAYVnM.jpg",
        "id_str" : "901072474686861312",
        "id" : 901072474686861312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DIFApEKXsAAYVnM.jpg",
        "sizes" : [ {
          "h" : 490,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 310
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/DCSE0DLObG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "901072026814861313",
    "geo" : { },
    "id_str" : "901072519070875648",
    "in_reply_to_user_id" : 828025928,
    "text" : "The best (and by best I mean worst) part: https:\/\/t.co\/DCSE0DLObG",
    "id" : 901072519070875648,
    "in_reply_to_status_id" : 901072026814861313,
    "created_at" : "2017-08-25 13:23:24 +0000",
    "in_reply_to_screen_name" : "MsEmilyLiner",
    "in_reply_to_user_id_str" : "828025928",
    "user" : {
      "name" : "Emily Liner",
      "screen_name" : "MsEmilyLiner",
      "protected" : false,
      "id_str" : "828025928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/858309547211071488\/FGjl3pmO_normal.jpg",
      "id" : 828025928,
      "verified" : false
    }
  },
  "id" : 901384536403083264,
  "created_at" : "2017-08-26 10:03:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "901373400316350464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35909973125773, 8.587530050223995 ]
  },
  "id_str" : "901373554264076289",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr That sounds about right!",
  "id" : 901373554264076289,
  "in_reply_to_status_id" : 901373400316350464,
  "created_at" : "2017-08-26 09:19:36 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/901365456505884672\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/8VtpJtQ3gP",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DIJLF98XYAI74FY.jpg",
      "id_str" : "901365441326702594",
      "id" : 901365441326702594,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DIJLF98XYAI74FY.jpg",
      "sizes" : [ {
        "h" : 496,
        "resize" : "fit",
        "w" : 372
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 372
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 372
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 372
      } ],
      "display_url" : "pic.twitter.com\/8VtpJtQ3gP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "901365456505884672",
  "text" : "Before having a first draft for your PhD thesis and after. \uD83D\uDE02 https:\/\/t.co\/8VtpJtQ3gP",
  "id" : 901365456505884672,
  "created_at" : "2017-08-26 08:47:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 10, 20 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35915009868085, 8.587593147539149 ]
  },
  "id_str" : "901359815410188290",
  "text" : "@kopshtik @blahah404 Please study me! :p",
  "id" : 901359815410188290,
  "created_at" : "2017-08-26 08:25:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/zivO70lArH",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/At_the_Mountains_of_Madness",
      "display_url" : "en.wikipedia.org\/wiki\/At_the_Mo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "900677797596643328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17230794132865, 8.627539136488123 ]
  },
  "id_str" : "900678505201053696",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann https:\/\/t.co\/zivO70lArH :p",
  "id" : 900678505201053696,
  "in_reply_to_status_id" : 900677797596643328,
  "created_at" : "2017-08-24 11:17:44 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Vogel",
      "screen_name" : "GretchenVogel1",
      "indices" : [ 100, 115 ],
      "id_str" : "317838702",
      "id" : 317838702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "900660792474955776",
  "text" : "RT @petergrabitz: \"Germany has shown before how patient it can be when dealing with a wall.\" Thanks @GretchenVogel1 for great article https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gretchen Vogel",
        "screen_name" : "GretchenVogel1",
        "indices" : [ 82, 97 ],
        "id_str" : "317838702",
        "id" : 317838702
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/8w2eGVu4zb",
        "expanded_url" : "https:\/\/www.sciencemag.org\/news\/2017\/08\/bold-open-access-push-germany-could-change-future-academic-publishing",
        "display_url" : "sciencemag.org\/news\/2017\/08\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "900643987140337664",
    "text" : "\"Germany has shown before how patient it can be when dealing with a wall.\" Thanks @GretchenVogel1 for great article https:\/\/t.co\/8w2eGVu4zb",
    "id" : 900643987140337664,
    "created_at" : "2017-08-24 09:00:34 +0000",
    "user" : {
      "name" : "Peter",
      "screen_name" : "PeterRolandG",
      "protected" : false,
      "id_str" : "2396006202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636115977894260736\/ZadNq2eK_normal.jpg",
      "id" : 2396006202,
      "verified" : false
    }
  },
  "id" : 900660792474955776,
  "created_at" : "2017-08-24 10:07:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JONATHAN KEMP",
      "screen_name" : "JonathanMKemp",
      "indices" : [ 3, 17 ],
      "id_str" : "249190827",
      "id" : 249190827
    }, {
      "name" : "TimesHigherEducation",
      "screen_name" : "timeshighered",
      "indices" : [ 113, 127 ],
      "id_str" : "23602600",
      "id" : 23602600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/JMDvXlfwDf",
      "expanded_url" : "https:\/\/www.timeshighereducation.com\/news\/academics-face-higher-mental-health-risk-than-other-professions",
      "display_url" : "timeshighereducation.com\/news\/academics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900658486861864961",
  "text" : "RT @JonathanMKemp: Academics \u2018face higher mental health risk\u2019 than other professions https:\/\/t.co\/JMDvXlfwDf via @timeshighered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TimesHigherEducation",
        "screen_name" : "timeshighered",
        "indices" : [ 94, 108 ],
        "id_str" : "23602600",
        "id" : 23602600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/JMDvXlfwDf",
        "expanded_url" : "https:\/\/www.timeshighereducation.com\/news\/academics-face-higher-mental-health-risk-than-other-professions",
        "display_url" : "timeshighereducation.com\/news\/academics\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "900642118691160068",
    "text" : "Academics \u2018face higher mental health risk\u2019 than other professions https:\/\/t.co\/JMDvXlfwDf via @timeshighered",
    "id" : 900642118691160068,
    "created_at" : "2017-08-24 08:53:08 +0000",
    "user" : {
      "name" : "JONATHAN KEMP",
      "screen_name" : "JonathanMKemp",
      "protected" : false,
      "id_str" : "249190827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/862642335842263040\/z_-W8gA9_normal.jpg",
      "id" : 249190827,
      "verified" : false
    }
  },
  "id" : 900658486861864961,
  "created_at" : "2017-08-24 09:58:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Su",
      "screen_name" : "andrewsu",
      "indices" : [ 0, 9 ],
      "id_str" : "25743783",
      "id" : 25743783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "900509598288756736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227841187961, 8.627549021979608 ]
  },
  "id_str" : "900625726910730240",
  "in_reply_to_user_id" : 25743783,
  "text" : "@andrewsu well, that sounds like a really fancy title for everyone doing science? \uD83D\uDE09",
  "id" : 900625726910730240,
  "in_reply_to_status_id" : 900509598288756736,
  "created_at" : "2017-08-24 07:48:00 +0000",
  "in_reply_to_screen_name" : "andrewsu",
  "in_reply_to_user_id_str" : "25743783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Budd\uD83D\uDC3E\uD83D\uDC31",
      "screen_name" : "AidanBudd",
      "indices" : [ 0, 10 ],
      "id_str" : "1435074373",
      "id" : 1435074373
    }, {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 11, 25 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/oyWlGa8Tro",
      "expanded_url" : "https:\/\/www.littlebroken.com\/2016\/10\/04\/apple-walnut-salad-with-balsamic-vinaigrette\/",
      "display_url" : "littlebroken.com\/2016\/10\/04\/app\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "900471326988804100",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11389480980922, 8.7528797254397 ]
  },
  "id_str" : "900480075803627520",
  "in_reply_to_user_id" : 1435074373,
  "text" : "@AidanBudd @NazeefaFatima I second the salad recommendation. Can be super quick, e.g. https:\/\/t.co\/oyWlGa8Tro",
  "id" : 900480075803627520,
  "in_reply_to_status_id" : 900471326988804100,
  "created_at" : "2017-08-23 22:09:14 +0000",
  "in_reply_to_screen_name" : "AidanBudd",
  "in_reply_to_user_id_str" : "1435074373",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 9, 20 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "900378429375250432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233856690016, 8.627524808119976 ]
  },
  "id_str" : "900389586286891008",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @RaeKnowler Ah, too bad. If I wasn\u2019t in London at the time I\u2019d come over for that.",
  "id" : 900389586286891008,
  "in_reply_to_status_id" : 900378429375250432,
  "created_at" : "2017-08-23 16:09:40 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rae Knowler",
      "screen_name" : "RaeKnowler",
      "indices" : [ 53, 64 ],
      "id_str" : "1244114060",
      "id" : 1244114060
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 65, 73 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/58ELBEQA5s",
      "expanded_url" : "https:\/\/twitter.com\/openSNPorg\/status\/900332658978430976",
      "display_url" : "twitter.com\/openSNPorg\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17227341925071, 8.627530403551049 ]
  },
  "id_str" : "900335538535882752",
  "text" : "So sad to miss this one! But maybe something for you @RaeKnowler @betatim. https:\/\/t.co\/58ELBEQA5s",
  "id" : 900335538535882752,
  "created_at" : "2017-08-23 12:34:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Moscrop",
      "screen_name" : "David_Moscrop",
      "indices" : [ 3, 17 ],
      "id_str" : "330574021",
      "id" : 330574021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/TmkVsBamYg",
      "expanded_url" : "https:\/\/link.springer.com\/article\/10.1007\/s11109-016-9373-5?wt_mc=alerts.TOCjournals",
      "display_url" : "link.springer.com\/article\/10.100\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900330966916493312",
  "text" : "RT @David_Moscrop: This is interesting: an experiment on reducing racist harassment on Twitter. https:\/\/t.co\/TmkVsBamYg https:\/\/t.co\/RBKrhT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/David_Moscrop\/status\/900062545318264832\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/RBKrhTKAcA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DH2qA0_UQAAEG3S.jpg",
        "id_str" : "900062431744901120",
        "id" : 900062431744901120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DH2qA0_UQAAEG3S.jpg",
        "sizes" : [ {
          "h" : 722,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 944,
          "resize" : "fit",
          "w" : 1568
        }, {
          "h" : 944,
          "resize" : "fit",
          "w" : 1568
        } ],
        "display_url" : "pic.twitter.com\/RBKrhTKAcA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/TmkVsBamYg",
        "expanded_url" : "https:\/\/link.springer.com\/article\/10.1007\/s11109-016-9373-5?wt_mc=alerts.TOCjournals",
        "display_url" : "link.springer.com\/article\/10.100\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "900062545318264832",
    "text" : "This is interesting: an experiment on reducing racist harassment on Twitter. https:\/\/t.co\/TmkVsBamYg https:\/\/t.co\/RBKrhTKAcA",
    "id" : 900062545318264832,
    "created_at" : "2017-08-22 18:30:07 +0000",
    "user" : {
      "name" : "David Moscrop",
      "screen_name" : "David_Moscrop",
      "protected" : false,
      "id_str" : "330574021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925729962618789888\/w3oVktHK_normal.jpg",
      "id" : 330574021,
      "verified" : true
    }
  },
  "id" : 900330966916493312,
  "created_at" : "2017-08-23 12:16:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "indices" : [ 3, 14 ],
      "id_str" : "201632630",
      "id" : 201632630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/DglCVNHNXt",
      "expanded_url" : "https:\/\/buff.ly\/2vaYZto",
      "display_url" : "buff.ly\/2vaYZto"
    } ]
  },
  "geo" : { },
  "id_str" : "900123869234724865",
  "text" : "RT @BPrainsack: Are you a 23andMe customer?  We'd love to hear your views on how the company is using your data! https:\/\/t.co\/DglCVNHNXt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/DglCVNHNXt",
        "expanded_url" : "https:\/\/buff.ly\/2vaYZto",
        "display_url" : "buff.ly\/2vaYZto"
      } ]
    },
    "geo" : { },
    "id_str" : "900012685315772416",
    "text" : "Are you a 23andMe customer?  We'd love to hear your views on how the company is using your data! https:\/\/t.co\/DglCVNHNXt",
    "id" : 900012685315772416,
    "created_at" : "2017-08-22 15:12:00 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 900123869234724865,
  "created_at" : "2017-08-22 22:33:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 26 ],
      "url" : "https:\/\/t.co\/wVlrncBW4z",
      "expanded_url" : "https:\/\/twitter.com\/biolojical\/status\/892083506716721153",
      "display_url" : "twitter.com\/biolojical\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140334741205, 8.753367632702105 ]
  },
  "id_str" : "900119340011356160",
  "text" : "\uD83C\uDF46\uD83C\uDF56 https:\/\/t.co\/wVlrncBW4z",
  "id" : 900119340011356160,
  "created_at" : "2017-08-22 22:15:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "900091138010476547",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11197947154218, 8.75518170886856 ]
  },
  "id_str" : "900091835938373634",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima you\u2019re running a great project there! Good luck!",
  "id" : 900091835938373634,
  "in_reply_to_status_id" : 900091138010476547,
  "created_at" : "2017-08-22 20:26:31 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/fCOqp7mDIi",
      "expanded_url" : "https:\/\/twitter.com\/NazeefaFatima\/status\/900073999874625536",
      "display_url" : "twitter.com\/NazeefaFatima\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403025146866, 8.7533649965088 ]
  },
  "id_str" : "900087782537920513",
  "text" : "Folks, I just spent 100\u20AC on a rock. And you could do the same! https:\/\/t.co\/fCOqp7mDIi",
  "id" : 900087782537920513,
  "created_at" : "2017-08-22 20:10:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 3, 17 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarSeq",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "900086957241503744",
  "text" : "RT @NazeefaFatima: Our crowdfunding campaign ends soon! \u23F3\u23F0 Please support the #MarSeq project &amp; help make our campaign successful! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NazeefaFatima\/status\/900073999874625536\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/IDBx1kbtzL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DH20g4fXkAEoObi.jpg",
        "id_str" : "900073977556733953",
        "id" : 900073977556733953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DH20g4fXkAEoObi.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/IDBx1kbtzL"
      } ],
      "hashtags" : [ {
        "text" : "MarSeq",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/S9ZAE49foY",
        "expanded_url" : "http:\/\/bit.ly\/marseq",
        "display_url" : "bit.ly\/marseq"
      } ]
    },
    "geo" : { },
    "id_str" : "900073999874625536",
    "text" : "Our crowdfunding campaign ends soon! \u23F3\u23F0 Please support the #MarSeq project &amp; help make our campaign successful! https:\/\/t.co\/S9ZAE49foY https:\/\/t.co\/IDBx1kbtzL",
    "id" : 900073999874625536,
    "created_at" : "2017-08-22 19:15:38 +0000",
    "user" : {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "protected" : false,
      "id_str" : "37054704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/930210077885202432\/DY8D8hGM_normal.jpg",
      "id" : 37054704,
      "verified" : false
    }
  },
  "id" : 900086957241503744,
  "created_at" : "2017-08-22 20:07:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899870661560213504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11197959270257, 8.755181422131539 ]
  },
  "id_str" : "899875417108205569",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette Well, they implemented interactive 3D pie charts. Not sure whether there\u2019s any medium that can showcase the benefits of that.",
  "id" : 899875417108205569,
  "in_reply_to_status_id" : 899870661560213504,
  "created_at" : "2017-08-22 06:06:32 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 0, 14 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899741552255401985",
  "geo" : { },
  "id_str" : "899742135490142208",
  "in_reply_to_user_id" : 257319757,
  "text" : "@lorrainechu3n Taking on more responsibilities to forget the other ones. That, or falling asleep.",
  "id" : 899742135490142208,
  "in_reply_to_status_id" : 899741552255401985,
  "created_at" : "2017-08-21 21:16:56 +0000",
  "in_reply_to_screen_name" : "lorrainechu3n",
  "in_reply_to_user_id_str" : "257319757",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 70, 83 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/WYjBjCeJYe",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/pull\/426",
      "display_url" : "github.com\/openSNP\/snpr\/p\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11402996078434, 8.75336609386258 ]
  },
  "id_str" : "899727790009962496",
  "text" : "I guess now it\u2019ll be really official. If it passes the code review by @PhilippBayer \uD83D\uDE02 https:\/\/t.co\/WYjBjCeJYe",
  "id" : 899727790009962496,
  "created_at" : "2017-08-21 20:19:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 13, 28 ],
      "id_str" : "42558652",
      "id" : 42558652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899593629634899970",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232259677061, 8.627525831863872 ]
  },
  "id_str" : "899594861355159556",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @torstenseemann \u201Esomeone who knows how to accidentally spill some EtBr into their keyboard\u201C",
  "id" : 899594861355159556,
  "in_reply_to_status_id" : 899593629634899970,
  "created_at" : "2017-08-21 11:31:43 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    }, {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 17, 23 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899548505026547712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232973239535, 8.627518110244754 ]
  },
  "id_str" : "899551263687364608",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher @Ravna lunch breaks do show up around noonish each day. Toilet breaks probably too short to show up given the overall resolution of the plots?",
  "id" : 899551263687364608,
  "in_reply_to_status_id" : 899548505026547712,
  "created_at" : "2017-08-21 08:38:28 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linus Schumacher",
      "screen_name" : "LinusSchumacher",
      "indices" : [ 0, 16 ],
      "id_str" : "2289913051",
      "id" : 2289913051
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 33, 41 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899548195654688768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232973239535, 8.627518110244754 ]
  },
  "id_str" : "899551136759283712",
  "in_reply_to_user_id" : 2289913051,
  "text" : "@LinusSchumacher as I replied to @betatim: I don\u2019t think I could stand that longer than 2-3 weeks and even that\u2019s a stretch.",
  "id" : 899551136759283712,
  "in_reply_to_status_id" : 899548195654688768,
  "created_at" : "2017-08-21 08:37:58 +0000",
  "in_reply_to_screen_name" : "LinusSchumacher",
  "in_reply_to_user_id_str" : "2289913051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899540059074031617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231651236061, 8.627547398664156 ]
  },
  "id_str" : "899545701163642881",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette at least the website here has examples. But agree, so often you just get a crappy R vignette and are basically lost about what to do.",
  "id" : 899545701163642881,
  "in_reply_to_status_id" : 899540059074031617,
  "created_at" : "2017-08-21 08:16:22 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "indices" : [ 3, 12 ],
      "id_str" : "1096058449",
      "id" : 1096058449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "899412408900493314",
  "text" : "RT @itatiVCS: Okay. I'm at 1K. Time for a Tayler story: and yes, a Tayler story bc this was before I was Toby. This is why I do ecology.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "899158567604822017",
    "text" : "Okay. I'm at 1K. Time for a Tayler story: and yes, a Tayler story bc this was before I was Toby. This is why I do ecology.",
    "id" : 899158567604822017,
    "created_at" : "2017-08-20 06:38:02 +0000",
    "user" : {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "protected" : false,
      "id_str" : "1096058449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932026012556181505\/DEpx6nxN_normal.jpg",
      "id" : 1096058449,
      "verified" : false
    }
  },
  "id" : 899412408900493314,
  "created_at" : "2017-08-20 23:26:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravna",
      "screen_name" : "Ravna",
      "indices" : [ 0, 6 ],
      "id_str" : "292968981",
      "id" : 292968981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899373641175007232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11161189492888, 8.754867340909684 ]
  },
  "id_str" : "899374137801572354",
  "in_reply_to_user_id" : 292968981,
  "text" : "@Ravna It\u2019s called \u2018RescueTime\u2019, monitors applications &amp; websites you visit. The graphic was done by Gyroscope, which plugs into RTs API.",
  "id" : 899374137801572354,
  "in_reply_to_status_id" : 899373641175007232,
  "created_at" : "2017-08-20 20:54:38 +0000",
  "in_reply_to_screen_name" : "Ravna",
  "in_reply_to_user_id_str" : "292968981",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 0, 9 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899357593415675907",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11161016999998, 8.754871869999997 ]
  },
  "id_str" : "899357825088061440",
  "in_reply_to_user_id" : 92904426,
  "text" : "@Drahflow It\u2019s two things, \u2018Terminator\u2019 and \u2018Preview\u2019 (the graphics viewer of OS X). \uD83D\uDE09",
  "id" : 899357825088061440,
  "in_reply_to_status_id" : 899357593415675907,
  "created_at" : "2017-08-20 19:49:49 +0000",
  "in_reply_to_screen_name" : "Drahflow",
  "in_reply_to_user_id_str" : "92904426",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "899355776019562502",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11161016999998, 8.75487187 ]
  },
  "id_str" : "899357424456544256",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim Last few weeks were between 50-60h, but don\u2019t think that 70 is feasible for more than 2-3 without quickly sacrificing mental health.",
  "id" : 899357424456544256,
  "in_reply_to_status_id" : 899355776019562502,
  "created_at" : "2017-08-20 19:48:13 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/899353290277879808\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/HZfRz2otwa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHsk_nXWAAAboRu.jpg",
      "id_str" : "899353225907798016",
      "id" : 899353225907798016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHsk_nXWAAAboRu.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/HZfRz2otwa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11159976416699, 8.754682561222554 ]
  },
  "id_str" : "899353290277879808",
  "text" : "I\u2019m kind of convinced that everyone who claims to work 80h a week is lying. \uD83D\uDE34 https:\/\/t.co\/HZfRz2otwa",
  "id" : 899353290277879808,
  "created_at" : "2017-08-20 19:31:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897938664830808064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403943191031, 8.753389758245355 ]
  },
  "id_str" : "897961182107226112",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai Congratulations! :)",
  "id" : 897961182107226112,
  "in_reply_to_status_id" : 897938664830808064,
  "created_at" : "2017-08-16 23:20:03 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farah Z Khan \uD83D\uDC53\u270F\uFE0F \uD83D\uDCD3",
      "screen_name" : "farahzk03",
      "indices" : [ 0, 10 ],
      "id_str" : "1138409204",
      "id" : 1138409204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897635277761589249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229709379414, 8.62754279736778 ]
  },
  "id_str" : "897703315580096513",
  "in_reply_to_user_id" : 1138409204,
  "text" : "@farahzk03 thanks, back to writing already \uD83D\uDE0A",
  "id" : 897703315580096513,
  "in_reply_to_status_id" : 897635277761589249,
  "created_at" : "2017-08-16 06:15:23 +0000",
  "in_reply_to_screen_name" : "farahzk03",
  "in_reply_to_user_id_str" : "1138409204",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "indices" : [ 3, 14 ],
      "id_str" : "6745972",
      "id" : 6745972
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 61, 69 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ARwYjrRTts",
      "expanded_url" : "https:\/\/www.nytimes.com\/2017\/08\/12\/opinion\/why-women-had-better-sex-under-socialism.html",
      "display_url" : "nytimes.com\/2017\/08\/12\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "897703245665226752",
  "text" : "RT @bella_velo: Why Women Had Better Sex Under Socialism via @NYTimes https:\/\/t.co\/ARwYjrRTts",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 45, 53 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/ARwYjrRTts",
        "expanded_url" : "https:\/\/www.nytimes.com\/2017\/08\/12\/opinion\/why-women-had-better-sex-under-socialism.html",
        "display_url" : "nytimes.com\/2017\/08\/12\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "897600636631617536",
    "text" : "Why Women Had Better Sex Under Socialism via @NYTimes https:\/\/t.co\/ARwYjrRTts",
    "id" : 897600636631617536,
    "created_at" : "2017-08-15 23:27:23 +0000",
    "user" : {
      "name" : "\uD83D\uDCABKelsey Merkley \uD83D\uDCAB",
      "screen_name" : "bella_velo",
      "protected" : false,
      "id_str" : "6745972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875913994929934336\/1aiBO2bG_normal.jpg",
      "id" : 6745972,
      "verified" : false
    }
  },
  "id" : 897703245665226752,
  "created_at" : "2017-08-16 06:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897550097373941762",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392004094402, 8.753030427197254 ]
  },
  "id_str" : "897556398023770113",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg \uD83D\uDE0D\uD83D\uDE0D\uD83D\uDE0D",
  "id" : 897556398023770113,
  "in_reply_to_status_id" : 897550097373941762,
  "created_at" : "2017-08-15 20:31:35 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark O. Martin",
      "screen_name" : "markowenmartin",
      "indices" : [ 0, 15 ],
      "id_str" : "303598509",
      "id" : 303598509
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 16, 25 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 26, 33 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Micropia",
      "screen_name" : "Micropia",
      "indices" : [ 34, 43 ],
      "id_str" : "2482016394",
      "id" : 2482016394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/HzQWYSeDTx",
      "expanded_url" : "https:\/\/instagram.com\/p\/-9Ht9phwvv\/",
      "display_url" : "instagram.com\/p\/-9Ht9phwvv\/"
    } ]
  },
  "in_reply_to_status_id_str" : "897517319059939329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231701507353, 8.627527151195299 ]
  },
  "id_str" : "897517519807938568",
  "in_reply_to_user_id" : 303598509,
  "text" : "@markowenmartin @kbradnam @sujaik @Micropia They must have changed the rules! https:\/\/t.co\/HzQWYSeDTx",
  "id" : 897517519807938568,
  "in_reply_to_status_id" : 897517319059939329,
  "created_at" : "2017-08-15 17:57:06 +0000",
  "in_reply_to_screen_name" : "markowenmartin",
  "in_reply_to_user_id_str" : "303598509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 8, 17 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Micropia",
      "screen_name" : "Micropia",
      "indices" : [ 18, 27 ],
      "id_str" : "2482016394",
      "id" : 2482016394
    }, {
      "name" : "Mark O. Martin",
      "screen_name" : "markowenmartin",
      "indices" : [ 28, 43 ],
      "id_str" : "303598509",
      "id" : 303598509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897448775198720000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233482566343, 8.627526114569134 ]
  },
  "id_str" : "897448964303183872",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @kbradnam @Micropia @markowenmartin absolutely! :)",
  "id" : 897448964303183872,
  "in_reply_to_status_id" : 897448775198720000,
  "created_at" : "2017-08-15 13:24:41 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897413441627070464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232359966903, 8.627538779093115 ]
  },
  "id_str" : "897415294863454208",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute Oh, you\u2019re the best! And I\u2019m so jealous of the trip, enjoy it!",
  "id" : 897415294863454208,
  "in_reply_to_status_id" : 897413441627070464,
  "created_at" : "2017-08-15 11:10:54 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Hodges",
      "screen_name" : "tbyhdgs",
      "indices" : [ 0, 8 ],
      "id_str" : "3097680891",
      "id" : 3097680891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897361222227681280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172308802103, 8.62753449462424 ]
  },
  "id_str" : "897361879789703168",
  "in_reply_to_user_id" : 3097680891,
  "text" : "@tbyhdgs Danke! It restarted just fine after a while. :)",
  "id" : 897361879789703168,
  "in_reply_to_status_id" : 897361222227681280,
  "created_at" : "2017-08-15 07:38:38 +0000",
  "in_reply_to_screen_name" : "tbyhdgs",
  "in_reply_to_user_id_str" : "3097680891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Hodges",
      "screen_name" : "tbyhdgs",
      "indices" : [ 0, 8 ],
      "id_str" : "3097680891",
      "id" : 3097680891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/ylEUXJZb6m",
      "expanded_url" : "https:\/\/68.media.tumblr.com\/0d8c30b4ed1236e4c928f43868e18756\/tumblr_oi5iahoU7Q1t5dv58o1_500.gif",
      "display_url" : "68.media.tumblr.com\/0d8c30b4ed1236\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "897361607646486528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172308802103, 8.62753449462424 ]
  },
  "id_str" : "897361787363917824",
  "in_reply_to_user_id" : 3097680891,
  "text" : "@tbyhdgs \u201Ebut my data was backed up so well!\u201C https:\/\/t.co\/ylEUXJZb6m",
  "id" : 897361787363917824,
  "in_reply_to_status_id" : 897361607646486528,
  "created_at" : "2017-08-15 07:38:16 +0000",
  "in_reply_to_screen_name" : "tbyhdgs",
  "in_reply_to_user_id_str" : "3097680891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Hodges",
      "screen_name" : "tbyhdgs",
      "indices" : [ 0, 8 ],
      "id_str" : "3097680891",
      "id" : 3097680891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897360975220834305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232551160858, 8.627537303633742 ]
  },
  "id_str" : "897361322408628224",
  "in_reply_to_user_id" : 3097680891,
  "text" : "@tbyhdgs I assume if Github, Dropbox, 2 HDDs plus the SSD in my notebook completely die I\u2019ll have other issues than data loss. \uD83D\uDE31",
  "id" : 897361322408628224,
  "in_reply_to_status_id" : 897360975220834305,
  "created_at" : "2017-08-15 07:36:26 +0000",
  "in_reply_to_screen_name" : "tbyhdgs",
  "in_reply_to_user_id_str" : "3097680891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Hodges",
      "screen_name" : "tbyhdgs",
      "indices" : [ 0, 8 ],
      "id_str" : "3097680891",
      "id" : 3097680891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897360507421827072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17229352062154, 8.62753355363783 ]
  },
  "id_str" : "897360710396780545",
  "in_reply_to_user_id" : 3097680891,
  "text" : "@tbyhdgs that\u2019s the reason I have four backups, two of them offsite \uD83D\uDE09",
  "id" : 897360710396780545,
  "in_reply_to_status_id" : 897360507421827072,
  "created_at" : "2017-08-15 07:34:00 +0000",
  "in_reply_to_screen_name" : "tbyhdgs",
  "in_reply_to_user_id_str" : "3097680891",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/897338139974520832\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Y3PFtOq3Rz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHP8PWFXkAAfLLC.jpg",
      "id_str" : "897338091333193728",
      "id" : 897338091333193728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHP8PWFXkAAfLLC.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Y3PFtOq3Rz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231367915501, 8.627535109134449 ]
  },
  "id_str" : "897338139974520832",
  "text" : "One of the messages you don\u2019t want to see while writing up your thesis. https:\/\/t.co\/Y3PFtOq3Rz",
  "id" : 897338139974520832,
  "created_at" : "2017-08-15 06:04:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Lorenz K. Adlung on\/off Berg",
      "screen_name" : "LorenzAdlung",
      "indices" : [ 0, 13 ],
      "id_str" : "1623124639",
      "id" : 1623124639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897181779018338307",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403025307477, 8.753370873659795 ]
  },
  "id_str" : "897186292068429824",
  "in_reply_to_user_id" : 1623124639,
  "text" : "@LorenzAdlung It\u2019s low tech but a good way to have all notes, outlines etc in one place.",
  "id" : 897186292068429824,
  "in_reply_to_status_id" : 897181779018338307,
  "created_at" : "2017-08-14 20:00:55 +0000",
  "in_reply_to_screen_name" : "LorenzAdlung",
  "in_reply_to_user_id_str" : "1623124639",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Lorenz K. Adlung on\/off Berg",
      "screen_name" : "LorenzAdlung",
      "indices" : [ 0, 13 ],
      "id_str" : "1623124639",
      "id" : 1623124639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897177422273105921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17155387443506, 8.627444738530206 ]
  },
  "id_str" : "897178789746270210",
  "in_reply_to_user_id" : 1623124639,
  "text" : "@LorenzAdlung That\u2019s manually writing a markdown table and having it rendered on GitHub \u263A\uFE0F",
  "id" : 897178789746270210,
  "in_reply_to_status_id" : 897177422273105921,
  "created_at" : "2017-08-14 19:31:06 +0000",
  "in_reply_to_screen_name" : "LorenzAdlung",
  "in_reply_to_user_id_str" : "1623124639",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/897170363116904448\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/NahZ9H2iP9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DHNjsBVXkAAHNNB.jpg",
      "id_str" : "897170358700314624",
      "id" : 897170358700314624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHNjsBVXkAAHNNB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 389
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 389
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 389
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 389
      } ],
      "display_url" : "pic.twitter.com\/NahZ9H2iP9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232728401487, 8.627518620187884 ]
  },
  "id_str" : "897170363116904448",
  "text" : "34 days into the writing process\u2026 \uD83D\uDE34 https:\/\/t.co\/NahZ9H2iP9",
  "id" : 897170363116904448,
  "created_at" : "2017-08-14 18:57:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 3, 12 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/un29ttfSJ8",
      "expanded_url" : "http:\/\/www.madeleineball.net\/data-privacy-and-power\/",
      "display_url" : "madeleineball.net\/data-privacy-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "897132291188764674",
  "text" : "RT @madprime: \"Data, Privacy, and Power\" \u2013 some thoughts from me. (4 minute read)\nhttps:\/\/t.co\/un29ttfSJ8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/un29ttfSJ8",
        "expanded_url" : "http:\/\/www.madeleineball.net\/data-privacy-and-power\/",
        "display_url" : "madeleineball.net\/data-privacy-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "897131668384788480",
    "text" : "\"Data, Privacy, and Power\" \u2013 some thoughts from me. (4 minute read)\nhttps:\/\/t.co\/un29ttfSJ8",
    "id" : 897131668384788480,
    "created_at" : "2017-08-14 16:23:52 +0000",
    "user" : {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "protected" : false,
      "id_str" : "71557700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515539302931910656\/9N7oFHFZ_normal.png",
      "id" : 71557700,
      "verified" : false
    }
  },
  "id" : 897132291188764674,
  "created_at" : "2017-08-14 16:26:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897059337436184576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234081874463, 8.627503247308272 ]
  },
  "id_str" : "897089734136221696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer looks like there\u2019s some \uD83D\uDC3B in the mix as well \uD83D\uDE09\uD83D\uDE0D",
  "id" : 897089734136221696,
  "in_reply_to_status_id" : 897059337436184576,
  "created_at" : "2017-08-14 13:37:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "897059741796401153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234081874463, 8.627503247308272 ]
  },
  "id_str" : "897089550975205376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that sounds a lot like his dad! \uD83D\uDE02",
  "id" : 897089550975205376,
  "in_reply_to_status_id" : 897059741796401153,
  "created_at" : "2017-08-14 13:36:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 25, 35 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    }, {
      "name" : "Jeroen Bosman",
      "screen_name" : "jeroenbosman",
      "indices" : [ 36, 49 ],
      "id_str" : "9104202",
      "id" : 9104202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896823542054092801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11396853201099, 8.75330589434024 ]
  },
  "id_str" : "896871067783802881",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @Protohedgehog @l_matthia @jeroenbosman About the extreme geekiness? ;)",
  "id" : 896871067783802881,
  "in_reply_to_status_id" : 896823542054092801,
  "created_at" : "2017-08-13 23:08:20 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fran \u267F\u26A7\uD83C\uDF08",
      "screen_name" : "fran_k_ly",
      "indices" : [ 3, 13 ],
      "id_str" : "596875932",
      "id" : 596875932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "896753147728801799",
  "text" : "RT @fran_k_ly: I'm extremely tired of people holding up Germany as the pinnacle of anti-Nazism when we have a festering Nazi problem oursel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "896722439471812609",
    "text" : "I'm extremely tired of people holding up Germany as the pinnacle of anti-Nazism when we have a festering Nazi problem ourselves.",
    "id" : 896722439471812609,
    "created_at" : "2017-08-13 13:17:44 +0000",
    "user" : {
      "name" : "fran \u267F\u26A7\uD83C\uDF08",
      "screen_name" : "fran_k_ly",
      "protected" : false,
      "id_str" : "596875932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897035772423000064\/Tn0U32jm_normal.jpg",
      "id" : 596875932,
      "verified" : false
    }
  },
  "id" : 896753147728801799,
  "created_at" : "2017-08-13 15:19:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katharina",
      "screen_name" : "katheyrina",
      "indices" : [ 3, 14 ],
      "id_str" : "730326143295959040",
      "id" : 730326143295959040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/QhDWg3eyfi",
      "expanded_url" : "https:\/\/twitter.com\/katheyrina\/status\/896029064896663552",
      "display_url" : "twitter.com\/katheyrina\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "896699023566020608",
  "text" : "RT @katheyrina: Last call! Course starts tomorrow \uD83E\uDD13\uD83D\uDCBB\uD83D\uDCAA https:\/\/t.co\/QhDWg3eyfi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/QhDWg3eyfi",
        "expanded_url" : "https:\/\/twitter.com\/katheyrina\/status\/896029064896663552",
        "display_url" : "twitter.com\/katheyrina\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "896698696775213056",
    "text" : "Last call! Course starts tomorrow \uD83E\uDD13\uD83D\uDCBB\uD83D\uDCAA https:\/\/t.co\/QhDWg3eyfi",
    "id" : 896698696775213056,
    "created_at" : "2017-08-13 11:43:23 +0000",
    "user" : {
      "name" : "Katharina",
      "screen_name" : "katheyrina",
      "protected" : false,
      "id_str" : "730326143295959040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885460122394349569\/oHlt5LK-_normal.jpg",
      "id" : 730326143295959040,
      "verified" : false
    }
  },
  "id" : 896699023566020608,
  "created_at" : "2017-08-13 11:44:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Wacha",
      "screen_name" : "megwacha",
      "indices" : [ 3, 12 ],
      "id_str" : "78285757",
      "id" : 78285757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 32, 43 ]
    }, {
      "text" : "Wikimania",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "896680931758678016",
  "text" : "RT @megwacha: How do we advance #openaccess? Elbakyan suggests we eliminate copyright law for research and educational content #Wikimania",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 18, 29 ]
      }, {
        "text" : "Wikimania",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "896392616920666112",
    "text" : "How do we advance #openaccess? Elbakyan suggests we eliminate copyright law for research and educational content #Wikimania",
    "id" : 896392616920666112,
    "created_at" : "2017-08-12 15:27:08 +0000",
    "user" : {
      "name" : "Megan Wacha",
      "screen_name" : "megwacha",
      "protected" : false,
      "id_str" : "78285757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794387140885041154\/A1AeCbbh_normal.jpg",
      "id" : 78285757,
      "verified" : false
    }
  },
  "id" : 896680931758678016,
  "created_at" : "2017-08-13 10:32:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "indices" : [ 3, 12 ],
      "id_str" : "1096058449",
      "id" : 1096058449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "896444344655376384",
  "text" : "RT @itatiVCS: I keep seeing people acting surprised that there's Nazis running around Cville talking abt 'needing shooters'\nWhy are y'all s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "896425268742545408",
    "text" : "I keep seeing people acting surprised that there's Nazis running around Cville talking abt 'needing shooters'\nWhy are y'all surprised?",
    "id" : 896425268742545408,
    "created_at" : "2017-08-12 17:36:53 +0000",
    "user" : {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "protected" : false,
      "id_str" : "1096058449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932026012556181505\/DEpx6nxN_normal.jpg",
      "id" : 1096058449,
      "verified" : false
    }
  },
  "id" : 896444344655376384,
  "created_at" : "2017-08-12 18:52:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "indices" : [ 3, 15 ],
      "id_str" : "27513314",
      "id" : 27513314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "896421093925367808",
  "text" : "RT @ConnerHabib: As long a people like Sam Harris, Richard Dawkins, and Jordan Peterson promote Islamophobia, this is their crowd.\nThis is\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ConnerHabib\/status\/896391389063241728\/photo\/1",
        "indices" : [ 140, 163 ],
        "url" : "https:\/\/t.co\/ROeMGAocpx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DHCfNu9VYAAiyKO.jpg",
        "id_str" : "896391384139128832",
        "id" : 896391384139128832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DHCfNu9VYAAiyKO.jpg",
        "sizes" : [ {
          "h" : 714,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/ROeMGAocpx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "896391389063241728",
    "text" : "As long a people like Sam Harris, Richard Dawkins, and Jordan Peterson promote Islamophobia, this is their crowd.\nThis is who they empower. https:\/\/t.co\/ROeMGAocpx",
    "id" : 896391389063241728,
    "created_at" : "2017-08-12 15:22:15 +0000",
    "user" : {
      "name" : "Conner Habib",
      "screen_name" : "ConnerHabib",
      "protected" : false,
      "id_str" : "27513314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921495228984332289\/LhDY3muU_normal.jpg",
      "id" : 27513314,
      "verified" : true
    }
  },
  "id" : 896421093925367808,
  "created_at" : "2017-08-12 17:20:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "indices" : [ 0, 9 ],
      "id_str" : "1096058449",
      "id" : 1096058449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896420687522308096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395025071698, 8.748996919029159 ]
  },
  "id_str" : "896420962475753473",
  "in_reply_to_user_id" : 1096058449,
  "text" : "@itatiVCS \uD83D\uDE0D",
  "id" : 896420962475753473,
  "in_reply_to_status_id" : 896420687522308096,
  "created_at" : "2017-08-12 17:19:46 +0000",
  "in_reply_to_screen_name" : "itatiVCS",
  "in_reply_to_user_id_str" : "1096058449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Servan Gr\u00FCninger",
      "screen_name" : "SGruninger",
      "indices" : [ 0, 11 ],
      "id_str" : "1361723136",
      "id" : 1361723136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896417120258580482",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11441911520635, 8.746525399681689 ]
  },
  "id_str" : "896420055700910080",
  "in_reply_to_user_id" : 1361723136,
  "text" : "@SGruninger I fear I\u2019m guilty, there were some experiments that ended up in the file drawer.",
  "id" : 896420055700910080,
  "in_reply_to_status_id" : 896417120258580482,
  "created_at" : "2017-08-12 17:16:10 +0000",
  "in_reply_to_screen_name" : "SGruninger",
  "in_reply_to_user_id_str" : "1361723136",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itati de los angeles",
      "screen_name" : "itatiVCS",
      "indices" : [ 0, 9 ],
      "id_str" : "1096058449",
      "id" : 1096058449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896415672275681280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1144614210819, 8.746476145469346 ]
  },
  "id_str" : "896419832014536704",
  "in_reply_to_user_id" : 1096058449,
  "text" : "@itatiVCS Awww, that\u2019s cool! \uD83C\uDF43\uD83C\uDF3F\uD83C\uDF31 hope their partner was into plants as much! \uD83D\uDE02",
  "id" : 896419832014536704,
  "in_reply_to_status_id" : 896415672275681280,
  "created_at" : "2017-08-12 17:15:17 +0000",
  "in_reply_to_screen_name" : "itatiVCS",
  "in_reply_to_user_id_str" : "1096058449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DatingWhileScientist",
      "indices" : [ 0, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/320r3OWJjt",
      "expanded_url" : "https:\/\/instagram.com\/p\/BWKVI3hF5II\/",
      "display_url" : "instagram.com\/p\/BWKVI3hF5II\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17150289188579, 8.627804353876254 ]
  },
  "id_str" : "896414998641209348",
  "text" : "#DatingWhileScientist can mean ending up with wedding bands that have a normal distribution engraved. https:\/\/t.co\/320r3OWJjt",
  "id" : 896414998641209348,
  "created_at" : "2017-08-12 16:56:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896318229056020480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231367237819, 8.62755477215841 ]
  },
  "id_str" : "896383706981695488",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab Aye :)",
  "id" : 896383706981695488,
  "in_reply_to_status_id" : 896318229056020480,
  "created_at" : "2017-08-12 14:51:44 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "felix sch_er",
      "screen_name" : "derKorbinian",
      "indices" : [ 0, 13 ],
      "id_str" : "2888841267",
      "id" : 2888841267
    }, {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 14, 29 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896374830362243072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234134711462, 8.627527091490563 ]
  },
  "id_str" : "896375420865708032",
  "in_reply_to_user_id" : 2888841267,
  "text" : "@derKorbinian @TheConstructor absolutely :)",
  "id" : 896375420865708032,
  "in_reply_to_status_id" : 896374830362243072,
  "created_at" : "2017-08-12 14:18:48 +0000",
  "in_reply_to_screen_name" : "derKorbinian",
  "in_reply_to_user_id_str" : "2888841267",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 124, 139 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231073231105, 8.627544112962521 ]
  },
  "id_str" : "896374566133616642",
  "text" : "Sitting in the office all day, but at least I\u2019m wearing my \u201EBecome a scientist! Work on your free weekends!\u201C-shirt thanks 2 @TheConstructor!",
  "id" : 896374566133616642,
  "created_at" : "2017-08-12 14:15:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896308736175874048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239308417303, 8.627506577764455 ]
  },
  "id_str" : "896316798651559936",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab \u201CHow many species are there you ask me? Let me ask a counter question: which species concept do you happen to believe in?\u201D",
  "id" : 896316798651559936,
  "in_reply_to_status_id" : 896308736175874048,
  "created_at" : "2017-08-12 10:25:52 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Rich Boden FLS",
      "screen_name" : "BodenLab",
      "indices" : [ 0, 9 ],
      "id_str" : "455992362",
      "id" : 455992362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896308736175874048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239308417303, 8.627506577764455 ]
  },
  "id_str" : "896316663548825600",
  "in_reply_to_user_id" : 455992362,
  "text" : "@BodenLab I think the first point is the most important one.",
  "id" : 896316663548825600,
  "in_reply_to_status_id" : 896308736175874048,
  "created_at" : "2017-08-12 10:25:20 +0000",
  "in_reply_to_screen_name" : "BodenLab",
  "in_reply_to_user_id_str" : "455992362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Mhg0K4y3CO",
      "expanded_url" : "http:\/\/www.asmscience.org.sci-hub.cc\/content\/journal\/microbiolspec\/10.1128\/microbiolspec.FUNK-0052-2016",
      "display_url" : "asmscience.org.sci-hub.cc\/content\/journa\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231783825464, 8.627533349770045 ]
  },
  "id_str" : "896307480703184897",
  "text" : "How many fungal species are there? Depends on how you count. \uD83D\uDE09 https:\/\/t.co\/Mhg0K4y3CO",
  "id" : 896307480703184897,
  "created_at" : "2017-08-12 09:48:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/rFPpOLSVUg",
      "expanded_url" : "https:\/\/twitter.com\/notSoJunkDNA\/status\/896160513674977280",
      "display_url" : "twitter.com\/notSoJunkDNA\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140318512551, 8.753372565425067 ]
  },
  "id_str" : "896161514612072448",
  "text" : "Next up: paper on how your DNA-based, personalized rug can be used for writing malware that makes our cat pee on it.  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/rFPpOLSVUg",
  "id" : 896161514612072448,
  "created_at" : "2017-08-12 00:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quinnsplainer ' ; DROP TABLE altright_users",
      "screen_name" : "quinnnorton",
      "indices" : [ 0, 12 ],
      "id_str" : "38975663",
      "id" : 38975663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/ogMXbWgKbc",
      "expanded_url" : "https:\/\/twitter.com\/ianholmes\/status\/895654694583803904",
      "display_url" : "twitter.com\/ianholmes\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "896127457379573760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394275139294, 8.753150788782039 ]
  },
  "id_str" : "896148084157054977",
  "in_reply_to_user_id" : 38975663,
  "text" : "@quinnnorton My fav: https:\/\/t.co\/ogMXbWgKbc",
  "id" : 896148084157054977,
  "in_reply_to_status_id" : 896127457379573760,
  "created_at" : "2017-08-11 23:15:27 +0000",
  "in_reply_to_screen_name" : "quinnnorton",
  "in_reply_to_user_id_str" : "38975663",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shahak Shapira",
      "screen_name" : "ShahakShapira",
      "indices" : [ 3, 17 ],
      "id_str" : "4307446636",
      "id" : 4307446636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HEYTWITTER",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "896099100776513537",
  "text" : "RT @ShahakShapira: I reported about 300 hate tweets. Twitter didn't delete 'em, so I sprayed them in front of their office #HEYTWITTER \nhtt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HEYTWITTER",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wPqiwaxd7J",
        "expanded_url" : "https:\/\/youtu.be\/jzMTBINlLFU",
        "display_url" : "youtu.be\/jzMTBINlLFU"
      } ]
    },
    "geo" : { },
    "id_str" : "894497226189402112",
    "text" : "I reported about 300 hate tweets. Twitter didn't delete 'em, so I sprayed them in front of their office #HEYTWITTER \nhttps:\/\/t.co\/wPqiwaxd7J",
    "id" : 894497226189402112,
    "created_at" : "2017-08-07 09:55:32 +0000",
    "user" : {
      "name" : "Shahak Shapira",
      "screen_name" : "ShahakShapira",
      "protected" : false,
      "id_str" : "4307446636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889589605703593986\/lz3_VorW_normal.jpg",
      "id" : 4307446636,
      "verified" : true
    }
  },
  "id" : 896099100776513537,
  "created_at" : "2017-08-11 20:00:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teon L Brooks, PhD",
      "screen_name" : "teon_io",
      "indices" : [ 3, 11 ],
      "id_str" : "30960103",
      "id" : 30960103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "896076549442592770",
  "text" : "RT @teon_io: Mental health is a very important topic that must be discussed more in academia and there needs to be a stronger support syste\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 135, 158 ],
        "url" : "https:\/\/t.co\/cUAJppSnVa",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/895932455596720128",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "896070774640988160",
    "text" : "Mental health is a very important topic that must be discussed more in academia and there needs to be a stronger support system for it https:\/\/t.co\/cUAJppSnVa",
    "id" : 896070774640988160,
    "created_at" : "2017-08-11 18:08:15 +0000",
    "user" : {
      "name" : "Teon L Brooks, PhD",
      "screen_name" : "teon_io",
      "protected" : false,
      "id_str" : "30960103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/831627250957049857\/aYrScuvL_normal.jpg",
      "id" : 30960103,
      "verified" : false
    }
  },
  "id" : 896076549442592770,
  "created_at" : "2017-08-11 18:31:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Alfredo Carpineti",
      "screen_name" : "DrCarpineti",
      "indices" : [ 0, 12 ],
      "id_str" : "19183987",
      "id" : 19183987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896050305456001025",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233632783842, 8.627531151679534 ]
  },
  "id_str" : "896050820264767488",
  "in_reply_to_user_id" : 19183987,
  "text" : "@DrCarpineti now it\u2019s just grinding w\/o end. \uD83D\uDE09",
  "id" : 896050820264767488,
  "in_reply_to_status_id" : 896050305456001025,
  "created_at" : "2017-08-11 16:48:58 +0000",
  "in_reply_to_screen_name" : "DrCarpineti",
  "in_reply_to_user_id_str" : "19183987",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Alfredo Carpineti",
      "screen_name" : "DrCarpineti",
      "indices" : [ 0, 12 ],
      "id_str" : "19183987",
      "id" : 19183987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896047876773617664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233199477811, 8.627532574638382 ]
  },
  "id_str" : "896049129964670980",
  "in_reply_to_user_id" : 19183987,
  "text" : "@DrCarpineti ever since the update to kink v3.4.2 it\u2019s just not the same any longer. The classes are totally imbalanced and playing a wizard sucks now \uD83D\uDE02",
  "id" : 896049129964670980,
  "in_reply_to_status_id" : 896047876773617664,
  "created_at" : "2017-08-11 16:42:15 +0000",
  "in_reply_to_screen_name" : "DrCarpineti",
  "in_reply_to_user_id_str" : "19183987",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Alfredo Carpineti",
      "screen_name" : "DrCarpineti",
      "indices" : [ 0, 12 ],
      "id_str" : "19183987",
      "id" : 19183987
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/896047425835741187\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/3NhuiB6qgP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DG9mYUxXUAE3cms.jpg",
      "id_str" : "896047418948669441",
      "id" : 896047418948669441,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DG9mYUxXUAE3cms.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/3NhuiB6qgP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896014889352912900",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239910347244, 8.62746273475634 ]
  },
  "id_str" : "896047425835741187",
  "in_reply_to_user_id" : 19183987,
  "text" : "@DrCarpineti Punctuation added later to improve legibility \uD83D\uDE02\uD83E\uDD14 https:\/\/t.co\/3NhuiB6qgP",
  "id" : 896047425835741187,
  "in_reply_to_status_id" : 896014889352912900,
  "created_at" : "2017-08-11 16:35:28 +0000",
  "in_reply_to_screen_name" : "DrCarpineti",
  "in_reply_to_user_id_str" : "19183987",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David K Smith",
      "screen_name" : "professor_dave",
      "indices" : [ 0, 15 ],
      "id_str" : "173968705",
      "id" : 173968705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895906933214982144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236407356999, 8.627502672035966 ]
  },
  "id_str" : "895960720331952134",
  "in_reply_to_user_id" : 173968705,
  "text" : "@professor_dave Wait, how else are you supposed to eat those?!",
  "id" : 895960720331952134,
  "in_reply_to_status_id" : 895906933214982144,
  "created_at" : "2017-08-11 10:50:56 +0000",
  "in_reply_to_screen_name" : "professor_dave",
  "in_reply_to_user_id_str" : "173968705",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 0, 9 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895781446832410624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17238620896082, 8.627489965369554 ]
  },
  "id_str" : "895948058877468672",
  "in_reply_to_user_id" : 2362226100,
  "text" : "@InfinoMe You\u2019d assume that wouldn\u2019t be necessary, given that half of bioinformatics solutions are a bunch of perl scripts that hide under a coat. \uD83D\uDE02",
  "id" : 895948058877468672,
  "in_reply_to_status_id" : 895781446832410624,
  "created_at" : "2017-08-11 10:00:37 +0000",
  "in_reply_to_screen_name" : "InfinoMe",
  "in_reply_to_user_id_str" : "2362226100",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Sz8Z1suoMN",
      "expanded_url" : "https:\/\/www.theguardian.com\/science\/head-quarters\/2017\/aug\/10\/the-human-cost-of-the-pressures-of-postdoctoral-research?CMP=Share_iOSApp_Other",
      "display_url" : "theguardian.com\/science\/head-q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "895932455596720128",
  "text" : "The human cost of the pressures of postdoctoral research https:\/\/t.co\/Sz8Z1suoMN",
  "id" : 895932455596720128,
  "created_at" : "2017-08-11 08:58:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/agWCG5fPF7",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/895761788968501249",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895761776624758785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403073366559, 8.75337018779999 ]
  },
  "id_str" : "895762455623860226",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon I think you can skip the flash drive, non-negligible amount of people will blindly follow install instructions. https:\/\/t.co\/agWCG5fPF7",
  "id" : 895762455623860226,
  "in_reply_to_status_id" : 895761776624758785,
  "created_at" : "2017-08-10 21:43:06 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/v7LZsigmlT",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/895759716181303296",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895759716181303296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403218617924, 8.753372759093574 ]
  },
  "id_str" : "895761788968501249",
  "in_reply_to_user_id" : 14286491,
  "text" : "Just promise people a faster short read aligner, put some \u2018curl |sudo bash\u2019 in the INSTALL.md and you\u2019re done. \uD83D\uDE02 https:\/\/t.co\/v7LZsigmlT",
  "id" : 895761788968501249,
  "in_reply_to_status_id" : 895759716181303296,
  "created_at" : "2017-08-10 21:40:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/U4wUFg0xOM",
      "expanded_url" : "https:\/\/boingboing.net\/2017\/08\/10\/computer-viruses.html",
      "display_url" : "boingboing.net\/2017\/08\/10\/com\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403302683144, 8.753374247245752 ]
  },
  "id_str" : "895759716181303296",
  "text" : "Given IT Sec found in a typical lab I\u2019m nearly certain you don\u2019t have to synthesize DNA to plant malware there. https:\/\/t.co\/U4wUFg0xOM",
  "id" : 895759716181303296,
  "created_at" : "2017-08-10 21:32:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "NCBI Staff",
      "screen_name" : "NCBI",
      "indices" : [ 9, 14 ],
      "id_str" : "20746400",
      "id" : 20746400
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 15, 23 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895681301709193216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11450467170226, 8.746688878171842 ]
  },
  "id_str" : "895710930490855424",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @NCBI @kaiblin I wonder: is there any standards that say that species names need to be ASCII? Asking for a friend. \uD83D\uDE48\uD83E\uDD14",
  "id" : 895710930490855424,
  "in_reply_to_status_id" : 895681301709193216,
  "created_at" : "2017-08-10 18:18:21 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/9MY6anDQcz",
      "expanded_url" : "https:\/\/twitter.com\/IBJIYONGI\/status\/895016343245692928",
      "display_url" : "twitter.com\/IBJIYONGI\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "895659853124947969",
  "text" : "RT @ctitusbrown: This message applies SO widely! https:\/\/t.co\/9MY6anDQcz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/9MY6anDQcz",
        "expanded_url" : "https:\/\/twitter.com\/IBJIYONGI\/status\/895016343245692928",
        "display_url" : "twitter.com\/IBJIYONGI\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "895608745534902272",
    "text" : "This message applies SO widely! https:\/\/t.co\/9MY6anDQcz",
    "id" : 895608745534902272,
    "created_at" : "2017-08-10 11:32:19 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 895659853124947969,
  "created_at" : "2017-08-10 14:55:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Chanda Prescod-Weinstein \uD83C\uDDE7\uD83C\uDDE7",
      "screen_name" : "IBJIYONGI",
      "indices" : [ 3, 13 ],
      "id_str" : "14981648",
      "id" : 14981648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "895659829301260292",
  "text" : "RT @IBJIYONGI: Sorry men in physics and astronomy but your emails and FB messages telling me that you can't stand me are super unoriginal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "895015395207200768",
    "text" : "Sorry men in physics and astronomy but your emails and FB messages telling me that you can't stand me are super unoriginal",
    "id" : 895015395207200768,
    "created_at" : "2017-08-08 20:14:33 +0000",
    "user" : {
      "name" : "Dr. Chanda Prescod-Weinstein \uD83C\uDDE7\uD83C\uDDE7",
      "screen_name" : "IBJIYONGI",
      "protected" : false,
      "id_str" : "14981648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/887110118155878400\/5V_fLEf__normal.jpg",
      "id" : 14981648,
      "verified" : true
    }
  },
  "id" : 895659829301260292,
  "created_at" : "2017-08-10 14:55:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 0, 14 ],
      "id_str" : "636216638",
      "id" : 636216638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895559012153950208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233306334216, 8.627523738680955 ]
  },
  "id_str" : "895561491075747840",
  "in_reply_to_user_id" : 636216638,
  "text" : "@DaniRabaiotti If only there were a body of research, compiled over decades, showing that discrimination exists. \uD83D\uDE02",
  "id" : 895561491075747840,
  "in_reply_to_status_id" : 895559012153950208,
  "created_at" : "2017-08-10 08:24:32 +0000",
  "in_reply_to_screen_name" : "DaniRabaiotti",
  "in_reply_to_user_id_str" : "636216638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/895399979581407232\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/K4v9FZiSqi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DG0Zh85XsAE-mKy.jpg",
      "id_str" : "895399971989729281",
      "id" : 895399971989729281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DG0Zh85XsAE-mKy.jpg",
      "sizes" : [ {
        "h" : 172,
        "resize" : "fit",
        "w" : 267
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 267
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 267
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 267
      } ],
      "display_url" : "pic.twitter.com\/K4v9FZiSqi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895396216120500224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403212658499, 8.75337267895638 ]
  },
  "id_str" : "895399979581407232",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman  https:\/\/t.co\/K4v9FZiSqi",
  "id" : 895399979581407232,
  "in_reply_to_status_id" : 895396216120500224,
  "created_at" : "2017-08-09 21:42:45 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895395431999389696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11089083445577, 8.751405317134386 ]
  },
  "id_str" : "895396207325044736",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes And staying there in a NoAirBnb?",
  "id" : 895396207325044736,
  "in_reply_to_status_id" : 895395431999389696,
  "created_at" : "2017-08-09 21:27:46 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/MdINTwDCec",
      "expanded_url" : "https:\/\/twitter.com\/anildash\/status\/895391559809716224",
      "display_url" : "twitter.com\/anildash\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11133835000006, 8.754683340000607 ]
  },
  "id_str" : "895394658976759809",
  "text" : "I thought it\u2019s because we spend all our money on avocado toast and never save for buying a rocket? \uD83E\uDD51\uD83C\uDF5E\uD83D\uDE80 https:\/\/t.co\/MdINTwDCec",
  "id" : 895394658976759809,
  "created_at" : "2017-08-09 21:21:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieran O'Neill",
      "screen_name" : "oneillkza",
      "indices" : [ 3, 13 ],
      "id_str" : "100371111",
      "id" : 100371111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISMBECCB",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "895387848031047680",
  "text" : "RT @oneillkza: Great post here. ISMB's code of conduct is good, but we need to take more active steps towards inclusion. #ISMBECCB #ISCB_ED\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISMBECCB",
        "indices" : [ 106, 115 ]
      }, {
        "text" : "ISCB_EDI",
        "indices" : [ 116, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 126, 149 ],
        "url" : "https:\/\/t.co\/kJUovranMm",
        "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/894259488882077696",
        "display_url" : "twitter.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "895386326073188352",
    "text" : "Great post here. ISMB's code of conduct is good, but we need to take more active steps towards inclusion. #ISMBECCB #ISCB_EDI https:\/\/t.co\/kJUovranMm",
    "id" : 895386326073188352,
    "created_at" : "2017-08-09 20:48:30 +0000",
    "user" : {
      "name" : "Kieran O'Neill",
      "screen_name" : "oneillkza",
      "protected" : false,
      "id_str" : "100371111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620262526580883457\/7WEBO8wV_normal.jpg",
      "id" : 100371111,
      "verified" : false
    }
  },
  "id" : 895387848031047680,
  "created_at" : "2017-08-09 20:54:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895379762331439104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403301274785, 8.753374250813721 ]
  },
  "id_str" : "895381152302759936",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED thanks for a civil discussion on the internet. Have a good evening! \uD83D\uDE0A",
  "id" : 895381152302759936,
  "in_reply_to_status_id" : 895379762331439104,
  "created_at" : "2017-08-09 20:27:56 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895378457298948096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403123500988, 8.753371097709095 ]
  },
  "id_str" : "895378672894562304",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED shall we call it an EOD and agree to disagree? \uD83D\uDE09",
  "id" : 895378672894562304,
  "in_reply_to_status_id" : 895378457298948096,
  "created_at" : "2017-08-09 20:18:05 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895373364033933316",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403178619027, 8.753371090933971 ]
  },
  "id_str" : "895376765958455296",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED I mean: as soon as you try to convince people of doing OS practices you\u2019re joining the movement :)",
  "id" : 895376765958455296,
  "in_reply_to_status_id" : 895373364033933316,
  "created_at" : "2017-08-09 20:10:30 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895367629598330881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403123343035, 8.753371101110659 ]
  },
  "id_str" : "895370739733450754",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED \u2026due to bias\/discrimination. And you\u2019ll end up w\/ people being harassed for not doing core open science. (all impersonal \u201Eyou\u201Cs here).",
  "id" : 895370739733450754,
  "in_reply_to_status_id" : 895367629598330881,
  "created_at" : "2017-08-09 19:46:34 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895367629598330881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403180728131, 8.753370222151373 ]
  },
  "id_str" : "895370432462893056",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED if you advocate for everyone doing this (w\/ or w\/o policy changes), people will rightfully complain that they personally can\u2019t\u2026",
  "id" : 895370432462893056,
  "in_reply_to_status_id" : 895367629598330881,
  "created_at" : "2017-08-09 19:45:20 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895367629598330881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11403180728131, 8.753370222151373 ]
  },
  "id_str" : "895369980539269124",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED i think my point still stands: Do you want to do these core things by your own? Then all the power to you and go ahead.",
  "id" : 895369980539269124,
  "in_reply_to_status_id" : 895367629598330881,
  "created_at" : "2017-08-09 19:43:33 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895359602266697729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11348974895674, 8.752655535944507 ]
  },
  "id_str" : "895362278790488065",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED I think most of what open science is concerned with is not that core idea of science but rather dissemination etc.",
  "id" : 895362278790488065,
  "in_reply_to_status_id" : 895359602266697729,
  "created_at" : "2017-08-09 19:12:56 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895359602266697729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11362098820707, 8.748087696767145 ]
  },
  "id_str" : "895361225458143236",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED Do you want to change how science is done and lobby for it being more open? Then you need to address how transformation can be inclusive.",
  "id" : 895361225458143236,
  "in_reply_to_status_id" : 895359602266697729,
  "created_at" : "2017-08-09 19:08:45 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895359602266697729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399568063217, 8.747269576423566 ]
  },
  "id_str" : "895360971597910016",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED I don\u2019t fully get your point. Is it about just following some idea of open science on ones own? Just share your code\/data etc.",
  "id" : 895360971597910016,
  "in_reply_to_status_id" : 895359602266697729,
  "created_at" : "2017-08-09 19:07:45 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895350502292152320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235250717399, 8.627504656844332 ]
  },
  "id_str" : "895352939077931024",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED e.g in case of open peer review which we discussed yesterday evening.",
  "id" : 895352939077931024,
  "in_reply_to_status_id" : 895350502292152320,
  "created_at" : "2017-08-09 18:35:50 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895350502292152320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235250717399, 8.627504656844332 ]
  },
  "id_str" : "895352787445403648",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED b) bias &amp; discrimination will increase against those not privileged enough to follow through with open.",
  "id" : 895352787445403648,
  "in_reply_to_status_id" : 895350502292152320,
  "created_at" : "2017-08-09 18:35:14 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895350502292152320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232950947054, 8.62751853365976 ]
  },
  "id_str" : "895352559464050688",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog my point: by not doing so one is doing a disservice to both. Not addressing inclusivity means a) only few privileged will do open*.",
  "id" : 895352559464050688,
  "in_reply_to_status_id" : 895350502292152320,
  "created_at" : "2017-08-09 18:34:19 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/601CJy5M9B",
      "expanded_url" : "https:\/\/twitter.com\/ed_berry\/status\/895294747354509312",
      "display_url" : "twitter.com\/ed_berry\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17244344916766, 8.62737434536912 ]
  },
  "id_str" : "895339770506874880",
  "text" : "Also: It\u2019s been 36 years since SJ Gould published \u2018The Mismeasure of Man\u2019. https:\/\/t.co\/601CJy5M9B",
  "id" : 895339770506874880,
  "created_at" : "2017-08-09 17:43:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 7, 17 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 18, 32 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895316681941065728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231589065236, 8.627523098695882 ]
  },
  "id_str" : "895317105054068736",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw @strijkers @richarddmorey speak for yourself, I got a PhD thesis in dire need of some more procrastination. \uD83D\uDE02",
  "id" : 895317105054068736,
  "in_reply_to_status_id" : 895316681941065728,
  "created_at" : "2017-08-09 16:13:26 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 62, 69 ],
      "id_str" : "33651124",
      "id" : 33651124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/N8fHF8QBom",
      "expanded_url" : "https:\/\/www.micropia.nl\/en\/",
      "display_url" : "micropia.nl\/en\/"
    } ]
  },
  "in_reply_to_status_id_str" : "895274116869234693",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234365871782, 8.627506630472844 ]
  },
  "id_str" : "895287775901220865",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam ride on the huge tardigrades at the microbe museum. @sujaik and I loved doing that! https:\/\/t.co\/N8fHF8QBom",
  "id" : 895287775901220865,
  "in_reply_to_status_id" : 895274116869234693,
  "created_at" : "2017-08-09 14:16:54 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Jazeera English",
      "screen_name" : "AJEnglish",
      "indices" : [ 3, 13 ],
      "id_str" : "4970411",
      "id" : 4970411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "895263203281838081",
  "text" : "RT @AJEnglish: \"I thought I should make a game designed for old people to have fun.\"\n\nThis 82-year-old app developer proves you're never to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/studio.twitter.com\" rel=\"nofollow\"\u003EMedia Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AJEnglish\/status\/895117447409172481\/video\/1",
        "indices" : [ 139, 162 ],
        "url" : "https:\/\/t.co\/u8WLHR98Lk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DGotltXUIAA8FSL.jpg",
        "id_str" : "894561745167032321",
        "id" : 894561745167032321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DGotltXUIAA8FSL.jpg",
        "sizes" : [ {
          "h" : 1074,
          "resize" : "fit",
          "w" : 1072
        }, {
          "h" : 1074,
          "resize" : "fit",
          "w" : 1072
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 679
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1074,
          "resize" : "fit",
          "w" : 1072
        } ],
        "display_url" : "pic.twitter.com\/u8WLHR98Lk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "895117447409172481",
    "text" : "\"I thought I should make a game designed for old people to have fun.\"\n\nThis 82-year-old app developer proves you're never too old to code. https:\/\/t.co\/u8WLHR98Lk",
    "id" : 895117447409172481,
    "created_at" : "2017-08-09 03:00:04 +0000",
    "user" : {
      "name" : "Al Jazeera English",
      "screen_name" : "AJEnglish",
      "protected" : false,
      "id_str" : "4970411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875638617606987776\/YBOKib96_normal.jpg",
      "id" : 4970411,
      "verified" : true
    }
  },
  "id" : 895263203281838081,
  "created_at" : "2017-08-09 12:39:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895239831399301120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232856560862, 8.627527741558938 ]
  },
  "id_str" : "895259305586421761",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 \u201CUnlikely to have happened by chance\u201D, p=0.49",
  "id" : 895259305586421761,
  "in_reply_to_status_id" : 895239831399301120,
  "created_at" : "2017-08-09 12:23:46 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895234468415508480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236639949962, 8.627501310463742 ]
  },
  "id_str" : "895235550873047040",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe and totes agree about the standards. I can rest safely at night now \uD83D\uDE02",
  "id" : 895235550873047040,
  "in_reply_to_status_id" : 895234468415508480,
  "created_at" : "2017-08-09 10:49:22 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895235323004936193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17236639949962, 8.627501310463742 ]
  },
  "id_str" : "895235484372410368",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe uh, awesome!",
  "id" : 895235484372410368,
  "in_reply_to_status_id" : 895235323004936193,
  "created_at" : "2017-08-09 10:49:06 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 11, 25 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 26, 32 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 33, 47 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895230988648927232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17172875281184, 8.631988820670783 ]
  },
  "id_str" : "895231658366050304",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @richarddmorey @shefw @Protohedgehog @OED That\u2019s what lead to the formation of an open science movement that clashes internally and externally around values?",
  "id" : 895231658366050304,
  "in_reply_to_status_id" : 895230988648927232,
  "created_at" : "2017-08-09 10:33:54 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 11, 25 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 26, 32 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 33, 47 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895226793833234432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17212707088345, 8.631676174708298 ]
  },
  "id_str" : "895230575690342401",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @richarddmorey @shefw @Protohedgehog @OED Not everything can be solved by data (freq\/bayesian) or without underlying values (open peer review yes\/no).",
  "id" : 895230575690342401,
  "in_reply_to_status_id" : 895226793833234432,
  "created_at" : "2017-08-09 10:29:36 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 11, 25 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 26, 32 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 33, 47 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895223984618385409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723216779526, 8.62752898559961 ]
  },
  "id_str" : "895225046112890881",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @richarddmorey @shefw @Protohedgehog @OED philosophy has big clashing schools. And yes, there are movements around the culture of eating.",
  "id" : 895225046112890881,
  "in_reply_to_status_id" : 895223984618385409,
  "created_at" : "2017-08-09 10:07:38 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 11, 25 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 26, 32 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 33, 47 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895223984618385409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723216779526, 8.62752898559961 ]
  },
  "id_str" : "895224818357997569",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @richarddmorey @shefw @Protohedgehog @OED ad hominem: sorry, just wanted to make a joke because the example was one where there actually are big movements and discussions.",
  "id" : 895224818357997569,
  "in_reply_to_status_id" : 895223984618385409,
  "created_at" : "2017-08-09 10:06:43 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 11, 25 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 26, 32 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 33, 47 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895216733790842880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239532755031, 8.627548981056743 ]
  },
  "id_str" : "895217631799771136",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @richarddmorey @shefw @Protohedgehog @OED Of course there\u2019s a statistical movement. Have you slept trough the ongoing Frequentist vs Bayesian wars? :p just highlights social nature.",
  "id" : 895217631799771136,
  "in_reply_to_status_id" : 895216733790842880,
  "created_at" : "2017-08-09 09:38:10 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Nicholls",
      "screen_name" : "samstudio8",
      "indices" : [ 0, 11 ],
      "id_str" : "40444555",
      "id" : 40444555
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 12, 20 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/KyFsfgTSi0",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/2a6fjfpay3dmpr0\/bioinformagic.gif?dl=0",
      "display_url" : "dropbox.com\/s\/2a6fjfpay3dm\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "894900787448471552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241980087155, 8.627535800800459 ]
  },
  "id_str" : "895212552262737922",
  "in_reply_to_user_id" : 40444555,
  "text" : "@samstudio8 @pjacock After utilizing some wet lab, using pipettes, we applied bioinformatics\u2026 https:\/\/t.co\/KyFsfgTSi0",
  "id" : 895212552262737922,
  "in_reply_to_status_id" : 894900787448471552,
  "created_at" : "2017-08-09 09:17:59 +0000",
  "in_reply_to_screen_name" : "samstudio8",
  "in_reply_to_user_id_str" : "40444555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 0, 14 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 15, 21 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 37, 47 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895209630753841152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17239667705793, 8.627544713536611 ]
  },
  "id_str" : "895210778642575360",
  "in_reply_to_user_id" : 2760015084,
  "text" : "@richarddmorey @shefw @Protohedgehog @strijkers @OED Otherwise you end up in the same state as the open source movement, which for a long time terribly failed to address this.",
  "id" : 895210778642575360,
  "in_reply_to_status_id" : 895209630753841152,
  "created_at" : "2017-08-09 09:10:56 +0000",
  "in_reply_to_screen_name" : "richarddmorey",
  "in_reply_to_user_id_str" : "2760015084",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 0, 14 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 15, 21 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 37, 47 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895209630753841152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241221547969, 8.627529090589695 ]
  },
  "id_str" : "895210609775714304",
  "in_reply_to_user_id" : 2760015084,
  "text" : "@richarddmorey @shefw @Protohedgehog @strijkers @OED Open science is about both transparency &amp; accessibility. As you want to change norms in the social enterprise science you need inclusivity.",
  "id" : 895210609775714304,
  "in_reply_to_status_id" : 895209630753841152,
  "created_at" : "2017-08-09 09:10:16 +0000",
  "in_reply_to_screen_name" : "richarddmorey",
  "in_reply_to_user_id_str" : "2760015084",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 0, 14 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 15, 21 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 37, 47 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/uzoaaSjI9h",
      "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/889248986984591362",
      "display_url" : "twitter.com\/o_guest\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895202248665575424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232206445585, 8.627521361108645 ]
  },
  "id_str" : "895204398632247296",
  "in_reply_to_user_id" : 2760015084,
  "text" : "@richarddmorey @shefw @Protohedgehog @strijkers @OED c.f. https:\/\/t.co\/uzoaaSjI9h",
  "id" : 895204398632247296,
  "in_reply_to_status_id" : 895202248665575424,
  "created_at" : "2017-08-09 08:45:35 +0000",
  "in_reply_to_screen_name" : "richarddmorey",
  "in_reply_to_user_id_str" : "2760015084",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 0, 14 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 15, 21 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 37, 47 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/895204311650770944\/photo\/1",
      "indices" : [ 194, 217 ],
      "url" : "https:\/\/t.co\/R3IkX5bb81",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DGxnkv-XkAAsc-3.jpg",
      "id_str" : "895204306990895104",
      "id" : 895204306990895104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DGxnkv-XkAAsc-3.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/R3IkX5bb81"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895202515737825280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723358956534, 8.62750832359648 ]
  },
  "id_str" : "895204311650770944",
  "in_reply_to_user_id" : 2760015084,
  "text" : "@richarddmorey @shefw @Protohedgehog @strijkers @OED Problem is that non-consensus use of words does not make one understood. Your def. of OS is only a small parts of whats under the umbrella \uD83D\uDE0A https:\/\/t.co\/R3IkX5bb81",
  "id" : 895204311650770944,
  "in_reply_to_status_id" : 895202515737825280,
  "created_at" : "2017-08-09 08:45:14 +0000",
  "in_reply_to_screen_name" : "richarddmorey",
  "in_reply_to_user_id_str" : "2760015084",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard D. Morey",
      "screen_name" : "richarddmorey",
      "indices" : [ 0, 14 ],
      "id_str" : "2760015084",
      "id" : 2760015084
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 15, 21 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 37, 47 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 48, 52 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 143, 166 ],
      "url" : "https:\/\/t.co\/c3w78H7yHG",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Open_science",
      "display_url" : "en.wikipedia.org\/wiki\/Open_scie\u2026"
    }, {
      "indices" : [ 173, 196 ],
      "url" : "https:\/\/t.co\/GA6FzahZu3",
      "expanded_url" : "http:\/\/www.unesco.org\/new\/en\/communication-and-information\/portals-and-platforms\/goap\/open-science-movement\/",
      "display_url" : "unesco.org\/new\/en\/communi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895186427130114048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233607011016, 8.627508133910869 ]
  },
  "id_str" : "895201256859459584",
  "in_reply_to_user_id" : 2760015084,
  "text" : "@richarddmorey @shefw @Protohedgehog @strijkers @OED broad consensus seems to be that OS is a movement analogous to other open* movements. cf. https:\/\/t.co\/c3w78H7yHG &amp; https:\/\/t.co\/GA6FzahZu3",
  "id" : 895201256859459584,
  "in_reply_to_status_id" : 895186427130114048,
  "created_at" : "2017-08-09 08:33:06 +0000",
  "in_reply_to_screen_name" : "richarddmorey",
  "in_reply_to_user_id_str" : "2760015084",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895199780061585409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231713135478, 8.62754949247968 ]
  },
  "id_str" : "895200057636663297",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u201Euh, we need a new library. I just sequenced the navel microbiome of me and my kid\u201C",
  "id" : 895200057636663297,
  "in_reply_to_status_id" : 895199780061585409,
  "created_at" : "2017-08-09 08:28:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 11, 17 ],
      "id_str" : "48636190",
      "id" : 48636190
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 18, 32 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 33, 37 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895190059753889792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232657717826, 8.627538549921464 ]
  },
  "id_str" : "895199100743950336",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @shefw @Protohedgehog @OED I think that\u2019s just a very limited definition of what science is. Science is a social activity and as such somewhat of a movement in itself.",
  "id" : 895199100743950336,
  "in_reply_to_status_id" : 895190059753889792,
  "created_at" : "2017-08-09 08:24:32 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Sampat",
      "screen_name" : "twoscooters",
      "indices" : [ 3, 15 ],
      "id_str" : "26902304",
      "id" : 26902304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "895191888864718848",
  "text" : "RT @twoscooters: As promised: I got mad about the Google Manifesto and made a game about it.\n\nI hope you like it. My lawyer did.\n\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/r6CQ7EZdYI",
        "expanded_url" : "https:\/\/elizabethsampat.itch.io\/8-vignettes-from-the-tech-industry",
        "display_url" : "elizabethsampat.itch.io\/8-vignettes-fr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "894984821604327424",
    "text" : "As promised: I got mad about the Google Manifesto and made a game about it.\n\nI hope you like it. My lawyer did.\n\nhttps:\/\/t.co\/r6CQ7EZdYI",
    "id" : 894984821604327424,
    "created_at" : "2017-08-08 18:13:04 +0000",
    "user" : {
      "name" : "Elizabeth Sampat",
      "screen_name" : "twoscooters",
      "protected" : false,
      "id_str" : "26902304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752676043673088001\/-xN7quHw_normal.jpg",
      "id" : 26902304,
      "verified" : true
    }
  },
  "id" : 895191888864718848,
  "created_at" : "2017-08-09 07:55:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895099606815592448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235218044738, 8.627509526306806 ]
  },
  "id_str" : "895190591432163328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Please tell me that you\u2019ll now start sequencing all the random stuff.",
  "id" : 895190591432163328,
  "in_reply_to_status_id" : 895099606815592448,
  "created_at" : "2017-08-09 07:50:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "diebelfischer",
      "screen_name" : "hrmnn01",
      "indices" : [ 0, 8 ],
      "id_str" : "2925094713",
      "id" : 2925094713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895171807514435586",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17144335904175, 8.627653196462083 ]
  },
  "id_str" : "895175921329745921",
  "in_reply_to_user_id" : 2925094713,
  "text" : "@hrmnn01 Doppelname. Es gibt noch ein Feld \u2018Geburtsname\u2019, ist aber offensichtlich leer wenn der Doppelname den Geburtsnamen enth\u00E4lt. :)",
  "id" : 895175921329745921,
  "in_reply_to_status_id" : 895171807514435586,
  "created_at" : "2017-08-09 06:52:25 +0000",
  "in_reply_to_screen_name" : "hrmnn01",
  "in_reply_to_user_id_str" : "2925094713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viola vo\u00DF",
      "screen_name" : "v_i_o_l_a",
      "indices" : [ 0, 10 ],
      "id_str" : "14937469",
      "id" : 14937469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895170489659863040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11194676631141, 8.742188718178069 ]
  },
  "id_str" : "895171081123885057",
  "in_reply_to_user_id" : 14937469,
  "text" : "@v_i_o_l_a I\u2019m a bit worried that this would prove my citizenship even without having a passport \uD83D\uDE02",
  "id" : 895171081123885057,
  "in_reply_to_status_id" : 895170489659863040,
  "created_at" : "2017-08-09 06:33:11 +0000",
  "in_reply_to_screen_name" : "v_i_o_l_a",
  "in_reply_to_user_id_str" : "14937469",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Pohl",
      "screen_name" : "LilithElina",
      "indices" : [ 0, 12 ],
      "id_str" : "434020661",
      "id" : 434020661
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 13, 23 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895168787678408704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11414565956863, 8.746875039465742 ]
  },
  "id_str" : "895170178106916864",
  "in_reply_to_user_id" : 434020661,
  "text" : "@LilithElina @biocrusoe So close to the birthday paradox. ;)",
  "id" : 895170178106916864,
  "in_reply_to_status_id" : 895168787678408704,
  "created_at" : "2017-08-09 06:29:36 +0000",
  "in_reply_to_screen_name" : "LilithElina",
  "in_reply_to_user_id_str" : "434020661",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/5MaTFSiI6n",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/895167557606535168",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895167557606535168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11450622235435, 8.746648645036618 ]
  },
  "id_str" : "895169909717598209",
  "in_reply_to_user_id" : 14286491,
  "text" : "I\u2019m unreasonably happy about the fact that German passports finally fully adhere to ISO\/IEC 7810. https:\/\/t.co\/5MaTFSiI6n",
  "id" : 895169909717598209,
  "in_reply_to_status_id" : 895167557606535168,
  "created_at" : "2017-08-09 06:28:32 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 0, 10 ],
      "id_str" : "35304791",
      "id" : 35304791
    }, {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 11, 21 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Lv8pjF9cYQ",
      "expanded_url" : "https:\/\/www.google.de\/amp\/s\/www.germanpulse.com\/2017\/02\/24\/new-secure-german-passport\/amp\/",
      "display_url" : "google.de\/amp\/s\/www.germ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895167929473531905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11453136806387, 8.746724585079352 ]
  },
  "id_str" : "895169657564524544",
  "in_reply_to_user_id" : 35304791,
  "text" : "@razibkhan @biocrusoe Here\u2019s some stock footage of it, can\u2019t show it of myself right now. https:\/\/t.co\/Lv8pjF9cYQ",
  "id" : 895169657564524544,
  "in_reply_to_status_id" : 895167929473531905,
  "created_at" : "2017-08-09 06:27:32 +0000",
  "in_reply_to_screen_name" : "razibkhan",
  "in_reply_to_user_id_str" : "35304791",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 97, 107 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/895167557606535168\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/uYSnzOLbsG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DGxGJjGWsAEphl2.jpg",
      "id_str" : "895167555794546689",
      "id" : 895167555794546689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DGxGJjGWsAEphl2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 767
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 767
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 767
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 509
      } ],
      "display_url" : "pic.twitter.com\/uYSnzOLbsG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "895167557606535168",
  "text" : "Now it's real. Also: German passports are finally true ID-3 format, not ID-3 + 2mm to each side! @biocrusoe https:\/\/t.co\/uYSnzOLbsG",
  "id" : 895167557606535168,
  "created_at" : "2017-08-09 06:19:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/5s4FdcaGeP",
      "expanded_url" : "http:\/\/theconversation.com\/lets-face-it-gender-bias-in-academia-is-for-real-44637",
      "display_url" : "theconversation.com\/lets-face-it-g\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895060261735981056",
  "geo" : { },
  "id_str" : "895062070810562561",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown and https:\/\/t.co\/5s4FdcaGeP for some studies on language in letters of recommendation.",
  "id" : 895062070810562561,
  "in_reply_to_status_id" : 895060261735981056,
  "created_at" : "2017-08-08 23:20:01 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/OE3ZmUsxDJ",
      "expanded_url" : "http:\/\/www.pnas.org\/content\/109\/41\/16474.abstract",
      "display_url" : "pnas.org\/content\/109\/41\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895060261735981056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11406429421935, 8.753428827516089 ]
  },
  "id_str" : "895061793198026752",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown the bias already starts before anyone is getting invited, c.f. https:\/\/t.co\/OE3ZmUsxDJ",
  "id" : 895061793198026752,
  "in_reply_to_status_id" : 895060261735981056,
  "created_at" : "2017-08-08 23:18:55 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895057282605744128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11381483911642, 8.753158905140625 ]
  },
  "id_str" : "895058464589918209",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown I sign my reviews too, but I acknowledge that it\u2019s my privilege that gives me that choice without fearing serious repercussions for doing so",
  "id" : 895058464589918209,
  "in_reply_to_status_id" : 895057282605744128,
  "created_at" : "2017-08-08 23:05:41 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/LLFmuQ5fSV",
      "expanded_url" : "http:\/\/gap.hks.harvard.edu\/orchestrating-impartiality-impact-%E2%80%9Cblind%E2%80%9D-auditions-female-musicians",
      "display_url" : "gap.hks.harvard.edu\/orchestrating-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895056386903736325",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1140642196379, 8.75342884701946 ]
  },
  "id_str" : "895056861220786176",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown as in the famous Orchestra Blind Auditions? https:\/\/t.co\/LLFmuQ5fSV",
  "id" : 895056861220786176,
  "in_reply_to_status_id" : 895056386903736325,
  "created_at" : "2017-08-08 22:59:19 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895045738358390786",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401498511405, 8.753441722058204 ]
  },
  "id_str" : "895056222872887298",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski everyone who\u2019s ever actually done science knows only too well that science will most likely get it wrong and is far from infallible :D",
  "id" : 895056222872887298,
  "in_reply_to_status_id" : 895045738358390786,
  "created_at" : "2017-08-08 22:56:47 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 3, 17 ],
      "id_str" : "636216638",
      "id" : 636216638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/thvokywqa8",
      "expanded_url" : "https:\/\/twitter.com\/zerdeve\/status\/894989244325797888",
      "display_url" : "twitter.com\/zerdeve\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "895055354085748736",
  "text" : "RT @DaniRabaiotti: This thread \uD83D\uDC47\uD83D\uDC4F https:\/\/t.co\/thvokywqa8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/thvokywqa8",
        "expanded_url" : "https:\/\/twitter.com\/zerdeve\/status\/894989244325797888",
        "display_url" : "twitter.com\/zerdeve\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "895043175986991106",
    "text" : "This thread \uD83D\uDC47\uD83D\uDC4F https:\/\/t.co\/thvokywqa8",
    "id" : 895043175986991106,
    "created_at" : "2017-08-08 22:04:56 +0000",
    "user" : {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "protected" : false,
      "id_str" : "636216638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926387348354617344\/knjAV6uc_normal.jpg",
      "id" : 636216638,
      "verified" : false
    }
  },
  "id" : 895055354085748736,
  "created_at" : "2017-08-08 22:53:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Friday",
      "screen_name" : "scifri",
      "indices" : [ 3, 10 ],
      "id_str" : "16817883",
      "id" : 16817883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Yrunw7E9ks",
      "expanded_url" : "http:\/\/scifri.me\/r51",
      "display_url" : "scifri.me\/r51"
    } ]
  },
  "geo" : { },
  "id_str" : "895054881396019201",
  "text" : "RT @scifri: Women scientists get fewer paper citations and are less likely to be cited as first author. https:\/\/t.co\/Yrunw7E9ks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/Yrunw7E9ks",
        "expanded_url" : "http:\/\/scifri.me\/r51",
        "display_url" : "scifri.me\/r51"
      } ]
    },
    "geo" : { },
    "id_str" : "891752256168615936",
    "text" : "Women scientists get fewer paper citations and are less likely to be cited as first author. https:\/\/t.co\/Yrunw7E9ks",
    "id" : 891752256168615936,
    "created_at" : "2017-07-30 20:08:00 +0000",
    "user" : {
      "name" : "Science Friday",
      "screen_name" : "scifri",
      "protected" : false,
      "id_str" : "16817883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879343735410130944\/Ec_wG3Qi_normal.jpg",
      "id" : 16817883,
      "verified" : true
    }
  },
  "id" : 895054881396019201,
  "created_at" : "2017-08-08 22:51:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 99, 107 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/Q3RLRROJyw",
      "expanded_url" : "https:\/\/twitter.com\/scifri\/status\/891752256168615936",
      "display_url" : "twitter.com\/scifri\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895050876653625346",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11133860403564, 8.754685200395363 ]
  },
  "id_str" : "895052863520608257",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown Also: https:\/\/t.co\/Q3RLRROJyw (HT @o_guest)",
  "id" : 895052863520608257,
  "in_reply_to_status_id" : 895050876653625346,
  "created_at" : "2017-08-08 22:43:26 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 170, 193 ],
      "url" : "https:\/\/t.co\/ZILdBvLzNY",
      "expanded_url" : "https:\/\/f1000research.com\/articles\/6-1151\/v1",
      "display_url" : "f1000research.com\/articles\/6-115\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895050876653625346",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11128469285959, 8.75429038928679 ]
  },
  "id_str" : "895052606220926977",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown These biases are exactly the reasons that speak for 2-blind peer review (see 2.4, disclaimer: self-plug) https:\/\/t.co\/ZILdBvLzNY",
  "id" : 895052606220926977,
  "in_reply_to_status_id" : 895050876653625346,
  "created_at" : "2017-08-08 22:42:25 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 164, 187 ],
      "url" : "https:\/\/t.co\/AZqJsiZ1uq",
      "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/894903106953261056",
      "display_url" : "twitter.com\/o_guest\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895046399317954564",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395750106323, 8.753155767925785 ]
  },
  "id_str" : "895047640068612106",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown Not being able to discriminate between those things is the whole point on sexism that\u2019s made here: https:\/\/t.co\/AZqJsiZ1uq",
  "id" : 895047640068612106,
  "in_reply_to_status_id" : 895046399317954564,
  "created_at" : "2017-08-08 22:22:41 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 177, 185 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895046399317954564",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11388839227158, 8.752960301943824 ]
  },
  "id_str" : "895047290624385024",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown that\u2019s the problem: you can\u2019t and are always stuck not knowing how much of feedback is just based on gender. As @o_guest originally wrote.",
  "id" : 895047290624385024,
  "in_reply_to_status_id" : 895046399317954564,
  "created_at" : "2017-08-08 22:21:17 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895039867964579840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394346905154, 8.753572884814567 ]
  },
  "id_str" : "895041757804720129",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown I have no reason to believe that a \u201Esmaller scale\u201C version of this could not exist in the context here w\/ women targeted based on gender.",
  "id" : 895041757804720129,
  "in_reply_to_status_id" : 895039867964579840,
  "created_at" : "2017-08-08 21:59:18 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "895039867964579840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394346905154, 8.753572884814567 ]
  },
  "id_str" : "895041330451288064",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown women are being threatened with rape and murder, hacked and their personal data leaked on the internet over video games.",
  "id" : 895041330451288064,
  "in_reply_to_status_id" : 895039867964579840,
  "created_at" : "2017-08-08 21:57:36 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristof Strijkers",
      "screen_name" : "strijkers",
      "indices" : [ 0, 10 ],
      "id_str" : "828522193663434752",
      "id" : 828522193663434752
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Andrew & Sabrina",
      "screen_name" : "PsychScientists",
      "indices" : [ 20, 36 ],
      "id_str" : "182747810",
      "id" : 182747810
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 37, 51 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 52, 64 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 178, 201 ],
      "url" : "https:\/\/t.co\/s8kb3woBqi",
      "expanded_url" : "http:\/\/networkedintelligence.com\/wp\/wp-content\/uploads\/2017\/05\/Cyber_violence_Gender-report.pdf",
      "display_url" : "networkedintelligence.com\/wp\/wp-content\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "895025774868267008",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11390658770841, 8.753225437365993 ]
  },
  "id_str" : "895036474562928640",
  "in_reply_to_user_id" : 828522193663434752,
  "text" : "@strijkers @o_guest @PsychScientists @Protohedgehog @ctitusbrown women 27x more likely to be victims of online abuse. Translate to violently disagreeing\/arguing on social media? https:\/\/t.co\/s8kb3woBqi",
  "id" : 895036474562928640,
  "in_reply_to_status_id" : 895025774868267008,
  "created_at" : "2017-08-08 21:38:19 +0000",
  "in_reply_to_screen_name" : "strijkers",
  "in_reply_to_user_id_str" : "828522193663434752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sa\u0161a Marcan",
      "screen_name" : "cane51000",
      "indices" : [ 0, 10 ],
      "id_str" : "4794693811",
      "id" : 4794693811
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 20, 29 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Brent W. Roberts",
      "screen_name" : "BrentWRoberts",
      "indices" : [ 30, 44 ],
      "id_str" : "1618123446",
      "id" : 1618123446
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 45, 55 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894996401872142336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11394892377454, 8.753279595564496 ]
  },
  "id_str" : "895028059765714945",
  "in_reply_to_user_id" : 4794693811,
  "text" : "@cane51000 @o_guest @sampendu @BrentWRoberts @chrisdc77 yes, somewhat surprisingly the topic \u201Ecommons\u201C somehow attracted people who\u2019re interested in culture and political theory. \uD83D\uDE0A",
  "id" : 895028059765714945,
  "in_reply_to_status_id" : 894996401872142336,
  "created_at" : "2017-08-08 21:04:52 +0000",
  "in_reply_to_screen_name" : "cane51000",
  "in_reply_to_user_id_str" : "4794693811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894989135651291136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11392279808158, 8.753103248671705 ]
  },
  "id_str" : "894998728574160897",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw You're too kind, changing culture needs to start with being critical of oneself. And thanks for having me as part of the community! \uD83D\uDC96",
  "id" : 894998728574160897,
  "in_reply_to_status_id" : 894989135651291136,
  "created_at" : "2017-08-08 19:08:19 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 0, 13 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    }, {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 14, 27 ],
      "id_str" : "111020569",
      "id" : 111020569
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 28, 39 ],
      "id_str" : "380205172",
      "id" : 380205172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894997236089856002",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401793458509, 8.753374116503403 ]
  },
  "id_str" : "894997611131940864",
  "in_reply_to_user_id" : 3059929578,
  "text" : "@repositiveio @manuelcorpas @openSNPorg No worries, we've all accidentally forgotten adding the citation at times. No harm done \u263A\uFE0F",
  "id" : 894997611131940864,
  "in_reply_to_status_id" : 894997236089856002,
  "created_at" : "2017-08-08 19:03:53 +0000",
  "in_reply_to_screen_name" : "repositiveio",
  "in_reply_to_user_id_str" : "3059929578",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    }, {
      "name" : "Repositive.io",
      "screen_name" : "repositiveio",
      "indices" : [ 14, 27 ],
      "id_str" : "3059929578",
      "id" : 3059929578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894955419541663744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11416906029928, 8.746917620309393 ]
  },
  "id_str" : "894993001554030592",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas @repositiveio I have a suspicion for which repository hosts the bulk of that data. A citation would have been nice. \uD83D\uDE09",
  "id" : 894993001554030592,
  "in_reply_to_status_id" : 894955419541663744,
  "created_at" : "2017-08-08 18:45:34 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Sa\u0161a Marcan",
      "screen_name" : "cane51000",
      "indices" : [ 9, 19 ],
      "id_str" : "4794693811",
      "id" : 4794693811
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 20, 29 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Brent W. Roberts",
      "screen_name" : "BrentWRoberts",
      "indices" : [ 30, 44 ],
      "id_str" : "1618123446",
      "id" : 1618123446
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 45, 55 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894951361909067778",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231483927181, 8.62753231601024 ]
  },
  "id_str" : "894953395601252352",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @cane51000 @sampendu @BrentWRoberts @chrisdc77 thanks! It\u2019s a big team working on this and we formed a dedicated subgroup to work on issues of inclusivity.",
  "id" : 894953395601252352,
  "in_reply_to_status_id" : 894951361909067778,
  "created_at" : "2017-08-08 16:08:11 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sa\u0161a Marcan",
      "screen_name" : "cane51000",
      "indices" : [ 0, 10 ],
      "id_str" : "4794693811",
      "id" : 4794693811
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 20, 29 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Brent W. Roberts",
      "screen_name" : "BrentWRoberts",
      "indices" : [ 30, 44 ],
      "id_str" : "1618123446",
      "id" : 1618123446
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 45, 55 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894926207288053760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722927895347, 8.627552059255365 ]
  },
  "id_str" : "894949952174133255",
  "in_reply_to_user_id" : 4794693811,
  "text" : "@cane51000 @o_guest @sampendu @BrentWRoberts @chrisdc77 not by accident that one of them is \u201EParticipation in the production and use of knowledge should be open to all who wish to participate.\u201C \uD83D\uDE0A",
  "id" : 894949952174133255,
  "in_reply_to_status_id" : 894926207288053760,
  "created_at" : "2017-08-08 15:54:30 +0000",
  "in_reply_to_screen_name" : "cane51000",
  "in_reply_to_user_id_str" : "4794693811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sa\u0161a Marcan",
      "screen_name" : "cane51000",
      "indices" : [ 0, 10 ],
      "id_str" : "4794693811",
      "id" : 4794693811
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 11, 19 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 20, 29 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Brent W. Roberts",
      "screen_name" : "BrentWRoberts",
      "indices" : [ 30, 44 ],
      "id_str" : "1618123446",
      "id" : 1618123446
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 45, 55 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/gofYAHR9lR",
      "expanded_url" : "https:\/\/scholarlycommons.org\/",
      "display_url" : "scholarlycommons.org"
    } ]
  },
  "in_reply_to_status_id_str" : "894926207288053760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232583842155, 8.627521585222803 ]
  },
  "id_str" : "894949232116985857",
  "in_reply_to_user_id" : 4794693811,
  "text" : "@cane51000 @o_guest @sampendu @BrentWRoberts @chrisdc77 glad you\u2019re asking. Lots of people are working on formulating those tenets, e.g. https:\/\/t.co\/gofYAHR9lR",
  "id" : 894949232116985857,
  "in_reply_to_status_id" : 894926207288053760,
  "created_at" : "2017-08-08 15:51:38 +0000",
  "in_reply_to_screen_name" : "cane51000",
  "in_reply_to_user_id_str" : "4794693811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 15, 23 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 24, 38 ],
      "id_str" : "636216638",
      "id" : 636216638
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 39, 48 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 49, 59 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Y48KBMmia8",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/894880123656314880",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/PlwM7mI4ze",
      "expanded_url" : "https:\/\/twitter.com\/o_guest\/status\/894573247773192193",
      "display_url" : "twitter.com\/o_guest\/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "894888592987881472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234840865783, 8.62752476652119 ]
  },
  "id_str" : "894888829525647360",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @o_guest @DaniRabaiotti @sampendu @chrisdc77 I meant my tweet https:\/\/t.co\/Y48KBMmia8 in relation to https:\/\/t.co\/PlwM7mI4ze",
  "id" : 894888829525647360,
  "in_reply_to_status_id" : 894888592987881472,
  "created_at" : "2017-08-08 11:51:37 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 24, 38 ],
      "id_str" : "636216638",
      "id" : 636216638
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 39, 48 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 49, 59 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894881706972504064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17235725271374, 8.627531252717581 ]
  },
  "id_str" : "894882165229469697",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog @DaniRabaiotti @sampendu @chrisdc77 well, it\u2019s a case of a white dude rephrasing what was already been said. Feels right to acknowledge that, even if happened accidentally.",
  "id" : 894882165229469697,
  "in_reply_to_status_id" : 894881706972504064,
  "created_at" : "2017-08-08 11:25:08 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 24, 38 ],
      "id_str" : "636216638",
      "id" : 636216638
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 39, 48 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 49, 59 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894880884423139329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723539584955, 8.627507555769341 ]
  },
  "id_str" : "894881203656028160",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog @DaniRabaiotti @sampendu @chrisdc77 full ack and sorry for not reading that before, that\u2019s what I get for being off Twitter for a day.",
  "id" : 894881203656028160,
  "in_reply_to_status_id" : 894880884423139329,
  "created_at" : "2017-08-08 11:21:19 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 24, 38 ],
      "id_str" : "636216638",
      "id" : 636216638
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 39, 48 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 49, 59 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894880241642078208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234596089053, 8.627529791731162 ]
  },
  "id_str" : "894880700238880768",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog @DaniRabaiotti @sampendu @chrisdc77 hard to move towards inclusivity as long as \u201Ethe club\u201C doesn\u2019t acknowledge the existence of itself.",
  "id" : 894880700238880768,
  "in_reply_to_status_id" : 894880241642078208,
  "created_at" : "2017-08-08 11:19:19 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Dani Rabaiotti",
      "screen_name" : "DaniRabaiotti",
      "indices" : [ 24, 38 ],
      "id_str" : "636216638",
      "id" : 636216638
    }, {
      "name" : "Sam Schwarzkopf",
      "screen_name" : "sampendu",
      "indices" : [ 39, 48 ],
      "id_str" : "2817674196",
      "id" : 2817674196
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 49, 59 ],
      "id_str" : "525413893",
      "id" : 525413893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894878765502926848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234690785973, 8.62751602477249 ]
  },
  "id_str" : "894880123656314880",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog @DaniRabaiotti @sampendu @chrisdc77 it\u2019s all of the above. Communities formed around a movement. With a \u00B1 exclusive club of people representing\/shaping public perception of it.",
  "id" : 894880123656314880,
  "in_reply_to_status_id" : 894878765502926848,
  "created_at" : "2017-08-08 11:17:02 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/7P6y2W70Rs",
      "expanded_url" : "https:\/\/sunet.artologik.net\/lu\/Survey\/16030",
      "display_url" : "sunet.artologik.net\/lu\/Survey\/16030"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233791146597, 8.627529449912444 ]
  },
  "id_str" : "894844505920344064",
  "text" : "If you\u2019re doing research: Here\u2019s a survey on practices and norms in sharing\/publishing research, incl. Sci-Hub use. https:\/\/t.co\/7P6y2W70Rs",
  "id" : 894844505920344064,
  "created_at" : "2017-08-08 08:55:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17231695966297, 8.627529786088832 ]
  },
  "id_str" : "894602714889498624",
  "text" : "There\u2019s an \u201EInternational Journal of Manpower\u201C that published \u201EThe Effect of Sexual Activity on Wages\u201C. Bro-ology levels: Through the roof.",
  "id" : 894602714889498624,
  "created_at" : "2017-08-07 16:54:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/9QqydpI6v4",
      "expanded_url" : "http:\/\/bash.org\/?5273",
      "display_url" : "bash.org\/?5273"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233833675289, 8.62743174658029 ]
  },
  "id_str" : "894508102535581696",
  "text" : "What we've been playing in the office this morning. So far to no avail, the machine hides successfully. https:\/\/t.co\/9QqydpI6v4",
  "id" : 894508102535581696,
  "created_at" : "2017-08-07 10:38:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 0, 14 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894257196082614273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35914196524909, 8.587678687055318 ]
  },
  "id_str" : "894263317438636032",
  "in_reply_to_user_id" : 257319757,
  "text" : "@lorrainechu3n Thanks for writing it up!",
  "id" : 894263317438636032,
  "in_reply_to_status_id" : 894257196082614273,
  "created_at" : "2017-08-06 18:26:04 +0000",
  "in_reply_to_screen_name" : "lorrainechu3n",
  "in_reply_to_user_id_str" : "257319757",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 134, 157 ],
      "url" : "https:\/\/t.co\/qluIVlSXnh",
      "expanded_url" : "https:\/\/twitter.com\/lorrainechu3n\/status\/894257196082614273",
      "display_url" : "twitter.com\/lorrainechu3n\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35895887304033, 8.587481205699806 ]
  },
  "id_str" : "894259488882077696",
  "text" : "If you're organizing spaces where people come together: read this, especially if you want to make any claims to being an open* space. https:\/\/t.co\/qluIVlSXnh",
  "id" : 894259488882077696,
  "created_at" : "2017-08-06 18:10:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/894245058387619845\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/Ipgih7ray9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DGj_JAlXYBIA8_7.jpg",
      "id_str" : "894245056273670162",
      "id" : 894245056273670162,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DGj_JAlXYBIA8_7.jpg",
      "sizes" : [ {
        "h" : 488,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Ipgih7ray9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "894245058387619845",
  "text" : "Nazi human experiments can't be investigated because of data protection laws resulting from Nuremberg Medical Trials\u2026 https:\/\/t.co\/Ipgih7ray9",
  "id" : 894245058387619845,
  "created_at" : "2017-08-06 17:13:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "indices" : [ 3, 12 ],
      "id_str" : "55525953",
      "id" : 55525953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "894198721847709696",
  "text" : "RT @Pinboard: People believe dumb evolutionary psychology theories because those of our ancestors who didn\u2019t died from excessive eye-rolling",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "893951306662002688",
    "text" : "People believe dumb evolutionary psychology theories because those of our ancestors who didn\u2019t died from excessive eye-rolling",
    "id" : 893951306662002688,
    "created_at" : "2017-08-05 21:46:14 +0000",
    "user" : {
      "name" : "Pinboard",
      "screen_name" : "Pinboard",
      "protected" : false,
      "id_str" : "55525953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494414965\/logo_normal.png",
      "id" : 55525953,
      "verified" : false
    }
  },
  "id" : 894198721847709696,
  "created_at" : "2017-08-06 14:09:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "indices" : [ 9, 24 ],
      "id_str" : "1639877449",
      "id" : 1639877449
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 25, 35 ],
      "id_str" : "525413893",
      "id" : 525413893
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 36, 46 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 59, 68 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894158445980655616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931248382391, 8.587772548772199 ]
  },
  "id_str" : "894159133187989505",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @AsuraEnkhbayar @chrisdc77 @kirstie_j I hope that @open_con will broaden the focus at some point.",
  "id" : 894159133187989505,
  "in_reply_to_status_id" : 894158445980655616,
  "created_at" : "2017-08-06 11:32:04 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "indices" : [ 9, 24 ],
      "id_str" : "1639877449",
      "id" : 1639877449
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 25, 35 ],
      "id_str" : "525413893",
      "id" : 525413893
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 36, 45 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 46, 56 ],
      "id_str" : "37989702",
      "id" : 37989702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894157402500681728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35931248382391, 8.587772548772199 ]
  },
  "id_str" : "894158958381977600",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @AsuraEnkhbayar @chrisdc77 @open_con @kirstie_j Yes, sorry for the acronym.",
  "id" : 894158958381977600,
  "in_reply_to_status_id" : 894157402500681728,
  "created_at" : "2017-08-06 11:31:23 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asura Enkhbayar",
      "screen_name" : "AsuraEnkhbayar",
      "indices" : [ 0, 15 ],
      "id_str" : "1639877449",
      "id" : 1639877449
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 16, 24 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Chris Chambers",
      "screen_name" : "chrisdc77",
      "indices" : [ 25, 35 ],
      "id_str" : "525413893",
      "id" : 525413893
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 36, 45 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    }, {
      "name" : "Kirstie Whitaker",
      "screen_name" : "kirstie_j",
      "indices" : [ 46, 56 ],
      "id_str" : "37989702",
      "id" : 37989702
    }, {
      "name" : "OpenCon",
      "screen_name" : "open_con",
      "indices" : [ 64, 73 ],
      "id_str" : "2452073258",
      "id" : 2452073258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894151548766494720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35906327311236, 8.58756140832917 ]
  },
  "id_str" : "894157297718616064",
  "in_reply_to_user_id" : 1639877449,
  "text" : "@AsuraEnkhbayar @o_guest @chrisdc77 @open_con @kirstie_j I love @open_con, but the focus seems to be pretty heavy on open access and OER to me.",
  "id" : 894157297718616064,
  "in_reply_to_status_id" : 894151548766494720,
  "created_at" : "2017-08-06 11:24:47 +0000",
  "in_reply_to_screen_name" : "AsuraEnkhbayar",
  "in_reply_to_user_id_str" : "1639877449",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Randy McIntosh",
      "screen_name" : "ar0mcintosh",
      "indices" : [ 9, 21 ],
      "id_str" : "1584137959",
      "id" : 1584137959
    }, {
      "name" : "Helena",
      "screen_name" : "Helena_LB",
      "indices" : [ 22, 32 ],
      "id_str" : "234309722",
      "id" : 234309722
    }, {
      "name" : "Sage Bionetworks",
      "screen_name" : "Sagebio",
      "indices" : [ 41, 49 ],
      "id_str" : "130579391",
      "id" : 130579391
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 50, 59 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "894156610792296448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35906327311236, 8.58756140832917 ]
  },
  "id_str" : "894156792384688128",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @ar0mcintosh @Helena_LB I think @Sagebio\/@wilbanks can potentially help out with that.",
  "id" : 894156792384688128,
  "in_reply_to_status_id" : 894156610792296448,
  "created_at" : "2017-08-06 11:22:46 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Harbin",
      "screen_name" : "postphdtheblog",
      "indices" : [ 3, 18 ],
      "id_str" : "889137024489447425",
      "id" : 889137024489447425
    }, {
      "name" : "PhDStudent",
      "screen_name" : "PhDStudents",
      "indices" : [ 122, 134 ],
      "id_str" : "526624220",
      "id" : 526624220
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "academia",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "894156158021382145",
  "text" : "RT @postphdtheblog: My story of why I left #academia my decision to leave meant I was free to write this, it's important. @PhDStudents http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PhDStudent",
        "screen_name" : "PhDStudents",
        "indices" : [ 102, 114 ],
        "id_str" : "526624220",
        "id" : 526624220
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "academia",
        "indices" : [ 23, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/4iZiD8haTM",
        "expanded_url" : "https:\/\/www.allisonharbin.com\/post-phd\/why-i-left-academia-part-1",
        "display_url" : "allisonharbin.com\/post-phd\/why-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "890713470500560896",
    "text" : "My story of why I left #academia my decision to leave meant I was free to write this, it's important. @PhDStudents https:\/\/t.co\/4iZiD8haTM",
    "id" : 890713470500560896,
    "created_at" : "2017-07-27 23:20:14 +0000",
    "user" : {
      "name" : "Allison Harbin",
      "screen_name" : "postphdtheblog",
      "protected" : false,
      "id_str" : "889137024489447425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889140375360872448\/aPBLby06_normal.jpg",
      "id" : 889137024489447425,
      "verified" : false
    }
  },
  "id" : 894156158021382145,
  "created_at" : "2017-08-06 11:20:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/toicaWMZ3y",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/Magenbrot",
      "display_url" : "en.m.wikipedia.org\/wiki\/Magenbrot"
    } ]
  },
  "geo" : { },
  "id_str" : "894139999876243456",
  "text" : "Switzerland, we have to talk about your ice cream game. Who's putting this in ice cream that's sold in summer? \uD83C\uDF68\uD83C\uDF84\uD83C\uDF6A https:\/\/t.co\/toicaWMZ3y",
  "id" : 894139999876243456,
  "created_at" : "2017-08-06 10:16:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nora Madison",
      "screen_name" : "theoryofnora",
      "indices" : [ 3, 16 ],
      "id_str" : "44045569",
      "id" : 44045569
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 23, 32 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "893895413895499776",
  "text" : "RT @theoryofnora: When @guardian gets it! \"How bisexuals are being sidelined in the global campaign for L, G and T rights.\" https:\/\/t.co\/Un\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 5, 14 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/Un23Fz6fjU",
        "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2017\/aug\/01\/bisexuals-sidelined-campaign-l-g-and-t-rights",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "893855538668326912",
    "text" : "When @guardian gets it! \"How bisexuals are being sidelined in the global campaign for L, G and T rights.\" https:\/\/t.co\/Un23Fz6fjU",
    "id" : 893855538668326912,
    "created_at" : "2017-08-05 15:25:42 +0000",
    "user" : {
      "name" : "Nora Madison",
      "screen_name" : "theoryofnora",
      "protected" : false,
      "id_str" : "44045569",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756286087681732608\/WnCx1pNx_normal.jpg",
      "id" : 44045569,
      "verified" : false
    }
  },
  "id" : 893895413895499776,
  "created_at" : "2017-08-05 18:04:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893858158703251466",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35920440185487, 8.58768343987027 ]
  },
  "id_str" : "893862171251232769",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai do you want to collaborate on that one? :D",
  "id" : 893862171251232769,
  "in_reply_to_status_id" : 893858158703251466,
  "created_at" : "2017-08-05 15:52:03 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/VuIpPzpupi",
      "expanded_url" : "https:\/\/twitter.com\/vortacist\/status\/893853832387719168",
      "display_url" : "twitter.com\/vortacist\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35921208821218, 8.587682219537703 ]
  },
  "id_str" : "893859749845970945",
  "text" : "There\u2019s also a \u2615\uFE0F-mug. I know what I\u2019ll have my office-\u2615\uFE0F in from now on. \uD83D\uDE0D https:\/\/t.co\/VuIpPzpupi",
  "id" : 893859749845970945,
  "created_at" : "2017-08-05 15:42:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Bahlai",
      "screen_name" : "cbahlai",
      "indices" : [ 0, 8 ],
      "id_str" : "958649520",
      "id" : 958649520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893852925134594048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35907494812992, 8.587727768405575 ]
  },
  "id_str" : "893857644414414848",
  "in_reply_to_user_id" : 958649520,
  "text" : "@cbahlai Stuff that ends on my desk follows the ideal gas law perfectly.",
  "id" : 893857644414414848,
  "in_reply_to_status_id" : 893852925134594048,
  "created_at" : "2017-08-05 15:34:04 +0000",
  "in_reply_to_screen_name" : "cbahlai",
  "in_reply_to_user_id_str" : "958649520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 0, 14 ],
      "id_str" : "257319757",
      "id" : 257319757
    }, {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 15, 25 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893850642829029379",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35922458589296, 8.587688870355846 ]
  },
  "id_str" : "893852684037619713",
  "in_reply_to_user_id" : 257319757,
  "text" : "@lorrainechu3n @blahah404 Why am I not surprised by this \uD83D\uDE1E",
  "id" : 893852684037619713,
  "in_reply_to_status_id" : 893850642829029379,
  "created_at" : "2017-08-05 15:14:21 +0000",
  "in_reply_to_screen_name" : "lorrainechu3n",
  "in_reply_to_user_id_str" : "257319757",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Minton",
      "screen_name" : "cjohnweb",
      "indices" : [ 0, 9 ],
      "id_str" : "17693715",
      "id" : 17693715
    }, {
      "name" : "openSNP team",
      "screen_name" : "openSNPorg",
      "indices" : [ 10, 21 ],
      "id_str" : "380205172",
      "id" : 380205172
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 53, 66 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893587183449276416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925663115909, 8.587679389145032 ]
  },
  "id_str" : "893840092514668544",
  "in_reply_to_user_id" : 17693715,
  "text" : "@cjohnweb @openSNPorg Thanks for the hint. Thanks to @PhilippBayer it's now automated and shouldn't happen again!",
  "id" : 893840092514668544,
  "in_reply_to_status_id" : 893587183449276416,
  "created_at" : "2017-08-05 14:24:19 +0000",
  "in_reply_to_screen_name" : "cjohnweb",
  "in_reply_to_user_id_str" : "17693715",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/1orh94NaWe",
      "expanded_url" : "https:\/\/twitter.com\/pennyb\/status\/893829324293459969",
      "display_url" : "twitter.com\/pennyb\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35941895683456, 8.58800602489324 ]
  },
  "id_str" : "893836171960254466",
  "text" : "\uD83D\uDC4D\uD83D\uDE0D thread on the issues we have in open*. https:\/\/t.co\/1orh94NaWe",
  "id" : 893836171960254466,
  "created_at" : "2017-08-05 14:08:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 3, 10 ],
      "id_str" : "6069772",
      "id" : 6069772
    }, {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 19, 33 ],
      "id_str" : "257319757",
      "id" : 257319757
    }, {
      "name" : "Jennifer Bayjoo",
      "screen_name" : "epicbayj",
      "indices" : [ 42, 51 ],
      "id_str" : "23600651",
      "id" : 23600651
    }, {
      "name" : "April H.",
      "screen_name" : "AprilHathcock",
      "indices" : [ 63, 77 ],
      "id_str" : "3209949862",
      "id" : 3209949862
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 89, 105 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "893835701275504640",
  "text" : "RT @pennyb: I love @lorrainechu3n, I love @epicbayj and I love @AprilHathcock and I love @gedankenstuecke and I want to hear more than dive\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lorraine Chuen",
        "screen_name" : "lorrainechu3n",
        "indices" : [ 7, 21 ],
        "id_str" : "257319757",
        "id" : 257319757
      }, {
        "name" : "Jennifer Bayjoo",
        "screen_name" : "epicbayj",
        "indices" : [ 30, 39 ],
        "id_str" : "23600651",
        "id" : 23600651
      }, {
        "name" : "April H.",
        "screen_name" : "AprilHathcock",
        "indices" : [ 51, 65 ],
        "id_str" : "3209949862",
        "id" : 3209949862
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 77, 93 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "893832955067600896",
    "geo" : { },
    "id_str" : "893833593943969793",
    "in_reply_to_user_id" : 6069772,
    "text" : "I love @lorrainechu3n, I love @epicbayj and I love @AprilHathcock and I love @gedankenstuecke and I want to hear more than diversity panels.",
    "id" : 893833593943969793,
    "in_reply_to_status_id" : 893832955067600896,
    "created_at" : "2017-08-05 13:58:30 +0000",
    "in_reply_to_screen_name" : "pennyb",
    "in_reply_to_user_id_str" : "6069772",
    "user" : {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "protected" : false,
      "id_str" : "6069772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/921360107505704960\/-c9C3uCY_normal.jpg",
      "id" : 6069772,
      "verified" : false
    }
  },
  "id" : 893835701275504640,
  "created_at" : "2017-08-05 14:06:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 0, 14 ],
      "id_str" : "257319757",
      "id" : 257319757
    }, {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 15, 22 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893703509123620864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35902490302723, 8.58747502076033 ]
  },
  "id_str" : "893831128326582272",
  "in_reply_to_user_id" : 257319757,
  "text" : "@lorrainechu3n @pennyb Thanks so much for doing this.",
  "id" : 893831128326582272,
  "in_reply_to_status_id" : 893703509123620864,
  "created_at" : "2017-08-05 13:48:42 +0000",
  "in_reply_to_screen_name" : "lorrainechu3n",
  "in_reply_to_user_id_str" : "257319757",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "893828460669530113",
  "text" : "RT @lorrainechu3n: Was told that this list wasn't actionable enough (by a white man, no less!). Taking suggestions for improvement: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/EYlRhErnYB",
        "expanded_url" : "https:\/\/github.com\/sparcopen\/opencon-dei-report\/issues",
        "display_url" : "github.com\/sparcopen\/open\u2026"
      }, {
        "indices" : [ 137, 160 ],
        "url" : "https:\/\/t.co\/YIA31bg5Fq",
        "expanded_url" : "https:\/\/twitter.com\/lorrainechu3n\/status\/893505865952579584",
        "display_url" : "twitter.com\/lorrainechu3n\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "893534387635052544",
    "text" : "Was told that this list wasn't actionable enough (by a white man, no less!). Taking suggestions for improvement: https:\/\/t.co\/EYlRhErnYB https:\/\/t.co\/YIA31bg5Fq",
    "id" : 893534387635052544,
    "created_at" : "2017-08-04 18:09:33 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 893828460669530113,
  "created_at" : "2017-08-05 13:38:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "indices" : [ 3, 17 ],
      "id_str" : "257319757",
      "id" : 257319757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FSCI",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "893828444877967360",
  "text" : "RT @lorrainechu3n: Reminder to conference planners (e.g. @ #FSCI!): we've compiled a guide for designing inclusive\/diverse events -&gt; https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FSCI",
        "indices" : [ 40, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/K0vD4WdXaK",
        "expanded_url" : "https:\/\/sparcopen.github.io\/opencon-dei-report\/",
        "display_url" : "sparcopen.github.io\/opencon-dei-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "893505865952579584",
    "text" : "Reminder to conference planners (e.g. @ #FSCI!): we've compiled a guide for designing inclusive\/diverse events -&gt; https:\/\/t.co\/K0vD4WdXaK",
    "id" : 893505865952579584,
    "created_at" : "2017-08-04 16:16:13 +0000",
    "user" : {
      "name" : "Lorraine Chuen",
      "screen_name" : "lorrainechu3n",
      "protected" : false,
      "id_str" : "257319757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926996461719621632\/aBq5xtJy_normal.jpg",
      "id" : 257319757,
      "verified" : false
    }
  },
  "id" : 893828444877967360,
  "created_at" : "2017-08-05 13:38:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "beau",
      "screen_name" : "beaugunderson",
      "indices" : [ 14, 28 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893661992673832960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35917819922049, 8.587742383806157 ]
  },
  "id_str" : "893736710911262720",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @beaugunderson Thanks for taking care of it! \uD83D\uDE0D",
  "id" : 893736710911262720,
  "in_reply_to_status_id" : 893661992673832960,
  "created_at" : "2017-08-05 07:33:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 0, 11 ],
      "id_str" : "402180727",
      "id" : 402180727
    }, {
      "name" : "MOZCCBHAM",
      "screen_name" : "mozccbham",
      "indices" : [ 12, 22 ],
      "id_str" : "825042283976343553",
      "id" : 825042283976343553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893441609391525888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35904700127184, 8.587568588562856 ]
  },
  "id_str" : "893442473250492416",
  "in_reply_to_user_id" : 402180727,
  "text" : "@PHerterich @mozccbham Let me know if you start a campaign. Happy to contribute my \uD83D\uDCB0share and spread the word.",
  "id" : 893442473250492416,
  "in_reply_to_status_id" : 893441609391525888,
  "created_at" : "2017-08-04 12:04:19 +0000",
  "in_reply_to_screen_name" : "PHerterich",
  "in_reply_to_user_id_str" : "402180727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/kVCg8LhR9I",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/893421460483649536",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35914944645471, 8.587681344397849 ]
  },
  "id_str" : "893441263420272640",
  "text" : "\"The study lacks adequate controls. 5 frowning poo emoji from reviewer 3\" https:\/\/t.co\/kVCg8LhR9I",
  "id" : 893441263420272640,
  "created_at" : "2017-08-04 11:59:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Herterich",
      "screen_name" : "PHerterich",
      "indices" : [ 0, 11 ],
      "id_str" : "402180727",
      "id" : 402180727
    }, {
      "name" : "MOZCCBHAM",
      "screen_name" : "mozccbham",
      "indices" : [ 12, 22 ],
      "id_str" : "825042283976343553",
      "id" : 825042283976343553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893413096122920960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35948610770893, 8.588433426043776 ]
  },
  "id_str" : "893437918374744066",
  "in_reply_to_user_id" : 402180727,
  "text" : "@PHerterich @mozccbham Took a brief video why we want to go and then spammed social media like hell. Also: asked all of our friends to contribute ;)",
  "id" : 893437918374744066,
  "in_reply_to_status_id" : 893413096122920960,
  "created_at" : "2017-08-04 11:46:13 +0000",
  "in_reply_to_screen_name" : "PHerterich",
  "in_reply_to_user_id_str" : "402180727",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hao Ye",
      "screen_name" : "Hao_and_Y",
      "indices" : [ 0, 10 ],
      "id_str" : "111093392",
      "id" : 111093392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "893248998324043777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401708275933, 8.753353729491753 ]
  },
  "id_str" : "893249529507713032",
  "in_reply_to_user_id" : 111093392,
  "text" : "@Hao_and_Y Additionally OUP journals were totally screwed up today as well. Refused to load the CSS. Another case of reading via sci-hub.",
  "id" : 893249529507713032,
  "in_reply_to_status_id" : 893248998324043777,
  "created_at" : "2017-08-03 23:17:38 +0000",
  "in_reply_to_screen_name" : "Hao_and_Y",
  "in_reply_to_user_id_str" : "111093392",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ZKGFPMYyIL",
      "expanded_url" : "https:\/\/twitter.com\/__yoson__\/status\/893234854837530625",
      "display_url" : "twitter.com\/__yoson__\/stat\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11385994252652, 8.753377462985114 ]
  },
  "id_str" : "893248002198036480",
  "text" : "Observed the same today. Just put all DOIs straight into Sci-Hub as a workaround. https:\/\/t.co\/ZKGFPMYyIL",
  "id" : 893248002198036480,
  "created_at" : "2017-08-03 23:11:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/ggd5kQKnrF",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BXV3SQGlmFb\/",
      "display_url" : "instagram.com\/p\/BXV3SQGlmFb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "893176024627892224",
  "text" : "Describe your thesis progress with a picture. https:\/\/t.co\/ggd5kQKnrF",
  "id" : 893176024627892224,
  "created_at" : "2017-08-03 18:25:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 3, 12 ],
      "id_str" : "31936449",
      "id" : 31936449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/WEE1qCmDPu",
      "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2017\/08\/03\/i-was-wrong-part-2\/",
      "display_url" : "liorpachter.wordpress.com\/2017\/08\/03\/i-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "893149981330296833",
  "text" : "RT @lpachter: I was wrong (part\u00A02) https:\/\/t.co\/WEE1qCmDPu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/WEE1qCmDPu",
        "expanded_url" : "https:\/\/liorpachter.wordpress.com\/2017\/08\/03\/i-was-wrong-part-2\/",
        "display_url" : "liorpachter.wordpress.com\/2017\/08\/03\/i-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "893149070717579264",
    "text" : "I was wrong (part\u00A02) https:\/\/t.co\/WEE1qCmDPu",
    "id" : 893149070717579264,
    "created_at" : "2017-08-03 16:38:27 +0000",
    "user" : {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "protected" : false,
      "id_str" : "31936449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861688064258719744\/p8MVi-zW_normal.jpg",
      "id" : 31936449,
      "verified" : false
    }
  },
  "id" : 893149981330296833,
  "created_at" : "2017-08-03 16:42:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 65, 74 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/rD4IMrxojJ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/893120837603250176",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "893120837603250176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17233559581533, 8.627536012910008 ]
  },
  "id_str" : "893121219083546626",
  "in_reply_to_user_id" : 14286491,
  "text" : "The write-up is appreciated a lot, as it makes it so accessible! @madprime https:\/\/t.co\/rD4IMrxojJ",
  "id" : 893121219083546626,
  "in_reply_to_status_id" : 893120837603250176,
  "created_at" : "2017-08-03 14:47:46 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 74, 83 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BOSC2017",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/tzIOndqwAy",
      "expanded_url" : "http:\/\/www.madeleineball.net\/open-sourcing-ourselves\/",
      "display_url" : "madeleineball.net\/open-sourcing-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17232289373606, 8.62754011689078 ]
  },
  "id_str" : "893120837603250176",
  "text" : "You want to know what Open Humans and \u201EOpen Sourcing Ourselves\u201C is about? @madprime wrote up her #BOSC2017 keynote: https:\/\/t.co\/tzIOndqwAy",
  "id" : 893120837603250176,
  "created_at" : "2017-08-03 14:46:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Kiggins",
      "screen_name" : "neuromusic",
      "indices" : [ 0, 11 ],
      "id_str" : "8932272",
      "id" : 8932272
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/892874746341314561\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/tzVqCfp4Yb",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/DGQg19rVoAA1cgL.jpg",
      "id_str" : "892874737587691520",
      "id" : 892874737587691520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/DGQg19rVoAA1cgL.jpg",
      "sizes" : [ {
        "h" : 328,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/tzVqCfp4Yb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "892873706891956224",
  "geo" : { },
  "id_str" : "892874746341314561",
  "in_reply_to_user_id" : 8932272,
  "text" : "@neuromusic Can't wait for those sweet 26h productivity days. https:\/\/t.co\/tzVqCfp4Yb",
  "id" : 892874746341314561,
  "in_reply_to_status_id" : 892873706891956224,
  "created_at" : "2017-08-02 22:28:22 +0000",
  "in_reply_to_screen_name" : "neuromusic",
  "in_reply_to_user_id_str" : "8932272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/892871429070499844\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/uBMFYcOzWW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DGQd09kU0AEieMc.jpg",
      "id_str" : "892871421843525633",
      "id" : 892871421843525633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DGQd09kU0AEieMc.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 352
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 352
      } ],
      "display_url" : "pic.twitter.com\/uBMFYcOzWW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11395873333704, 8.753533164294016 ]
  },
  "id_str" : "892871429070499844",
  "text" : "Four data points make a trend, right? \uD83D\uDE13 https:\/\/t.co\/uBMFYcOzWW",
  "id" : 892871429070499844,
  "created_at" : "2017-08-02 22:15:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]