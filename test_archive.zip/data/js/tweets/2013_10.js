Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096482039, 8.2830904556 ]
  },
  "id_str" : "396048084314378241",
  "text" : "\u00ABWenn ich dir weiterhin die Miete rechtzeitig \u00FCberweisen soll muss ich mehr Flattr-Einnahmen generieren. Ich sollte mehr instagramen.\u00BB",
  "id" : 396048084314378241,
  "created_at" : "2013-10-31 22:56:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958497, 8.282848395 ]
  },
  "id_str" : "396021216907374592",
  "text" : "\u00ABEr stand dann in Niederrad statt in Nied\u00BB \u2013 \u00ABPaarweise Alignments &amp; Sequence Similarity vs. Sequence Identity \u00FCben wir dann wohl noch mal\u2026\u00BB",
  "id" : 396021216907374592,
  "created_at" : "2013-10-31 21:09:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/RlUKawhrET",
      "expanded_url" : "http:\/\/media.npr.org\/assets\/img\/2012\/10\/30\/orca_custom-b834caa6ef1cf6e97b495f8b1666e5745b28d9e1-s6-c30.jpg",
      "display_url" : "media.npr.org\/assets\/img\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396003384899411968",
  "text" : "Sneaky http:\/\/t.co\/RlUKawhrET",
  "id" : 396003384899411968,
  "created_at" : "2013-10-31 19:58:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395995177082318848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095900661, 8.2829211094 ]
  },
  "id_str" : "395996912501161985",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot dann kann ich ja bis morgen Abend wieder hungern!",
  "id" : 395996912501161985,
  "in_reply_to_status_id" : 395995177082318848,
  "created_at" : "2013-10-31 19:33:15 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395994052887199745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095537724, 8.2827991527 ]
  },
  "id_str" : "395994764220579840",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot klingt aber nicht mehr nach einem deutschen Qualit\u00E4tsprodukt. Ernte wird dann mit dem Wochenmarktsimulator 2014 verkauft.",
  "id" : 395994764220579840,
  "in_reply_to_status_id" : 395994052887199745,
  "created_at" : "2013-10-31 19:24:43 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/HjXhKNXVmA",
      "expanded_url" : "http:\/\/85playgames.eval.hwcdn.net\/thumbs\/super-mario-world-tm.gif",
      "display_url" : "85playgames.eval.hwcdn.net\/thumbs\/super-m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "395992412603940864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096543431, 8.2829606879 ]
  },
  "id_str" : "395993297887715329",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot bitte, werde ich jetzt zum essen eingeladen? http:\/\/t.co\/HjXhKNXVmA",
  "id" : 395993297887715329,
  "in_reply_to_status_id" : 395992412603940864,
  "created_at" : "2013-10-31 19:18:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096223231, 8.2830168926 ]
  },
  "id_str" : "395989367971651584",
  "text" : "\u00ABTrue citizens are not the audience of their government, nor their consumers; they are its makers. The same may be said of a viable culture\u00BB",
  "id" : 395989367971651584,
  "created_at" : "2013-10-31 19:03:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/8HADdzLjSa",
      "expanded_url" : "http:\/\/bit.ly\/1h3Nnio",
      "display_url" : "bit.ly\/1h3Nnio"
    } ]
  },
  "geo" : { },
  "id_str" : "395988791946924032",
  "text" : "RT @wilbanks: Not that I'm a deontologist or anything...  http:\/\/t.co\/8HADdzLjSa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\" rel=\"nofollow\"\u003EEchofon for Android PRO\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/8HADdzLjSa",
        "expanded_url" : "http:\/\/bit.ly\/1h3Nnio",
        "display_url" : "bit.ly\/1h3Nnio"
      } ]
    },
    "geo" : { },
    "id_str" : "395988096615202816",
    "text" : "Not that I'm a deontologist or anything...  http:\/\/t.co\/8HADdzLjSa",
    "id" : 395988096615202816,
    "created_at" : "2013-10-31 18:58:13 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 395988791946924032,
  "created_at" : "2013-10-31 19:00:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Ip9D3ui0gR",
      "expanded_url" : "http:\/\/arstechnica.com\/gadgets\/2006\/10\/8044\/",
      "display_url" : "arstechnica.com\/gadgets\/2006\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.067612, 8.489082 ]
  },
  "id_str" : "395973678070235136",
  "text" : "TIL: In 2006 the MPAA did a 'Respect Copyright' merit badge which was implemented by the LA Boy Scouts\u2026 http:\/\/t.co\/Ip9D3ui0gR",
  "id" : 395973678070235136,
  "created_at" : "2013-10-31 18:00:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1027602538, 8.5662697417 ]
  },
  "id_str" : "395971772920893440",
  "text" : "\u00ABDie Jobsituation f\u00FCr Molekularbiologen ist so competitive. Ich h\u00E4tte doch Spieleprogrammierer werden sollen.\u00BB \u2014 \u00ABPilzsammelsimulator 2013.\u00BB",
  "id" : 395971772920893440,
  "created_at" : "2013-10-31 17:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1189451391, 8.6807129711 ]
  },
  "id_str" : "395968517692203008",
  "text" : "\u00ABStop being so inParanoid!\u00BB \u2014 \u00ABSagt der Typ der die ganze Zeit nur HaMStRt?\u00BB",
  "id" : 395968517692203008,
  "created_at" : "2013-10-31 17:40:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/CdhgpCNPL8",
      "expanded_url" : "http:\/\/i.imgur.com\/lC7S7dU.png",
      "display_url" : "i.imgur.com\/lC7S7dU.png"
    } ]
  },
  "geo" : { },
  "id_str" : "395884959254056960",
  "text" : "Whatever\u2026 http:\/\/t.co\/CdhgpCNPL8",
  "id" : 395884959254056960,
  "created_at" : "2013-10-31 12:08:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cariaso",
      "screen_name" : "cariaso",
      "indices" : [ 0, 8 ],
      "id_str" : "14151263",
      "id" : 14151263
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395883976339906560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722872438, 8.6276583501 ]
  },
  "id_str" : "395884096528056320",
  "in_reply_to_user_id" : 14151263,
  "text" : "@cariaso @PhilippBayer ah, thanks :)",
  "id" : 395884096528056320,
  "in_reply_to_status_id" : 395883976339906560,
  "created_at" : "2013-10-31 12:04:58 +0000",
  "in_reply_to_screen_name" : "cariaso",
  "in_reply_to_user_id_str" : "14151263",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395865652356870144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722987642, 8.6276514168 ]
  },
  "id_str" : "395867042588676096",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng aus welcher Perspektive? ;)",
  "id" : 395867042588676096,
  "in_reply_to_status_id" : 395865652356870144,
  "created_at" : "2013-10-31 10:57:12 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723123986, 8.6276422374 ]
  },
  "id_str" : "395866775013060608",
  "text" : "\u00ABDu programmierst so schnell das Netbeans 400% CPU-Load hat?!\u00BB",
  "id" : 395866775013060608,
  "created_at" : "2013-10-31 10:56:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/gLWNRCzB2Z",
      "expanded_url" : "http:\/\/www.pleated-jeans.com\/wp-content\/uploads\/2013\/10\/gaquqVU.gif",
      "display_url" : "pleated-jeans.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395865456977772544",
  "text" : "Gemeinsam essen gehen. Symbolfoto http:\/\/t.co\/gLWNRCzB2Z",
  "id" : 395865456977772544,
  "created_at" : "2013-10-31 10:50:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395864031921463296",
  "geo" : { },
  "id_str" : "395864223525253120",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer yeah, that's what I meant. As the DB was read-only for that time no data could be uploaded.",
  "id" : 395864223525253120,
  "in_reply_to_status_id" : 395864031921463296,
  "created_at" : "2013-10-31 10:46:00 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395863368688742400",
  "geo" : { },
  "id_str" : "395863649778016256",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer I don't think that this enters. The created_at of all genotype-objects is plotted. And that is set before proces.",
  "id" : 395863649778016256,
  "in_reply_to_status_id" : 395863368688742400,
  "created_at" : "2013-10-31 10:43:43 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/kaX6Ib5ZsO",
      "expanded_url" : "http:\/\/rarlindseysmash.com\/posts\/stupid-programmer-tricks-and-star-wars-gifs",
      "display_url" : "rarlindseysmash.com\/posts\/stupid-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395861930776092673",
  "text" : "\u00ABA simple way to get Star Wars gifs by the quote\u00BB http:\/\/t.co\/kaX6Ib5ZsO",
  "id" : 395861930776092673,
  "created_at" : "2013-10-31 10:36:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395859868017373185",
  "geo" : { },
  "id_str" : "395860022334193664",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and even if you do you probably don't check every 24h to see whether it's back up. So revisiting will be spread out over time.",
  "id" : 395860022334193664,
  "in_reply_to_status_id" : 395859868017373185,
  "created_at" : "2013-10-31 10:29:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/zeoLB1VPZZ",
      "expanded_url" : "http:\/\/bit.ly\/1hv3l2H",
      "display_url" : "bit.ly\/1hv3l2H"
    } ]
  },
  "geo" : { },
  "id_str" : "395858558103089152",
  "text" : "RT @AkshatRathi: \"Getting fresh, organic verbs used to pose a challenge, because of the unusual way they propagate.\" http:\/\/t.co\/zeoLB1VPZZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/zeoLB1VPZZ",
        "expanded_url" : "http:\/\/bit.ly\/1hv3l2H",
        "display_url" : "bit.ly\/1hv3l2H"
      } ]
    },
    "geo" : { },
    "id_str" : "395831288042881024",
    "text" : "\"Getting fresh, organic verbs used to pose a challenge, because of the unusual way they propagate.\" http:\/\/t.co\/zeoLB1VPZZ",
    "id" : 395831288042881024,
    "created_at" : "2013-10-31 08:35:07 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 395858558103089152,
  "created_at" : "2013-10-31 10:23:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395854904582873088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722857346, 8.6276626772 ]
  },
  "id_str" : "395855286952808448",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s easy to explain: how many web services have you ever revisited after they were down the first time you wanted to try?",
  "id" : 395855286952808448,
  "in_reply_to_status_id" : 395854904582873088,
  "created_at" : "2013-10-31 10:10:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395853308713132032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172278751, 8.6276768205 ]
  },
  "id_str" : "395854563066269696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and we will always be able to see the one time we updated Postgres ;)",
  "id" : 395854563066269696,
  "in_reply_to_status_id" : 395853308713132032,
  "created_at" : "2013-10-31 10:07:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/d1BlhHNt5l",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Zeigarnik_effect",
      "display_url" : "en.m.wikipedia.org\/wiki\/Zeigarnik\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395847066356023296",
  "text" : "I'm not procrastinating, I'm effectively using the Zeigarnik effect! http:\/\/t.co\/d1BlhHNt5l",
  "id" : 395847066356023296,
  "created_at" : "2013-10-31 09:37:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395838470016344064",
  "text" : "\u00ABWenn ich sage ich bin Bioinformatiker und jemand fragt was das ist sage ich immer ich photoshoppe Fr\u00F6sche.\u00BB",
  "id" : 395838470016344064,
  "created_at" : "2013-10-31 09:03:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Pete Etchells",
      "screen_name" : "PeteEtchells",
      "indices" : [ 3, 16 ],
      "id_str" : "19350455",
      "id" : 19350455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/hGLW1pg8Cv",
      "expanded_url" : "http:\/\/www.theguardian.com\/science\/2013\/oct\/31\/zombies-cognitive-dissonance-halloween",
      "display_url" : "theguardian.com\/science\/2013\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395830158957248512",
  "text" : "RT @PeteEtchells: Prep for an impending zombie apocalypse by getting the philosophising out of the way now: http:\/\/t.co\/hGLW1pg8Cv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/hGLW1pg8Cv",
        "expanded_url" : "http:\/\/www.theguardian.com\/science\/2013\/oct\/31\/zombies-cognitive-dissonance-halloween",
        "display_url" : "theguardian.com\/science\/2013\/o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395823623547928576",
    "text" : "Prep for an impending zombie apocalypse by getting the philosophising out of the way now: http:\/\/t.co\/hGLW1pg8Cv",
    "id" : 395823623547928576,
    "created_at" : "2013-10-31 08:04:40 +0000",
    "user" : {
      "name" : "Dr Pete Etchells",
      "screen_name" : "PeteEtchells",
      "protected" : false,
      "id_str" : "19350455",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3698098081\/d03e95d2ef1470a8b632067ead1e0917_normal.jpeg",
      "id" : 19350455,
      "verified" : true
    }
  },
  "id" : 395830158957248512,
  "created_at" : "2013-10-31 08:30:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/uD91fNym9O",
      "expanded_url" : "http:\/\/instagram.com\/p\/gH9lzihwjB\/",
      "display_url" : "instagram.com\/p\/gH9lzihwjB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "395823782692421632",
  "text" : "\u00ABImmerhin ist die Aussicht auf dem Riedberg gut!\u00BB http:\/\/t.co\/uD91fNym9O",
  "id" : 395823782692421632,
  "created_at" : "2013-10-31 08:05:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395786203829530624",
  "geo" : { },
  "id_str" : "395822438304321537",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that has been like this for a while. Not 100% sure how it's decided on (not) setting a link, probably whether it returns 404.",
  "id" : 395822438304321537,
  "in_reply_to_status_id" : 395786203829530624,
  "created_at" : "2013-10-31 07:59:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/y9d834QUmN",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/outward\/2013\/10\/16\/is_polyamory_a_choice.html",
      "display_url" : "slate.com\/blogs\/outward\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.160593, 8.650569 ]
  },
  "id_str" : "395817890286682112",
  "text" : "\u00ABThe correct response to \u2018nature vs. nurture\u2019 is: There\u2019s no way to know for sure, and it doesn\u2019t matter\u00BB http:\/\/t.co\/y9d834QUmN",
  "id" : 395817890286682112,
  "created_at" : "2013-10-31 07:41:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 0, 7 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395722579001888768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096371682, 8.2829764098 ]
  },
  "id_str" : "395800253154492416",
  "in_reply_to_user_id" : 852039852,
  "text" : "@uBiome if just looking at the microbiomes you could tell me what kind of fun and how much of it I had in the prev 8h? Pretty much fun. :)",
  "id" : 395800253154492416,
  "in_reply_to_status_id" : 395722579001888768,
  "created_at" : "2013-10-31 06:31:48 +0000",
  "in_reply_to_screen_name" : "uBiome",
  "in_reply_to_user_id_str" : "852039852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395706670606598145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395707276021202944",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer guess it\u2019s some auto-detection-magic that internally sets the flag if missing.",
  "id" : 395707276021202944,
  "in_reply_to_status_id" : 395706670606598145,
  "created_at" : "2013-10-31 00:22:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395702856440758272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395705573117014016",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer should, but give it a try and see for yourself :D",
  "id" : 395705573117014016,
  "in_reply_to_status_id" : 395702856440758272,
  "created_at" : "2013-10-31 00:15:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395698090780282880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009587905, 8.28294847 ]
  },
  "id_str" : "395702668473417729",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you just use xvf every time and it virtually never fails? ;)",
  "id" : 395702668473417729,
  "in_reply_to_status_id" : 395698090780282880,
  "created_at" : "2013-10-31 00:04:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ubiome",
      "indices" : [ 137, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395690106696515584",
  "text" : "For 8h no \u00ABcontact with antiseptic or antibiotic soaps or lotions, sex, kissing, food, hot tubs &amp; pools, and the like.\u00BB aka \u201Cno fun\u201D #ubiome",
  "id" : 395690106696515584,
  "created_at" : "2013-10-30 23:14:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/8XuHTHM0uG",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/food-matters\/2013\/10\/30\/sexually-transmitted-food-allergens\/",
      "display_url" : "blogs.scientificamerican.com\/food-matters\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395685845883453440",
  "text" : "Sexually Transmitted Food Allergens http:\/\/t.co\/8XuHTHM0uG",
  "id" : 395685845883453440,
  "created_at" : "2013-10-30 22:57:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/9NGWYPWgT5",
      "expanded_url" : "http:\/\/imgur.com\/wp9Qr8V",
      "display_url" : "imgur.com\/wp9Qr8V"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395682537798107136",
  "text" : "\u00ABI just remembered my dog has pooped while I was bathing her so I think Rocket dog might be okay.\u00BB http:\/\/t.co\/9NGWYPWgT5",
  "id" : 395682537798107136,
  "created_at" : "2013-10-30 22:44:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395679478921191424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096711992, 8.2829563279 ]
  },
  "id_str" : "395681659196280832",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer next: PCoA ;)",
  "id" : 395681659196280832,
  "in_reply_to_status_id" : 395679478921191424,
  "created_at" : "2013-10-30 22:40:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/Lmabr9Snhe",
      "expanded_url" : "http:\/\/i.imgur.com\/Rklw8Z8.jpg",
      "display_url" : "i.imgur.com\/Rklw8Z8.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "395669507509067776",
  "text" : "spooning http:\/\/t.co\/Lmabr9Snhe",
  "id" : 395669507509067776,
  "created_at" : "2013-10-30 21:52:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0143343011, 8.2757126036 ]
  },
  "id_str" : "395639374005956610",
  "text" : "\u00ABWir haben im Kindergarten eine Variante gesungen. Dar\u00FCber was Kinder k\u00F6nnen, nicht das der Chute nicht \u00F6ffnet.\u00BB\u2014\u00ABBlut war an der Schaukel\u2026\u00BB",
  "id" : 395639374005956610,
  "created_at" : "2013-10-30 19:52:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 9, 16 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/tizwGb1p62",
      "expanded_url" : "http:\/\/instagram.com\/p\/gGZYwShwi2\/",
      "display_url" : "instagram.com\/p\/gGZYwShwi2\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0059405631, 8.2865283783 ]
  },
  "id_str" : "395604106297233408",
  "text" : "Yay, the @uBiome sampling kit arrived. Time to get a peek into my mouth\/gut\/genital microbiomes! @\u2026 http:\/\/t.co\/tizwGb1p62",
  "id" : 395604106297233408,
  "created_at" : "2013-10-30 17:32:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Iv67tWOz4b",
      "expanded_url" : "https:\/\/twitter.com\/GenomeTweetHIV\/status\/395580482370695168",
      "display_url" : "twitter.com\/GenomeTweetHIV\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0069896838, 8.2831545233 ]
  },
  "id_str" : "395600588148584449",
  "text" : "TWASTA: Because bioinformatics utterly lacks yet another sequence file format. https:\/\/t.co\/Iv67tWOz4b",
  "id" : 395600588148584449,
  "created_at" : "2013-10-30 17:18:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AlexisMychajliw\uD83D\uDC2D\u26CF",
      "screen_name" : "AlexisMychajliw",
      "indices" : [ 3, 19 ],
      "id_str" : "1245008893",
      "id" : 1245008893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/FBwlPyqLcR",
      "expanded_url" : "http:\/\/www.gradhacker.org\/2013\/10\/16\/student-or-professional-on-the-paradox-of-being-a-graduate-student\/",
      "display_url" : "gradhacker.org\/2013\/10\/16\/stu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395599227747045376",
  "text" : "RT @AlexisMychajliw: Student or Professional? On the Paradox of Being a Graduate \u201CStudent\u201D http:\/\/t.co\/FBwlPyqLcR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/FBwlPyqLcR",
        "expanded_url" : "http:\/\/www.gradhacker.org\/2013\/10\/16\/student-or-professional-on-the-paradox-of-being-a-graduate-student\/",
        "display_url" : "gradhacker.org\/2013\/10\/16\/stu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395294626048774144",
    "text" : "Student or Professional? On the Paradox of Being a Graduate \u201CStudent\u201D http:\/\/t.co\/FBwlPyqLcR",
    "id" : 395294626048774144,
    "created_at" : "2013-10-29 21:02:37 +0000",
    "user" : {
      "name" : "AlexisMychajliw\uD83D\uDC2D\u26CF",
      "screen_name" : "AlexisMychajliw",
      "protected" : false,
      "id_str" : "1245008893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903399319658651648\/T_f2NQso_normal.jpg",
      "id" : 1245008893,
      "verified" : false
    }
  },
  "id" : 395599227747045376,
  "created_at" : "2013-10-30 17:13:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/ivvMsGb3CM",
      "expanded_url" : "http:\/\/i.imgur.com\/nBqPMMe.jpg",
      "display_url" : "i.imgur.com\/nBqPMMe.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.991074, 8.371525 ]
  },
  "id_str" : "395597680279556096",
  "text" : "I didn't know Ewoks are doing Batesian mimicry! http:\/\/t.co\/ivvMsGb3CM",
  "id" : 395597680279556096,
  "created_at" : "2013-10-30 17:06:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "indices" : [ 3, 17 ],
      "id_str" : "69133574",
      "id" : 69133574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futureofstats",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/KjVnilAZQg",
      "expanded_url" : "http:\/\/jakevdp.github.io\/blog\/2013\/10\/26\/big-data-brain-drain\/",
      "display_url" : "jakevdp.github.io\/blog\/2013\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395595218185379840",
  "text" : "RT @hadleywickham: the big data brain drain: http:\/\/t.co\/KjVnilAZQg. relevant to #futureofstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "futureofstats",
        "indices" : [ 62, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/KjVnilAZQg",
        "expanded_url" : "http:\/\/jakevdp.github.io\/blog\/2013\/10\/26\/big-data-brain-drain\/",
        "display_url" : "jakevdp.github.io\/blog\/2013\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395590303060459520",
    "text" : "the big data brain drain: http:\/\/t.co\/KjVnilAZQg. relevant to #futureofstats",
    "id" : 395590303060459520,
    "created_at" : "2013-10-30 16:37:32 +0000",
    "user" : {
      "name" : "Hadley Wickham",
      "screen_name" : "hadleywickham",
      "protected" : false,
      "id_str" : "69133574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/905186381995147264\/7zKAG5sY_normal.jpg",
      "id" : 69133574,
      "verified" : true
    }
  },
  "id" : 395595218185379840,
  "created_at" : "2013-10-30 16:57:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Martin Delius)))",
      "screen_name" : "martindelius",
      "indices" : [ 0, 13 ],
      "id_str" : "279412211",
      "id" : 279412211
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395579517361983488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1283219878, 8.6765593893 ]
  },
  "id_str" : "395587610711961600",
  "in_reply_to_user_id" : 279412211,
  "text" : "@martindelius @Senficon lmftfy: @senfefecon",
  "id" : 395587610711961600,
  "in_reply_to_status_id" : 395579517361983488,
  "created_at" : "2013-10-30 16:26:50 +0000",
  "in_reply_to_screen_name" : "martindelius",
  "in_reply_to_user_id_str" : "279412211",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/bjDoSGyf4P",
      "expanded_url" : "http:\/\/i.imgur.com\/wsDwkJK.gif",
      "display_url" : "i.imgur.com\/wsDwkJK.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "395568199128715264",
  "text" : "he felt the wind, he felt the cold, he felt the awful drop\u2026 http:\/\/t.co\/bjDoSGyf4P",
  "id" : 395568199128715264,
  "created_at" : "2013-10-30 15:09:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.174784434, 8.6105524251 ]
  },
  "id_str" : "395547582413668352",
  "text" : "\u00ABWie hast du das gefunden?\u00BB \u2014 \u00ABStrg+F im Browser.\u00BB \u2014 \u00ABDas schreibst du nicht in deine Arbeit. Das nennt man \u2018Naive Pattern Matching\u2019.\u00BB",
  "id" : 395547582413668352,
  "created_at" : "2013-10-30 13:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172296553, 8.6274504382 ]
  },
  "id_str" : "395521007077031936",
  "text" : "\u00ABDie Autoklaven-Simulation: Bei 96\u00B0C in die Sauna und auspeitschen.\u00BB \u2014 \u00ABDa muss man sich seine Staffelpartner gut aussuchen.\u00BB",
  "id" : 395521007077031936,
  "created_at" : "2013-10-30 12:02:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395490787703525377",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722368943, 8.6276826524 ]
  },
  "id_str" : "395491319097069568",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, okay. Thanks for fixing :)",
  "id" : 395491319097069568,
  "in_reply_to_status_id" : 395490787703525377,
  "created_at" : "2013-10-30 10:04:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395490028958146561",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722368943, 8.6276826524 ]
  },
  "id_str" : "395490578928271360",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, i was also puzzled and started investigating those exceptions :)",
  "id" : 395490578928271360,
  "in_reply_to_status_id" : 395490028958146561,
  "created_at" : "2013-10-30 10:01:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/TZGUfSw5JM",
      "expanded_url" : "http:\/\/thumbs2.ebaystatic.com\/d\/l225\/m\/mYUBiVtgKb9Y78YnHCrYHkA.jpg",
      "display_url" : "thumbs2.ebaystatic.com\/d\/l225\/m\/mYUBi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "395479649351782401",
  "geo" : { },
  "id_str" : "395480155038044161",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot more like http:\/\/t.co\/TZGUfSw5JM",
  "id" : 395480155038044161,
  "in_reply_to_status_id" : 395479649351782401,
  "created_at" : "2013-10-30 09:19:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/UuIjrnNo9L",
      "expanded_url" : "http:\/\/imgur.com\/7wQ3uJB",
      "display_url" : "imgur.com\/7wQ3uJB"
    } ]
  },
  "geo" : { },
  "id_str" : "395478380579016704",
  "text" : "\u00ABThats a bad ass HP. I miss mine best programmable calculator ever for field\/surveying use. IMO.\u00BB http:\/\/t.co\/UuIjrnNo9L",
  "id" : 395478380579016704,
  "created_at" : "2013-10-30 09:12:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 3, 14 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 91, 103 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/BESqC5l04N",
      "expanded_url" : "http:\/\/j.mp\/1is6EW8",
      "display_url" : "j.mp\/1is6EW8"
    } ]
  },
  "geo" : { },
  "id_str" : "395477333387522048",
  "text" : "RT @LouWoodley: Does fiction help us to escape our filter bubbles\/confirmation biases? Via @brainpicker: http:\/\/t.co\/BESqC5l04N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria Popova",
        "screen_name" : "brainpicker",
        "indices" : [ 75, 87 ],
        "id_str" : "9207632",
        "id" : 9207632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/BESqC5l04N",
        "expanded_url" : "http:\/\/j.mp\/1is6EW8",
        "display_url" : "j.mp\/1is6EW8"
      } ]
    },
    "geo" : { },
    "id_str" : "395477165707653120",
    "text" : "Does fiction help us to escape our filter bubbles\/confirmation biases? Via @brainpicker: http:\/\/t.co\/BESqC5l04N",
    "id" : 395477165707653120,
    "created_at" : "2013-10-30 09:07:58 +0000",
    "user" : {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "protected" : false,
      "id_str" : "20342875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/415633332408688640\/IRl4qNXY_normal.jpeg",
      "id" : 20342875,
      "verified" : false
    }
  },
  "id" : 395477333387522048,
  "created_at" : "2013-10-30 09:08:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/6Wh0FuCMOH",
      "expanded_url" : "http:\/\/imgur.com\/lzaMeXm",
      "display_url" : "imgur.com\/lzaMeXm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0921231929, 8.605108529 ]
  },
  "id_str" : "395448967473139712",
  "text" : "Next: banana fMRI, though I\u2019m not sure how that goes with dead salmon and cheese. http:\/\/t.co\/6Wh0FuCMOH",
  "id" : 395448967473139712,
  "created_at" : "2013-10-30 07:15:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/mxpHQ77EaY",
      "expanded_url" : "http:\/\/what-if.xkcd.com\/69\/",
      "display_url" : "what-if.xkcd.com\/69\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958, 8.362922 ]
  },
  "id_str" : "395447731709554688",
  "text" : "When, if ever, will Facebook contain more profiles of dead people than of living ones? http:\/\/t.co\/mxpHQ77EaY",
  "id" : 395447731709554688,
  "created_at" : "2013-10-30 07:11:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/9iZ7GXoJ1Y",
      "expanded_url" : "http:\/\/saypeople.com\/2013\/10\/30\/do-you-know-the-time-of-the-day-when-you-are-most-honest-kind-of-yourself\/",
      "display_url" : "saypeople.com\/2013\/10\/30\/do-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395444356481839104",
  "text" : "Morning morality: Maybe it's not that self-control isn't depleted yet but ppl aren't awake enough for lying? http:\/\/t.co\/9iZ7GXoJ1Y",
  "id" : 395444356481839104,
  "created_at" : "2013-10-30 06:57:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/TwQ15PWGeQ",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/VVm5LEeQkxk\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.003601, 8.353322 ]
  },
  "id_str" : "395442539958108160",
  "text" : "Zombies in the\u00A0landscape http:\/\/t.co\/TwQ15PWGeQ",
  "id" : 395442539958108160,
  "created_at" : "2013-10-30 06:50:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/IRuXAuDLSq",
      "expanded_url" : "http:\/\/i.imgur.com\/Wdul0y8.gif",
      "display_url" : "i.imgur.com\/Wdul0y8.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009668, 8.283109 ]
  },
  "id_str" : "395344294552559616",
  "text" : "\u00ABNie streichelst du mir den Kopf!\u00BB http:\/\/t.co\/IRuXAuDLSq",
  "id" : 395344294552559616,
  "created_at" : "2013-10-30 00:19:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Orr, but maybe not the one you're expecting",
      "screen_name" : "anatotitan",
      "indices" : [ 3, 14 ],
      "id_str" : "15776891",
      "id" : 15776891
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dinosaurs",
      "indices" : [ 83, 93 ]
    }, {
      "text" : "design",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "paleontology",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/yMtJ1wfw0i",
      "expanded_url" : "http:\/\/www.coroflot.com\/anatotitan\/Cladistic-Heraldry-Dinosauria-Vol-1",
      "display_url" : "coroflot.com\/anatotitan\/Cla\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395342517585330176",
  "text" : "RT @anatotitan: And, if you've never seen it before, my family crests dedicated to #dinosaurs. http:\/\/t.co\/yMtJ1wfw0i #design #paleontology\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dinosaurs",
        "indices" : [ 67, 77 ]
      }, {
        "text" : "design",
        "indices" : [ 102, 109 ]
      }, {
        "text" : "paleontology",
        "indices" : [ 110, 123 ]
      }, {
        "text" : "illustration",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/yMtJ1wfw0i",
        "expanded_url" : "http:\/\/www.coroflot.com\/anatotitan\/Cladistic-Heraldry-Dinosauria-Vol-1",
        "display_url" : "coroflot.com\/anatotitan\/Cla\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395341622465945600",
    "text" : "And, if you've never seen it before, my family crests dedicated to #dinosaurs. http:\/\/t.co\/yMtJ1wfw0i #design #paleontology #illustration",
    "id" : 395341622465945600,
    "created_at" : "2013-10-30 00:09:22 +0000",
    "user" : {
      "name" : "David Orr, but maybe not the one you're expecting",
      "screen_name" : "anatotitan",
      "protected" : false,
      "id_str" : "15776891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/892432266303066112\/T0lcv6Oo_normal.jpg",
      "id" : 15776891,
      "verified" : false
    }
  },
  "id" : 395342517585330176,
  "created_at" : "2013-10-30 00:12:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/VBIE489e6f",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/10\/29\/millennium-falcon-turntable.html",
      "display_url" : "boingboing.net\/2013\/10\/29\/mil\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395324732268359680",
  "text" : "Millennium Falcon\u00A0turntable http:\/\/t.co\/VBIE489e6f",
  "id" : 395324732268359680,
  "created_at" : "2013-10-29 23:02:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395323339767832576",
  "text" : "\u00ABImmer wenn du abgelenkt bist und sagst du w\u00FCrdest arbeiten liest du Masku-Blogs!\u00BB \u2013 \u00ABDas war mein Lawblog im Feedreader. Oh, right\u2026\u00BB",
  "id" : 395323339767832576,
  "created_at" : "2013-10-29 22:56:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/6CLDFTWRmC",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/10\/29\/3d-printed-ukulele.html",
      "display_url" : "boingboing.net\/2013\/10\/29\/3d-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395322578736541696",
  "text" : "Who cares about 3D printed guns? A 3D printed\u00A0ukulele! http:\/\/t.co\/6CLDFTWRmC",
  "id" : 395322578736541696,
  "created_at" : "2013-10-29 22:53:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/XlJ7fubtHt",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1648",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395320617278648320",
  "text" : "Trending http:\/\/t.co\/XlJ7fubtHt",
  "id" : 395320617278648320,
  "created_at" : "2013-10-29 22:45:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 116, 129 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/7Kadwc8e1M",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0078575",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395319524431769601",
  "text" : "Ligation Bias in Illumina NGS DNA Libraries: Implications for Sequencing Ancient Genomes http:\/\/t.co\/7Kadwc8e1M \/cc @PhilippBayer",
  "id" : 395319524431769601,
  "created_at" : "2013-10-29 22:41:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395315959017512960",
  "text" : "Funny: Running MEGA over wine in a VM actually did the trick. Now we can teach sequence editing like it\u2019s 2007 again!",
  "id" : 395315959017512960,
  "created_at" : "2013-10-29 22:27:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "395308966370373632",
  "text" : "installing a ubuntu VM to test whether MEGA5 will work on a linux system with wine\u2026",
  "id" : 395308966370373632,
  "created_at" : "2013-10-29 21:59:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395303689273225216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0092874821, 8.4213653576 ]
  },
  "id_str" : "395304300467220480",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot protip before you start with that: make sure you either have a strong vacuum or are doing it over the trash can right away :)",
  "id" : 395304300467220480,
  "in_reply_to_status_id" : 395303689273225216,
  "created_at" : "2013-10-29 21:41:04 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/vZctfasAJm",
      "expanded_url" : "http:\/\/xkcd.com\/1053\/",
      "display_url" : "xkcd.com\/1053\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1024807897, 8.6510437355 ]
  },
  "id_str" : "395297815498604544",
  "text" : "Let\u2019s break some CD-Rs so you can learn where glitter comes from. http:\/\/t.co\/vZctfasAJm",
  "id" : 395297815498604544,
  "created_at" : "2013-10-29 21:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sascha Lobo",
      "screen_name" : "saschalobo",
      "indices" : [ 24, 35 ],
      "id_str" : "5876652",
      "id" : 5876652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1038767392, 8.6902046176 ]
  },
  "id_str" : "395269651518980096",
  "text" : "\u00ABIch vergesse immer das @saschalobo unser Safeword ist. Und dann schreie ich \u2018Felix von Leitner!\u2019, aber er h\u00F6rt einfach nicht auf.\u00BB",
  "id" : 395269651518980096,
  "created_at" : "2013-10-29 19:23:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1039095657, 8.6901692099 ]
  },
  "id_str" : "395268330904637440",
  "text" : "\u00ABUnsere Safewords von gr\u00FCn nach rot: \u2018Du darfst gern noch tiefer\u2019, \u2018Au\u2019, \u2018Aufh\u00F6ren\u2019.\u00BB",
  "id" : 395268330904637440,
  "created_at" : "2013-10-29 19:18:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0946496641, 8.7521822214 ]
  },
  "id_str" : "395232221474586624",
  "text" : "\u00ABSorry, ich wollte deinen K\u00F6rper nicht mit F\u00FC\u00DFen treten. Nur deine Gef\u00FChle.\u00BB",
  "id" : 395232221474586624,
  "created_at" : "2013-10-29 16:54:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395182737490849792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1056865007, 8.744005096 ]
  },
  "id_str" : "395184790238167040",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab I misread that as \u2018university\u2019 at first. It didn\u2019t change a thing, except that it\u2019s maybe too optimistic.",
  "id" : 395184790238167040,
  "in_reply_to_status_id" : 395182737490849792,
  "created_at" : "2013-10-29 13:46:10 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395152106820096000",
  "geo" : { },
  "id_str" : "395156597833342977",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer in principle yes, but my best guess is that how much of a problem that is heavily depends on how you structure your classes.",
  "id" : 395156597833342977,
  "in_reply_to_status_id" : 395152106820096000,
  "created_at" : "2013-10-29 11:54:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395141677897105408",
  "text" : "2013: People in bioinformatics still use relational databases without understanding primary keys (and get their software published)\u2026",
  "id" : 395141677897105408,
  "created_at" : "2013-10-29 10:54:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/D0pvpMzE1q",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/10\/25\/squirrel-drops-nut-devastated-photo_n_4164135.html?ir=Comedy",
      "display_url" : "huffingtonpost.com\/2013\/10\/25\/squ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395131135832776705",
  "text" : "News at 11: Squirrel Drops Nut, Looks Absolutely Devastated http:\/\/t.co\/D0pvpMzE1q",
  "id" : 395131135832776705,
  "created_at" : "2013-10-29 10:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/HPttTwuqoX",
      "expanded_url" : "http:\/\/www.latimes.com\/business\/la-fi-hiltzik-20131027,0,1228881.column#axzz2j6U08LnA",
      "display_url" : "latimes.com\/business\/la-fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395128710799429632",
  "text" : "Well, that's what you get if funding depends on your claims to cure cancer and the # of Nature publications\u2026 http:\/\/t.co\/HPttTwuqoX",
  "id" : 395128710799429632,
  "created_at" : "2013-10-29 10:03:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/cLnff9lxbN",
      "expanded_url" : "https:\/\/www.mcgill.ca\/newsroom\/node\/19281\/",
      "display_url" : "mcgill.ca\/newsroom\/node\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395123215229415424",
  "text" : "Yay, Phylo has opened up! https:\/\/t.co\/cLnff9lxbN",
  "id" : 395123215229415424,
  "created_at" : "2013-10-29 09:41:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395120878008434688",
  "geo" : { },
  "id_str" : "395121781054255104",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon the only reason to keep this job! And it's just not 'all of our group' because significant parts just arrive after noon!",
  "id" : 395121781054255104,
  "in_reply_to_status_id" : 395120878008434688,
  "created_at" : "2013-10-29 09:35:48 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 120, 129 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/7c56HiCEhj",
      "expanded_url" : "http:\/\/news.sciencemag.org\/brain-behavior\/2013\/10\/statistical-fluke-researchers-observations-tea-party-and-science-spark",
      "display_url" : "news.sciencemag.org\/brain-behavior\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395120951416741888",
  "text" : "Statistical Fluke? Researcher's Observations on Tea Party and Science Spark Political Frenzy http:\/\/t.co\/7c56HiCEhj \/cc @Senficon",
  "id" : 395120951416741888,
  "created_at" : "2013-10-29 09:32:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/IKTN6zvpZB",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/65350563688\/when-someone-asks-me-for-advice-on-a-difficult-protocol",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/653505636\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395119295287406592",
  "text" : "Every time someone asks me about help for installing some weird software http:\/\/t.co\/IKTN6zvpZB",
  "id" : 395119295287406592,
  "created_at" : "2013-10-29 09:25:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723996923, 8.6275065132 ]
  },
  "id_str" : "395117519809548290",
  "text" : "\u00ABWie oft kann versuchen mich einzuloggen bis ich gesperrt werde?\u00BB\u2014\u00AB3x. Dann wird zum besseren Lerneffekt der User mit Homefolder gel\u00F6scht.\u00BB",
  "id" : 395117519809548290,
  "created_at" : "2013-10-29 09:18:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/Pbozz2NUwO",
      "expanded_url" : "http:\/\/www.nature.com\/news\/rodent-immune-to-scorpion-venom-1.14014",
      "display_url" : "nature.com\/news\/rodent-im\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395113458728845312",
  "text" : "Rodent immune to scorpion venom http:\/\/t.co\/Pbozz2NUwO",
  "id" : 395113458728845312,
  "created_at" : "2013-10-29 09:02:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395112085656322048",
  "geo" : { },
  "id_str" : "395112709114458113",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer not sure whetherproblem of stand. tests. In my days there were none but still was rote learning of formulas over understanding",
  "id" : 395112709114458113,
  "in_reply_to_status_id" : 395112085656322048,
  "created_at" : "2013-10-29 08:59:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Yvan Le Bras",
      "screen_name" : "Yvan2935",
      "indices" : [ 14, 23 ],
      "id_str" : "1574674273",
      "id" : 1574674273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395110487798448128",
  "geo" : { },
  "id_str" : "395111218655936512",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Yvan2935 plus there needs to be a plugin, whereas you can just string together unix-tools in virtually any way.",
  "id" : 395111218655936512,
  "in_reply_to_status_id" : 395110487798448128,
  "created_at" : "2013-10-29 08:53:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/6rk5nDxIet",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0077332",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395107144631975936",
  "text" : "Restoration Ecology: Two-Sex Dynamics and Cost Minimization http:\/\/t.co\/6rk5nDxIet",
  "id" : 395107144631975936,
  "created_at" : "2013-10-29 08:37:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/zYYBfJMegf",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/65365348897\/after-spending-8-hours-running-flow",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/653653488\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395104312197521408",
  "text" : "How large parts of our group already look like at noon. http:\/\/t.co\/zYYBfJMegf",
  "id" : 395104312197521408,
  "created_at" : "2013-10-29 08:26:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yvan Le Bras",
      "screen_name" : "Yvan2935",
      "indices" : [ 0, 9 ],
      "id_str" : "1574674273",
      "id" : 1574674273
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395098024344420352",
  "geo" : { },
  "id_str" : "395102043062292480",
  "in_reply_to_user_id" : 1574674273,
  "text" : "@Yvan2935 @PhilippBayer thanks for the pointer. But I'm sceptical that this will happen. large part of scientific anal. in bioinf are 1-offs",
  "id" : 395102043062292480,
  "in_reply_to_status_id" : 395098024344420352,
  "created_at" : "2013-10-29 08:17:22 +0000",
  "in_reply_to_screen_name" : "Yvan2935",
  "in_reply_to_user_id_str" : "1574674273",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yvan Le Bras",
      "screen_name" : "Yvan2935",
      "indices" : [ 0, 9 ],
      "id_str" : "1574674273",
      "id" : 1574674273
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395089290805669888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1119061672, 8.6852936755 ]
  },
  "id_str" : "395089994223992833",
  "in_reply_to_user_id" : 1574674273,
  "text" : "@Yvan2935 @PhilippBayer that\u2019s also part of the course. But manipulate data so it can be imported into tool of your choice can\u2019t be ignored.",
  "id" : 395089994223992833,
  "in_reply_to_status_id" : 395089290805669888,
  "created_at" : "2013-10-29 07:29:29 +0000",
  "in_reply_to_screen_name" : "Yvan2935",
  "in_reply_to_user_id_str" : "1574674273",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "395073335182102528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044795359, 8.3021935355 ]
  },
  "id_str" : "395079986383962112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer from following US blogs and reading the mathematician\u2019s lament this also seems to be a result of rote learning.",
  "id" : 395079986383962112,
  "in_reply_to_status_id" : 395073335182102528,
  "created_at" : "2013-10-29 06:49:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394976669112360961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0040355064, 8.2955163166 ]
  },
  "id_str" : "395079243644010496",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch \u2018lesson 1: here\u2019s how not to delete your sequence data while grepping for fasta-headers\u2019 ;)",
  "id" : 395079243644010496,
  "in_reply_to_status_id" : 394976669112360961,
  "created_at" : "2013-10-29 06:46:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/GfnXIQA8MW",
      "expanded_url" : "http:\/\/www.theatlantic.com\/education\/archive\/2013\/10\/the-myth-of-im-bad-at-math\/280914\/",
      "display_url" : "theatlantic.com\/education\/arch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "395078770782396416",
  "text" : "RT @PhilippBayer: \"The Myth of 'I'm Bad at Math'\" http:\/\/t.co\/GfnXIQA8MW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/GfnXIQA8MW",
        "expanded_url" : "http:\/\/www.theatlantic.com\/education\/archive\/2013\/10\/the-myth-of-im-bad-at-math\/280914\/",
        "display_url" : "theatlantic.com\/education\/arch\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "395073335182102528",
    "text" : "\"The Myth of 'I'm Bad at Math'\" http:\/\/t.co\/GfnXIQA8MW",
    "id" : 395073335182102528,
    "created_at" : "2013-10-29 06:23:17 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 395078770782396416,
  "created_at" : "2013-10-29 06:44:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096906144, 8.2831005314 ]
  },
  "id_str" : "394982958916202496",
  "text" : "\u00ABF\u00FCr meine Bewerbung: Plautze, orangener Anzug, Dreispitz &amp; Nerdbrille.\u00BB\u2014\u00ABMach Glitter an die Brille &amp; dazu einen Gehstock: Notorious BGE!\u00BB",
  "id" : 394982958916202496,
  "created_at" : "2013-10-29 00:24:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394974452863082496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096252031, 8.2829886388 ]
  },
  "id_str" : "394975148040011777",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch I said fun! It\u2019s mean to be a course for biologists with approximately zero prior bash knowledge. ;)",
  "id" : 394975148040011777,
  "in_reply_to_status_id" : 394974452863082496,
  "created_at" : "2013-10-28 23:53:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 107, 120 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "394953512830111744",
  "text" : "Okay, lazyweb: Are there any fun ways out there to teach the trinity of bioinformatics (aka awk,sed,grep)? @PhilippBayer",
  "id" : 394953512830111744,
  "created_at" : "2013-10-28 22:27:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/eh1nXX9qE5",
      "expanded_url" : "http:\/\/i.imgur.com\/7GRDQJr.png",
      "display_url" : "i.imgur.com\/7GRDQJr.png"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00958, 8.283176 ]
  },
  "id_str" : "394952662086868992",
  "text" : "Graphic &amp; Web Designer Halloween http:\/\/t.co\/eh1nXX9qE5",
  "id" : 394952662086868992,
  "created_at" : "2013-10-28 22:23:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394911842159448064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096666525, 8.282992 ]
  },
  "id_str" : "394918081862328320",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot a sure sign that someone\u2122 needs to trim it so I can finally improve my eating. ;)",
  "id" : 394918081862328320,
  "in_reply_to_status_id" : 394911842159448064,
  "created_at" : "2013-10-28 20:06:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir Beef-A-Lot \uD83C\uDDE9\uD83C\uDDEA\uD83D\uDD1C\uD83C\uDDEF\uD83C\uDDF5",
      "screen_name" : "FreXxX",
      "indices" : [ 0, 7 ],
      "id_str" : "22941893",
      "id" : 22941893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394900044559568896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096262409, 8.2829841812 ]
  },
  "id_str" : "394900665669259264",
  "in_reply_to_user_id" : 22941893,
  "text" : "@FreXxX sorry das ich dich vorher nicht gesehen hab. War erst in mein Hirn und dann mein Buch vertieft.",
  "id" : 394900665669259264,
  "in_reply_to_status_id" : 394900044559568896,
  "created_at" : "2013-10-28 18:57:10 +0000",
  "in_reply_to_screen_name" : "FreXxX",
  "in_reply_to_user_id_str" : "22941893",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "indices" : [ 3, 8 ],
      "id_str" : "773450",
      "id" : 773450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oaKlcJhdW2",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1pdnjh\/reddit_what_is_your_primary_addiction\/cd19v0x",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394899843640217600",
  "text" : "RT @klmr: Tempting. This really makes me want to try Adderall. \u201CAdderall was like cheating at life, I miss it a lot\u201D\n\nhttp:\/\/t.co\/oaKlcJhdW2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/oaKlcJhdW2",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1pdnjh\/reddit_what_is_your_primary_addiction\/cd19v0x",
        "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394898591502057472",
    "text" : "Tempting. This really makes me want to try Adderall. \u201CAdderall was like cheating at life, I miss it a lot\u201D\n\nhttp:\/\/t.co\/oaKlcJhdW2",
    "id" : 394898591502057472,
    "created_at" : "2013-10-28 18:48:55 +0000",
    "user" : {
      "name" : "Konrad Rudolph \uD83D\uDC68\u200D\uD83D\uDD2C\uD83D\uDCBB\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "klmr",
      "protected" : false,
      "id_str" : "773450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2617576817\/4n2x4ln6fqopk944375r_normal.jpeg",
      "id" : 773450,
      "verified" : false
    }
  },
  "id" : 394899843640217600,
  "created_at" : "2013-10-28 18:53:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/5BmIACh9HK",
      "expanded_url" : "http:\/\/i.imgur.com\/AhPiE0Y.jpg",
      "display_url" : "i.imgur.com\/AhPiE0Y.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.124414, 8.677638 ]
  },
  "id_str" : "394888865204690944",
  "text" : "I imagine my beard looks just alike on windy days like this.  http:\/\/t.co\/5BmIACh9HK",
  "id" : 394888865204690944,
  "created_at" : "2013-10-28 18:10:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1715626431, 8.6240647978 ]
  },
  "id_str" : "394881391915466752",
  "text" : "\u00ABWenn meine Freundin unterwegs ist wirkt sich das gleich auf meine Produktivit\u00E4t aus.\u00BB \u2014 \u00ABWeil du dich nicht mehr im B\u00FCro verstecken musst?\u00BB",
  "id" : 394881391915466752,
  "created_at" : "2013-10-28 17:40:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 41, 49 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722887378, 8.6276665038 ]
  },
  "id_str" : "394872685840576512",
  "text" : "\u00ABMeine Tweets sind so dreckig das selbst @moeffju sich nur traut sie mit seinem Sexaccount zu faven.\u00BB",
  "id" : 394872685840576512,
  "created_at" : "2013-10-28 17:05:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723021883, 8.6276482864 ]
  },
  "id_str" : "394857979687993344",
  "text" : "\u00ABIch war so sp\u00E4t dran beim Marathon das die Stra\u00DFen schon wieder frei waren. Die Polizisten wollten mich dann nicht auf die Autobahn lassen\u00BB",
  "id" : 394857979687993344,
  "created_at" : "2013-10-28 16:07:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723306943, 8.6276229977 ]
  },
  "id_str" : "394851431079219200",
  "text" : "\u00ABLass uns fl\u00FCchten bevor sie aufstehen. Nimm deine Schuhe in die Hand und renn!\u00BB \u2014 \u00ABHast du an deine Jacke und das Lube gedacht?\u00BB",
  "id" : 394851431079219200,
  "created_at" : "2013-10-28 15:41:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/KjP8rVEjkP",
      "expanded_url" : "http:\/\/instagram.com\/p\/gBCSAUBwjz\/",
      "display_url" : "instagram.com\/p\/gBCSAUBwjz\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "394848987037319168",
  "text" : "Heiter bis wolkig @ Biologicum http:\/\/t.co\/KjP8rVEjkP",
  "id" : 394848987037319168,
  "created_at" : "2013-10-28 15:31:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/T6OdksN1Ap",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=OgLl0_mqLtc",
      "display_url" : "youtube.com\/watch?v=OgLl0_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394845451523874816",
  "text" : "Star Wars Blooper Reel http:\/\/t.co\/T6OdksN1Ap",
  "id" : 394845451523874816,
  "created_at" : "2013-10-28 15:17:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/nesKUMoOJh",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.de\/2013\/10\/when-orgasm-triggers-light-show-first.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+BpsResearchDigest+%28BPS+Research+Digest%29",
      "display_url" : "bps-research-digest.blogspot.de\/2013\/10\/when-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394827476016197632",
  "text" : "\u00ABThe first ever study of synaesthetic sex\u00BB http:\/\/t.co\/nesKUMoOJh",
  "id" : 394827476016197632,
  "created_at" : "2013-10-28 14:06:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 119, 128 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Gtg5NK3mPj",
      "expanded_url" : "http:\/\/www.crackajack.de\/2013\/10\/28\/wifi-router-is-a-planter\/",
      "display_url" : "crackajack.de\/2013\/10\/28\/wif\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394826654922461184",
  "text" : "So oft wie es bei uns aus der Decke in den Router regnet m\u00FCssten wir sie nicht mal giessen! http:\/\/t.co\/Gtg5NK3mPj \/cc @Senficon",
  "id" : 394826654922461184,
  "created_at" : "2013-10-28 14:03:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/nRFmPzHZ4v",
      "expanded_url" : "http:\/\/i.imgur.com\/6G0JhxF.jpg",
      "display_url" : "i.imgur.com\/6G0JhxF.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172322, 8.627633 ]
  },
  "id_str" : "394817450258464768",
  "text" : "\u00ABSomething smells funny in your office\u2026\u00BB http:\/\/t.co\/nRFmPzHZ4v",
  "id" : 394817450258464768,
  "created_at" : "2013-10-28 13:26:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/zBKEa5l1M3",
      "expanded_url" : "https:\/\/www.facebook.com\/ambivalentscience?ref=stream&hc_location=stream",
      "display_url" : "facebook.com\/ambivalentscie\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394803192959344640",
  "text" : "RT @edyong209: \"I Am Fucking Ambivalent About Science\" - a Facebook group https:\/\/t.co\/zBKEa5l1M3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/zBKEa5l1M3",
        "expanded_url" : "https:\/\/www.facebook.com\/ambivalentscience?ref=stream&hc_location=stream",
        "display_url" : "facebook.com\/ambivalentscie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394802761964859393",
    "text" : "\"I Am Fucking Ambivalent About Science\" - a Facebook group https:\/\/t.co\/zBKEa5l1M3",
    "id" : 394802761964859393,
    "created_at" : "2013-10-28 12:28:08 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 394803192959344640,
  "created_at" : "2013-10-28 12:29:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394585409042132992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1064853676, 8.7566399158 ]
  },
  "id_str" : "394587135762006016",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer love the chapter on power. Too many people don\u2019t get that difference. :)",
  "id" : 394587135762006016,
  "in_reply_to_status_id" : 394585409042132992,
  "created_at" : "2013-10-27 22:11:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 3, 13 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/m6VqAeVJSn",
      "expanded_url" : "http:\/\/www.jstor.org\/stable\/info\/10.1086\/673296",
      "display_url" : "jstor.org\/stable\/info\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394584935937638400",
  "text" : "RT @razibkhan: Heritability of Life Span Is Largely Sex Limited in Drosophila. http:\/\/t.co\/m6VqAeVJSn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/m6VqAeVJSn",
        "expanded_url" : "http:\/\/www.jstor.org\/stable\/info\/10.1086\/673296",
        "display_url" : "jstor.org\/stable\/info\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394584433769992192",
    "text" : "Heritability of Life Span Is Largely Sex Limited in Drosophila. http:\/\/t.co\/m6VqAeVJSn",
    "id" : 394584433769992192,
    "created_at" : "2013-10-27 22:00:34 +0000",
    "user" : {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "protected" : false,
      "id_str" : "35304791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890083843385958400\/YKPy0Uup_normal.jpg",
      "id" : 35304791,
      "verified" : true
    }
  },
  "id" : 394584935937638400,
  "created_at" : "2013-10-27 22:02:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394584051798929410",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1071560038, 8.7575088704 ]
  },
  "id_str" : "394584163078402048",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I didn\u2019t think so. But that will be handy one day! ;)",
  "id" : 394584163078402048,
  "in_reply_to_status_id" : 394584051798929410,
  "created_at" : "2013-10-27 21:59:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/dulxmEINWL",
      "expanded_url" : "http:\/\/www.refsmmat.com\/statistics\/",
      "display_url" : "refsmmat.com\/statistics\/"
    } ]
  },
  "geo" : { },
  "id_str" : "394583964633280512",
  "text" : "RT @PhilippBayer: \"Statistics Done Wrong - The woefully complete guide\" A guide to the most popular stats-errors http:\/\/t.co\/dulxmEINWL cc \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 121, 137 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/dulxmEINWL",
        "expanded_url" : "http:\/\/www.refsmmat.com\/statistics\/",
        "display_url" : "refsmmat.com\/statistics\/"
      } ]
    },
    "geo" : { },
    "id_str" : "394583664022925312",
    "text" : "\"Statistics Done Wrong - The woefully complete guide\" A guide to the most popular stats-errors http:\/\/t.co\/dulxmEINWL cc @gedankenstuecke",
    "id" : 394583664022925312,
    "created_at" : "2013-10-27 21:57:31 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 394583964633280512,
  "created_at" : "2013-10-27 21:58:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394583664022925312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.106518768, 8.7567918207 ]
  },
  "id_str" : "394583821703598081",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer wow, Thanks! :)",
  "id" : 394583821703598081,
  "in_reply_to_status_id" : 394583664022925312,
  "created_at" : "2013-10-27 21:58:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rolling Stone",
      "screen_name" : "RollingStone",
      "indices" : [ 3, 16 ],
      "id_str" : "14780915",
      "id" : 14780915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/LDr2rv3X0s",
      "expanded_url" : "http:\/\/rol.st\/17S0pWI",
      "display_url" : "rol.st\/17S0pWI"
    } ]
  },
  "geo" : { },
  "id_str" : "394519550437625856",
  "text" : "RT @RollingStone: Lou Reed has died at age 71: http:\/\/t.co\/LDr2rv3X0s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/LDr2rv3X0s",
        "expanded_url" : "http:\/\/rol.st\/17S0pWI",
        "display_url" : "rol.st\/17S0pWI"
      } ]
    },
    "geo" : { },
    "id_str" : "394513570840731648",
    "text" : "Lou Reed has died at age 71: http:\/\/t.co\/LDr2rv3X0s",
    "id" : 394513570840731648,
    "created_at" : "2013-10-27 17:18:59 +0000",
    "user" : {
      "name" : "Rolling Stone",
      "screen_name" : "RollingStone",
      "protected" : false,
      "id_str" : "14780915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875453682170576896\/KDcOPtgI_normal.jpg",
      "id" : 14780915,
      "verified" : true
    }
  },
  "id" : 394519550437625856,
  "created_at" : "2013-10-27 17:42:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/52Q2QgWfnY",
      "expanded_url" : "http:\/\/instagram.com\/p\/f-sXSQBwgb\/",
      "display_url" : "instagram.com\/p\/f-sXSQBwgb\/"
    } ]
  },
  "geo" : { },
  "id_str" : "394519166327468032",
  "text" : "Eine Tagesordnung die man falsch verstehen k\u00F6nnte. http:\/\/t.co\/52Q2QgWfnY",
  "id" : 394519166327468032,
  "created_at" : "2013-10-27 17:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heiko S.",
      "screen_name" : "hkos",
      "indices" : [ 0, 5 ],
      "id_str" : "27012673",
      "id" : 27012673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394514479486349312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.103995234, 8.6899528497 ]
  },
  "id_str" : "394518436220784640",
  "in_reply_to_user_id" : 27012673,
  "text" : "@hkos viel Spass beim essen :)",
  "id" : 394518436220784640,
  "in_reply_to_status_id" : 394514479486349312,
  "created_at" : "2013-10-27 17:38:19 +0000",
  "in_reply_to_screen_name" : "hkos",
  "in_reply_to_user_id_str" : "27012673",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1040855181, 8.6901104988 ]
  },
  "id_str" : "394518118548389888",
  "text" : "\u00ABUserbewertungen beim Online-Dating: Hab ihn getroffen. Er war ein Hund. Gerne wieder.\u00BB",
  "id" : 394518118548389888,
  "created_at" : "2013-10-27 17:37:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1182169257, 8.6860891359 ]
  },
  "id_str" : "394484670194548736",
  "text" : "Unter dem\nTisch twittern und faven. Zettelchen im Unterricht schreiben 2.0",
  "id" : 394484670194548736,
  "created_at" : "2013-10-27 15:24:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1182149582, 8.6861905822 ]
  },
  "id_str" : "394480078354399232",
  "text" : "\u00ABWas hast du mit dem Kuchen gemacht?! Du hast ihn zerst\u00F6rt!\u00BB \u2014 \u00ABIch habe die Banane f\u00FCr dich freigelegt!\u00BB",
  "id" : 394480078354399232,
  "created_at" : "2013-10-27 15:05:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1182139083, 8.6861059259 ]
  },
  "id_str" : "394470879348162560",
  "text" : "\u00ABHei\u00DFt eine von den Poly-Parties zu Silvester jetzt Polyester?\u00BB \u2014 \u00ABDa stehen einem ja die Haare zu Berge!\u00BB",
  "id" : 394470879348162560,
  "created_at" : "2013-10-27 14:29:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0762517192, 8.6621546187 ]
  },
  "id_str" : "394444143164157952",
  "text" : "\u00ABIch bin noch unschl\u00FCssig ob ich Bochum-Blitzkrieg oder Bochum-Blutschande in der Stadtteilnamenreihe vom Klang her besser f\u00E4nde.\u00BB",
  "id" : 394444143164157952,
  "created_at" : "2013-10-27 12:43:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zamm",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9481655341, 6.995218629 ]
  },
  "id_str" : "394420695721340928",
  "text" : "\u00ABMental reflection is so much more interesting than TV it\u2019s a shame more people don\u2019t switch over to it.\u00BB #zamm",
  "id" : 394420695721340928,
  "created_at" : "2013-10-27 11:09:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/elamJZOr0d",
      "expanded_url" : "http:\/\/i.imgur.com\/wJ7F2br.jpg",
      "display_url" : "i.imgur.com\/wJ7F2br.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "394406675568136192",
  "text" : "Even though I have no idea what I'm doing!  http:\/\/t.co\/elamJZOr0d",
  "id" : 394406675568136192,
  "created_at" : "2013-10-27 10:14:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/tUSdej12W2",
      "expanded_url" : "http:\/\/www.imgur.com\/mx5g3eD.jpeg",
      "display_url" : "imgur.com\/mx5g3eD.jpeg"
    } ]
  },
  "geo" : { },
  "id_str" : "394404226178514944",
  "text" : "Halloween bumblebeard http:\/\/t.co\/tUSdej12W2",
  "id" : 394404226178514944,
  "created_at" : "2013-10-27 10:04:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/4LM2wEGw6i",
      "expanded_url" : "http:\/\/instagram.com\/p\/f92ha6hwuq\/",
      "display_url" : "instagram.com\/p\/f92ha6hwuq\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5175827119, 7.4589443207 ]
  },
  "id_str" : "394400813734703104",
  "text" : "Repetition @ Dortmund Hauptbahnhof http:\/\/t.co\/4LM2wEGw6i",
  "id" : 394400813734703104,
  "created_at" : "2013-10-27 09:50:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/rhuR4l22Oj",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/mikegiglio\/william-suess-thought-he-was-an-american-until-the-day-he-wa",
      "display_url" : "buzzfeed.com\/mikegiglio\/wil\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.499754, 7.48869 ]
  },
  "id_str" : "394389115862409216",
  "text" : "William Suess Thought He Was An American Until The Day He Was Deported http:\/\/t.co\/rhuR4l22Oj",
  "id" : 394389115862409216,
  "created_at" : "2013-10-27 09:04:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/Aqlxu9Al62",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/65182064484",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/651820644\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.499308, 7.486989 ]
  },
  "id_str" : "394383637283872768",
  "text" : "Reflecting http:\/\/t.co\/Aqlxu9Al62",
  "id" : 394383637283872768,
  "created_at" : "2013-10-27 08:42:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/MSiFfwATnw",
      "expanded_url" : "http:\/\/extrafabulouscomics.com\/comic\/126\/",
      "display_url" : "extrafabulouscomics.com\/comic\/126\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4996171891, 7.4883673007 ]
  },
  "id_str" : "394243693689192448",
  "text" : "Obi-Wang http:\/\/t.co\/MSiFfwATnw",
  "id" : 394243693689192448,
  "created_at" : "2013-10-26 23:26:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 3, 18 ],
      "id_str" : "76013938",
      "id" : 76013938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/CQyzqBwTK3",
      "expanded_url" : "http:\/\/wp.me\/p1rYgm-1On",
      "display_url" : "wp.me\/p1rYgm-1On"
    } ]
  },
  "geo" : { },
  "id_str" : "394237581636141056",
  "text" : "RT @john_s_wilkins: Are species theoretical objects? http:\/\/t.co\/CQyzqBwTK3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/CQyzqBwTK3",
        "expanded_url" : "http:\/\/wp.me\/p1rYgm-1On",
        "display_url" : "wp.me\/p1rYgm-1On"
      } ]
    },
    "geo" : { },
    "id_str" : "394234617298837504",
    "text" : "Are species theoretical objects? http:\/\/t.co\/CQyzqBwTK3",
    "id" : 394234617298837504,
    "created_at" : "2013-10-26 22:50:31 +0000",
    "user" : {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "protected" : false,
      "id_str" : "76013938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852294288838807552\/FZpeLbxA_normal.jpg",
      "id" : 76013938,
      "verified" : false
    }
  },
  "id" : 394237581636141056,
  "created_at" : "2013-10-26 23:02:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4996230304, 7.4880730996 ]
  },
  "id_str" : "394232827967184896",
  "text" : "Given that my BEE calculates at around 1.1 kcal\/min and even fast walking doesn\u2019t score much &gt; than 8 kcal\/min that doesn\u2019t seem to bad.",
  "id" : 394232827967184896,
  "created_at" : "2013-10-26 22:43:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/olJBvz0N4G",
      "expanded_url" : "http:\/\/theadamglass.tumblr.com\/tagged\/back-to-the-future",
      "display_url" : "theadamglass.tumblr.com\/tagged\/back-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394229605290504192",
  "text" : "RT @edyong209: This is some truly dedicated trolling. http:\/\/t.co\/olJBvz0N4G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/olJBvz0N4G",
        "expanded_url" : "http:\/\/theadamglass.tumblr.com\/tagged\/back-to-the-future",
        "display_url" : "theadamglass.tumblr.com\/tagged\/back-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "394229393909768192",
    "text" : "This is some truly dedicated trolling. http:\/\/t.co\/olJBvz0N4G",
    "id" : 394229393909768192,
    "created_at" : "2013-10-26 22:29:46 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 394229605290504192,
  "created_at" : "2013-10-26 22:30:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 84, 91 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/BjqN3krBNw",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/6bFLyBCkRT4\/info%3Adoi%2F10.1371%2Fjournal.pone.0079342",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.499623, 7.488073 ]
  },
  "id_str" : "394228547243765760",
  "text" : "\u00ABResults suggest that sexual activity may be a significant exercise.\u00BB time 2 update @fitbit activity DB? http:\/\/t.co\/BjqN3krBNw",
  "id" : 394228547243765760,
  "created_at" : "2013-10-26 22:26:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/tbcVmoP3zR",
      "expanded_url" : "http:\/\/www.united-academics.org\/magazine\/sex-society\/good-news-dating-success-for-the-underdog\/",
      "display_url" : "united-academics.org\/magazine\/sex-s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.499002, 7.485627 ]
  },
  "id_str" : "394224279925325824",
  "text" : "Science: \u00ABAs an unfairly disadvantaged person you are still attractive and easy to love\u00BB http:\/\/t.co\/tbcVmoP3zR",
  "id" : 394224279925325824,
  "created_at" : "2013-10-26 22:09:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/P0ttWVRW6M",
      "expanded_url" : "http:\/\/youtu.be\/sw3wmKum844",
      "display_url" : "youtu.be\/sw3wmKum844"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4996953939, 7.4883176106 ]
  },
  "id_str" : "394204610703142912",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon das Cover wird dir gefallen! ;) http:\/\/t.co\/P0ttWVRW6M",
  "id" : 394204610703142912,
  "created_at" : "2013-10-26 20:51:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/fukeLc9x5U",
      "expanded_url" : "http:\/\/i.imgur.com\/m2FnPRp.jpg",
      "display_url" : "i.imgur.com\/m2FnPRp.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4997315342, 7.4886193099 ]
  },
  "id_str" : "394199251380887552",
  "text" : "He looks like he\u2019d prefer to be (un)dead as well. http:\/\/t.co\/fukeLc9x5U",
  "id" : 394199251380887552,
  "created_at" : "2013-10-26 20:30:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4996829635, 7.4887018245 ]
  },
  "id_str" : "394175823852634112",
  "text" : "\u00ABUnd dann von Stahlhausen nach Heimaterde.\u00BB \u2014 \u00ABDie 30er haben angerufen. Sie wollen ihre Stadtteilnamen zur\u00FCck.\u00BB",
  "id" : 394175823852634112,
  "created_at" : "2013-10-26 18:56:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 10, 17 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "394084522389536768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.2263027338, 6.775166321 ]
  },
  "id_str" : "394085101174546432",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @TnaKng aber du bist doch ein Brand-Fan. Deshalb dachte ich, nicht wegen der Revolution. ;)",
  "id" : 394085101174546432,
  "in_reply_to_status_id" : 394084522389536768,
  "created_at" : "2013-10-26 12:56:24 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4995211317, 7.4717105459 ]
  },
  "id_str" : "394055187692015616",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay ETA noch 1400 ;)",
  "id" : 394055187692015616,
  "created_at" : "2013-10-26 10:57:32 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Y6L8B6UhTU",
      "expanded_url" : "http:\/\/www.amazon.com\/review\/R2VDKZ4X1F992Q\/ref=cm_cr_rdp_perm",
      "display_url" : "amazon.com\/review\/R2VDKZ4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "394039285336506369",
  "text" : "RT @PhilippBayer: This must be the best review for \"A story about Ping\": http:\/\/t.co\/Y6L8B6UhTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/Y6L8B6UhTU",
        "expanded_url" : "http:\/\/www.amazon.com\/review\/R2VDKZ4X1F992Q\/ref=cm_cr_rdp_perm",
        "display_url" : "amazon.com\/review\/R2VDKZ4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393984204939096064",
    "text" : "This must be the best review for \"A story about Ping\": http:\/\/t.co\/Y6L8B6UhTU",
    "id" : 393984204939096064,
    "created_at" : "2013-10-26 06:15:28 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 394039285336506369,
  "created_at" : "2013-10-26 09:54:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393923982564409344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5000747141, 7.4891110975 ]
  },
  "id_str" : "394038724734222336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and I should have stayed in bed as well, because I failed that exam ;)",
  "id" : 394038724734222336,
  "in_reply_to_status_id" : 393923982564409344,
  "created_at" : "2013-10-26 09:52:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/QOK7EhoIws",
      "expanded_url" : "http:\/\/i.imgur.com\/0rvW5uK.jpg",
      "display_url" : "i.imgur.com\/0rvW5uK.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4998361466, 7.4886845748 ]
  },
  "id_str" : "393863777898487808",
  "text" : "Basically how @PhilippBayer and I spent our undergrad time. Though only one of us ever slept through an exam! http:\/\/t.co\/QOK7EhoIws",
  "id" : 393863777898487808,
  "created_at" : "2013-10-25 22:16:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/QvqaRs7qWA",
      "expanded_url" : "http:\/\/i.imgur.com\/higyIb3.jpg",
      "display_url" : "i.imgur.com\/higyIb3.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4998058437, 7.4888225798 ]
  },
  "id_str" : "393861648228036608",
  "text" : "So the street artists already joined in for Brand\u2019s revolution? http:\/\/t.co\/QvqaRs7qWA",
  "id" : 393861648228036608,
  "created_at" : "2013-10-25 22:08:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/1dtsA7fGbd",
      "expanded_url" : "http:\/\/i.imgur.com\/taBFrQt.jpg",
      "display_url" : "i.imgur.com\/taBFrQt.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4997103788, 7.4887306783 ]
  },
  "id_str" : "393858783321284608",
  "text" : "Nice Try! http:\/\/t.co\/1dtsA7fGbd",
  "id" : 393858783321284608,
  "created_at" : "2013-10-25 21:57:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/kJr5GZ9oeg",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=Gaid72fqzNE",
      "display_url" : "youtube.com\/watch?v=Gaid72\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.499756844, 7.4886775221 ]
  },
  "id_str" : "393850928224546816",
  "text" : "\u00ABI think your special but you fall within a bell curve\u00BB Great that Tim Minchin\u2019s \u2018If I didn\u2019t have you\u2019 is listed. http:\/\/t.co\/kJr5GZ9oeg",
  "id" : 393850928224546816,
  "created_at" : "2013-10-25 21:25:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/0fNymm7PNe",
      "expanded_url" : "http:\/\/akateinflight.blogspot.de\/2013\/10\/reclaiming-mix-tape.html",
      "display_url" : "akateinflight.blogspot.de\/2013\/10\/reclai\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.500065, 7.488855 ]
  },
  "id_str" : "393848065221992448",
  "text" : "Reclaiming the Mix Tape http:\/\/t.co\/0fNymm7PNe",
  "id" : 393848065221992448,
  "created_at" : "2013-10-25 21:14:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.499746102, 7.4886974786 ]
  },
  "id_str" : "393840595716042752",
  "text" : "\u00ABBei n\u00E4herer Betrachtung h\u00E4tte ich vielleicht fragen sollen bevor ich alle Brownies esse, aber: Welche Drogen sind da eigentlich drin?\u00BB",
  "id" : 393840595716042752,
  "created_at" : "2013-10-25 20:44:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.1632854976, 7.6393981401 ]
  },
  "id_str" : "393836836331991040",
  "text" : "\u00ABF\u00FCr eine Handvoll. Doller!\u00BB \u2014 \u00ABMehr!\u00BB",
  "id" : 393836836331991040,
  "created_at" : "2013-10-25 20:29:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/fh8pMJsxwr",
      "expanded_url" : "http:\/\/i.imgur.com\/RaB62I1.jpg",
      "display_url" : "i.imgur.com\/RaB62I1.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4997065125, 7.4886077957 ]
  },
  "id_str" : "393801242369339392",
  "text" : "Are we the baddies? http:\/\/t.co\/fh8pMJsxwr",
  "id" : 393801242369339392,
  "created_at" : "2013-10-25 18:08:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393795526015340544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5001526575, 7.4835424568 ]
  },
  "id_str" : "393796299184951296",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ du meinst aber nicht mich, oder? ;)",
  "id" : 393796299184951296,
  "in_reply_to_status_id" : 393795526015340544,
  "created_at" : "2013-10-25 17:48:48 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.6926919333, 7.1403549804 ]
  },
  "id_str" : "393764766344577024",
  "text" : "Kapitalitmus test",
  "id" : 393764766344577024,
  "created_at" : "2013-10-25 15:43:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/1U3Cwd8rnY",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=tFCbacVw94Q",
      "display_url" : "youtube.com\/watch?v=tFCbac\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.426251022, 7.4485716621 ]
  },
  "id_str" : "393764078155759616",
  "text" : "\u00ABIf you\u2019re born with a love for the wrote and the writ\u2026\u00BB I\u2019m such a sucker for the typical Dobro sound http:\/\/t.co\/1U3Cwd8rnY",
  "id" : 393764078155759616,
  "created_at" : "2013-10-25 15:40:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zamm",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.088797307, 7.7330682467 ]
  },
  "id_str" : "393752872657367040",
  "text" : "\u00ABYou are never dedicated to something you have complete confidence in.\u00BB #zamm",
  "id" : 393752872657367040,
  "created_at" : "2013-10-25 14:56:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 59, 68 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Ib424NDNVe",
      "expanded_url" : "http:\/\/gawker.com\/russell-brand-may-have-started-a-revolution-last-night-1451318185",
      "display_url" : "gawker.com\/russell-brand-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393748781730365440",
  "text" : "Russell Brand May Have Started a Revolution Last Night \/cc @senficon  http:\/\/t.co\/Ib424NDNVe",
  "id" : 393748781730365440,
  "created_at" : "2013-10-25 14:39:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Kml2ShPAnD",
      "expanded_url" : "http:\/\/instagram.com\/p\/f5KS5QBwnt\/",
      "display_url" : "instagram.com\/p\/f5KS5QBwnt\/"
    } ]
  },
  "geo" : { },
  "id_str" : "393740525217792000",
  "text" : "On the Intersection of Public Art and Consumption http:\/\/t.co\/Kml2ShPAnD",
  "id" : 393740525217792000,
  "created_at" : "2013-10-25 14:07:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0846873426, 8.6345699179 ]
  },
  "id_str" : "393739527896178689",
  "text" : "\u00ABZu deiner Disputation werde ich bekleidet kommen und mich erst ausziehen &amp; tanzen wenn du ein Ablenkungsman\u00F6ver brauchst.\u00BB",
  "id" : 393739527896178689,
  "created_at" : "2013-10-25 14:03:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0993826457, 8.5243854926 ]
  },
  "id_str" : "393680447836020736",
  "text" : "Zen and the Art of Repeating Yourself: An Inquiry Into Boredom",
  "id" : 393680447836020736,
  "created_at" : "2013-10-25 10:08:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393673721724284928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.007303909, 8.2829948458 ]
  },
  "id_str" : "393673835285057536",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 du mir auch, nenn es Karma. :)",
  "id" : 393673835285057536,
  "in_reply_to_status_id" : 393673721724284928,
  "created_at" : "2013-10-25 09:42:11 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393666417507454976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096471732, 8.282999268 ]
  },
  "id_str" : "393667816223956992",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 ja, unter dem Punkt \u2018Larger Type\u2019 kann man es kleiner machen ;)",
  "id" : 393667816223956992,
  "in_reply_to_status_id" : 393666417507454976,
  "created_at" : "2013-10-25 09:18:16 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393666373853151232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096471732, 8.282999268 ]
  },
  "id_str" : "393667550862921728",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 danke! Das hilft schon mal. Aber eigentlich w\u00FCrde ich gerne nur einige Apps anpassen, das geht aber wohl nicht :)",
  "id" : 393667550862921728,
  "in_reply_to_status_id" : 393666373853151232,
  "created_at" : "2013-10-25 09:17:12 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095936735, 8.2829513155 ]
  },
  "id_str" : "393666159092187136",
  "text" : "Is there no option to decrease font size in Tweetbot 3?",
  "id" : 393666159092187136,
  "created_at" : "2013-10-25 09:11:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096165529, 8.2829369512 ]
  },
  "id_str" : "393654169384796160",
  "text" : "\u00ABSelbst wenn ich jetzt losrenne bin ich zu sp\u00E4t!\u00BB \u2014 \u00ABNackt, 20 Minuten zu sp\u00E4t, in die Disputation zu rennen ist vielleicht nicht so ideal\u2026\u00BB",
  "id" : 393654169384796160,
  "created_at" : "2013-10-25 08:24:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096999528, 8.2829254679 ]
  },
  "id_str" : "393505459241766912",
  "text" : "\u00AB\u2018Manchmal denke ich das eine andere Beziehung mein Leben interessanter machen w\u00FCrde\u2019. Muss ich die bestehenden daf\u00FCr aufl\u00F6sen?\u00BB",
  "id" : 393505459241766912,
  "created_at" : "2013-10-24 22:33:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096658067, 8.2831536159 ]
  },
  "id_str" : "393503895303258112",
  "text" : "\u00AB\u2018In Wiesbaden zu Leben gibt mir Selbstvertrauen\u2019? Welche armen W\u00FCrstchen stimmen denn da zu?!\u00BB",
  "id" : 393503895303258112,
  "created_at" : "2013-10-24 22:26:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/hsOEao9ooZ",
      "expanded_url" : "http:\/\/i.imgur.com\/RZXuvES.jpg",
      "display_url" : "i.imgur.com\/RZXuvES.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00971143, 8.28303171 ]
  },
  "id_str" : "393497359243825152",
  "text" : "ALL the coffee! http:\/\/t.co\/hsOEao9ooZ",
  "id" : 393497359243825152,
  "created_at" : "2013-10-24 22:00:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/RVvs0dsTwk",
      "expanded_url" : "http:\/\/www.pidjin.net\/2013\/10\/24\/future-me\/",
      "display_url" : "pidjin.net\/2013\/10\/24\/fut\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096492365, 8.2832094951 ]
  },
  "id_str" : "393490425388236800",
  "text" : "I can\u2019t wait to meet future me! http:\/\/t.co\/RVvs0dsTwk",
  "id" : 393490425388236800,
  "created_at" : "2013-10-24 21:33:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393462661884559360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0118244712, 8.2785175648 ]
  },
  "id_str" : "393463732070002688",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Gl\u00FCckwunsch\u2026",
  "id" : 393463732070002688,
  "in_reply_to_status_id" : 393462661884559360,
  "created_at" : "2013-10-24 19:47:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096423608, 8.2830883807 ]
  },
  "id_str" : "393461135082807297",
  "text" : "\u00ABIch habe das Lock vom Briefkasten gepickt. Und damit meine ich: Den Briefkasten aus der Wand gerissen.\u00BB",
  "id" : 393461135082807297,
  "created_at" : "2013-10-24 19:36:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucie \uD83C\uDF42",
      "screen_name" : "Autofocus",
      "indices" : [ 0, 10 ],
      "id_str" : "18939309",
      "id" : 18939309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393437398786641920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009595081, 8.2829437207 ]
  },
  "id_str" : "393439401998819329",
  "in_reply_to_user_id" : 18939309,
  "text" : "@Autofocus Sword, Juno, Gold, Omaha, Utah (unsortiert)",
  "id" : 393439401998819329,
  "in_reply_to_status_id" : 393437398786641920,
  "created_at" : "2013-10-24 18:10:37 +0000",
  "in_reply_to_screen_name" : "Autofocus",
  "in_reply_to_user_id_str" : "18939309",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 11, 19 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1052829725, 8.6504606649 ]
  },
  "id_str" : "393424978496212992",
  "text" : "Still wish @spotify would add support for Boolean Operators to their playlist filters.",
  "id" : 393424978496212992,
  "created_at" : "2013-10-24 17:13:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Auntie Silke",
      "screen_name" : "TanteSilke",
      "indices" : [ 0, 11 ],
      "id_str" : "56062177",
      "id" : 56062177
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393410601432936448",
  "geo" : { },
  "id_str" : "393411574011928576",
  "in_reply_to_user_id" : 56062177,
  "text" : "@TanteSilke aus dem Kontext war \"zwischen zweien hindurchfahren\" gemeint.",
  "id" : 393411574011928576,
  "in_reply_to_status_id" : 393410601432936448,
  "created_at" : "2013-10-24 16:20:03 +0000",
  "in_reply_to_screen_name" : "TanteSilke",
  "in_reply_to_user_id_str" : "56062177",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722740365, 8.6276652114 ]
  },
  "id_str" : "393409029089017856",
  "text" : "\u00ABDas Umfahren der Verkehrspoller als Auflehnung gegen die phallokratische Gesellschaft!\u00BB",
  "id" : 393409029089017856,
  "created_at" : "2013-10-24 16:09:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "indices" : [ 3, 15 ],
      "id_str" : "15859033",
      "id" : 15859033
    }, {
      "name" : "Deborah Blum",
      "screen_name" : "deborahblum",
      "indices" : [ 122, 134 ],
      "id_str" : "72842277",
      "id" : 72842277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393403100331274241",
  "text" : "RT @ivanoransky: \"Inorganic chemistry: The syphoning off of grant money for research that will never be useful. Ever.\" cc @deborahblum http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deborah Blum",
        "screen_name" : "deborahblum",
        "indices" : [ 105, 117 ],
        "id_str" : "72842277",
        "id" : 72842277
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ivanoransky\/status\/393383838849581056\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/617YF0fsHG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXWUhGdCQAA7sA8.jpg",
        "id_str" : "393383838853775360",
        "id" : 393383838853775360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXWUhGdCQAA7sA8.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1154
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1154
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 676
        } ],
        "display_url" : "pic.twitter.com\/617YF0fsHG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393383838849581056",
    "text" : "\"Inorganic chemistry: The syphoning off of grant money for research that will never be useful. Ever.\" cc @deborahblum http:\/\/t.co\/617YF0fsHG",
    "id" : 393383838849581056,
    "created_at" : "2013-10-24 14:29:51 +0000",
    "user" : {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "protected" : false,
      "id_str" : "15859033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1485171512\/bearcubtwitter_normal.jpg",
      "id" : 15859033,
      "verified" : false
    }
  },
  "id" : 393403100331274241,
  "created_at" : "2013-10-24 15:46:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723426277, 8.6276196801 ]
  },
  "id_str" : "393386842638131202",
  "text" : "\u00ABOrrr, klapp doch mal deine Ohren wieder um\u2026 \u2026\u00E4h, ich meinte eigentlich den Hund und nicht dich!\u00BB",
  "id" : 393386842638131202,
  "created_at" : "2013-10-24 14:41:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "indices" : [ 3, 8 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393386090213953536",
  "text" : "RT @mims: \"It's like AirBnB for your womb\" --some pitch deck somewhere",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393385578370433024",
    "text" : "\"It's like AirBnB for your womb\" --some pitch deck somewhere",
    "id" : 393385578370433024,
    "created_at" : "2013-10-24 14:36:45 +0000",
    "user" : {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "protected" : false,
      "id_str" : "1769191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805781204381351936\/_P3k7Gmn_normal.jpg",
      "id" : 1769191,
      "verified" : true
    }
  },
  "id" : 393386090213953536,
  "created_at" : "2013-10-24 14:38:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/UiFov0MV2s",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3154",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393377923073208321",
  "text" : "Being a good parent is about\u2026 http:\/\/t.co\/UiFov0MV2s",
  "id" : 393377923073208321,
  "created_at" : "2013-10-24 14:06:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/3ryZQLR1wH",
      "expanded_url" : "http:\/\/biomickwatson.wordpress.com\/2013\/10\/21\/how-many-hours-have-been-wasted-parsing-unstructured-text-in-biological-databases\/",
      "display_url" : "biomickwatson.wordpress.com\/2013\/10\/21\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393363015187169280",
  "text" : "Biolog. DBs &amp; unstructured text: \u00ABended in a nightmare of regex in some desperate attempt to create something useful\u00BB http:\/\/t.co\/3ryZQLR1wH",
  "id" : 393363015187169280,
  "created_at" : "2013-10-24 13:07:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Coyne",
      "screen_name" : "Evolutionistrue",
      "indices" : [ 3, 19 ],
      "id_str" : "127305588",
      "id" : 127305588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/vMvf1H34dw",
      "expanded_url" : "http:\/\/wp.me\/ppUXF-pzl",
      "display_url" : "wp.me\/ppUXF-pzl"
    } ]
  },
  "geo" : { },
  "id_str" : "393358892937539584",
  "text" : "RT @Evolutionistrue: The first venomous crustacean is found http:\/\/t.co\/vMvf1H34dw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/vMvf1H34dw",
        "expanded_url" : "http:\/\/wp.me\/ppUXF-pzl",
        "display_url" : "wp.me\/ppUXF-pzl"
      } ]
    },
    "geo" : { },
    "id_str" : "393355647557062656",
    "text" : "The first venomous crustacean is found http:\/\/t.co\/vMvf1H34dw",
    "id" : 393355647557062656,
    "created_at" : "2013-10-24 12:37:49 +0000",
    "user" : {
      "name" : "Jerry Coyne",
      "screen_name" : "Evolutionistrue",
      "protected" : false,
      "id_str" : "127305588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768814617837596673\/BIuC-_yL_normal.jpg",
      "id" : 127305588,
      "verified" : false
    }
  },
  "id" : 393358892937539584,
  "created_at" : "2013-10-24 12:50:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 130, 139 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/dGwtB5QUDY",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/books\/2013\/10\/the-writer-as-meme-machine-how-has-the-internet-altered-poetry.html",
      "display_url" : "newyorker.com\/online\/blogs\/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393356215679336448",
  "text" : "\u00ABthe writer as a meme machine, writing with the intention for works to ripple rapidly across networks\u00BB http:\/\/t.co\/dGwtB5QUDY \/HT @wilbanks",
  "id" : 393356215679336448,
  "created_at" : "2013-10-24 12:40:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723239611, 8.6276177168 ]
  },
  "id_str" : "393352371600125952",
  "text" : "\u00ABEs ist erst Donnerstag. Du hast morgen noch Bootycamp, \u00E4h, Bootcamp f\u00FCr den Marathon!\u00BB \u2014 \u00ABIch lauf nicht mit, passt also schon.\u00BB",
  "id" : 393352371600125952,
  "created_at" : "2013-10-24 12:24:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/rjUbbnd8St",
      "expanded_url" : "http:\/\/evolvingthoughts.net\/2013\/10\/the-theological-and-philosophical-origins-of-the-concept-of-species\/",
      "display_url" : "evolvingthoughts.net\/2013\/10\/the-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393334345584218112",
  "text" : "Articles of faith: The theological and philosophical origins of the concept of species http:\/\/t.co\/rjUbbnd8St",
  "id" : 393334345584218112,
  "created_at" : "2013-10-24 11:13:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393324939102539776",
  "geo" : { },
  "id_str" : "393328826559655936",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Not that extreme, but along the lines of hunter-gatherer societies etc.",
  "id" : 393328826559655936,
  "in_reply_to_status_id" : 393324939102539776,
  "created_at" : "2013-10-24 10:51:14 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393311139951812608",
  "geo" : { },
  "id_str" : "393315415029346304",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon in that case both tests are either sig or non-sig depend. on diff x\u0304(f) and x\u0304(m) (at least if we expect comparable SDs).",
  "id" : 393315415029346304,
  "in_reply_to_status_id" : 393311139951812608,
  "created_at" : "2013-10-24 09:57:57 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393311139951812608",
  "geo" : { },
  "id_str" : "393314760168452096",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon picture 3 shifted norm. dist. for (pref. m), (pref. f.) and (walking together). For compromise x\u0304(wt) should be ~ x\u0304(diff), right?",
  "id" : 393314760168452096,
  "in_reply_to_status_id" : 393311139951812608,
  "created_at" : "2013-10-24 09:55:20 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393311139951812608",
  "geo" : { },
  "id_str" : "393313196649373696",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon which basically shd be given when test results for male &amp; female are the same I'd argue.",
  "id" : 393313196649373696,
  "in_reply_to_status_id" : 393311139951812608,
  "created_at" : "2013-10-24 09:49:08 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393310557170053121",
  "geo" : { },
  "id_str" : "393311378179514368",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon sure, but for a compromise either both individuals show non-sig change or both should show sig change in speed I'd guess.",
  "id" : 393311378179514368,
  "in_reply_to_status_id" : 393310557170053121,
  "created_at" : "2013-10-24 09:41:54 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393310962054217729",
  "text" : "Uh, since when do you need an account to download data from the JGI?",
  "id" : 393310962054217729,
  "created_at" : "2013-10-24 09:40:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393307705156599808",
  "geo" : { },
  "id_str" : "393310147411329025",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon plus: one could argue that individual changes are non-sig shows that it's compromising.",
  "id" : 393310147411329025,
  "in_reply_to_status_id" : 393307705156599808,
  "created_at" : "2013-10-24 09:37:01 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393307705156599808",
  "geo" : { },
  "id_str" : "393309195870543872",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon but then again that makes little sense: qua definition they the total speed diff has to approach 0 for walking together.",
  "id" : 393309195870543872,
  "in_reply_to_status_id" : 393307705156599808,
  "created_at" : "2013-10-24 09:33:14 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393307705156599808",
  "geo" : { },
  "id_str" : "393309063838060544",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon yeah, my guess: comp. speed diff (male\/female alone) to (male\/female walking together) would work if in dire need of a p-val.",
  "id" : 393309063838060544,
  "in_reply_to_status_id" : 393307705156599808,
  "created_at" : "2013-10-24 09:32:42 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393306328858632192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724029612, 8.6275858898 ]
  },
  "id_str" : "393307540337225728",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon for same-sex: males increase speed over preferred speed of individuals, females decrease below preferred.",
  "id" : 393307540337225728,
  "in_reply_to_status_id" : 393306328858632192,
  "created_at" : "2013-10-24 09:26:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393306328858632192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724029612, 8.6275858898 ]
  },
  "id_str" : "393307363564081152",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon depends as far as I\u2019ve understood: opposite-sex friends compromise between preferred speeds but individual speed changes are p&gt;.05",
  "id" : 393307363564081152,
  "in_reply_to_status_id" : 393306328858632192,
  "created_at" : "2013-10-24 09:25:57 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/WF0dSiFnWt",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0076576",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393304990409699328",
  "text" : "\u00ABWalking Speed Choices among Friendly Dyads\u00BB Interesting, but: n=22 and I don't buy their evolutionary explanation http:\/\/t.co\/WF0dSiFnWt",
  "id" : 393304990409699328,
  "created_at" : "2013-10-24 09:16:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ennomane",
      "screen_name" : "ennomane",
      "indices" : [ 3, 12 ],
      "id_str" : "850704103814705152",
      "id" : 850704103814705152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gender",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/on5vULk8BB",
      "expanded_url" : "http:\/\/bit.ly\/19za47z",
      "display_url" : "bit.ly\/19za47z"
    } ]
  },
  "geo" : { },
  "id_str" : "393299452926394368",
  "text" : "RT @ennomane: Jonas war im Kleid in der Schule! #Gender http:\/\/t.co\/on5vULk8BB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gender",
        "indices" : [ 34, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/on5vULk8BB",
        "expanded_url" : "http:\/\/bit.ly\/19za47z",
        "display_url" : "bit.ly\/19za47z"
      } ]
    },
    "geo" : { },
    "id_str" : "393284337371975680",
    "text" : "Jonas war im Kleid in der Schule! #Gender http:\/\/t.co\/on5vULk8BB",
    "id" : 393284337371975680,
    "created_at" : "2013-10-24 07:54:27 +0000",
    "user" : {
      "name" : "Enno Park",
      "screen_name" : "ennopark",
      "protected" : false,
      "id_str" : "16034275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/850708765955457024\/GvgumDIQ_normal.jpg",
      "id" : 16034275,
      "verified" : false
    }
  },
  "id" : 393299452926394368,
  "created_at" : "2013-10-24 08:54:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723981344, 8.6273826032 ]
  },
  "id_str" : "393291559640502272",
  "text" : "\u00ABIhr k\u00F6nnt f\u00FCr das Seminar gern alles verwenden. Videokameras, Partner, Ausdruckstanz, \u2026\u00BB",
  "id" : 393291559640502272,
  "created_at" : "2013-10-24 08:23:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723291992, 8.6275750881 ]
  },
  "id_str" : "393285064517500928",
  "text" : "\u00ABMeine Mutter ist auch schon um 6 aufgestanden. Dann habe ich sie gezwungen Pita f\u00FCr uns zu backen!\u00BB",
  "id" : 393285064517500928,
  "created_at" : "2013-10-24 07:57:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/q2W3yHlxYi",
      "expanded_url" : "http:\/\/blog.pieratt.com\/post\/64881538909\/work-versus-life-greatness-versus-family",
      "display_url" : "blog.pieratt.com\/post\/648815389\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393164764324847617",
  "text" : "RT @genetics_blog: Every lab head \/ PI should read this. \"Work versus Life. Greatness versus Family.\" http:\/\/t.co\/q2W3yHlxYi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/q2W3yHlxYi",
        "expanded_url" : "http:\/\/blog.pieratt.com\/post\/64881538909\/work-versus-life-greatness-versus-family",
        "display_url" : "blog.pieratt.com\/post\/648815389\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393162803454181376",
    "text" : "Every lab head \/ PI should read this. \"Work versus Life. Greatness versus Family.\" http:\/\/t.co\/q2W3yHlxYi",
    "id" : 393162803454181376,
    "created_at" : "2013-10-23 23:51:31 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 393164764324847617,
  "created_at" : "2013-10-23 23:59:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    }, {
      "name" : "Yaniv (((Erlich)))",
      "screen_name" : "erlichya",
      "indices" : [ 39, 48 ],
      "id_str" : "495517322",
      "id" : 495517322
    }, {
      "name" : "Oxford Nanopore",
      "screen_name" : "nanopore",
      "indices" : [ 57, 66 ],
      "id_str" : "37732219",
      "id" : 37732219
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ASHG2013",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393161785685311488",
  "text" : "RT @genetics_blog: nanopore details RT @erlichya: Oxford @nanopore disclose new details on their sample prep. A new blog post #ASHG2013 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yaniv (((Erlich)))",
        "screen_name" : "erlichya",
        "indices" : [ 20, 29 ],
        "id_str" : "495517322",
        "id" : 495517322
      }, {
        "name" : "Oxford Nanopore",
        "screen_name" : "nanopore",
        "indices" : [ 38, 47 ],
        "id_str" : "37732219",
        "id" : 37732219
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ASHG2013",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/puqE9Yr0Rw",
        "expanded_url" : "http:\/\/bit.ly\/1iezQQg",
        "display_url" : "bit.ly\/1iezQQg"
      } ]
    },
    "geo" : { },
    "id_str" : "393161077846183936",
    "text" : "nanopore details RT @erlichya: Oxford @nanopore disclose new details on their sample prep. A new blog post #ASHG2013 http:\/\/t.co\/puqE9Yr0Rw",
    "id" : 393161077846183936,
    "created_at" : "2013-10-23 23:44:40 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 393161785685311488,
  "created_at" : "2013-10-23 23:47:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393154254783127552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096839067, 8.2831243297 ]
  },
  "id_str" : "393154559050534912",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode also mein Client zeigt die Locations inline an, wenn es eine gibt sehe ich sie auch. ;)",
  "id" : 393154559050534912,
  "in_reply_to_status_id" : 393154254783127552,
  "created_at" : "2013-10-23 23:18:45 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/ykt1SkGEer",
      "expanded_url" : "http:\/\/instagram.com\/p\/f0_Ynvhwi2\/",
      "display_url" : "instagram.com\/p\/f0_Ynvhwi2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "393153585107972096",
  "text" : "Ein &lt;3 f\u00FCr Invertebraten http:\/\/t.co\/ykt1SkGEer",
  "id" : 393153585107972096,
  "created_at" : "2013-10-23 23:14:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393152608783056896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096501809, 8.2829929555 ]
  },
  "id_str" : "393152771471720448",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode steht doch bei jedem Tweet dabei (und in der Bio!)",
  "id" : 393152771471720448,
  "in_reply_to_status_id" : 393152608783056896,
  "created_at" : "2013-10-23 23:11:39 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393147657851387904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096879831, 8.2831476585 ]
  },
  "id_str" : "393152074470653952",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode ich geb gern laut wenn ich mal in der Gegend bin.",
  "id" : 393152074470653952,
  "in_reply_to_status_id" : 393147657851387904,
  "created_at" : "2013-10-23 23:08:53 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    }, {
      "name" : "maiimouna",
      "screen_name" : "Maiimouna",
      "indices" : [ 10, 20 ],
      "id_str" : "62768385",
      "id" : 62768385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393145777805332480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096609198, 8.2830508953 ]
  },
  "id_str" : "393147177373270017",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode @Maiimouna news at 11 ;)",
  "id" : 393147177373270017,
  "in_reply_to_status_id" : 393145777805332480,
  "created_at" : "2013-10-23 22:49:26 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maiimouna",
      "screen_name" : "Maiimouna",
      "indices" : [ 0, 10 ],
      "id_str" : "62768385",
      "id" : 62768385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393141892160172032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096679334, 8.2829596444 ]
  },
  "id_str" : "393143862967169025",
  "in_reply_to_user_id" : 62768385,
  "text" : "@Maiimouna naja, die polycyclic aromatic hydrocarbons waren etwas lahm. ;)",
  "id" : 393143862967169025,
  "in_reply_to_status_id" : 393141892160172032,
  "created_at" : "2013-10-23 22:36:15 +0000",
  "in_reply_to_screen_name" : "Maiimouna",
  "in_reply_to_user_id_str" : "62768385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elementary",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967096, 8.2829610016 ]
  },
  "id_str" : "393141138129166336",
  "text" : "\u00ABUh, sexy!\u00BB \u2014 \u00ABDer Kerl?\u00BB \u2014 \u00ABNein, der IonTorrent Benchtop Sequencer im Hintergrund!\u00BB #elementary",
  "id" : 393141138129166336,
  "created_at" : "2013-10-23 22:25:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/3lAcKYNonH",
      "expanded_url" : "http:\/\/www.pbh2.com\/wordpress\/wp-content\/uploads\/2012\/10\/pandas-tumble-down-slide-2.gif",
      "display_url" : "pbh2.com\/wordpress\/wp-c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096397482, 8.2829710957 ]
  },
  "id_str" : "393126103747158017",
  "text" : "\u00ABWie? Gar keine multiplen Orgasmen heute?\u00BB \u2014 \u00ABIch merk schon: No pressure, Panda!\u00BB http:\/\/t.co\/3lAcKYNonH",
  "id" : 393126103747158017,
  "created_at" : "2013-10-23 21:25:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 40, 49 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393100008024989696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096673173, 8.2829562581 ]
  },
  "id_str" : "393100261126053888",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Ganz im gegenteil! Ich glaube @Senficon hat viel mehr davon wenn du sie endorsed als wenn ich das versuchen w\u00FCrde ;)",
  "id" : 393100261126053888,
  "in_reply_to_status_id" : 393100008024989696,
  "created_at" : "2013-10-23 19:43:00 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096458824, 8.2829181934 ]
  },
  "id_str" : "393090495133794304",
  "text" : "\u00ABIch mein, \u2018Impact Factor\u2019, das klingt doch schon so als ob sich das ein SM-Berater ausgedacht h\u00E4tte!\u00BB\u2014\u00ABIt\u2019s like Klout-Scores for Science\u2026\u00BB",
  "id" : 393090495133794304,
  "created_at" : "2013-10-23 19:04:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 6, 15 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0050339819, 8.2899825187 ]
  },
  "id_str" : "393087290337423360",
  "text" : "\u00ABAch, @JP_Stich nimmt mich jetzt in Sippenhaft weil du ihn als Langzeitstudenten tituliert hast?\u00BB\u2014\u00ABDER hat mich immerhin publicly endorsed!\u00BB",
  "id" : 393087290337423360,
  "created_at" : "2013-10-23 18:51:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393080762037456896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0090121377, 8.2844818755 ]
  },
  "id_str" : "393083439442059264",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot eine meiner gr\u00F6\u00DFeren Qualit\u00E4ten muss ich mir also regelm\u00E4\u00DFig neu erkaufen. Not sure if win. ;)",
  "id" : 393083439442059264,
  "in_reply_to_status_id" : 393080762037456896,
  "created_at" : "2013-10-23 18:36:09 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393029283183996928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096668733, 8.2829609033 ]
  },
  "id_str" : "393077438684868608",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Lobot Mehr bin ich f\u00FCr dich also nicht mehr, nun wo ich nicht mehr Content-Orga mache? ;)",
  "id" : 393077438684868608,
  "in_reply_to_status_id" : 393029283183996928,
  "created_at" : "2013-10-23 18:12:19 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9939388478, 8.2444358969 ]
  },
  "id_str" : "393059587412480000",
  "text" : "\u00ABMir wurde diese Studie forwarded nach der Leute Sex zwischen 11 und 1 pr\u00E4ferieren.\u00BB \u2014 \u00ABIn der Mittagspause?!\u00AB",
  "id" : 393059587412480000,
  "created_at" : "2013-10-23 17:01:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0695363236, 8.6118339426 ]
  },
  "id_str" : "393037898859425792",
  "text" : "\u00ABBereit zum intellektuellen Duell um Methodenwissen?\u00BB\u2014\u00ABKlar! Mit oder ohne Anschreien?\u00BB\u2014\u00ABMit, wie wei\u00DF ich sonst wann ich gewonnen hab?!\u00BB",
  "id" : 393037898859425792,
  "created_at" : "2013-10-23 15:35:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9922402393, 8.4183350672 ]
  },
  "id_str" : "393029463895977985",
  "text" : "\u00ABAufgrund eines explodierten, \u00E4h, liegengebliebenen G\u00FCterzugs in Mainz-Kastel f\u00E4hrt dieser Zug heute wie die S8.\u00BB",
  "id" : 393029463895977985,
  "created_at" : "2013-10-23 15:01:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "393023928920047618",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0790396414, 8.6407418344 ]
  },
  "id_str" : "393024723673960448",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner wenn es zum Zerw\u00FCrfnis kommt kann man \u00FCber \u2018Wallace\u2019 weiter nach \u2018Laurasia\u2019 (Erdgeschoss, wie zu erwarten) ziehen.",
  "id" : 393024723673960448,
  "in_reply_to_status_id" : 393023928920047618,
  "created_at" : "2013-10-23 14:42:50 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1171966055, 8.6638135482 ]
  },
  "id_str" : "393017097787559936",
  "text" : "\u00ABIch suche den Konferenzraum \u2018Gondwana\u2019.\u00BB \u2014 \u00ABDer ist nat\u00FCrlich im S\u00FCden. Also im Keller.\u00BB",
  "id" : 393017097787559936,
  "created_at" : "2013-10-23 14:12:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 9, 15 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392996193136959488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1164303394, 8.6490954336 ]
  },
  "id_str" : "392996952574812160",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju @Lobot in the museum\u2019s underground archives, where scheduled lock times may force you to stay!",
  "id" : 392996952574812160,
  "in_reply_to_status_id" : 392996193136959488,
  "created_at" : "2013-10-23 12:52:29 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392996141274374144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1166556174, 8.6499070746 ]
  },
  "id_str" : "392996573938216960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i said suppression, not ignition!",
  "id" : 392996573938216960,
  "in_reply_to_status_id" : 392996141274374144,
  "created_at" : "2013-10-23 12:50:59 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392994960984637440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1163925555, 8.6489524126 ]
  },
  "id_str" : "392996488869314560",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nooooo, I hoped for pics! :)",
  "id" : 392996488869314560,
  "in_reply_to_status_id" : 392994960984637440,
  "created_at" : "2013-10-23 12:50:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392993104078188544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1177703704, 8.649408599 ]
  },
  "id_str" : "392994133788594176",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot to places where lighting a cigarette will lead to a different kind of autoerotic asphyxiation thanks to the gaseous fire suppression?",
  "id" : 392994133788594176,
  "in_reply_to_status_id" : 392993104078188544,
  "created_at" : "2013-10-23 12:41:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392990155700580352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1158250478, 8.6810378361 ]
  },
  "id_str" : "392991471001141248",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ready to call your bluff on that. You wouldn\u2019t believe what the Senckenberg has in storage!",
  "id" : 392991471001141248,
  "in_reply_to_status_id" : 392990155700580352,
  "created_at" : "2013-10-23 12:30:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/fkIp22Mvs5",
      "expanded_url" : "http:\/\/i.imgur.com\/D8vfEeQ.jpg",
      "display_url" : "i.imgur.com\/D8vfEeQ.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1198363939, 8.6776659007 ]
  },
  "id_str" : "392989939006447617",
  "text" : "Und ich dachte meine Blutflecken in Vogel-Form w\u00E4ren schon cool! http:\/\/t.co\/fkIp22Mvs5",
  "id" : 392989939006447617,
  "created_at" : "2013-10-23 12:24:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392818241728282624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1436316634, 8.6686089425 ]
  },
  "id_str" : "392988680077713408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer please tell me you visited that museum!",
  "id" : 392988680077713408,
  "in_reply_to_status_id" : 392818241728282624,
  "created_at" : "2013-10-23 12:19:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tokyo Reporter",
      "screen_name" : "tokyoreporter",
      "indices" : [ 3, 17 ],
      "id_str" : "19386949",
      "id" : 19386949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/6NAZhRC9HQ",
      "expanded_url" : "http:\/\/nymag.com\/thecut\/2013\/10\/parasite-museum-japans-version-of-a-hot-date.html",
      "display_url" : "nymag.com\/thecut\/2013\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392988171212177408",
  "text" : "RT @tokyoreporter: People in Japan Aren\u2019t Having Sex Because They Think Visiting a Parasite Museum Is a Hot Date http:\/\/t.co\/6NAZhRC9HQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/6NAZhRC9HQ",
        "expanded_url" : "http:\/\/nymag.com\/thecut\/2013\/10\/parasite-museum-japans-version-of-a-hot-date.html",
        "display_url" : "nymag.com\/thecut\/2013\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392818086807478273",
    "text" : "People in Japan Aren\u2019t Having Sex Because They Think Visiting a Parasite Museum Is a Hot Date http:\/\/t.co\/6NAZhRC9HQ",
    "id" : 392818086807478273,
    "created_at" : "2013-10-23 01:01:44 +0000",
    "user" : {
      "name" : "Tokyo Reporter",
      "screen_name" : "tokyoreporter",
      "protected" : false,
      "id_str" : "19386949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737606299270029314\/QwwpRPmN_normal.jpg",
      "id" : 19386949,
      "verified" : false
    }
  },
  "id" : 392988171212177408,
  "created_at" : "2013-10-23 12:17:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((The Doctor)))",
      "screen_name" : "virtadpt",
      "indices" : [ 3, 12 ],
      "id_str" : "123610994",
      "id" : 123610994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knitting",
      "indices" : [ 19, 28 ]
    }, {
      "text" : "police",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/aXKgFLsFKr",
      "expanded_url" : "https:\/\/madmanknitting.wordpress.com\/2013\/10\/19\/i-was-questioned-by-the-police\/",
      "display_url" : "madmanknitting.wordpress.com\/2013\/10\/19\/i-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392987048132767744",
  "text" : "RT @virtadpt: Male #knitting in a coffee shop questioned by #police, turns out very differently than expected: https:\/\/t.co\/aXKgFLsFKr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "knitting",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "police",
        "indices" : [ 46, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/aXKgFLsFKr",
        "expanded_url" : "https:\/\/madmanknitting.wordpress.com\/2013\/10\/19\/i-was-questioned-by-the-police\/",
        "display_url" : "madmanknitting.wordpress.com\/2013\/10\/19\/i-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392515456977743872",
    "text" : "Male #knitting in a coffee shop questioned by #police, turns out very differently than expected: https:\/\/t.co\/aXKgFLsFKr",
    "id" : 392515456977743872,
    "created_at" : "2013-10-22 04:59:12 +0000",
    "user" : {
      "name" : "(((The Doctor)))",
      "screen_name" : "virtadpt",
      "protected" : false,
      "id_str" : "123610994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765677904168529920\/0vI2TBJE_normal.jpg",
      "id" : 123610994,
      "verified" : false
    }
  },
  "id" : 392987048132767744,
  "created_at" : "2013-10-23 12:13:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392984041991176192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1698269994, 8.622527612 ]
  },
  "id_str" : "392984808118554624",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay sollte ich mir life coach in die Bio schreiben?",
  "id" : 392984808118554624,
  "in_reply_to_status_id" : 392984041991176192,
  "created_at" : "2013-10-23 12:04:14 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392982345252601856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722896212, 8.6276538318 ]
  },
  "id_str" : "392983744015253504",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay ich gebe die \u00DCbungen in \u2018Sich nicht zu ernst nehmen 101\u2019 ;)",
  "id" : 392983744015253504,
  "in_reply_to_status_id" : 392982345252601856,
  "created_at" : "2013-10-23 12:00:00 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392981184122470401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722896212, 8.6276538318 ]
  },
  "id_str" : "392982056583852032",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay zu meinen Studenten. ;)",
  "id" : 392982056583852032,
  "in_reply_to_status_id" : 392981184122470401,
  "created_at" : "2013-10-23 11:53:18 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392981001447563264",
  "text" : "\u00ABDu bist neu in die Runde gekommen. Erz\u00E4hl auch was peinliches von dir.\u00BB \u2013 \u00ABBitte nicht, seine normalen Geschichten sind schon so weird!\u00BB",
  "id" : 392981001447563264,
  "created_at" : "2013-10-23 11:49:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/OvKKj41ueO",
      "expanded_url" : "http:\/\/haacked.com\/archive\/2013\/10\/21\/argue-well-by-losing.aspx",
      "display_url" : "haacked.com\/archive\/2013\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392975144148144128",
  "text" : "Argue Well By Losing http:\/\/t.co\/OvKKj41ueO",
  "id" : 392975144148144128,
  "created_at" : "2013-10-23 11:25:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 0, 5 ],
      "id_str" : "14095571",
      "id" : 14095571
    }, {
      "name" : "maiimouna",
      "screen_name" : "Maiimouna",
      "indices" : [ 6, 16 ],
      "id_str" : "62768385",
      "id" : 62768385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/2WQVnTDjIj",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0960982299803613",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "392960133648891904",
  "geo" : { },
  "id_str" : "392973127929442304",
  "in_reply_to_user_id" : 14095571,
  "text" : "@towo @Maiimouna Keine Ahnung, aber eine kurze Suche sagt: Sieht so aus. http:\/\/t.co\/2WQVnTDjIj",
  "id" : 392973127929442304,
  "in_reply_to_status_id" : 392960133648891904,
  "created_at" : "2013-10-23 11:17:49 +0000",
  "in_reply_to_screen_name" : "towo",
  "in_reply_to_user_id_str" : "14095571",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392956238410956800",
  "geo" : { },
  "id_str" : "392956886321856512",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer best public health interest! Given the UK roots I wouldn't be surprised. After all: Koalas are just tree badgers, right?",
  "id" : 392956886321856512,
  "in_reply_to_status_id" : 392956238410956800,
  "created_at" : "2013-10-23 10:13:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/0tj1gRKpo8",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1029",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392955927680135168",
  "text" : "What kind of person I would be\u2026 http:\/\/t.co\/0tj1gRKpo8",
  "id" : 392955927680135168,
  "created_at" : "2013-10-23 10:09:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392954785172701184",
  "geo" : { },
  "id_str" : "392955816426229760",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, the poaching should be straight-forward, given that they are to stoned to run away!",
  "id" : 392955816426229760,
  "in_reply_to_status_id" : 392954785172701184,
  "created_at" : "2013-10-23 10:09:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/wbgVysQtn6",
      "expanded_url" : "http:\/\/www.nature.com\/ncomms\/2013\/131022\/ncomms3614\/full\/ncomms3614.html",
      "display_url" : "nature.com\/ncomms\/2013\/13\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392953899453128704",
  "text" : "Natural gold particles in Eucalyptus leaves and their relevance to exploration for buried gold deposits http:\/\/t.co\/wbgVysQtn6",
  "id" : 392953899453128704,
  "created_at" : "2013-10-23 10:01:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392952096581894145",
  "text" : "\u00ABSo, what we've learned from this paper: We all suck. Now let's have Sushi!\u00BB",
  "id" : 392952096581894145,
  "created_at" : "2013-10-23 09:54:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/NWKifDxIac",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/10\/22\/how-crocodiles-have-sex.html",
      "display_url" : "boingboing.net\/2013\/10\/22\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392950260827295744",
  "text" : "How crocodiles have sex http:\/\/t.co\/NWKifDxIac",
  "id" : 392950260827295744,
  "created_at" : "2013-10-23 09:46:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/ASarEpNUXq",
      "expanded_url" : "http:\/\/instagram.com\/p\/fzce5Shwp2\/",
      "display_url" : "instagram.com\/p\/fzce5Shwp2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "392936034415431680",
  "text" : "Rubber duck journal club: Today I'm talking to myself to explain\u2026 http:\/\/t.co\/ASarEpNUXq",
  "id" : 392936034415431680,
  "created_at" : "2013-10-23 08:50:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/GHCxU961n3",
      "expanded_url" : "http:\/\/instagram.com\/p\/fzceJZBwp0\/",
      "display_url" : "instagram.com\/p\/fzceJZBwp0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "392936010809896960",
  "text" : "Rubber duck journal club: Today I'm talking to myself to explain\u2026 http:\/\/t.co\/GHCxU961n3",
  "id" : 392936010809896960,
  "created_at" : "2013-10-23 08:50:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392921025660190720",
  "geo" : { },
  "id_str" : "392921487323054080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer don't forget the equally ancient and \"well\" documented Perl scripts to perform batch testing!",
  "id" : 392921487323054080,
  "in_reply_to_status_id" : 392921025660190720,
  "created_at" : "2013-10-23 07:52:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392909668562915328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.120094671, 8.6780361293 ]
  },
  "id_str" : "392910118930882560",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Seriously: Paco and one other prof later on showed me how to do branch &amp; branch-site tests. Becomes cargo cultish quickly.",
  "id" : 392910118930882560,
  "in_reply_to_status_id" : 392909668562915328,
  "created_at" : "2013-10-23 07:07:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392901025004138497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1108596463, 8.6885234816 ]
  },
  "id_str" : "392909296306249728",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer only what, 10 years, after the release of PAML it might finally become usable without vertically transmitted secret knowledge?",
  "id" : 392909296306249728,
  "in_reply_to_status_id" : 392901025004138497,
  "created_at" : "2013-10-23 07:04:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/kBXjkhgHdp",
      "expanded_url" : "http:\/\/www.shamusyoung.com\/twentysidedtale\/?p=9557",
      "display_url" : "shamusyoung.com\/twentysidedtal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392895888194297856",
  "text" : "RT @PhilippBayer: Slightly old, but still true 3 years later: \"Object-Disoriented Programming\" http:\/\/t.co\/kBXjkhgHdp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/kBXjkhgHdp",
        "expanded_url" : "http:\/\/www.shamusyoung.com\/twentysidedtale\/?p=9557",
        "display_url" : "shamusyoung.com\/twentysidedtal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392888351201587200",
    "text" : "Slightly old, but still true 3 years later: \"Object-Disoriented Programming\" http:\/\/t.co\/kBXjkhgHdp",
    "id" : 392888351201587200,
    "created_at" : "2013-10-23 05:40:57 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 392895888194297856,
  "created_at" : "2013-10-23 06:10:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/yT20wz6BtC",
      "expanded_url" : "http:\/\/m.sciencemag.org\/content\/342\/6156\/373",
      "display_url" : "m.sciencemag.org\/content\/342\/61\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009662111, 8.2828956695 ]
  },
  "id_str" : "392802847274053632",
  "text" : "time to take out the trash http:\/\/t.co\/yT20wz6BtC",
  "id" : 392802847274053632,
  "created_at" : "2013-10-23 00:01:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/XOzNbyV1yt",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/64802319599\/when-someone-asks-me-when-i-will-graduate",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/648023195\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096668733, 8.2829609033 ]
  },
  "id_str" : "392784648629395456",
  "text" : "\u00ABNeben dem Pf\u00F6rtnerjob kann ich total gut meine zweite Diss schreiben!\u00BB http:\/\/t.co\/XOzNbyV1yt",
  "id" : 392784648629395456,
  "created_at" : "2013-10-22 22:48:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096668733, 8.2829609033 ]
  },
  "id_str" : "392772359847149568",
  "text" : "\u00ABLass uns das mit den geilen Methoden auf morgen verschieben. Ich versuch das noch mal mit dem Schlaf.\u00BB",
  "id" : 392772359847149568,
  "created_at" : "2013-10-22 22:00:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096668733, 8.2829609033 ]
  },
  "id_str" : "392768803706527744",
  "text" : "Uh oh, reading this email made me seriously reconsider whether I\u2019ve understood any of the methods I used during my Master\u2019s thesis\u2026 o_O",
  "id" : 392768803706527744,
  "created_at" : "2013-10-22 21:45:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095268338, 8.2832284043 ]
  },
  "id_str" : "392758219422314496",
  "text" : "\u00ABHabt ihr gut gefeiert?\u00BB \u2014 \u00ABIch blute.\u00BB \u2014 \u00ABDas werte ich mal als ein 'ja'.\u00BB",
  "id" : 392758219422314496,
  "created_at" : "2013-10-22 21:03:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392756304730542080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392756853773709312",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Und: aus dem Hochbett zu fallen ist viel gef\u00E4hrlicher als von dem Sitzsack zu fallen.",
  "id" : 392756853773709312,
  "in_reply_to_status_id" : 392756304730542080,
  "created_at" : "2013-10-22 20:58:25 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/LSxnqv1Ft4",
      "expanded_url" : "http:\/\/i.imgur.com\/7b3hIo7.gif",
      "display_url" : "i.imgur.com\/7b3hIo7.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392739925906690048",
  "text" : "\u00ABAbove the trophy case hangs an elvish sword of great antiquity.\u00BB http:\/\/t.co\/LSxnqv1Ft4",
  "id" : 392739925906690048,
  "created_at" : "2013-10-22 19:51:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392736065758707712",
  "text" : "\u00ABText-Adventure Enddarm: It is pitch black. You are likely to be eaten by a grue.\u00BB",
  "id" : 392736065758707712,
  "created_at" : "2013-10-22 19:35:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/jsArNnoL7d",
      "expanded_url" : "https:\/\/peerj.com\/articles\/187\/",
      "display_url" : "peerj.com\/articles\/187\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392648245002117120",
  "text" : "PhyBin: binning trees by topology https:\/\/t.co\/jsArNnoL7d",
  "id" : 392648245002117120,
  "created_at" : "2013-10-22 13:46:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 3, 15 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392640545652506624",
  "text" : "RT @froggleston: How would one refer to a cross-discipline wet *and* dry lab researcher? Moist? Clammy? Sandpaper?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392638284448272384",
    "text" : "How would one refer to a cross-discipline wet *and* dry lab researcher? Moist? Clammy? Sandpaper?",
    "id" : 392638284448272384,
    "created_at" : "2013-10-22 13:07:16 +0000",
    "user" : {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "protected" : false,
      "id_str" : "53893339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742344707469086720\/UP8kTNU-_normal.jpg",
      "id" : 53893339,
      "verified" : false
    }
  },
  "id" : 392640545652506624,
  "created_at" : "2013-10-22 13:16:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JAmz4be1fc",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/the-switch\/wp\/2013\/10\/21\/i-paid-4-to-read-this-bitcoin-erotica-so-you-dont-have-to\/",
      "display_url" : "washingtonpost.com\/blogs\/the-swit\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392635061096677377",
  "text" : "\u00ABonce [we] discovered that Bitcoin erotica existed,we felt it was our journalistic duty to review and report on this\u00BB http:\/\/t.co\/JAmz4be1fc",
  "id" : 392635061096677377,
  "created_at" : "2013-10-22 12:54:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/uCDMDhYti5",
      "expanded_url" : "http:\/\/gifs.gifbin.com\/092013\/1381178358_lizard_catches_ant.gif",
      "display_url" : "gifs.gifbin.com\/092013\/1381178\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392631016952963072",
  "text" : "\u00ABDownloading ant launcher\u2026\u00BB http:\/\/t.co\/uCDMDhYti5",
  "id" : 392631016952963072,
  "created_at" : "2013-10-22 12:38:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392627018036441088",
  "text" : "\u00ABOh Gott, du bist ja total verfilzt!\u00BB \u2013 \u00ABIch freu mich auch dich zu sehen\u2026\u00BB",
  "id" : 392627018036441088,
  "created_at" : "2013-10-22 12:22:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OA",
      "indices" : [ 80, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/IUyrmRbdGC",
      "expanded_url" : "http:\/\/www.cell.com\/current-biology\/retrieve\/pii\/S0960982213011159",
      "display_url" : "cell.com\/current-biolog\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392620011963305984",
  "text" : "Aplacophoran Mollusks Evolved from Ancestors with Polyplacophoran-like Features #OA http:\/\/t.co\/IUyrmRbdGC",
  "id" : 392620011963305984,
  "created_at" : "2013-10-22 11:54:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/qkS5ztbHwk",
      "expanded_url" : "http:\/\/vimeo.com\/77111226",
      "display_url" : "vimeo.com\/77111226"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392619197857300482",
  "text" : "\u00ABResearch? Du schaust ja Pornos!\u00BB (not slacking off, my grails project is compiling) http:\/\/t.co\/qkS5ztbHwk",
  "id" : 392619197857300482,
  "created_at" : "2013-10-22 11:51:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009572445, 8.2828720317 ]
  },
  "id_str" : "392616164570173441",
  "text" : "\u00ABFictitious: This app cries at weddings.\u00BB Too bad, that would have made a great feature.",
  "id" : 392616164570173441,
  "created_at" : "2013-10-22 11:39:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/cO4pFBig01",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/List_of_fictional_badgers",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658298, 8.283057512 ]
  },
  "id_str" : "392597530917498880",
  "text" : "\u00ABList of fictional badgers. This list is incomplete [\u2026] Main article: List of fictional mustelids\u00BB It\u2019s work-related! http:\/\/t.co\/cO4pFBig01",
  "id" : 392597530917498880,
  "created_at" : "2013-10-22 10:25:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658298, 8.283057512 ]
  },
  "id_str" : "392584521964875776",
  "text" : "\u00ABOh, so Grails is just like Rails with more time to slack off because you need to compile it?\u00BB",
  "id" : 392584521964875776,
  "created_at" : "2013-10-22 09:33:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0430\u0441\u0442\u0430\u0441\u0438\u044F \u041F\u0440\u0438\u0432\u043E\u043B\u0436\u043D\u0430\u044F",
      "screen_name" : "Wutbuergerin",
      "indices" : [ 3, 16 ],
      "id_str" : "224452301",
      "id" : 224452301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/8BjKJy7AOe",
      "expanded_url" : "http:\/\/buff.ly\/GYxv06",
      "display_url" : "buff.ly\/GYxv06"
    } ]
  },
  "geo" : { },
  "id_str" : "392562589466906624",
  "text" : "RT @Wutbuergerin: 'dignitary harm'? Van Asche et al on dignitary interests of participants in genetics research http:\/\/t.co\/8BjKJy7AOe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/8BjKJy7AOe",
        "expanded_url" : "http:\/\/buff.ly\/GYxv06",
        "display_url" : "buff.ly\/GYxv06"
      } ]
    },
    "geo" : { },
    "id_str" : "392561568099368960",
    "text" : "'dignitary harm'? Van Asche et al on dignitary interests of participants in genetics research http:\/\/t.co\/8BjKJy7AOe",
    "id" : 392561568099368960,
    "created_at" : "2013-10-22 08:02:25 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 392562589466906624,
  "created_at" : "2013-10-22 08:06:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/zUxHWqEx3n",
      "expanded_url" : "http:\/\/www.nytimes.com\/video\/us\/100000002507537\/scalded-by-coffee-then-news-media.html",
      "display_url" : "nytimes.com\/video\/us\/10000\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658298, 8.283057512 ]
  },
  "id_str" : "392555443186597888",
  "text" : "Scalded by Coffee, Then News Media http:\/\/t.co\/zUxHWqEx3n",
  "id" : 392555443186597888,
  "created_at" : "2013-10-22 07:38:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Kx1qUcNJcV",
      "expanded_url" : "http:\/\/pythonsweetness.tumblr.com\/post\/64740079543\/how-to-lose-172-222-a-second-for-45-minutes",
      "display_url" : "pythonsweetness.tumblr.com\/post\/647400795\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658298, 8.283057512 ]
  },
  "id_str" : "392547962758639616",
  "text" : "This sounds just like deployment in academia. But thanks to the funding situation we seldom lose $465m in the process http:\/\/t.co\/Kx1qUcNJcV",
  "id" : 392547962758639616,
  "created_at" : "2013-10-22 07:08:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 3, 11 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icanhazpdf",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392432210433028096",
  "text" : "RT @rmounce: Acknowledgements: thanks to library.nu \/ #icanhazpdf \/ SciHub and more - I couldn't have done it without you http:\/\/t.co\/vYkTB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "icanhazpdf",
        "indices" : [ 41, 52 ]
      }, {
        "text" : "OAweek",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/vYkTBA2e7D",
        "expanded_url" : "http:\/\/rossmounce.co.uk\/2013\/10\/21\/acknowledgements\/",
        "display_url" : "rossmounce.co.uk\/2013\/10\/21\/ack\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392431517676605440",
    "text" : "Acknowledgements: thanks to library.nu \/ #icanhazpdf \/ SciHub and more - I couldn't have done it without you http:\/\/t.co\/vYkTBA2e7D #OAweek",
    "id" : 392431517676605440,
    "created_at" : "2013-10-21 23:25:39 +0000",
    "user" : {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "protected" : false,
      "id_str" : "222765418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668402841262927872\/2vZUj52I_normal.jpg",
      "id" : 222765418,
      "verified" : false
    }
  },
  "id" : 392432210433028096,
  "created_at" : "2013-10-21 23:28:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392419696399486977",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096345723, 8.2829667025 ]
  },
  "id_str" : "392420583671341056",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus ich hab mich sehr \u00FCber den inside joke gefreut. :)",
  "id" : 392420583671341056,
  "in_reply_to_status_id" : 392419696399486977,
  "created_at" : "2013-10-21 22:42:12 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/TXeac6Jbbv",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/392416190704128001",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "392419142185136129",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097390125, 8.2829309162 ]
  },
  "id_str" : "392419509489111040",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus nein, https:\/\/t.co\/TXeac6Jbbv kommt aus dem Buch was ich heut gelesen habe und ist nat\u00FCrlich ein Wink auf den GBE. :)",
  "id" : 392419509489111040,
  "in_reply_to_status_id" : 392419142185136129,
  "created_at" : "2013-10-21 22:37:56 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392418270541660160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096715933, 8.2830198082 ]
  },
  "id_str" : "392418735359008768",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus nicht ich, Bill Hamilton (ich wei\u00DF nicht ob er je einen Bart getragen hat).",
  "id" : 392418735359008768,
  "in_reply_to_status_id" : 392418270541660160,
  "created_at" : "2013-10-21 22:34:51 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/dVuHecqMR3",
      "expanded_url" : "http:\/\/liorpachter.wordpress.com\/2013\/10\/21\/gtex\/",
      "display_url" : "liorpachter.wordpress.com\/2013\/10\/21\/gte\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658298, 8.283057512 ]
  },
  "id_str" : "392417105725104128",
  "text" : "GTEx is throwing away 90% of their\u00A0data http:\/\/t.co\/dVuHecqMR3",
  "id" : 392417105725104128,
  "created_at" : "2013-10-21 22:28:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/KzhYgzhPZj",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Green-beard_effect",
      "display_url" : "en.wikipedia.org\/wiki\/Green-bea\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658298, 8.283057512 ]
  },
  "id_str" : "392416785766817792",
  "text" : "Though seriously: Dishonest green-beard effects can only be proposed by people who never dyed theirs. http:\/\/t.co\/KzhYgzhPZj",
  "id" : 392416785766817792,
  "created_at" : "2013-10-21 22:27:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nbga",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658298, 8.283057512 ]
  },
  "id_str" : "392416190704128001",
  "text" : "\u00ABThe idea is that markers arise because they allow altruists to recognize other altruists. The problem: Talk is cheap. So is hair dye\u00BB #nbga",
  "id" : 392416190704128001,
  "created_at" : "2013-10-21 22:24:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392404126866227200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096491585, 8.2829501107 ]
  },
  "id_str" : "392404996027068416",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot but then you try to pressure me into talking to her?! You wonder why I won't trust you?",
  "id" : 392404996027068416,
  "in_reply_to_status_id" : 392404126866227200,
  "created_at" : "2013-10-21 21:40:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "392403766936207360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096815037, 8.2830768268 ]
  },
  "id_str" : "392403908397924353",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ask that girl on the train!",
  "id" : 392403908397924353,
  "in_reply_to_status_id" : 392403766936207360,
  "created_at" : "2013-10-21 21:35:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 11, 25 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/jB15A80YLq",
      "expanded_url" : "https:\/\/github.com\/stephenturner\/oneliners",
      "display_url" : "github.com\/stephenturner\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392397379997290496",
  "text" : "Looks like @genetics_blog has just published everything I know about bioinformatics as a single README https:\/\/t.co\/jB15A80YLq",
  "id" : 392397379997290496,
  "created_at" : "2013-10-21 21:10:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/cKP3TzKRdw",
      "expanded_url" : "http:\/\/imgur.com\/hAk9Cjv",
      "display_url" : "imgur.com\/hAk9Cjv"
    } ]
  },
  "in_reply_to_status_id_str" : "392353815778701313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658298, 8.283057512 ]
  },
  "id_str" : "392396054140039168",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/cKP3TzKRdw",
  "id" : 392396054140039168,
  "in_reply_to_status_id" : 392353815778701313,
  "created_at" : "2013-10-21 21:04:44 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9955879584, 8.3378145467 ]
  },
  "id_str" : "392358625450418176",
  "text" : "\u00ABWas grinst du so?\u00BB \u2014 \u00ABIch versuche verliebt zu schauen. Aber das muss ich wohl noch \u00FCben.\u00BB",
  "id" : 392358625450418176,
  "created_at" : "2013-10-21 18:36:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0079300151, 8.4520893584 ]
  },
  "id_str" : "392356634594639872",
  "text" : "\u00ABThose who claim to study unquant. complexity are being unreasonable,for quantifying is precisely what we do when things get complicated\u00BB &lt;3",
  "id" : 392356634594639872,
  "created_at" : "2013-10-21 18:28:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/iDApt48jA4",
      "expanded_url" : "http:\/\/amzn.com\/k\/mEsF0mjaQn2Snu-3b6B9uA",
      "display_url" : "amzn.com\/k\/mEsF0mjaQn2S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392355406447910912",
  "text" : "\u00ABScratch many a scientist, and a nature mystic bleeds.\u00BB What a nice adaptation of Ghiselin's quote!  http:\/\/t.co\/iDApt48jA4 Scientifi...",
  "id" : 392355406447910912,
  "created_at" : "2013-10-21 18:23:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nbga",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0698741111, 8.6327011667 ]
  },
  "id_str" : "392351839427264512",
  "text" : "\u00ABSo many older scientists try their hand at philosophy that it can practically be regarded as a normal sign of aging.\u00BB #nbga",
  "id" : 392351839427264512,
  "created_at" : "2013-10-21 18:09:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/D7UM76Gp6Q",
      "expanded_url" : "http:\/\/imgur.com\/r\/funny\/BxVePVt",
      "display_url" : "imgur.com\/r\/funny\/BxVePVt"
    } ]
  },
  "geo" : { },
  "id_str" : "392287306712748033",
  "text" : "Danger! http:\/\/t.co\/D7UM76Gp6Q",
  "id" : 392287306712748033,
  "created_at" : "2013-10-21 13:52:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan",
      "screen_name" : "Lichtecho",
      "indices" : [ 0, 10 ],
      "id_str" : "44849597",
      "id" : 44849597
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 11, 21 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 22, 31 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/jt5pVpei95",
      "expanded_url" : "http:\/\/de.wikipedia.org\/wiki\/Ficken#Etymologie",
      "display_url" : "de.wikipedia.org\/wiki\/Ficken#Et\u2026"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/S3GJHXILwC",
      "expanded_url" : "https:\/\/books.google.com\/ngrams\/graph?content=fick%2C+ficken&year_start=1800&year_end=2000&corpus=20&smoothing=3&share=&direct_url=t1%3B%2Cfick%3B%2Cc0%3B.t1%3B%2Cficken%3B%2Cc0",
      "display_url" : "books.google.com\/ngrams\/graph?c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "392273734687809536",
  "geo" : { },
  "id_str" : "392277105121054720",
  "in_reply_to_user_id" : 44849597,
  "text" : "@Lichtecho @Fischblog @Roterhai Laut wikipedia ja. http:\/\/t.co\/jt5pVpei95 Laut ngrams aber weniger in Schrift. https:\/\/t.co\/S3GJHXILwC",
  "id" : 392277105121054720,
  "in_reply_to_status_id" : 392273734687809536,
  "created_at" : "2013-10-21 13:12:04 +0000",
  "in_reply_to_screen_name" : "Lichtecho",
  "in_reply_to_user_id_str" : "44849597",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392219917459529728",
  "text" : "A prime example of vagrancy: Me using vagrant\u2026",
  "id" : 392219917459529728,
  "created_at" : "2013-10-21 09:24:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/SVo4ICbXql",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Fick%27s_laws_of_diffusion",
      "display_url" : "en.wikipedia.org\/wiki\/Fick%27s_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "392206078970036225",
  "geo" : { },
  "id_str" : "392206243042848769",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng http:\/\/t.co\/SVo4ICbXql",
  "id" : 392206243042848769,
  "in_reply_to_status_id" : 392206078970036225,
  "created_at" : "2013-10-21 08:30:29 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392205905523011584",
  "text" : "Die Fick\u2019schen Gesetze. Amusing students since 1855.",
  "id" : 392205905523011584,
  "created_at" : "2013-10-21 08:29:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ULh5X2Z1DI",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/10\/20\/howto-braid-your-long-hair-int.html",
      "display_url" : "boingboing.net\/2013\/10\/20\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392194140500267008",
  "text" : "HOWTO braid your long hair into a Gimli beard http:\/\/t.co\/ULh5X2Z1DI",
  "id" : 392194140500267008,
  "created_at" : "2013-10-21 07:42:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1182201947, 8.6795853198 ]
  },
  "id_str" : "392183373177053184",
  "text" : "\u00ABmoralistic punishment can stabilize any arbitrary behavior\u2014wearing a tie, being kind to animals, or eating the brains of dead relatives.\u00BB",
  "id" : 392183373177053184,
  "created_at" : "2013-10-21 06:59:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nbga",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1052857562, 8.6345854379 ]
  },
  "id_str" : "392181548172460032",
  "text" : "\u00ABCulture is on a leash, but the dog on the end is big, smart, and independent. On any walk, it's hard to tell who is leading who.\u00BB #nbga",
  "id" : 392181548172460032,
  "created_at" : "2013-10-21 06:52:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/oMim4Ym7bE",
      "expanded_url" : "http:\/\/instagram.com\/p\/fuAxY7Bwim\/",
      "display_url" : "instagram.com\/p\/fuAxY7Bwim\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0075459472, 8.2818889618 ]
  },
  "id_str" : "392171537471909888",
  "text" : "\u00ABI might be a bit later in the office today\u2026\u00BB @ Bahnhof Mainz-Kastel http:\/\/t.co\/oMim4Ym7bE",
  "id" : 392171537471909888,
  "created_at" : "2013-10-21 06:12:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/4kE5OhCJj0",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/psi-vid\/2013\/10\/19\/lucky-field-researcher-witnesses-birth-of-sloth-happy-international-day-of-the-sloth\/",
      "display_url" : "blogs.scientificamerican.com\/psi-vid\/2013\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009666, 8.282944 ]
  },
  "id_str" : "392079074031861760",
  "text" : "So I missed International Sloth Day by a few hours?! http:\/\/t.co\/4kE5OhCJj0",
  "id" : 392079074031861760,
  "created_at" : "2013-10-21 00:05:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/v2absPXC8V",
      "expanded_url" : "http:\/\/i.imgur.com\/FSW9K4l.jpg",
      "display_url" : "i.imgur.com\/FSW9K4l.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096148765, 8.2829688024 ]
  },
  "id_str" : "392077562958348288",
  "text" : "\u00ABexceptionally cute for a hamster\u00BB http:\/\/t.co\/v2absPXC8V",
  "id" : 392077562958348288,
  "created_at" : "2013-10-20 23:59:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096904955, 8.2830621756 ]
  },
  "id_str" : "392076694888390656",
  "text" : "\u00ABSo krassen dirty talk macht ihr?\u00BB \u2014 \u00ABDu nennst es dirty talk, ich Terminplanung.\u00BB",
  "id" : 392076694888390656,
  "created_at" : "2013-10-20 23:55:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 3, 16 ],
      "id_str" : "19084034",
      "id" : 19084034
    }, {
      "name" : "Christie Wilcox",
      "screen_name" : "NerdyChristie",
      "indices" : [ 94, 108 ],
      "id_str" : "19808176",
      "id" : 19808176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/wjxT87XKMU",
      "expanded_url" : "https:\/\/medium.com\/the-power-of-harassment\/873515a58835",
      "display_url" : "medium.com\/the-power-of-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392071188874555392",
  "text" : "RT @ericmjohnson: \"I didn\u2019t have accusations to make, and I wasn\u2019t going to spread gossip.\" - @NerdyChristie: https:\/\/t.co\/wjxT87XKMU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christie Wilcox",
        "screen_name" : "NerdyChristie",
        "indices" : [ 76, 90 ],
        "id_str" : "19808176",
        "id" : 19808176
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/wjxT87XKMU",
        "expanded_url" : "https:\/\/medium.com\/the-power-of-harassment\/873515a58835",
        "display_url" : "medium.com\/the-power-of-h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392070625743077377",
    "text" : "\"I didn\u2019t have accusations to make, and I wasn\u2019t going to spread gossip.\" - @NerdyChristie: https:\/\/t.co\/wjxT87XKMU",
    "id" : 392070625743077377,
    "created_at" : "2013-10-20 23:31:36 +0000",
    "user" : {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "protected" : false,
      "id_str" : "19084034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434953612825858048\/DckRYRye_normal.png",
      "id" : 19084034,
      "verified" : false
    }
  },
  "id" : 392071188874555392,
  "created_at" : "2013-10-20 23:33:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/dOzSNC9dFl",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2013\/10\/20\/colorful-case-philosophical-zombie\/#.UmRjaGS6SXo",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968646, 8.28299397 ]
  },
  "id_str" : "392068322919215104",
  "text" : "\u00ABWhether that makes him less of a zombie is one for philosophers to ponder\u00BB Sounds like a fun job! http:\/\/t.co\/dOzSNC9dFl",
  "id" : 392068322919215104,
  "created_at" : "2013-10-20 23:22:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965702, 8.283055044 ]
  },
  "id_str" : "392059431967817729",
  "text" : "\u00ABHaha, jetzt wird Amazon dir f\u00FCr ewig \u2018Bettlaken\u2019 empfehlen!\u00BB \u2013 \u00ABWieso sprichst du das in Scare Quotes?!\u00BB",
  "id" : 392059431967817729,
  "created_at" : "2013-10-20 22:47:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095402966, 8.2828492456 ]
  },
  "id_str" : "392019183934136320",
  "text" : "\u00ABThat's not modesty. There's just no reliable way to test the hypothesis.\u00BB Now I'm sold!",
  "id" : 392019183934136320,
  "created_at" : "2013-10-20 20:07:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/YMi6BWQax0",
      "expanded_url" : "http:\/\/imgur.com\/1PvE1oN",
      "display_url" : "imgur.com\/1PvE1oN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965702, 8.283055044 ]
  },
  "id_str" : "391998340738859008",
  "text" : "And then we kissed like\u2026 http:\/\/t.co\/YMi6BWQax0",
  "id" : 391998340738859008,
  "created_at" : "2013-10-20 18:44:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James McInerney",
      "screen_name" : "jomcinerney",
      "indices" : [ 3, 15 ],
      "id_str" : "22478416",
      "id" : 22478416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391996688367644672",
  "text" : "RT @jomcinerney: Pseudo-Sanger sequencing: massively parallel production of long and near error-free reads using NGS technology http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/PoValEZykM",
        "expanded_url" : "http:\/\/bit.ly\/171iwg3",
        "display_url" : "bit.ly\/171iwg3"
      } ]
    },
    "geo" : { },
    "id_str" : "391990739070382080",
    "text" : "Pseudo-Sanger sequencing: massively parallel production of long and near error-free reads using NGS technology http:\/\/t.co\/PoValEZykM",
    "id" : 391990739070382080,
    "created_at" : "2013-10-20 18:14:09 +0000",
    "user" : {
      "name" : "James McInerney",
      "screen_name" : "jomcinerney",
      "protected" : false,
      "id_str" : "22478416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/872791269646495744\/YElLECX6_normal.jpg",
      "id" : 22478416,
      "verified" : false
    }
  },
  "id" : 391996688367644672,
  "created_at" : "2013-10-20 18:37:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ZXvQdpRUk3",
      "expanded_url" : "http:\/\/imgur.com\/4pwvMKC",
      "display_url" : "imgur.com\/4pwvMKC"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965702, 8.283055044 ]
  },
  "id_str" : "391976940862988288",
  "text" : "\u00ABDu zeigst dich g\u00E4nzlich unbeeindruckt von meiner Nacktheit!\u00BB \u2013 \u00ABSorry, niedliche, nackte Tiere habe mich abgelenkt!\u00BB http:\/\/t.co\/ZXvQdpRUk3",
  "id" : 391976940862988288,
  "created_at" : "2013-10-20 17:19:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 62, 74 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/N8P1xFHwo7",
      "expanded_url" : "http:\/\/wtfshouldidowithmylife.com\/you-should-walk-dogs",
      "display_url" : "wtfshouldidowithmylife.com\/you-should-wal\u2026"
    }, {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/Qv8t8wSo3p",
      "expanded_url" : "http:\/\/wtfshouldidowithmylife.com\/",
      "display_url" : "wtfshouldidowithmylife.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965702, 8.283055044 ]
  },
  "id_str" : "391972504556032001",
  "text" : "I think the web has figured me out! http:\/\/t.co\/N8P1xFHwo7 RT @AkshatRathi: http:\/\/t.co\/Qv8t8wSo3p",
  "id" : 391972504556032001,
  "created_at" : "2013-10-20 17:01:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391955584351608834",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0996143586, 8.5387381017 ]
  },
  "id_str" : "391955747808219136",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng ich hoffe das wird kein gev\u00F6geltes Wort! :p",
  "id" : 391955747808219136,
  "in_reply_to_status_id" : 391955584351608834,
  "created_at" : "2013-10-20 15:55:07 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1005992815, 8.5707600816 ]
  },
  "id_str" : "391952311435935744",
  "text" : "\u00ABDein Gesichtsausdruck war kurz angeekelt! Das habe ich noch nie gesehen!\u00BB",
  "id" : 391952311435935744,
  "created_at" : "2013-10-20 15:41:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/85kGdKqKak",
      "expanded_url" : "http:\/\/reasoningwithvampires.tumblr.com\/",
      "display_url" : "reasoningwithvampires.tumblr.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10056523, 8.5709047293 ]
  },
  "id_str" : "391946259109793793",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng Reasoning with Vampires http:\/\/t.co\/85kGdKqKak",
  "id" : 391946259109793793,
  "created_at" : "2013-10-20 15:17:24 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/pjfweOLrzQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/fsU9raBwqd\/",
      "display_url" : "instagram.com\/p\/fsU9raBwqd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "391934430115545088",
  "text" : "Onobject http:\/\/t.co\/pjfweOLrzQ",
  "id" : 391934430115545088,
  "created_at" : "2013-10-20 14:30:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7wxz7G2P66",
      "expanded_url" : "http:\/\/critiquemydickpic.tumblr.com\/",
      "display_url" : "critiquemydickpic.tumblr.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1005392294, 8.5708754235 ]
  },
  "id_str" : "391928338077720576",
  "text" : "\u00ABHast du dein iPad? Ich muss Tina \u2018critique my dick pic\u2019 zeigen. Das ist auf dem kleinen Display nicht das gleiche!\u00BB http:\/\/t.co\/7wxz7G2P66",
  "id" : 391928338077720576,
  "created_at" : "2013-10-20 14:06:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/J7QQc32dR4",
      "expanded_url" : "http:\/\/instagram.com\/p\/fsR1bnhwlH\/",
      "display_url" : "instagram.com\/p\/fsR1bnhwlH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "391927486541729792",
  "text" : "Writing to reach you http:\/\/t.co\/J7QQc32dR4",
  "id" : 391927486541729792,
  "created_at" : "2013-10-20 14:02:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1013134839, 8.5748803988 ]
  },
  "id_str" : "391924974174633984",
  "text" : "\u00ABIhr macht mich ganz matschig im Hirn. Ihr seid wie Baum\u00E4rkte!\u00BB",
  "id" : 391924974174633984,
  "created_at" : "2013-10-20 13:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0962716753, 8.6028688669 ]
  },
  "id_str" : "391923679699173376",
  "text" : "\u00ABWir haben noch abwaschbare, aufblasbare Matratzen im Flur liegen. Wenn man die in die Abstellkammer schiebt haben wir einen DIY-Darkroom.\u00BB",
  "id" : 391923679699173376,
  "created_at" : "2013-10-20 13:47:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/2AUtQZryRg",
      "expanded_url" : "http:\/\/instagram.com\/p\/fsPGLvhwg_\/",
      "display_url" : "instagram.com\/p\/fsPGLvhwg_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "391921544295104512",
  "text" : "Bookcrossing gone horribly wrong. http:\/\/t.co\/2AUtQZryRg",
  "id" : 391921544295104512,
  "created_at" : "2013-10-20 13:39:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/d8WmFAGdWR",
      "expanded_url" : "http:\/\/instagram.com\/p\/fsN_5AhwvR\/",
      "display_url" : "instagram.com\/p\/fsN_5AhwvR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1274980367, 8.6896611828 ]
  },
  "id_str" : "391919598138040320",
  "text" : "\u00ABBring das Nudelwasser durch Handauflegen zum Kochen.\u00BB @ EXPLORA Museum+Wissenschaft+Technik http:\/\/t.co\/d8WmFAGdWR",
  "id" : 391919598138040320,
  "created_at" : "2013-10-20 13:31:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/riv8bXaWfb",
      "expanded_url" : "http:\/\/instagram.com\/p\/fsMqR-Bwtl\/",
      "display_url" : "instagram.com\/p\/fsMqR-Bwtl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "391916133684891648",
  "text" : "\u00ABEin Katzenpenis!\u00BB http:\/\/t.co\/riv8bXaWfb",
  "id" : 391916133684891648,
  "created_at" : "2013-10-20 13:17:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.113630999, 8.6788669761 ]
  },
  "id_str" : "391884773234581504",
  "text" : "\u00ABF\u00FCr das Refugeecamp haben wir uns in der Kirche aufw\u00E4rmen wollen &amp; daf\u00FCr Hausverbot bekommen. Aber der Bratwurst-Stand bekommt Strom?!\u00BB",
  "id" : 391884773234581504,
  "created_at" : "2013-10-20 11:13:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nbga",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.017344661, 8.4313511399 ]
  },
  "id_str" : "391874316339777536",
  "text" : "Having a great excuse: \u00ABIn effect, all animals are under stringent selection pressure to be as stupid as they can get away with.\u00BB #nbga",
  "id" : 391874316339777536,
  "created_at" : "2013-10-20 10:31:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/oeMeo9mt4v",
      "expanded_url" : "http:\/\/judgestarling.tumblr.com\/post\/64504735261\/the-origin-of-junk-dna-a-historical-whodunnit",
      "display_url" : "judgestarling.tumblr.com\/post\/645047352\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.003577, 8.368591 ]
  },
  "id_str" : "391871531309346816",
  "text" : "The Origin of Junk DNA: A Historical Whodunnit http:\/\/t.co\/oeMeo9mt4v",
  "id" : 391871531309346816,
  "created_at" : "2013-10-20 10:20:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter W.",
      "screen_name" : "herrwenz",
      "indices" : [ 4, 13 ],
      "id_str" : "728233778",
      "id" : 728233778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/PdRTrd2tA7",
      "expanded_url" : "http:\/\/instagram.com\/p\/fqxvafhwmG\/",
      "display_url" : "instagram.com\/p\/fqxvafhwmG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "391716287204065280",
  "text" : "F\u00FCr @herrwenz http:\/\/t.co\/PdRTrd2tA7",
  "id" : 391716287204065280,
  "created_at" : "2013-10-20 00:03:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Shafer",
      "screen_name" : "jackshafer",
      "indices" : [ 3, 14 ],
      "id_str" : "12245632",
      "id" : 12245632
    }, {
      "name" : "Evgeny Morozov",
      "screen_name" : "evgenymorozov",
      "indices" : [ 41, 55 ],
      "id_str" : "30331417",
      "id" : 30331417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391713086291578880",
  "text" : "RT @jackshafer: Is that a confession? RT @evgenymorozov: What is it about \"the Internet\" that makes smart people say dumb things?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evgeny Morozov",
        "screen_name" : "evgenymorozov",
        "indices" : [ 25, 39 ],
        "id_str" : "30331417",
        "id" : 30331417
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391709122506149888",
    "text" : "Is that a confession? RT @evgenymorozov: What is it about \"the Internet\" that makes smart people say dumb things?",
    "id" : 391709122506149888,
    "created_at" : "2013-10-19 23:35:07 +0000",
    "user" : {
      "name" : "Jack Shafer",
      "screen_name" : "jackshafer",
      "protected" : false,
      "id_str" : "12245632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/68221457\/JohnnyPress_normal.gif",
      "id" : 12245632,
      "verified" : true
    }
  },
  "id" : 391713086291578880,
  "created_at" : "2013-10-19 23:50:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/2HLmNAQrBh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=otFmtLe9NvM",
      "display_url" : "youtube.com\/watch?v=otFmtL\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965702, 8.283055044 ]
  },
  "id_str" : "391712257488719872",
  "text" : "\u00ABWell if you agree, then come hating with me and feel free to sing along\u00BB http:\/\/t.co\/2HLmNAQrBh",
  "id" : 391712257488719872,
  "created_at" : "2013-10-19 23:47:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391707047861186560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096671964, 8.2830531153 ]
  },
  "id_str" : "391708630162366464",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode but she drives me crazy!",
  "id" : 391708630162366464,
  "in_reply_to_status_id" : 391707047861186560,
  "created_at" : "2013-10-19 23:33:09 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391696919514595329",
  "text" : "\u00ABWenn du gleich wieder die Fine Young Cannibals anmachst wirst du zu Kopfh\u00F6rern verurteilt!\u00BB",
  "id" : 391696919514595329,
  "created_at" : "2013-10-19 22:46:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/4NZsibxuCK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=prcKkUs2y6o",
      "display_url" : "youtube.com\/watch?v=prcKkU\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968646, 8.28299397 ]
  },
  "id_str" : "391682598273298432",
  "text" : "\u00ABThese coffee orders, the Magna Carta is less complicated.\u00BB Having this in my head instantaneously http:\/\/t.co\/4NZsibxuCK",
  "id" : 391682598273298432,
  "created_at" : "2013-10-19 21:49:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0075110438, 8.2829058049 ]
  },
  "id_str" : "391652035332173824",
  "text" : "\u00ABAch, daf\u00FCr habe ich ja Outdoor-Hosen.\u00BB \u2014 \u00ABMeine Hosen sind alle Outdoor-Hosen. Denn Zuhause trage ich gar keine.\u00BB",
  "id" : 391652035332173824,
  "created_at" : "2013-10-19 19:48:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/U2nZfJwgIQ",
      "expanded_url" : "http:\/\/mindhacks.com\/2013\/10\/19\/seeing-synaesthetic-stars-during-sex\/",
      "display_url" : "mindhacks.com\/2013\/10\/19\/see\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009630896, 8.282961016 ]
  },
  "id_str" : "391597348427923456",
  "text" : "Seeing synaesthetic stars during\u00A0sex http:\/\/t.co\/U2nZfJwgIQ",
  "id" : 391597348427923456,
  "created_at" : "2013-10-19 16:10:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/FbYwSqkzq8",
      "expanded_url" : "http:\/\/instagram.com\/p\/fpxExYhwlo\/",
      "display_url" : "instagram.com\/p\/fpxExYhwlo\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9948293683, 8.2442092896 ]
  },
  "id_str" : "391574244431507456",
  "text" : "\u00ABGebt mir einen Punkt wo ich hintreten kann\u2026\u00BB @ Johannes Gutenberg-Universit\u00E4t Mainz http:\/\/t.co\/FbYwSqkzq8",
  "id" : 391574244431507456,
  "created_at" : "2013-10-19 14:39:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 86, 100 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/DgzaaKexq9",
      "expanded_url" : "http:\/\/thatsnothowyoupipette.tumblr.com\/",
      "display_url" : "thatsnothowyoupipette.tumblr.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0011096903, 8.2589425353 ]
  },
  "id_str" : "391568879312723970",
  "text" : "And this is why you have to repeat it during every lab practical for like 4 years: RT @genetics_blog: Ha. http:\/\/t.co\/DgzaaKexq9",
  "id" : 391568879312723970,
  "created_at" : "2013-10-19 14:17:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0011176209, 8.2589124583 ]
  },
  "id_str" : "391567254074458112",
  "text" : "\u00ABWie ist es bei euch?\u00BB \u2014 \u00ABAlles beim alten. Der Kaffee muss flie\u00DFen!\u00BB",
  "id" : 391567254074458112,
  "created_at" : "2013-10-19 14:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391509451519561728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009630896, 8.282961016 ]
  },
  "id_str" : "391558960815542272",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode \u2018inzwischen\u2019?!",
  "id" : 391558960815542272,
  "in_reply_to_status_id" : 391509451519561728,
  "created_at" : "2013-10-19 13:38:25 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9861879131, 8.1751450431 ]
  },
  "id_str" : "391508502684106754",
  "text" : "\u00ABKrass wie schnell die Zeit vergeht wenn man sich gegenseitig H\u00E4nde in K\u00F6rper\u00F6ffnungen schiebt!\u00BB",
  "id" : 391508502684106754,
  "created_at" : "2013-10-19 10:17:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 30, 38 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9861297001, 8.1751513155 ]
  },
  "id_str" : "391502381374275585",
  "text" : "\u00ABWas gibt es bei Twitter?\u00BB \u2014 \u00AB@moeffju hat gefickt.\u00BB \u2014 \u00ABAlso nichts neues?\u00BB",
  "id" : 391502381374275585,
  "created_at" : "2013-10-19 09:53:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9862298869, 8.1753149032 ]
  },
  "id_str" : "391343874133987328",
  "text" : "\u00ABAn was denkst du?\u00BB \u2014 \u00ABSex!\u00BB \u2014 \u00ABDas war aber ein kurzer Gedanke\u2026\u00BB",
  "id" : 391343874133987328,
  "created_at" : "2013-10-18 23:23:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/amiEC2rpYe",
      "expanded_url" : "http:\/\/static.funpic.hu\/_files\/pictures\/630\/43\/14\/1443.jpg",
      "display_url" : "static.funpic.hu\/_files\/picture\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1136815259, 8.6785703033 ]
  },
  "id_str" : "391242009627099136",
  "text" : "Ah, a monolithic calendar! http:\/\/t.co\/amiEC2rpYe",
  "id" : 391242009627099136,
  "created_at" : "2013-10-18 16:38:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391230064932954112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1714795689, 8.6247109808 ]
  },
  "id_str" : "391232694472167424",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara I bet they will be pretty depressed once they find out it's only micro-culling!",
  "id" : 391232694472167424,
  "in_reply_to_status_id" : 391230064932954112,
  "created_at" : "2013-10-18 16:01:57 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 3, 12 ],
      "id_str" : "19146944",
      "id" : 19146944
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 14, 30 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Defra UK",
      "screen_name" : "DefraGovUK",
      "indices" : [ 92, 103 ],
      "id_str" : "50069007",
      "id" : 50069007
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badger",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391232338161836032",
  "text" : "RT @BobOHara: @gedankenstuecke oh, not the #badger genome project. Which was only funded by @DefraGovUK because the proposal said shotgun s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Defra UK",
        "screen_name" : "DefraGovUK",
        "indices" : [ 78, 89 ],
        "id_str" : "50069007",
        "id" : 50069007
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "badger",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "391226927832244224",
    "geo" : { },
    "id_str" : "391230064932954112",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke oh, not the #badger genome project. Which was only funded by @DefraGovUK because the proposal said shotgun sequencing",
    "id" : 391230064932954112,
    "in_reply_to_status_id" : 391226927832244224,
    "created_at" : "2013-10-18 15:51:30 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "protected" : false,
      "id_str" : "19146944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624292977\/twitterProfilePhoto_normal.jpg",
      "id" : 19146944,
      "verified" : false
    }
  },
  "id" : 391232338161836032,
  "created_at" : "2013-10-18 16:00:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/kNxt7KWGIP",
      "expanded_url" : "https:\/\/github.com\/elswob\/Badger",
      "display_url" : "github.com\/elswob\/Badger"
    } ]
  },
  "geo" : { },
  "id_str" : "391226927832244224",
  "text" : "\u00ABBadger: Accessible genome exploration environment\u00BB \u2013 Comes \/w data of mushroom &amp; snake! (well at least it should\u2026) https:\/\/t.co\/kNxt7KWGIP",
  "id" : 391226927832244224,
  "created_at" : "2013-10-18 15:39:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391218972815032320",
  "geo" : { },
  "id_str" : "391220076369567744",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara even though it's unclear whether Haldane ever said it: \u00ABI would lay down my life for two genomes or eight transcriptomes\u00BB",
  "id" : 391220076369567744,
  "in_reply_to_status_id" : 391218972815032320,
  "created_at" : "2013-10-18 15:11:49 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391214901340803072",
  "text" : "\u00AB(1985-20xx), bioinformatician, crushed to death as he rescued the data when the compute nodes came tumbling down\u00BB One may dream, right?",
  "id" : 391214901340803072,
  "created_at" : "2013-10-18 14:51:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Qo0Vw8XKXg",
      "expanded_url" : "http:\/\/strangebehaviors.wordpress.com\/2011\/01\/14\/the-wall-of-the-dead\/",
      "display_url" : "strangebehaviors.wordpress.com\/2011\/01\/14\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391213072058028032",
  "text" : "\u00ABA Memorial to Fallen Naturalists\u00BB So many great ways to die while doing the things you love most! http:\/\/t.co\/Qo0Vw8XKXg",
  "id" : 391213072058028032,
  "created_at" : "2013-10-18 14:43:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/dTeZSdDq43",
      "expanded_url" : "http:\/\/nautil.us\/issue\/6\/secret-codes\/whats-the-sound-of-personhood",
      "display_url" : "nautil.us\/issue\/6\/secret\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391176962170822656",
  "text" : "What\u2019s the Sound of Personhood? http:\/\/t.co\/dTeZSdDq43",
  "id" : 391176962170822656,
  "created_at" : "2013-10-18 12:20:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/OnxfIAT2tM",
      "expanded_url" : "http:\/\/www.nytimes.com\/newsgraphics\/2013\/10\/13\/russia\/",
      "display_url" : "nytimes.com\/newsgraphics\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391161623131348992",
  "text" : "The Russia Left Behind http:\/\/t.co\/OnxfIAT2tM",
  "id" : 391161623131348992,
  "created_at" : "2013-10-18 11:19:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/zBxbmRD7lw",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2013\/10\/absurd-creature-goblin-shark\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391156911187324928",
  "text" : "Ich kenne Menschen die das beim Nudeln essen ganz \u00E4hnlich machen! http:\/\/t.co\/zBxbmRD7lw",
  "id" : 391156911187324928,
  "created_at" : "2013-10-18 11:00:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 0, 8 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391143640518496256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722904717, 8.6276534863 ]
  },
  "id_str" : "391145071036608513",
  "in_reply_to_user_id" : 14857351,
  "text" : "@insideX ich bin so vision\u00E4r!",
  "id" : 391145071036608513,
  "in_reply_to_status_id" : 391143640518496256,
  "created_at" : "2013-10-18 10:13:46 +0000",
  "in_reply_to_screen_name" : "insideX",
  "in_reply_to_user_id_str" : "14857351",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/WtdV4fyhZ0",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/beards\/comments\/1opax3\/so_quick_question_about_making_outoral_sex_with_8\/",
      "display_url" : "reddit.com\/r\/beards\/comme\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723423875, 8.6275999081 ]
  },
  "id_str" : "391140782306263040",
  "text" : "\u00ABI eat my mustache regardless of what I eat. How does kissing work?\u00BB http:\/\/t.co\/WtdV4fyhZ0",
  "id" : 391140782306263040,
  "created_at" : "2013-10-18 09:56:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722779335, 8.6276642696 ]
  },
  "id_str" : "391129097260523520",
  "text" : "Once I've finished this figure I will at least finally have memorized the 3 &lt;-&gt; 1 letter amino acid codes\u2026",
  "id" : 391129097260523520,
  "created_at" : "2013-10-18 09:10:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QtghXY4l5E",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/10\/17\/photographer-shoots-portraits.html",
      "display_url" : "boingboing.net\/2013\/10\/17\/pho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391122475271995392",
  "text" : "Photographer shoots portraits of men who catcall her on the street http:\/\/t.co\/QtghXY4l5E",
  "id" : 391122475271995392,
  "created_at" : "2013-10-18 08:43:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391108300818767872",
  "text" : "\u00ABWas gibt es sch\u00F6neres als den Tag mit Inkscape anzufangen?\u00BB \u2013 \u00ABSuizid?\u00BB",
  "id" : 391108300818767872,
  "created_at" : "2013-10-18 07:47:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/PvtDDai1fo",
      "expanded_url" : "http:\/\/amzn.com\/k\/-55Ovu26Rw2Vubs-WPaiqA",
      "display_url" : "amzn.com\/k\/-55Ovu26Rw2V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391091299870597120",
  "text" : "\u00ABConsider one of the most bizarre traditions in the whole ethnographic record\u2026\u00BB http:\/\/t.co\/PvtDDai1fo Consider one of the most bizar...",
  "id" : 391091299870597120,
  "created_at" : "2013-10-18 06:40:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ice Cream Assasin",
      "screen_name" : "_Firebug_",
      "indices" : [ 0, 10 ],
      "id_str" : "15837895",
      "id" : 15837895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390985417694011392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0173838467, 8.4316490701 ]
  },
  "id_str" : "391086942756294656",
  "in_reply_to_user_id" : 15837895,
  "text" : "@_Firebug_ sehr gern :)",
  "id" : 391086942756294656,
  "in_reply_to_status_id" : 390985417694011392,
  "created_at" : "2013-10-18 06:22:47 +0000",
  "in_reply_to_screen_name" : "_Firebug_",
  "in_reply_to_user_id_str" : "15837895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan D\u00F6rrenhaus",
      "screen_name" : "JanDoerrenhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2199295838",
      "id" : 2199295838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390959484450783232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968696, 8.282994695 ]
  },
  "id_str" : "390959874462711808",
  "in_reply_to_user_id" : 49373312,
  "text" : "@JanDoerrenhaus erstmal ein paar VCs anschreiben: \u2018I have this startup idea, it\u2019s like Facebook for beards\u2019!",
  "id" : 390959874462711808,
  "in_reply_to_status_id" : 390959484450783232,
  "created_at" : "2013-10-17 21:57:52 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/csZ896t7I1",
      "expanded_url" : "http:\/\/imgur.com\/8LWcqzb",
      "display_url" : "imgur.com\/8LWcqzb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968696, 8.282994695 ]
  },
  "id_str" : "390958752113111040",
  "text" : "Achoo! http:\/\/t.co\/csZ896t7I1",
  "id" : 390958752113111040,
  "created_at" : "2013-10-17 21:53:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/oCSPx1wBef",
      "expanded_url" : "http:\/\/imgur.com\/su6NLn8",
      "display_url" : "imgur.com\/su6NLn8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968696, 8.282994695 ]
  },
  "id_str" : "390956432851746816",
  "text" : "Stalking http:\/\/t.co\/oCSPx1wBef",
  "id" : 390956432851746816,
  "created_at" : "2013-10-17 21:44:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390950547110375424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968696, 8.282994695 ]
  },
  "id_str" : "390950876128751616",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon \u00ABMr Nobody believe you were a ball that was a nuance!\u00BB",
  "id" : 390950876128751616,
  "in_reply_to_status_id" : 390950547110375424,
  "created_at" : "2013-10-17 21:22:07 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rH3ci2W2qE",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1310.3737",
      "display_url" : "arxiv.org\/abs\/1310.3737"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009659392, 8.283055142 ]
  },
  "id_str" : "390946971542110208",
  "text" : "\u00ABdiscover the \"Law of Urination\u201D [\u2026] animals empty their bladders over nearly constant duration of average 21 secs\u00BB http:\/\/t.co\/rH3ci2W2qE",
  "id" : 390946971542110208,
  "created_at" : "2013-10-17 21:06:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/jyA1iHoYLH",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2013\/10\/17\/find-and-replace-across-an-entire-genome\/",
      "display_url" : "phenomena.nationalgeographic.com\/2013\/10\/17\/fin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390937130891218944",
  "text" : "RT @edyong209: So, these guys are actually swapping out codons across entire genomes. o_O http:\/\/t.co\/jyA1iHoYLH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/jyA1iHoYLH",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2013\/10\/17\/find-and-replace-across-an-entire-genome\/",
        "display_url" : "phenomena.nationalgeographic.com\/2013\/10\/17\/fin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390936880742531072",
    "text" : "So, these guys are actually swapping out codons across entire genomes. o_O http:\/\/t.co\/jyA1iHoYLH",
    "id" : 390936880742531072,
    "created_at" : "2013-10-17 20:26:30 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 390937130891218944,
  "created_at" : "2013-10-17 20:27:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ice Cream Assasin",
      "screen_name" : "_Firebug_",
      "indices" : [ 0, 10 ],
      "id_str" : "15837895",
      "id" : 15837895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390898325655785472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009646614, 8.2829239279 ]
  },
  "id_str" : "390899764700930048",
  "in_reply_to_user_id" : 15837895,
  "text" : "@_Firebug_ ich sage nichts ohne ein Glas Wein in der Hand. ;)",
  "id" : 390899764700930048,
  "in_reply_to_status_id" : 390898325655785472,
  "created_at" : "2013-10-17 17:59:01 +0000",
  "in_reply_to_screen_name" : "_Firebug_",
  "in_reply_to_user_id_str" : "15837895",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096568024, 8.2829376392 ]
  },
  "id_str" : "390891297655246849",
  "text" : "\u00ABBald mal wieder Lust, mit mir Kultur zu geniessen?\u00BB\u2014\u00ABIst das genauso Code wie 'Kopf kraulen'?\u00BB\u2014\u00ABIch mein: Wildes rumh\u00FCpfen auf Matratzen!\u00BB",
  "id" : 390891297655246849,
  "created_at" : "2013-10-17 17:25:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390762111531364352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094964623, 8.2827364617 ]
  },
  "id_str" : "390890276354801664",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot you went from 'prematurely ending relationships' to 'prematurely ending the world'? Ever speak of being overly dramatic again!",
  "id" : 390890276354801664,
  "in_reply_to_status_id" : 390762111531364352,
  "created_at" : "2013-10-17 17:21:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.985594078, 8.407074075 ]
  },
  "id_str" : "390885337071120384",
  "text" : "\u00ABPaley's argument from Design would better support a polyth. pantheon than his solit. Creator; it takes many designers to make a watch.\u00BB",
  "id" : 390885337071120384,
  "created_at" : "2013-10-17 17:01:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390879215291486208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0798187564, 8.6391189779 ]
  },
  "id_str" : "390879971218292736",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon stell dein in Katzenurin getr\u00E4nktes FX-Board darunter und deklarier es als Wasserschaden?",
  "id" : 390879971218292736,
  "in_reply_to_status_id" : 390879215291486208,
  "created_at" : "2013-10-17 16:40:21 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1102669609, 8.6768675446 ]
  },
  "id_str" : "390879380035371008",
  "text" : "\u00ABHast du bei 'der B\u00F6se mit dem Bart' auch gleich an dich denken m\u00FCssen?\u00BB \u2014 \u00ABNat\u00FCrlich, ich betreu doch gerade wieder das Masterpraktikum.\u00BB",
  "id" : 390879380035371008,
  "created_at" : "2013-10-17 16:38:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 0, 9 ],
      "id_str" : "342250615",
      "id" : 342250615
    }, {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 10, 20 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 21, 34 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390870120626524162",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115954509, 8.6817595902 ]
  },
  "id_str" : "390876921082695680",
  "in_reply_to_user_id" : 342250615,
  "text" : "@rOpenSci @Jon_Slate @PhilippBayer great, thanks a lot! :)",
  "id" : 390876921082695680,
  "in_reply_to_status_id" : 390870120626524162,
  "created_at" : "2013-10-17 16:28:14 +0000",
  "in_reply_to_screen_name" : "rOpenSci",
  "in_reply_to_user_id_str" : "342250615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115954509, 8.6817595902 ]
  },
  "id_str" : "390876791776509952",
  "text" : "\u00ABZur Not k\u00F6nnen wir nach der Diss immer noch Lehrer werden, z.B. an Waldorfschulen, da braucht man keine P\u00E4dagogik.\u00BB\u2014\u00ABTanz die Doppelhelix!\u00BB",
  "id" : 390876791776509952,
  "created_at" : "2013-10-17 16:27:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390852224332476416",
  "text" : "\u00ABDiesmal habe ich aber wirklich schwer recherchiert bevor ich frage. Ich hab sogar auf der zweiten Seite von Google gelesen!\u00BB",
  "id" : 390852224332476416,
  "created_at" : "2013-10-17 14:50:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 0, 9 ],
      "id_str" : "342250615",
      "id" : 342250615
    }, {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 10, 20 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 21, 34 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/LJ3ABFOQyx",
      "expanded_url" : "http:\/\/opensnp.org\/users.json",
      "display_url" : "opensnp.org\/users.json"
    } ]
  },
  "in_reply_to_status_id_str" : "390848621203439616",
  "geo" : { },
  "id_str" : "390849155381219328",
  "in_reply_to_user_id" : 342250615,
  "text" : "@rOpenSci @Jon_Slate @PhilippBayer sure, that isn't a problem. You can easily get the file-links for those users: http:\/\/t.co\/LJ3ABFOQyx",
  "id" : 390849155381219328,
  "in_reply_to_status_id" : 390848621203439616,
  "created_at" : "2013-10-17 14:37:54 +0000",
  "in_reply_to_screen_name" : "rOpenSci",
  "in_reply_to_user_id_str" : "342250615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 0, 9 ],
      "id_str" : "342250615",
      "id" : 342250615
    }, {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 10, 20 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 21, 34 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390847912105619457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723236685, 8.6276309893 ]
  },
  "id_str" : "390848483345059840",
  "in_reply_to_user_id" : 342250615,
  "text" : "@rOpenSci @Jon_Slate @PhilippBayer please don't grab all SNPs for each user through our API.Our machine cries every time someone tries it :)",
  "id" : 390848483345059840,
  "in_reply_to_status_id" : 390847912105619457,
  "created_at" : "2013-10-17 14:35:14 +0000",
  "in_reply_to_screen_name" : "rOpenSci",
  "in_reply_to_user_id_str" : "342250615",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 25, 34 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/7EcZ0XVB5t",
      "expanded_url" : "http:\/\/opensnp.org\/dump_download",
      "display_url" : "opensnp.org\/dump_download"
    } ]
  },
  "in_reply_to_status_id_str" : "390800219337535488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722984218, 8.6276493545 ]
  },
  "id_str" : "390800538100850688",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate @PhilippBayer @rOpenSci there's also a complete dump. http:\/\/t.co\/7EcZ0XVB5t that includes a csv with all variations for all user",
  "id" : 390800538100850688,
  "in_reply_to_status_id" : 390800219337535488,
  "created_at" : "2013-10-17 11:24:43 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722909558, 8.627659119 ]
  },
  "id_str" : "390798765114011648",
  "text" : "\u00ABIgitt, du riechst ja nach Baby-Shampoo!\u00BB \u2014 \u00ABMir hat sie auch besser gefallen als sie noch nach Schlamm gerochen hat.\u00BB",
  "id" : 390798765114011648,
  "created_at" : "2013-10-17 11:17:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 25, 34 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/YYtn08xAxW",
      "expanded_url" : "https:\/\/opensnp.org\/phenotypes\/182",
      "display_url" : "opensnp.org\/phenotypes\/182"
    } ]
  },
  "in_reply_to_status_id_str" : "390790077858598912",
  "geo" : { },
  "id_str" : "390797050062700544",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate @PhilippBayer @rOpenSci e.g. https:\/\/t.co\/YYtn08xAxW (if you're logged in you should see all download links above description)",
  "id" : 390797050062700544,
  "in_reply_to_status_id" : 390790077858598912,
  "created_at" : "2013-10-17 11:10:52 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 25, 34 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390790077858598912",
  "geo" : { },
  "id_str" : "390796894332416001",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate @PhilippBayer @rOpenSci But you can get downloads of all genotyping-files for a given trait at a given phenotype from the site.",
  "id" : 390796894332416001,
  "in_reply_to_status_id" : 390790077858598912,
  "created_at" : "2013-10-17 11:10:14 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 25, 34 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390790077858598912",
  "geo" : { },
  "id_str" : "390796806537216000",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate @PhilippBayer @rOpenSci Nope, no R function for that because that would be too much data to hand out via API.",
  "id" : 390796806537216000,
  "in_reply_to_status_id" : 390790077858598912,
  "created_at" : "2013-10-17 11:09:53 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390758685812604928",
  "text" : "\u00ABWir k\u00F6nnten das Cluster durch MacPros ersetzen. Dann sieht der Serverraum wie ein Urnenfriedhof aus\u00BB \u2013 \u00AB'Hier sterben unsere Ambitionen'?\u00BB",
  "id" : 390758685812604928,
  "created_at" : "2013-10-17 08:38:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Kv6iog2DzP",
      "expanded_url" : "http:\/\/wp.me\/p3walV-7k",
      "display_url" : "wp.me\/p3walV-7k"
    } ]
  },
  "geo" : { },
  "id_str" : "390752983132422144",
  "text" : "RT @brembs: Not to be outdone, Nature Magazine rejects data, publishes opinion http:\/\/t.co\/Kv6iog2DzP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/Kv6iog2DzP",
        "expanded_url" : "http:\/\/wp.me\/p3walV-7k",
        "display_url" : "wp.me\/p3walV-7k"
      } ]
    },
    "geo" : { },
    "id_str" : "390745149006819330",
    "text" : "Not to be outdone, Nature Magazine rejects data, publishes opinion http:\/\/t.co\/Kv6iog2DzP",
    "id" : 390745149006819330,
    "created_at" : "2013-10-17 07:44:37 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 390752983132422144,
  "created_at" : "2013-10-17 08:15:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Highfield",
      "screen_name" : "RogerHighfield",
      "indices" : [ 3, 18 ],
      "id_str" : "46959037",
      "id" : 46959037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/jTy3NrMdyA",
      "expanded_url" : "http:\/\/www.newscientist.com\/article\/dn24414-chimp-calls-suggest-language-evolved-from-a-song.html#.Ul-EBBbU6Ls",
      "display_url" : "newscientist.com\/article\/dn2441\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390751930555072512",
  "text" : "RT @RogerHighfield: Stuffed python suggests language evolved from a song. No, really! http:\/\/t.co\/jTy3NrMdyA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/jTy3NrMdyA",
        "expanded_url" : "http:\/\/www.newscientist.com\/article\/dn24414-chimp-calls-suggest-language-evolved-from-a-song.html#.Ul-EBBbU6Ls",
        "display_url" : "newscientist.com\/article\/dn2441\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390726795386830849",
    "text" : "Stuffed python suggests language evolved from a song. No, really! http:\/\/t.co\/jTy3NrMdyA",
    "id" : 390726795386830849,
    "created_at" : "2013-10-17 06:31:42 +0000",
    "user" : {
      "name" : "Roger Highfield",
      "screen_name" : "RogerHighfield",
      "protected" : false,
      "id_str" : "46959037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/262576031\/highfield_20for_20web_normal.jpg",
      "id" : 46959037,
      "verified" : false
    }
  },
  "id" : 390751930555072512,
  "created_at" : "2013-10-17 08:11:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/5KMxGVJf5y",
      "expanded_url" : "http:\/\/exurbe.com\/?p=2392",
      "display_url" : "exurbe.com\/?p=2392"
    } ]
  },
  "geo" : { },
  "id_str" : "390751178515951616",
  "text" : "the more you know: \u00ABHow to Spot Good Gelato from 15 Feet Away\u00BB http:\/\/t.co\/5KMxGVJf5y",
  "id" : 390751178515951616,
  "created_at" : "2013-10-17 08:08:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096550295, 8.2830653765 ]
  },
  "id_str" : "390604905255542784",
  "text" : "\u00ABMeinst du der Weltraumaufzug f\u00E4llt auch unter Netzpolitik? Ich mein: Das Ding hat auch ein Kabel.\u00BB",
  "id" : 390604905255542784,
  "created_at" : "2013-10-16 22:27:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/akNNqoQdkw",
      "expanded_url" : "http:\/\/inurashii.tumblr.com\/post\/64212310957\/how-to-not-ruin-polyamory-for-everybody-in-6-easy-steps",
      "display_url" : "inurashii.tumblr.com\/post\/642123109\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.010764, 8.283127 ]
  },
  "id_str" : "390593408072679424",
  "text" : "\u00ABwe are not approaching the polylarity to become a glorious single global-spanning relationship structure\u00BB http:\/\/t.co\/akNNqoQdkw",
  "id" : 390593408072679424,
  "created_at" : "2013-10-16 21:41:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klaus Graf",
      "screen_name" : "Archivalia_kg",
      "indices" : [ 3, 17 ],
      "id_str" : "22986608",
      "id" : 22986608
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "histmonast",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ZMTTiB2tG3",
      "expanded_url" : "http:\/\/www.xefer.com\/2013\/03\/phallus-tree",
      "display_url" : "xefer.com\/2013\/03\/phallu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390553557004713984",
  "text" : "RT @Archivalia_kg: #histmonast \u00A0 (The Phallus Tree of fr. 25526) http:\/\/t.co\/ZMTTiB2tG3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "histmonast",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/ZMTTiB2tG3",
        "expanded_url" : "http:\/\/www.xefer.com\/2013\/03\/phallus-tree",
        "display_url" : "xefer.com\/2013\/03\/phallu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390553250056790016",
    "text" : "#histmonast \u00A0 (The Phallus Tree of fr. 25526) http:\/\/t.co\/ZMTTiB2tG3",
    "id" : 390553250056790016,
    "created_at" : "2013-10-16 19:02:05 +0000",
    "user" : {
      "name" : "Klaus Graf",
      "screen_name" : "Archivalia_kg",
      "protected" : false,
      "id_str" : "22986608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/264793807\/Archivalia_green_normal.jpg",
      "id" : 22986608,
      "verified" : false
    }
  },
  "id" : 390553557004713984,
  "created_at" : "2013-10-16 19:03:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390529228304707584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875451, 8.283074103 ]
  },
  "id_str" : "390551306131476480",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot story of your life.",
  "id" : 390551306131476480,
  "in_reply_to_status_id" : 390529228304707584,
  "created_at" : "2013-10-16 18:54:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096731314, 8.282985618 ]
  },
  "id_str" : "390540730634346496",
  "text" : "\u00ABWieso l\u00E4ufst du nicht beim Marathon mit?\u00BB \u2014 \u00ABIch habe schon gelernt, was du n\u00E4chste Woche unter Schmerzen lernen wirst: Nein sagen.\u00BB",
  "id" : 390540730634346496,
  "created_at" : "2013-10-16 18:12:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009693658, 8.2830314096 ]
  },
  "id_str" : "390528280857948160",
  "text" : "\u00ABIch mache eine Woche Sportpause wenn ich zu viel Gewicht verliere.\u00BB\u2014\u00ABInteressantes Konzept. Ich beweg mich weiter &amp; stopf mehr Eis in mich\u00BB",
  "id" : 390528280857948160,
  "created_at" : "2013-10-16 17:22:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/rLxb6nK6QH",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S0304395913000778",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390488898691809281",
  "text" : "\u00ABthe vibration of male beard hairs did not evoke itch but only a tickling sensation in the present study\u00BB http:\/\/t.co\/rLxb6nK6QH",
  "id" : 390488898691809281,
  "created_at" : "2013-10-16 14:46:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/QRTvobBQ4Y",
      "expanded_url" : "http:\/\/biologicalexceptions.blogspot.de\/2013\/10\/post-of-living-dead.html",
      "display_url" : "biologicalexceptions.blogspot.de\/2013\/10\/post-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390485521496948736",
  "text" : "\u00ABa new study shows that rabies can incubate for decades before symptoms manifest.\u00BB http:\/\/t.co\/QRTvobBQ4Y",
  "id" : 390485521496948736,
  "created_at" : "2013-10-16 14:32:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/jbE2DdQyKA",
      "expanded_url" : "http:\/\/i.imgur.com\/Oa80ivv.gif",
      "display_url" : "i.imgur.com\/Oa80ivv.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724279812, 8.6274633464 ]
  },
  "id_str" : "390481895697702912",
  "text" : "How our workstations behave like thanks to the load on openVPN. http:\/\/t.co\/jbE2DdQyKA",
  "id" : 390481895697702912,
  "created_at" : "2013-10-16 14:18:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/sr13R7vThj",
      "expanded_url" : "http:\/\/bps-research-digest.blogspot.de\/2013\/10\/what-makes-internet-video-go-viral.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+BpsResearchDigest+%28BPS+Research+Digest%29",
      "display_url" : "bps-research-digest.blogspot.de\/2013\/10\/what-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390432600222732288",
  "text" : "What makes an internet video go viral? http:\/\/t.co\/sr13R7vThj",
  "id" : 390432600222732288,
  "created_at" : "2013-10-16 11:02:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723139883, 8.6276349474 ]
  },
  "id_str" : "390401703289569280",
  "text" : "\u00ABBrauchst du Hilfe beim Umzug?\u00BB \u2014 \u00ABDas geht schon, ich hab nur 2 Koffer.\u00BB \u2014 \u00ABDie besten Umz\u00FCge: Einen Koffer tragen und dann Bier trinken!\u00BB",
  "id" : 390401703289569280,
  "created_at" : "2013-10-16 08:59:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ulrich Greveler",
      "screen_name" : "greveler",
      "indices" : [ 13, 22 ],
      "id_str" : "38829076",
      "id" : 38829076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BUDGU4ugnm",
      "expanded_url" : "http:\/\/ics-cert.us-cert.gov\/alerts\/ICS-ALERT-13-164-01",
      "display_url" : "ics-cert.us-cert.gov\/alerts\/ICS-ALE\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722918422, 8.6276560117 ]
  },
  "id_str" : "390394539162468352",
  "text" : "Shocking! MT @greveler: medizin. Ger\u00E4te mit hartcodierten Passw\u00F6rtern. Firmwaremanipulation m\u00F6glich. Defis betroffen. http:\/\/t.co\/BUDGU4ugnm",
  "id" : 390394539162468352,
  "created_at" : "2013-10-16 08:31:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723189795, 8.6276357062 ]
  },
  "id_str" : "390394077898108928",
  "text" : "\u00ABIch lieg ja gern mit euch zusammen im Bett.\u00BB \u2014 \u00ABVier F\u00E4uste f\u00FCr ein Halleluja!\u00BB",
  "id" : 390394077898108928,
  "created_at" : "2013-10-16 08:29:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YES TO ALL",
      "screen_name" : "philodem",
      "indices" : [ 0, 9 ],
      "id_str" : "18237661",
      "id" : 18237661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390389012315140096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172444578, 8.6274096862 ]
  },
  "id_str" : "390389318684278784",
  "in_reply_to_user_id" : 18237661,
  "text" : "@philodem ah, danke. Die Referenz war mir nicht klar. :)",
  "id" : 390389318684278784,
  "in_reply_to_status_id" : 390389012315140096,
  "created_at" : "2013-10-16 08:10:41 +0000",
  "in_reply_to_screen_name" : "philodem",
  "in_reply_to_user_id_str" : "18237661",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YES TO ALL",
      "screen_name" : "philodem",
      "indices" : [ 0, 9 ],
      "id_str" : "18237661",
      "id" : 18237661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390388599000014848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723793325, 8.6274962007 ]
  },
  "id_str" : "390388708358508544",
  "in_reply_to_user_id" : 18237661,
  "text" : "@philodem ja, ich verstehe nur 'Topsider' nicht.",
  "id" : 390388708358508544,
  "in_reply_to_status_id" : 390388599000014848,
  "created_at" : "2013-10-16 08:08:15 +0000",
  "in_reply_to_screen_name" : "philodem",
  "in_reply_to_user_id_str" : "18237661",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YES TO ALL",
      "screen_name" : "philodem",
      "indices" : [ 0, 9 ],
      "id_str" : "18237661",
      "id" : 18237661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390386751627603968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723878174, 8.627492969 ]
  },
  "id_str" : "390388482600108032",
  "in_reply_to_user_id" : 18237661,
  "text" : "@philodem I don't get it.",
  "id" : 390388482600108032,
  "in_reply_to_status_id" : 390386751627603968,
  "created_at" : "2013-10-16 08:07:21 +0000",
  "in_reply_to_screen_name" : "philodem",
  "in_reply_to_user_id_str" : "18237661",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "indices" : [ 3, 14 ],
      "id_str" : "14729597",
      "id" : 14729597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/22gaF8AFvH",
      "expanded_url" : "http:\/\/bit.ly\/19G1MJQ",
      "display_url" : "bit.ly\/19G1MJQ"
    } ]
  },
  "geo" : { },
  "id_str" : "390258202421755904",
  "text" : "RT @KateClancy: All of this. \"Let me fix that for you\" http:\/\/t.co\/22gaF8AFvH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/22gaF8AFvH",
        "expanded_url" : "http:\/\/bit.ly\/19G1MJQ",
        "display_url" : "bit.ly\/19G1MJQ"
      } ]
    },
    "geo" : { },
    "id_str" : "390247518535024640",
    "text" : "All of this. \"Let me fix that for you\" http:\/\/t.co\/22gaF8AFvH",
    "id" : 390247518535024640,
    "created_at" : "2013-10-15 22:47:13 +0000",
    "user" : {
      "name" : "Kate Clancy",
      "screen_name" : "KateClancy",
      "protected" : false,
      "id_str" : "14729597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/827538287191527424\/BClQOCKV_normal.jpg",
      "id" : 14729597,
      "verified" : false
    }
  },
  "id" : 390258202421755904,
  "created_at" : "2013-10-15 23:29:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096278324, 8.2829600219 ]
  },
  "id_str" : "390257150955909120",
  "text" : "\u00ABDu siehst wieder so aus als h\u00E4ttest du Bei\u00DFoeira zusammen mit Mike Tyson trainiert.\u00BB",
  "id" : 390257150955909120,
  "created_at" : "2013-10-15 23:25:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/NuyUKKwDTg",
      "expanded_url" : "http:\/\/i.imgur.com\/gHdvcJN.gif",
      "display_url" : "i.imgur.com\/gHdvcJN.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009659392, 8.283055142 ]
  },
  "id_str" : "390233212762750976",
  "text" : "barking up the wrong Huey http:\/\/t.co\/NuyUKKwDTg",
  "id" : 390233212762750976,
  "created_at" : "2013-10-15 21:50:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Schreiber",
      "screen_name" : "Fabschreiber",
      "indices" : [ 3, 16 ],
      "id_str" : "21987362",
      "id" : 21987362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/w3qXfeWht0",
      "expanded_url" : "http:\/\/zite.to\/168sgXr",
      "display_url" : "zite.to\/168sgXr"
    } ]
  },
  "geo" : { },
  "id_str" : "390224689819553792",
  "text" : "RT @Fabschreiber: This is so cool: Announcing the \"Voyage of the Beagle\" trading card game. http:\/\/t.co\/w3qXfeWht0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/w3qXfeWht0",
        "expanded_url" : "http:\/\/zite.to\/168sgXr",
        "display_url" : "zite.to\/168sgXr"
      } ]
    },
    "geo" : { },
    "id_str" : "390224056483454976",
    "text" : "This is so cool: Announcing the \"Voyage of the Beagle\" trading card game. http:\/\/t.co\/w3qXfeWht0",
    "id" : 390224056483454976,
    "created_at" : "2013-10-15 21:13:59 +0000",
    "user" : {
      "name" : "Fabian Schreiber",
      "screen_name" : "Fabschreiber",
      "protected" : false,
      "id_str" : "21987362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510892454531182592\/4uw7E_9e_normal.png",
      "id" : 21987362,
      "verified" : false
    }
  },
  "id" : 390224689819553792,
  "created_at" : "2013-10-15 21:16:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00963236, 8.282952164 ]
  },
  "id_str" : "390224185307709440",
  "text" : "\u00ABSo wie du mir die Worte im Mund rumdrehst solltest du Spin-Doctor werden.\u00BB \u2014 \u00ABDanke, aber ich mach lieber erstmal einen echten.\u00BB",
  "id" : 390224185307709440,
  "created_at" : "2013-10-15 21:14:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097065302, 8.2831854623 ]
  },
  "id_str" : "390212215170953216",
  "text" : "\u00ABIhr Echsenwesen aus der PR mit eurer Mindcontrol!\u00BB \u2014 \u00ABWir machen auch Chemtrails, aus meinem Arsch!\u00BB",
  "id" : 390212215170953216,
  "created_at" : "2013-10-15 20:26:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095871826, 8.2828847685 ]
  },
  "id_str" : "390188332950753281",
  "text" : "\u00ABWir kochen gerade Nudeln. Willst du auch welche wenn du nach Hause kommst?\u00BB \u2014 \u00ABKackt der Papst im Wald?\u00BB",
  "id" : 390188332950753281,
  "created_at" : "2013-10-15 18:52:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390181262725349376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096556484, 8.2830365435 ]
  },
  "id_str" : "390181755355164672",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng eine ganze Wohnung!",
  "id" : 390181755355164672,
  "in_reply_to_status_id" : 390181262725349376,
  "created_at" : "2013-10-15 18:25:54 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096031484, 8.2829632639 ]
  },
  "id_str" : "390179833743179776",
  "text" : "\u00ABVielleicht verstehen wir uns jetzt ja wieder besser. Wo du mir den Bart gestutzt hast und die RL-Emoticons auch wieder funktionieren!\u00BB",
  "id" : 390179833743179776,
  "created_at" : "2013-10-15 18:18:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/6UPgo4GlEy",
      "expanded_url" : "http:\/\/liartownusa.tumblr.com\/post\/63546416528\/ann-coulters-handy-guide-to-competitive-speed",
      "display_url" : "liartownusa.tumblr.com\/post\/635464165\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00957849, 8.2828791971 ]
  },
  "id_str" : "390127700960354304",
  "text" : "Ann Coulter\u2019s Handy Guide to Competitive Speed Fisting http:\/\/t.co\/6UPgo4GlEy",
  "id" : 390127700960354304,
  "created_at" : "2013-10-15 14:51:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/UpNn1S9eFH",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3145",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00957849, 8.2828791971 ]
  },
  "id_str" : "390123733060702208",
  "text" : "Before we agree to a second date\u2026 http:\/\/t.co\/UpNn1S9eFH",
  "id" : 390123733060702208,
  "created_at" : "2013-10-15 14:35:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/R40a0SlpXH",
      "expanded_url" : "http:\/\/nymag.com\/daily\/intelligencer\/2013\/10\/how-the-media-would-have-covered-columbus.html",
      "display_url" : "nymag.com\/daily\/intellig\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00957849, 8.2828791971 ]
  },
  "id_str" : "390103160196718593",
  "text" : "How the Media Would Have Covered Columbus\u2019s Discovery of the New World http:\/\/t.co\/R40a0SlpXH",
  "id" : 390103160196718593,
  "created_at" : "2013-10-15 13:13:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daphne Eviatar",
      "screen_name" : "deviatar",
      "indices" : [ 3, 12 ],
      "id_str" : "19168381",
      "id" : 19168381
    }, {
      "name" : "trutherbot",
      "screen_name" : "trutherbot",
      "indices" : [ 66, 77 ],
      "id_str" : "477583514",
      "id" : 477583514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/5yvrEvo2KY",
      "expanded_url" : "https:\/\/twitter.com\/trutherbot\/status\/387725364354498560\/photo\/1",
      "display_url" : "pic.twitter.com\/5yvrEvo2KY"
    } ]
  },
  "geo" : { },
  "id_str" : "390097771086479360",
  "text" : "RT @deviatar: An underreported impact of the NSA spying program RT@trutherbot: http:\/\/t.co\/5yvrEvo2KY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "trutherbot",
        "screen_name" : "trutherbot",
        "indices" : [ 52, 63 ],
        "id_str" : "477583514",
        "id" : 477583514
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/5yvrEvo2KY",
        "expanded_url" : "https:\/\/twitter.com\/trutherbot\/status\/387725364354498560\/photo\/1",
        "display_url" : "pic.twitter.com\/5yvrEvo2KY"
      } ]
    },
    "geo" : { },
    "id_str" : "390095020994605056",
    "text" : "An underreported impact of the NSA spying program RT@trutherbot: http:\/\/t.co\/5yvrEvo2KY",
    "id" : 390095020994605056,
    "created_at" : "2013-10-15 12:41:15 +0000",
    "user" : {
      "name" : "Daphne Eviatar",
      "screen_name" : "deviatar",
      "protected" : false,
      "id_str" : "19168381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/335460256\/daphcap_normal.jpg",
      "id" : 19168381,
      "verified" : false
    }
  },
  "id" : 390097771086479360,
  "created_at" : "2013-10-15 12:52:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00957849, 8.2828791971 ]
  },
  "id_str" : "390091630323466240",
  "text" : "\u00ABTreat your motif right.\u00BB \u2013 Mr. tRNA",
  "id" : 390091630323466240,
  "created_at" : "2013-10-15 12:27:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "390047464658849792",
  "geo" : { },
  "id_str" : "390049371716210688",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock Looking forward to it! And your language skills should totally take care of you when you visit Germany. ;)",
  "id" : 390049371716210688,
  "in_reply_to_status_id" : 390047464658849792,
  "created_at" : "2013-10-15 09:39:51 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 97, 105 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/KYnYdEIwta",
      "expanded_url" : "http:\/\/www2.warwick.ac.uk\/fac\/sci\/moac\/people\/students\/peter_cock\/python\/genbank\/",
      "display_url" : "www2.warwick.ac.uk\/fac\/sci\/moac\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390039373334323200",
  "text" : "Never tried it before, but the GB features of BioPython are awesome. One day I'll have to invite @pjacock for a beer! http:\/\/t.co\/KYnYdEIwta",
  "id" : 390039373334323200,
  "created_at" : "2013-10-15 09:00:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390026547060412416",
  "text" : "Den Kaffee-getr\u00E4nkten Bart sch\u00FCtteln erzeugt spannende Muster auf dem Schreibtisch\u2026",
  "id" : 390026547060412416,
  "created_at" : "2013-10-15 08:09:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nmsTKKN7N3",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2013\/10\/how-to-read-a-research-paper-about-that-scientist-with-a-nematode-in-his-mouth\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "390013893562494976",
  "text" : "\u00AB\u201Cthis is really interesting,\u201D thought Allen. And then 1) I hope it\u2019s not fatal and 2) I hope it\u2019s publishable\u00BB Awww! http:\/\/t.co\/nmsTKKN7N3",
  "id" : 390013893562494976,
  "created_at" : "2013-10-15 07:18:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/2iTpVApylz",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/fWxQfhOLVZs\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.016343, 8.429685 ]
  },
  "id_str" : "389995573975461888",
  "text" : "Homlessness and technological literacy: the Tenderloin Technology\u00A0Lab http:\/\/t.co\/2iTpVApylz",
  "id" : 389995573975461888,
  "created_at" : "2013-10-15 06:06:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "indices" : [ 3, 16 ],
      "id_str" : "49413866",
      "id" : 49413866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "python",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "ipython",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "rstats",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/RVBR0orvVz",
      "expanded_url" : "https:\/\/github.com\/yhat\/ggplot\/",
      "display_url" : "github.com\/yhat\/ggplot\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389990166905233408",
  "text" : "RT @randal_olson: R's popular plotting system Ggplot2 ported to #python: https:\/\/t.co\/RVBR0orvVz\n\n#ipython #rstats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "python",
        "indices" : [ 46, 53 ]
      }, {
        "text" : "ipython",
        "indices" : [ 80, 88 ]
      }, {
        "text" : "rstats",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/RVBR0orvVz",
        "expanded_url" : "https:\/\/github.com\/yhat\/ggplot\/",
        "display_url" : "github.com\/yhat\/ggplot\/"
      } ]
    },
    "geo" : { },
    "id_str" : "389825977779384320",
    "text" : "R's popular plotting system Ggplot2 ported to #python: https:\/\/t.co\/RVBR0orvVz\n\n#ipython #rstats",
    "id" : 389825977779384320,
    "created_at" : "2013-10-14 18:52:10 +0000",
    "user" : {
      "name" : "Randy Olson",
      "screen_name" : "randal_olson",
      "protected" : false,
      "id_str" : "49413866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770816518988959744\/Ma530Li__normal.jpg",
      "id" : 49413866,
      "verified" : false
    }
  },
  "id" : 389990166905233408,
  "created_at" : "2013-10-15 05:44:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097952132, 8.2832169067 ]
  },
  "id_str" : "389894332393988096",
  "text" : "\u00ABWie gut, dass wir dank DIYBio wissen, dass 9V Blockbatterien intern 6 AAAAs sind. Close enough und wir m\u00FCssen nicht den ADAC rufen!\u00BB",
  "id" : 389894332393988096,
  "created_at" : "2013-10-14 23:23:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009686805, 8.282993875 ]
  },
  "id_str" : "389878595570892801",
  "text" : "Nice idea of BMC Evolutionary Biology: Linking GenBank-IDs in PDFs directly to NCBI. Too bad: They link to PubMed for some reason\u2026",
  "id" : 389878595570892801,
  "created_at" : "2013-10-14 22:21:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Queer Has No Name",
      "screen_name" : "memeticsexgod",
      "indices" : [ 0, 14 ],
      "id_str" : "1451060280",
      "id" : 1451060280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389855038082150401",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1202157784, 8.6506698108 ]
  },
  "id_str" : "389855387031441408",
  "in_reply_to_user_id" : 1451060280,
  "text" : "@memeticsexgod das ist was es herauszufinden gilt!",
  "id" : 389855387031441408,
  "in_reply_to_status_id" : 389855038082150401,
  "created_at" : "2013-10-14 20:49:02 +0000",
  "in_reply_to_screen_name" : "memeticsexgod",
  "in_reply_to_user_id_str" : "1451060280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1202339004, 8.6505546638 ]
  },
  "id_str" : "389851537847386112",
  "text" : "\u00ABDu solltest das mit dem ADAC rufen mal probieren: \"Ich bin hier irgendwie liegengeblieben und br\u00E4uchte mal dringend 2 AA-Batterien!\"\u00BB",
  "id" : 389851537847386112,
  "created_at" : "2013-10-14 20:33:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389851444117270529",
  "text" : "RT @Senficon: \u201EIch nehme nicht am motorisierten Verkehr teil, also bin ich auch nicht im ADAC.\u201C \u201EAber du hast doch st\u00E4ndig motorisierten Ve\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389850815386898432",
    "text" : "\u201EIch nehme nicht am motorisierten Verkehr teil, also bin ich auch nicht im ADAC.\u201C \u201EAber du hast doch st\u00E4ndig motorisierten Verkehr!\u201C",
    "id" : 389850815386898432,
    "created_at" : "2013-10-14 20:30:52 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 389851444117270529,
  "created_at" : "2013-10-14 20:33:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1201145538, 8.6506683938 ]
  },
  "id_str" : "389847293937340416",
  "text" : "\u00ABIch muss mir ja immer anh\u00F6ren wie er Alterswitze \u00FCber seine andere Freundin macht.\u00BB \u2014 \u00ABNever gets old. Oh, too late\u2026\u00BB",
  "id" : 389847293937340416,
  "created_at" : "2013-10-14 20:16:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.120195097, 8.6505848044 ]
  },
  "id_str" : "389840335113048064",
  "text" : "\u00ABAlso die Arbeit bei den Piraten hat mich schon politisiert. Halt nur nicht f\u00FCr die Piratenpartei.\u00BB",
  "id" : 389840335113048064,
  "created_at" : "2013-10-14 19:49:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dedalus Root",
      "screen_name" : "DedalusRoot",
      "indices" : [ 0, 12 ],
      "id_str" : "112733212",
      "id" : 112733212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389838345502982145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1202293399, 8.6506619587 ]
  },
  "id_str" : "389840023136526336",
  "in_reply_to_user_id" : 112733212,
  "text" : "@DedalusRoot und auf einmal f\u00FChlt man sich so Vanilla!",
  "id" : 389840023136526336,
  "in_reply_to_status_id" : 389838345502982145,
  "created_at" : "2013-10-14 19:47:59 +0000",
  "in_reply_to_screen_name" : "DedalusRoot",
  "in_reply_to_user_id_str" : "112733212",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 3, 16 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/EfrqIV8NvE",
      "expanded_url" : "http:\/\/pigeonsandplanes.com\/2013\/10\/sufjan-stevens-letter-to-miley\/",
      "display_url" : "pigeonsandplanes.com\/2013\/10\/sufjan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389838213931876352",
  "text" : "RT @Unsichtbarer: Sufjan Stevens' open letter to Miley Cyrus: http:\/\/t.co\/EfrqIV8NvE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/EfrqIV8NvE",
        "expanded_url" : "http:\/\/pigeonsandplanes.com\/2013\/10\/sufjan-stevens-letter-to-miley\/",
        "display_url" : "pigeonsandplanes.com\/2013\/10\/sufjan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "389837094199492608",
    "text" : "Sufjan Stevens' open letter to Miley Cyrus: http:\/\/t.co\/EfrqIV8NvE",
    "id" : 389837094199492608,
    "created_at" : "2013-10-14 19:36:20 +0000",
    "user" : {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "protected" : false,
      "id_str" : "53639020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888018080533798912\/tLyWNYBf_normal.jpg",
      "id" : 53639020,
      "verified" : false
    }
  },
  "id" : 389838213931876352,
  "created_at" : "2013-10-14 19:40:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/nC14tmuCtf",
      "expanded_url" : "http:\/\/instagram.com\/p\/fdai_uhwil\/",
      "display_url" : "instagram.com\/p\/fdai_uhwil\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389835952275083264",
  "text" : "Mimesis http:\/\/t.co\/nC14tmuCtf",
  "id" : 389835952275083264,
  "created_at" : "2013-10-14 19:31:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/JUHmegkohM",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3144",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1201331197, 8.6506473553 ]
  },
  "id_str" : "389831459332444160",
  "text" : "I can explain! http:\/\/t.co\/JUHmegkohM",
  "id" : 389831459332444160,
  "created_at" : "2013-10-14 19:13:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/eXrWJaeEQP",
      "expanded_url" : "http:\/\/www.thelocal.de\/sci-tech\/20131014-52385.html",
      "display_url" : "thelocal.de\/sci-tech\/20131\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.120011, 8.650532 ]
  },
  "id_str" : "389822844135550976",
  "text" : "\u00ABin Germany, not a single byte leaves the country\u00BB Yeah, let's build a wall, it worked so well in the past\u2026 http:\/\/t.co\/eXrWJaeEQP",
  "id" : 389822844135550976,
  "created_at" : "2013-10-14 18:39:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1143964181, 8.6756579216 ]
  },
  "id_str" : "389813499440136193",
  "text" : "\u00ABJaja, ich wei\u00DF: \"Don't drink and derive'. Ich bin \u00FCbrigens mit dem Wagen hier. Soll ich dich irgendwo hinfahren?\u00BB",
  "id" : 389813499440136193,
  "created_at" : "2013-10-14 18:02:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389810173763543040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1137409932, 8.6786256246 ]
  },
  "id_str" : "389811665010962432",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich wei\u00DF, dein so offensichtliches Grundnahrungsmittel.",
  "id" : 389811665010962432,
  "in_reply_to_status_id" : 389810173763543040,
  "created_at" : "2013-10-14 17:55:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389808701042724864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1138577746, 8.6788931239 ]
  },
  "id_str" : "389809801016127488",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich dachte du l\u00E4sst wachsen damit du deinen Schnurrbart nach oben zwiebeln kannst und auch mal gl\u00FCcklich aussiehst?",
  "id" : 389809801016127488,
  "in_reply_to_status_id" : 389808701042724864,
  "created_at" : "2013-10-14 17:47:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389808145586872320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1199472164, 8.6776224309 ]
  },
  "id_str" : "389808473980301313",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot SEO &lt; PR &lt; Menschenhandel ist die international anerkannte Reihenfolge.",
  "id" : 389808473980301313,
  "in_reply_to_status_id" : 389808145586872320,
  "created_at" : "2013-10-14 17:42:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389807824487731200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1366053083, 8.6712965498 ]
  },
  "id_str" : "389808004813828096",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot einmal PR, immer PR, eh?",
  "id" : 389808004813828096,
  "in_reply_to_status_id" : 389807824487731200,
  "created_at" : "2013-10-14 17:40:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389805132646338560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1542389321, 8.6596190092 ]
  },
  "id_str" : "389805992965574656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u00ABIch w\u00FCrde ja sagen du kannst alles was keine h\u00F6heren Hirnfunktionen erfordert. Aber du versagst ja schon beim essen.\u00BB \u2014 Anonym",
  "id" : 389805992965574656,
  "in_reply_to_status_id" : 389805132646338560,
  "created_at" : "2013-10-14 17:32:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1693665055, 8.6223999431 ]
  },
  "id_str" : "389804687056449536",
  "text" : "\u00ABAlkohol und Statistik vertragen sich nicht. Versuch mal nach ein paar Bier Kolmogorov\u2013Smirnov-Test zu sagen.\u00BB",
  "id" : 389804687056449536,
  "created_at" : "2013-10-14 17:27:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389803037105340416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1653899768, 8.641541924 ]
  },
  "id_str" : "389804455669293056",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ach, Age-Shaming wird wieder okay wenn es in geologischer Zeit passiert?",
  "id" : 389804455669293056,
  "in_reply_to_status_id" : 389803037105340416,
  "created_at" : "2013-10-14 17:26:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1713444968, 8.6244767573 ]
  },
  "id_str" : "389802359809130497",
  "text" : "\u00ABDas haben wir gerne. Erst betrunken machen und dann ROC-Kurven diskutieren wollen!\u00BB",
  "id" : 389802359809130497,
  "created_at" : "2013-10-14 17:18:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724620536, 8.6276105326 ]
  },
  "id_str" : "389764952950849536",
  "text" : "\u00ABOh, wie sch\u00F6n ist VPNama.\u00BB",
  "id" : 389764952950849536,
  "created_at" : "2013-10-14 14:49:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389759981655842816",
  "text" : "Is there a tool that can visualize translocations between (mt)-genomes when given GFF-files or do I need to push around boxes in Inkscape?",
  "id" : 389759981655842816,
  "created_at" : "2013-10-14 14:29:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/6923g2LYuB",
      "expanded_url" : "http:\/\/completelyseriouscomics.com\/?p=647",
      "display_url" : "completelyseriouscomics.com\/?p=647"
    } ]
  },
  "geo" : { },
  "id_str" : "389755327962288129",
  "text" : "Travel to the Fear Dimension http:\/\/t.co\/6923g2LYuB",
  "id" : 389755327962288129,
  "created_at" : "2013-10-14 14:11:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/wPhg7oMlUI",
      "expanded_url" : "http:\/\/worldobserveronline.com\/2013\/10\/04\/man-lives-without-money\/",
      "display_url" : "worldobserveronline.com\/2013\/10\/04\/man\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389747276542783488",
  "text" : "The man who lives without money http:\/\/t.co\/wPhg7oMlUI",
  "id" : 389747276542783488,
  "created_at" : "2013-10-14 13:39:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/DEU1eiWeXU",
      "expanded_url" : "http:\/\/www.anticscomic.com\/comics\/2013-05-10.jpg",
      "display_url" : "anticscomic.com\/comics\/2013-05\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389745642328698880",
  "text" : "It's time for the world to see! http:\/\/t.co\/DEU1eiWeXU",
  "id" : 389745642328698880,
  "created_at" : "2013-10-14 13:32:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 14, 25 ],
      "id_str" : "995259308",
      "id" : 995259308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389731296399745024",
  "geo" : { },
  "id_str" : "389732694419968001",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @HansZauner impressive enough for me ;)",
  "id" : 389732694419968001,
  "in_reply_to_status_id" : 389731296399745024,
  "created_at" : "2013-10-14 12:41:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 14, 25 ],
      "id_str" : "995259308",
      "id" : 995259308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/km4Prq40Z8",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=XvdpjZYLumw",
      "display_url" : "youtube.com\/watch?v=XvdpjZ\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722883969, 8.6276538623 ]
  },
  "id_str" : "389731690882809856",
  "text" : "Uh, thanks to @HansZauner I found this great Dylan-at-Royal Albert Hall-reference by the uke orchestra of GB http:\/\/t.co\/km4Prq40Z8",
  "id" : 389731690882809856,
  "created_at" : "2013-10-14 12:37:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 12, 25 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/s1IlCuhxqK",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=dKpzCCuHDVY",
      "display_url" : "youtube.com\/watch?v=dKpzCC\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "389725801228165120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723158417, 8.6276288721 ]
  },
  "id_str" : "389730142219952128",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner @PhilippBayer nah, that\u2019s just not true. :) http:\/\/t.co\/s1IlCuhxqK",
  "id" : 389730142219952128,
  "in_reply_to_status_id" : 389725801228165120,
  "created_at" : "2013-10-14 12:31:21 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 12, 25 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389723651651534849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722821138, 8.6276568107 ]
  },
  "id_str" : "389723901670207488",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner @PhilippBayer there\u2019s always money in the uke if bioinformatics doesn\u2019t work out!",
  "id" : 389723901670207488,
  "in_reply_to_status_id" : 389723651651534849,
  "created_at" : "2013-10-14 12:06:33 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 56, 69 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/kRH4MvwGHG",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=sSdyHPBOmfE",
      "display_url" : "youtube.com\/watch?v=sSdyHP\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172332443, 8.6276264075 ]
  },
  "id_str" : "389722306349916160",
  "text" : "This makes me wonder: How are your uke skills improving @PhilippBayer? http:\/\/t.co\/kRH4MvwGHG",
  "id" : 389722306349916160,
  "created_at" : "2013-10-14 12:00:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/N6RK78hOey",
      "expanded_url" : "http:\/\/instagram.com\/p\/fciDEuhwhs\/",
      "display_url" : "instagram.com\/p\/fciDEuhwhs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389711485808934912",
  "text" : "Modern Art: A Commentary on the State of Modern Society http:\/\/t.co\/N6RK78hOey",
  "id" : 389711485808934912,
  "created_at" : "2013-10-14 11:17:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/ADdkPy5o6c",
      "expanded_url" : "http:\/\/instagram.com\/p\/fcVh1uhwm1\/",
      "display_url" : "instagram.com\/p\/fcVh1uhwm1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389683823736545280",
  "text" : "\u00ABOh, Tentakelmonster wurden zu moderner Kunst erhoben! http:\/\/t.co\/ADdkPy5o6c",
  "id" : 389683823736545280,
  "created_at" : "2013-10-14 09:27:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene-Talk.de",
      "screen_name" : "Gene_Talk",
      "indices" : [ 0, 10 ],
      "id_str" : "1130798947",
      "id" : 1130798947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389662904582025216",
  "geo" : { },
  "id_str" : "389663473891680256",
  "in_reply_to_user_id" : 1130798947,
  "text" : "@Gene_Talk sure, I will drop you an email later. Exec summary: Found no interesting variations, all filtered ones are only correlations.",
  "id" : 389663473891680256,
  "in_reply_to_status_id" : 389662904582025216,
  "created_at" : "2013-10-14 08:06:26 +0000",
  "in_reply_to_screen_name" : "Gene_Talk",
  "in_reply_to_user_id_str" : "1130798947",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/FZHebOZ8pf",
      "expanded_url" : "http:\/\/xkcd.com\/1277\/",
      "display_url" : "xkcd.com\/1277\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389661953066418176",
  "text" : "This totally explains the Newcomb-Benford Law http:\/\/t.co\/FZHebOZ8pf",
  "id" : 389661953066418176,
  "created_at" : "2013-10-14 08:00:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 105, 114 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 115, 122 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/SpwYYDBhCa",
      "expanded_url" : "http:\/\/www.normativeorders.net\/media\/downloads\/2013-2014_WS_RV_Beyond%20Anarchy.pdf",
      "display_url" : "normativeorders.net\/media\/download\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1080952126, 8.6629061583 ]
  },
  "id_str" : "389646865878482944",
  "text" : "Lecture Series Beyond Anarchy: Rule and Authority in the International System http:\/\/t.co\/SpwYYDBhCa \/cc @Senficon @TnaKng",
  "id" : 389646865878482944,
  "created_at" : "2013-10-14 07:00:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Kliesch",
      "screen_name" : "antipattern",
      "indices" : [ 0, 12 ],
      "id_str" : "21827943",
      "id" : 21827943
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 13, 22 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "389510040891432960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009686805, 8.282993875 ]
  },
  "id_str" : "389510671165296641",
  "in_reply_to_user_id" : 21827943,
  "text" : "@antipattern @eramirez thanks for the pointer!",
  "id" : 389510671165296641,
  "in_reply_to_status_id" : 389510040891432960,
  "created_at" : "2013-10-13 21:59:15 +0000",
  "in_reply_to_screen_name" : "antipattern",
  "in_reply_to_user_id_str" : "21827943",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 84, 93 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/389508570557210625\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/887Bg9p3BM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWfP-yfIgAAGS4X.png",
      "id_str" : "389508570402029568",
      "id" : 389508570402029568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWfP-yfIgAAGS4X.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 666
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 1039,
        "resize" : "fit",
        "w" : 1017
      } ],
      "display_url" : "pic.twitter.com\/887Bg9p3BM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009685215, 8.2830656775 ]
  },
  "id_str" : "389508570557210625",
  "text" : "the quantified relationship via chat logs shows: emotional blackmail seems to work. @eramirez http:\/\/t.co\/887Bg9p3BM",
  "id" : 389508570557210625,
  "created_at" : "2013-10-13 21:50:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/XE9dSGt3Vk",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/7d2b2fd4129cca5368abf8ecd5e90d2c\/tumblr_mufii0vRfQ1qdlh1io1_400.gif",
      "display_url" : "25.media.tumblr.com\/7d2b2fd4129cca\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009685215, 8.2830656775 ]
  },
  "id_str" : "389497088356413440",
  "text" : "Me, every time R surprises me http:\/\/t.co\/XE9dSGt3Vk",
  "id" : 389497088356413440,
  "created_at" : "2013-10-13 21:05:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/uUOX34O6AC",
      "expanded_url" : "http:\/\/instagram.com\/p\/fa6DG_hwvQ\/",
      "display_url" : "instagram.com\/p\/fa6DG_hwvQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389484861142339584",
  "text" : "Insert Random Buddhist Candle Quote Here http:\/\/t.co\/uUOX34O6AC",
  "id" : 389484861142339584,
  "created_at" : "2013-10-13 20:16:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/4KglsqQn3n",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2013\/10\/arafat-and-polonium-poisoning-a-sort-of-update\/",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009685215, 8.2830656775 ]
  },
  "id_str" : "389481098696482816",
  "text" : "Arafat and Polonium Poisoning: A Sort-of Update http:\/\/t.co\/4KglsqQn3n",
  "id" : 389481098696482816,
  "created_at" : "2013-10-13 20:01:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/lmg47TTShw",
      "expanded_url" : "http:\/\/instagram.com\/p\/fauMViBwn1\/",
      "display_url" : "instagram.com\/p\/fauMViBwn1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389456566510166016",
  "text" : "Begleitflora http:\/\/t.co\/lmg47TTShw",
  "id" : 389456566510166016,
  "created_at" : "2013-10-13 18:24:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095483386, 8.2830578916 ]
  },
  "id_str" : "389450205999157248",
  "text" : "\u00ABDer Herr Kind ist wirklich sehr unproblematisch. Ich hatte ihn ein ganzes Wochenende hier. Und er ist nicht gestorben.\u00BB",
  "id" : 389450205999157248,
  "created_at" : "2013-10-13 17:58:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0087199101, 8.2863578825 ]
  },
  "id_str" : "389446461945303040",
  "text" : "\u00ABHast du mal Poppers genommen?\u00BB \u2014 \u00ABDu meinst damit ich noch weniger sp\u00FCre?!\u00BB",
  "id" : 389446461945303040,
  "created_at" : "2013-10-13 17:44:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/OKsz9EJplH",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0075993",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009605472, 8.282918994 ]
  },
  "id_str" : "389415273297879041",
  "text" : "Measuring the Evolution of Ontology Complexity: The Gene Ontology Case Study\n http:\/\/t.co\/OKsz9EJplH",
  "id" : 389415273297879041,
  "created_at" : "2013-10-13 15:40:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/MJCGAey4cx",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3143",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009605472, 8.282918994 ]
  },
  "id_str" : "389414186083954688",
  "text" : "Expectation of Death http:\/\/t.co\/MJCGAey4cx",
  "id" : 389414186083954688,
  "created_at" : "2013-10-13 15:35:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/3d1fxkkzA1",
      "expanded_url" : "http:\/\/imgur.com\/E7gNfYa",
      "display_url" : "imgur.com\/E7gNfYa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009605472, 8.282918994 ]
  },
  "id_str" : "389410293874708480",
  "text" : "\u00ABin the game of technology, you either win, or you turn it off &amp; on again\u00BB http:\/\/t.co\/3d1fxkkzA1",
  "id" : 389410293874708480,
  "created_at" : "2013-10-13 15:20:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/e4h00Nefwc",
      "expanded_url" : "http:\/\/imgur.com\/zJq8gBI",
      "display_url" : "imgur.com\/zJq8gBI"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009605472, 8.282918994 ]
  },
  "id_str" : "389408304579239936",
  "text" : "Flamincock http:\/\/t.co\/e4h00Nefwc",
  "id" : 389408304579239936,
  "created_at" : "2013-10-13 15:12:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/k2rGXd83MM",
      "expanded_url" : "http:\/\/instagram.com\/p\/faWSZSBwpl\/",
      "display_url" : "instagram.com\/p\/faWSZSBwpl\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1118226426, 8.6846355129 ]
  },
  "id_str" : "389404317423521792",
  "text" : "Traurig: Der K\u00FCnstler sagt yay, das MMK nay\u2026 @ Museum f\u00FCr Moderne Kunst http:\/\/t.co\/k2rGXd83MM",
  "id" : 389404317423521792,
  "created_at" : "2013-10-13 14:56:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0126949889, 8.4252983147 ]
  },
  "id_str" : "389399789164843008",
  "text" : "Moderne Kunst ist gut wenn sie einen dazu bringt die Schuhe auszuziehen und einen komplett mit Matratzen gepflasterten Raum zu betreten.",
  "id" : 389399789164843008,
  "created_at" : "2013-10-13 14:38:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/nWMXl9WNlp",
      "expanded_url" : "http:\/\/instagram.com\/p\/faR5WcBwhn\/",
      "display_url" : "instagram.com\/p\/faR5WcBwhn\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1118226426, 8.6846355129 ]
  },
  "id_str" : "389394460683304960",
  "text" : "Quantified Self @ Museum f\u00FCr Moderne Kunst http:\/\/t.co\/nWMXl9WNlp",
  "id" : 389394460683304960,
  "created_at" : "2013-10-13 14:17:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/sT75PvQomS",
      "expanded_url" : "http:\/\/instagram.com\/p\/faROcihwgP\/",
      "display_url" : "instagram.com\/p\/faROcihwgP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "389392849365897217",
  "text" : "Urinello http:\/\/t.co\/sT75PvQomS",
  "id" : 389392849365897217,
  "created_at" : "2013-10-13 14:11:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1121733467, 8.6854818382 ]
  },
  "id_str" : "389372689825406977",
  "text" : "\u00ABIch soll dich \u00FCbrigens von dem Typen gr\u00FC\u00DFen den ich in der Bahn getroffen habe und den ich von Twitter kenne.\u00BB",
  "id" : 389372689825406977,
  "created_at" : "2013-10-13 12:50:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1117222989, 8.6817610636 ]
  },
  "id_str" : "389365946164731904",
  "text" : "\u00ABDieser brasilianische K\u00FCnstler soll sehr gut sein &amp; ist schon tot.\u2014\u00ABDu meinst ich kann mich lustig machen ohne seine Gef\u00FChle zu verletzen?\u00BB",
  "id" : 389365946164731904,
  "created_at" : "2013-10-13 12:24:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dispatches",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1137043709, 8.678626519 ]
  },
  "id_str" : "389362628189241345",
  "text" : "\u00ABWe never announced a scorched-earth policy; we never announced any policy at all.\u00BB #dispatches",
  "id" : 389362628189241345,
  "created_at" : "2013-10-13 12:10:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/KXvw38WNip",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/ResearchBloggingBiologyEnglish\/~3\/5NPddTuj-Vw\/unempathetic-kids-dont-get-sarcasm.html",
      "display_url" : "feedproxy.google.com\/~r\/ResearchBlo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389359484168310784",
  "text" : "Unempathetic Kids Don't Get Sarcasm http:\/\/t.co\/KXvw38WNip",
  "id" : 389359484168310784,
  "created_at" : "2013-10-13 11:58:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/QNX7yWCmiT",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/zw2LT42RR34\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389358390868459520",
  "text" : "Free vibrators for non-essential federal\u00A0employees http:\/\/t.co\/QNX7yWCmiT",
  "id" : 389358390868459520,
  "created_at" : "2013-10-13 11:54:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/hTra4HFOCh",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/63776458051",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/637764580\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "389358122433019904",
  "text" : "When I'm overzealous with my tip box (worst if you had to fill it yourself in the first place) http:\/\/t.co\/hTra4HFOCh",
  "id" : 389358122433019904,
  "created_at" : "2013-10-13 11:53:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dispatches",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9880165009, 8.3950138251 ]
  },
  "id_str" : "389043167053774849",
  "text" : "\u00ABWe napalmed off their crops and flattened their villages, and then we admired the restlessness in their spirit.\u00BB #dispatches",
  "id" : 389043167053774849,
  "created_at" : "2013-10-12 15:01:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0005182105, 8.2696500817 ]
  },
  "id_str" : "388987904124780544",
  "text" : "\u00ABWas wei\u00DF ich schon von Emotionen?\u00BB \u2014 \u00ABDu versuchst sie zu plotten. Das sagt doch schon alles.\u00BB",
  "id" : 388987904124780544,
  "created_at" : "2013-10-12 11:21:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388977322445246465",
  "text" : "\u00ABDu hast keinen Grund zur linearen Regression. Wir Polys glauben doch nicht an den Relationship Escalator sondern an eine andere Religion!\u00BB",
  "id" : 388977322445246465,
  "created_at" : "2013-10-12 10:39:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 32, 41 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096641418, 8.2829966444 ]
  },
  "id_str" : "388951552209453056",
  "text" : "\u00ABActually, it\u2019s pretty easy.\u00BB \u2014 @Senficon, talking about R while sleeping.",
  "id" : 388951552209453056,
  "created_at" : "2013-10-12 08:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388807553234513920",
  "text" : "\u00ABKurz dachte ich, dass das Generalized Linear Model sagt \u2018Ihr h\u00E4ttet euch schon lange trennen sollen\u2019. Aber die X-Achse war nur unsorted.\u00BB",
  "id" : 388807553234513920,
  "created_at" : "2013-10-11 23:25:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 125, 134 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388786857666150400",
  "text" : "\u00ABWarning: namespace \u2018ggplot2\u2019 is not available and has been replaced by .GlobalEnv when processing object \u2018freiheit\u2019\u00BB *hust* @Senficon",
  "id" : 388786857666150400,
  "created_at" : "2013-10-11 22:03:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388783677078904832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388783841374375936",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez great, because I already started working on it :)",
  "id" : 388783841374375936,
  "in_reply_to_status_id" : 388783677078904832,
  "created_at" : "2013-10-11 21:51:05 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/q1NPHJ2NS8",
      "expanded_url" : "http:\/\/instagram.com\/p\/fV1DEZBwrZ\/",
      "display_url" : "instagram.com\/p\/fV1DEZBwrZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "388767946019209216",
  "text" : "Hobby scientists render reconstruction of how the LUCA looked like. http:\/\/t.co\/q1NPHJ2NS8",
  "id" : 388767946019209216,
  "created_at" : "2013-10-11 20:47:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0107960543, 8.2778949849 ]
  },
  "id_str" : "388766309674401793",
  "text" : "\u00ABDu darfst mich ruhig in deinen Blogposts erw\u00E4hnen und shamen. Ich wei\u00DF ja, dass es deine Art ist deine Liebe zu zeigen.\u00BB",
  "id" : 388766309674401793,
  "created_at" : "2013-10-11 20:41:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388753233231249408",
  "text" : "\u00ABWollen wir nicht lieber deine Jura-Lehrb\u00FCcher aus der zweiten Reihe holen und Dawkins dahinter verstecken als es andersrum zu machen?\u00BB",
  "id" : 388753233231249408,
  "created_at" : "2013-10-11 19:49:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388751603727368192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388752892330795008",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode Finanzberatung is Magic!",
  "id" : 388752892330795008,
  "in_reply_to_status_id" : 388751603727368192,
  "created_at" : "2013-10-11 19:48:06 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Heller",
      "screen_name" : "plomlompom",
      "indices" : [ 65, 76 ],
      "id_str" : "7941582",
      "id" : 7941582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096049859, 8.2829201035 ]
  },
  "id_str" : "388751114465988608",
  "text" : "Nach Wasserschaden B\u00FCcherregal neu sortiert: \u00ABMLP-Vorschulbuch\u00BB, @plomlompom, \u00ABG\u00F6del, Escher, Bach\u00BB &amp; \u00ABWie der Maulwurf zu seinen Hosen kam\u00BB",
  "id" : 388751114465988608,
  "created_at" : "2013-10-11 19:41:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dispatches",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097457599, 8.2830585726 ]
  },
  "id_str" : "388716151318253568",
  "text" : "\u00ABA common prayer for the overattached: You\u2019ll let it go sooner or later, why not do it now?\u00BB #dispatches",
  "id" : 388716151318253568,
  "created_at" : "2013-10-11 17:22:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/TAEwbcFom7",
      "expanded_url" : "http:\/\/www.boredpanda.com\/defrosting-building-chicago-cold-storage\/",
      "display_url" : "boredpanda.com\/defrosting-bui\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388708966001565696",
  "text" : "RT @Lobot: Industrial building from the outside, ice cave from the inside. http:\/\/t.co\/TAEwbcFom7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/TAEwbcFom7",
        "expanded_url" : "http:\/\/www.boredpanda.com\/defrosting-building-chicago-cold-storage\/",
        "display_url" : "boredpanda.com\/defrosting-bui\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388689850519814144",
    "text" : "Industrial building from the outside, ice cave from the inside. http:\/\/t.co\/TAEwbcFom7",
    "id" : 388689850519814144,
    "created_at" : "2013-10-11 15:37:36 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 388708966001565696,
  "created_at" : "2013-10-11 16:53:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0068673007, 8.2662752565 ]
  },
  "id_str" : "388701291058565120",
  "text" : "\u00ABDon\u2019t you dare calling me a mad engineer, I\u2019m a scientist\u00BB\u2014\u00ABHe wants to test how well humans can recover from an effect pop size of 1000.\u00BB",
  "id" : 388701291058565120,
  "created_at" : "2013-10-11 16:23:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/ewE0ZqwfWR",
      "expanded_url" : "http:\/\/instagram.com\/p\/fVUdhVBwmu\/",
      "display_url" : "instagram.com\/p\/fVUdhVBwmu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "388696410541285377",
  "text" : "Und ich sag noch das Mars gr\u00F6\u00DFer als die Erde ist! http:\/\/t.co\/ewE0ZqwfWR",
  "id" : 388696410541285377,
  "created_at" : "2013-10-11 16:03:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388694048485412864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9958600258, 8.363986567 ]
  },
  "id_str" : "388694384126222336",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv more like \u2018being in the Vietnam war fucked me up pretty fast",
  "id" : 388694384126222336,
  "in_reply_to_status_id" : 388694048485412864,
  "created_at" : "2013-10-11 15:55:37 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dispatches",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9980743661, 8.4230936764 ]
  },
  "id_str" : "388691900854964224",
  "text" : "\u00ABHow do you feel when a 19-year-old kid tells you from the bottom of his heart that he\u2019s gotten to old for this kind of shit?\u00BB #dispatches",
  "id" : 388691900854964224,
  "created_at" : "2013-10-11 15:45:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0685077263, 8.6080748472 ]
  },
  "id_str" : "388689519719247872",
  "text" : "\u00ABDeath could come in on the freakyfluky as easily as in the so-called expected ways, a wonder anyone was left alive to die in firefights.\u00BB",
  "id" : 388689519719247872,
  "created_at" : "2013-10-11 15:36:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 25, 34 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388678538586386432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1650060642, 8.6280924736 ]
  },
  "id_str" : "388679158899179520",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate @PhilippBayer @rOpenSci great, if you\u2019d like to see any additional API calls give us notice. Glad to add those if possible. :)",
  "id" : 388679158899179520,
  "in_reply_to_status_id" : 388678538586386432,
  "created_at" : "2013-10-11 14:55:07 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 40, 49 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388675586073186305",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1729779058, 8.625693906 ]
  },
  "id_str" : "388676365228441600",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate @PhilippBayer are they using @rOpenSci? They offer R-wrapper for our APIs. :)",
  "id" : 388676365228441600,
  "in_reply_to_status_id" : 388675586073186305,
  "created_at" : "2013-10-11 14:44:01 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 24, 36 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/TqNI0SplJQ",
      "expanded_url" : "http:\/\/bit.ly\/GRyQ9M",
      "display_url" : "bit.ly\/GRyQ9M"
    } ]
  },
  "geo" : { },
  "id_str" : "388668610517803009",
  "text" : "Worst argument ever: MT @AkshatRathi: \"Monogamy is a man-made contract, and when has DNA ever lost out to that?\" http:\/\/t.co\/TqNI0SplJQ",
  "id" : 388668610517803009,
  "created_at" : "2013-10-11 14:13:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/2Ma1JUYBhN",
      "expanded_url" : "http:\/\/buzzhootroar.com\/a-spider-did-not-bite-you\/",
      "display_url" : "buzzhootroar.com\/a-spider-did-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388658826779435010",
  "text" : "A Spider Did Not Bite You http:\/\/t.co\/2Ma1JUYBhN",
  "id" : 388658826779435010,
  "created_at" : "2013-10-11 13:34:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1039615859, 8.6988908339 ]
  },
  "id_str" : "388641167916937216",
  "text" : "\u00ABHast du \u00FCberlegt ins Kloster zu gehen?\u00BB \u2014 \u00ABGute Idee, in einer religi\u00F6sen Einrichtung h\u00E4tte ich genauso viel Spass wie mit dir.\u00BB",
  "id" : 388641167916937216,
  "created_at" : "2013-10-11 12:24:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388598879706697728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1135065223, 8.6784127388 ]
  },
  "id_str" : "388599698032177152",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon I only have like a handful of those so far. Plus: Those are \u2018conscious\u2019 point measures which are prbly extremely prone to bias.",
  "id" : 388599698032177152,
  "in_reply_to_status_id" : 388598879706697728,
  "created_at" : "2013-10-11 09:39:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388577033753985024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1196791334, 8.6507796679 ]
  },
  "id_str" : "388598418211631104",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon I understand that ratios of ratios are a bit problematic, but guess ((pos proxies\/all comm)\/(neg proxies\/all comm)) could do it?",
  "id" : 388598418211631104,
  "in_reply_to_status_id" : 388577033753985024,
  "created_at" : "2013-10-11 09:34:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388577033753985024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1156925385, 8.6495315529 ]
  },
  "id_str" : "388595715926401024",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon thought about that as well. But that should be easy to check by correlating mood indicators with sum(comm), right?",
  "id" : 388595715926401024,
  "in_reply_to_status_id" : 388577033753985024,
  "created_at" : "2013-10-11 09:23:33 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1164769652, 8.6500496857 ]
  },
  "id_str" : "388591899084591104",
  "text" : "\u00ABDie melden sich alle 3 Wochen &amp; fragen wegen des Antrags. Dabei arbeite ich hier nicht!\u00BB\u2014\u00ABDeshalb hab ich dich den Kontakt machen lassen.\u00BB",
  "id" : 388591899084591104,
  "created_at" : "2013-10-11 09:08:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/bkStDcWtbY",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/388554679292297216",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0040770794, 8.3562414108 ]
  },
  "id_str" : "388556038297108480",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon let\u2019s say I\u2019m to lazy to learn more NLP. Think your salience analysis would work on emoticon-counts? https:\/\/t.co\/bkStDcWtbY",
  "id" : 388556038297108480,
  "created_at" : "2013-10-11 06:45:53 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 104, 113 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0068894588, 8.282768894 ]
  },
  "id_str" : "388554679292297216",
  "text" : "Quick idea: Perform sentiment analysis on my own textual comm output to correlate with activity\/weight. @eramirez: has anyone tried that?",
  "id" : 388554679292297216,
  "created_at" : "2013-10-11 06:40:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Luis de Vicente",
      "screen_name" : "Macroscopist",
      "indices" : [ 3, 16 ],
      "id_str" : "447312248",
      "id" : 447312248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388430161173303296",
  "text" : "RT @Macroscopist: The Guardian's answer to the Daily Mail has to be the most articulate and thought out Fuck You in journalism history http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/IeFq6EP2Y0",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2013\/oct\/10\/guardian-democracy-editors",
        "display_url" : "theguardian.com\/world\/2013\/oct\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388426887422558208",
    "text" : "The Guardian's answer to the Daily Mail has to be the most articulate and thought out Fuck You in journalism history http:\/\/t.co\/IeFq6EP2Y0",
    "id" : 388426887422558208,
    "created_at" : "2013-10-10 22:12:41 +0000",
    "user" : {
      "name" : "Jose Luis de Vicente",
      "screen_name" : "Macroscopist",
      "protected" : false,
      "id_str" : "447312248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682393004468994052\/lCw43Oj-_normal.jpg",
      "id" : 447312248,
      "verified" : false
    }
  },
  "id" : 388430161173303296,
  "created_at" : "2013-10-10 22:25:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rn Huxhorn",
      "screen_name" : "huxi",
      "indices" : [ 0, 5 ],
      "id_str" : "15710349",
      "id" : 15710349
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 96, 105 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388423178143666176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388423669816758272",
  "in_reply_to_user_id" : 15710349,
  "text" : "@huxi Ne, hatte ich nicht. Aber Sims sind auch nicht so meins. Das w\u00E4re vermutlich mehr was f\u00FCr @Senficon",
  "id" : 388423669816758272,
  "in_reply_to_status_id" : 388423178143666176,
  "created_at" : "2013-10-10 21:59:54 +0000",
  "in_reply_to_screen_name" : "huxi",
  "in_reply_to_user_id_str" : "15710349",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/JT4CrNNcYx",
      "expanded_url" : "http:\/\/i.imgur.com\/BtAjJ0T.jpg",
      "display_url" : "i.imgur.com\/BtAjJ0T.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388414924965568513",
  "text" : "it\u2019s a trap http:\/\/t.co\/JT4CrNNcYx",
  "id" : 388414924965568513,
  "created_at" : "2013-10-10 21:25:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0105689857, 8.2776503576 ]
  },
  "id_str" : "388411200511700992",
  "text" : "\u00ABIch mag Boxplots. Boxplots sind best Plots. Die haben so niedliche Whiskers!\u00BB",
  "id" : 388411200511700992,
  "created_at" : "2013-10-10 21:10:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0089230475, 8.2706441701 ]
  },
  "id_str" : "388405826953961472",
  "text" : "\u00ABDas sind ja sch\u00F6ne Wolken. Die sehen aus wie eine Kommunisten-Sichel. Oder ein umgedrehtes Nike-Logo!\u00BB",
  "id" : 388405826953961472,
  "created_at" : "2013-10-10 20:49:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/EuIxgyQcpX",
      "expanded_url" : "http:\/\/www.hankboughtabus.com\/a-tour-of-the-bus\/",
      "display_url" : "hankboughtabus.com\/a-tour-of-the-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388400852098359296",
  "text" : "Hank Bought A Bus\u2026 http:\/\/t.co\/EuIxgyQcpX",
  "id" : 388400852098359296,
  "created_at" : "2013-10-10 20:29:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ro Bot Dylan",
      "screen_name" : "ro_bot_dylan",
      "indices" : [ 3, 16 ],
      "id_str" : "200272047",
      "id" : 200272047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388398900123820032",
  "text" : "RT @ro_bot_dylan: Well, you know I need a steam shovel mama to keep away the dead I need a dump truck mama to unload my head",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/unahormiga.com\/?lang=en\" rel=\"nofollow\"\u003ESingingBob\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388398728127975424",
    "text" : "Well, you know I need a steam shovel mama to keep away the dead I need a dump truck mama to unload my head",
    "id" : 388398728127975424,
    "created_at" : "2013-10-10 20:20:47 +0000",
    "user" : {
      "name" : "Ro Bot Dylan",
      "screen_name" : "ro_bot_dylan",
      "protected" : false,
      "id_str" : "200272047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1143638857\/bobdylan_normal.JPG",
      "id" : 200272047,
      "verified" : false
    }
  },
  "id" : 388398900123820032,
  "created_at" : "2013-10-10 20:21:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rn Huxhorn",
      "screen_name" : "huxi",
      "indices" : [ 39, 44 ],
      "id_str" : "15710349",
      "id" : 15710349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/RJSAl2GhtB",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/hinterlandgames\/the-long-dark-a-first-person-post-disaster-surviva",
      "display_url" : "kickstarter.com\/projects\/hinte\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388397366161989634",
  "text" : "\u2018The Long Dark\u2019 sounds pretty nice \/cc @huxi http:\/\/t.co\/RJSAl2GhtB",
  "id" : 388397366161989634,
  "created_at" : "2013-10-10 20:15:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/BT6gtLySio",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/Bsp5GojkyN8\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388384915584471040",
  "text" : "Airbnb fights NY AG subpoena for user\u00A0data http:\/\/t.co\/BT6gtLySio",
  "id" : 388384915584471040,
  "created_at" : "2013-10-10 19:25:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 10, 19 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388380331155275776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1158315574, 8.6824550227 ]
  },
  "id_str" : "388380736698724352",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Roterhai seit \u00FCber 10 Jahren ist mein Motto: \u2018wenn ich \u00FCber meine Umst\u00E4nde nicht lachen k\u00F6nnte hatte ich mich schon umgebracht\u2019",
  "id" : 388380736698724352,
  "in_reply_to_status_id" : 388380331155275776,
  "created_at" : "2013-10-10 19:09:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388379260655648768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1150877107, 8.682861116 ]
  },
  "id_str" : "388380053614362624",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai @Senficon jetzt verstehe ich auch wieso die gleichen Nachbarn uns einen Pl\u00FCschwal aus dem Fenster in den Garten geworfen haben!",
  "id" : 388380053614362624,
  "in_reply_to_status_id" : 388379260655648768,
  "created_at" : "2013-10-10 19:06:35 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115822058, 8.6824602059 ]
  },
  "id_str" : "388379304310345728",
  "text" : "\u00ABDu ziehst das Tempo an. Jetzt willst du dich schon zwei mal pro Woche trennen.\u00BB",
  "id" : 388379304310345728,
  "created_at" : "2013-10-10 19:03:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 10, 19 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388378820966756353",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151102544, 8.6828488082 ]
  },
  "id_str" : "388379066854047744",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Roterhai am Telefon sagte der Hausverwalter am Dienstag das es die gleichen wie beim letzten mal waren.",
  "id" : 388379066854047744,
  "in_reply_to_status_id" : 388378820966756353,
  "created_at" : "2013-10-10 19:02:39 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388378502291931136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1173891787, 8.6816050303 ]
  },
  "id_str" : "388378876042547200",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai @Senficon ja, diese Episode ist auch nicht das erste mal. War vor ~1 Jahr schon mal.",
  "id" : 388378876042547200,
  "in_reply_to_status_id" : 388378502291931136,
  "created_at" : "2013-10-10 19:01:54 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388378078683996160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1164612849, 8.6821145452 ]
  },
  "id_str" : "388378711877496832",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon yay, ich sag dann schon mal den Mykologen Bescheid das sie bald Samples bekommen.",
  "id" : 388378711877496832,
  "in_reply_to_status_id" : 388378078683996160,
  "created_at" : "2013-10-10 19:01:15 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388378006097387520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1150850959, 8.6828628449 ]
  },
  "id_str" : "388378246674657280",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai @Senficon ja, Familie \u2018wir schrauben den Duschabfluss los und Duschen dann\u2019 wohnt 4(!) Etagen \u00FCber uns\u2026",
  "id" : 388378246674657280,
  "in_reply_to_status_id" : 388378006097387520,
  "created_at" : "2013-10-10 18:59:24 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388377314628599808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11529138, 8.6819195569 ]
  },
  "id_str" : "388377739361009666",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai @Senficon ja, ist jetzt das 3. mal in 5 Tagen das es aus der Decke l\u00E4uft.",
  "id" : 388377739361009666,
  "in_reply_to_status_id" : 388377314628599808,
  "created_at" : "2013-10-10 18:57:23 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388377036512710656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1137841022, 8.6790668821 ]
  },
  "id_str" : "388377231573413889",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon meh, gr\u00F6\u00DFere Mengen oder ist es jetzt erst durchgesuppt?",
  "id" : 388377231573413889,
  "in_reply_to_status_id" : 388377036512710656,
  "created_at" : "2013-10-10 18:55:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388340423955329024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1137751411, 8.6788380773 ]
  },
  "id_str" : "388376828395921408",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Fenster oder Decke? (Unsere Wohnung ist ja so geil das man das nachfragen muss\u2026)",
  "id" : 388376828395921408,
  "in_reply_to_status_id" : 388340423955329024,
  "created_at" : "2013-10-10 18:53:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/R2UB2GZlaN",
      "expanded_url" : "http:\/\/egtheory.wordpress.com\/2013\/10\/09\/games-animals-play\/",
      "display_url" : "egtheory.wordpress.com\/2013\/10\/09\/gam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388315001808642048",
  "text" : "A video of John Maynard Smith explaining the basics of evolutionary game theory &lt;3 http:\/\/t.co\/R2UB2GZlaN",
  "id" : 388315001808642048,
  "created_at" : "2013-10-10 14:48:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pleuni Pennings",
      "screen_name" : "pleunipennings",
      "indices" : [ 3, 18 ],
      "id_str" : "52010875",
      "id" : 52010875
    }, {
      "name" : "Adam Eyre-Walker",
      "screen_name" : "AdamEyreWalker",
      "indices" : [ 33, 48 ],
      "id_str" : "632538212",
      "id" : 632538212
    }, {
      "name" : "Nina Stoletzki",
      "screen_name" : "Nstoletzki",
      "indices" : [ 53, 64 ],
      "id_str" : "813148866",
      "id" : 813148866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PLOSBiology",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/81q0sPGBWr",
      "expanded_url" : "http:\/\/dx.plos.org\/10.1371\/journal.pbio.1001675",
      "display_url" : "dx.plos.org\/10.1371\/journa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388070865273106433",
  "text" : "RT @pleunipennings: #PLOSBiology @AdamEyreWalker and @Nstoletzki on how bad we all are a judging papers http:\/\/t.co\/81q0sPGBWr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Eyre-Walker",
        "screen_name" : "AdamEyreWalker",
        "indices" : [ 13, 28 ],
        "id_str" : "632538212",
        "id" : 632538212
      }, {
        "name" : "Nina Stoletzki",
        "screen_name" : "Nstoletzki",
        "indices" : [ 33, 44 ],
        "id_str" : "813148866",
        "id" : 813148866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PLOSBiology",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/81q0sPGBWr",
        "expanded_url" : "http:\/\/dx.plos.org\/10.1371\/journal.pbio.1001675",
        "display_url" : "dx.plos.org\/10.1371\/journa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387693909612060672",
    "text" : "#PLOSBiology @AdamEyreWalker and @Nstoletzki on how bad we all are a judging papers http:\/\/t.co\/81q0sPGBWr",
    "id" : 387693909612060672,
    "created_at" : "2013-10-08 21:40:05 +0000",
    "user" : {
      "name" : "Pleuni Pennings",
      "screen_name" : "pleunipennings",
      "protected" : false,
      "id_str" : "52010875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780605848695349248\/XRjghuR__normal.jpg",
      "id" : 52010875,
      "verified" : false
    }
  },
  "id" : 388070865273106433,
  "created_at" : "2013-10-09 22:37:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slim Amamou",
      "screen_name" : "slim404",
      "indices" : [ 3, 11 ],
      "id_str" : "8516062",
      "id" : 8516062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388062328329363457",
  "text" : "RT @slim404: \"Christianity did not really begin as a religion, but a sophisticated government project\" - Joseph Atwill http:\/\/t.co\/nYyvSccV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/nYyvSccV6R",
        "expanded_url" : "http:\/\/uk.prweb.com\/releases\/2013\/10\/prweb11201273.htm",
        "display_url" : "uk.prweb.com\/releases\/2013\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "388061558116347904",
    "text" : "\"Christianity did not really begin as a religion, but a sophisticated government project\" - Joseph Atwill http:\/\/t.co\/nYyvSccV6R",
    "id" : 388061558116347904,
    "created_at" : "2013-10-09 22:00:59 +0000",
    "user" : {
      "name" : "Slim Amamou",
      "screen_name" : "slim404",
      "protected" : false,
      "id_str" : "8516062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459253270406389760\/6p0ZALpm_normal.jpeg",
      "id" : 8516062,
      "verified" : true
    }
  },
  "id" : 388062328329363457,
  "created_at" : "2013-10-09 22:04:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Biermann",
      "screen_name" : "kaibiermann",
      "indices" : [ 3, 15 ],
      "id_str" : "20499665",
      "id" : 20499665
    }, {
      "name" : "Gilad Lotan",
      "screen_name" : "gilgul",
      "indices" : [ 57, 64 ],
      "id_str" : "3183721",
      "id" : 3183721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/A0UvTXbaym",
      "expanded_url" : "https:\/\/readtapestry.com\/s\/ww3HtHfmW\/",
      "display_url" : "readtapestry.com\/s\/ww3HtHfmW\/"
    } ]
  },
  "geo" : { },
  "id_str" : "388057750338801664",
  "text" : "RT @kaibiermann: \"funny\" \u2260 \"LOL\" interessante Folien von @gilgul \u00FCber Datenanalyse: https:\/\/t.co\/A0UvTXbaym",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gilad Lotan",
        "screen_name" : "gilgul",
        "indices" : [ 40, 47 ],
        "id_str" : "3183721",
        "id" : 3183721
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/A0UvTXbaym",
        "expanded_url" : "https:\/\/readtapestry.com\/s\/ww3HtHfmW\/",
        "display_url" : "readtapestry.com\/s\/ww3HtHfmW\/"
      } ]
    },
    "geo" : { },
    "id_str" : "387887503002173440",
    "text" : "\"funny\" \u2260 \"LOL\" interessante Folien von @gilgul \u00FCber Datenanalyse: https:\/\/t.co\/A0UvTXbaym",
    "id" : 387887503002173440,
    "created_at" : "2013-10-09 10:29:21 +0000",
    "user" : {
      "name" : "Kai Biermann",
      "screen_name" : "kaibiermann",
      "protected" : false,
      "id_str" : "20499665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427394466\/portrait_normal.jpg",
      "id" : 20499665,
      "verified" : true
    }
  },
  "id" : 388057750338801664,
  "created_at" : "2013-10-09 21:45:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/GVykVZSQrg",
      "expanded_url" : "http:\/\/www.whompcomic.com\/comics\/2013-05-08-Hairrowing-Experience.jpg",
      "display_url" : "whompcomic.com\/comics\/2013-05\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "388051706074103808",
  "text" : "Trimming http:\/\/t.co\/GVykVZSQrg",
  "id" : 388051706074103808,
  "created_at" : "2013-10-09 21:21:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387940964477595649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968864, 8.28299479 ]
  },
  "id_str" : "388050359006289922",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate Let us know if we can be of any help!",
  "id" : 388050359006289922,
  "in_reply_to_status_id" : 387940964477595649,
  "created_at" : "2013-10-09 21:16:29 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucomo",
      "screen_name" : "Lucomo",
      "indices" : [ 0, 7 ],
      "id_str" : "47782352",
      "id" : 47782352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388042489514319872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0146119286, 8.2775114377 ]
  },
  "id_str" : "388046472685842432",
  "in_reply_to_user_id" : 47782352,
  "text" : "@Lucomo garantiert ist es nur wenn man selbst die Daten passend biegt, stimmt.",
  "id" : 388046472685842432,
  "in_reply_to_status_id" : 388042489514319872,
  "created_at" : "2013-10-09 21:01:03 +0000",
  "in_reply_to_screen_name" : "Lucomo",
  "in_reply_to_user_id_str" : "47782352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0126334755, 8.2788650866 ]
  },
  "id_str" : "388039898961567744",
  "text" : "\u00ABOnline-Reviews f\u00FCr Gleisabschnitte die gut zum Suizid geeignet sind leiden extrem unter dem Survivorship-Bias: 0\/10, would not try again.\u00BB",
  "id" : 388039898961567744,
  "created_at" : "2013-10-09 20:34:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucomo",
      "screen_name" : "Lucomo",
      "indices" : [ 0, 7 ],
      "id_str" : "47782352",
      "id" : 47782352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "388035931447365632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096794951, 8.2830717853 ]
  },
  "id_str" : "388036130098384896",
  "in_reply_to_user_id" : 47782352,
  "text" : "@Lucomo naja, ich kann mir auch einen Test suchen bei dem mein Datensatz alle Bedingungen die erf\u00FCllt sein m\u00FCssten verletzt und mich freuen.",
  "id" : 388036130098384896,
  "in_reply_to_status_id" : 388035931447365632,
  "created_at" : "2013-10-09 20:19:57 +0000",
  "in_reply_to_screen_name" : "Lucomo",
  "in_reply_to_user_id_str" : "47782352",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Theo Farrell",
      "screen_name" : "WarProf",
      "indices" : [ 3, 11 ],
      "id_str" : "1884016339",
      "id" : 1884016339
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JephPhD\/status\/287275069279981569\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/I1pkiE9M1z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_ybJ0nCUAAyk9c.jpg",
      "id_str" : "287275069288370176",
      "id" : 287275069288370176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_ybJ0nCUAAyk9c.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/I1pkiE9M1z"
    } ],
    "hashtags" : [ {
      "text" : "overlyhonestreviews",
      "indices" : [ 84, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388031231134539777",
  "text" : "RT @WarProf: Hilarious acknowledgement on conference paper! http:\/\/t.co\/I1pkiE9M1z\" #overlyhonestreviews\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JephPhD\/status\/287275069279981569\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/I1pkiE9M1z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A_ybJ0nCUAAyk9c.jpg",
        "id_str" : "287275069288370176",
        "id" : 287275069288370176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_ybJ0nCUAAyk9c.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/I1pkiE9M1z"
      } ],
      "hashtags" : [ {
        "text" : "overlyhonestreviews",
        "indices" : [ 71, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387621108377460736",
    "text" : "Hilarious acknowledgement on conference paper! http:\/\/t.co\/I1pkiE9M1z\" #overlyhonestreviews\u201D",
    "id" : 387621108377460736,
    "created_at" : "2013-10-08 16:50:48 +0000",
    "user" : {
      "name" : "Theo Farrell",
      "screen_name" : "WarProf",
      "protected" : false,
      "id_str" : "1884016339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787231747201204224\/bejqPCP0_normal.jpg",
      "id" : 1884016339,
      "verified" : true
    }
  },
  "id" : 388031231134539777,
  "created_at" : "2013-10-09 20:00:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0014758782, 8.3692818153 ]
  },
  "id_str" : "388026316848902144",
  "text" : "\u00ABNat\u00FCrlich haben Psychologen voll Ahnung von Statistik. Wie sollten sie denn sonst wissen welcher Test am wahrscheinlichsten p&lt;0.05 gibt?\u00BB",
  "id" : 388026316848902144,
  "created_at" : "2013-10-09 19:40:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1149618863, 8.6830828159 ]
  },
  "id_str" : "388015273221304322",
  "text" : "\u00ABAn guten Tagen glaube ich die Tollwut-Impfung rechtzeitig bekommen zu haben. An Schlechten \u00FCberwache ich obsessiv meinen Speichelfluss.\u00BB",
  "id" : 388015273221304322,
  "created_at" : "2013-10-09 18:57:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/ih68XWgUoH",
      "expanded_url" : "http:\/\/priceonomics.com\/making-a-living-collecting-cans\/",
      "display_url" : "priceonomics.com\/making-a-livin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387964359827140608",
  "text" : "San Francisco: Making a Living Collecting Cans http:\/\/t.co\/ih68XWgUoH",
  "id" : 387964359827140608,
  "created_at" : "2013-10-09 15:34:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387912152570290176",
  "geo" : { },
  "id_str" : "387916289051611136",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog du formulierst doch teleologisch um auf den Deckel zu kriegen!",
  "id" : 387916289051611136,
  "in_reply_to_status_id" : 387912152570290176,
  "created_at" : "2013-10-09 12:23:45 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Adam Rutherford",
      "screen_name" : "AdamRutherford",
      "indices" : [ 3, 18 ],
      "id_str" : "22419487",
      "id" : 22419487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387899322249277441",
  "text" : "RT @AdamRutherford: 'I\u2019ve dropped some serious Nobel cheddar on this bad boy.\nIt\u2019s sick.' Peter Higgs on spending his winnings http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/OxxlZDBBeh",
        "expanded_url" : "http:\/\/bit.ly\/19gaq1t",
        "display_url" : "bit.ly\/19gaq1t"
      } ]
    },
    "geo" : { },
    "id_str" : "387895212733120512",
    "text" : "'I\u2019ve dropped some serious Nobel cheddar on this bad boy.\nIt\u2019s sick.' Peter Higgs on spending his winnings http:\/\/t.co\/OxxlZDBBeh",
    "id" : 387895212733120512,
    "created_at" : "2013-10-09 11:00:00 +0000",
    "user" : {
      "name" : "Dr Adam Rutherford",
      "screen_name" : "AdamRutherford",
      "protected" : false,
      "id_str" : "22419487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608384474292846592\/6HNevMZN_normal.jpg",
      "id" : 22419487,
      "verified" : false
    }
  },
  "id" : 387899322249277441,
  "created_at" : "2013-10-09 11:16:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/WFU7enGjXo",
      "expanded_url" : "http:\/\/www.amazon.com\/Communion-Wafers-1000-Broadman-Press\/dp\/0805470859\/ref=sr_1_1?ie=UTF8&qid=1381278136&sr=8-1&keywords=communion+wafers",
      "display_url" : "amazon.com\/Communion-Wafe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387897426595442688",
  "text" : "\u00ABHow better to spruce up the blandness than the crunchy goodness of Jesus?  Jesus is good with fat-free dips\u00BB http:\/\/t.co\/WFU7enGjXo",
  "id" : 387897426595442688,
  "created_at" : "2013-10-09 11:08:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722960973, 8.6276446498 ]
  },
  "id_str" : "387881733800353792",
  "text" : "\u00ABUnd was kann man mit der Methode jetzt anfangen?\u00BB\u2014 Andere Disziplinen shamen weil sie so viele False Positives haben. Psych zum Beispiel!\u00BB",
  "id" : 387881733800353792,
  "created_at" : "2013-10-09 10:06:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 6, 19 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UaynKnMSss",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/6965582-ass-goblins-of-auschwitz?ac=1",
      "display_url" : "goodreads.com\/book\/show\/6965\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "387863207924084736",
  "geo" : { },
  "id_str" : "387863953029599232",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a @PhilippBayer you don't It's basically 'how many times can you cram 'Auschwitz' into 1 page for shock value\"  https:\/\/t.co\/UaynKnMSss",
  "id" : 387863953029599232,
  "in_reply_to_status_id" : 387863207924084736,
  "created_at" : "2013-10-09 08:55:47 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 104, 117 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/uQ8UJ2lC6w",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0075402",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387857595156807681",
  "text" : "Coval: Improving Alignment Quality and Variant Calling Accuracy for Next-Generation Sequencing Data \/cc @PhilippBayer http:\/\/t.co\/uQ8UJ2lC6w",
  "id" : 387857595156807681,
  "created_at" : "2013-10-09 08:30:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Kauer",
      "screen_name" : "sebastiankauer",
      "indices" : [ 3, 18 ],
      "id_str" : "154295601",
      "id" : 154295601
    }, {
      "name" : "mundraub",
      "screen_name" : "mundraub_org",
      "indices" : [ 21, 34 ],
      "id_str" : "247921398",
      "id" : 247921398
    }, {
      "name" : "Silke Bicker",
      "screen_name" : "Erdhaftig",
      "indices" : [ 85, 95 ],
      "id_str" : "613777232",
      "id" : 613777232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allmende",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/jrvAYCFKUA",
      "expanded_url" : "http:\/\/wp.me\/p2Uk1l-rO",
      "display_url" : "wp.me\/p2Uk1l-rO"
    } ]
  },
  "geo" : { },
  "id_str" : "387856031277416448",
  "text" : "RT @sebastiankauer: .@mundraub_org ist keine Einladung zum Hamstern: Blogartikel von @Erdhaftig http:\/\/t.co\/jrvAYCFKUA #allmende",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mundraub",
        "screen_name" : "mundraub_org",
        "indices" : [ 1, 14 ],
        "id_str" : "247921398",
        "id" : 247921398
      }, {
        "name" : "Silke Bicker",
        "screen_name" : "Erdhaftig",
        "indices" : [ 65, 75 ],
        "id_str" : "613777232",
        "id" : 613777232
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "allmende",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/jrvAYCFKUA",
        "expanded_url" : "http:\/\/wp.me\/p2Uk1l-rO",
        "display_url" : "wp.me\/p2Uk1l-rO"
      } ]
    },
    "geo" : { },
    "id_str" : "387855228998914048",
    "text" : ".@mundraub_org ist keine Einladung zum Hamstern: Blogartikel von @Erdhaftig http:\/\/t.co\/jrvAYCFKUA #allmende",
    "id" : 387855228998914048,
    "created_at" : "2013-10-09 08:21:07 +0000",
    "user" : {
      "name" : "Sebastian Kauer",
      "screen_name" : "sebastiankauer",
      "protected" : false,
      "id_str" : "154295601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1145248556\/sk_normal.jpg",
      "id" : 154295601,
      "verified" : false
    }
  },
  "id" : 387856031277416448,
  "created_at" : "2013-10-09 08:24:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722871196, 8.6276587161 ]
  },
  "id_str" : "387852477795934208",
  "text" : "\u00ABWir werden das ganze jetzt offener angehen. Also mal abwarten wann mir der Hund in die Eier bei\u00DFt weil ich was falsch gemacht habe.\u00BB",
  "id" : 387852477795934208,
  "created_at" : "2013-10-09 08:10:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387851848750997504",
  "geo" : { },
  "id_str" : "387851992418119680",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng good luck!",
  "id" : 387851992418119680,
  "in_reply_to_status_id" : 387851848750997504,
  "created_at" : "2013-10-09 08:08:15 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0047246839, 8.2884753594 ]
  },
  "id_str" : "387836661474029568",
  "text" : "\u00ABIhr seid ja noch im Bett.\u00BB \u2014 \u00ABSorry, wir mussten noch kl\u00E4ren wegen welches Missverst\u00E4ndnisses wir uns diese Woche fast trennen.\u00BB",
  "id" : 387836661474029568,
  "created_at" : "2013-10-09 07:07:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1031453466, 8.5740187958 ]
  },
  "id_str" : "387830481645215744",
  "text" : "\u00ABIn der Oberstufe hat Mathe ja nicht mehr viel mit Mathe zu tun. Sondern mit Verstehen.\u00BB",
  "id" : 387830481645215744,
  "created_at" : "2013-10-09 06:42:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387816556714921984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0069910664, 8.2831459146 ]
  },
  "id_str" : "387822775840538625",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer don\u2019t worry. For every huge failure like \u2018The War of Art\u2019 or the \u2018Ass Goblins\u2019 I find at least 3-4 books I really enjoy. :)",
  "id" : 387822775840538625,
  "in_reply_to_status_id" : 387816556714921984,
  "created_at" : "2013-10-09 06:12:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387723701858623488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644555, 8.2829684125 ]
  },
  "id_str" : "387724304584298496",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon but it might do a great case-study to publish in some obscure journal, getting me 1 step closer to the PhD!",
  "id" : 387724304584298496,
  "in_reply_to_status_id" : 387723701858623488,
  "created_at" : "2013-10-08 23:40:52 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/TKtkyqeAcj",
      "expanded_url" : "http:\/\/i.imgur.com\/mk5rbvg.gif",
      "display_url" : "i.imgur.com\/mk5rbvg.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965699, 8.282954995 ]
  },
  "id_str" : "387723753851224064",
  "text" : "How our work cluster must feel for most of the time. http:\/\/t.co\/TKtkyqeAcj",
  "id" : 387723753851224064,
  "created_at" : "2013-10-08 23:38:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387723134625132544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965699, 8.282954995 ]
  },
  "id_str" : "387723468235866113",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon if I manage to get time scheduled at the MRI you could join. Though 3 might be a crowd in that particular case. ;)",
  "id" : 387723468235866113,
  "in_reply_to_status_id" : 387723134625132544,
  "created_at" : "2013-10-08 23:37:33 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387722649709072384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965699, 8.282954995 ]
  },
  "id_str" : "387722767401234432",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon or playing guitar! ;)",
  "id" : 387722767401234432,
  "in_reply_to_status_id" : 387722649709072384,
  "created_at" : "2013-10-08 23:34:45 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/wfJY3MrWxm",
      "expanded_url" : "http:\/\/i.imgur.com\/SJ7tVZZ.jpg",
      "display_url" : "i.imgur.com\/SJ7tVZZ.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387720178282545152",
  "text" : "Every time @Senficon and I are reading from the same screen. http:\/\/t.co\/wfJY3MrWxm",
  "id" : 387720178282545152,
  "created_at" : "2013-10-08 23:24:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 3, 16 ],
      "id_str" : "19084034",
      "id" : 19084034
    }, {
      "name" : "Annalee Newitz",
      "screen_name" : "Annaleen",
      "indices" : [ 116, 125 ],
      "id_str" : "756475",
      "id" : 756475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/aVcsbSHrdb",
      "expanded_url" : "http:\/\/io9.com\/the-great-library-at-alexandria-was-destroyed-by-budget-1442659066",
      "display_url" : "io9.com\/the-great-libr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387718313172021248",
  "text" : "RT @ericmjohnson: The great library at Alexandria was destroyed by budget cuts, not fire: http:\/\/t.co\/aVcsbSHrdb by @Annaleen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Annalee Newitz",
        "screen_name" : "Annaleen",
        "indices" : [ 98, 107 ],
        "id_str" : "756475",
        "id" : 756475
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/aVcsbSHrdb",
        "expanded_url" : "http:\/\/io9.com\/the-great-library-at-alexandria-was-destroyed-by-budget-1442659066",
        "display_url" : "io9.com\/the-great-libr\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "387703849990893568",
    "geo" : { },
    "id_str" : "387718108104105984",
    "in_reply_to_user_id" : 756475,
    "text" : "The great library at Alexandria was destroyed by budget cuts, not fire: http:\/\/t.co\/aVcsbSHrdb by @Annaleen",
    "id" : 387718108104105984,
    "in_reply_to_status_id" : 387703849990893568,
    "created_at" : "2013-10-08 23:16:15 +0000",
    "in_reply_to_screen_name" : "Annaleen",
    "in_reply_to_user_id_str" : "756475",
    "user" : {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "protected" : false,
      "id_str" : "19084034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434953612825858048\/DckRYRye_normal.png",
      "id" : 19084034,
      "verified" : false
    }
  },
  "id" : 387718313172021248,
  "created_at" : "2013-10-08 23:17:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387702587736469504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387702762462801920",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Latex -&gt; M, Nitril -&gt; L, ich bin ja kein Noob. Aber dann schlabbern die Dinger immer so unangenehm!",
  "id" : 387702762462801920,
  "in_reply_to_status_id" : 387702587736469504,
  "created_at" : "2013-10-08 22:15:16 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387701189514911744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387701814319415297",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Vielleicht vom Schutz her, aber in Nitril kommt man so unglaublich schlecht rein!",
  "id" : 387701814319415297,
  "in_reply_to_status_id" : 387701189514911744,
  "created_at" : "2013-10-08 22:11:30 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cUsRvmiP3C",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2013\/10\/marsupial-species-evolved-suicidal-reproduction\/",
      "display_url" : "arstechnica.com\/science\/2013\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387698963560017920",
  "text" : "Suicidal Reproduction: Probably not due to kin selection but sperm competition &amp; precopulatory sexual selection. http:\/\/t.co\/cUsRvmiP3C",
  "id" : 387698963560017920,
  "created_at" : "2013-10-08 22:00:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387694593804091392",
  "text" : "\u00ABYour weird fetish for invertebrates!\u00BB \u2013 \u00ABThe ~99% Occupy Taxonomy!\u00BB",
  "id" : 387694593804091392,
  "created_at" : "2013-10-08 21:42:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/SlElZOgbqI",
      "expanded_url" : "http:\/\/www.nature.com\/nbt\/journal\/v31\/n10\/box\/nbt.2721_BX1.html",
      "display_url" : "nature.com\/nbt\/journal\/v3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387694061886656512",
  "text" : "Does every new biology PhD student need to learn how to program? http:\/\/t.co\/SlElZOgbqI",
  "id" : 387694061886656512,
  "created_at" : "2013-10-08 21:40:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0157795231, 8.2741608052 ]
  },
  "id_str" : "387689505345769472",
  "text" : "\u00ABDein Kopf ist so gro\u00DF. Das ist schon mal mindestens ein Grund kein Kind von dir zu bekommen.\u00BB",
  "id" : 387689505345769472,
  "created_at" : "2013-10-08 21:22:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097750128, 8.2830310799 ]
  },
  "id_str" : "387661679913603072",
  "text" : "\u00ABAuf der Konferenz will ich mir dann einen Franzosen angeln\u00BB\u2014\u00ABDen hast du dann nur f\u00FCr 3 Tage!\u00BB\u2014\u00ABDas ist das Gute. 1 Nacht w\u00FCrd mir reichen\u00BB",
  "id" : 387661679913603072,
  "created_at" : "2013-10-08 19:32:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096736609, 8.2830915334 ]
  },
  "id_str" : "387659085006794753",
  "text" : "\u00ABIch w\u00FCrde meinen Ex ja auch mal gerne kennenlernen!\u00BB",
  "id" : 387659085006794753,
  "created_at" : "2013-10-08 19:21:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387533532853059586",
  "text" : "\u00ABIch hab zuhause keine normale Textverarbeitung. Deshalb musste ich das Protokoll in meinem selbstgeschriebenem Texteditor schreiben!\u00BB",
  "id" : 387533532853059586,
  "created_at" : "2013-10-08 11:02:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/HYvjSKmbXf",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/GeneExpressionBlog\/~3\/VbHWLsOcqHo\/",
      "display_url" : "feedproxy.google.com\/~r\/GeneExpress\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172326, 8.627633 ]
  },
  "id_str" : "387521211674398721",
  "text" : "\u00ABeven a lazy man wants to know about the world. Ergo, genetics.\u00BB http:\/\/t.co\/HYvjSKmbXf",
  "id" : 387521211674398721,
  "created_at" : "2013-10-08 10:13:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hakantee",
      "screen_name" : "hakantee",
      "indices" : [ 96, 105 ],
      "id_str" : "4902835689",
      "id" : 4902835689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/dAzIKsvQju",
      "expanded_url" : "http:\/\/m.bmjopen.bmj.com\/content\/3\/9\/e003077",
      "display_url" : "m.bmjopen.bmj.com\/content\/3\/9\/e0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0027945131, 8.3245399956 ]
  },
  "id_str" : "387454350836367360",
  "text" : "The original study for the last RT on the war on drugs #openaccess  http:\/\/t.co\/dAzIKsvQju \/\/cc @hakantee",
  "id" : 387454350836367360,
  "created_at" : "2013-10-08 05:48:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096316396, 8.2829494191 ]
  },
  "id_str" : "387364021990866944",
  "text" : "\u00ABDie Katze ist gar nicht fett!\u00BB \u2014 \u00ABStimmt, die macht im Bett auch nur den Seestern!\u00BB",
  "id" : 387364021990866944,
  "created_at" : "2013-10-07 23:49:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/9ejj4y3van",
      "expanded_url" : "http:\/\/i.imgur.com\/ZwuyWEx.gif",
      "display_url" : "i.imgur.com\/ZwuyWEx.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387354993231425536",
  "text" : "We're putting the band back together. http:\/\/t.co\/9ejj4y3van",
  "id" : 387354993231425536,
  "created_at" : "2013-10-07 23:13:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "indices" : [ 3, 15 ],
      "id_str" : "7612412",
      "id" : 7612412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/YZTwumidkh",
      "expanded_url" : "http:\/\/youtu.be\/fI_xuFA18m4",
      "display_url" : "youtu.be\/fI_xuFA18m4"
    } ]
  },
  "geo" : { },
  "id_str" : "387346923122098176",
  "text" : "RT @lirontocker: Cannot be unseen. http:\/\/t.co\/YZTwumidkh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/YZTwumidkh",
        "expanded_url" : "http:\/\/youtu.be\/fI_xuFA18m4",
        "display_url" : "youtu.be\/fI_xuFA18m4"
      } ]
    },
    "geo" : { },
    "id_str" : "387346520489881600",
    "text" : "Cannot be unseen. http:\/\/t.co\/YZTwumidkh",
    "id" : 387346520489881600,
    "created_at" : "2013-10-07 22:39:41 +0000",
    "user" : {
      "name" : "Liron Tocker",
      "screen_name" : "lirontocker",
      "protected" : false,
      "id_str" : "7612412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698133259792838656\/bZcR6SJ4_normal.png",
      "id" : 7612412,
      "verified" : false
    }
  },
  "id" : 387346923122098176,
  "created_at" : "2013-10-07 22:41:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/gw37UYMCqR",
      "expanded_url" : "http:\/\/i.imgur.com\/zJts2Ap.gif",
      "display_url" : "i.imgur.com\/zJts2Ap.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387342262780563456",
  "text" : "Ich hab geh\u00F6rt in etwa so soll der n\u00E4chste Piraten-Parteitag werden http:\/\/t.co\/gw37UYMCqR",
  "id" : 387342262780563456,
  "created_at" : "2013-10-07 22:22:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/kB7dgRGQbp",
      "expanded_url" : "http:\/\/www.genome.gov\/sequencingcosts\/",
      "display_url" : "genome.gov\/sequencingcost\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387341714186588160",
  "text" : "RT @ctitusbrown: PANIC! The Genome Sequencing Costs link is NOT UP TO DATE! http:\/\/t.co\/kB7dgRGQbp #shutdown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shutdown",
        "indices" : [ 82, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/kB7dgRGQbp",
        "expanded_url" : "http:\/\/www.genome.gov\/sequencingcosts\/",
        "display_url" : "genome.gov\/sequencingcost\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387341297075240960",
    "text" : "PANIC! The Genome Sequencing Costs link is NOT UP TO DATE! http:\/\/t.co\/kB7dgRGQbp #shutdown",
    "id" : 387341297075240960,
    "created_at" : "2013-10-07 22:18:56 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 387341714186588160,
  "created_at" : "2013-10-07 22:20:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/eGnNFCJYcV",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/10\/07\/see-world-war-ii-play-out-in-7.html",
      "display_url" : "boingboing.net\/2013\/10\/07\/see\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387338751158288384",
  "text" : "See World War II play out in 7\u00A0minutes (done in MS Paint?!) http:\/\/t.co\/eGnNFCJYcV",
  "id" : 387338751158288384,
  "created_at" : "2013-10-07 22:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009678472, 8.2829871604 ]
  },
  "id_str" : "387315421600567296",
  "text" : "\u00ABRunning away. The international sign of guilt.\u00BB",
  "id" : 387315421600567296,
  "created_at" : "2013-10-07 20:36:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 70, 83 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "387296927437840384",
  "text" : "I made I huge mistake: Scrolled through the Goodreads to-read list of @PhilippBayer once again\u2026",
  "id" : 387296927437840384,
  "created_at" : "2013-10-07 19:22:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/kqquprgWuD",
      "expanded_url" : "http:\/\/instagram.com\/p\/fLLJnUhwm9\/",
      "display_url" : "instagram.com\/p\/fLLJnUhwm9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "387268571061305345",
  "text" : "8 bit make out http:\/\/t.co\/kqquprgWuD",
  "id" : 387268571061305345,
  "created_at" : "2013-10-07 17:29:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0081405868, 8.2703694421 ]
  },
  "id_str" : "387263714082443264",
  "text" : "\u00ABNichts wie weg von der Stra\u00DFe. Ich kann ja nicht so gut geradeaus laufen, nachher schubs ich dich noch drauf\u00BB",
  "id" : 387263714082443264,
  "created_at" : "2013-10-07 17:10:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/EKtsA8JcA7",
      "expanded_url" : "http:\/\/www.chick.com\/m\/reading\/tracts\/readtract.asp?stk=0046",
      "display_url" : "chick.com\/m\/reading\/trac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387253264355700736",
  "text" : "\u00ABThe intense occult training through D&amp;D\u2026\u00BB http:\/\/t.co\/EKtsA8JcA7",
  "id" : 387253264355700736,
  "created_at" : "2013-10-07 16:29:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387249666901151744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0515294341, 8.5049426666 ]
  },
  "id_str" : "387250038659117056",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well, k\u00F6nnen\u2026 \u2018I did nothing wrong\u2019, ich versteh schon.",
  "id" : 387250038659117056,
  "in_reply_to_status_id" : 387249666901151744,
  "created_at" : "2013-10-07 16:16:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387249383294504960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0619436792, 8.5248456572 ]
  },
  "id_str" : "387249567814918144",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot als ob du \u00FCberhaupt mal \u00FCben w\u00FCrdest, nice try!",
  "id" : 387249567814918144,
  "in_reply_to_status_id" : 387249383294504960,
  "created_at" : "2013-10-07 16:14:26 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.07288894, 8.6336913852 ]
  },
  "id_str" : "387247701416755200",
  "text" : "Liebe S-Bahn-Musiker: Wenn ihr immer zur Pendlerstosszeit in die Bahn springt f\u00E4llt nach maximal 3 Tagen auf das ihr genau einen Song k\u00F6nnt\u2026",
  "id" : 387247701416755200,
  "created_at" : "2013-10-07 16:07:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Queer Has No Name",
      "screen_name" : "memeticsexgod",
      "indices" : [ 0, 14 ],
      "id_str" : "1451060280",
      "id" : 1451060280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387217537559445504",
  "geo" : { },
  "id_str" : "387217722909532162",
  "in_reply_to_user_id" : 1451060280,
  "text" : "@memeticsexgod Die in meinem B\u00FCro werden gut mit Dehydration gequ\u00E4lt!",
  "id" : 387217722909532162,
  "in_reply_to_status_id" : 387217537559445504,
  "created_at" : "2013-10-07 14:07:53 +0000",
  "in_reply_to_screen_name" : "memeticsexgod",
  "in_reply_to_user_id_str" : "1451060280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387181383874916353",
  "geo" : { },
  "id_str" : "387181626930626560",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Hast du deine ganzen Graphen etwa schon eingebaut? ;)",
  "id" : 387181626930626560,
  "in_reply_to_status_id" : 387181383874916353,
  "created_at" : "2013-10-07 11:44:28 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387179777133531136",
  "geo" : { },
  "id_str" : "387180932131586048",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon dann bist du Ende der Woche ja locker bei 2\/3 :p",
  "id" : 387180932131586048,
  "in_reply_to_status_id" : 387179777133531136,
  "created_at" : "2013-10-07 11:41:42 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 3, 17 ],
      "id_str" : "16066596",
      "id" : 16066596
    }, {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 85, 100 ],
      "id_str" : "15143478",
      "id" : 15143478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387175593525399552",
  "text" : "RT @onetruecathal: If you're fighting for secularism in government and human rights, @RichardDawkins has no place in your rhetoric: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Dawkins",
        "screen_name" : "RichardDawkins",
        "indices" : [ 66, 81 ],
        "id_str" : "15143478",
        "id" : 15143478
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Ri8xc7enSD",
        "expanded_url" : "http:\/\/www.kractivist.org\/racism-in-atheism-richard-dawkins-anti-muslim-tweet\/",
        "display_url" : "kractivist.org\/racism-in-athe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "387174453387329537",
    "text" : "If you're fighting for secularism in government and human rights, @RichardDawkins has no place in your rhetoric: http:\/\/t.co\/Ri8xc7enSD",
    "id" : 387174453387329537,
    "created_at" : "2013-10-07 11:15:57 +0000",
    "user" : {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "protected" : false,
      "id_str" : "16066596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673955584920563713\/KsGsM0A5_normal.jpg",
      "id" : 16066596,
      "verified" : false
    }
  },
  "id" : 387175593525399552,
  "created_at" : "2013-10-07 11:20:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387171609658015744",
  "geo" : { },
  "id_str" : "387173240319131649",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a +49 176 213 044 66, ruf durch wenn du in Teil B, 3OG vor der T\u00FCr stehst damit ich dich reinlassen kann. :)",
  "id" : 387173240319131649,
  "in_reply_to_status_id" : 387171609658015744,
  "created_at" : "2013-10-07 11:11:08 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387171609658015744",
  "geo" : { },
  "id_str" : "387173127949524994",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Biologicum, Campus Riedberg, Geb\u00E4udeteil B, 3.OG, Max-von-Laue-Stra\u00DFe 13. U8 bis Campus Riedberg oder U3 bis Niederursel.",
  "id" : 387173127949524994,
  "in_reply_to_status_id" : 387171609658015744,
  "created_at" : "2013-10-07 11:10:41 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387171609658015744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17226371, 8.6276790502 ]
  },
  "id_str" : "387171712414285824",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a klar, wenn dir bis 17:00 Uhr erstmal weiterhilft. :)",
  "id" : 387171712414285824,
  "in_reply_to_status_id" : 387171609658015744,
  "created_at" : "2013-10-07 11:05:04 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387170554215927808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722584981, 8.6276648134 ]
  },
  "id_str" : "387170869275271168",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a ich bin so bis ~17:00 im B\u00FCro und habe einen Schreibtisch frei. Hast du noch eduroam-Credentials?",
  "id" : 387170869275271168,
  "in_reply_to_status_id" : 387170554215927808,
  "created_at" : "2013-10-07 11:01:43 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387169636699344896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722583484, 8.6276655271 ]
  },
  "id_str" : "387169709478907904",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a ja, Campus Riedberg.",
  "id" : 387169709478907904,
  "in_reply_to_status_id" : 387169636699344896,
  "created_at" : "2013-10-07 10:57:06 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723289048, 8.6276141198 ]
  },
  "id_str" : "387167065515507712",
  "text" : "\u00ABW\u00E4re schon doof, wenn du jetzt stirbst. Wo wir jetzt so viel Geld f\u00FCr die Impfungen ausgegeben haben.\u00BB",
  "id" : 387167065515507712,
  "created_at" : "2013-10-07 10:46:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723116379, 8.6276298482 ]
  },
  "id_str" : "387164274642407425",
  "text" : "\u00ABUnser Begr\u00FC\u00DFungssatz muss erweitert werden: Wir m\u00F6gen Kuchen, Bier, Pflanzen und Peitschen.\u00BB",
  "id" : 387164274642407425,
  "created_at" : "2013-10-07 10:35:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/kUynMOElWq",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskReddit\/comments\/1nug1e\/hey_reddit_how_was_life_before_the_internet\/",
      "display_url" : "reddit.com\/r\/AskReddit\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387150827858579456",
  "text" : "\"I spend my entire day browsing my Encarta CD-ROMS.\" - Hey reddit, how was life before the Internet? http:\/\/t.co\/kUynMOElWq",
  "id" : 387150827858579456,
  "created_at" : "2013-10-07 09:42:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/w3KohNPI0j",
      "expanded_url" : "http:\/\/solopoly.net\/2012\/11\/29\/riding-the-relationship-escalator-or-not\/",
      "display_url" : "solopoly.net\/2012\/11\/29\/rid\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "387144503896711168",
  "geo" : { },
  "id_str" : "387145290848817152",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju http:\/\/t.co\/w3KohNPI0j",
  "id" : 387145290848817152,
  "in_reply_to_status_id" : 387144503896711168,
  "created_at" : "2013-10-07 09:20:04 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387138137433985025",
  "text" : "Meine gr\u00F6\u00DFte work related anxiety: Das jemand pl\u00F6tzlich anf\u00E4ngt den Salzstreuer mit Salz statt Zucker zu bef\u00FCllen &amp; mir den Kaffee versaut.",
  "id" : 387138137433985025,
  "created_at" : "2013-10-07 08:51:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 101, 114 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/DhF1cPo2nB",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0073667",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387137074161123328",
  "text" : "Support Measures to Estimate the Reliability of Evol. Events Predicted by Reconciliation Methods \/cc @PhilippBayer http:\/\/t.co\/DhF1cPo2nB",
  "id" : 387137074161123328,
  "created_at" : "2013-10-07 08:47:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/34ehcxRylO",
      "expanded_url" : "http:\/\/instagram.com\/p\/fKLZfqhwi5\/",
      "display_url" : "instagram.com\/p\/fKLZfqhwi5\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "387128689810759680",
  "text" : "I'm not slacking off, I'm watching birds! @ Biologicum http:\/\/t.co\/34ehcxRylO",
  "id" : 387128689810759680,
  "created_at" : "2013-10-07 08:14:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387122154451374080",
  "text" : "\u00ABWenn ich mir die Abdr\u00FCcke an deinem Arm so anschaue f\u00E4llt mir auf: Ich sollte mal wieder zum Zahnarzt gehen.\u00BB",
  "id" : 387122154451374080,
  "created_at" : "2013-10-07 07:48:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/0o7MmK0lsN",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2013\/10\/what-science-tells-us-about-the-safety-of-genetically-modified-foods\/",
      "display_url" : "arstechnica.com\/science\/2013\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387120660540968960",
  "text" : "What science tells us about the safety of genetically modified foods http:\/\/t.co\/0o7MmK0lsN",
  "id" : 387120660540968960,
  "created_at" : "2013-10-07 07:42:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/ENT8NWkCgW",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/neuroskeptic\/2013\/10\/06\/jazz-guitar-after-brain-damage\/",
      "display_url" : "blogs.discovermagazine.com\/neuroskeptic\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "387118627645685760",
  "text" : "Jazz Guitar After Brain Damage http:\/\/t.co\/ENT8NWkCgW",
  "id" : 387118627645685760,
  "created_at" : "2013-10-07 07:34:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/edM5KHnDW8",
      "expanded_url" : "http:\/\/i.imgur.com\/No3WFty.gif",
      "display_url" : "i.imgur.com\/No3WFty.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "387110236986687488",
  "text" : "Next: http:\/\/t.co\/edM5KHnDW8",
  "id" : 387110236986687488,
  "created_at" : "2013-10-07 07:00:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386983718554198016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00959096, 8.2828145681 ]
  },
  "id_str" : "386983981331517442",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon on rare occasions tue ich das.",
  "id" : 386983981331517442,
  "in_reply_to_status_id" : 386983718554198016,
  "created_at" : "2013-10-06 22:39:05 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096234562, 8.282903502 ]
  },
  "id_str" : "386983822304505857",
  "text" : "\u00ABEr hat nicht viele Bed\u00FCrfnisse: Essen, Schlafen, aufs Klo, gestreichelt werden.\u00BB\u2014\u00ABRedest du vom Kater oder von mir?\u00BB\u2014\u00ABDu hast nie Hunger.\u00BB",
  "id" : 386983822304505857,
  "created_at" : "2013-10-06 22:38:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 10, 17 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386979481933848576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096187907, 8.2828604831 ]
  },
  "id_str" : "386979648741318656",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @lsanoj weil ich ausnahmsweise noch Unterw\u00E4sche getragen habe!",
  "id" : 386979648741318656,
  "in_reply_to_status_id" : 386979481933848576,
  "created_at" : "2013-10-06 22:21:52 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386978147482488832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096187907, 8.2828604831 ]
  },
  "id_str" : "386978312163442688",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 @Senficon nur wenn du den Stream machst. :p",
  "id" : 386978312163442688,
  "in_reply_to_status_id" : 386978147482488832,
  "created_at" : "2013-10-06 22:16:33 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386976695435403264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097154174, 8.2830161601 ]
  },
  "id_str" : "386977385335488512",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 @Senficon dann wei\u00DF ich ja was ich zur Hochzeit trage statt Jedi-Robe. ;)",
  "id" : 386977385335488512,
  "in_reply_to_status_id" : 386976695435403264,
  "created_at" : "2013-10-06 22:12:53 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386975644573114370",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097154174, 8.2830161601 ]
  },
  "id_str" : "386976183575121920",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon diesmal ist es aber ausnahmsweise nicht mein Blut!",
  "id" : 386976183575121920,
  "in_reply_to_status_id" : 386975644573114370,
  "created_at" : "2013-10-06 22:08:06 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 24, 40 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/386975644573114370\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/gGlc8wSsET",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BV7QTE2CQAANB_A.jpg",
      "id_str" : "386975644136914944",
      "id" : 386975644136914944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BV7QTE2CQAANB_A.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 716
      } ],
      "display_url" : "pic.twitter.com\/gGlc8wSsET"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386976108241227776",
  "text" : "RT @Senficon: Egal, was @gedankenstuecke anzieht, immer sind rote Flecken drauf. http:\/\/t.co\/gGlc8wSsET",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 10, 26 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/386975644573114370\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/gGlc8wSsET",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BV7QTE2CQAANB_A.jpg",
        "id_str" : "386975644136914944",
        "id" : 386975644136914944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BV7QTE2CQAANB_A.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 716
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 507
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 716
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 716
        } ],
        "display_url" : "pic.twitter.com\/gGlc8wSsET"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386975644573114370",
    "text" : "Egal, was @gedankenstuecke anzieht, immer sind rote Flecken drauf. http:\/\/t.co\/gGlc8wSsET",
    "id" : 386975644573114370,
    "created_at" : "2013-10-06 22:05:57 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 386976108241227776,
  "created_at" : "2013-10-06 22:07:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097463048, 8.2830374502 ]
  },
  "id_str" : "386974322176585728",
  "text" : "\u00ABWas ist das denn f\u00FCr ein Kleid?! Die 50er haben angerufen und gesagt du sollst zur\u00FCck an den Herd?!\u00BB",
  "id" : 386974322176585728,
  "created_at" : "2013-10-06 22:00:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096808654, 8.2830944079 ]
  },
  "id_str" : "386973584079749120",
  "text" : "\u00ABDie Katze liegt in meinem Sichtfeld.\u00BB \u2014 \u00ABUnd in meinem!\u00BB \u2014 \u00ABJammert nicht, mein Schritt liegt in ihrem Kratzfeld!\u00BB",
  "id" : 386973584079749120,
  "created_at" : "2013-10-06 21:57:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/YtWFzVcXSV",
      "expanded_url" : "http:\/\/instagram.com\/p\/fIziTthwrl\/",
      "display_url" : "instagram.com\/p\/fIziTthwrl\/"
    } ]
  },
  "geo" : { },
  "id_str" : "386935116448407552",
  "text" : "~1 kg Pleurotus ostreatus http:\/\/t.co\/YtWFzVcXSV",
  "id" : 386935116448407552,
  "created_at" : "2013-10-06 19:24:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095975291, 8.2827948291 ]
  },
  "id_str" : "386927967265644544",
  "text" : "\u00ABDas sollen Katzen sein, aber weil die Hose so spannt sehen sie mehr nach Pumas aus.\u00BB",
  "id" : 386927967265644544,
  "created_at" : "2013-10-06 18:56:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 3, 8 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/CRuz4HqPlB",
      "expanded_url" : "https:\/\/github.com\/rowanmanning\/joblint",
      "display_url" : "github.com\/rowanmanning\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386887204918030336",
  "text" : "RT @johl: Joblint: Test tech job specs for issues with sexism, culture, expectations, and recruiter fails. https:\/\/t.co\/CRuz4HqPlB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/CRuz4HqPlB",
        "expanded_url" : "https:\/\/github.com\/rowanmanning\/joblint",
        "display_url" : "github.com\/rowanmanning\/j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "386885937541955584",
    "text" : "Joblint: Test tech job specs for issues with sexism, culture, expectations, and recruiter fails. https:\/\/t.co\/CRuz4HqPlB",
    "id" : 386885937541955584,
    "created_at" : "2013-10-06 16:09:30 +0000",
    "user" : {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "protected" : false,
      "id_str" : "1147751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876909912185597952\/E61jm8M3_normal.jpg",
      "id" : 1147751,
      "verified" : false
    }
  },
  "id" : 386887204918030336,
  "created_at" : "2013-10-06 16:14:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386878645782188033",
  "text" : "Eine unter Strom stehende Sp\u00FCle vertr\u00E4gt sich super mit aus der Decke tropfendem Wasser, right?",
  "id" : 386878645782188033,
  "created_at" : "2013-10-06 15:40:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386849037926006784",
  "text" : "A couple more of those afternoons and I can start to charge for my R consulting* skills. (* randomly googling stuff)",
  "id" : 386849037926006784,
  "created_at" : "2013-10-06 13:42:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/gxi0NkR91Q",
      "expanded_url" : "http:\/\/instagram.com\/p\/fIMNuPhwub\/",
      "display_url" : "instagram.com\/p\/fIMNuPhwub\/"
    } ]
  },
  "geo" : { },
  "id_str" : "386848581363466240",
  "text" : "Nice try, Jesus. http:\/\/t.co\/gxi0NkR91Q",
  "id" : 386848581363466240,
  "created_at" : "2013-10-06 13:41:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/tXW01Ow3Tt",
      "expanded_url" : "http:\/\/instagram.com\/p\/fHw8MAhwv6\/",
      "display_url" : "instagram.com\/p\/fHw8MAhwv6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "386788607232847872",
  "text" : "Wir haben Nachwuchs! http:\/\/t.co\/tXW01Ow3Tt",
  "id" : 386788607232847872,
  "created_at" : "2013-10-06 09:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "indices" : [ 3, 12 ],
      "id_str" : "43360175",
      "id" : 43360175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MK8kJwNVg1",
      "expanded_url" : "http:\/\/j.mp\/1fS2Q4r",
      "display_url" : "j.mp\/1fS2Q4r"
    } ]
  },
  "geo" : { },
  "id_str" : "386775666517360640",
  "text" : "RT @JoonasD6: &lt;3 \"After Just Four Weeks, The Homeless Man Learning To Code Has Almost Finished His First App\" http:\/\/t.co\/MK8kJwNVg1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/MK8kJwNVg1",
        "expanded_url" : "http:\/\/j.mp\/1fS2Q4r",
        "display_url" : "j.mp\/1fS2Q4r"
      } ]
    },
    "geo" : { },
    "id_str" : "386771144000684032",
    "text" : "&lt;3 \"After Just Four Weeks, The Homeless Man Learning To Code Has Almost Finished His First App\" http:\/\/t.co\/MK8kJwNVg1",
    "id" : 386771144000684032,
    "created_at" : "2013-10-06 08:33:21 +0000",
    "user" : {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "protected" : false,
      "id_str" : "43360175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/238120339\/Pi3_150x150_normal.jpg",
      "id" : 43360175,
      "verified" : false
    }
  },
  "id" : 386775666517360640,
  "created_at" : "2013-10-06 08:51:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/fGxEFlyYlc",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/844938edba646e487dbe50a2835b0ed1\/tumblr_msml75gFSk1qm62s4o1_250.gif",
      "display_url" : "25.media.tumblr.com\/844938edba646e\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096953343, 8.2830953882 ]
  },
  "id_str" : "386769382741114880",
  "text" : "Off http:\/\/t.co\/fGxEFlyYlc",
  "id" : 386769382741114880,
  "created_at" : "2013-10-06 08:26:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suman Biswas",
      "screen_name" : "amateursuman",
      "indices" : [ 3, 16 ],
      "id_str" : "22247075",
      "id" : 22247075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386762408385331200",
  "text" : "RT @amateursuman: If F1 doesn't interest you, \nyou might find F5 refreshing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "386760610119438336",
    "text" : "If F1 doesn't interest you, \nyou might find F5 refreshing.",
    "id" : 386760610119438336,
    "created_at" : "2013-10-06 07:51:29 +0000",
    "user" : {
      "name" : "Suman Biswas",
      "screen_name" : "amateursuman",
      "protected" : false,
      "id_str" : "22247075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000677237177\/8ff4e5616cfb26ff1381653e0ec8940a_normal.jpeg",
      "id" : 22247075,
      "verified" : false
    }
  },
  "id" : 386762408385331200,
  "created_at" : "2013-10-06 07:58:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/OUHbiIGYEd",
      "expanded_url" : "http:\/\/gawker.com\/california-children-can-now-legally-have-three-parents-1441519480",
      "display_url" : "gawker.com\/california-chi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386635562645741568",
  "text" : "California Children Can Now Legally Have Three Parents http:\/\/t.co\/OUHbiIGYEd",
  "id" : 386635562645741568,
  "created_at" : "2013-10-05 23:34:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/RDES7TrCix",
      "expanded_url" : "http:\/\/instagram.com\/p\/fF7FDthwvQ\/",
      "display_url" : "instagram.com\/p\/fF7FDthwvQ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8671567179, 2.3538422585 ]
  },
  "id_str" : "386529450776883200",
  "text" : "Beware! @ Square \u00C9mile Chautemps http:\/\/t.co\/RDES7TrCix",
  "id" : 386529450776883200,
  "created_at" : "2013-10-05 16:32:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 4, 11 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/8FoHzBs6Va",
      "expanded_url" : "http:\/\/instagram.com\/p\/fFxB-OhwtR\/",
      "display_url" : "instagram.com\/p\/fFxB-OhwtR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.2079812655, 5.4239845276 ]
  },
  "id_str" : "386507658708406272",
  "text" : "F\u00FCr @TnaKng, auch wenn es nicht im Mittsommer-Gr\u00FCn ist. @ Ossuary Douaumont http:\/\/t.co\/8FoHzBs6Va",
  "id" : 386507658708406272,
  "created_at" : "2013-10-05 15:06:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386500083581485056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1065276501, 8.6930164259 ]
  },
  "id_str" : "386502078161747968",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog es ist ja nicht mal ein Geheimnis. Ich habe noch niemanden gefunden der nicht dar\u00FCber gejammert h\u00E4tte.",
  "id" : 386502078161747968,
  "in_reply_to_status_id" : 386500083581485056,
  "created_at" : "2013-10-05 14:44:10 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/GnKeLb7XhN",
      "expanded_url" : "http:\/\/instagram.com\/p\/fFmTbyBwqn\/",
      "display_url" : "instagram.com\/p\/fFmTbyBwqn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "386483998564032512",
  "text" : "Ich f\u00FChle mich so matt! http:\/\/t.co\/GnKeLb7XhN",
  "id" : 386483998564032512,
  "created_at" : "2013-10-05 13:32:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/kHkvR8Dv5k",
      "expanded_url" : "http:\/\/m.huffpost.com\/uk\/entry\/4034691?utm_hp_ref=fb&src=sp&comm_ref=false&just_reloaded=1",
      "display_url" : "m.huffpost.com\/uk\/entry\/40346\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1063716691, 8.6932195444 ]
  },
  "id_str" : "386473730295463936",
  "text" : "Seven Things You Should Know About Open Relationships (or all relationships for that matter) http:\/\/t.co\/kHkvR8Dv5k",
  "id" : 386473730295463936,
  "created_at" : "2013-10-05 12:51:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1064039395, 8.693244271 ]
  },
  "id_str" : "386471659626303488",
  "text" : "\u00ABMein Bein tut so weh!\u00BB \u2014 \u00ABNa, hast du wieder die s\u00FCdamerikanische Kampfsportart \u2018Bei\u00DFoeira\u2019 praktiziert?\u00BB",
  "id" : 386471659626303488,
  "created_at" : "2013-10-05 12:43:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/hJ0fRctPQl",
      "expanded_url" : "http:\/\/instagram.com\/p\/fFdLLThwvI\/",
      "display_url" : "instagram.com\/p\/fFdLLThwvI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.2079812655, 5.4239845276 ]
  },
  "id_str" : "386465130361655296",
  "text" : "a leurs morts @ Ossuary Douaumont http:\/\/t.co\/hJ0fRctPQl",
  "id" : 386465130361655296,
  "created_at" : "2013-10-05 12:17:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386454168430718976",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386455013037735936",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Klingt nach Hundeh\u00FCtte ;)",
  "id" : 386455013037735936,
  "in_reply_to_status_id" : 386454168430718976,
  "created_at" : "2013-10-05 11:37:09 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386450092380917761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386453599012003840",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Na klar, meine einzige Sorge ist das es in den Router tropft!",
  "id" : 386453599012003840,
  "in_reply_to_status_id" : 386450092380917761,
  "created_at" : "2013-10-05 11:31:32 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386448887936212992",
  "text" : "Und mal wieder tropft es aus einer Wohnung \u00FCber bei uns rein\u2026",
  "id" : 386448887936212992,
  "created_at" : "2013-10-05 11:12:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas",
      "screen_name" : "gheed87",
      "indices" : [ 0, 8 ],
      "id_str" : "61405159",
      "id" : 61405159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386431381775319040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386431695421206528",
  "in_reply_to_user_id" : 61405159,
  "text" : "@gheed87 Wenn dann ist sie &gt;28, ich bin seit dem 1. frischer Bachelorstudent f\u00FCr Geographie ;)",
  "id" : 386431695421206528,
  "in_reply_to_status_id" : 386431381775319040,
  "created_at" : "2013-10-05 10:04:30 +0000",
  "in_reply_to_screen_name" : "gheed87",
  "in_reply_to_user_id_str" : "61405159",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/O8ukvYcWmC",
      "expanded_url" : "http:\/\/instagram.com\/p\/fD12fbBwt_\/",
      "display_url" : "instagram.com\/p\/fD12fbBwt_\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8816422468, 2.3702162645 ]
  },
  "id_str" : "386407958634311681",
  "text" : "Guess the City of Love got sick of the fucking tourists. @ Anti-Flirt http:\/\/t.co\/O8ukvYcWmC",
  "id" : 386407958634311681,
  "created_at" : "2013-10-05 08:30:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 8, 21 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386316930031706112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009665617, 8.2829651784 ]
  },
  "id_str" : "386405505591422976",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn @PhilippBayer yes, they did just mine abstracts for p-values",
  "id" : 386405505591422976,
  "in_reply_to_status_id" : 386316930031706112,
  "created_at" : "2013-10-05 08:20:26 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 96, 103 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386289630644948992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097714505, 8.2829602528 ]
  },
  "id_str" : "386290147840770048",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, though I\u2019d love to hear how eg the reproducibility initiative views this :) @mrgunn",
  "id" : 386290147840770048,
  "in_reply_to_status_id" : 386289630644948992,
  "created_at" : "2013-10-05 00:42:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "indices" : [ 3, 10 ],
      "id_str" : "47876842",
      "id" : 47876842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/wlLT8ScgAc",
      "expanded_url" : "http:\/\/wp.me\/p3walV-76",
      "display_url" : "wp.me\/p3walV-76"
    } ]
  },
  "geo" : { },
  "id_str" : "386289123050659840",
  "text" : "RT @brembs: Science Magazine rejects data, publishes anecdote http:\/\/t.co\/wlLT8ScgAc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/wlLT8ScgAc",
        "expanded_url" : "http:\/\/wp.me\/p3walV-76",
        "display_url" : "wp.me\/p3walV-76"
      } ]
    },
    "geo" : { },
    "id_str" : "386026577504374784",
    "text" : "Science Magazine rejects data, publishes anecdote http:\/\/t.co\/wlLT8ScgAc",
    "id" : 386026577504374784,
    "created_at" : "2013-10-04 07:14:42 +0000",
    "user" : {
      "name" : "Bj\u00F6rn Brembs",
      "screen_name" : "brembs",
      "protected" : false,
      "id_str" : "47876842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524937570984013824\/uPSUsTcU_normal.png",
      "id" : 47876842,
      "verified" : false
    }
  },
  "id" : 386289123050659840,
  "created_at" : "2013-10-05 00:37:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386287033028599808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096793334, 8.282970814 ]
  },
  "id_str" : "386287522583941120",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer which makes it a bit useless IMHO. Correctly refuting H0 but getting wrong conclusions out of it doesn\u2019t qual. for \u2018accurate",
  "id" : 386287522583941120,
  "in_reply_to_status_id" : 386287033028599808,
  "created_at" : "2013-10-05 00:31:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386285224960602112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095522637, 8.2832231931 ]
  },
  "id_str" : "386286789960691712",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but that\u2019s probably more of a philosophy of science\/stats debate. Rejecting H0 might be true, but not for cause you thought.",
  "id" : 386286789960691712,
  "in_reply_to_status_id" : 386285224960602112,
  "created_at" : "2013-10-05 00:28:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386285224960602112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0100711873, 8.2824756112 ]
  },
  "id_str" : "386285532118257664",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer just as everything alive goes extinct. :p",
  "id" : 386285532118257664,
  "in_reply_to_status_id" : 386285224960602112,
  "created_at" : "2013-10-05 00:23:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386285224960602112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096198218, 8.2832237799 ]
  },
  "id_str" : "386285464841625600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I actually find that quite low. From a science evolution point of view most things turn out to be somewhat wrong in the end.",
  "id" : 386285464841625600,
  "in_reply_to_status_id" : 386285224960602112,
  "created_at" : "2013-10-05 00:23:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Berufsquerulant",
      "screen_name" : "Stefan51278",
      "indices" : [ 0, 12 ],
      "id_str" : "18631049",
      "id" : 18631049
    }, {
      "name" : "\u00D0aniel Schwerd",
      "screen_name" : "netnrd",
      "indices" : [ 13, 20 ],
      "id_str" : "88916809",
      "id" : 88916809
    }, {
      "name" : "das corax",
      "screen_name" : "coraxaroc",
      "indices" : [ 21, 31 ],
      "id_str" : "16958590",
      "id" : 16958590
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 32, 39 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 40, 49 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386273134443511810",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096168882, 8.2831024937 ]
  },
  "id_str" : "386273611327471616",
  "in_reply_to_user_id" : 18631049,
  "text" : "@Stefan51278 @netnrd @coraxaroc @CaeVye @Dave_Kay jetzt fehlt nur noch das 1000-j\u00E4hrige Reich und wir sind alle Etikettenschwindel durch?",
  "id" : 386273611327471616,
  "in_reply_to_status_id" : 386273134443511810,
  "created_at" : "2013-10-04 23:36:20 +0000",
  "in_reply_to_screen_name" : "Stefan51278",
  "in_reply_to_user_id_str" : "18631049",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 3, 18 ],
      "id_str" : "76013938",
      "id" : 76013938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/BR0Dew7e7p",
      "expanded_url" : "http:\/\/s.shr.lc\/1a00FTV",
      "display_url" : "s.shr.lc\/1a00FTV"
    } ]
  },
  "geo" : { },
  "id_str" : "386266503194370048",
  "text" : "RT @john_s_wilkins: 9 Strategies For Oppressive Polyamory | - http:\/\/t.co\/BR0Dew7e7p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/BR0Dew7e7p",
        "expanded_url" : "http:\/\/s.shr.lc\/1a00FTV",
        "display_url" : "s.shr.lc\/1a00FTV"
      } ]
    },
    "geo" : { },
    "id_str" : "386265520376643584",
    "text" : "9 Strategies For Oppressive Polyamory | - http:\/\/t.co\/BR0Dew7e7p",
    "id" : 386265520376643584,
    "created_at" : "2013-10-04 23:04:11 +0000",
    "user" : {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "protected" : false,
      "id_str" : "76013938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852294288838807552\/FZpeLbxA_normal.jpg",
      "id" : 76013938,
      "verified" : false
    }
  },
  "id" : 386266503194370048,
  "created_at" : "2013-10-04 23:08:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "das corax",
      "screen_name" : "coraxaroc",
      "indices" : [ 0, 10 ],
      "id_str" : "16958590",
      "id" : 16958590
    }, {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 11, 18 ],
      "id_str" : "31104704",
      "id" : 31104704
    }, {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 19, 28 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/hFrzolf10G",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/German_tank_problem",
      "display_url" : "en.m.wikipedia.org\/wiki\/German_ta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "386261882606473216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096320266, 8.2829803042 ]
  },
  "id_str" : "386262270550220800",
  "in_reply_to_user_id" : 16958590,
  "text" : "@coraxaroc @CaeVye @Dave_Kay und man kann sogar quantifizieren wieviel mehr ;) http:\/\/t.co\/hFrzolf10G",
  "id" : 386262270550220800,
  "in_reply_to_status_id" : 386261882606473216,
  "created_at" : "2013-10-04 22:51:16 +0000",
  "in_reply_to_screen_name" : "coraxaroc",
  "in_reply_to_user_id_str" : "16958590",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/0mePKyt257",
      "expanded_url" : "http:\/\/imgur.com\/a\/xq2eN",
      "display_url" : "imgur.com\/a\/xq2eN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386254377318879232",
  "text" : "Stoned Dogs http:\/\/t.co\/0mePKyt257",
  "id" : 386254377318879232,
  "created_at" : "2013-10-04 22:19:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/AigPCVujCY",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=KLkpV1NaP7o",
      "display_url" : "youtube.com\/watch?v=KLkpV1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096473775, 8.2829867875 ]
  },
  "id_str" : "386233317328453632",
  "text" : "I wasn\u2019t aware that Johnny Cash actually managed to do an even more passive-aggressive take on \u00ABDon\u2019t Think Twice\u00BB http:\/\/t.co\/AigPCVujCY",
  "id" : 386233317328453632,
  "created_at" : "2013-10-04 20:56:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Robison",
      "screen_name" : "OmicsOmicsBlog",
      "indices" : [ 0, 15 ],
      "id_str" : "116867280",
      "id" : 116867280
    }, {
      "name" : "David \u2603\uFE0FBaltrus \uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85\uD83C\uDF85",
      "screen_name" : "surt_lab",
      "indices" : [ 16, 25 ],
      "id_str" : "155230346",
      "id" : 155230346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386199839697956864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618634, 8.2829649734 ]
  },
  "id_str" : "386202580902481920",
  "in_reply_to_user_id" : 116867280,
  "text" : "@OmicsOmicsBlog @surt_lab that\u2019s true for all models :)",
  "id" : 386202580902481920,
  "in_reply_to_status_id" : 386199839697956864,
  "created_at" : "2013-10-04 18:54:05 +0000",
  "in_reply_to_screen_name" : "OmicsOmicsBlog",
  "in_reply_to_user_id_str" : "116867280",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/1MEYwPxDw1",
      "expanded_url" : "http:\/\/www.biomedcentral.com\/1471-2164\/14\/675\/abstract#",
      "display_url" : "biomedcentral.com\/1471-2164\/14\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386138586392719361",
  "text" : "Speaking of assemblies: Efficient and accurate whole genome assembly and methylome profiling of E. coli http:\/\/t.co\/1MEYwPxDw1",
  "id" : 386138586392719361,
  "created_at" : "2013-10-04 14:39:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386135581568151552",
  "text" : "all genome assemblies are wrong, but some are useful\u2026",
  "id" : 386135581568151552,
  "created_at" : "2013-10-04 14:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/TKodpO3LWb",
      "expanded_url" : "http:\/\/biostatistics.oxfordjournals.org\/content\/early\/2013\/09\/24\/biostatistics.kxt007",
      "display_url" : "biostatistics.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386132565838409730",
  "text" : "An estimate of the science-wise false discovery rate and application to the top medical literature http:\/\/t.co\/TKodpO3LWb \/cc @PhilippBayer",
  "id" : 386132565838409730,
  "created_at" : "2013-10-04 14:15:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/7DRZx6OQcW",
      "expanded_url" : "http:\/\/bib.oxfordjournals.org\/content\/early\/2013\/09\/24\/bib.bbt069",
      "display_url" : "bib.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386123100946849792",
  "text" : "Three-stage quality control strategies for DNA re-sequencing data http:\/\/t.co\/7DRZx6OQcW",
  "id" : 386123100946849792,
  "created_at" : "2013-10-04 13:38:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/fHs9iszagk",
      "expanded_url" : "http:\/\/asofterworld.com\/index.php?id=1005",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386122630790512641",
  "text" : "We'll always have your total ignorance of Casablanca quotes http:\/\/t.co\/fHs9iszagk",
  "id" : 386122630790512641,
  "created_at" : "2013-10-04 13:36:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/11rxysju1K",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0075110",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386109679530569728",
  "text" : "Evidence of Coat Color Variation Sheds New Light on Ancient Canids http:\/\/t.co\/11rxysju1K",
  "id" : 386109679530569728,
  "created_at" : "2013-10-04 12:44:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ro Bot Dylan",
      "screen_name" : "ro_bot_dylan",
      "indices" : [ 3, 16 ],
      "id_str" : "200272047",
      "id" : 200272047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386100223111467008",
  "text" : "RT @ro_bot_dylan: He went to get the hangin' judge, but the hangin' judge was drunk, As the leading actor hurried by in the costume of a mo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/unahormiga.com\/?lang=en\" rel=\"nofollow\"\u003ESingingBob\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385479491822579712",
    "text" : "He went to get the hangin' judge, but the hangin' judge was drunk, As the leading actor hurried by in the costume of a monk.",
    "id" : 385479491822579712,
    "created_at" : "2013-10-02 19:00:47 +0000",
    "user" : {
      "name" : "Ro Bot Dylan",
      "screen_name" : "ro_bot_dylan",
      "protected" : false,
      "id_str" : "200272047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1143638857\/bobdylan_normal.JPG",
      "id" : 200272047,
      "verified" : false
    }
  },
  "id" : 386100223111467008,
  "created_at" : "2013-10-04 12:07:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 11, 18 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386097468813103104",
  "geo" : { },
  "id_str" : "386097843284373504",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Gurdur 'ich arbeite doch an Flechten, deshalb sind Verflechtungen in die SciCom-Szene sehr wichtig f\u00FCr mich'?",
  "id" : 386097843284373504,
  "in_reply_to_status_id" : 386097468813103104,
  "created_at" : "2013-10-04 11:57:53 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 11, 18 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386093756359127040",
  "geo" : { },
  "id_str" : "386094354286116864",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Gurdur Nein, werde ich gleich mal, aber das ist weniger unser Thema. :p",
  "id" : 386094354286116864,
  "in_reply_to_status_id" : 386093756359127040,
  "created_at" : "2013-10-04 11:44:02 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 11, 18 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386092197885788160",
  "geo" : { },
  "id_str" : "386092560336158720",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Gurdur Okay, bis dahin sollte ich das auch entscheiden k\u00F6nnen. Ich kann das glaube ich nicht als Business-Trip abrechnen ;)",
  "id" : 386092560336158720,
  "in_reply_to_status_id" : 386092197885788160,
  "created_at" : "2013-10-04 11:36:54 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 11, 18 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386091606732177408",
  "geo" : { },
  "id_str" : "386092111264612352",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Gurdur Ich muss mal meine Reisekasse checken, Montag ist noch mal Ticketverkauf, oder?",
  "id" : 386092111264612352,
  "in_reply_to_status_id" : 386091606732177408,
  "created_at" : "2013-10-04 11:35:07 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 111, 120 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/x67OwO9DcV",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0075637",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386060083315998720",
  "text" : "The Role of Conspiracist Ideation and Worldviews in Predicting Rejection of Science http:\/\/t.co\/x67OwO9DcV \/cc @Senficon",
  "id" : 386060083315998720,
  "created_at" : "2013-10-04 09:27:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Voll dufter Typ",
      "screen_name" : "supaheld",
      "indices" : [ 27, 36 ],
      "id_str" : "52670399",
      "id" : 52670399
    }, {
      "name" : "Piratenpartei",
      "screen_name" : "Piratenpartei",
      "indices" : [ 56, 70 ],
      "id_str" : "14341194",
      "id" : 14341194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Iq4O6hifwH",
      "expanded_url" : "http:\/\/www.piratenpartei-frankfurt.de\/content\/europa-wo-geht-es-hin-ein-interview-mit-julia-reda",
      "display_url" : "piratenpartei-frankfurt.de\/content\/europa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386057604146798593",
  "text" : "RT @Senficon: Ich habe mit @supaheld \u00FCber die Pl\u00E4ne der @Piratenpartei f\u00FCr Europa gesprochen: http:\/\/t.co\/Iq4O6hifwH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Voll dufter Typ",
        "screen_name" : "supaheld",
        "indices" : [ 13, 22 ],
        "id_str" : "52670399",
        "id" : 52670399
      }, {
        "name" : "Piratenpartei",
        "screen_name" : "Piratenpartei",
        "indices" : [ 42, 56 ],
        "id_str" : "14341194",
        "id" : 14341194
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/Iq4O6hifwH",
        "expanded_url" : "http:\/\/www.piratenpartei-frankfurt.de\/content\/europa-wo-geht-es-hin-ein-interview-mit-julia-reda",
        "display_url" : "piratenpartei-frankfurt.de\/content\/europa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "386052620344758272",
    "text" : "Ich habe mit @supaheld \u00FCber die Pl\u00E4ne der @Piratenpartei f\u00FCr Europa gesprochen: http:\/\/t.co\/Iq4O6hifwH",
    "id" : 386052620344758272,
    "created_at" : "2013-10-04 08:58:11 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 386057604146798593,
  "created_at" : "2013-10-04 09:18:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/toDEJ6I3wl",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3132",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386057403415789568",
  "text" : "True story! Well, nearly: The Triassic is a period within the Mesozoic Era\u2026 http:\/\/t.co\/toDEJ6I3wl",
  "id" : 386057403415789568,
  "created_at" : "2013-10-04 09:17:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/OHyt3AznWW",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1439",
      "display_url" : "michaeleisen.org\/blog\/?p=1439"
    } ]
  },
  "geo" : { },
  "id_str" : "386055341349158912",
  "text" : "\u00ABthe lesson people should take home from this story not that open access is  bad, but that peer review is a joke\u00BB http:\/\/t.co\/OHyt3AznWW",
  "id" : 386055341349158912,
  "created_at" : "2013-10-04 09:09:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/oydW2kDd2J",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1022",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "386053238715187202",
  "text" : "I can explain that! http:\/\/t.co\/oydW2kDd2J",
  "id" : 386053238715187202,
  "created_at" : "2013-10-04 09:00:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386047435866648576",
  "geo" : { },
  "id_str" : "386047640552488960",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara oh dear, and I hoped that those days would be over after moving out of the Siesmayer!",
  "id" : 386047640552488960,
  "in_reply_to_status_id" : 386047435866648576,
  "created_at" : "2013-10-04 08:38:24 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386046022319079424",
  "geo" : { },
  "id_str" : "386046250761453568",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach shorthand f\u00FCr 'anstrengend aber rewarding' ;)",
  "id" : 386046250761453568,
  "in_reply_to_status_id" : 386046022319079424,
  "created_at" : "2013-10-04 08:32:53 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 55, 66 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096921971, 8.2832271849 ]
  },
  "id_str" : "386045611675746304",
  "text" : "\u00ABWie war die Fahrt?\u00BB \u2014 \u00ABErinnerst du dich, wie ich mit @herrurbach zum Netzpolitischem Kongress gefahren bin?\u00BB \u2014 \u00ABOh, hier ist ein Drink\u2026\u00BB",
  "id" : 386045611675746304,
  "created_at" : "2013-10-04 08:30:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386042240411631616",
  "geo" : { },
  "id_str" : "386042921977266176",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara at the GVS?",
  "id" : 386042921977266176,
  "in_reply_to_status_id" : 386042240411631616,
  "created_at" : "2013-10-04 08:19:39 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386042660546310144",
  "text" : "\u00ABMein gr\u00F6\u00DFtes Problem sitzt zuhause\u2026\u00BB \u2013 \u00ABIch hoffe es hat nicht vier Beine!\u00BB",
  "id" : 386042660546310144,
  "created_at" : "2013-10-04 08:18:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386020281866649600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1021996556, 8.5436880462 ]
  },
  "id_str" : "386020584569991168",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, Louder Than Hell is great so far. Basically what I hoped Choosing Death would be.",
  "id" : 386020584569991168,
  "in_reply_to_status_id" : 386020281866649600,
  "created_at" : "2013-10-04 06:50:53 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386013766443233280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045185123, 8.3505827151 ]
  },
  "id_str" : "386014029762011136",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yup, right. Think it was gifted along the StrataRx participation.",
  "id" : 386014029762011136,
  "in_reply_to_status_id" : 386013766443233280,
  "created_at" : "2013-10-04 06:24:51 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385579711364997120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098625618, 8.2825532276 ]
  },
  "id_str" : "386006624424710144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, I already have a copy of hacking healthcare (and even read it iirc) ;)",
  "id" : 386006624424710144,
  "in_reply_to_status_id" : 385579711364997120,
  "created_at" : "2013-10-04 05:55:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/n9JYGvyotj",
      "expanded_url" : "http:\/\/instagram.com\/p\/fBbMRUhwgI\/",
      "display_url" : "instagram.com\/p\/fBbMRUhwgI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "385896453643988993",
  "text" : "\u00ABIn Nied spr\u00FChen sie sogar Westernhagen-Lyrics!\u00BB http:\/\/t.co\/n9JYGvyotj",
  "id" : 385896453643988993,
  "created_at" : "2013-10-03 22:37:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny Haeusler",
      "screen_name" : "spreeblick",
      "indices" : [ 8, 19 ],
      "id_str" : "3782931",
      "id" : 3782931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/RzoWdyNSAJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/fBGklEhwvV\/",
      "display_url" : "instagram.com\/p\/fBGklEhwvV\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.2079812655, 5.4239845276 ]
  },
  "id_str" : "385851195174436864",
  "text" : "\u00ABDieser @spreeblick ist auch \u00FCberall!\u00BB @ Ossuary Douaumont http:\/\/t.co\/RzoWdyNSAJ",
  "id" : 385851195174436864,
  "created_at" : "2013-10-03 19:37:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/1JrRjwxRxi",
      "expanded_url" : "http:\/\/instagram.com\/p\/e-We6ihwu3\/",
      "display_url" : "instagram.com\/p\/e-We6ihwu3\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8701666531, 2.32847929 ]
  },
  "id_str" : "385464019135787008",
  "text" : "\u0394 @ L'Olympia http:\/\/t.co\/1JrRjwxRxi",
  "id" : 385464019135787008,
  "created_at" : "2013-10-02 17:59:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8841852511, 2.3674641257 ]
  },
  "id_str" : "385419738320756736",
  "text" : "\u00ABWerden andere Paare auch so angeschaut beim knutschen? Oder ist es bei uns wegen der Mischung aus deinem Hobo-tum &amp; meinem \u00D6komuttistyle?\u00BB",
  "id" : 385419738320756736,
  "created_at" : "2013-10-02 15:03:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/OLJFVuHJQ6",
      "expanded_url" : "http:\/\/instagram.com\/p\/e9qPDLBwma\/",
      "display_url" : "instagram.com\/p\/e9qPDLBwma\/"
    } ]
  },
  "geo" : { },
  "id_str" : "385366549915521024",
  "text" : "\u00ABSoll das Buddha oder Jabba the Hutt darstellen?\u00BB http:\/\/t.co\/OLJFVuHJQ6",
  "id" : 385366549915521024,
  "created_at" : "2013-10-02 11:31:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "385348305766465537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8835249263, 2.3673778782 ]
  },
  "id_str" : "385364833165910016",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich vielleicht auf dem R\u00FCckweg. Hatte gestern meine H\u00E4nde lieber am Steuer. ;)",
  "id" : 385364833165910016,
  "in_reply_to_status_id" : 385348305766465537,
  "created_at" : "2013-10-02 11:25:10 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/zpw4QroDgx",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Barzy-sur-Marne#Sites_and_Monuments",
      "display_url" : "en.wikipedia.org\/wiki\/Barzy-sur\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8835381279, 2.3673895977 ]
  },
  "id_str" : "385346946682343424",
  "text" : "TIL: Der Monument-Hinweiser bei Ch\u00E2teau-Thierry zeigt doch nicht wie Eichh\u00F6rnchen &amp; Storch sich eine Bong teilen. http:\/\/t.co\/zpw4QroDgx",
  "id" : 385346946682343424,
  "created_at" : "2013-10-02 10:14:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8835403162, 2.3673738525 ]
  },
  "id_str" : "385337470696833024",
  "text" : "\u00ABIch sehe sogar eine zweite Katze!\u00BB \u2014 \u00ABDas ist ein Pl\u00FCsch-Panda\u2026\u00BB",
  "id" : 385337470696833024,
  "created_at" : "2013-10-02 09:36:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.8835268668, 2.3673473327 ]
  },
  "id_str" : "385328999515578369",
  "text" : "\u00ABHat sie gerade wirklich \u2018nehmen sie die sechste Ausfahrt Richtung Stalingrad\u2019 gesagt?\u00BB",
  "id" : 385328999515578369,
  "created_at" : "2013-10-02 09:02:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045190008, 8.3507389639 ]
  },
  "id_str" : "385190936395128832",
  "text" : "\u00ABThey were saying we can\u2019t play that loud, and we were saying, \u2018Yes you can. All you have to do is turn up the amplifier, you idiot.\u2019\u00BB",
  "id" : 385190936395128832,
  "created_at" : "2013-10-01 23:54:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/vF3cWWgl5c",
      "expanded_url" : "http:\/\/instagram.com\/p\/e61tAnBwh9\/",
      "display_url" : "instagram.com\/p\/e61tAnBwh9\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.174465742, 8.6284089088 ]
  },
  "id_str" : "384969541098672128",
  "text" : "Halb Batman zu Verschenken @ Otto-Stern-Zentrum http:\/\/t.co\/vF3cWWgl5c",
  "id" : 384969541098672128,
  "created_at" : "2013-10-01 09:14:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384962955038580736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722793835, 8.6276634486 ]
  },
  "id_str" : "384963716955262976",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer which leads them to scp around their thesis TeX-files and of course it happens that they overwrite their latest revisions. :)",
  "id" : 384963716955262976,
  "in_reply_to_status_id" : 384962955038580736,
  "created_at" : "2013-10-01 08:51:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384962955038580736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722793835, 8.6276634486 ]
  },
  "id_str" : "384963335990808576",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my students had to use svn in the past and now think all version control sucks and is useless. :p",
  "id" : 384963335990808576,
  "in_reply_to_status_id" : 384962955038580736,
  "created_at" : "2013-10-01 08:49:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384960600708632576",
  "geo" : { },
  "id_str" : "384962412660551680",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer did you include version control? The complete lack of understanding of it around here baffles me again and again. ;)",
  "id" : 384962412660551680,
  "in_reply_to_status_id" : 384960600708632576,
  "created_at" : "2013-10-01 08:46:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/JJXMQ7UV2I",
      "expanded_url" : "http:\/\/www.ln.edu.hk\/philoso\/staff\/rowbottom\/KvP.pdf",
      "display_url" : "ln.edu.hk\/philoso\/staff\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384954538429382656",
  "text" : "RT @PhilippBayer: \"Kuhn vs. Popper on Criticism and Dogmatism in Science: A Resolution at the Group Level\" http:\/\/t.co\/JJXMQ7UV2I cc @gedan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 115, 131 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/JJXMQ7UV2I",
        "expanded_url" : "http:\/\/www.ln.edu.hk\/philoso\/staff\/rowbottom\/KvP.pdf",
        "display_url" : "ln.edu.hk\/philoso\/staff\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "384953781839859712",
    "text" : "\"Kuhn vs. Popper on Criticism and Dogmatism in Science: A Resolution at the Group Level\" http:\/\/t.co\/JJXMQ7UV2I cc @gedankenstuecke",
    "id" : 384953781839859712,
    "created_at" : "2013-10-01 08:11:48 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 384954538429382656,
  "created_at" : "2013-10-01 08:14:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "384953781839859712",
  "geo" : { },
  "id_str" : "384954042763313152",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Sexy, thanks!",
  "id" : 384954042763313152,
  "in_reply_to_status_id" : 384953781839859712,
  "created_at" : "2013-10-01 08:12:50 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/PjNob4IFca",
      "expanded_url" : "http:\/\/www.nybooks.com\/articles\/archives\/2013\/sep\/26\/doctor-who-made-revolution\/?pagination=false",
      "display_url" : "nybooks.com\/articles\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384944417523519489",
  "text" : "The Doctor Who Made a Revolution http:\/\/t.co\/PjNob4IFca",
  "id" : 384944417523519489,
  "created_at" : "2013-10-01 07:34:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ghHP3tsWa2",
      "expanded_url" : "http:\/\/egtheory.wordpress.com\/2013\/09\/30\/bounded-rationality\/",
      "display_url" : "egtheory.wordpress.com\/2013\/09\/30\/bou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384942011637178368",
  "text" : "\u00ABto lull you into a false sense of security before overrunning you with mathematics\u00BB On Bounded Rationality http:\/\/t.co\/ghHP3tsWa2",
  "id" : 384942011637178368,
  "created_at" : "2013-10-01 07:25:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/NV6rqNzjIO",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1020",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "384939603787931648",
  "text" : "I will never lie to you! http:\/\/t.co\/NV6rqNzjIO",
  "id" : 384939603787931648,
  "created_at" : "2013-10-01 07:15:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0045190008, 8.3507389639 ]
  },
  "id_str" : "384910897069948928",
  "text" : "\u00ABI learnt a lot about performing working as a roadie for Hendrix. And that\u2019s where I learnt how to function on five hits of acid.\u00BB",
  "id" : 384910897069948928,
  "created_at" : "2013-10-01 05:21:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/uWFXlOJVci",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=y3AQXtqY0Es&feature=youtu.be&t=5m58s",
      "display_url" : "youtube.com\/watch?v=y3AQXt\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658115, 8.282964355 ]
  },
  "id_str" : "384816488856952832",
  "text" : "\u00ABWhy, sure, I bet I can play this riff for at least 3 minutes without falling asleep!\u00BB http:\/\/t.co\/uWFXlOJVci",
  "id" : 384816488856952832,
  "created_at" : "2013-09-30 23:06:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/oYMeSmZwhI",
      "expanded_url" : "http:\/\/i.imgur.com\/6hLGAMV.jpg",
      "display_url" : "i.imgur.com\/6hLGAMV.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658115, 8.282964355 ]
  },
  "id_str" : "384811817807384576",
  "text" : "Who wouldn\u2019t love R2-D2! http:\/\/t.co\/oYMeSmZwhI",
  "id" : 384811817807384576,
  "created_at" : "2013-09-30 22:47:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/2LO4Q6NRGL",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/09\/30\/twitter-party-gameprisoners.html",
      "display_url" : "boingboing.net\/2013\/09\/30\/twi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658115, 8.282964355 ]
  },
  "id_str" : "384807423091146753",
  "text" : "Things you probably don\u2019t want to play with me: Twitter party game\/Prisoners' Dilemma \"I Eat\u00A0Poo\" http:\/\/t.co\/2LO4Q6NRGL",
  "id" : 384807423091146753,
  "created_at" : "2013-09-30 22:30:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/TrmOc7vArx",
      "expanded_url" : "http:\/\/blogs.hbr.org\/2012\/01\/to-do-lists-dont-work\/",
      "display_url" : "blogs.hbr.org\/2012\/01\/to-do-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658115, 8.282964355 ]
  },
  "id_str" : "384806203786002432",
  "text" : "\u00ABStop making to-do lists. They\u2019re simply setting you up for failure and frustration\u00BB http:\/\/t.co\/TrmOc7vArx",
  "id" : 384806203786002432,
  "created_at" : "2013-09-30 22:25:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/hW44NdzzD5",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/62743401128\/optimizing-workflow",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/627434011\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096574317, 8.2830582667 ]
  },
  "id_str" : "384804524189581312",
  "text" : "Every bash-batch-scripting-attempt http:\/\/t.co\/hW44NdzzD5",
  "id" : 384804524189581312,
  "created_at" : "2013-09-30 22:18:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096574317, 8.2830582667 ]
  },
  "id_str" : "384801607319564288",
  "text" : "\u00ABGibt es was neues bei dir?\u00BB \u2013 \u00ABJa, dass du mich nicht verl\u00E4sst ist mein neues Worst-Case-Szenario.\u00BB",
  "id" : 384801607319564288,
  "created_at" : "2013-09-30 22:07:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]