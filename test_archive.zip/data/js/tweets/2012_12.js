Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/CWj4VSq8",
      "expanded_url" : "http:\/\/j.mp\/WWGPEl",
      "display_url" : "j.mp\/WWGPEl"
    } ]
  },
  "geo" : { },
  "id_str" : "285876972666617856",
  "text" : "Ghostly sex stories: \u00ABPeople would go down to the Palermo Catacombs and treat him as the patron saint of big cocks.\u00BB http:\/\/t.co\/CWj4VSq8",
  "id" : 285876972666617856,
  "created_at" : "2012-12-31 22:35:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nickdjones",
      "screen_name" : "nickdjones",
      "indices" : [ 0, 11 ],
      "id_str" : "7988572",
      "id" : 7988572
    }, {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 12, 24 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285875505662668801",
  "geo" : { },
  "id_str" : "285876032291106816",
  "in_reply_to_user_id" : 7988572,
  "text" : "@nickdjones @bengoldacre after that reading it feels like a tough battle to fight.",
  "id" : 285876032291106816,
  "in_reply_to_status_id" : 285875505662668801,
  "created_at" : "2012-12-31 22:32:12 +0000",
  "in_reply_to_screen_name" : "nickdjones",
  "in_reply_to_user_id_str" : "7988572",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285848315961171968",
  "text" : "\u00ABAha, wenn ich also mit Katzen einem Harem gr\u00FCnde hast du nichts dagegen?\u00BB\u2014\u00ABNein, hab ich nicht.\u00BB\u2014\u00ABSpeziestin!\u00BB",
  "id" : 285848315961171968,
  "created_at" : "2012-12-31 20:42:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solo12",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285845211748397056",
  "geo" : { },
  "id_str" : "285845816919326720",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg as you also were at #solo12 you prob. won\u2019t learn too much new. But the condensed form will transform you into open science hulk :)",
  "id" : 285845816919326720,
  "in_reply_to_status_id" : 285845211748397056,
  "created_at" : "2012-12-31 20:32:08 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 19, 31 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285843944972115968",
  "text" : "Now: Bad Pharma by @bengoldacre Only read the first 10% so far but I\u2019m already in the mood for an evening of epic ranting about bad science.",
  "id" : 285843944972115968,
  "created_at" : "2012-12-31 20:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/3IuqaGjb",
      "expanded_url" : "http:\/\/instagr.am\/p\/T6JdiPBwgE\/",
      "display_url" : "instagr.am\/p\/T6JdiPBwgE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "285793253155016705",
  "text" : "Mock Duck (aka fried gluten with a slight texture) http:\/\/t.co\/3IuqaGjb",
  "id" : 285793253155016705,
  "created_at" : "2012-12-31 17:03:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285788688112312321",
  "text" : "RT @leonidkruglyak: A parody-worthy confused mishmash of religion, evoluitionary psych and neuroscience: The Moral Animal http:\/\/t.co\/qO ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/qOvsvVgm",
        "expanded_url" : "http:\/\/nyti.ms\/Y57TAp",
        "display_url" : "nyti.ms\/Y57TAp"
      } ]
    },
    "geo" : { },
    "id_str" : "285788367822671872",
    "text" : "A parody-worthy confused mishmash of religion, evoluitionary psych and neuroscience: The Moral Animal http:\/\/t.co\/qOvsvVgm",
    "id" : 285788367822671872,
    "created_at" : "2012-12-31 16:43:51 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 285788688112312321,
  "created_at" : "2012-12-31 16:45:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/8mzeQ2g3",
      "expanded_url" : "http:\/\/j.mp\/ZPlHFP",
      "display_url" : "j.mp\/ZPlHFP"
    } ]
  },
  "geo" : { },
  "id_str" : "285780769052430339",
  "text" : "Ethical Challenges for Clinical Genome Sequencing http:\/\/t.co\/8mzeQ2g3",
  "id" : 285780769052430339,
  "created_at" : "2012-12-31 16:13:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285771752053809154",
  "geo" : { },
  "id_str" : "285774064507817984",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ \u00ABDie Stadt in der erstaunlich viele ICs halten\u00BB ;)",
  "id" : 285774064507817984,
  "in_reply_to_status_id" : 285771752053809154,
  "created_at" : "2012-12-31 15:47:01 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "indices" : [ 0, 13 ],
      "id_str" : "26374915",
      "id" : 26374915
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 14, 21 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285768683018674177",
  "geo" : { },
  "id_str" : "285768927290748930",
  "in_reply_to_user_id" : 26374915,
  "text" : "@barrycburton @fitbit ah thanks, looking forward to it :-)",
  "id" : 285768927290748930,
  "in_reply_to_status_id" : 285768683018674177,
  "created_at" : "2012-12-31 15:26:36 +0000",
  "in_reply_to_screen_name" : "barrycburton",
  "in_reply_to_user_id_str" : "26374915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prof Jeff Jarvis",
      "screen_name" : "ProfJeffJarvis",
      "indices" : [ 3, 18 ],
      "id_str" : "2751062792",
      "id" : 2751062792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopKony2012",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285765794384736256",
  "text" : "RT @ProfJeffJarvis: Netizens, one last push to finish what we started: #StopKony2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopKony2012",
        "indices" : [ 51, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285763183296258048",
    "text" : "Netizens, one last push to finish what we started: #StopKony2012",
    "id" : 285763183296258048,
    "created_at" : "2012-12-31 15:03:46 +0000",
    "user" : {
      "name" : "#JeSuisForbes30under30",
      "screen_name" : "ProfJeffJarviss",
      "protected" : false,
      "id_str" : "514613499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883037883455680512\/SNA5PtKb_normal.jpg",
      "id" : 514613499,
      "verified" : false
    }
  },
  "id" : 285765794384736256,
  "created_at" : "2012-12-31 15:14:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285761372581687296",
  "text" : "RT @phylogenomics: For AM crowd: Reposting in honor of Carl Woese who just passed away: Most important paper ever in microbiology? http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/EMM2xWQG",
        "expanded_url" : "http:\/\/phylogenomics.blogspot.com\/2010\/04\/most-important-paper-ever-in.html?spref=tw",
        "display_url" : "phylogenomics.blogspot.com\/2010\/04\/most-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "285758648318296065",
    "text" : "For AM crowd: Reposting in honor of Carl Woese who just passed away: Most important paper ever in microbiology? http:\/\/t.co\/EMM2xWQG",
    "id" : 285758648318296065,
    "created_at" : "2012-12-31 14:45:45 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 285761372581687296,
  "created_at" : "2012-12-31 14:56:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285754274091266048",
  "geo" : { },
  "id_str" : "285754383776481280",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 ich hab f\u00FCr jeden Grundton eine. ;)",
  "id" : 285754383776481280,
  "in_reply_to_status_id" : 285754274091266048,
  "created_at" : "2012-12-31 14:28:48 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285748534865711104",
  "geo" : { },
  "id_str" : "285751417124311040",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Australia, not liking 2013 since before it was cool!",
  "id" : 285751417124311040,
  "in_reply_to_status_id" : 285748534865711104,
  "created_at" : "2012-12-31 14:17:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285747064283987969",
  "geo" : { },
  "id_str" : "285751162425192449",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 ich kann dir meine Bluesharp-Kollektion anbieten. ;)",
  "id" : 285751162425192449,
  "in_reply_to_status_id" : 285747064283987969,
  "created_at" : "2012-12-31 14:16:00 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 8, 15 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285740950431625216",
  "text" : "The iOS @Fitbit app is missing yesterday\u2019s data. I somehow expect 2012 being a leap year is the culprit.",
  "id" : 285740950431625216,
  "created_at" : "2012-12-31 13:35:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 66, 75 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285728647724273665",
  "geo" : { },
  "id_str" : "285728944148320256",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj geht schon, falls der Blutverlust doch zu gross wird kann @Senficon ja bescheid sagen. ;)",
  "id" : 285728944148320256,
  "in_reply_to_status_id" : 285728647724273665,
  "created_at" : "2012-12-31 12:47:43 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manu",
      "screen_name" : "manubloggt",
      "indices" : [ 0, 11 ],
      "id_str" : "39963826",
      "id" : 39963826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285726629534244864",
  "geo" : { },
  "id_str" : "285726787336544256",
  "in_reply_to_user_id" : 39963826,
  "text" : "@manubloggt passt farblich auf jeden Fall besser als das nat\u00FCrliche Blond. ;)",
  "id" : 285726787336544256,
  "in_reply_to_status_id" : 285726629534244864,
  "created_at" : "2012-12-31 12:39:09 +0000",
  "in_reply_to_screen_name" : "manubloggt",
  "in_reply_to_user_id_str" : "39963826",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285726541126709249",
  "text" : "Praktisch an lila Haaren: Man sieht das Blut nicht so wenn man sich den Sch\u00E4del am K\u00FCchenregal aufschl\u00E4gt.",
  "id" : 285726541126709249,
  "created_at" : "2012-12-31 12:38:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rabid",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285723112941703168",
  "text" : "\u00ABEven in Africa, undeniably the birthplace of the human virus, locals have an origin myth for AIDS that involves sex with a dog.\u00BB #rabid",
  "id" : 285723112941703168,
  "created_at" : "2012-12-31 12:24:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/r7wohqYo",
      "expanded_url" : "http:\/\/www.igb.illinois.edu\/news\/carl-r-woese-1928-%E2%80%93-2012",
      "display_url" : "igb.illinois.edu\/news\/carl-r-wo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285715998332571648",
  "text" : "Oh, Carl Woese (of Archaea-fame) passed away yesterday :( http:\/\/t.co\/r7wohqYo",
  "id" : 285715998332571648,
  "created_at" : "2012-12-31 11:56:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285708342117167105",
  "geo" : { },
  "id_str" : "285708689539735552",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019m not too surprised by this ;)",
  "id" : 285708689539735552,
  "in_reply_to_status_id" : 285708342117167105,
  "created_at" : "2012-12-31 11:27:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285707268463407104",
  "geo" : { },
  "id_str" : "285707789173678081",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, probably on other national holidays!",
  "id" : 285707789173678081,
  "in_reply_to_status_id" : 285707268463407104,
  "created_at" : "2012-12-31 11:23:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285704143723692032",
  "geo" : { },
  "id_str" : "285704699955523584",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, I guess Australians like to blow up stuff. :)",
  "id" : 285704699955523584,
  "in_reply_to_status_id" : 285704143723692032,
  "created_at" : "2012-12-31 11:11:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285701762944466944",
  "geo" : { },
  "id_str" : "285702223751696384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you\u2019re early! :P",
  "id" : 285702223751696384,
  "in_reply_to_status_id" : 285701762944466944,
  "created_at" : "2012-12-31 11:01:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/m5VOUCWe",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Courage_of_Lassie",
      "display_url" : "en.wikipedia.org\/wiki\/Courage_o\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00283, 8.296302 ]
  },
  "id_str" : "285698672660983808",
  "text" : "TIL there is a Lassie titled film which deals with K9 PTSD http:\/\/t.co\/m5VOUCWe",
  "id" : 285698672660983808,
  "created_at" : "2012-12-31 10:47:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/285688313103405057\/photo\/1",
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/nJdBCUS6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_b4AdNCUAED0no.jpg",
      "id_str" : "285688313107599361",
      "id" : 285688313107599361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_b4AdNCUAED0no.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/nJdBCUS6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285688313103405057",
  "text" : "Hund in Kastel gesucht http:\/\/t.co\/nJdBCUS6",
  "id" : 285688313103405057,
  "created_at" : "2012-12-31 10:06:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285529758471700480",
  "geo" : { },
  "id_str" : "285531674140356610",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj awww!",
  "id" : 285531674140356610,
  "in_reply_to_status_id" : 285529758471700480,
  "created_at" : "2012-12-30 23:43:50 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285528662705594368",
  "geo" : { },
  "id_str" : "285529194849505281",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj ich laufe regelm\u00E4\u00DFig zum Mainzer Campus (&amp; zur\u00FCck) &amp; meinetwegen brauchst du keine Hose. Aber Eisunterversorgung ist ein Dealbreaker",
  "id" : 285529194849505281,
  "in_reply_to_status_id" : 285528662705594368,
  "created_at" : "2012-12-30 23:33:59 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285528058084093954",
  "geo" : { },
  "id_str" : "285528154578231298",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj W\u00E4re noch etwas da wenn ich nun loslaufen w\u00FCrde?",
  "id" : 285528154578231298,
  "in_reply_to_status_id" : 285528058084093954,
  "created_at" : "2012-12-30 23:29:51 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/gPUH0eTI",
      "expanded_url" : "http:\/\/i.imgur.com\/FBzX7.jpg",
      "display_url" : "i.imgur.com\/FBzX7.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "285524474877583361",
  "text" : "Great Beach! http:\/\/t.co\/gPUH0eTI",
  "id" : 285524474877583361,
  "created_at" : "2012-12-30 23:15:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/WNBYA1MQ",
      "expanded_url" : "http:\/\/j.mp\/VrX9ew",
      "display_url" : "j.mp\/VrX9ew"
    } ]
  },
  "geo" : { },
  "id_str" : "285516678383689728",
  "text" : "Ability to sit and rise from the floor is closely correlated with all-cause mortality risk http:\/\/t.co\/WNBYA1MQ",
  "id" : 285516678383689728,
  "created_at" : "2012-12-30 22:44:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285515950143467520",
  "text" : "\u00ABI guess it\u2019ll only be in my dreams that you\u2019re the \u2018Chief of Doing Me\u2019\u00BB",
  "id" : 285515950143467520,
  "created_at" : "2012-12-30 22:41:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AkshatRathi\/status\/285506445632499713\/photo\/1",
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/A5zoZEcv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_ZSmYFCcAEJ2NR.png",
      "id_str" : "285506445636694017",
      "id" : 285506445636694017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_ZSmYFCcAEJ2NR.png",
      "sizes" : [ {
        "h" : 895,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 895,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 895,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/A5zoZEcv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/pekbfzk2",
      "expanded_url" : "http:\/\/www.nerdybaby.net\/",
      "display_url" : "nerdybaby.net"
    } ]
  },
  "geo" : { },
  "id_str" : "285508039639969792",
  "text" : "RT @AkshatRathi: Every baby knows the scientific method via http:\/\/t.co\/pekbfzk2 http:\/\/t.co\/A5zoZEcv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AkshatRathi\/status\/285506445632499713\/photo\/1",
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/A5zoZEcv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A_ZSmYFCcAEJ2NR.png",
        "id_str" : "285506445636694017",
        "id" : 285506445636694017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_ZSmYFCcAEJ2NR.png",
        "sizes" : [ {
          "h" : 895,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 895,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 895,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/A5zoZEcv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/pekbfzk2",
        "expanded_url" : "http:\/\/www.nerdybaby.net\/",
        "display_url" : "nerdybaby.net"
      } ]
    },
    "geo" : { },
    "id_str" : "285506445632499713",
    "text" : "Every baby knows the scientific method via http:\/\/t.co\/pekbfzk2 http:\/\/t.co\/A5zoZEcv",
    "id" : 285506445632499713,
    "created_at" : "2012-12-30 22:03:36 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 285508039639969792,
  "created_at" : "2012-12-30 22:09:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/6IZJ52I7",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=dUChsyvSw2Y",
      "display_url" : "youtube.com\/watch?v=dUChsy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285500439192018945",
  "text" : "Pain of Salvation &lt;3 http:\/\/t.co\/6IZJ52I7",
  "id" : 285500439192018945,
  "created_at" : "2012-12-30 21:39:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285444448635203584",
  "geo" : { },
  "id_str" : "285444703044915200",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer I guess in that specific case it makes no sense (UserSnps, Comments &amp; Annotations should go with the source)",
  "id" : 285444703044915200,
  "in_reply_to_status_id" : 285444448635203584,
  "created_at" : "2012-12-30 17:58:15 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285429429977620480",
  "text" : "It took me over a week but I finally can map those damned CDS-predictions back to my raw data! \\o\/",
  "id" : 285429429977620480,
  "created_at" : "2012-12-30 16:57:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/NnVbVRji",
      "expanded_url" : "http:\/\/j.mp\/VPpLgE",
      "display_url" : "j.mp\/VPpLgE"
    } ]
  },
  "geo" : { },
  "id_str" : "285422899953823748",
  "text" : "Goodbye Rita (Levi-Montalcini) http:\/\/t.co\/NnVbVRji",
  "id" : 285422899953823748,
  "created_at" : "2012-12-30 16:31:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/ihEPx8Gd",
      "expanded_url" : "http:\/\/jonfwilkins.blogspot.com\/2012\/12\/scocca-on-toy-gender-apartheid.html",
      "display_url" : "jonfwilkins.blogspot.com\/2012\/12\/scocca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285415213099008002",
  "text" : "RT @jonfwilkins: Tom Scocca has written an awesome piece on the gendering of toys http:\/\/t.co\/ihEPx8Gd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/ihEPx8Gd",
        "expanded_url" : "http:\/\/jonfwilkins.blogspot.com\/2012\/12\/scocca-on-toy-gender-apartheid.html",
        "display_url" : "jonfwilkins.blogspot.com\/2012\/12\/scocca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "285414131383795714",
    "text" : "Tom Scocca has written an awesome piece on the gendering of toys http:\/\/t.co\/ihEPx8Gd",
    "id" : 285414131383795714,
    "created_at" : "2012-12-30 15:56:46 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 285415213099008002,
  "created_at" : "2012-12-30 16:01:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285365707393339392",
  "geo" : { },
  "id_str" : "285406088537440258",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer I guess we kicked it out for some weird reason (aka not trusting ourselves enough to have set everything right)",
  "id" : 285406088537440258,
  "in_reply_to_status_id" : 285365707393339392,
  "created_at" : "2012-12-30 15:24:48 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285363826113781760",
  "geo" : { },
  "id_str" : "285364526365433856",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer that all objects associated with a SNP get deleted when the SNP itself gets deleted?",
  "id" : 285364526365433856,
  "in_reply_to_status_id" : 285363826113781760,
  "created_at" : "2012-12-30 12:39:39 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285360404312510464",
  "geo" : { },
  "id_str" : "285361888882212865",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer it\u2019s more of db-sanitation. And an easy way to get rid of \u201Ewrong\u201C data.",
  "id" : 285361888882212865,
  "in_reply_to_status_id" : 285360404312510464,
  "created_at" : "2012-12-30 12:29:10 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antifalala-la-la \uD83C\uDF84",
      "screen_name" : "st_christophr",
      "indices" : [ 3, 17 ],
      "id_str" : "23820736",
      "id" : 23820736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285357075670896640",
  "text" : "RT @st_christophr: lady in store lost her 3 year-old, faked a sneeze and from the corner we heard a tiny \"bess you!\" then she looked at  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "192631798763753473",
    "text" : "lady in store lost her 3 year-old, faked a sneeze and from the corner we heard a tiny \"bess you!\" then she looked at me and went \"pro tip.\"",
    "id" : 192631798763753473,
    "created_at" : "2012-04-18 15:12:54 +0000",
    "user" : {
      "name" : "antifalala-la-la \uD83C\uDF84",
      "screen_name" : "st_christophr",
      "protected" : false,
      "id_str" : "23820736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911376246923251712\/1vDsRMNA_normal.jpg",
      "id" : 23820736,
      "verified" : false
    }
  },
  "id" : 285357075670896640,
  "created_at" : "2012-12-30 12:10:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285353940059566080",
  "text" : "The biggest disadvantage of telecommuting: \u00ABScrew you guys, I\u2019m going home\u00BB no longer sounds as impressive.",
  "id" : 285353940059566080,
  "created_at" : "2012-12-30 11:57:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284953740623101953",
  "geo" : { },
  "id_str" : "285343800321257472",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ftdna-upload &amp; genotype-deletion works on my end.",
  "id" : 285343800321257472,
  "in_reply_to_status_id" : 284953740623101953,
  "created_at" : "2012-12-30 11:17:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sergio",
      "screen_name" : "Function",
      "indices" : [ 3, 12 ],
      "id_str" : "760418900571934721",
      "id" : 760418900571934721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285343666439090176",
  "text" : "RT @function: Merke: 'Fourier Analysis Discussions' nicht mit 'Four Anal Discs' abk\u00FCrzen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285343582397808640",
    "text" : "Merke: 'Fourier Analysis Discussions' nicht mit 'Four Anal Discs' abk\u00FCrzen",
    "id" : 285343582397808640,
    "created_at" : "2012-12-30 11:16:26 +0000",
    "user" : {
      "name" : "Stefan Graunke",
      "screen_name" : "StGraunke",
      "protected" : false,
      "id_str" : "14673413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801521157107306497\/kIy-VSUI_normal.jpg",
      "id" : 14673413,
      "verified" : false
    }
  },
  "id" : 285343666439090176,
  "created_at" : "2012-12-30 11:16:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/prsBgfuo",
      "expanded_url" : "http:\/\/j.mp\/WdcX4B",
      "display_url" : "j.mp\/WdcX4B"
    } ]
  },
  "geo" : { },
  "id_str" : "285341876020727808",
  "text" : "I Am Your Density -- Life On Ice http:\/\/t.co\/prsBgfuo",
  "id" : 285341876020727808,
  "created_at" : "2012-12-30 11:09:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molly Meade Hall",
      "screen_name" : "StaffingSAS_etc",
      "indices" : [ 3, 19 ],
      "id_str" : "26668905",
      "id" : 26668905
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StaffingSAS_etc\/status\/285172077063970816\/photo\/1",
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/6ndfJRK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_UifkGCIAAFU6N.jpg",
      "id_str" : "285172077068165120",
      "id" : 285172077068165120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_UifkGCIAAFU6N.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/6ndfJRK1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285176234856550400",
  "text" : "RT @StaffingSAS_etc: Your tan line is showing (haha) http:\/\/t.co\/6ndfJRK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StaffingSAS_etc\/status\/285172077063970816\/photo\/1",
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/6ndfJRK1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A_UifkGCIAAFU6N.jpg",
        "id_str" : "285172077068165120",
        "id" : 285172077068165120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_UifkGCIAAFU6N.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 625
        } ],
        "display_url" : "pic.twitter.com\/6ndfJRK1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285172077063970816",
    "text" : "Your tan line is showing (haha) http:\/\/t.co\/6ndfJRK1",
    "id" : 285172077063970816,
    "created_at" : "2012-12-29 23:54:56 +0000",
    "user" : {
      "name" : "Molly Meade Hall",
      "screen_name" : "StaffingSAS_etc",
      "protected" : false,
      "id_str" : "26668905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2292657238\/togwdys6qxfqa7sc2e32_normal.jpeg",
      "id" : 26668905,
      "verified" : false
    }
  },
  "id" : 285176234856550400,
  "created_at" : "2012-12-30 00:11:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rabid",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285144978861203457",
  "text" : "14th century: \u00ABSet the [rooster\u2019s feather-pulled] anus on the bite wound, on the theory that said anus would suck forth the poison.\u00BB #rabid",
  "id" : 285144978861203457,
  "created_at" : "2012-12-29 22:07:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 17, 26 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "openmind #om17",
      "screen_name" : "openmindkonf",
      "indices" : [ 27, 40 ],
      "id_str" : "158112993",
      "id" : 158112993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285133926119378944",
  "geo" : { },
  "id_str" : "285141007874543616",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @Senficon @snooze82 @openmindkonf meinetwegen ja.",
  "id" : 285141007874543616,
  "in_reply_to_status_id" : 285133926119378944,
  "created_at" : "2012-12-29 21:51:28 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "indices" : [ 3, 13 ],
      "id_str" : "42300167",
      "id" : 42300167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkedForGandalf",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285140203956494336",
  "text" : "RT @hughhowey: ***SPOILER ALERT*** Congress is going to wait until the very last minute, and then call for the eagles. #WorkedForGandalf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorkedForGandalf",
        "indices" : [ 104, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285117265442136064",
    "text" : "***SPOILER ALERT*** Congress is going to wait until the very last minute, and then call for the eagles. #WorkedForGandalf",
    "id" : 285117265442136064,
    "created_at" : "2012-12-29 20:17:07 +0000",
    "user" : {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "protected" : false,
      "id_str" : "42300167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2894618046\/60e0fd687df4f1b155723ae931e53909_normal.jpeg",
      "id" : 42300167,
      "verified" : true
    }
  },
  "id" : 285140203956494336,
  "created_at" : "2012-12-29 21:48:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 22, 36 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 102, 117 ]
    }, {
      "text" : "ngs",
      "indices" : [ 118, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/0UNsbcwP",
      "expanded_url" : "http:\/\/biomickwatson.wordpress.com\/2012\/12\/28\/an-embargo-on-short-read-alignment-software\/",
      "display_url" : "biomickwatson.wordpress.com\/2012\/12\/28\/an-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285020775814164480",
  "text" : "RT @pathogenomenick: \u201C@BioMickWatson: An embargo on short read alignment tools?  http:\/\/t.co\/0UNsbcwP #bioinformatics #ngs\u201D I agree with ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mick Watson",
        "screen_name" : "BioMickWatson",
        "indices" : [ 1, 15 ],
        "id_str" : "228586748",
        "id" : 228586748
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 81, 96 ]
      }, {
        "text" : "ngs",
        "indices" : [ 97, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/0UNsbcwP",
        "expanded_url" : "http:\/\/biomickwatson.wordpress.com\/2012\/12\/28\/an-embargo-on-short-read-alignment-software\/",
        "display_url" : "biomickwatson.wordpress.com\/2012\/12\/28\/an-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "285020197121839106",
    "text" : "\u201C@BioMickWatson: An embargo on short read alignment tools?  http:\/\/t.co\/0UNsbcwP #bioinformatics #ngs\u201D I agree with Mick!",
    "id" : 285020197121839106,
    "created_at" : "2012-12-29 13:51:25 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 285020775814164480,
  "created_at" : "2012-12-29 13:53:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 16, 25 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285015549132541952",
  "geo" : { },
  "id_str" : "285015930059239424",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay nein, @Senficon liest gerade aus dem WASG-RLP-2006-Programm. ;)",
  "id" : 285015930059239424,
  "in_reply_to_status_id" : 285015549132541952,
  "created_at" : "2012-12-29 13:34:27 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285015434141515776",
  "text" : "\u00ABDas ist oft das Problem mit der Linken. Das sind so Alt-Linke die den Kommunismus nach amerikanischem Vorbild wiedereinf\u00FChren wollen.\u00BB",
  "id" : 285015434141515776,
  "created_at" : "2012-12-29 13:32:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "indices" : [ 3, 12 ],
      "id_str" : "3453971",
      "id" : 3453971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/cmlzKtG1",
      "expanded_url" : "http:\/\/buff.ly\/U3YA3X",
      "display_url" : "buff.ly\/U3YA3X"
    } ]
  },
  "geo" : { },
  "id_str" : "285009106971000832",
  "text" : "RT @blacktar: Stanford Students And Professors Are Bridging The CS Gender Gap One Student At A Time http:\/\/t.co\/cmlzKtG1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/cmlzKtG1",
        "expanded_url" : "http:\/\/buff.ly\/U3YA3X",
        "display_url" : "buff.ly\/U3YA3X"
      } ]
    },
    "geo" : { },
    "id_str" : "285008551062159360",
    "text" : "Stanford Students And Professors Are Bridging The CS Gender Gap One Student At A Time http:\/\/t.co\/cmlzKtG1",
    "id" : 285008551062159360,
    "created_at" : "2012-12-29 13:05:08 +0000",
    "user" : {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "protected" : false,
      "id_str" : "3453971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897036682721153024\/sPNcTIBm_normal.jpg",
      "id" : 3453971,
      "verified" : false
    }
  },
  "id" : 285009106971000832,
  "created_at" : "2012-12-29 13:07:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 42, 49 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 75, 84 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 107 ],
      "url" : "https:\/\/t.co\/KBDbEiH1",
      "expanded_url" : "https:\/\/shells.ohai.su\/~lutoma\/zoidficon.gif",
      "display_url" : "shells.ohai.su\/~lutoma\/zoidfi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284979462766989312",
  "text" : "The transformation is nearly finished! MT @lutoma Need a Zoidberg? Why not @senficon? https:\/\/t.co\/KBDbEiH1",
  "id" : 284979462766989312,
  "created_at" : "2012-12-29 11:09:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284953740623101953",
  "geo" : { },
  "id_str" : "284960317249830913",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, i will have a look at it",
  "id" : 284960317249830913,
  "in_reply_to_status_id" : 284953740623101953,
  "created_at" : "2012-12-29 09:53:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284958956579848192",
  "text" : "\u00ABIch stell mir gerade ein Alpaka auf der Casting-Couch vor.\u00BB",
  "id" : 284958956579848192,
  "created_at" : "2012-12-29 09:48:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/pnXARSO8",
      "expanded_url" : "http:\/\/j.mp\/UrupVk",
      "display_url" : "j.mp\/UrupVk"
    } ]
  },
  "geo" : { },
  "id_str" : "284811582616264704",
  "text" : "Working record made from ice http:\/\/t.co\/pnXARSO8",
  "id" : 284811582616264704,
  "created_at" : "2012-12-29 00:02:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "erikalust",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/dq7XWavm",
      "expanded_url" : "http:\/\/bit.ly\/Rm3pH9",
      "display_url" : "bit.ly\/Rm3pH9"
    } ]
  },
  "geo" : { },
  "id_str" : "284800460299317248",
  "text" : "RT @Lobot: \"Ein guter Porno kommt eben auch ohne Ejakulation des Mannes aus.\" http:\/\/t.co\/dq7XWavm #erikalust",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "erikalust",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/dq7XWavm",
        "expanded_url" : "http:\/\/bit.ly\/Rm3pH9",
        "display_url" : "bit.ly\/Rm3pH9"
      } ]
    },
    "geo" : { },
    "id_str" : "284792169150160896",
    "text" : "\"Ein guter Porno kommt eben auch ohne Ejakulation des Mannes aus.\" http:\/\/t.co\/dq7XWavm #erikalust",
    "id" : 284792169150160896,
    "created_at" : "2012-12-28 22:45:18 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 284800460299317248,
  "created_at" : "2012-12-28 23:18:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284799580082675712",
  "text" : "\u00ABThat's your problem. You brought a funeral program to a knife fight.\u00BB",
  "id" : 284799580082675712,
  "created_at" : "2012-12-28 23:14:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284792807590346753",
  "text" : "\u00ABCause of death: Diabetes. Just kidding, he exploded.\u00BB",
  "id" : 284792807590346753,
  "created_at" : "2012-12-28 22:47:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/ktsRx1CF",
      "expanded_url" : "http:\/\/imgur.com\/zGfz2",
      "display_url" : "imgur.com\/zGfz2"
    } ]
  },
  "geo" : { },
  "id_str" : "284774289931128832",
  "text" : "Kids first! http:\/\/t.co\/ktsRx1CF",
  "id" : 284774289931128832,
  "created_at" : "2012-12-28 21:34:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/vQAJqT4D",
      "expanded_url" : "http:\/\/s-ak.buzzfed.com\/static\/enhanced\/terminal01\/2010\/9\/19\/22\/enhanced-buzz-23247-1284949703-3.jpg",
      "display_url" : "s-ak.buzzfed.com\/static\/enhance\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284770885783662592",
  "text" : "Know your bible verses! http:\/\/t.co\/vQAJqT4D",
  "id" : 284770885783662592,
  "created_at" : "2012-12-28 21:20:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284757421556125696",
  "text" : "Doh, der Rei\u00DFverschluss an der Lieblingsjacke l\u00F6st sich langsam auf!",
  "id" : 284757421556125696,
  "created_at" : "2012-12-28 20:27:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284738972448587777",
  "text" : "Zwangsurlaub weil der Remoterechner ausgeschaltet wurde\u2026",
  "id" : 284738972448587777,
  "created_at" : "2012-12-28 19:13:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284726477063327745",
  "text" : "Weil ich keine Nudeln will: \u00ABAuf einer intellektuellen Ebene verstehe ich es. Ich w\u00FCrde es zwar nie machen, aber respektiere deinen Wunsch\u00BB",
  "id" : 284726477063327745,
  "created_at" : "2012-12-28 18:24:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/3Epm6rDr",
      "expanded_url" : "http:\/\/babiesareyum.tumblr.com\/post\/27695992311\/a-member-of-the-scottish-national-antarctic",
      "display_url" : "babiesareyum.tumblr.com\/post\/276959923\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284721442770284545",
  "text" : "Indifferent Penguins in Scottish Folk Music http:\/\/t.co\/3Epm6rDr",
  "id" : 284721442770284545,
  "created_at" : "2012-12-28 18:04:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deborah Blum",
      "screen_name" : "deborahblum",
      "indices" : [ 3, 15 ],
      "id_str" : "72842277",
      "id" : 72842277
    }, {
      "name" : "Brian Switek @MFF",
      "screen_name" : "Laelaps",
      "indices" : [ 26, 34 ],
      "id_str" : "29342640",
      "id" : 29342640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284716434301538304",
  "text" : "RT @deborahblum: Sigh. RT @Laelaps Why did the box turtle cross the road? Oh wait, it probably didn\u2019t, because people are evil.\" http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Switek @MFF",
        "screen_name" : "Laelaps",
        "indices" : [ 9, 17 ],
        "id_str" : "29342640",
        "id" : 29342640
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/Pu2KO15i",
        "expanded_url" : "http:\/\/bit.ly\/TuE24H",
        "display_url" : "bit.ly\/TuE24H"
      } ]
    },
    "geo" : { },
    "id_str" : "284715795286749184",
    "text" : "Sigh. RT @Laelaps Why did the box turtle cross the road? Oh wait, it probably didn\u2019t, because people are evil.\" http:\/\/t.co\/Pu2KO15i",
    "id" : 284715795286749184,
    "created_at" : "2012-12-28 17:41:50 +0000",
    "user" : {
      "name" : "Deborah Blum",
      "screen_name" : "deborahblum",
      "protected" : false,
      "id_str" : "72842277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425431154385108992\/UzYxcmWl_normal.jpeg",
      "id" : 72842277,
      "verified" : false
    }
  },
  "id" : 284716434301538304,
  "created_at" : "2012-12-28 17:44:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/OhnELwTl",
      "expanded_url" : "http:\/\/www.outsideonline.com\/outdoor-adventure\/As-Freezing-Persons-Recollect-the-Snow--First-Chill--Then-Stupor--Then-the-Letting-Go.html?page=all",
      "display_url" : "outsideonline.com\/outdoor-advent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284699645391806464",
  "text" : "The cold hard facts of freezing to death http:\/\/t.co\/OhnELwTl",
  "id" : 284699645391806464,
  "created_at" : "2012-12-28 16:37:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 3, 15 ],
      "id_str" : "53560219",
      "id" : 53560219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/oAZaPgeZ",
      "expanded_url" : "http:\/\/1.usa.gov\/UwSZp0",
      "display_url" : "1.usa.gov\/UwSZp0"
    } ]
  },
  "geo" : { },
  "id_str" : "284693441596772352",
  "text" : "RT @openscience: Impact factor is overrated: A principal component analysis of 39 scientific impact measures http:\/\/t.co\/oAZaPgeZ via @h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hilary Mason",
        "screen_name" : "hmason",
        "indices" : [ 117, 124 ],
        "id_str" : "765548",
        "id" : 765548
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/oAZaPgeZ",
        "expanded_url" : "http:\/\/1.usa.gov\/UwSZp0",
        "display_url" : "1.usa.gov\/UwSZp0"
      } ]
    },
    "geo" : { },
    "id_str" : "284569974427762689",
    "text" : "Impact factor is overrated: A principal component analysis of 39 scientific impact measures http:\/\/t.co\/oAZaPgeZ via @hmason",
    "id" : 284569974427762689,
    "created_at" : "2012-12-28 08:02:23 +0000",
    "user" : {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "protected" : false,
      "id_str" : "53560219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459933268746317825\/wrEyqxhT_normal.png",
      "id" : 53560219,
      "verified" : false
    }
  },
  "id" : 284693441596772352,
  "created_at" : "2012-12-28 16:13:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "der LUSTIGE Wellensittich",
      "screen_name" : "FR31H31T",
      "indices" : [ 3, 12 ],
      "id_str" : "73747798",
      "id" : 73747798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284691839854989312",
  "text" : "RT @FR31H31T: In meiner Timeline schreibt keiner \u201ESilvester\u201C falsch, aber 100 sagen mir, wie man es nicht schreiben soll. Nehmt euch doc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284691717918179328",
    "text" : "In meiner Timeline schreibt keiner \u201ESilvester\u201C falsch, aber 100 sagen mir, wie man es nicht schreiben soll. Nehmt euch doch'n Klassenzimmer.",
    "id" : 284691717918179328,
    "created_at" : "2012-12-28 16:06:09 +0000",
    "user" : {
      "name" : "der LUSTIGE Wellensittich",
      "screen_name" : "FR31H31T",
      "protected" : false,
      "id_str" : "73747798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/931967334817894400\/XW5_KgF0_normal.jpg",
      "id" : 73747798,
      "verified" : false
    }
  },
  "id" : 284691839854989312,
  "created_at" : "2012-12-28 16:06:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Primitives Element",
      "screen_name" : "drseilzug",
      "indices" : [ 0, 10 ],
      "id_str" : "243633845",
      "id" : 243633845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284687244500013056",
  "geo" : { },
  "id_str" : "284687721388179456",
  "in_reply_to_user_id" : 243633845,
  "text" : "@drseilzug nein, das war dieses Jahr zeitlich, finanziell und nervlich nicht mehr drin.",
  "id" : 284687721388179456,
  "in_reply_to_status_id" : 284687244500013056,
  "created_at" : "2012-12-28 15:50:16 +0000",
  "in_reply_to_screen_name" : "drseilzug",
  "in_reply_to_user_id_str" : "243633845",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/WBaPxlk7",
      "expanded_url" : "http:\/\/instagr.am\/p\/TyPMRChwoE\/",
      "display_url" : "instagr.am\/p\/TyPMRChwoE\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0001153401, 8.2858982658 ]
  },
  "id_str" : "284679809202794496",
  "text" : "Geflutet @ Maaraue http:\/\/t.co\/WBaPxlk7",
  "id" : 284679809202794496,
  "created_at" : "2012-12-28 15:18:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/txZOj4YF",
      "expanded_url" : "http:\/\/imgur.com\/5Cx3t",
      "display_url" : "imgur.com\/5Cx3t"
    } ]
  },
  "geo" : { },
  "id_str" : "284670476129824769",
  "text" : "Pet me! http:\/\/t.co\/txZOj4YF",
  "id" : 284670476129824769,
  "created_at" : "2012-12-28 14:41:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/a4VfNWTa",
      "expanded_url" : "http:\/\/j.mp\/W5sHGl",
      "display_url" : "j.mp\/W5sHGl"
    } ]
  },
  "geo" : { },
  "id_str" : "284654562881708032",
  "text" : "Rock stardom reduces life expectancy: \u00ABSadly, they can't turn life expectancy all the way to 11.\u00BB http:\/\/t.co\/a4VfNWTa",
  "id" : 284654562881708032,
  "created_at" : "2012-12-28 13:38:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/hcdYLGd7",
      "expanded_url" : "http:\/\/j.mp\/W5sinl",
      "display_url" : "j.mp\/W5sinl"
    } ]
  },
  "geo" : { },
  "id_str" : "284653092803317761",
  "text" : "Human-rights court orders world\u2019s last IVF ban to be lifted http:\/\/t.co\/hcdYLGd7",
  "id" : 284653092803317761,
  "created_at" : "2012-12-28 13:32:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284642175520763905",
  "text" : "\u00ABIch hab \u00FCber die Feiertage Gewicht verloren!\u00BB\u2014\u00ABZu schade das du deine Leberwerte nicht trackst.\u00BB",
  "id" : 284642175520763905,
  "created_at" : "2012-12-28 12:49:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deborah Blum",
      "screen_name" : "deborahblum",
      "indices" : [ 3, 15 ],
      "id_str" : "72842277",
      "id" : 72842277
    }, {
      "name" : "Nature Chemistry",
      "screen_name" : "NatureChemistry",
      "indices" : [ 48, 64 ],
      "id_str" : "23575322",
      "id" : 23575322
    }, {
      "name" : "Royal Institution",
      "screen_name" : "Ri_Science",
      "indices" : [ 76, 87 ],
      "id_str" : "58431280",
      "id" : 58431280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284439687937019904",
  "text" : "RT @deborahblum: Two most reactive elements: RT @NatureChemistry Cs + F! RT @ri_science: Watch 1st ever test of reaction http:\/\/t.co\/65f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nature Chemistry",
        "screen_name" : "NatureChemistry",
        "indices" : [ 31, 47 ],
        "id_str" : "23575322",
        "id" : 23575322
      }, {
        "name" : "Royal Institution",
        "screen_name" : "Ri_Science",
        "indices" : [ 59, 70 ],
        "id_str" : "58431280",
        "id" : 58431280
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "xmaslectures",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/65f2DSJE",
        "expanded_url" : "http:\/\/bit.ly\/UoTnF1",
        "display_url" : "bit.ly\/UoTnF1"
      } ]
    },
    "geo" : { },
    "id_str" : "284435716119855105",
    "text" : "Two most reactive elements: RT @NatureChemistry Cs + F! RT @ri_science: Watch 1st ever test of reaction http:\/\/t.co\/65f2DSJE  #xmaslectures",
    "id" : 284435716119855105,
    "created_at" : "2012-12-27 23:08:53 +0000",
    "user" : {
      "name" : "Deborah Blum",
      "screen_name" : "deborahblum",
      "protected" : false,
      "id_str" : "72842277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425431154385108992\/UzYxcmWl_normal.jpeg",
      "id" : 72842277,
      "verified" : false
    }
  },
  "id" : 284439687937019904,
  "created_at" : "2012-12-27 23:24:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 27, 37 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Ivan Oransky",
      "screen_name" : "ivanoransky",
      "indices" : [ 55, 67 ],
      "id_str" : "15859033",
      "id" : 15859033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284417819536392192",
  "text" : "RT @AkshatRathi: Hahaha RT @edyong209: And diagram! RT @ivanoransky \u201CAn In-Depth Analysis of a Piece of Shit.\" Wonderful paper title htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Yong",
        "screen_name" : "edyong209",
        "indices" : [ 10, 20 ],
        "id_str" : "19767193",
        "id" : 19767193
      }, {
        "name" : "Ivan Oransky",
        "screen_name" : "ivanoransky",
        "indices" : [ 38, 50 ],
        "id_str" : "15859033",
        "id" : 15859033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/t3iPL9wx",
        "expanded_url" : "http:\/\/bit.ly\/VzVX7H",
        "display_url" : "bit.ly\/VzVX7H"
      } ]
    },
    "geo" : { },
    "id_str" : "284417226340179969",
    "text" : "Hahaha RT @edyong209: And diagram! RT @ivanoransky \u201CAn In-Depth Analysis of a Piece of Shit.\" Wonderful paper title http:\/\/t.co\/t3iPL9wx",
    "id" : 284417226340179969,
    "created_at" : "2012-12-27 21:55:25 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 284417819536392192,
  "created_at" : "2012-12-27 21:57:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DevOps Borat",
      "screen_name" : "DEVOPS_BORAT",
      "indices" : [ 3, 16 ],
      "id_str" : "167499429",
      "id" : 167499429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284416015675297792",
  "text" : "RT @DEVOPS_BORAT: In agile startup we have policy of \"is not bug, is feature\" unless bug is open by CEO.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284415640805208064",
    "text" : "In agile startup we have policy of \"is not bug, is feature\" unless bug is open by CEO.",
    "id" : 284415640805208064,
    "created_at" : "2012-12-27 21:49:07 +0000",
    "user" : {
      "name" : "DevOps Borat",
      "screen_name" : "DEVOPS_BORAT",
      "protected" : false,
      "id_str" : "167499429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1079908235\/borat_855_18535194_0_0_12672_300_normal.jpg",
      "id" : 167499429,
      "verified" : false
    }
  },
  "id" : 284416015675297792,
  "created_at" : "2012-12-27 21:50:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ds187",
      "screen_name" : "ds187",
      "indices" : [ 0, 6 ],
      "id_str" : "15895350",
      "id" : 15895350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284412457458491392",
  "geo" : { },
  "id_str" : "284414079815254017",
  "in_reply_to_user_id" : 15895350,
  "text" : "@ds187 ich auch! Aber ich war schon total verplant als ich in NRW war :(",
  "id" : 284414079815254017,
  "in_reply_to_status_id" : 284412457458491392,
  "created_at" : "2012-12-27 21:42:55 +0000",
  "in_reply_to_screen_name" : "ds187",
  "in_reply_to_user_id_str" : "15895350",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284407685980499968",
  "geo" : { },
  "id_str" : "284407921364832258",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy true, aber das ist dann schon ein bisschen gefaket.",
  "id" : 284407921364832258,
  "in_reply_to_status_id" : 284407685980499968,
  "created_at" : "2012-12-27 21:18:27 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284406705775837185",
  "geo" : { },
  "id_str" : "284407556099678208",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy das hat dann aber nix mehr mit Biss zu tun!",
  "id" : 284407556099678208,
  "in_reply_to_status_id" : 284406705775837185,
  "created_at" : "2012-12-27 21:17:00 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carla Gentry",
      "screen_name" : "data_nerd",
      "indices" : [ 0, 10 ],
      "id_str" : "119802433",
      "id" : 119802433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284405630549245952",
  "geo" : { },
  "id_str" : "284406365886234624",
  "in_reply_to_user_id" : 119802433,
  "text" : "@data_nerd Thanks for sharing. Und auch alles gute f\u00FCrs neue Jahr! :)",
  "id" : 284406365886234624,
  "in_reply_to_status_id" : 284405630549245952,
  "created_at" : "2012-12-27 21:12:16 +0000",
  "in_reply_to_screen_name" : "data_nerd",
  "in_reply_to_user_id_str" : "119802433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284405811269218304",
  "geo" : { },
  "id_str" : "284406116891369472",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy sowas von, Blut muss flie\u00DFen!",
  "id" : 284406116891369472,
  "in_reply_to_status_id" : 284405811269218304,
  "created_at" : "2012-12-27 21:11:16 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284404320919748608",
  "geo" : { },
  "id_str" : "284405690833973249",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ich f\u00E4nde es in beiden F\u00E4llen sexy.",
  "id" : 284405690833973249,
  "in_reply_to_status_id" : 284404320919748608,
  "created_at" : "2012-12-27 21:09:35 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 3, 12 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/0sJI06dH",
      "expanded_url" : "http:\/\/www.pledgebank.com\/stoererhaftung",
      "display_url" : "pledgebank.com\/stoererhaftung"
    } ]
  },
  "geo" : { },
  "id_str" : "284405403746463744",
  "text" : "RT @Dave_Kay: Pledge zur St\u00F6rerhaftung eingerichtet pls RT thx http:\/\/t.co\/0sJI06dH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/0sJI06dH",
        "expanded_url" : "http:\/\/www.pledgebank.com\/stoererhaftung",
        "display_url" : "pledgebank.com\/stoererhaftung"
      } ]
    },
    "geo" : { },
    "id_str" : "284398186624348160",
    "text" : "Pledge zur St\u00F6rerhaftung eingerichtet pls RT thx http:\/\/t.co\/0sJI06dH",
    "id" : 284398186624348160,
    "created_at" : "2012-12-27 20:39:46 +0000",
    "user" : {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "protected" : false,
      "id_str" : "10487642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856861749089370112\/pWlNIzsQ_normal.jpg",
      "id" : 10487642,
      "verified" : false
    }
  },
  "id" : 284405403746463744,
  "created_at" : "2012-12-27 21:08:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284403986461765632",
  "text" : "\u00ABDer Kater hat mich gebissen!\u00BB\u2014\u00ABDas ist eine Katze, du Sexist!\u00BB",
  "id" : 284403986461765632,
  "created_at" : "2012-12-27 21:02:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284398572252827648",
  "text" : "\u00ABIch geh jetzt auch zu fapstar.\u00BB",
  "id" : 284398572252827648,
  "created_at" : "2012-12-27 20:41:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284395888305111042",
  "text" : "Bunny-Exchange.",
  "id" : 284395888305111042,
  "created_at" : "2012-12-27 20:30:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carla Gentry",
      "screen_name" : "data_nerd",
      "indices" : [ 3, 13 ],
      "id_str" : "119802433",
      "id" : 119802433
    }, {
      "name" : "Janrain",
      "screen_name" : "Janrain",
      "indices" : [ 104, 112 ],
      "id_str" : "14806188",
      "id" : 14806188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/mPzIck6H",
      "expanded_url" : "http:\/\/janrain.com\/blog\/infographic-how-to-solve-the-online-registration-challenge\/",
      "display_url" : "janrain.com\/blog\/infograph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284394832670121984",
  "text" : "RT @data_nerd: 2 in 5 people would rather solve world peace than create a new password [Infographic via @janrain] http:\/\/t.co\/mPzIck6H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Janrain",
        "screen_name" : "Janrain",
        "indices" : [ 89, 97 ],
        "id_str" : "14806188",
        "id" : 14806188
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/mPzIck6H",
        "expanded_url" : "http:\/\/janrain.com\/blog\/infographic-how-to-solve-the-online-registration-challenge\/",
        "display_url" : "janrain.com\/blog\/infograph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "284386119364268032",
    "text" : "2 in 5 people would rather solve world peace than create a new password [Infographic via @janrain] http:\/\/t.co\/mPzIck6H",
    "id" : 284386119364268032,
    "created_at" : "2012-12-27 19:51:49 +0000",
    "user" : {
      "name" : "Carla Gentry",
      "screen_name" : "data_nerd",
      "protected" : false,
      "id_str" : "119802433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563828727306391552\/Jxxp_Nar_normal.jpeg",
      "id" : 119802433,
      "verified" : true
    }
  },
  "id" : 284394832670121984,
  "created_at" : "2012-12-27 20:26:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 10, 14 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 24, 31 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 32, 42 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 43, 50 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284388417574416384",
  "geo" : { },
  "id_str" : "284388525208645633",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @scy @levudev @lutoma @prauscher @lsanoj Frauenquote wie bei Blood &amp; Honor!",
  "id" : 284388525208645633,
  "in_reply_to_status_id" : 284388417574416384,
  "created_at" : "2012-12-27 20:01:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284362258807656449",
  "geo" : { },
  "id_str" : "284362433735319552",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher @Senficon gern geschehen!",
  "id" : 284362433735319552,
  "in_reply_to_status_id" : 284362258807656449,
  "created_at" : "2012-12-27 18:17:42 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284361882532474880",
  "geo" : { },
  "id_str" : "284362017668739072",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher @Senficon zehnthofstrasse 36.",
  "id" : 284362017668739072,
  "in_reply_to_status_id" : 284361882532474880,
  "created_at" : "2012-12-27 18:16:02 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "29c3",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284359343644766208",
  "text" : "\u00ABBlood &amp; Honor? Das ist ja ne Frauenquote wie bei der Piratenpartei.\u00BB #29c3",
  "id" : 284359343644766208,
  "created_at" : "2012-12-27 18:05:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bee",
      "screen_name" : "zynaesthesie",
      "indices" : [ 3, 16 ],
      "id_str" : "78050059",
      "id" : 78050059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284358558974373888",
  "text" : "RT @zynaesthesie: \u201EUnd wenn Ihre Kunden beim Umtauschen durchknallen?\u201C \u201EWir haben einen Salesorger.\u201C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284358335594110976",
    "text" : "\u201EUnd wenn Ihre Kunden beim Umtauschen durchknallen?\u201C \u201EWir haben einen Salesorger.\u201C",
    "id" : 284358335594110976,
    "created_at" : "2012-12-27 18:01:24 +0000",
    "user" : {
      "name" : "bee",
      "screen_name" : "zynaesthesie",
      "protected" : false,
      "id_str" : "78050059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763319044174995456\/UcQwTixG_normal.jpg",
      "id" : 78050059,
      "verified" : false
    }
  },
  "id" : 284358558974373888,
  "created_at" : "2012-12-27 18:02:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284356285728698368",
  "text" : "\u00ABDu isst vom Boden. Ich von meiner Nase, die ist sauberer!\u00BB",
  "id" : 284356285728698368,
  "created_at" : "2012-12-27 17:53:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284337390884098049",
  "geo" : { },
  "id_str" : "284338086320680961",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma trolololo!",
  "id" : 284338086320680961,
  "in_reply_to_status_id" : 284337390884098049,
  "created_at" : "2012-12-27 16:40:57 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 9, 19 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284331357264568322",
  "text" : "@levudev @prauscher ne, so altes Fernsehklinkenartiges Ged\u00F6ns. Nen 22\u201C Screen haben wir zur Not auch hier.",
  "id" : 284331357264568322,
  "created_at" : "2012-12-27 16:14:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284330569465225217",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher @levudev hat wer von euch Adapterbla von VGA zu Standard-Video-Foo? Sonst bekommen wir den Stream nicht auf den Fernseher.",
  "id" : 284330569465225217,
  "created_at" : "2012-12-27 16:11:05 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284325236600610816",
  "text" : "\u00ABDu bist f\u00FCr mich der Vater den ich nie hatte.\u00BB\u2014\u00ABDu hast einen Vater &amp; bevor du es nochmal versuchst: Denk dran, du hast auch einen Bruder.\u00BB",
  "id" : 284325236600610816,
  "created_at" : "2012-12-27 15:49:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 8, 18 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 19, 28 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284322491101503488",
  "geo" : { },
  "id_str" : "284322754147270656",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma @prauscher @Senficon ich rechne fest mit dir!",
  "id" : 284322754147270656,
  "in_reply_to_status_id" : 284322491101503488,
  "created_at" : "2012-12-27 15:40:01 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284308654830788609",
  "geo" : { },
  "id_str" : "284311433502674947",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du wei\u00DFt doch wie clever sie ist. :P",
  "id" : 284311433502674947,
  "in_reply_to_status_id" : 284308654830788609,
  "created_at" : "2012-12-27 14:55:02 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284304779889483776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9930739375, 8.0727989461 ]
  },
  "id_str" : "284305324708622337",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du wei\u00DFt ja wer \u00E4ltere Rechte hat. ;)",
  "id" : 284305324708622337,
  "in_reply_to_status_id" : 284304779889483776,
  "created_at" : "2012-12-27 14:30:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284299647948840960",
  "geo" : { },
  "id_str" : "284302233657552896",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon meine Wahlfamilie ist \u00FCbrigens fest davon \u00FCberzeugt das Miezi als n\u00E4chstes erst Miller und dann dich verdr\u00E4ngen werden will. :P",
  "id" : 284302233657552896,
  "in_reply_to_status_id" : 284299647948840960,
  "created_at" : "2012-12-27 14:18:29 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284298663503732736",
  "text" : "\u00ABIch bin mir nicht sicher ob da mein Herz oder der Alkohol spricht.\u00BB\u2014\u00ABVom Geruch her tippe ich auf letzteres.\u00BB",
  "id" : 284298663503732736,
  "created_at" : "2012-12-27 14:04:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/3zYEdwes",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/BpsResearchDigest\/~3\/R6X_EDsDvb4\/how-to-kill-earworm.html",
      "display_url" : "feedproxy.google.com\/~r\/BpsResearch\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9822235881, 7.0191452445 ]
  },
  "id_str" : "284291162121052160",
  "text" : "How to kill an earworm http:\/\/t.co\/3zYEdwes",
  "id" : 284291162121052160,
  "created_at" : "2012-12-27 13:34:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/lB3ZzgCl",
      "expanded_url" : "http:\/\/j.mp\/WULs5G",
      "display_url" : "j.mp\/WULs5G"
    } ]
  },
  "geo" : { },
  "id_str" : "284287529463713793",
  "text" : "Theodizee f\u00FCr Anf\u00E4nger http:\/\/t.co\/lB3ZzgCl",
  "id" : 284287529463713793,
  "created_at" : "2012-12-27 13:20:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284114511353483264",
  "text" : "\u00ABIch habe bereits alle Vaterpflichten wahrgenommen.\u00BB\u2014\u00ABErwachsene Menschen betrunken ins Bett bringen reicht daf\u00FCr nicht aus\u2026\u00BB",
  "id" : 284114511353483264,
  "created_at" : "2012-12-27 01:52:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284054733742800896",
  "geo" : { },
  "id_str" : "284057433951858688",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ ich h\u00F6re Kneipengespr\u00E4chen zu.",
  "id" : 284057433951858688,
  "in_reply_to_status_id" : 284054733742800896,
  "created_at" : "2012-12-26 22:05:44 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284054075480350720",
  "text" : "\u00ABIch wohne seit 2 Jahren in Dorstfeld und f\u00FChle mich total sicher da.\u00BB\u2014\u00ABAls wei\u00DFer, blonder, blau\u00E4ugiger Mann. Tell me more\u2026\u00BB",
  "id" : 284054075480350720,
  "created_at" : "2012-12-26 21:52:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284050144050155521",
  "text" : "\u00ABIn W\u00FCrde altern? Das ist in ihrem Land leider nicht verf\u00FCgbar.\u00BB",
  "id" : 284050144050155521,
  "created_at" : "2012-12-26 21:36:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284032003714740224",
  "text" : "\u00ABWillst du mir eine Hauen? Oder was soll die Geste?\u00BB\u2014\u00ABEs nennt sich \u2018die Hand reichen\u2026\u2019\u00BB",
  "id" : 284032003714740224,
  "created_at" : "2012-12-26 20:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283966581208412160",
  "text" : "\u00ABIch hab im Laufe unserer Beziehung damals schon einiges n\u00FCtzliches gelernt. \u2018Fuck Society\u2019, zum Beispiel.\u00BB &lt;3",
  "id" : 283966581208412160,
  "created_at" : "2012-12-26 16:04:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283899590825111553",
  "text" : "FYI: Wenn man nach \u00ABTierbordell Arche Noah\u00BB googlet bekommt man als einzigen Treffer ein Sitzungsprotokoll des \u00F6sterreich. Nationalrates.",
  "id" : 283899590825111553,
  "created_at" : "2012-12-26 11:38:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283895611693092864",
  "geo" : { },
  "id_str" : "283896493390307329",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot highly unlikely, but it\u2019s still a really neat trick.",
  "id" : 283896493390307329,
  "in_reply_to_status_id" : 283895611693092864,
  "created_at" : "2012-12-26 11:26:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/xVRhj5xr",
      "expanded_url" : "http:\/\/j.mp\/V2NlIe",
      "display_url" : "j.mp\/V2NlIe"
    } ]
  },
  "geo" : { },
  "id_str" : "283893347834269696",
  "text" : "CCR5 \"transplants\": All I want for Christmas is a cure for HIV http:\/\/t.co\/xVRhj5xr",
  "id" : 283893347834269696,
  "created_at" : "2012-12-26 11:13:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/UHLKHFHt",
      "expanded_url" : "http:\/\/j.mp\/V2Mo2z",
      "display_url" : "j.mp\/V2Mo2z"
    } ]
  },
  "geo" : { },
  "id_str" : "283891738865696768",
  "text" : "Size matters, including tapir &amp; barnacle porn http:\/\/t.co\/UHLKHFHt",
  "id" : 283891738865696768,
  "created_at" : "2012-12-26 11:07:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283791847812378624",
  "geo" : { },
  "id_str" : "283792008005431296",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy that\u2019s a pretty nice idea. I\u2019d love to see a prototype of this :)",
  "id" : 283792008005431296,
  "in_reply_to_status_id" : 283791847812378624,
  "created_at" : "2012-12-26 04:31:01 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283790823345233922",
  "geo" : { },
  "id_str" : "283791265068359680",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy but it would be much harder to do similar estimates for this kind of activity as it depends on so many variables.",
  "id" : 283791265068359680,
  "in_reply_to_status_id" : 283790823345233922,
  "created_at" : "2012-12-26 04:28:04 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283790823345233922",
  "geo" : { },
  "id_str" : "283791083098484736",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy i guess it\u2019s hard to make it a general item in their list. E.g: You can estimate calories for walking through time &amp; distance.",
  "id" : 283791083098484736,
  "in_reply_to_status_id" : 283790823345233922,
  "created_at" : "2012-12-26 04:27:21 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283789728279568384",
  "geo" : { },
  "id_str" : "283790409254174721",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy tbh: I just tried to manually log it myself through their website a couple of weeks ago and couldn\u2019t find a good fit.",
  "id" : 283790409254174721,
  "in_reply_to_status_id" : 283789728279568384,
  "created_at" : "2012-12-26 04:24:40 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/yp2cxujh",
      "expanded_url" : "http:\/\/j.mp\/12MHfkb",
      "display_url" : "j.mp\/12MHfkb"
    } ]
  },
  "geo" : { },
  "id_str" : "283789559173636097",
  "text" : "Relationship-Grammar Test. Not to be tried with vegans http:\/\/t.co\/yp2cxujh",
  "id" : 283789559173636097,
  "created_at" : "2012-12-26 04:21:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283786271539736576",
  "geo" : { },
  "id_str" : "283786877323059201",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy nope, at least there wasn\u2019t an appropriate category last time I checked.",
  "id" : 283786877323059201,
  "in_reply_to_status_id" : 283786271539736576,
  "created_at" : "2012-12-26 04:10:38 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283785092084666369",
  "text" : "\u00ABUnd wor\u00FCber hast du dich mit deiner Walfamilie unterhalten?\u00BB\u2014\u00ABInfraschall.\u00BB",
  "id" : 283785092084666369,
  "created_at" : "2012-12-26 04:03:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283758535190409216",
  "geo" : { },
  "id_str" : "283761054310338560",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy das beste Journal f\u00FCr Detektiv-Content!",
  "id" : 283761054310338560,
  "in_reply_to_status_id" : 283758535190409216,
  "created_at" : "2012-12-26 02:28:02 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283757041208668160",
  "geo" : { },
  "id_str" : "283758324816674816",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Lauf m\u00F6glichst nah an der Wand, da macht man am wenigsten Ger\u00E4usche. :)",
  "id" : 283758324816674816,
  "in_reply_to_status_id" : 283757041208668160,
  "created_at" : "2012-12-26 02:17:11 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283742443847958528",
  "text" : "\u00ABWas Freud wohl dazu sagen w\u00FCrde?\u00BB\u2014\u00ABVermutlich \u2018Geil, \u00E4ltere Frauen!\u2019 oder so.\u00BB",
  "id" : 283742443847958528,
  "created_at" : "2012-12-26 01:14:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283724307778134018",
  "text" : "@jack_berlin1 m\u00E4nnlich.",
  "id" : 283724307778134018,
  "created_at" : "2012-12-26 00:02:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283722780527190016",
  "text" : "\u00ABUnser Maskottchen: Eine M\u00F6hre. Die hat sich jemand in die Hose gesteckt. Dann haben wir sie eingepflanzt und nun schimmelt sie\u00BB",
  "id" : 283722780527190016,
  "created_at" : "2012-12-25 23:55:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283721188398735361",
  "text" : "\u00ABIch mach es mal ein bisschen romantisch\u00BB\u2014\u00ABDu holst den Schnaps raus?\u00BB",
  "id" : 283721188398735361,
  "created_at" : "2012-12-25 23:49:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283709464324997120",
  "text" : "\u00ABIslam is cracking up. We got women talking back. We got people playing stringed instruments. It\u2019s the end of days!\u00BB",
  "id" : 283709464324997120,
  "created_at" : "2012-12-25 23:03:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283575406664237057",
  "geo" : { },
  "id_str" : "283576253330628609",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon verdammt. Stricksocken sind doch beste Socken!",
  "id" : 283576253330628609,
  "in_reply_to_status_id" : 283575406664237057,
  "created_at" : "2012-12-25 14:13:42 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283575723631984640",
  "text" : "\u00ABIch hab nachgefragt. Stricknadeln sind an Bord von Flugzeugen verboten. Naja, dann h\u00E4kle ich halt wenn wir nach LA fliegen.\u00BB",
  "id" : 283575723631984640,
  "created_at" : "2012-12-25 14:11:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283574603375321088",
  "geo" : { },
  "id_str" : "283575114371584000",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ich auch? :P",
  "id" : 283575114371584000,
  "in_reply_to_status_id" : 283574603375321088,
  "created_at" : "2012-12-25 14:09:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283573034386862082",
  "text" : "\u00ABDas ist selbst gemachter Honiglik\u00F6r. Also eigentlich ist es Honig in Korn gel\u00F6st.\u00BB Willkommen in Westfalen.",
  "id" : 283573034386862082,
  "created_at" : "2012-12-25 14:00:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283377435834187776",
  "text" : "Habe ich euch schon erz\u00E4hlt wie awesome meine Wahlfamilie ist? (Auch wenn sie Alt trinkt)",
  "id" : 283377435834187776,
  "created_at" : "2012-12-25 01:03:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grybelfix",
      "screen_name" : "grybelfix",
      "indices" : [ 0, 10 ],
      "id_str" : "415804530",
      "id" : 415804530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283255631157284865",
  "geo" : { },
  "id_str" : "283263229629702144",
  "in_reply_to_user_id" : 415804530,
  "text" : "@grybelfix meinen Master um noch Intellektueller zu werden. ;)",
  "id" : 283263229629702144,
  "in_reply_to_status_id" : 283255631157284865,
  "created_at" : "2012-12-24 17:29:51 +0000",
  "in_reply_to_screen_name" : "grybelfix",
  "in_reply_to_user_id_str" : "415804530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283254269719764992",
  "text" : "Das Beste an diesem fiesen Husten: Leute schauen so als w\u00E4re ich Patient Zero und halten Abstand.",
  "id" : 283254269719764992,
  "created_at" : "2012-12-24 16:54:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grybelfix",
      "screen_name" : "grybelfix",
      "indices" : [ 0, 10 ],
      "id_str" : "415804530",
      "id" : 415804530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283253227330355200",
  "geo" : { },
  "id_str" : "283253611172073473",
  "in_reply_to_user_id" : 415804530,
  "text" : "@grybelfix leider nein, am 27. geht es wieder nach Frankfurt zur\u00FCck.",
  "id" : 283253611172073473,
  "in_reply_to_status_id" : 283253227330355200,
  "created_at" : "2012-12-24 16:51:38 +0000",
  "in_reply_to_screen_name" : "grybelfix",
  "in_reply_to_user_id_str" : "415804530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grybelfix",
      "screen_name" : "grybelfix",
      "indices" : [ 0, 10 ],
      "id_str" : "415804530",
      "id" : 415804530
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 89, 100 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283250312918204416",
  "geo" : { },
  "id_str" : "283251256967966722",
  "in_reply_to_user_id" : 415804530,
  "text" : "@grybelfix ich bin ja ins genauso provinzielle Frankfurt gegangen, nicht nach Berlin wie @plaetzchen :P",
  "id" : 283251256967966722,
  "in_reply_to_status_id" : 283250312918204416,
  "created_at" : "2012-12-24 16:42:16 +0000",
  "in_reply_to_screen_name" : "grybelfix",
  "in_reply_to_user_id_str" : "415804530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grybelfix",
      "screen_name" : "grybelfix",
      "indices" : [ 0, 10 ],
      "id_str" : "415804530",
      "id" : 415804530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283243914822041600",
  "geo" : { },
  "id_str" : "283244114936471552",
  "in_reply_to_user_id" : 415804530,
  "text" : "@grybelfix ja, die buckelige Verwandtschaft besuchen ;)",
  "id" : 283244114936471552,
  "in_reply_to_status_id" : 283243914822041600,
  "created_at" : "2012-12-24 16:13:54 +0000",
  "in_reply_to_screen_name" : "grybelfix",
  "in_reply_to_user_id_str" : "415804530",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.21781023, 7.5496085301 ]
  },
  "id_str" : "283240884315758592",
  "text" : "\u00ABBitte hier nicht aussteigen.\u00BB Immerhin warnt einen die Bahn vor Hagen.",
  "id" : 283240884315758592,
  "created_at" : "2012-12-24 16:01:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "indices" : [ 3, 11 ],
      "id_str" : "19863141",
      "id" : 19863141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283223890581413890",
  "text" : "RT @cdarwin: A blank &amp; idle day",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.thebeaglevoyage.com\/\" rel=\"nofollow\"\u003EHMSBeagle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283223262949945347",
    "text" : "A blank &amp; idle day",
    "id" : 283223262949945347,
    "created_at" : "2012-12-24 14:51:02 +0000",
    "user" : {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "protected" : false,
      "id_str" : "19863141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/75125076\/darwin_normal.jpg",
      "id" : 19863141,
      "verified" : false
    }
  },
  "id" : 283223890581413890,
  "created_at" : "2012-12-24 14:53:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/3gt7kXRG",
      "expanded_url" : "http:\/\/j.mp\/UXaLyN",
      "display_url" : "j.mp\/UXaLyN"
    } ]
  },
  "geo" : { },
  "id_str" : "283223282554126336",
  "text" : "How Intelligent is IQ? http:\/\/t.co\/3gt7kXRG",
  "id" : 283223282554126336,
  "created_at" : "2012-12-24 14:51:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/fZD0Csx1",
      "expanded_url" : "http:\/\/j.mp\/TgDEI2",
      "display_url" : "j.mp\/TgDEI2"
    } ]
  },
  "geo" : { },
  "id_str" : "283222302575968256",
  "text" : "Great to see how citizen science is no longer limited to data collection: The gift of creativity in citizen science http:\/\/t.co\/fZD0Csx1",
  "id" : 283222302575968256,
  "created_at" : "2012-12-24 14:47:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "supergarv",
      "screen_name" : "supergarv",
      "indices" : [ 0, 10 ],
      "id_str" : "14340395",
      "id" : 14340395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283220506814058496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.6864740206, 7.1577915218 ]
  },
  "id_str" : "283220800448892929",
  "in_reply_to_user_id" : 14340395,
  "text" : "@supergarv gut zu wissen. :)",
  "id" : 283220800448892929,
  "in_reply_to_status_id" : 283220506814058496,
  "created_at" : "2012-12-24 14:41:15 +0000",
  "in_reply_to_screen_name" : "supergarv",
  "in_reply_to_user_id_str" : "14340395",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "supergarv",
      "screen_name" : "supergarv",
      "indices" : [ 0, 10 ],
      "id_str" : "14340395",
      "id" : 14340395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283219958291369985",
  "geo" : { },
  "id_str" : "283220362303512576",
  "in_reply_to_user_id" : 14340395,
  "text" : "@supergarv ich hab leider gerade aufs Display geschaut als wir durchgefahren sind. ;)",
  "id" : 283220362303512576,
  "in_reply_to_status_id" : 283219958291369985,
  "created_at" : "2012-12-24 14:39:31 +0000",
  "in_reply_to_screen_name" : "supergarv",
  "in_reply_to_user_id_str" : "14340395",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Heitmann",
      "screen_name" : "dictvm",
      "indices" : [ 0, 7 ],
      "id_str" : "49569961",
      "id" : 49569961
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 8, 12 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283219108454072320",
  "geo" : { },
  "id_str" : "283219676731949057",
  "in_reply_to_user_id" : 49569961,
  "text" : "@dictvm @scy die Plastikgabeln die Lufthansa beim Essen verteilt haben iirc eine gezackte Seite. Man muss nur wollen!",
  "id" : 283219676731949057,
  "in_reply_to_status_id" : 283219108454072320,
  "created_at" : "2012-12-24 14:36:47 +0000",
  "in_reply_to_screen_name" : "dictvm",
  "in_reply_to_user_id_str" : "49569961",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283218877230485505",
  "text" : "Last Minute Geschenke done right: \u00ABHat jemand in diesem Zug eine Schere dabei? In Wagen 3 wollen noch Leute ihre Geschenke verpacken.\u00BB",
  "id" : 283218877230485505,
  "created_at" : "2012-12-24 14:33:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/OjcgnjRC",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=Z12t26o1KDI",
      "display_url" : "youtube.com\/watch?v=Z12t26\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "283215788318523393",
  "geo" : { },
  "id_str" : "283217880437358593",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot YouTube ist eine tolle Fundgrube f\u00FCr Tiersexexperten. http:\/\/t.co\/OjcgnjRC",
  "id" : 283217880437358593,
  "in_reply_to_status_id" : 283215788318523393,
  "created_at" : "2012-12-24 14:29:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283215881658572800",
  "geo" : { },
  "id_str" : "283216261545086976",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur Thanks! And I\u2019ve no wishes for it, love to see what you will write about :)",
  "id" : 283216261545086976,
  "in_reply_to_status_id" : 283215881658572800,
  "created_at" : "2012-12-24 14:23:13 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/PkhuYoV6",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=L2N-8oPOV78",
      "display_url" : "youtube.com\/watch?v=L2N-8o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "283213677065273344",
  "geo" : { },
  "id_str" : "283214520225243136",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot \u201Eshe\u2019s so laid back!\u201C http:\/\/t.co\/PkhuYoV6",
  "id" : 283214520225243136,
  "in_reply_to_status_id" : 283213677065273344,
  "created_at" : "2012-12-24 14:16:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283212741769035778",
  "text" : "RT @edyong209: Seriously, if one more person talks about \"disrupting the disruptors\", Imma disrupt your face.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283212574638612480",
    "text" : "Seriously, if one more person talks about \"disrupting the disruptors\", Imma disrupt your face.",
    "id" : 283212574638612480,
    "created_at" : "2012-12-24 14:08:34 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 283212741769035778,
  "created_at" : "2012-12-24 14:09:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283211578768228352",
  "geo" : { },
  "id_str" : "283212196199149572",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur I envy your trip. During my paleontology course we only took google earth to Ngorongoro. Looks like you had a great time there. :)",
  "id" : 283212196199149572,
  "in_reply_to_status_id" : 283211578768228352,
  "created_at" : "2012-12-24 14:07:04 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 3, 10 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ngorongoro",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283211333980278788",
  "text" : "RT @Gurdur: Dunno if I tweeted this before, but hey. Me on the rim of the #Ngorongoro crater\/caldera. Truly massive super-caldera http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gurdur\/status\/283210822044487680\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/arBYm1kw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-4qvf1CEAAqzPj.jpg",
        "id_str" : "283210822057070592",
        "id" : 283210822057070592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-4qvf1CEAAqzPj.jpg",
        "sizes" : [ {
          "h" : 158,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/arBYm1kw"
      } ],
      "hashtags" : [ {
        "text" : "Ngorongoro",
        "indices" : [ 62, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283210822044487680",
    "text" : "Dunno if I tweeted this before, but hey. Me on the rim of the #Ngorongoro crater\/caldera. Truly massive super-caldera http:\/\/t.co\/arBYm1kw",
    "id" : 283210822044487680,
    "created_at" : "2012-12-24 14:01:37 +0000",
    "user" : {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "protected" : false,
      "id_str" : "125928028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721158367398506496\/c4cchuLu_normal.jpg",
      "id" : 125928028,
      "verified" : false
    }
  },
  "id" : 283211333980278788,
  "created_at" : "2012-12-24 14:03:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/T8rv9Rqp",
      "expanded_url" : "http:\/\/andthencamebeard.tumblr.com\/post\/20719491694\/you-really-dont-see-enough-beard-bondage-these",
      "display_url" : "andthencamebeard.tumblr.com\/post\/207194916\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "283210004847263744",
  "text" : "\u00ABYou really don\u2019t see enough beard bondage these days\u2026 shame.\u00BB http:\/\/t.co\/T8rv9Rqp",
  "id" : 283210004847263744,
  "created_at" : "2012-12-24 13:58:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283209366100918272",
  "text" : "RT @Lobot: Thrust me, I'm a linguist.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "283207344421208064",
    "text" : "Thrust me, I'm a linguist.",
    "id" : 283207344421208064,
    "created_at" : "2012-12-24 13:47:47 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 283209366100918272,
  "created_at" : "2012-12-24 13:55:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283206188752064514",
  "text" : "Und: Soll es ein ehrliches Signal sein weil man nicht entsprechend verr\u00FCckt spielen kann oder \u201Eich bin verr\u00FCckt und lebe trotzdem\u201C?",
  "id" : 283206188752064514,
  "created_at" : "2012-12-24 13:43:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283205177731866624",
  "text" : "Den \u00ABmilden Wahnsinn der Verliebten\u00BB mit den Luftspr\u00FCngen von Thomson-Gazellen als ehrliches Signal zu vergleichen ist auch etwas gewagt\u2026",
  "id" : 283205177731866624,
  "created_at" : "2012-12-24 13:39:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283202298451197952",
  "geo" : { },
  "id_str" : "283203282535596032",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 ich hatte es neulich schon mal getwittert: Er macht diese Dokus jetzt schon l\u00E4nger als das 1000j\u00E4hrige Reich angedauert hat.",
  "id" : 283203282535596032,
  "in_reply_to_status_id" : 283202298451197952,
  "created_at" : "2012-12-24 13:31:38 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283201796103630848",
  "geo" : { },
  "id_str" : "283202151256322048",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 ich wollte gerade sagen: Guido Knopp pr\u00E4sentiert \u00ABBlondies Weihnachsgeschenke\u00BB",
  "id" : 283202151256322048,
  "in_reply_to_status_id" : 283201796103630848,
  "created_at" : "2012-12-24 13:27:09 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283201256569315329",
  "geo" : { },
  "id_str" : "283201495388790784",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 mit Nikolaus-M\u00FCtze auf w\u00E4re das dabei sogar cool gewesen. ;)",
  "id" : 283201495388790784,
  "in_reply_to_status_id" : 283201256569315329,
  "created_at" : "2012-12-24 13:24:32 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/MqrUhWHO",
      "expanded_url" : "http:\/\/instagr.am\/p\/TnuYuvBwuz\/",
      "display_url" : "instagr.am\/p\/TnuYuvBwuz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "283200210795102208",
  "text" : "Das Mem hatte auch schon mal bessere Captions http:\/\/t.co\/MqrUhWHO",
  "id" : 283200210795102208,
  "created_at" : "2012-12-24 13:19:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283195575686529024",
  "text" : "Bei den Temperaturen muss ich ja hoffen das die Klimaanlage des ICE gleich nicht kaputt ist.",
  "id" : 283195575686529024,
  "created_at" : "2012-12-24 13:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/XQ9c2ZpL",
      "expanded_url" : "http:\/\/j.mp\/TgtBTf",
      "display_url" : "j.mp\/TgtBTf"
    } ]
  },
  "geo" : { },
  "id_str" : "283185629456633856",
  "text" : "Santa Claus: a public health pariah http:\/\/t.co\/XQ9c2ZpL",
  "id" : 283185629456633856,
  "created_at" : "2012-12-24 12:21:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/uI26Ccgi",
      "expanded_url" : "http:\/\/j.mp\/V5C9do",
      "display_url" : "j.mp\/V5C9do"
    } ]
  },
  "geo" : { },
  "id_str" : "283169641910648832",
  "text" : "This is a post about shooters, Katy Perry and Pop Culture http:\/\/t.co\/uI26Ccgi",
  "id" : 283169641910648832,
  "created_at" : "2012-12-24 11:17:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NineBerry",
      "screen_name" : "NineBerry",
      "indices" : [ 0, 10 ],
      "id_str" : "30478074",
      "id" : 30478074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282935685537734656",
  "geo" : { },
  "id_str" : "282936129852948480",
  "in_reply_to_user_id" : 30478074,
  "text" : "@NineBerry danke f\u00FCr den Hinweis. Finde es auch auf der Seite nicht, sondern nur im Google Reader o_O Scheinbar gel\u00F6scht\/inaktiv zur Zeit.",
  "id" : 282936129852948480,
  "in_reply_to_status_id" : 282935685537734656,
  "created_at" : "2012-12-23 19:50:04 +0000",
  "in_reply_to_screen_name" : "NineBerry",
  "in_reply_to_user_id_str" : "30478074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/UaCiaAON",
      "expanded_url" : "http:\/\/j.mp\/UZQd9a",
      "display_url" : "j.mp\/UZQd9a"
    } ]
  },
  "geo" : { },
  "id_str" : "282935542805590017",
  "text" : "Darwin\u2019s asylum http:\/\/t.co\/UaCiaAON",
  "id" : 282935542805590017,
  "created_at" : "2012-12-23 19:47:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/1pRoPZ0E",
      "expanded_url" : "http:\/\/j.mp\/VXppVs",
      "display_url" : "j.mp\/VXppVs"
    } ]
  },
  "geo" : { },
  "id_str" : "282813820940988417",
  "text" : "Is The Exotic Erotic? Probably Not\u2026 http:\/\/t.co\/1pRoPZ0E",
  "id" : 282813820940988417,
  "created_at" : "2012-12-23 11:44:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/lncj01eU",
      "expanded_url" : "http:\/\/j.mp\/VXp05v",
      "display_url" : "j.mp\/VXp05v"
    } ]
  },
  "geo" : { },
  "id_str" : "282812096662630400",
  "text" : "Calvin and Hobbes guitar refurb http:\/\/t.co\/lncj01eU",
  "id" : 282812096662630400,
  "created_at" : "2012-12-23 11:37:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Bloom",
      "screen_name" : "MattBloomFilms",
      "indices" : [ 3, 18 ],
      "id_str" : "32591490",
      "id" : 32591490
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MattBloomFilms\/status\/282794718750990336\/photo\/1",
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/FE80vbbU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-ywTGPCYAAQNP9.jpg",
      "id_str" : "282794718755184640",
      "id" : 282794718755184640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-ywTGPCYAAQNP9.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 288
      }, {
        "h" : 1016,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1016,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 1016,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/FE80vbbU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282810527326035968",
  "text" : "RT @MattBloomFilms: Genius... http:\/\/t.co\/FE80vbbU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MattBloomFilms\/status\/282794718750990336\/photo\/1",
        "indices" : [ 10, 30 ],
        "url" : "http:\/\/t.co\/FE80vbbU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-ywTGPCYAAQNP9.jpg",
        "id_str" : "282794718755184640",
        "id" : 282794718755184640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-ywTGPCYAAQNP9.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 288
        }, {
          "h" : 1016,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1016,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 1016,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/FE80vbbU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282794718750990336",
    "text" : "Genius... http:\/\/t.co\/FE80vbbU",
    "id" : 282794718750990336,
    "created_at" : "2012-12-23 10:28:10 +0000",
    "user" : {
      "name" : "Matt Bloom",
      "screen_name" : "MattBloomFilms",
      "protected" : false,
      "id_str" : "32591490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/891364268809039872\/MyOuPVVh_normal.jpg",
      "id" : 32591490,
      "verified" : false
    }
  },
  "id" : 282810527326035968,
  "created_at" : "2012-12-23 11:30:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 0, 8 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282802022116380672",
  "geo" : { },
  "id_str" : "282805781735284736",
  "in_reply_to_user_id" : 107502279,
  "text" : "@pulegon haha, die hab ich ja seit Jahren nicht mehr geh\u00F6rt!",
  "id" : 282805781735284736,
  "in_reply_to_status_id" : 282802022116380672,
  "created_at" : "2012-12-23 11:12:07 +0000",
  "in_reply_to_screen_name" : "pulegon",
  "in_reply_to_user_id_str" : "107502279",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282800152350167040",
  "text" : "\u00ABDu bist ja wieder da!\u00BB\u2014\u00ABGlaubst du ernsthaft ich w\u00FCrde dich verlassen ohne meine Netzteile und Ladeger\u00E4te einzupacken?\u00BB",
  "id" : 282800152350167040,
  "created_at" : "2012-12-23 10:49:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282795221908082688",
  "text" : "Can\u2019t help but think of Needleman as a voodoo superhero.",
  "id" : 282795221908082688,
  "created_at" : "2012-12-23 10:30:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/Io6jubWp",
      "expanded_url" : "http:\/\/instagr.am\/p\/TkyKn-BwhM\/",
      "display_url" : "instagr.am\/p\/TkyKn-BwhM\/"
    } ]
  },
  "geo" : { },
  "id_str" : "282786274845274112",
  "text" : "Hochwasser http:\/\/t.co\/Io6jubWp",
  "id" : 282786274845274112,
  "created_at" : "2012-12-23 09:54:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/J0jNEnmN",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=o9pEzgHorH0",
      "display_url" : "youtube.com\/watch?v=o9pEzg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282646603322490880",
  "text" : "Stop writing classes! http:\/\/t.co\/J0jNEnmN",
  "id" : 282646603322490880,
  "created_at" : "2012-12-23 00:39:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "indices" : [ 3, 9 ],
      "id_str" : "17567533",
      "id" : 17567533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/3594G9qT",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/12\/23\/fashion\/noted-a-vibrator-that-will-make-her-thankful-for-the-memory.html?_r=0",
      "display_url" : "nytimes.com\/2012\/12\/23\/fas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282646238359334913",
  "text" : "RT @BoraZ: A Vibrator That with built-in flash memory, not flesh memory: http:\/\/t.co\/3594G9qT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/3594G9qT",
        "expanded_url" : "http:\/\/www.nytimes.com\/2012\/12\/23\/fashion\/noted-a-vibrator-that-will-make-her-thankful-for-the-memory.html?_r=0",
        "display_url" : "nytimes.com\/2012\/12\/23\/fas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "282640597368586240",
    "text" : "A Vibrator That with built-in flash memory, not flesh memory: http:\/\/t.co\/3594G9qT",
    "id" : 282640597368586240,
    "created_at" : "2012-12-23 00:15:44 +0000",
    "user" : {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "protected" : false,
      "id_str" : "17567533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651779136\/b927bab618cdf46063f9c265817f3a8a_normal.jpeg",
      "id" : 17567533,
      "verified" : false
    }
  },
  "id" : 282646238359334913,
  "created_at" : "2012-12-23 00:38:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282636350140858369",
  "text" : "\u00ABH\u00F6rst du wieder mittelm\u00E4ssige Musik von mittelm\u00E4ssigen Biologen?\u00BB \u00ABNaja, Bad Religion heisst nicht automatisch Good Science\u2026\u00BB",
  "id" : 282636350140858369,
  "created_at" : "2012-12-22 23:58:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282610376997236736",
  "geo" : { },
  "id_str" : "282611007006842880",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy but given that it\u2019s past 11pm here I say: Screw that, I\u2019ll give it another try tomorrow :)",
  "id" : 282611007006842880,
  "in_reply_to_status_id" : 282610376997236736,
  "created_at" : "2012-12-22 22:18:09 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282610376997236736",
  "geo" : { },
  "id_str" : "282610746817396738",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy yes, testing is too often lacking, totally agree. None of those, I\u2019m working on unannotated mollusk transcriptomes.",
  "id" : 282610746817396738,
  "in_reply_to_status_id" : 282610376997236736,
  "created_at" : "2012-12-22 22:17:07 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282607542968918016",
  "geo" : { },
  "id_str" : "282607976706084864",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy well, except if you think that it\u2019s enough that they share the same alphabet\u2026",
  "id" : 282607976706084864,
  "in_reply_to_status_id" : 282607542968918016,
  "created_at" : "2012-12-22 22:06:06 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282607542968918016",
  "geo" : { },
  "id_str" : "282607899761582080",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy my best guess for now: It\u2019s an upstream problem in the prediction software (again). No way that this ORF was based on that input",
  "id" : 282607899761582080,
  "in_reply_to_status_id" : 282607542968918016,
  "created_at" : "2012-12-22 22:05:48 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282607263775080449",
  "text" : "mapping my predicted reading frames to the original cdna-contigs shouldn't result in lots of seemingly random alignable fragments...",
  "id" : 282607263775080449,
  "created_at" : "2012-12-22 22:03:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/RkUKwkkm",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=qm8n0vhVJcg",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282592871331266560",
  "text" : "Lou Reed, reading Porn Ads http:\/\/t.co\/RkUKwkkm",
  "id" : 282592871331266560,
  "created_at" : "2012-12-22 21:06:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282589334094356480",
  "text" : "\u00ABIch k\u00F6nnte schon wieder einem Entwickler verhauen. Nur diesmal wohnt er im Geltungsbereich des Semestertickets und nicht in Frankreich\u00BB",
  "id" : 282589334094356480,
  "created_at" : "2012-12-22 20:52:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282584034809356288",
  "text" : "ffs! if you ever write software that predicts peptide sequences: give back the correct(!) positions in the query nt-sequence.",
  "id" : 282584034809356288,
  "created_at" : "2012-12-22 20:30:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282575586055032833",
  "text" : "\u00ABI\u2019d love some chickpeas. With amphetamines!\u00BB",
  "id" : 282575586055032833,
  "created_at" : "2012-12-22 19:57:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Lorenz",
      "screen_name" : "mitZett",
      "indices" : [ 0, 8 ],
      "id_str" : "8517622",
      "id" : 8517622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282541254800191489",
  "geo" : { },
  "id_str" : "282541651174514688",
  "in_reply_to_user_id" : 8517622,
  "text" : "@mitZett Ich hab auch so einen. Deshalb war es nicht ganz so schwer ;)",
  "id" : 282541651174514688,
  "in_reply_to_status_id" : 282541254800191489,
  "created_at" : "2012-12-22 17:42:33 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Lorenz",
      "screen_name" : "mitZett",
      "indices" : [ 0, 8 ],
      "id_str" : "8517622",
      "id" : 8517622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282540271399473152",
  "geo" : { },
  "id_str" : "282541155391008768",
  "in_reply_to_user_id" : 8517622,
  "text" : "@mitZett Eine Stiftkappe?",
  "id" : 282541155391008768,
  "in_reply_to_status_id" : 282540271399473152,
  "created_at" : "2012-12-22 17:40:35 +0000",
  "in_reply_to_screen_name" : "mitZett",
  "in_reply_to_user_id_str" : "8517622",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282522858457026560",
  "text" : "\u00ABDiese Leute. Erst gehen sie nicht einkaufen weil sie glauben das die Apokalypse kommt. Und heute verstopfen sie die L\u00E4den.\u00BB",
  "id" : 282522858457026560,
  "created_at" : "2012-12-22 16:27:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/7TaFMWA4",
      "expanded_url" : "http:\/\/j.mp\/U3jlLA",
      "display_url" : "j.mp\/U3jlLA"
    } ]
  },
  "geo" : { },
  "id_str" : "282459278676217856",
  "text" : "Totally missed that 23andMe will perform phasing where possible! Really want this data to be available as well. http:\/\/t.co\/7TaFMWA4",
  "id" : 282459278676217856,
  "created_at" : "2012-12-22 12:15:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    }, {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "indices" : [ 15, 25 ],
      "id_str" : "42300167",
      "id" : 42300167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282450112666546178",
  "geo" : { },
  "id_str" : "282450588002811905",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal @hughhowey No problem. Good luck finding the dead tree version! :-)",
  "id" : 282450588002811905,
  "in_reply_to_status_id" : 282450112666546178,
  "created_at" : "2012-12-22 11:40:42 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    }, {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "indices" : [ 15, 25 ],
      "id_str" : "42300167",
      "id" : 42300167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/BVBj3mmj",
      "expanded_url" : "http:\/\/www.amazon.com\/Wool-Omnibus-Edition-ebook\/dp\/B0071XO8RA",
      "display_url" : "amazon.com\/Wool-Omnibus-E\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "282443567182524416",
  "geo" : { },
  "id_str" : "282444874584825857",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal @hughhowey here\u2019s it in the US store. Looked like the Kindle version isn\u2019t available in the UK store? http:\/\/t.co\/BVBj3mmj",
  "id" : 282444874584825857,
  "in_reply_to_status_id" : 282443567182524416,
  "created_at" : "2012-12-22 11:18:00 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    }, {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "indices" : [ 15, 25 ],
      "id_str" : "42300167",
      "id" : 42300167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282443567182524416",
  "geo" : { },
  "id_str" : "282444151558127616",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal @hughhowey Not sure if their available without DRM. I personally bought it on Amazon (including DRM unfortunately).",
  "id" : 282444151558127616,
  "in_reply_to_status_id" : 282443567182524416,
  "created_at" : "2012-12-22 11:15:07 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/3MR02lAy",
      "expanded_url" : "http:\/\/www.empiricalzeal.com\/2012\/12\/21\/what-does-randomness-look-like\/",
      "display_url" : "empiricalzeal.com\/2012\/12\/21\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282438502820478978",
  "text" : "\u00ABA single incidence of death by horse kick is rare (and assumedly independent, unless the horses have a hidden agenda)\u00BB http:\/\/t.co\/3MR02lAy",
  "id" : 282438502820478978,
  "created_at" : "2012-12-22 10:52:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh Howey",
      "screen_name" : "hughhowey",
      "indices" : [ 65, 75 ],
      "id_str" : "42300167",
      "id" : 42300167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/0RmqkLnu",
      "expanded_url" : "http:\/\/j.mp\/Ta92Ks",
      "display_url" : "j.mp\/Ta92Ks"
    } ]
  },
  "geo" : { },
  "id_str" : "282436700934922242",
  "text" : "Word! \u00ABIf the only new author I'd been introduced to in 2012 was @hughhowey,then 2012 would have been a fantastic year\u00BB http:\/\/t.co\/0RmqkLnu",
  "id" : 282436700934922242,
  "created_at" : "2012-12-22 10:45:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282422770195902464",
  "geo" : { },
  "id_str" : "282424538145386496",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy bestimmt nur ein \u201Ewir leben ja leider doch noch alle\u201C-Hangover.",
  "id" : 282424538145386496,
  "in_reply_to_status_id" : 282422770195902464,
  "created_at" : "2012-12-22 09:57:11 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282422200928174080",
  "text" : "Irrationale Zukunfts\u00E4ngste f\u00FCr 1000.",
  "id" : 282422200928174080,
  "created_at" : "2012-12-22 09:47:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282221043140161536",
  "text" : "\u00ABSecretly, we know we\u2019ll survive. All those other folks will die. That\u2019s what after-the-bomb stories are all about\u00BB \u2014 John Varley",
  "id" : 282221043140161536,
  "created_at" : "2012-12-21 20:28:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282220410320326656",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma beabsichtigt gel\u00F6scht. Unabsichtlich dort gespeichert. Brb, emptying trash. :P",
  "id" : 282220410320326656,
  "created_at" : "2012-12-21 20:26:03 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282220013824397312",
  "geo" : { },
  "id_str" : "282220165788229635",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay ich weiss was da steht. Aber egal was das Verb ist: 140k Dateien und Desktop vertragen sich nicht. ;)",
  "id" : 282220165788229635,
  "in_reply_to_status_id" : 282220013824397312,
  "created_at" : "2012-12-21 20:25:05 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282219080994398208",
  "geo" : { },
  "id_str" : "282219293830168576",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay files! ;)",
  "id" : 282219293830168576,
  "in_reply_to_status_id" : 282219080994398208,
  "created_at" : "2012-12-21 20:21:37 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282218955941232640",
  "text" : "I accidentally 140k files on my desktop\u2026",
  "id" : 282218955941232640,
  "created_at" : "2012-12-21 20:20:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kennedy Lewis",
      "screen_name" : "ncbirofl",
      "indices" : [ 3, 12 ],
      "id_str" : "1664474352",
      "id" : 1664474352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/x5KYN2Re",
      "expanded_url" : "http:\/\/bit.ly\/YuxYOi",
      "display_url" : "bit.ly\/YuxYOi"
    } ]
  },
  "geo" : { },
  "id_str" : "282197288846229505",
  "text" : "RT @ncbirofl: NCBI ROFL: Finally, science weighs in: should you give it up on the first date? http:\/\/t.co\/x5KYN2Re",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/x5KYN2Re",
        "expanded_url" : "http:\/\/bit.ly\/YuxYOi",
        "display_url" : "bit.ly\/YuxYOi"
      } ]
    },
    "geo" : { },
    "id_str" : "282195408195813377",
    "text" : "NCBI ROFL: Finally, science weighs in: should you give it up on the first date? http:\/\/t.co\/x5KYN2Re",
    "id" : 282195408195813377,
    "created_at" : "2012-12-21 18:46:42 +0000",
    "user" : {
      "name" : "Seriously, Science?",
      "screen_name" : "srslyscience",
      "protected" : false,
      "id_str" : "52496912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664320968\/Photo_on_2010-01-11_at_18.59__2_normal.jpg",
      "id" : 52496912,
      "verified" : false
    }
  },
  "id" : 282197288846229505,
  "created_at" : "2012-12-21 18:54:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282196052990361600",
  "geo" : { },
  "id_str" : "282196328564539393",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma Deutsche Forschungsinstitute -&gt; Gef\u00FChlt 3 kg Papier zum Unterzeichen bekommen.",
  "id" : 282196328564539393,
  "in_reply_to_status_id" : 282196052990361600,
  "created_at" : "2012-12-21 18:50:22 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282195803995533312",
  "text" : "Neuen Arbeitsvertrag unterschrieben. Bin mir fast sicher das ich irgendwo im Kleingedruckten meine Seele dem Teufel verkauft habe.",
  "id" : 282195803995533312,
  "created_at" : "2012-12-21 18:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282186535992963073",
  "geo" : { },
  "id_str" : "282188508628676609",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj tell me about it. ;)",
  "id" : 282188508628676609,
  "in_reply_to_status_id" : 282186535992963073,
  "created_at" : "2012-12-21 18:19:17 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282185989152202752",
  "geo" : { },
  "id_str" : "282186136120598530",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj besser aber noch nicht \u00FCberzeugend.",
  "id" : 282186136120598530,
  "in_reply_to_status_id" : 282185989152202752,
  "created_at" : "2012-12-21 18:09:52 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gilbster",
      "screen_name" : "ggggilbster",
      "indices" : [ 0, 12 ],
      "id_str" : "56975274",
      "id" : 56975274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282185809665335296",
  "geo" : { },
  "id_str" : "282185887297724416",
  "in_reply_to_user_id" : 56975274,
  "text" : "@ggggilbster hatte zu viele Zeichen. ;)",
  "id" : 282185887297724416,
  "in_reply_to_status_id" : 282185809665335296,
  "created_at" : "2012-12-21 18:08:52 +0000",
  "in_reply_to_screen_name" : "ggggilbster",
  "in_reply_to_user_id_str" : "56975274",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282175002512617472",
  "geo" : { },
  "id_str" : "282185640865574913",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj aber die Uniformen sind jetzt nicht so sexy.",
  "id" : 282185640865574913,
  "in_reply_to_status_id" : 282175002512617472,
  "created_at" : "2012-12-21 18:07:54 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282185523857088512",
  "text" : "\u00ABIch bin ein Entrepreneur!\u00BB\u2014\u00ABDu meinst du bist Pleite weil du zu viele Kickstarter- &amp; Indiegogo-Projekte unterst\u00FCtzt hast?\u00BB\u2014\u00ABEntrepreneur!\u00BB",
  "id" : 282185523857088512,
  "created_at" : "2012-12-21 18:07:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 3, 17 ],
      "id_str" : "228586748",
      "id" : 228586748
    }, {
      "name" : "Jennifer Gardy",
      "screen_name" : "jennifergardy",
      "indices" : [ 22, 36 ],
      "id_str" : "20478716",
      "id" : 20478716
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jennifergardy\/status\/282176753819086849\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/mlTUY1w4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-p-QzgCcAAhPpM.jpg",
      "id_str" : "282176753831669760",
      "id" : 282176753831669760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-p-QzgCcAAhPpM.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/mlTUY1w4"
    } ],
    "hashtags" : [ {
      "text" : "stillshrinkwrapped",
      "indices" : [ 81, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282183397017780224",
  "text" : "RT @BioMickWatson: MT @jennifergardy Bioinformatics types - here's Entrez c.1996 #stillshrinkwrapped http:\/\/t.co\/mlTUY1w4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Gardy",
        "screen_name" : "jennifergardy",
        "indices" : [ 3, 17 ],
        "id_str" : "20478716",
        "id" : 20478716
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jennifergardy\/status\/282176753819086849\/photo\/1",
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/mlTUY1w4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-p-QzgCcAAhPpM.jpg",
        "id_str" : "282176753831669760",
        "id" : 282176753831669760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-p-QzgCcAAhPpM.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/mlTUY1w4"
      } ],
      "hashtags" : [ {
        "text" : "stillshrinkwrapped",
        "indices" : [ 62, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282182095051309056",
    "text" : "MT @jennifergardy Bioinformatics types - here's Entrez c.1996 #stillshrinkwrapped http:\/\/t.co\/mlTUY1w4",
    "id" : 282182095051309056,
    "created_at" : "2012-12-21 17:53:48 +0000",
    "user" : {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "protected" : false,
      "id_str" : "228586748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870214569679093760\/YIZGIDTS_normal.jpg",
      "id" : 228586748,
      "verified" : false
    }
  },
  "id" : 282183397017780224,
  "created_at" : "2012-12-21 17:58:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/RdMuVBbx",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/chadwickmatlin\/meet-the-entrepreneur-behind-the-apocalypses-must",
      "display_url" : "buzzfeed.com\/chadwickmatlin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282156507603279872",
  "text" : "Happy Apocalypse! \u00ABThey don\u2019t just want a shovel with a crowbar, they want a shovel that can kill somebody.\u00BB http:\/\/t.co\/RdMuVBbx",
  "id" : 282156507603279872,
  "created_at" : "2012-12-21 16:12:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 0, 9 ],
      "id_str" : "14094265",
      "id" : 14094265
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282152015558213632",
  "geo" : { },
  "id_str" : "282152203328815105",
  "in_reply_to_user_id" : 14094265,
  "text" : "@snooze82 Ja, @PhilippBayer hatte es heute Nacht noch verlinkt. Aber trotzdem vielen Dank :)",
  "id" : 282152203328815105,
  "in_reply_to_status_id" : 282152015558213632,
  "created_at" : "2012-12-21 15:55:02 +0000",
  "in_reply_to_screen_name" : "snooze82",
  "in_reply_to_user_id_str" : "14094265",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282141076842749953",
  "geo" : { },
  "id_str" : "282141391612682240",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me tja, die Paketboten finden in der Regel unsere Klingel nie. Die Polizei daf\u00FCr wohl vor allem unsere.",
  "id" : 282141391612682240,
  "in_reply_to_status_id" : 282141076842749953,
  "created_at" : "2012-12-21 15:12:04 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282140945372295169",
  "text" : "\u00ABHey Sexy\u00BB Nicht die perfekte Ansprache wenn man den DHL-Boten an der T\u00FCr erwartet, es aber Polizisten in schusssicherer Weste sind.",
  "id" : 282140945372295169,
  "created_at" : "2012-12-21 15:10:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/zNIrmabZ",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/2012\/12\/21\/edward-bella-and-mcgurk-why-a-bad-lip-synching-is-so-damn-funny\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282114848245051393",
  "text" : "Edward, Bella, and McGurk: Why Bad Lip-Synching Is So Funny http:\/\/t.co\/zNIrmabZ",
  "id" : 282114848245051393,
  "created_at" : "2012-12-21 13:26:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282075404427198464",
  "geo" : { },
  "id_str" : "282075529258074113",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 hehe, Zehnthofstra\u00DFe 36 (plz ist 55252)",
  "id" : 282075529258074113,
  "in_reply_to_status_id" : 282075404427198464,
  "created_at" : "2012-12-21 10:50:21 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282075153846923265",
  "geo" : { },
  "id_str" : "282075242430607360",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 Die Adresse hast du noch? :)",
  "id" : 282075242430607360,
  "in_reply_to_status_id" : 282075153846923265,
  "created_at" : "2012-12-21 10:49:13 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282074840213618688",
  "geo" : { },
  "id_str" : "282074963593273344",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 Aldi &amp; Rewe sind um die Ecke.",
  "id" : 282074963593273344,
  "in_reply_to_status_id" : 282074840213618688,
  "created_at" : "2012-12-21 10:48:06 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282070247375245312",
  "geo" : { },
  "id_str" : "282073419535745024",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 willst auf einen Kaffee hier vorbeikommen? :D",
  "id" : 282073419535745024,
  "in_reply_to_status_id" : 282070247375245312,
  "created_at" : "2012-12-21 10:41:58 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281925161597423617",
  "geo" : { },
  "id_str" : "281925704348729345",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, I need to get some sleep. Probably will be haunted by freakish digit dreams. See you in a couple of hours. :P",
  "id" : 281925704348729345,
  "in_reply_to_status_id" : 281925161597423617,
  "created_at" : "2012-12-21 00:55:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281925161597423617",
  "geo" : { },
  "id_str" : "281925402262380545",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I guess that still wouldn\u2019t fit. Even a hobbit with slender digits wouldn\u2019t fit!",
  "id" : 281925402262380545,
  "in_reply_to_status_id" : 281925161597423617,
  "created_at" : "2012-12-21 00:53:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281924783719985155",
  "geo" : { },
  "id_str" : "281925007838433280",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer no, because it\u2019s so much easier. ;)",
  "id" : 281925007838433280,
  "in_reply_to_status_id" : 281924783719985155,
  "created_at" : "2012-12-21 00:52:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281924430400200704",
  "geo" : { },
  "id_str" : "281924787931070465",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer there\u2019s a fetish for everything in Japan but that sounds more like a horrific developmental disease.",
  "id" : 281924787931070465,
  "in_reply_to_status_id" : 281924430400200704,
  "created_at" : "2012-12-21 00:51:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281924373869375488",
  "geo" : { },
  "id_str" : "281924486150909953",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer better use a Possum. :P",
  "id" : 281924486150909953,
  "in_reply_to_status_id" : 281924373869375488,
  "created_at" : "2012-12-21 00:50:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281923779364540416",
  "geo" : { },
  "id_str" : "281924040950706176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, but I doubt that people with fingers that size exist.",
  "id" : 281924040950706176,
  "in_reply_to_status_id" : 281923779364540416,
  "created_at" : "2012-12-21 00:48:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281921189633486848",
  "geo" : { },
  "id_str" : "281923572358840322",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, but specifically the lab mice: You remember how small they are? Guess you could pull it off with a lab rat.",
  "id" : 281923572358840322,
  "in_reply_to_status_id" : 281921189633486848,
  "created_at" : "2012-12-21 00:46:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281918263741538304",
  "geo" : { },
  "id_str" : "281919172613648384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer though I\u2019m unsure of how you\u2019d actually achieve this without unnecessary harm to the animal.",
  "id" : 281919172613648384,
  "in_reply_to_status_id" : 281918263741538304,
  "created_at" : "2012-12-21 00:29:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281918263741538304",
  "geo" : { },
  "id_str" : "281918975741415424",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, nice. Though the \u201Ehiding a ring inside a mouse\u201C sounds like fun as well. ;)",
  "id" : 281918975741415424,
  "in_reply_to_status_id" : 281918263741538304,
  "created_at" : "2012-12-21 00:28:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281915137617711104",
  "geo" : { },
  "id_str" : "281915559052967936",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer can\u2019t imagine how many badly run gels had to be tried before getting this :P",
  "id" : 281915559052967936,
  "in_reply_to_status_id" : 281915137617711104,
  "created_at" : "2012-12-21 00:14:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/Jkm9bZKo",
      "expanded_url" : "http:\/\/i.imgur.com\/A8wVQ.jpg",
      "display_url" : "i.imgur.com\/A8wVQ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "281915432489861120",
  "text" : "RT @PhilippBayer: Someone posted this on \/r\/biology - beautiful! http:\/\/t.co\/Jkm9bZKo (Also: extremely well-run gel :P )",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/Jkm9bZKo",
        "expanded_url" : "http:\/\/i.imgur.com\/A8wVQ.jpg",
        "display_url" : "i.imgur.com\/A8wVQ.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "281915137617711104",
    "text" : "Someone posted this on \/r\/biology - beautiful! http:\/\/t.co\/Jkm9bZKo (Also: extremely well-run gel :P )",
    "id" : 281915137617711104,
    "created_at" : "2012-12-21 00:13:01 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 281915432489861120,
  "created_at" : "2012-12-21 00:14:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281913279872389121",
  "geo" : { },
  "id_str" : "281913883017494528",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur I will try my best!",
  "id" : 281913883017494528,
  "in_reply_to_status_id" : 281913279872389121,
  "created_at" : "2012-12-21 00:08:02 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281913760942280705",
  "text" : "\u00ABIch Trolle dich ja nur weil ich dich so lieb habe. Und weil du mir noch nicht den Kopf abgerissen hast.\u00BB",
  "id" : 281913760942280705,
  "created_at" : "2012-12-21 00:07:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281912402377859075",
  "text" : "\u00ABWir m\u00FCssen uns mal unser eigenes Nasenspray brauen. Dann kann uns niemand mehr sagen wie oft wir es verwenden d\u00FCrfen!\u00BB",
  "id" : 281912402377859075,
  "created_at" : "2012-12-21 00:02:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "indices" : [ 0, 13 ],
      "id_str" : "26374915",
      "id" : 26374915
    }, {
      "name" : "Kenneth Pfeifer",
      "screen_name" : "kennethpfeifer",
      "indices" : [ 14, 29 ],
      "id_str" : "185742430",
      "id" : 185742430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281910031736250369",
  "in_reply_to_user_id" : 26374915,
  "text" : "@barrycburton @kennethpfeifer Thanks!",
  "id" : 281910031736250369,
  "created_at" : "2012-12-20 23:52:43 +0000",
  "in_reply_to_screen_name" : "barrycburton",
  "in_reply_to_user_id_str" : "26374915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281908646294724608",
  "geo" : { },
  "id_str" : "281908932790853632",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon only a hobo\u2026 ;)",
  "id" : 281908932790853632,
  "in_reply_to_status_id" : 281908646294724608,
  "created_at" : "2012-12-20 23:48:21 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281908401645187073",
  "text" : "RT @leonidkruglyak: Betteridge's law of headlines: \"Any headline which ends in a question mark can be answered by the word no.\" HT @case ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Casey Bergman",
        "screen_name" : "caseybergman",
        "indices" : [ 111, 124 ],
        "id_str" : "320210499",
        "id" : 320210499
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281908168999706626",
    "text" : "Betteridge's law of headlines: \"Any headline which ends in a question mark can be answered by the word no.\" HT @caseybergman",
    "id" : 281908168999706626,
    "created_at" : "2012-12-20 23:45:19 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 281908401645187073,
  "created_at" : "2012-12-20 23:46:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 7, 14 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281893525208043520",
  "geo" : { },
  "id_str" : "281893818683518976",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @McDawg Enter Sandman made the list iirc, as did some Van Halen. Both should work equally well.",
  "id" : 281893818683518976,
  "in_reply_to_status_id" : 281893525208043520,
  "created_at" : "2012-12-20 22:48:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281890488058011648",
  "geo" : { },
  "id_str" : "281890793344614402",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, probably!",
  "id" : 281890793344614402,
  "in_reply_to_status_id" : 281890488058011648,
  "created_at" : "2012-12-20 22:36:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281888175583019008",
  "geo" : { },
  "id_str" : "281889802847141889",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my psychic skills tell me he will be unemployed soon!",
  "id" : 281889802847141889,
  "in_reply_to_status_id" : 281888175583019008,
  "created_at" : "2012-12-20 22:32:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 3, 11 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/LrO0D9aB",
      "expanded_url" : "http:\/\/youtu.be\/VFtlDhksGHA",
      "display_url" : "youtu.be\/VFtlDhksGHA"
    } ]
  },
  "geo" : { },
  "id_str" : "281884341263532032",
  "text" : "RT @voelker: Can Dungeons &amp; Dragons Make You A Confident &amp; Successful Person? http:\/\/t.co\/LrO0D9aB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/LrO0D9aB",
        "expanded_url" : "http:\/\/youtu.be\/VFtlDhksGHA",
        "display_url" : "youtu.be\/VFtlDhksGHA"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.564275, -0.134289 ]
    },
    "id_str" : "281881212149170176",
    "text" : "Can Dungeons &amp; Dragons Make You A Confident &amp; Successful Person? http:\/\/t.co\/LrO0D9aB",
    "id" : 281881212149170176,
    "created_at" : "2012-12-20 21:58:12 +0000",
    "user" : {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "protected" : false,
      "id_str" : "14783339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595572463381172224\/xb2DDLGV_normal.jpg",
      "id" : 14783339,
      "verified" : false
    }
  },
  "id" : 281884341263532032,
  "created_at" : "2012-12-20 22:10:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00F6rn Huxhorn",
      "screen_name" : "huxi",
      "indices" : [ 0, 5 ],
      "id_str" : "15710349",
      "id" : 15710349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281879166314491905",
  "geo" : { },
  "id_str" : "281879229254234112",
  "in_reply_to_user_id" : 15710349,
  "text" : "@huxi Tanzverbot?",
  "id" : 281879229254234112,
  "in_reply_to_status_id" : 281879166314491905,
  "created_at" : "2012-12-20 21:50:19 +0000",
  "in_reply_to_screen_name" : "huxi",
  "in_reply_to_user_id_str" : "15710349",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281875808732200960",
  "geo" : { },
  "id_str" : "281877818399395840",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg took one for the team ;)",
  "id" : 281877818399395840,
  "in_reply_to_status_id" : 281875808732200960,
  "created_at" : "2012-12-20 21:44:43 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Gr\u24D0h\u24D0m Steel \uD83D\uDD2C\uD83C\uDF93",
      "screen_name" : "McDawg",
      "indices" : [ 0, 7 ],
      "id_str" : "12432262",
      "id" : 12432262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281874753646632961",
  "geo" : { },
  "id_str" : "281874841190158336",
  "in_reply_to_user_id" : 12432262,
  "text" : "@McDawg made it through all 100. Surprise: Stairway is missing!",
  "id" : 281874841190158336,
  "in_reply_to_status_id" : 281874753646632961,
  "created_at" : "2012-12-20 21:32:53 +0000",
  "in_reply_to_screen_name" : "McDawg",
  "in_reply_to_user_id_str" : "12432262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 0, 12 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281871524238094336",
  "geo" : { },
  "id_str" : "281873722095325184",
  "in_reply_to_user_id" : 214099847,
  "text" : "@jonfwilkins That would be great :-)",
  "id" : 281873722095325184,
  "in_reply_to_status_id" : 281871524238094336,
  "created_at" : "2012-12-20 21:28:26 +0000",
  "in_reply_to_screen_name" : "jonfwilkins",
  "in_reply_to_user_id_str" : "214099847",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/gBXbhpPg",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/12\/20\/tabs-for-100-riffs-guitar.html",
      "display_url" : "boingboing.net\/2012\/12\/20\/tab\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281873614352035840",
  "text" : "Tabs for the 100 Song Riff Medley. If you ever wanted to get thrown out of a guitar store: That\u2019s your chance! http:\/\/t.co\/gBXbhpPg",
  "id" : 281873614352035840,
  "created_at" : "2012-12-20 21:28:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281850184483340289",
  "geo" : { },
  "id_str" : "281868066214797312",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Okay, ich hatte den Fall nicht wirklich verfolgt.",
  "id" : 281868066214797312,
  "in_reply_to_status_id" : 281850184483340289,
  "created_at" : "2012-12-20 21:05:58 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 0, 12 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281866890928869377",
  "geo" : { },
  "id_str" : "281867984593629184",
  "in_reply_to_user_id" : 214099847,
  "text" : "@jonfwilkins Thanks for the great post. (I\u2019m a huge fanboy since your primers on imprinting-series!)",
  "id" : 281867984593629184,
  "in_reply_to_status_id" : 281866890928869377,
  "created_at" : "2012-12-20 21:05:39 +0000",
  "in_reply_to_screen_name" : "jonfwilkins",
  "in_reply_to_user_id_str" : "214099847",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/2TsE60T0",
      "expanded_url" : "http:\/\/j.mp\/12CDWvH",
      "display_url" : "j.mp\/12CDWvH"
    } ]
  },
  "geo" : { },
  "id_str" : "281843817634742272",
  "text" : "Diagnosing the Home Alone burglars' injuries: \u00AB Marv and Harry each take a roughly 2 kilo-newton hit to the face\u00BB http:\/\/t.co\/2TsE60T0",
  "id" : 281843817634742272,
  "created_at" : "2012-12-20 19:29:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281838179768733696",
  "geo" : { },
  "id_str" : "281839736765689856",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog dann Dr\u00FCcke ich mal weiter die Daumen das du schnell von der Traufe zur\u00FCck in den Regen darfst. :)",
  "id" : 281839736765689856,
  "in_reply_to_status_id" : 281838179768733696,
  "created_at" : "2012-12-20 19:13:24 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281836813667155968",
  "geo" : { },
  "id_str" : "281837419496607744",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog wenn es schlimmer als die Kollegen ist dann will es schon was heissen! :)",
  "id" : 281837419496607744,
  "in_reply_to_status_id" : 281836813667155968,
  "created_at" : "2012-12-20 19:04:11 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/3E3eVXSr",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=JXnt9iGEdIM",
      "display_url" : "youtube.com\/watch?v=JXnt9i\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "281835558056108032",
  "geo" : { },
  "id_str" : "281836504584699904",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog du bekommst also bald Die Kollegen ins Bett nebenan geliefert? ;) http:\/\/t.co\/3E3eVXSr",
  "id" : 281836504584699904,
  "in_reply_to_status_id" : 281835558056108032,
  "created_at" : "2012-12-20 19:00:33 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281830186603929600",
  "geo" : { },
  "id_str" : "281830691627495424",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot w\u00E4hrend er sich Dirty Proto-Talk angeh\u00F6rt hat!",
  "id" : 281830691627495424,
  "in_reply_to_status_id" : 281830186603929600,
  "created_at" : "2012-12-20 18:37:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/M9RTXBuj",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Homo_ergaster#Linguistic_use",
      "display_url" : "en.wikipedia.org\/wiki\/Homo_erga\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "281828475990573056",
  "geo" : { },
  "id_str" : "281828847580753921",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Wer wei\u00DF wof\u00FCr sie das benutzt haben? http:\/\/t.co\/M9RTXBuj",
  "id" : 281828847580753921,
  "in_reply_to_status_id" : 281828475990573056,
  "created_at" : "2012-12-20 18:30:08 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281826763808579584",
  "text" : "To put 1.2 million years of watched porn since 2006 into perspective: About 1.2 million years ago Homo eregaster went extinct\u2026",
  "id" : 281826763808579584,
  "created_at" : "2012-12-20 18:21:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "indices" : [ 3, 8 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/QqVTGpKY",
      "expanded_url" : "http:\/\/betabeat.com\/2012\/12\/we-did-it-everyone-weve-watched-1-2-million-years-of-internet-porn-since-2006\/",
      "display_url" : "betabeat.com\/2012\/12\/we-did\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281824819606089728",
  "text" : "RT @mims: We Did It, Everyone! We\u2019ve Watched 1.2 Million Years of Internet Porn Since 2006 http:\/\/t.co\/QqVTGpKY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/QqVTGpKY",
        "expanded_url" : "http:\/\/betabeat.com\/2012\/12\/we-did-it-everyone-weve-watched-1-2-million-years-of-internet-porn-since-2006\/",
        "display_url" : "betabeat.com\/2012\/12\/we-did\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281824531490951169",
    "text" : "We Did It, Everyone! We\u2019ve Watched 1.2 Million Years of Internet Porn Since 2006 http:\/\/t.co\/QqVTGpKY",
    "id" : 281824531490951169,
    "created_at" : "2012-12-20 18:12:59 +0000",
    "user" : {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "protected" : false,
      "id_str" : "1769191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805781204381351936\/_P3k7Gmn_normal.jpg",
      "id" : 1769191,
      "verified" : true
    }
  },
  "id" : 281824819606089728,
  "created_at" : "2012-12-20 18:14:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281824151361175552",
  "geo" : { },
  "id_str" : "281824440558424064",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me schade. :(",
  "id" : 281824440558424064,
  "in_reply_to_status_id" : 281824151361175552,
  "created_at" : "2012-12-20 18:12:37 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281824395742306304",
  "text" : "\u00ABMir ist gar nicht alles egal. Wenn ich Dinge kleinschneiden darf bin ich sehr zufrieden.\u00BB",
  "id" : 281824395742306304,
  "created_at" : "2012-12-20 18:12:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281823047881736194",
  "geo" : { },
  "id_str" : "281823436244910080",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me Link zum Ergebnis?",
  "id" : 281823436244910080,
  "in_reply_to_status_id" : 281823047881736194,
  "created_at" : "2012-12-20 18:08:37 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Polischuk",
      "screen_name" : "ppolischuk",
      "indices" : [ 3, 14 ],
      "id_str" : "18722932",
      "id" : 18722932
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 16, 32 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281821397632839680",
  "text" : "RT @ppolischuk: @gedankenstuecke Stay tuned! We have big plans for figures and data. This initial redesign is just the beginning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "281809349763026944",
    "geo" : { },
    "id_str" : "281821214408863744",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Stay tuned! We have big plans for figures and data. This initial redesign is just the beginning.",
    "id" : 281821214408863744,
    "in_reply_to_status_id" : 281809349763026944,
    "created_at" : "2012-12-20 17:59:48 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Patrick Polischuk",
      "screen_name" : "ppolischuk",
      "protected" : false,
      "id_str" : "18722932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1462122581\/photo__1__normal.JPG",
      "id" : 18722932,
      "verified" : false
    }
  },
  "id" : 281821397632839680,
  "created_at" : "2012-12-20 18:00:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Polischuk",
      "screen_name" : "ppolischuk",
      "indices" : [ 0, 11 ],
      "id_str" : "18722932",
      "id" : 18722932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281821214408863744",
  "geo" : { },
  "id_str" : "281821388724117504",
  "in_reply_to_user_id" : 18722932,
  "text" : "@ppolischuk nice! Can\u2019t wait to see those :)",
  "id" : 281821388724117504,
  "in_reply_to_status_id" : 281821214408863744,
  "created_at" : "2012-12-20 18:00:29 +0000",
  "in_reply_to_screen_name" : "ppolischuk",
  "in_reply_to_user_id_str" : "18722932",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 15, 20 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/MTBOqcxS",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0052203",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281809349763026944",
  "text" : "I wish the new @PLOS article layout would include a zoom function for the figure detail view. http:\/\/t.co\/MTBOqcxS",
  "id" : 281809349763026944,
  "created_at" : "2012-12-20 17:12:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281806907159748609",
  "text" : "Hypermedia APIs\u2026 Well, I guess Star Trek taught us that this is how you get your Big Data to high velocity\u2026",
  "id" : 281806907159748609,
  "created_at" : "2012-12-20 17:02:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/hlQIG1Mc",
      "expanded_url" : "http:\/\/j.mp\/T9XTFZ",
      "display_url" : "j.mp\/T9XTFZ"
    } ]
  },
  "geo" : { },
  "id_str" : "281789457018007552",
  "text" : "\u00ABBe like Santa and make sure your data is findable and re-useable: use good metadata!\u00BB http:\/\/t.co\/hlQIG1Mc",
  "id" : 281789457018007552,
  "created_at" : "2012-12-20 15:53:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281757906381193216",
  "geo" : { },
  "id_str" : "281759079607705600",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro thanks, I\u2019m quite positive about it (at least for now ;))",
  "id" : 281759079607705600,
  "in_reply_to_status_id" : 281757906381193216,
  "created_at" : "2012-12-20 13:52:54 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281755461647233024",
  "geo" : { },
  "id_str" : "281756898234097664",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro but you succeeded! :)",
  "id" : 281756898234097664,
  "in_reply_to_status_id" : 281755461647233024,
  "created_at" : "2012-12-20 13:44:13 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 0, 9 ],
      "id_str" : "22828618",
      "id" : 22828618
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 10, 19 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281755891802456066",
  "geo" : { },
  "id_str" : "281756406447759362",
  "in_reply_to_user_id" : 22828618,
  "text" : "@Argent23 @Roterhai Direkt nichts, aber ich arbeite neben dem Studium bei Karsten in der AG.",
  "id" : 281756406447759362,
  "in_reply_to_status_id" : 281755891802456066,
  "created_at" : "2012-12-20 13:42:16 +0000",
  "in_reply_to_screen_name" : "Argent23",
  "in_reply_to_user_id_str" : "22828618",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/GlJGqJRe",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1212.4788",
      "display_url" : "arxiv.org\/abs\/1212.4788"
    } ]
  },
  "geo" : { },
  "id_str" : "281756131729235968",
  "text" : "What I\u2019ve been also working on during the last months: A web-tool for GWAS in non-human model organisms. http:\/\/t.co\/GlJGqJRe",
  "id" : 281756131729235968,
  "created_at" : "2012-12-20 13:41:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281752489450151936",
  "geo" : { },
  "id_str" : "281755030061719554",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro the last 3 month will start in Jan for me. I guess it will be similar, though I only work part-time (well, &amp; have to run openSNP)",
  "id" : 281755030061719554,
  "in_reply_to_status_id" : 281752489450151936,
  "created_at" : "2012-12-20 13:36:48 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281754001056354305",
  "geo" : { },
  "id_str" : "281754763421442048",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai Du hast es nur 5 Minuten sp\u00E4ter gefunden als ich davon erfahren habe :D",
  "id" : 281754763421442048,
  "in_reply_to_status_id" : 281754001056354305,
  "created_at" : "2012-12-20 13:35:45 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281748212371578880",
  "geo" : { },
  "id_str" : "281748641310466048",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro Right now I\u2019m focussing on working on my thesis as it has a fixed deadline. A completely different topic but fun as well!",
  "id" : 281748641310466048,
  "in_reply_to_status_id" : 281748212371578880,
  "created_at" : "2012-12-20 13:11:25 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281745435717152770",
  "geo" : { },
  "id_str" : "281745967462621184",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro You\u2019re so sweet! Hope you\u2019re right! ;-) How are things going for you?",
  "id" : 281745967462621184,
  "in_reply_to_status_id" : 281745435717152770,
  "created_at" : "2012-12-20 13:00:47 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 118, 123 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/AkBJKmd1",
      "expanded_url" : "http:\/\/j.mp\/TC7fKw",
      "display_url" : "j.mp\/TC7fKw"
    } ]
  },
  "geo" : { },
  "id_str" : "281743580643602432",
  "text" : "Ermittler d\u00FCrfen bei Reihen-Gentests nicht R\u00FCckschl\u00FCsse auf Verwandte der Getesteten ziehen. http:\/\/t.co\/AkBJKmd1 \/cc @li5a",
  "id" : 281743580643602432,
  "created_at" : "2012-12-20 12:51:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 6, 18 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/i8s34RA4",
      "expanded_url" : "http:\/\/jonfwilkins.blogspot.de\/2012\/12\/epigenetics-and-homosexuality.html",
      "display_url" : "jonfwilkins.blogspot.de\/2012\/12\/epigen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281742779850309632",
  "text" : "Nice, @jonfwilkins gives you a real idea what the Epigenetics and Homosexuality fuss is all about http:\/\/t.co\/i8s34RA4",
  "id" : 281742779850309632,
  "created_at" : "2012-12-20 12:48:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/biLB79Zk",
      "expanded_url" : "http:\/\/calnewport.com\/blog\/2012\/11\/21\/knowledge-workers-are-bad-at-working-and-heres-what-to-do-about-it\/",
      "display_url" : "calnewport.com\/blog\/2012\/11\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281737361442889728",
  "text" : "\u00ABIf you\u2019re a veteran knowledge worker, you\u2019ll spend most of your day answering e-mail.\u00BB http:\/\/t.co\/biLB79Zk",
  "id" : 281737361442889728,
  "created_at" : "2012-12-20 12:26:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "talented hack",
      "screen_name" : "jrecursive",
      "indices" : [ 3, 14 ],
      "id_str" : "13002342",
      "id" : 13002342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281727545416769536",
  "text" : "RT @jrecursive: today's complexity, O(shit!), brought to you by the traveling failsman",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281395841787371521",
    "text" : "today's complexity, O(shit!), brought to you by the traveling failsman",
    "id" : 281395841787371521,
    "created_at" : "2012-12-19 13:49:31 +0000",
    "user" : {
      "name" : "talented hack",
      "screen_name" : "jrecursive",
      "protected" : false,
      "id_str" : "13002342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458990518160998401\/Tgo-kZwI_normal.png",
      "id" : 13002342,
      "verified" : false
    }
  },
  "id" : 281727545416769536,
  "created_at" : "2012-12-20 11:47:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281699340957925377",
  "text" : "\u00ABDon\u2019t worry. If I just slap you fast enough it won\u2019t hurt at all. Trust me, I\u2019m a biologist.\u00BB",
  "id" : 281699340957925377,
  "created_at" : "2012-12-20 09:55:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281699193020620801",
  "text" : "My answer to years of people going \u00ABYou\u2019re a biologist. What exotic plant that?\u00BB: Adding \u00ABTrust me, I\u2019m a biologist\u00BB to made up nonsense.",
  "id" : 281699193020620801,
  "created_at" : "2012-12-20 09:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281626978082238464",
  "text" : "\u00ABDie Katze hat mich angekotzt.\u00BB \u2014 \u00ABDas ist ein Zeichen ihrer Liebe. Entweder das oder sie will dich vorverdauen.\u00BB",
  "id" : 281626978082238464,
  "created_at" : "2012-12-20 05:07:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bartel",
      "screen_name" : "avatar",
      "indices" : [ 3, 10 ],
      "id_str" : "1144181",
      "id" : 1144181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/vFJ5vO0d",
      "expanded_url" : "http:\/\/drfarrington.tumblr.com\/post\/38042632494\/ahahahah#notes",
      "display_url" : "drfarrington.tumblr.com\/post\/380426324\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281539913298624512",
  "text" : "RT @avatar: Cat torus - yeah! http:\/\/t.co\/vFJ5vO0d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http:\/\/t.co\/vFJ5vO0d",
        "expanded_url" : "http:\/\/drfarrington.tumblr.com\/post\/38042632494\/ahahahah#notes",
        "display_url" : "drfarrington.tumblr.com\/post\/380426324\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "281539404701499393",
    "text" : "Cat torus - yeah! http:\/\/t.co\/vFJ5vO0d",
    "id" : 281539404701499393,
    "created_at" : "2012-12-19 23:19:59 +0000",
    "user" : {
      "name" : "Tim Bartel",
      "screen_name" : "avatar",
      "protected" : false,
      "id_str" : "1144181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3349205030\/b27e7c954e84ca3ef1e433bbe9acff97_normal.jpeg",
      "id" : 1144181,
      "verified" : false
    }
  },
  "id" : 281539913298624512,
  "created_at" : "2012-12-19 23:22:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281532244290572289",
  "geo" : { },
  "id_str" : "281532386414571521",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj s\/frostschutzmittel\/guterschnaps\/g bitte :P",
  "id" : 281532386414571521,
  "in_reply_to_status_id" : 281532244290572289,
  "created_at" : "2012-12-19 22:52:06 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281530998112538625",
  "geo" : { },
  "id_str" : "281532097787736065",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Ich hab ja nichts gegen stillos trinken, aber irgendwo ist auch schluss.",
  "id" : 281532097787736065,
  "in_reply_to_status_id" : 281530998112538625,
  "created_at" : "2012-12-19 22:50:57 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281530319872606209",
  "geo" : { },
  "id_str" : "281530863068540928",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj willst du mich gerade \u00FCberzeugen an dem Datum doch nicht zuhause zu sein? :P",
  "id" : 281530863068540928,
  "in_reply_to_status_id" : 281530319872606209,
  "created_at" : "2012-12-19 22:46:03 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281529753847091201",
  "geo" : { },
  "id_str" : "281529832641290240",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Das mache ich seit Jahren nicht mehr :D",
  "id" : 281529832641290240,
  "in_reply_to_status_id" : 281529753847091201,
  "created_at" : "2012-12-19 22:41:57 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281529304666480640",
  "geo" : { },
  "id_str" : "281529583252152322",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Vermutlich schon.",
  "id" : 281529583252152322,
  "in_reply_to_status_id" : 281529304666480640,
  "created_at" : "2012-12-19 22:40:57 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281529030094753793",
  "geo" : { },
  "id_str" : "281529123971661825",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj treffer &amp; versenkt",
  "id" : 281529123971661825,
  "in_reply_to_status_id" : 281529030094753793,
  "created_at" : "2012-12-19 22:39:08 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 8, 16 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281528394984865792",
  "geo" : { },
  "id_str" : "281528549859540992",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @pulegon so auf den Tag genau? Oder im gr\u00F6\u00DFeren Kontext?",
  "id" : 281528549859540992,
  "in_reply_to_status_id" : 281528394984865792,
  "created_at" : "2012-12-19 22:36:51 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281525532179443712",
  "geo" : { },
  "id_str" : "281525934635507712",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor ich bevorzuge einfach Freunde die auch \u00FCber sich selbst lachen k\u00F6nnen ;)",
  "id" : 281525934635507712,
  "in_reply_to_status_id" : 281525532179443712,
  "created_at" : "2012-12-19 22:26:27 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purrrlegon",
      "screen_name" : "pulegon",
      "indices" : [ 45, 53 ],
      "id_str" : "107502279",
      "id" : 107502279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281525135289241603",
  "text" : "Erfolgreiches Lebensmotto seit 27 Jahren: RT @pulegon: lieber einen freund verlieren, als ne gute pointe verpassen, was?",
  "id" : 281525135289241603,
  "created_at" : "2012-12-19 22:23:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/j6uscEUn",
      "expanded_url" : "http:\/\/j.mp\/ZQg8Wf",
      "display_url" : "j.mp\/ZQg8Wf"
    } ]
  },
  "geo" : { },
  "id_str" : "281503575199326208",
  "text" : "Spanish scientists take to the streets http:\/\/t.co\/j6uscEUn",
  "id" : 281503575199326208,
  "created_at" : "2012-12-19 20:57:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/vejEVMln",
      "expanded_url" : "http:\/\/j.mp\/ZdCNww",
      "display_url" : "j.mp\/ZdCNww"
    } ]
  },
  "geo" : { },
  "id_str" : "281503219799179264",
  "text" : "Conlangers: Utopian for Beginners http:\/\/t.co\/vejEVMln",
  "id" : 281503219799179264,
  "created_at" : "2012-12-19 20:56:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 34, 47 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281491647227895808",
  "text" : "Slightly scared by how productive @iameltonjohn is becoming lately.",
  "id" : 281491647227895808,
  "created_at" : "2012-12-19 20:10:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/R9hWAz6s",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ESnMbcIvgvU",
      "display_url" : "youtube.com\/watch?v=ESnMbc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281490372524396545",
  "text" : "Darrell Scott is awesome. I can\u2019t believe I hadn\u2019t heard of him before this day! http:\/\/t.co\/R9hWAz6s",
  "id" : 281490372524396545,
  "created_at" : "2012-12-19 20:05:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/IwkMDtvE",
      "expanded_url" : "http:\/\/j.mp\/WsiqKw",
      "display_url" : "j.mp\/WsiqKw"
    } ]
  },
  "geo" : { },
  "id_str" : "281468450008879104",
  "text" : "Lottery Winner Jack Whittaker's Losing Ticket http:\/\/t.co\/IwkMDtvE",
  "id" : 281468450008879104,
  "created_at" : "2012-12-19 18:38:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "schlappohr",
      "indices" : [ 24, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281434417174552576",
  "geo" : { },
  "id_str" : "281435129514188800",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ich mag Lassie ja. #schlappohr",
  "id" : 281435129514188800,
  "in_reply_to_status_id" : 281434417174552576,
  "created_at" : "2012-12-19 16:25:38 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281432557541797889",
  "geo" : { },
  "id_str" : "281433699382329344",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ich f\u00FChle mich der Schweiz halt sehr verbunden. Denen ist auch so vieles angenehm egal. ;)",
  "id" : 281433699382329344,
  "in_reply_to_status_id" : 281432557541797889,
  "created_at" : "2012-12-19 16:19:57 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/nYAJdlrP",
      "expanded_url" : "http:\/\/de.wikipedia.org\/wiki\/Anf%C3%BChrungszeichen#Schweiz.2C_Liechtenstein.2C_Frankreich",
      "display_url" : "de.wikipedia.org\/wiki\/Anf%C3%BC\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "281431584668782593",
  "geo" : { },
  "id_str" : "281432192855470081",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy (\u00DCber die Guillemets hatten wir aber garantiert schon mal gestritten http:\/\/t.co\/nYAJdlrP)",
  "id" : 281432192855470081,
  "in_reply_to_status_id" : 281431584668782593,
  "created_at" : "2012-12-19 16:13:58 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281431584668782593",
  "geo" : { },
  "id_str" : "281431779049607170",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy moment, habe ich dir auch versprochen keine Gliedma\u00DFen zu entfernen?",
  "id" : 281431779049607170,
  "in_reply_to_status_id" : 281431584668782593,
  "created_at" : "2012-12-19 16:12:19 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281431298369806336",
  "text" : "\u00ABDas du noch mal extra sagst das du mir keine Gliedma\u00DFen abschneiden willst sollte mir zu denken geben, oder?\u00BB",
  "id" : 281431298369806336,
  "created_at" : "2012-12-19 16:10:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lsr",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/hecjVoRH",
      "expanded_url" : "http:\/\/j.mp\/T7cAK8",
      "display_url" : "j.mp\/T7cAK8"
    } ]
  },
  "geo" : { },
  "id_str" : "281414399858728960",
  "text" : "The humanitarian impact of European laws targeting Google News #lsr http:\/\/t.co\/hecjVoRH",
  "id" : 281414399858728960,
  "created_at" : "2012-12-19 15:03:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/ZsqY7sIz",
      "expanded_url" : "http:\/\/j.mp\/RDabK4",
      "display_url" : "j.mp\/RDabK4"
    } ]
  },
  "geo" : { },
  "id_str" : "281410745374228480",
  "text" : "Post-Newtown, Sales Boom for Kids' Body Armor http:\/\/t.co\/ZsqY7sIz",
  "id" : 281410745374228480,
  "created_at" : "2012-12-19 14:48:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281409572101566464",
  "text" : "\u00ABDu bist wirklich sehr nasenputzig.\u00BB",
  "id" : 281409572101566464,
  "created_at" : "2012-12-19 14:44:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281404126179512320",
  "text" : "\u00ABThe important thing is that, in the end, you made the right choice.\u00BB \u2013 \u00ABSounds like the wrap-up to a Scooby-Doo movie.\u00BB",
  "id" : 281404126179512320,
  "created_at" : "2012-12-19 14:22:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/HE5AV1ms",
      "expanded_url" : "http:\/\/j.mp\/WqHGkj",
      "display_url" : "j.mp\/WqHGkj"
    } ]
  },
  "geo" : { },
  "id_str" : "281363927231778816",
  "text" : "The value of re-analysis http:\/\/t.co\/HE5AV1ms",
  "id" : 281363927231778816,
  "created_at" : "2012-12-19 11:42:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/0dH3QGOl",
      "expanded_url" : "http:\/\/j.mp\/WqH66f",
      "display_url" : "j.mp\/WqH66f"
    } ]
  },
  "geo" : { },
  "id_str" : "281363293921218560",
  "text" : "\u00ABThe main appeal of the crab is its dignified air of feistiness\u00BB \u2014 Giant Robber Crabs Monitored from Space http:\/\/t.co\/0dH3QGOl",
  "id" : 281363293921218560,
  "created_at" : "2012-12-19 11:40:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/z3VTp1b4",
      "expanded_url" : "http:\/\/j.mp\/WqFxF8",
      "display_url" : "j.mp\/WqFxF8"
    } ]
  },
  "geo" : { },
  "id_str" : "281362203481874433",
  "text" : "The Tribbles analogy is quite good: The Trouble with FASTQ http:\/\/t.co\/z3VTp1b4",
  "id" : 281362203481874433,
  "created_at" : "2012-12-19 11:35:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/5ug5U2EE",
      "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2012\/12\/18\/worm-eating-fungi-eavesdrop-on-the-chemicals-of-their-prey\/",
      "display_url" : "phenomena.nationalgeographic.com\/2012\/12\/18\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281358863872167936",
  "text" : "Eavesdropping fungal predators http:\/\/t.co\/5ug5U2EE",
  "id" : 281358863872167936,
  "created_at" : "2012-12-19 11:22:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281306114409242624",
  "text" : "Neuroplasticity. Bringing us \u201Cdoing X changes the brain!!\u201D headlines since the invention of sloppy science journalism\u2026",
  "id" : 281306114409242624,
  "created_at" : "2012-12-19 07:52:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "genegeek",
      "screen_name" : "genegeek",
      "indices" : [ 3, 12 ],
      "id_str" : "16678835",
      "id" : 16678835
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 48, 58 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Vaughan Bell",
      "screen_name" : "vaughanbell",
      "indices" : [ 63, 75 ],
      "id_str" : "20542737",
      "id" : 20542737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/dhQHIy79",
      "expanded_url" : "http:\/\/is.gd\/F0Fmjp",
      "display_url" : "is.gd\/F0Fmjp"
    } ]
  },
  "geo" : { },
  "id_str" : "281190248938106880",
  "text" : "RT @genegeek: Reminds me of 'general public' MT @edyong209: RT @vaughanbell: Crowds Are Not People, My Friend http:\/\/t.co\/dhQHIy79 Excel ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Yong",
        "screen_name" : "edyong209",
        "indices" : [ 34, 44 ],
        "id_str" : "19767193",
        "id" : 19767193
      }, {
        "name" : "Vaughan Bell",
        "screen_name" : "vaughanbell",
        "indices" : [ 49, 61 ],
        "id_str" : "20542737",
        "id" : 20542737
      }, {
        "name" : "Maggie Koerth-Baker",
        "screen_name" : "maggiekb1",
        "indices" : [ 130, 140 ],
        "id_str" : "26858764",
        "id" : 26858764
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/dhQHIy79",
        "expanded_url" : "http:\/\/is.gd\/F0Fmjp",
        "display_url" : "is.gd\/F0Fmjp"
      } ]
    },
    "geo" : { },
    "id_str" : "281189735299436544",
    "text" : "Reminds me of 'general public' MT @edyong209: RT @vaughanbell: Crowds Are Not People, My Friend http:\/\/t.co\/dhQHIy79 Excellent by @maggiekb1",
    "id" : 281189735299436544,
    "created_at" : "2012-12-19 00:10:31 +0000",
    "user" : {
      "name" : "genegeek",
      "screen_name" : "genegeek",
      "protected" : false,
      "id_str" : "16678835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532597977303355392\/RbyFFNod_normal.jpeg",
      "id" : 16678835,
      "verified" : false
    }
  },
  "id" : 281190248938106880,
  "created_at" : "2012-12-19 00:12:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xeni Jardin \uD83E\uDD2F",
      "screen_name" : "xeni",
      "indices" : [ 3, 8 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281152324934696960",
  "text" : "RT @xeni: Instagram is selling your nail art &amp; food porn pix to buy meth for Taliban abortion clinics on Mars &amp; there\u2019s fuck-all ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281146775111344128",
    "text" : "Instagram is selling your nail art &amp; food porn pix to buy meth for Taliban abortion clinics on Mars &amp; there\u2019s fuck-all you can do about it.",
    "id" : 281146775111344128,
    "created_at" : "2012-12-18 21:19:49 +0000",
    "user" : {
      "name" : "Xeni Jardin \uD83E\uDD2F",
      "screen_name" : "xeni",
      "protected" : false,
      "id_str" : "767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879456546119311360\/sigIHyFi_normal.jpg",
      "id" : 767,
      "verified" : true
    }
  },
  "id" : 281152324934696960,
  "created_at" : "2012-12-18 21:41:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281138509593579520",
  "text" : "\u00ABI\u2019d be honored to saw through your chest and remove your good-natured heart from its cavity.\u00BB &lt;3",
  "id" : 281138509593579520,
  "created_at" : "2012-12-18 20:46:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281136309551132672",
  "text" : "\u00ABWhoever said work was supposed to be fun?\u00BB \u2013 \u00ABRon Jeremy for starters.\u00BB",
  "id" : 281136309551132672,
  "created_at" : "2012-12-18 20:38:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Niles",
      "screen_name" : "robertniles",
      "indices" : [ 3, 15 ],
      "id_str" : "10546372",
      "id" : 10546372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281106480923570178",
  "text" : "RT @robertniles: I've revised and expanded my online statistics tutorial for math-phobic journalists. I hope you'll take a look:  http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/ROUd9Djb",
        "expanded_url" : "http:\/\/www.robertniles.com\/stats\/",
        "display_url" : "robertniles.com\/stats\/"
      } ]
    },
    "geo" : { },
    "id_str" : "281105664019922944",
    "text" : "I've revised and expanded my online statistics tutorial for math-phobic journalists. I hope you'll take a look:  http:\/\/t.co\/ROUd9Djb",
    "id" : 281105664019922944,
    "created_at" : "2012-12-18 18:36:27 +0000",
    "user" : {
      "name" : "Robert Niles",
      "screen_name" : "robertniles",
      "protected" : false,
      "id_str" : "10546372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/903287166729576448\/ND7sf7j5_normal.jpg",
      "id" : 10546372,
      "verified" : true
    }
  },
  "id" : 281106480923570178,
  "created_at" : "2012-12-18 18:39:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason H. Moore, PhD",
      "screen_name" : "moorejh",
      "indices" : [ 3, 11 ],
      "id_str" : "15496407",
      "id" : 15496407
    }, {
      "name" : "FabulousAniyyah",
      "screen_name" : "hnycombinator",
      "indices" : [ 55, 69 ],
      "id_str" : "2560186998",
      "id" : 2560186998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "machinelearning",
      "indices" : [ 13, 29 ]
    }, {
      "text" : "datascience",
      "indices" : [ 30, 42 ]
    }, {
      "text" : "bigdata",
      "indices" : [ 43, 51 ]
    }, {
      "text" : "datamining",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/V0C59akz",
      "expanded_url" : "http:\/\/goo.gl\/fb\/MkhbO",
      "display_url" : "goo.gl\/fb\/MkhbO"
    } ]
  },
  "geo" : { },
  "id_str" : "281083913835794432",
  "text" : "RT @moorejh: #machinelearning #datascience #bigdata RT @hnycombinator Top ten algorithms in #datamining [pdf] http:\/\/t.co\/V0C59akz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FabulousAniyyah",
        "screen_name" : "hnycombinator",
        "indices" : [ 42, 56 ],
        "id_str" : "2560186998",
        "id" : 2560186998
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "machinelearning",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "datascience",
        "indices" : [ 17, 29 ]
      }, {
        "text" : "bigdata",
        "indices" : [ 30, 38 ]
      }, {
        "text" : "datamining",
        "indices" : [ 79, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/V0C59akz",
        "expanded_url" : "http:\/\/goo.gl\/fb\/MkhbO",
        "display_url" : "goo.gl\/fb\/MkhbO"
      } ]
    },
    "geo" : { },
    "id_str" : "281083462763556865",
    "text" : "#machinelearning #datascience #bigdata RT @hnycombinator Top ten algorithms in #datamining [pdf] http:\/\/t.co\/V0C59akz",
    "id" : 281083462763556865,
    "created_at" : "2012-12-18 17:08:14 +0000",
    "user" : {
      "name" : "Jason H. Moore, PhD",
      "screen_name" : "moorejh",
      "protected" : false,
      "id_str" : "15496407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550024402142625793\/5aw9u9E8_normal.jpeg",
      "id" : 15496407,
      "verified" : false
    }
  },
  "id" : 281083913835794432,
  "created_at" : "2012-12-18 17:10:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281055374763757568",
  "geo" : { },
  "id_str" : "281056652709470208",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai @Senficon im B\u00FCcherregal steht ja auch \u201EDie Krebsl\u00FCge\u201C ;)",
  "id" : 281056652709470208,
  "in_reply_to_status_id" : 281055374763757568,
  "created_at" : "2012-12-18 15:21:42 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "indices" : [ 3, 11 ],
      "id_str" : "19202541",
      "id" : 19202541
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 95, 105 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/PL3YKm0H",
      "expanded_url" : "http:\/\/on.natgeo.com\/RBQ5jv",
      "display_url" : "on.natgeo.com\/RBQ5jv"
    } ]
  },
  "geo" : { },
  "id_str" : "281055683158360064",
  "text" : "RT @kzelnio: The Fungus Behind the Frog Apocalypse Hides in Crayfish http:\/\/t.co\/PL3YKm0H  via @edyong209",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Yong",
        "screen_name" : "edyong209",
        "indices" : [ 82, 92 ],
        "id_str" : "19767193",
        "id" : 19767193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/PL3YKm0H",
        "expanded_url" : "http:\/\/on.natgeo.com\/RBQ5jv",
        "display_url" : "on.natgeo.com\/RBQ5jv"
      } ]
    },
    "geo" : { },
    "id_str" : "281055190491217921",
    "text" : "The Fungus Behind the Frog Apocalypse Hides in Crayfish http:\/\/t.co\/PL3YKm0H  via @edyong209",
    "id" : 281055190491217921,
    "created_at" : "2012-12-18 15:15:53 +0000",
    "user" : {
      "name" : "Kevin Zelnio",
      "screen_name" : "kzelnio",
      "protected" : false,
      "id_str" : "19202541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/847483816457285632\/b1frtSEL_normal.jpg",
      "id" : 19202541,
      "verified" : false
    }
  },
  "id" : 281055683158360064,
  "created_at" : "2012-12-18 15:17:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281053985576730624",
  "geo" : { },
  "id_str" : "281054293543505920",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai nicht nur du\u2026",
  "id" : 281054293543505920,
  "in_reply_to_status_id" : 281053985576730624,
  "created_at" : "2012-12-18 15:12:19 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281053457002143744",
  "text" : "\u00ABGepulste Magnetfeldtherapie\u00BB-Werbung im Wartezimmer des Tierarztes\u2026",
  "id" : 281053457002143744,
  "created_at" : "2012-12-18 15:09:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/yITH0S85",
      "expanded_url" : "http:\/\/teefury.com\/",
      "display_url" : "teefury.com"
    } ]
  },
  "in_reply_to_status_id_str" : "281046255059214337",
  "geo" : { },
  "id_str" : "281047810332307457",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das heute Teefury ist noch besser: http:\/\/t.co\/yITH0S85",
  "id" : 281047810332307457,
  "in_reply_to_status_id" : 281046255059214337,
  "created_at" : "2012-12-18 14:46:34 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281036771926634497",
  "text" : "\u00ABKeine Sorge, wenn es in Academia nicht klappt kannst du immer noch Zwerg werden.\u00BB",
  "id" : 281036771926634497,
  "created_at" : "2012-12-18 14:02:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    }, {
      "name" : "alios",
      "screen_name" : "alios",
      "indices" : [ 9, 15 ],
      "id_str" : "16309072",
      "id" : 16309072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281034642042269696",
  "geo" : { },
  "id_str" : "281035823305080833",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker @alios das stimmt. :)",
  "id" : 281035823305080833,
  "in_reply_to_status_id" : 281034642042269696,
  "created_at" : "2012-12-18 13:58:56 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    }, {
      "name" : "alios",
      "screen_name" : "alios",
      "indices" : [ 77, 83 ],
      "id_str" : "16309072",
      "id" : 16309072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281033898044043265",
  "geo" : { },
  "id_str" : "281034096761774081",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker das Video was ich verlink hab ist imho \u00E4lter als Occupy. Ich glaube @alios hatte mir das 2009 schon mal vorgespielt. :)",
  "id" : 281034096761774081,
  "in_reply_to_status_id" : 281033898044043265,
  "created_at" : "2012-12-18 13:52:04 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/xzB3gWEd",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=qAQrsA3m8Bg",
      "display_url" : "youtube.com\/watch?v=qAQrsA\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "281032814873419778",
  "geo" : { },
  "id_str" : "281033159750074369",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker sorry, scheint am iPad und der Mobile-page zu liegen. Geht http:\/\/t.co\/xzB3gWEd ?",
  "id" : 281033159750074369,
  "in_reply_to_status_id" : 281032814873419778,
  "created_at" : "2012-12-18 13:48:21 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 3, 11 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/FodR3CkW",
      "expanded_url" : "http:\/\/youtu.be\/HUV7Fs8KJLc",
      "display_url" : "youtu.be\/HUV7Fs8KJLc"
    } ]
  },
  "geo" : { },
  "id_str" : "281032690189344768",
  "text" : "RT @voelker: Entertaining live rant in front of Kings Cross' McDonalds: http:\/\/t.co\/FodR3CkW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/FodR3CkW",
        "expanded_url" : "http:\/\/youtu.be\/HUV7Fs8KJLc",
        "display_url" : "youtu.be\/HUV7Fs8KJLc"
      } ]
    },
    "geo" : { },
    "id_str" : "281031811201630211",
    "text" : "Entertaining live rant in front of Kings Cross' McDonalds: http:\/\/t.co\/FodR3CkW",
    "id" : 281031811201630211,
    "created_at" : "2012-12-18 13:42:59 +0000",
    "user" : {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "protected" : false,
      "id_str" : "14783339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595572463381172224\/xb2DDLGV_normal.jpg",
      "id" : 14783339,
      "verified" : false
    }
  },
  "id" : 281032690189344768,
  "created_at" : "2012-12-18 13:46:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/3GQrizaV",
      "expanded_url" : "http:\/\/m.youtube.com\/#\/watch?feature=youtu.be&v=HUV7Fs8KJLc&desktop_uri=%2Fwatch%3Fv%3DHUV7Fs8KJLc%26feature%3Dyoutu.be",
      "display_url" : "m.youtube.com\/#\/watch?featur\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "281031811201630211",
  "geo" : { },
  "id_str" : "281032394469949440",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker any chance that this was the same guy? http:\/\/t.co\/3GQrizaV",
  "id" : 281032394469949440,
  "in_reply_to_status_id" : 281031811201630211,
  "created_at" : "2012-12-18 13:45:18 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Balu Walter",
      "screen_name" : "balu",
      "indices" : [ 0, 5 ],
      "id_str" : "10078652",
      "id" : 10078652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281026674504634369",
  "geo" : { },
  "id_str" : "281026945561538560",
  "in_reply_to_user_id" : 10078652,
  "text" : "@balu but I already get broken strings and can\u2019t work until the problem is fixed. So i can call it a day! :)",
  "id" : 281026945561538560,
  "in_reply_to_status_id" : 281026674504634369,
  "created_at" : "2012-12-18 13:23:39 +0000",
  "in_reply_to_screen_name" : "balu",
  "in_reply_to_user_id_str" : "10078652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281026532653297665",
  "text" : "Progress of my master of string manipulation studies: Yeah, the bug isn\u2019t on my end!",
  "id" : 281026532653297665,
  "created_at" : "2012-12-18 13:22:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HB35sLZF",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=469",
      "display_url" : "asofterworld.com\/index.php?id=4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280994522882789376",
  "text" : "A sweet day http:\/\/t.co\/HB35sLZF",
  "id" : 280994522882789376,
  "created_at" : "2012-12-18 11:14:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280486881211346944",
  "geo" : { },
  "id_str" : "280975510580895744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Oh yes, that was the worst job done in a long time. :D",
  "id" : 280975510580895744,
  "in_reply_to_status_id" : 280486881211346944,
  "created_at" : "2012-12-18 09:59:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280811692953317376",
  "text" : "\u00ABFindest du wir streiten zu viel?\u00BB \u2013 \u00ABNein, ich wei\u00DF ja wenn ich recht habe.\u00BB",
  "id" : 280811692953317376,
  "created_at" : "2012-12-17 23:08:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280809433817305088",
  "geo" : { },
  "id_str" : "280809728303579137",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 ich bin mit ihr unterwegs. Sie ist aber ganz und gar in Baldurs Gate versunken. Also h\u00F6re ich Musik &amp; lese Feeds. :)",
  "id" : 280809728303579137,
  "in_reply_to_status_id" : 280809433817305088,
  "created_at" : "2012-12-17 23:00:31 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    }, {
      "name" : "John Pavlus",
      "screen_name" : "johnpavlus",
      "indices" : [ 125, 136 ],
      "id_str" : "12798822",
      "id" : 12798822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/4kErzc29",
      "expanded_url" : "http:\/\/www.technologyreview.com\/view\/508901\/by-hiring-kurzweil-google-just-killed-the-singularity\/",
      "display_url" : "technologyreview.com\/view\/508901\/by\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280806598954336257",
  "text" : "RT @AkshatRathi: By hiring Ray Kurzweil Google just killed singluarity, and perhaps helped humanity. http:\/\/t.co\/4kErzc29 HT @johnpavlus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Pavlus",
        "screen_name" : "johnpavlus",
        "indices" : [ 108, 119 ],
        "id_str" : "12798822",
        "id" : 12798822
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/4kErzc29",
        "expanded_url" : "http:\/\/www.technologyreview.com\/view\/508901\/by-hiring-kurzweil-google-just-killed-the-singularity\/",
        "display_url" : "technologyreview.com\/view\/508901\/by\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280805237319692288",
    "text" : "By hiring Ray Kurzweil Google just killed singluarity, and perhaps helped humanity. http:\/\/t.co\/4kErzc29 HT @johnpavlus",
    "id" : 280805237319692288,
    "created_at" : "2012-12-17 22:42:40 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 280806598954336257,
  "created_at" : "2012-12-17 22:48:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/UGwf6t1r",
      "expanded_url" : "http:\/\/j.mp\/VMLqXq",
      "display_url" : "j.mp\/VMLqXq"
    } ]
  },
  "geo" : { },
  "id_str" : "280803711645798400",
  "text" : "Should the Cox Proportional Hazards model get the Nobel Prize in Medicine? http:\/\/t.co\/UGwf6t1r",
  "id" : 280803711645798400,
  "created_at" : "2012-12-17 22:36:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/OfBrNf3Q",
      "expanded_url" : "http:\/\/j.mp\/T4B1ca",
      "display_url" : "j.mp\/T4B1ca"
    } ]
  },
  "geo" : { },
  "id_str" : "280803473891684352",
  "text" : "Promises http:\/\/t.co\/OfBrNf3Q",
  "id" : 280803473891684352,
  "created_at" : "2012-12-17 22:35:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Horev",
      "screen_name" : "GuyHorev",
      "indices" : [ 0, 9 ],
      "id_str" : "376585264",
      "id" : 376585264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280795244751093761",
  "geo" : { },
  "id_str" : "280796426089426945",
  "in_reply_to_user_id" : 376585264,
  "text" : "@GuyHorev yep :)",
  "id" : 280796426089426945,
  "in_reply_to_status_id" : 280795244751093761,
  "created_at" : "2012-12-17 22:07:39 +0000",
  "in_reply_to_screen_name" : "GuyHorev",
  "in_reply_to_user_id_str" : "376585264",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280792980263165952",
  "text" : "\u00AB13 Zwerge was an inside Job!\u00BB",
  "id" : 280792980263165952,
  "created_at" : "2012-12-17 21:53:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280790075367899140",
  "text" : "\u00ABBlind Guardian haben ja auch viele von Tolkiens Legenden vertont.\u00BB \u2014 \u00ABStimmt, das mit dem Surfen!\u00BB",
  "id" : 280790075367899140,
  "created_at" : "2012-12-17 21:42:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280764965445582849",
  "geo" : { },
  "id_str" : "280765175525679104",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg danke, werde ich mal machen :)",
  "id" : 280765175525679104,
  "in_reply_to_status_id" : 280764965445582849,
  "created_at" : "2012-12-17 20:03:28 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280728466494717952",
  "geo" : { },
  "id_str" : "280728819881611265",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg nicht zwingend. Aktuell mache ich ja auch \u00D6kologie &amp; Evolution. Personal Genomics darf auch Hobby bleiben :)",
  "id" : 280728819881611265,
  "in_reply_to_status_id" : 280728466494717952,
  "created_at" : "2012-12-17 17:39:01 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/78SvJTfX",
      "expanded_url" : "http:\/\/instagr.am\/p\/TWJ6Brhwqx\/",
      "display_url" : "instagr.am\/p\/TWJ6Brhwqx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "280727435698372609",
  "text" : "Einbruchgefahr! http:\/\/t.co\/78SvJTfX",
  "id" : 280727435698372609,
  "created_at" : "2012-12-17 17:33:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280724720389877760",
  "geo" : { },
  "id_str" : "280725834296344579",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg kein Ding, das Leben geht weiter. :) Ich bin ja nur Biologe by Training. W\u00FCrde jetzt mehr in die echte(tm) Bioinformatik gehen.",
  "id" : 280725834296344579,
  "in_reply_to_status_id" : 280724720389877760,
  "created_at" : "2012-12-17 17:27:09 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Boegel",
      "screen_name" : "sebboeg",
      "indices" : [ 0, 8 ],
      "id_str" : "296476788",
      "id" : 296476788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280717747002933248",
  "geo" : { },
  "id_str" : "280718953477722113",
  "in_reply_to_user_id" : 296476788,
  "text" : "@sebboeg Das was es +\/- immer ist in der Wissenschaft: Die Finanzierung. ;)",
  "id" : 280718953477722113,
  "in_reply_to_status_id" : 280717747002933248,
  "created_at" : "2012-12-17 16:59:48 +0000",
  "in_reply_to_screen_name" : "sebboeg",
  "in_reply_to_user_id_str" : "296476788",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/RlIKFvb5",
      "expanded_url" : "http:\/\/j.mp\/UMh08E",
      "display_url" : "j.mp\/UMh08E"
    } ]
  },
  "geo" : { },
  "id_str" : "280712591645474816",
  "text" : "I had to sell my body! http:\/\/t.co\/RlIKFvb5",
  "id" : 280712591645474816,
  "created_at" : "2012-12-17 16:34:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280712077172158465",
  "geo" : { },
  "id_str" : "280712166947028993",
  "in_reply_to_user_id" : 31104704,
  "text" : "@CaeVye danke!",
  "id" : 280712166947028993,
  "in_reply_to_status_id" : 280712077172158465,
  "created_at" : "2012-12-17 16:32:50 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280711833457922049",
  "text" : "Und da sind die PhD-Pl\u00E4ne zur\u00FCck auf Null.",
  "id" : 280711833457922049,
  "created_at" : "2012-12-17 16:31:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280705570405761025",
  "text" : "\u00ABIch wei\u00DF nicht mehr ob er angeschossen wurde oder einen Herzinfarkt hatte. Aber die Symptome sind ja \u00E4hnlich.\u00BB\u2014\u00ABStechende Brustschmerzen?\u00BB",
  "id" : 280705570405761025,
  "created_at" : "2012-12-17 16:06:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280703957440012290",
  "text" : "\u00ABAbz\u00FCge in der B-Note: Die Lichtverh\u00E4ltnisse hier erlauben keine ordentlichen Essensfotos f\u00FCr Instagram.\u00BB",
  "id" : 280703957440012290,
  "created_at" : "2012-12-17 16:00:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scih\u00F6rnchen",
      "screen_name" : "MTaege",
      "indices" : [ 0, 7 ],
      "id_str" : "286361635",
      "id" : 286361635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280698798035070977",
  "geo" : { },
  "id_str" : "280702715561123840",
  "in_reply_to_user_id" : 286361635,
  "text" : "@MTaege leider war DIY kein so gro\u00DFes Thema beim SpotOn London dieses Jahr. Naja, vielleicht 2013 :)",
  "id" : 280702715561123840,
  "in_reply_to_status_id" : 280698798035070977,
  "created_at" : "2012-12-17 15:55:17 +0000",
  "in_reply_to_screen_name" : "MTaege",
  "in_reply_to_user_id_str" : "286361635",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scih\u00F6rnchen",
      "screen_name" : "MTaege",
      "indices" : [ 0, 7 ],
      "id_str" : "286361635",
      "id" : 286361635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280691712345640960",
  "geo" : { },
  "id_str" : "280693739981250560",
  "in_reply_to_user_id" : 286361635,
  "text" : "@MTaege danke, hab es mir mal gebookmarkt.",
  "id" : 280693739981250560,
  "in_reply_to_status_id" : 280691712345640960,
  "created_at" : "2012-12-17 15:19:37 +0000",
  "in_reply_to_screen_name" : "MTaege",
  "in_reply_to_user_id_str" : "286361635",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/zkTEgaI4",
      "expanded_url" : "http:\/\/tinyurl.com\/d2ng742",
      "display_url" : "tinyurl.com\/d2ng742"
    } ]
  },
  "geo" : { },
  "id_str" : "280676052815208448",
  "text" : "Amerikanische Wissenschaftler haben herausgefunden: Schokolade ist gut f\u00FCr Roboterarme http:\/\/t.co\/zkTEgaI4",
  "id" : 280676052815208448,
  "created_at" : "2012-12-17 14:09:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280672487254138880",
  "geo" : { },
  "id_str" : "280673444469825536",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Btw: How's your work going? Do you need more proofreading?",
  "id" : 280673444469825536,
  "in_reply_to_status_id" : 280672487254138880,
  "created_at" : "2012-12-17 13:58:58 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280672487254138880",
  "geo" : { },
  "id_str" : "280672787830558721",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a May I introduce you to fastq. (But I won't tell you which of the 3 billion quality-encodings I've used!)",
  "id" : 280672787830558721,
  "in_reply_to_status_id" : 280672487254138880,
  "created_at" : "2012-12-17 13:56:21 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280652127255265280",
  "geo" : { },
  "id_str" : "280652626645905409",
  "in_reply_to_user_id" : 14700783,
  "text" : "@fischblog Hoffen wir mal das die \u00C4rzte das Gleiche auch vom OP-Besteck sagen k\u00F6nnen ;)",
  "id" : 280652626645905409,
  "in_reply_to_status_id" : 280652127255265280,
  "created_at" : "2012-12-17 12:36:15 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/Z7EEUIac",
      "expanded_url" : "http:\/\/tinyurl.com\/cywaz6k",
      "display_url" : "tinyurl.com\/cywaz6k"
    } ]
  },
  "geo" : { },
  "id_str" : "280651717152997376",
  "text" : "\"When the KKK steps in as the voice of reason, you know you are dealing with the bottom-of-the-barrel crazy.\" http:\/\/t.co\/Z7EEUIac",
  "id" : 280651717152997376,
  "created_at" : "2012-12-17 12:32:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280648701754617856",
  "text" : "Feels more like doing my \"Master of String-Manipulation\" recently...",
  "id" : 280648701754617856,
  "created_at" : "2012-12-17 12:20:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/Pq87N4Jz",
      "expanded_url" : "http:\/\/j.mp\/T1Vxcc",
      "display_url" : "j.mp\/T1Vxcc"
    } ]
  },
  "geo" : { },
  "id_str" : "280614863678615552",
  "text" : "\u00ABIt\u2019s a pity that all our participants ran away screaming before the first scan\u00BB http:\/\/t.co\/Pq87N4Jz",
  "id" : 280614863678615552,
  "created_at" : "2012-12-17 10:06:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/iFFkIpiK",
      "expanded_url" : "http:\/\/xkcd.com\/1148\/",
      "display_url" : "xkcd.com\/1148\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009626, 8.283028 ]
  },
  "id_str" : "280614243185852416",
  "text" : "Churchill really wanted to keep most of his body fluids  http:\/\/t.co\/iFFkIpiK",
  "id" : 280614243185852416,
  "created_at" : "2012-12-17 10:03:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/llX9ZwaQ",
      "expanded_url" : "http:\/\/j.mp\/T1V75M",
      "display_url" : "j.mp\/T1V75M"
    } ]
  },
  "geo" : { },
  "id_str" : "280613563184316416",
  "text" : "Am Frankfurter Flughafen kann man sich jetzt anschauen ob Nobelpreistr\u00E4ger zeichnen k\u00F6nnen oder nicht http:\/\/t.co\/llX9ZwaQ",
  "id" : 280613563184316416,
  "created_at" : "2012-12-17 10:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "The Daily Mash",
      "screen_name" : "thedailymash",
      "indices" : [ 18, 31 ],
      "id_str" : "18668407",
      "id" : 18668407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/WFveczBW",
      "expanded_url" : "http:\/\/www.thedailymash.co.uk\/news\/society\/mayans-full-of-shit-say-experts-from-within-lead-lined-bunker-2012121753571",
      "display_url" : "thedailymash.co.uk\/news\/society\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280600455862685697",
  "text" : "RT @edyong209: RT @thedailymash: Mayans \u2018full of shit\u2019 say experts from within lead-lined bunker http:\/\/t.co\/WFveczBW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Mash",
        "screen_name" : "thedailymash",
        "indices" : [ 3, 16 ],
        "id_str" : "18668407",
        "id" : 18668407
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/WFveczBW",
        "expanded_url" : "http:\/\/www.thedailymash.co.uk\/news\/society\/mayans-full-of-shit-say-experts-from-within-lead-lined-bunker-2012121753571",
        "display_url" : "thedailymash.co.uk\/news\/society\/m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280599713433149440",
    "text" : "RT @thedailymash: Mayans \u2018full of shit\u2019 say experts from within lead-lined bunker http:\/\/t.co\/WFveczBW",
    "id" : 280599713433149440,
    "created_at" : "2012-12-17 09:05:59 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 280600455862685697,
  "created_at" : "2012-12-17 09:08:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280595644547219457",
  "text" : "Zweithaardesigner Siggi",
  "id" : 280595644547219457,
  "created_at" : "2012-12-17 08:49:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280591478361817088",
  "geo" : { },
  "id_str" : "280592441705377793",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara okay, got to take on of those trains to Frankfurt. Glad it\u2019s not a bigger problem.",
  "id" : 280592441705377793,
  "in_reply_to_status_id" : 280591478361817088,
  "created_at" : "2012-12-17 08:37:05 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 0, 9 ],
      "id_str" : "19146944",
      "id" : 19146944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280589719711125504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0428857025, 8.2530124841 ]
  },
  "id_str" : "280590095126511616",
  "in_reply_to_user_id" : 19146944,
  "text" : "@BobOHara S8 or S9?",
  "id" : 280590095126511616,
  "in_reply_to_status_id" : 280589719711125504,
  "created_at" : "2012-12-17 08:27:46 +0000",
  "in_reply_to_screen_name" : "BobOHara",
  "in_reply_to_user_id_str" : "19146944",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280589257083600896",
  "text" : "\u00ABSure: You\u2019re looking suspicious. You have a beard!\u00BB \u2014 \u00ABYou should try to apply with the TSA. They need highly trained profilers like you!\u00BB",
  "id" : 280589257083600896,
  "created_at" : "2012-12-17 08:24:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280449927677612033",
  "geo" : { },
  "id_str" : "280461258828963840",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus @Senficon ja, mir ist nur noch nicht ganz klar geworden wie Cap &amp; Capper jetzt Bayes .\/. Fisher l\u00F6sen soll. ;)",
  "id" : 280461258828963840,
  "in_reply_to_status_id" : 280449927677612033,
  "created_at" : "2012-12-16 23:55:49 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280448353827954690",
  "text" : "RT @Senficon: Disney Porn Mashups: Two Girls one Cap &amp; Capper o.O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280448110294097921",
    "text" : "Disney Porn Mashups: Two Girls one Cap &amp; Capper o.O",
    "id" : 280448110294097921,
    "created_at" : "2012-12-16 23:03:34 +0000",
    "user" : {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "protected" : false,
      "id_str" : "14861745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637016870638350336\/QrtPmoul_normal.jpg",
      "id" : 14861745,
      "verified" : true
    }
  },
  "id" : 280448353827954690,
  "created_at" : "2012-12-16 23:04:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280448216330285056",
  "text" : "Beziehungsprobleme. Anschaulich an Cap und Capper erkl\u00E4rt.",
  "id" : 280448216330285056,
  "created_at" : "2012-12-16 23:03:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280440027643797504",
  "text" : "\u00ABYes, you\u2019re important to me. Nearly as important as science!\u00BB \u2014 \u00ABWell, fair enough.\u00BB",
  "id" : 280440027643797504,
  "created_at" : "2012-12-16 22:31:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280406397630414848",
  "geo" : { },
  "id_str" : "280407760875708416",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a (that\u2019s most likely a bias on my behalf, triggered by doing too much de novo RNA seq assembly)",
  "id" : 280407760875708416,
  "in_reply_to_status_id" : 280406397630414848,
  "created_at" : "2012-12-16 20:23:14 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280406397630414848",
  "geo" : { },
  "id_str" : "280407060594712576",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I\u2019d be more concerned about unbiased success metrics. ;)",
  "id" : 280407060594712576,
  "in_reply_to_status_id" : 280406397630414848,
  "created_at" : "2012-12-16 20:20:27 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280403920860368896",
  "geo" : { },
  "id_str" : "280404220958605312",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a well, most of science starts out with small sample sizes.",
  "id" : 280404220958605312,
  "in_reply_to_status_id" : 280403920860368896,
  "created_at" : "2012-12-16 20:09:10 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280403242402340864",
  "geo" : { },
  "id_str" : "280403663430758400",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a i hope you have studies to support your view. ;)",
  "id" : 280403663430758400,
  "in_reply_to_status_id" : 280403242402340864,
  "created_at" : "2012-12-16 20:06:57 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280364248536866816",
  "text" : "\u00ABI mean it from the bottom of my heart: All romance ends in despair. Or death. But mostly despair\u00BB",
  "id" : 280364248536866816,
  "created_at" : "2012-12-16 17:30:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280355658925223936",
  "text" : "\u00ABThe only thing she is guilty of is being awesome\u00BB",
  "id" : 280355658925223936,
  "created_at" : "2012-12-16 16:56:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280307829900972032",
  "text" : "Krank sein ist so praktisch. Man bekommt so viel Zeug geschafft. Und damit meine ich: Man kann so viele Folgen Psych in Reihe schauen.",
  "id" : 280307829900972032,
  "created_at" : "2012-12-16 13:46:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/v4u1CrAt",
      "expanded_url" : "http:\/\/sciencecareers.sciencemag.org\/career_magazine\/previous_issues\/articles\/2012_12_14\/caredit.a1200137",
      "display_url" : "sciencecareers.sciencemag.org\/career_magazin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280271731086737408",
  "text" : "The Myth of the Well-Rounded Scientist http:\/\/t.co\/v4u1CrAt",
  "id" : 280271731086737408,
  "created_at" : "2012-12-16 11:22:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/5JrQulHi",
      "expanded_url" : "http:\/\/imgur.com\/a\/WIjki",
      "display_url" : "imgur.com\/a\/WIjki"
    } ]
  },
  "geo" : { },
  "id_str" : "280266427666145280",
  "text" : "Alternate Endings http:\/\/t.co\/5JrQulHi",
  "id" : 280266427666145280,
  "created_at" : "2012-12-16 11:01:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280134713241370624",
  "geo" : { },
  "id_str" : "280253606731608064",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u2026in order to use its skin to hide Python: Go for it! :P",
  "id" : 280253606731608064,
  "in_reply_to_status_id" : 280134713241370624,
  "created_at" : "2012-12-16 10:10:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280134713241370624",
  "geo" : { },
  "id_str" : "280253514251382785",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Yes. I\u2019d rather see pure Python in all browsers. But if we have to skin JS alive, kicking &amp; screaming\u2026",
  "id" : 280253514251382785,
  "in_reply_to_status_id" : 280134713241370624,
  "created_at" : "2012-12-16 10:10:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "indices" : [ 3, 14 ],
      "id_str" : "13183522",
      "id" : 13183522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280249470405472256",
  "text" : "RT @fabianmohr: same walmart that refused to do prints of my pictures from burning man festival because of their \"family values policy\". ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280235992860987392",
    "text" : "same walmart that refused to do prints of my pictures from burning man festival because of their \"family values policy\". true story.",
    "id" : 280235992860987392,
    "created_at" : "2012-12-16 09:00:41 +0000",
    "user" : {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "protected" : false,
      "id_str" : "13183522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932352046967246849\/UXOqOF2N_normal.jpg",
      "id" : 13183522,
      "verified" : true
    }
  },
  "id" : 280249470405472256,
  "created_at" : "2012-12-16 09:54:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "indices" : [ 3, 14 ],
      "id_str" : "13183522",
      "id" : 13183522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newtown",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/nqkiOuDY",
      "expanded_url" : "http:\/\/mobile.walmart.com\/m\/phoenix;jsessionid=50A5E3F3C8CE3C3D7D9F5D000B2FFE13#ip\/Bushmaster-M4A3-.223-REM-16-Patrol-Carbine\/19235996",
      "display_url" : "mobile.walmart.com\/m\/phoenix;jses\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280249448813195264",
  "text" : "RT @fabianmohr: \"this gun from bushmaster will always shoot straight and aim true.\" walmart store: http:\/\/t.co\/nqkiOuDY #newtown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "newtown",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/nqkiOuDY",
        "expanded_url" : "http:\/\/mobile.walmart.com\/m\/phoenix;jsessionid=50A5E3F3C8CE3C3D7D9F5D000B2FFE13#ip\/Bushmaster-M4A3-.223-REM-16-Patrol-Carbine\/19235996",
        "display_url" : "mobile.walmart.com\/m\/phoenix;jses\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280234525685084160",
    "text" : "\"this gun from bushmaster will always shoot straight and aim true.\" walmart store: http:\/\/t.co\/nqkiOuDY #newtown",
    "id" : 280234525685084160,
    "created_at" : "2012-12-16 08:54:52 +0000",
    "user" : {
      "name" : "Fabian Mohr",
      "screen_name" : "fabianmohr",
      "protected" : false,
      "id_str" : "13183522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932352046967246849\/UXOqOF2N_normal.jpg",
      "id" : 13183522,
      "verified" : true
    }
  },
  "id" : 280249448813195264,
  "created_at" : "2012-12-16 09:54:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/K0CMmeUJ",
      "expanded_url" : "http:\/\/i.imgur.com\/08jxb.jpg",
      "display_url" : "i.imgur.com\/08jxb.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "280061543842979841",
  "text" : "We\u2019re drifting apart\u2026 http:\/\/t.co\/K0CMmeUJ",
  "id" : 280061543842979841,
  "created_at" : "2012-12-15 21:27:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 81, 94 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/8urcd7IG",
      "expanded_url" : "http:\/\/www.brython.info\/index_en.html",
      "display_url" : "brython.info\/index_en.html"
    } ]
  },
  "geo" : { },
  "id_str" : "280051565950291968",
  "text" : "I\u2019d really like to see JS die and be replaced by Python http:\/\/t.co\/8urcd7IG \/cc @PhilippBayer",
  "id" : 280051565950291968,
  "created_at" : "2012-12-15 20:47:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/pMDGycsv",
      "expanded_url" : "http:\/\/j.mp\/Tkl14v",
      "display_url" : "j.mp\/Tkl14v"
    } ]
  },
  "geo" : { },
  "id_str" : "280046835081547776",
  "text" : "Les (Really) Miserables http:\/\/t.co\/pMDGycsv",
  "id" : 280046835081547776,
  "created_at" : "2012-12-15 20:29:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280022765623455747",
  "geo" : { },
  "id_str" : "280025029973000193",
  "in_reply_to_user_id" : 110795320,
  "text" : "@erklaerfix ah, danke!",
  "id" : 280025029973000193,
  "in_reply_to_status_id" : 280022765623455747,
  "created_at" : "2012-12-15 19:02:24 +0000",
  "in_reply_to_screen_name" : "neugierologe",
  "in_reply_to_user_id_str" : "110795320",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Ef0vt5JV",
      "expanded_url" : "http:\/\/j.mp\/Sv3WZ4",
      "display_url" : "j.mp\/Sv3WZ4"
    } ]
  },
  "geo" : { },
  "id_str" : "280021406174040065",
  "text" : "Creativity can be improved by spending time with Nature http:\/\/t.co\/Ef0vt5JV",
  "id" : 280021406174040065,
  "created_at" : "2012-12-15 18:48:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280014434234146816",
  "text" : "\u00ABEinfach niemanden schw\u00E4ngern. Dann darfst du auch in Deutschland bleiben.\u00BB",
  "id" : 280014434234146816,
  "created_at" : "2012-12-15 18:20:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 3, 17 ],
      "id_str" : "112475924",
      "id" : 112475924
    }, {
      "name" : "Michele Banks",
      "screen_name" : "artologica",
      "indices" : [ 92, 103 ],
      "id_str" : "121869155",
      "id" : 121869155
    }, {
      "name" : "Brian Switek @MFF",
      "screen_name" : "Laelaps",
      "indices" : [ 108, 116 ],
      "id_str" : "29342640",
      "id" : 29342640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/dFRnmE9g",
      "expanded_url" : "http:\/\/amzn.com\/B004XWGSIE",
      "display_url" : "amzn.com\/B004XWGSIE"
    } ]
  },
  "geo" : { },
  "id_str" : "280004797149626368",
  "text" : "RT @JacquelynGill: I have been slain...by CUTENESS! It's a Tea Rex! http:\/\/t.co\/dFRnmE9g HT @artologica, cc @laelaps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michele Banks",
        "screen_name" : "artologica",
        "indices" : [ 73, 84 ],
        "id_str" : "121869155",
        "id" : 121869155
      }, {
        "name" : "Brian Switek @MFF",
        "screen_name" : "Laelaps",
        "indices" : [ 89, 97 ],
        "id_str" : "29342640",
        "id" : 29342640
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/dFRnmE9g",
        "expanded_url" : "http:\/\/amzn.com\/B004XWGSIE",
        "display_url" : "amzn.com\/B004XWGSIE"
      } ]
    },
    "geo" : { },
    "id_str" : "280004601376301056",
    "text" : "I have been slain...by CUTENESS! It's a Tea Rex! http:\/\/t.co\/dFRnmE9g HT @artologica, cc @laelaps",
    "id" : 280004601376301056,
    "created_at" : "2012-12-15 17:41:13 +0000",
    "user" : {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "protected" : false,
      "id_str" : "112475924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816027573343965184\/qUfIq3xY_normal.jpg",
      "id" : 112475924,
      "verified" : true
    }
  },
  "id" : 280004797149626368,
  "created_at" : "2012-12-15 17:42:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279975663375638528",
  "text" : "\u00ABThis is a disaster. I hire a psychopath to work in my murder camp. What are the odds?\u00BB",
  "id" : 279975663375638528,
  "created_at" : "2012-12-15 15:46:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279952688857374720",
  "text" : "\u00ABHow can you tell that someone's a compulsive liar? I mean, assuming that their pants aren't on fire.\u00BB",
  "id" : 279952688857374720,
  "created_at" : "2012-12-15 14:14:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279945911604506624",
  "text" : "\u00ABNanometer? What is that? Like two or three feet?\u00BB",
  "id" : 279945911604506624,
  "created_at" : "2012-12-15 13:48:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cc10",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279944584254083073",
  "text" : "RT @wilbanks: BY-ND-NC is absolutely dominant in France. Based on graphs looks like 90%+ #cc10",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cc10",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279941565038854144",
    "text" : "BY-ND-NC is absolutely dominant in France. Based on graphs looks like 90%+ #cc10",
    "id" : 279941565038854144,
    "created_at" : "2012-12-15 13:30:44 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 279944584254083073,
  "created_at" : "2012-12-15 13:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phryk",
      "screen_name" : "lephryk",
      "indices" : [ 0, 8 ],
      "id_str" : "211820423",
      "id" : 211820423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279899741351968768",
  "geo" : { },
  "id_str" : "279902957250682880",
  "in_reply_to_user_id" : 211820423,
  "text" : "@lephryk and given how secure their submission system is I wouldn\u2019t be surprised if some it sec researcher could add new categories :D",
  "id" : 279902957250682880,
  "in_reply_to_status_id" : 279899741351968768,
  "created_at" : "2012-12-15 10:57:20 +0000",
  "in_reply_to_screen_name" : "lephryk",
  "in_reply_to_user_id_str" : "211820423",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phryk",
      "screen_name" : "lephryk",
      "indices" : [ 0, 8 ],
      "id_str" : "211820423",
      "id" : 211820423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279899741351968768",
  "geo" : { },
  "id_str" : "279902725452476416",
  "in_reply_to_user_id" : 211820423,
  "text" : "@lephryk PLOS ONE is open to pretty much everything. So CompSci in a greater sense should be fine.",
  "id" : 279902725452476416,
  "in_reply_to_status_id" : 279899741351968768,
  "created_at" : "2012-12-15 10:56:24 +0000",
  "in_reply_to_screen_name" : "lephryk",
  "in_reply_to_user_id_str" : "211820423",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "phryk",
      "screen_name" : "lephryk",
      "indices" : [ 0, 8 ],
      "id_str" : "211820423",
      "id" : 211820423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279897536762875904",
  "geo" : { },
  "id_str" : "279898483316645888",
  "in_reply_to_user_id" : 211820423,
  "text" : "@lephryk you\u2019d expect that PLOS ONE would be swamped with lots of IT Sec publications which \u201Esomehow\u201C made it through review ;)",
  "id" : 279898483316645888,
  "in_reply_to_status_id" : 279897536762875904,
  "created_at" : "2012-12-15 10:39:33 +0000",
  "in_reply_to_screen_name" : "lephryk",
  "in_reply_to_user_id_str" : "211820423",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279897254477832192",
  "text" : "Simple example: The \u201CEditorial Manager\u201D-software of PLOS ONE emails you your old password in plain text if you\u2019ve forgotten it\u2026",
  "id" : 279897254477832192,
  "created_at" : "2012-12-15 10:34:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/g6MJM6iU",
      "expanded_url" : "http:\/\/retractionwatch.wordpress.com\/2012\/12\/11\/elsevier-editorial-system-hacked-reviews-faked-11-retractions-follow\/",
      "display_url" : "retractionwatch.wordpress.com\/2012\/12\/11\/els\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279896706064199681",
  "text" : "Given the state of most editorial software this isn\u2019t too surprising: Fake reviews via hacked editing system http:\/\/t.co\/g6MJM6iU",
  "id" : 279896706064199681,
  "created_at" : "2012-12-15 10:32:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/4nndGX5t",
      "expanded_url" : "http:\/\/j.mp\/Z6yXWc",
      "display_url" : "j.mp\/Z6yXWc"
    } ]
  },
  "geo" : { },
  "id_str" : "279722623250862080",
  "text" : "No big surprise on fishing quotas: Ministers stuck to the scientific advice in only 13% of their decisions\u2026 http:\/\/t.co\/4nndGX5t",
  "id" : 279722623250862080,
  "created_at" : "2012-12-14 23:00:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/W2xe4kOS",
      "expanded_url" : "http:\/\/j.mp\/12qjMoB",
      "display_url" : "j.mp\/12qjMoB"
    } ]
  },
  "geo" : { },
  "id_str" : "279722001365626880",
  "text" : "Before you try to recognize suicidal ppl based on pictures better make sure you understand that p-values != effect size http:\/\/t.co\/W2xe4kOS",
  "id" : 279722001365626880,
  "created_at" : "2012-12-14 22:58:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/cvEaWgua",
      "expanded_url" : "http:\/\/j.mp\/Z6yaED",
      "display_url" : "j.mp\/Z6yaED"
    } ]
  },
  "geo" : { },
  "id_str" : "279720331428646913",
  "text" : "Complete Genomics CEO rebuts warnings of national security risks http:\/\/t.co\/cvEaWgua",
  "id" : 279720331428646913,
  "created_at" : "2012-12-14 22:51:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/vy9BsOVu",
      "expanded_url" : "http:\/\/j.mp\/12qiEBm",
      "display_url" : "j.mp\/12qiEBm"
    } ]
  },
  "geo" : { },
  "id_str" : "279718812696338433",
  "text" : "The Invention of an Illness http:\/\/t.co\/vy9BsOVu",
  "id" : 279718812696338433,
  "created_at" : "2012-12-14 22:45:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279704479274774529",
  "text" : "\u00ABYou know that fungus is my bread and butter.\u00BB \u2013 \u00ABYou know what my bread and butter is? Bread and butter.\u00BB",
  "id" : 279704479274774529,
  "created_at" : "2012-12-14 21:48:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "indices" : [ 0, 13 ],
      "id_str" : "26374915",
      "id" : 26374915
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 14, 24 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 25, 34 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279691408904962049",
  "geo" : { },
  "id_str" : "279692110108696576",
  "in_reply_to_user_id" : 26374915,
  "text" : "@barrycburton @e_ramirez @viirus42 thanks! I\u2019m looking forward to it! :)",
  "id" : 279692110108696576,
  "in_reply_to_status_id" : 279691408904962049,
  "created_at" : "2012-12-14 20:59:30 +0000",
  "in_reply_to_screen_name" : "barrycburton",
  "in_reply_to_user_id_str" : "26374915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "indices" : [ 0, 13 ],
      "id_str" : "26374915",
      "id" : 26374915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279687041715953664",
  "geo" : { },
  "id_str" : "279690419435102208",
  "in_reply_to_user_id" : 26374915,
  "text" : "@barrycburton and I\u2019m already a huge fan of your services and track using Ultra &amp; Aria. But I\u2019m running Mac OS &amp; iOS all over the place. ;)",
  "id" : 279690419435102208,
  "in_reply_to_status_id" : 279687041715953664,
  "created_at" : "2012-12-14 20:52:47 +0000",
  "in_reply_to_screen_name" : "barrycburton",
  "in_reply_to_user_id_str" : "26374915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "indices" : [ 0, 13 ],
      "id_str" : "26374915",
      "id" : 26374915
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 14, 24 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 25, 34 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279687041715953664",
  "geo" : { },
  "id_str" : "279687429361893376",
  "in_reply_to_user_id" : 26374915,
  "text" : "@barrycburton @e_ramirez @viirus42 thanks for pointing that out! Good luck for all your applications. :)",
  "id" : 279687429361893376,
  "in_reply_to_status_id" : 279687041715953664,
  "created_at" : "2012-12-14 20:40:54 +0000",
  "in_reply_to_screen_name" : "barrycburton",
  "in_reply_to_user_id_str" : "26374915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "indices" : [ 0, 13 ],
      "id_str" : "26374915",
      "id" : 26374915
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 14, 24 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 25, 34 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279686517398573057",
  "geo" : { },
  "id_str" : "279687084988579843",
  "in_reply_to_user_id" : 26374915,
  "text" : "@barrycburton @e_ramirez @viirus42 don\u2019t mean to say that you haven\u2019t put lots of work into Android app. Just that doesn\u2019t help in spec case",
  "id" : 279687084988579843,
  "in_reply_to_status_id" : 279686517398573057,
  "created_at" : "2012-12-14 20:39:32 +0000",
  "in_reply_to_screen_name" : "barrycburton",
  "in_reply_to_user_id_str" : "26374915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "indices" : [ 0, 13 ],
      "id_str" : "26374915",
      "id" : 26374915
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 14, 24 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 25, 34 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279686517398573057",
  "geo" : { },
  "id_str" : "279686812946026496",
  "in_reply_to_user_id" : 26374915,
  "text" : "@barrycburton @e_ramirez @viirus42 sure, but if you don\u2019t have a Mac\/Windows\/iOS device you can\u2019t see any data in it because you can\u2019t sync.",
  "id" : 279686812946026496,
  "in_reply_to_status_id" : 279686517398573057,
  "created_at" : "2012-12-14 20:38:27 +0000",
  "in_reply_to_screen_name" : "barrycburton",
  "in_reply_to_user_id_str" : "26374915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/BEvSISjx",
      "expanded_url" : "http:\/\/www.classicshaving.com\/catalog\/item\/8360186\/9623294.htm",
      "display_url" : "classicshaving.com\/catalog\/item\/8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "279658471635435521",
  "geo" : { },
  "id_str" : "279659881315844096",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy http:\/\/t.co\/BEvSISjx :3",
  "id" : 279659881315844096,
  "in_reply_to_status_id" : 279658471635435521,
  "created_at" : "2012-12-14 18:51:26 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sumner Paine",
      "screen_name" : "SMNR",
      "indices" : [ 0, 5 ],
      "id_str" : "14154787",
      "id" : 14154787
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 6, 16 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 17, 26 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279641044411351041",
  "geo" : { },
  "id_str" : "279641355670663169",
  "in_reply_to_user_id" : 14154787,
  "text" : "@SMNR @e_ramirez @viirus42 but it doesn\u2019t sync the devices. Which is what you\u2019d want from the app. :)",
  "id" : 279641355670663169,
  "in_reply_to_status_id" : 279641044411351041,
  "created_at" : "2012-12-14 17:37:49 +0000",
  "in_reply_to_screen_name" : "SMNR",
  "in_reply_to_user_id_str" : "14154787",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 11, 20 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279635294138015745",
  "geo" : { },
  "id_str" : "279635526011744257",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @viirus42 yes, and especially Jawbones \u201Cfuture\u201D is known to be a long time away. :D",
  "id" : 279635526011744257,
  "in_reply_to_status_id" : 279635294138015745,
  "created_at" : "2012-12-14 17:14:39 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 11, 20 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279634332044390400",
  "geo" : { },
  "id_str" : "279635136084070402",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @viirus42 that\u2019s quite sad. I think Jawbone &amp; Fitbit have said to offer Android apps \u201Cin the future\u201D",
  "id" : 279635136084070402,
  "in_reply_to_status_id" : 279634332044390400,
  "created_at" : "2012-12-14 17:13:06 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 11, 20 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279617106956406784",
  "geo" : { },
  "id_str" : "279632357315715072",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @viirus42 thx, I knew that one. But so there aren\u2019t any hardware tools out there ready to use right now? :(",
  "id" : 279632357315715072,
  "in_reply_to_status_id" : 279617106956406784,
  "created_at" : "2012-12-14 17:02:03 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 3, 12 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279631903437512705",
  "text" : "RT @Argent23: Ein kurzer Post auf Alles was lebt mit dem genialen Video von @WeigelWorld und Kollegen aus dem MPI T\u00FCbingen! http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/q5vqlrqM",
        "expanded_url" : "http:\/\/scienceblogs.de\/alles-was-lebt\/2012\/12\/14\/working-weigel-style\/",
        "display_url" : "scienceblogs.de\/alles-was-lebt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "279630928731578368",
    "text" : "Ein kurzer Post auf Alles was lebt mit dem genialen Video von @WeigelWorld und Kollegen aus dem MPI T\u00FCbingen! http:\/\/t.co\/q5vqlrqM",
    "id" : 279630928731578368,
    "created_at" : "2012-12-14 16:56:23 +0000",
    "user" : {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "protected" : false,
      "id_str" : "22828618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1118469929\/13410001_bearbeitet_klein_normal.jpg",
      "id" : 22828618,
      "verified" : false
    }
  },
  "id" : 279631903437512705,
  "created_at" : "2012-12-14 17:00:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/if9oJ30Q",
      "expanded_url" : "http:\/\/j.mp\/Hv4kdR",
      "display_url" : "j.mp\/Hv4kdR"
    } ]
  },
  "geo" : { },
  "id_str" : "279630559947415553",
  "text" : "The Missing 20th Century: How Copyright Protection Makes Books Vanish http:\/\/t.co\/if9oJ30Q",
  "id" : 279630559947415553,
  "created_at" : "2012-12-14 16:54:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/Xf01kB5I",
      "expanded_url" : "http:\/\/j.mp\/XmtgwA",
      "display_url" : "j.mp\/XmtgwA"
    } ]
  },
  "geo" : { },
  "id_str" : "279630070258204672",
  "text" : "Skills for the apocalypse http:\/\/t.co\/Xf01kB5I",
  "id" : 279630070258204672,
  "created_at" : "2012-12-14 16:52:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "indices" : [ 3, 11 ],
      "id_str" : "19863141",
      "id" : 19863141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279629711401971713",
  "text" : "RT @cdarwin: The number of things to be done is infinite",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.thebeaglevoyage.com\/\" rel=\"nofollow\"\u003EHMSBeagle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279629582049636352",
    "text" : "The number of things to be done is infinite",
    "id" : 279629582049636352,
    "created_at" : "2012-12-14 16:51:02 +0000",
    "user" : {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "protected" : false,
      "id_str" : "19863141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/75125076\/darwin_normal.jpg",
      "id" : 19863141,
      "verified" : false
    }
  },
  "id" : 279629711401971713,
  "created_at" : "2012-12-14 16:51:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "indices" : [ 3, 12 ],
      "id_str" : "43360175",
      "id" : 43360175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "polyamory",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/u0Pq5BqP",
      "expanded_url" : "http:\/\/j.mp\/QYuPmm",
      "display_url" : "j.mp\/QYuPmm"
    } ]
  },
  "geo" : { },
  "id_str" : "279607860223176704",
  "text" : "RT @JoonasD6: \"What responsibilities we have, if any, to our lovers\u2019 other partners.\" http:\/\/t.co\/u0Pq5BqP #polyamory",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "polyamory",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/u0Pq5BqP",
        "expanded_url" : "http:\/\/j.mp\/QYuPmm",
        "display_url" : "j.mp\/QYuPmm"
      } ]
    },
    "geo" : { },
    "id_str" : "279605742053490688",
    "text" : "\"What responsibilities we have, if any, to our lovers\u2019 other partners.\" http:\/\/t.co\/u0Pq5BqP #polyamory",
    "id" : 279605742053490688,
    "created_at" : "2012-12-14 15:16:18 +0000",
    "user" : {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "protected" : false,
      "id_str" : "43360175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/238120339\/Pi3_150x150_normal.jpg",
      "id" : 43360175,
      "verified" : false
    }
  },
  "id" : 279607860223176704,
  "created_at" : "2012-12-14 15:24:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/xvwsXMI4",
      "expanded_url" : "http:\/\/i.imgur.com\/RvUGY.jpg",
      "display_url" : "i.imgur.com\/RvUGY.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "279588760079982593",
  "text" : "\u00ABNot now, I\u2019m doing science!\u00BB http:\/\/t.co\/xvwsXMI4",
  "id" : 279588760079982593,
  "created_at" : "2012-12-14 14:08:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/IyS9fqU2",
      "expanded_url" : "http:\/\/poorlydrawnlines.com\/comic\/love-tree\/",
      "display_url" : "poorlydrawnlines.com\/comic\/love-tre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279581729134612481",
  "text" : "Do you love me? http:\/\/t.co\/IyS9fqU2",
  "id" : 279581729134612481,
  "created_at" : "2012-12-14 13:40:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/QrOxHlaK",
      "expanded_url" : "http:\/\/poorlydrawnlines.com\/comic\/snail\/",
      "display_url" : "poorlydrawnlines.com\/comic\/snail\/"
    } ]
  },
  "geo" : { },
  "id_str" : "279576930540457984",
  "text" : "Don\u2019t give snails cocaine! http:\/\/t.co\/QrOxHlaK",
  "id" : 279576930540457984,
  "created_at" : "2012-12-14 13:21:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/7zel2Y2h",
      "expanded_url" : "http:\/\/www.sciencemag.org\/content\/338\/6113\/1462",
      "display_url" : "sciencemag.org\/content\/338\/61\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279569051028684800",
  "text" : "\u00ABAn invol. sex pheromone in male mouse urine, can rapidly condition preference for its remembered location\u00BB(subs. req) http:\/\/t.co\/7zel2Y2h",
  "id" : 279569051028684800,
  "created_at" : "2012-12-14 12:50:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Amsen",
      "screen_name" : "easternblot",
      "indices" : [ 3, 15 ],
      "id_str" : "14506075",
      "id" : 14506075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sonyc",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279567945108160513",
  "text" : "RT @easternblot: All these DIY science things make me excited about experiments again. I lost that excitement years ago... #Sonyc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sonyc",
        "indices" : [ 106, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279566935698571265",
    "text" : "All these DIY science things make me excited about experiments again. I lost that excitement years ago... #Sonyc",
    "id" : 279566935698571265,
    "created_at" : "2012-12-14 12:42:06 +0000",
    "user" : {
      "name" : "Eva Amsen",
      "screen_name" : "easternblot",
      "protected" : false,
      "id_str" : "14506075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821131597848121345\/Zedt0G5I_normal.jpg",
      "id" : 14506075,
      "verified" : false
    }
  },
  "id" : 279567945108160513,
  "created_at" : "2012-12-14 12:46:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/RzRgeoEv",
      "expanded_url" : "http:\/\/j.mp\/Ur4kmH",
      "display_url" : "j.mp\/Ur4kmH"
    } ]
  },
  "geo" : { },
  "id_str" : "279566980468580353",
  "text" : "German court bars local-government interference with animal research http:\/\/t.co\/RzRgeoEv",
  "id" : 279566980468580353,
  "created_at" : "2012-12-14 12:42:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/qEHqI2m1",
      "expanded_url" : "http:\/\/j.mp\/Ur2GS2",
      "display_url" : "j.mp\/Ur2GS2"
    } ]
  },
  "geo" : { },
  "id_str" : "279564471003934720",
  "text" : "Bladerunner FX-Storyboards http:\/\/t.co\/qEHqI2m1",
  "id" : 279564471003934720,
  "created_at" : "2012-12-14 12:32:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/8FiQwloa",
      "expanded_url" : "http:\/\/www.theonion.com\/articles\/mumford-and-sons-cant-believe-they-all-got-each-ot,30709\/",
      "display_url" : "theonion.com\/articles\/mumfo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279557969933389824",
  "text" : "Mumford And Sons Can't Believe They All Got Each Other Mandolins For Christmas http:\/\/t.co\/8FiQwloa",
  "id" : 279557969933389824,
  "created_at" : "2012-12-14 12:06:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279551482574032896",
  "text" : "Klar werde ich eure propriet\u00E4ren &amp; kommerziellen \u00C4nderungen an meinem freien Code gerne umsonst bugfixen da ihr nicht wisst was ihr tut\u2026 m(",
  "id" : 279551482574032896,
  "created_at" : "2012-12-14 11:40:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279549042663518208",
  "geo" : { },
  "id_str" : "279549200662945792",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Alles gute. Sag Bescheid wenn wir wieder Nonsense twittern sollen um dich zu unterhalten :)",
  "id" : 279549200662945792,
  "in_reply_to_status_id" : 279549042663518208,
  "created_at" : "2012-12-14 11:31:37 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279539878797123586",
  "text" : "\u00ABIch habe genug von eurem Monate andauernden Freeloading. Macht mir gef\u00E4lligst einen Erk\u00E4ltungstee, Katzen!\u00BB",
  "id" : 279539878797123586,
  "created_at" : "2012-12-14 10:54:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279532936955572224",
  "geo" : { },
  "id_str" : "279533098763431937",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ja",
  "id" : 279533098763431937,
  "in_reply_to_status_id" : 279532936955572224,
  "created_at" : "2012-12-14 10:27:38 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Sommer",
      "screen_name" : "tosopiratas",
      "indices" : [ 0, 12 ],
      "id_str" : "99694646",
      "id" : 99694646
    }, {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 13, 19 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279526639828885504",
  "geo" : { },
  "id_str" : "279529062513385472",
  "in_reply_to_user_id" : 99694646,
  "text" : "@tosopiratas @_Rya_ dann viel Spass damit. :)",
  "id" : 279529062513385472,
  "in_reply_to_status_id" : 279526639828885504,
  "created_at" : "2012-12-14 10:11:36 +0000",
  "in_reply_to_screen_name" : "tosopiratas",
  "in_reply_to_user_id_str" : "99694646",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 83, 92 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279526687950123008",
  "geo" : { },
  "id_str" : "279528636757995520",
  "in_reply_to_user_id" : 81582697,
  "text" : "@e_ramirez do you know a step counter\/QS tracker that syncs with Linux or Android? @viirus42 is looking &amp; doesn\u2019t use iOS\/Mac OS\/Windows.",
  "id" : 279528636757995520,
  "in_reply_to_status_id" : 279526687950123008,
  "created_at" : "2012-12-14 10:09:55 +0000",
  "in_reply_to_screen_name" : "viirus42",
  "in_reply_to_user_id_str" : "81582697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 0, 9 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279526687950123008",
  "geo" : { },
  "id_str" : "279528062490669056",
  "in_reply_to_user_id" : 81582697,
  "text" : "@viirus42 aktuell f\u00E4llt mir auch kein Device ein was mit Android und\/oder Linux gehen w\u00FCrde.",
  "id" : 279528062490669056,
  "in_reply_to_status_id" : 279526687950123008,
  "created_at" : "2012-12-14 10:07:38 +0000",
  "in_reply_to_screen_name" : "viirus42",
  "in_reply_to_user_id_str" : "81582697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 0, 9 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279525098887712768",
  "geo" : { },
  "id_str" : "279526344075931648",
  "in_reply_to_user_id" : 81582697,
  "text" : "@viirus42 nope, ich setze aus. Nach dem ganzen Konferenz-Zirkus den ich dieses Jahr schon hatte freue ich mich auf eine Woche Urlaub :)",
  "id" : 279526344075931648,
  "in_reply_to_status_id" : 279525098887712768,
  "created_at" : "2012-12-14 10:00:48 +0000",
  "in_reply_to_screen_name" : "viirus42",
  "in_reply_to_user_id_str" : "81582697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279525373442670593",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Mein \u00ABKann sich wenn n\u00F6tig in ~20 Sekunden komplett bekleiden\u00BB-Skill hat gerade daf\u00FCr gesorgt das dein Paket angekommen ist. :)",
  "id" : 279525373442670593,
  "created_at" : "2012-12-14 09:56:57 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viirus",
      "screen_name" : "viirus42",
      "indices" : [ 0, 9 ],
      "id_str" : "81582697",
      "id" : 81582697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279524249625038848",
  "geo" : { },
  "id_str" : "279524813406605313",
  "in_reply_to_user_id" : 81582697,
  "text" : "@viirus42 ich glaube nicht. Aber eine Android-App soll ja irgendwann(tm) kommen so weit ich wei\u00DF.",
  "id" : 279524813406605313,
  "in_reply_to_status_id" : 279524249625038848,
  "created_at" : "2012-12-14 09:54:43 +0000",
  "in_reply_to_screen_name" : "viirus42",
  "in_reply_to_user_id_str" : "81582697",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Torsten Sommer",
      "screen_name" : "tosopiratas",
      "indices" : [ 7, 19 ],
      "id_str" : "99694646",
      "id" : 99694646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/w2w7EEVk",
      "expanded_url" : "http:\/\/www.fitbit.com\/one",
      "display_url" : "fitbit.com\/one"
    } ]
  },
  "in_reply_to_status_id_str" : "279508605806465024",
  "geo" : { },
  "id_str" : "279523647868239872",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @tosopiratas den Vorg\u00E4nger von diesem: http:\/\/t.co\/w2w7EEVk",
  "id" : 279523647868239872,
  "in_reply_to_status_id" : 279508605806465024,
  "created_at" : "2012-12-14 09:50:05 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2766",
      "screen_name" : "daniel_bohrer",
      "indices" : [ 0, 14 ],
      "id_str" : "237942141",
      "id" : 237942141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279363228662906880",
  "geo" : { },
  "id_str" : "279363516274728960",
  "in_reply_to_user_id" : 237942141,
  "text" : "@daniel_bohrer Sehr sch\u00F6ner Verleser. (Wobei wer p-values ernst nimmt war vor kurzem recht sicher sehr nah am lokalen Opium) ;)",
  "id" : 279363516274728960,
  "in_reply_to_status_id" : 279363228662906880,
  "created_at" : "2012-12-13 23:13:47 +0000",
  "in_reply_to_screen_name" : "daniel_bohrer",
  "in_reply_to_user_id_str" : "237942141",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 10, 22 ],
      "id_str" : "14728378",
      "id" : 14728378
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 23, 33 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279360397331537922",
  "geo" : { },
  "id_str" : "279361056420294656",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @terrorzicke @Fischblog Ich bef\u00FCrchte nur das wird schon zur Massentierhaltung gez\u00E4hlt.",
  "id" : 279361056420294656,
  "in_reply_to_status_id" : 279360397331537922,
  "created_at" : "2012-12-13 23:04:00 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 23, 33 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279359964248682496",
  "geo" : { },
  "id_str" : "279360186722951168",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke @Senficon @Fischblog Ich will aber Waldorf UND Statler sein :)",
  "id" : 279360186722951168,
  "in_reply_to_status_id" : 279359964248682496,
  "created_at" : "2012-12-13 23:00:33 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 10, 20 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 21, 33 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279359753040310273",
  "geo" : { },
  "id_str" : "279359860037021699",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Fischblog @terrorzicke Vergiss nicht das Tiere jetzt schlecht sind, genauso wie Frauen. Oder so \u00E4hnlich.",
  "id" : 279359860037021699,
  "in_reply_to_status_id" : 279359753040310273,
  "created_at" : "2012-12-13 22:59:15 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 10, 20 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 21, 33 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279359388815339521",
  "geo" : { },
  "id_str" : "279359669653360640",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Fischblog @terrorzicke Was mich beruhigt: Offensichtlich sind wir doch nicht in der gleichen Zeitlinie gefangen!",
  "id" : 279359669653360640,
  "in_reply_to_status_id" : 279359388815339521,
  "created_at" : "2012-12-13 22:58:30 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 10, 20 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 21, 33 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279358131333636098",
  "geo" : { },
  "id_str" : "279358806197170177",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Fischblog @terrorzicke Entschuldige das manche ihren Glauben an die Fakten anpassen. Wir k\u00F6nnen nicht alle Piraten sein.",
  "id" : 279358806197170177,
  "in_reply_to_status_id" : 279358131333636098,
  "created_at" : "2012-12-13 22:55:04 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279358343997444103",
  "text" : "\u00ABIch habe ja nichts gegen Fis(c)her. Einige meiner besten Freunde sind welche.\u00BB",
  "id" : 279358343997444103,
  "created_at" : "2012-12-13 22:53:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 10, 20 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 21, 33 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279357319979085825",
  "geo" : { },
  "id_str" : "279357818295943169",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Fischblog @terrorzicke Wir bevorzugen K\u00E4mpfer des Lichts.",
  "id" : 279357818295943169,
  "in_reply_to_status_id" : 279357319979085825,
  "created_at" : "2012-12-13 22:51:08 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 10, 20 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 21, 33 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279356731195260928",
  "geo" : { },
  "id_str" : "279356859654234112",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Fischblog @terrorzicke Ich habe nicht nur alleinig recht. Anders als die Kirche kann ich meinen Standpunkt begr\u00FCnden!",
  "id" : 279356859654234112,
  "in_reply_to_status_id" : 279356731195260928,
  "created_at" : "2012-12-13 22:47:20 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279353894411309056",
  "text" : "Overly attached physics-girlfriend: \u00ABDas ist gut. Du bist n\u00E4mlich auch mit mir in dieser Zeitlinie gefangen!\u00BB",
  "id" : 279353894411309056,
  "created_at" : "2012-12-13 22:35:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 21, 33 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279352189833605120",
  "geo" : { },
  "id_str" : "279352681611554816",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog @Senficon @terrorzicke nur weil der Arme im Dienst der Kirche war muss man damit nicht die ganze Richtung verleumden. ;)",
  "id" : 279352681611554816,
  "in_reply_to_status_id" : 279352189833605120,
  "created_at" : "2012-12-13 22:30:44 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 51, 60 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279350738302431232",
  "geo" : { },
  "id_str" : "279352404103802881",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke nein nein, ich war romantisch, danach @Senficon hat Bayesian Statistics mit Religion verglichen und mich damit ver\u00E4rgert. ;)",
  "id" : 279352404103802881,
  "in_reply_to_status_id" : 279350738302431232,
  "created_at" : "2012-12-13 22:29:37 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/uzWcfGG1",
      "expanded_url" : "http:\/\/oikosjournal.wordpress.com\/2011\/10\/11\/frequentist-vs-bayesian-statistics-resources-to-help-you-choose\/",
      "display_url" : "oikosjournal.wordpress.com\/2011\/10\/11\/fre\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "279349973299122176",
  "geo" : { },
  "id_str" : "279350461599977473",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke @Senficon http:\/\/t.co\/uzWcfGG1 :)",
  "id" : 279350461599977473,
  "in_reply_to_status_id" : 279349973299122176,
  "created_at" : "2012-12-13 22:21:54 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 10, 22 ],
      "id_str" : "14728378",
      "id" : 14728378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279348901084008448",
  "geo" : { },
  "id_str" : "279349885810126848",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @terrorzicke du willst dich nur nach dem Bayes-Bashing wieder einschleimen!",
  "id" : 279349885810126848,
  "in_reply_to_status_id" : 279348901084008448,
  "created_at" : "2012-12-13 22:19:37 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279348310098190337",
  "text" : "\u00ABDu glaubst ja nicht an p-values. Sondern geh\u00F6rst dieser anderen Kirche an\u00BB \u2014 \u00ABDu entfernst dich langsam vom lokalen Optimum\u2026\u00BB",
  "id" : 279348310098190337,
  "created_at" : "2012-12-13 22:13:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279345866727387137",
  "text" : "\u00ABAlso wenn wir uns Frauen mal im hyperdimensionalen Raum vorstellen ist es unwahrscheinlich das ein gro\u00DFer Parametersprung optimiert\u00BB",
  "id" : 279345866727387137,
  "created_at" : "2012-12-13 22:03:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/uu11TfrC",
      "expanded_url" : "http:\/\/www.laphamsquarterly.org\/essays\/death-in-the-pot.php",
      "display_url" : "laphamsquarterly.org\/essays\/death-i\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279334091646705664",
  "text" : "Death in the Pot. Including stories on mad honey! http:\/\/t.co\/uu11TfrC",
  "id" : 279334091646705664,
  "created_at" : "2012-12-13 21:16:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/vl5hOnf3",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/artful-amoeba\/2012\/12\/13\/were-weirdo-ediacarans-really-lichens-fungi-and-slime-molds\/",
      "display_url" : "blogs.scientificamerican.com\/artful-amoeba\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279330955355906050",
  "text" : "Were Weirdo Ediacarans Really Lichens, Fungi, and Slime Molds? http:\/\/t.co\/vl5hOnf3",
  "id" : 279330955355906050,
  "created_at" : "2012-12-13 21:04:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/94puJiOJ",
      "expanded_url" : "http:\/\/www.explosm.net\/comics\/2987\/",
      "display_url" : "explosm.net\/comics\/2987\/"
    } ]
  },
  "geo" : { },
  "id_str" : "279321106106703872",
  "text" : "Luck of the Irish http:\/\/t.co\/94puJiOJ",
  "id" : 279321106106703872,
  "created_at" : "2012-12-13 20:25:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Roman Mars",
      "screen_name" : "romanmars",
      "indices" : [ 49, 59 ],
      "id_str" : "8198012",
      "id" : 8198012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279314020186607616",
  "geo" : { },
  "id_str" : "279314439289839616",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez I probably should have guessed it! :) @romanmars",
  "id" : 279314439289839616,
  "in_reply_to_status_id" : 279314020186607616,
  "created_at" : "2012-12-13 19:58:46 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 35, 45 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279313818390253569",
  "text" : "Having a closer look at the things @e_ramirez plays on Spotify already has been a great idea. Thanks!",
  "id" : 279313818390253569,
  "created_at" : "2012-12-13 19:56:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279312523986104320",
  "geo" : { },
  "id_str" : "279313091638988800",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj \u201CI can walk my Fuhrer!\u201D, do it! :)",
  "id" : 279313091638988800,
  "in_reply_to_status_id" : 279312523986104320,
  "created_at" : "2012-12-13 19:53:25 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/oPQHTOFO",
      "expanded_url" : "http:\/\/j.mp\/XXQluG",
      "display_url" : "j.mp\/XXQluG"
    } ]
  },
  "geo" : { },
  "id_str" : "279293742253486080",
  "text" : "Literacy privilege, or, why grammar nazis are dicks http:\/\/t.co\/oPQHTOFO",
  "id" : 279293742253486080,
  "created_at" : "2012-12-13 18:36:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/OIqoP0SL",
      "expanded_url" : "http:\/\/j.mp\/TQTRkk",
      "display_url" : "j.mp\/TQTRkk"
    } ]
  },
  "geo" : { },
  "id_str" : "279290862339506177",
  "text" : "\u00ABEscape to Alcatraz\u00BB, on the US prison system: \u00ABA start would be for us to recognize the hypocrisy of our own beliefs.\u00BB http:\/\/t.co\/OIqoP0SL",
  "id" : 279290862339506177,
  "created_at" : "2012-12-13 18:25:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279221953343135744",
  "text" : "Manchmal lachst du \u00FCber den off-by-one error. Und manchmal lacht der off-by-one error \u00FCber dich.",
  "id" : 279221953343135744,
  "created_at" : "2012-12-13 13:51:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279197347160932352",
  "geo" : { },
  "id_str" : "279198128396197888",
  "in_reply_to_user_id" : 1492631,
  "text" : "@lobot Wenn man sich die Hyphen der Pilze so anschaut passt das ja auch fast.",
  "id" : 279198128396197888,
  "in_reply_to_status_id" : 279197347160932352,
  "created_at" : "2012-12-13 12:16:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279195822476890112",
  "geo" : { },
  "id_str" : "279196064081391616",
  "in_reply_to_user_id" : 1492631,
  "text" : "@lobot Schlimmer, ich co-authore. Tats\u00E4chlich geht es aber um Pilz\u00F6kologie. :)",
  "id" : 279196064081391616,
  "in_reply_to_status_id" : 279195822476890112,
  "created_at" : "2012-12-13 12:08:23 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279181009453477889",
  "geo" : { },
  "id_str" : "279182690912202752",
  "in_reply_to_user_id" : 14861745,
  "text" : "@senficon \u00DCberrasch mich :D",
  "id" : 279182690912202752,
  "in_reply_to_status_id" : 279181009453477889,
  "created_at" : "2012-12-13 11:15:15 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279178913526210560",
  "geo" : { },
  "id_str" : "279179799870701568",
  "in_reply_to_user_id" : 14861745,
  "text" : "@senficon Kann man Wolle nicht auch splicen?",
  "id" : 279179799870701568,
  "in_reply_to_status_id" : 279178913526210560,
  "created_at" : "2012-12-13 11:03:45 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279178093934039040",
  "text" : "Habe mich relativ lang gefragte wieso man sein Paper in Verse aufteilt. Bis mir aufgegangen ist was mit \"manuskript_vers4\" gemeint ist...",
  "id" : 279178093934039040,
  "created_at" : "2012-12-13 10:56:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 3, 17 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279176595980300289",
  "text" : "RT @onetruecathal: Ireland: Europe's Silicon Valley of Calling-Yourself-The-Silicon-Valley-Of-Things",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/play.google.com\/store\/apps\/details?id=org.mariotaku.twidere\" rel=\"nofollow\"\u003ETwidere for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279176211983368192",
    "text" : "Ireland: Europe's Silicon Valley of Calling-Yourself-The-Silicon-Valley-Of-Things",
    "id" : 279176211983368192,
    "created_at" : "2012-12-13 10:49:30 +0000",
    "user" : {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "protected" : false,
      "id_str" : "16066596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673955584920563713\/KsGsM0A5_normal.jpg",
      "id" : 16066596,
      "verified" : false
    }
  },
  "id" : 279176595980300289,
  "created_at" : "2012-12-13 10:51:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/Qkbka144",
      "expanded_url" : "http:\/\/tinyurl.com\/cxttwov",
      "display_url" : "tinyurl.com\/cxttwov"
    } ]
  },
  "geo" : { },
  "id_str" : "279172075351048194",
  "text" : "DFG sanctions in misconduct case http:\/\/t.co\/Qkbka144",
  "id" : 279172075351048194,
  "created_at" : "2012-12-13 10:33:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/Ej05a6AW",
      "expanded_url" : "http:\/\/j.mp\/ST13xT",
      "display_url" : "j.mp\/ST13xT"
    } ]
  },
  "geo" : { },
  "id_str" : "279142167237255168",
  "text" : "Operation Delirium http:\/\/t.co\/Ej05a6AW",
  "id" : 279142167237255168,
  "created_at" : "2012-12-13 08:34:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279137648197640192",
  "text" : "\u00ABWie nennt man das noch gleich, wenn einem alles egal ist?\u00BB \u2014 \u00ABAlltag?\u00BB",
  "id" : 279137648197640192,
  "created_at" : "2012-12-13 08:16:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Millie Gibbs",
      "screen_name" : "Millie_Gibbs",
      "indices" : [ 3, 16 ],
      "id_str" : "177537105",
      "id" : 177537105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279002135339884545",
  "text" : "RT @Millie_Gibbs: CHURCH OF ENGLAND, YOU WERE INVENTED SPECIFICALLY FOR DIVORCE. ARE YOU REALLY GOING TO PLAY THE SANCTITY OF MARRIAGE C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278915653828743170",
    "text" : "CHURCH OF ENGLAND, YOU WERE INVENTED SPECIFICALLY FOR DIVORCE. ARE YOU REALLY GOING TO PLAY THE SANCTITY OF MARRIAGE CARD? REALLY?",
    "id" : 278915653828743170,
    "created_at" : "2012-12-12 17:34:08 +0000",
    "user" : {
      "name" : "Millie Gibbs",
      "screen_name" : "Millie_Gibbs",
      "protected" : false,
      "id_str" : "177537105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874659684959092736\/gaHl2WuS_normal.jpg",
      "id" : 177537105,
      "verified" : false
    }
  },
  "id" : 279002135339884545,
  "created_at" : "2012-12-12 23:17:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278998320129642496",
  "text" : "Oh, du kannst ja das Katzenspielzeug besser fangen als die Katze!\u00BB \u2014 \u00ABIch habe ja auch DAUMEN!\u00BB",
  "id" : 278998320129642496,
  "created_at" : "2012-12-12 23:02:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/Deyg8VtF",
      "expanded_url" : "http:\/\/j.mp\/TPDy7A",
      "display_url" : "j.mp\/TPDy7A"
    } ]
  },
  "geo" : { },
  "id_str" : "278997037582802944",
  "text" : "We\u2019re All (Flawed) Mutants http:\/\/t.co\/Deyg8VtF",
  "id" : 278997037582802944,
  "created_at" : "2012-12-12 22:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278994594182606848",
  "geo" : { },
  "id_str" : "278994933984153602",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj die arctic rhesus monkeys k\u00F6nnen bestimmt im Takt zittern (und dabei eventuell die Drums treffen)",
  "id" : 278994933984153602,
  "in_reply_to_status_id" : 278994594182606848,
  "created_at" : "2012-12-12 22:49:10 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/i7MxyrqB",
      "expanded_url" : "http:\/\/j.mp\/128UtZ6",
      "display_url" : "j.mp\/128UtZ6"
    } ]
  },
  "geo" : { },
  "id_str" : "278993771608297472",
  "text" : "Can rhesus monkeys detect the beat in music? Nope, probably not http:\/\/t.co\/i7MxyrqB",
  "id" : 278993771608297472,
  "created_at" : "2012-12-12 22:44:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "indices" : [ 3, 11 ],
      "id_str" : "15890805",
      "id" : 15890805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/yPHMSS8Q",
      "expanded_url" : "http:\/\/i.imgur.com\/W0mfh.jpg",
      "display_url" : "i.imgur.com\/W0mfh.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "278984907202650112",
  "text" : "RT @ekelias: http:\/\/t.co\/yPHMSS8Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/yPHMSS8Q",
        "expanded_url" : "http:\/\/i.imgur.com\/W0mfh.jpg",
        "display_url" : "i.imgur.com\/W0mfh.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "278984327956668416",
    "text" : "http:\/\/t.co\/yPHMSS8Q",
    "id" : 278984327956668416,
    "created_at" : "2012-12-12 22:07:01 +0000",
    "user" : {
      "name" : "gegengewalt",
      "screen_name" : "ekelias",
      "protected" : false,
      "id_str" : "15890805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925606337463177216\/wj55pFBP_normal.jpg",
      "id" : 15890805,
      "verified" : false
    }
  },
  "id" : 278984907202650112,
  "created_at" : "2012-12-12 22:09:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/U4QLMYqD",
      "expanded_url" : "http:\/\/www.theverge.com\/2012\/12\/12\/3759198\/23andme-genetics-testing-50-million-data-mining",
      "display_url" : "theverge.com\/2012\/12\/12\/375\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278971318509109248",
  "text" : "RT @wilbanks: Nice article on the 23andme financing. Includes cranky quotes from me.\nhttp:\/\/t.co\/U4QLMYqD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/U4QLMYqD",
        "expanded_url" : "http:\/\/www.theverge.com\/2012\/12\/12\/3759198\/23andme-genetics-testing-50-million-data-mining",
        "display_url" : "theverge.com\/2012\/12\/12\/375\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "278969953774882816",
    "text" : "Nice article on the 23andme financing. Includes cranky quotes from me.\nhttp:\/\/t.co\/U4QLMYqD",
    "id" : 278969953774882816,
    "created_at" : "2012-12-12 21:09:54 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 278971318509109248,
  "created_at" : "2012-12-12 21:15:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 48, 56 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278966570124980225",
  "text" : "Steige jetzt mit den Anatomischen Anekdoten von @h_wicht ins Bett.",
  "id" : 278966570124980225,
  "created_at" : "2012-12-12 20:56:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278958611269562368",
  "text" : "Hals- und Glied(er)schmerzen",
  "id" : 278958611269562368,
  "created_at" : "2012-12-12 20:24:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278957142726303744",
  "geo" : { },
  "id_str" : "278957624035246082",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ich vermute auch der Strassendealer von heute wei\u00DF um Ergonomie am Arbeitsplatz.",
  "id" : 278957624035246082,
  "in_reply_to_status_id" : 278957142726303744,
  "created_at" : "2012-12-12 20:20:55 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/NFqlhoKs",
      "expanded_url" : "http:\/\/instagr.am\/p\/TJkxXjhwno\/",
      "display_url" : "instagr.am\/p\/TJkxXjhwno\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094076368, 8.2804512978 ]
  },
  "id_str" : "278957036526530561",
  "text" : "Office, Kastel-Style @ Br\u00FCckenkopf Kastel Graffiti Hall Of Fame http:\/\/t.co\/NFqlhoKs",
  "id" : 278957036526530561,
  "created_at" : "2012-12-12 20:18:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dexter",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278951228698927104",
  "text" : "The authors probably call it \u2018character development\u2019. I call it \u2018getting stupid\u2019. #dexter",
  "id" : 278951228698927104,
  "created_at" : "2012-12-12 19:55:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278948567547277312",
  "geo" : { },
  "id_str" : "278949489430102017",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai du meinst ob ich Wein trinke oder nicht? ;)",
  "id" : 278949489430102017,
  "in_reply_to_status_id" : 278948567547277312,
  "created_at" : "2012-12-12 19:48:35 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278947964406358016",
  "geo" : { },
  "id_str" : "278948297354391552",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai ich wollte es beim Kater machen. Nicht bei mir! :P",
  "id" : 278948297354391552,
  "in_reply_to_status_id" : 278947964406358016,
  "created_at" : "2012-12-12 19:43:51 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278947437043916800",
  "geo" : { },
  "id_str" : "278947560268382208",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai also mal wieder Ether besorgen. ;)",
  "id" : 278947560268382208,
  "in_reply_to_status_id" : 278947437043916800,
  "created_at" : "2012-12-12 19:40:55 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278946445216849920",
  "geo" : { },
  "id_str" : "278946919378743296",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai irgendwelche Tipps? ;)",
  "id" : 278946919378743296,
  "in_reply_to_status_id" : 278946445216849920,
  "created_at" : "2012-12-12 19:38:22 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278945954873360385",
  "text" : "\u00ABDer Kater braucht eine neue Freundin. Er liegt immer auf mir rum wenn ich Zuhause bin.\u00BB \u2014 \u00ABBis dahin kannst du ihn ja Elektro-Absamen.\u00BB",
  "id" : 278945954873360385,
  "created_at" : "2012-12-12 19:34:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 6, 18 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/41rYFYLB",
      "expanded_url" : "http:\/\/jonfwilkins.blogspot.de\/2012\/12\/having-your-awesomest-grad-school.html",
      "display_url" : "jonfwilkins.blogspot.de\/2012\/12\/having\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278933915828371456",
  "text" : "Nice, @jonfwilkins has advice on spending time in grad school. Great to see \u00ABDon't Learn a Skill\u00BB &amp; \u00ABAsk Questions\u00BB http:\/\/t.co\/41rYFYLB",
  "id" : 278933915828371456,
  "created_at" : "2012-12-12 18:46:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278903492469456896",
  "text" : "\u00ABIch bin an deinem n\u00E4chsten Geburtstag Zuhause. Daf\u00FCr h\u00F6rst du bis dahin auf nautische Metaphern zu verwenden. Deal?\u00BB\u2014\u00ABBeim Klabautermann!\u00BB",
  "id" : 278903492469456896,
  "created_at" : "2012-12-12 16:45:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/ijrxIXNx",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=2821#comic",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.000735, 8.262513 ]
  },
  "id_str" : "278870428502609920",
  "text" : "I'm pretty sure that there's a cheap dry\/wet lab joke in here as well.  http:\/\/t.co\/ijrxIXNx",
  "id" : 278870428502609920,
  "created_at" : "2012-12-12 14:34:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 3, 19 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278866140262965248",
  "text" : "RT @pathogenomenick: &gt;1PB of data in NCBI SRA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278862914289537025",
    "text" : "&gt;1PB of data in NCBI SRA",
    "id" : 278862914289537025,
    "created_at" : "2012-12-12 14:04:34 +0000",
    "user" : {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "protected" : false,
      "id_str" : "85906238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654948428951195648\/i5lt2BWa_normal.jpg",
      "id" : 85906238,
      "verified" : false
    }
  },
  "id" : 278866140262965248,
  "created_at" : "2012-12-12 14:17:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/wOAaZaYj",
      "expanded_url" : "http:\/\/www.vanityfair.com\/hollywood",
      "display_url" : "vanityfair.com\/hollywood"
    } ]
  },
  "geo" : { },
  "id_str" : "278865861341769728",
  "text" : "\u00ABHow would you like to die?\u00BB \u2014 \u00ABHandcuffing myself to you and jumping into a cauldron of molten bronze.\u00BB http:\/\/t.co\/wOAaZaYj",
  "id" : 278865861341769728,
  "created_at" : "2012-12-12 14:16:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/dzAJ4fMA",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/dmWGz2y9Jvc\/kinky-gifts-from-science-surpl.html",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0679457446, 8.5405109163 ]
  },
  "id_str" : "278862628858757120",
  "text" : "Kinky gifts from science surplus http:\/\/t.co\/dzAJ4fMA",
  "id" : 278862628858757120,
  "created_at" : "2012-12-12 14:03:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/VGjBMHo4",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/notrocketscience\/2012\/12\/11\/why-porcupine-quills-slide-in-with-ease-but-come-out-with-difficulty\/",
      "display_url" : "blogs.discovermagazine.com\/notrocketscien\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278859699749801984",
  "text" : "Why porcupine quills slide in with ease but come out with difficulty http:\/\/t.co\/VGjBMHo4",
  "id" : 278859699749801984,
  "created_at" : "2012-12-12 13:51:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278811659370393601",
  "geo" : { },
  "id_str" : "278857282253623296",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall nope, weder noch (kann mich zumindest nicht erinnern das du mal gefragt hast). Nutze nur MacPorts.",
  "id" : 278857282253623296,
  "in_reply_to_status_id" : 278811659370393601,
  "created_at" : "2012-12-12 13:42:11 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/yQrNEc4C",
      "expanded_url" : "http:\/\/mail.scipy.org\/pipermail\/ipython-dev\/2012-December\/010799.html",
      "display_url" : "mail.scipy.org\/pipermail\/ipyt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278803377075412992",
  "text" : "RT @PhilippBayer: IPython gets a $1.15M grant from the Alfred P. Sloan foundation :O http:\/\/t.co\/yQrNEc4C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/yQrNEc4C",
        "expanded_url" : "http:\/\/mail.scipy.org\/pipermail\/ipython-dev\/2012-December\/010799.html",
        "display_url" : "mail.scipy.org\/pipermail\/ipyt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "278785602621681664",
    "text" : "IPython gets a $1.15M grant from the Alfred P. Sloan foundation :O http:\/\/t.co\/yQrNEc4C",
    "id" : 278785602621681664,
    "created_at" : "2012-12-12 08:57:21 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 278803377075412992,
  "created_at" : "2012-12-12 10:07:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278502872046510080",
  "geo" : { },
  "id_str" : "278503486801457154",
  "in_reply_to_user_id" : 1492631,
  "text" : "@lobot jedi mind tricks!",
  "id" : 278503486801457154,
  "in_reply_to_status_id" : 278502872046510080,
  "created_at" : "2012-12-11 14:16:20 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278495778878660608",
  "geo" : { },
  "id_str" : "278497341575684096",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma Ich hab es einmal versucht und dann entschieden \"naja, es l\u00E4uft ja unter 2.x. Und so wichtig sind updates ja auch nicht\" :D",
  "id" : 278497341575684096,
  "in_reply_to_status_id" : 278495778878660608,
  "created_at" : "2012-12-11 13:51:55 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278495166812262400",
  "text" : "\"I want to upgrade from Rails 2.x to 3.x. What can I do?\" - \"Abandon all hope?\"",
  "id" : 278495166812262400,
  "created_at" : "2012-12-11 13:43:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/P543lnSZ",
      "expanded_url" : "http:\/\/icgc.org\/",
      "display_url" : "icgc.org"
    } ]
  },
  "in_reply_to_status_id_str" : "278480976324210688",
  "geo" : { },
  "id_str" : "278482187706302464",
  "in_reply_to_user_id" : 31104704,
  "text" : "@caevye bzw. es gibt noch das International Cancer Genome Consortium was staatenweise arbeitet: http:\/\/t.co\/P543lnSZ",
  "id" : 278482187706302464,
  "in_reply_to_status_id" : 278480976324210688,
  "created_at" : "2012-12-11 12:51:42 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 0, 7 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278480976324210688",
  "geo" : { },
  "id_str" : "278481765306335234",
  "in_reply_to_user_id" : 31104704,
  "text" : "@caevye Nein, mir sind nur die beiden bekannt. Allerdings bin ich da auch nicht so tief im Thema.",
  "id" : 278481765306335234,
  "in_reply_to_status_id" : 278480976324210688,
  "created_at" : "2012-12-11 12:50:01 +0000",
  "in_reply_to_screen_name" : "CaeVye",
  "in_reply_to_user_id_str" : "31104704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278480236830679041",
  "geo" : { },
  "id_str" : "278480774901161985",
  "in_reply_to_user_id" : 1492631,
  "text" : "@lobot Twitter generell l\u00E4sst sich von Mail anhand von Dauer &amp; Intensit\u00E4t unterscheiden.",
  "id" : 278480774901161985,
  "in_reply_to_status_id" : 278480236830679041,
  "created_at" : "2012-12-11 12:46:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "indices" : [ 33, 44 ],
      "id_str" : "4339911",
      "id" : 4339911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/ncV8iDNE",
      "expanded_url" : "http:\/\/apijoy.tumblr.com\/post\/37704147784\/soap-xml-3",
      "display_url" : "apijoy.tumblr.com\/post\/377041477\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278480460982665217",
  "text" : "SOAP\/XML (In my mind this is how @IanMulvany reacts every time he has to deal with it) http:\/\/t.co\/ncV8iDNE",
  "id" : 278480460982665217,
  "created_at" : "2012-12-11 12:44:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278478770707517440",
  "text" : "Neuer Skill: Am flackern des Monitors erkennen k\u00F6nnen ob man gleich eine DM oder eine Mail auf sein Telefon gepusht bekommt.",
  "id" : 278478770707517440,
  "created_at" : "2012-12-11 12:38:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/dKCjGAFd",
      "expanded_url" : "http:\/\/xkcd.com\/460\/",
      "display_url" : "xkcd.com\/460\/"
    } ]
  },
  "geo" : { },
  "id_str" : "278471731209973760",
  "text" : "Hipster Paleontology http:\/\/t.co\/dKCjGAFd",
  "id" : 278471731209973760,
  "created_at" : "2012-12-11 12:10:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/z2FUW6L0",
      "expanded_url" : "http:\/\/i.imgur.com\/oYi7x.jpg",
      "display_url" : "i.imgur.com\/oYi7x.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "278454149463564288",
  "text" : "Deadlock http:\/\/t.co\/z2FUW6L0",
  "id" : 278454149463564288,
  "created_at" : "2012-12-11 11:00:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/5KgeuBuM",
      "expanded_url" : "http:\/\/blogs.discovermagazine.com\/discoblog\/?p=23481",
      "display_url" : "blogs.discovermagazine.com\/discoblog\/?p=2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278451879380402176",
  "text" : "RT @edyong209: I see. A study on the effect of Batman on a man's body image http:\/\/t.co\/5KgeuBuM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/5KgeuBuM",
        "expanded_url" : "http:\/\/blogs.discovermagazine.com\/discoblog\/?p=23481",
        "display_url" : "blogs.discovermagazine.com\/discoblog\/?p=2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "278450841143369729",
    "text" : "I see. A study on the effect of Batman on a man's body image http:\/\/t.co\/5KgeuBuM",
    "id" : 278450841143369729,
    "created_at" : "2012-12-11 10:47:08 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 278451879380402176,
  "created_at" : "2012-12-11 10:51:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278444660207267840",
  "geo" : { },
  "id_str" : "278446226607837185",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot nurturing the science of cell nature. ;)",
  "id" : 278446226607837185,
  "in_reply_to_status_id" : 278444660207267840,
  "created_at" : "2012-12-11 10:28:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 50, 58 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/hmYzDWfR",
      "expanded_url" : "http:\/\/tinyurl.com\/a7dj462",
      "display_url" : "tinyurl.com\/a7dj462"
    } ]
  },
  "geo" : { },
  "id_str" : "278445200349728768",
  "text" : "\"Hoschemaa, des hawwe mer awwer gut gemacht.\" Der @h_wicht \u00FCber den Herrn Haberl http:\/\/t.co\/hmYzDWfR",
  "id" : 278445200349728768,
  "created_at" : "2012-12-11 10:24:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/k1mUf63I",
      "expanded_url" : "http:\/\/tinyurl.com\/9ww6tls",
      "display_url" : "tinyurl.com\/9ww6tls"
    } ]
  },
  "geo" : { },
  "id_str" : "278440918154092544",
  "text" : "Genes &amp; Personality: There's no easy answer http:\/\/t.co\/k1mUf63I",
  "id" : 278440918154092544,
  "created_at" : "2012-12-11 10:07:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/FB3lFgNO",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_m6eo4aB08b1r6wav2o1_500.jpg",
      "display_url" : "25.media.tumblr.com\/tumblr_m6eo4aB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278422677125988352",
  "text" : "PI Platypus http:\/\/t.co\/FB3lFgNO",
  "id" : 278422677125988352,
  "created_at" : "2012-12-11 08:55:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/joF4G0Gh",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=906",
      "display_url" : "asofterworld.com\/index.php?id=9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278420444896444416",
  "text" : "Define: Slut http:\/\/t.co\/joF4G0Gh",
  "id" : 278420444896444416,
  "created_at" : "2012-12-11 08:46:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278416952911859712",
  "text" : "Das allmorgendliche Mantra: \u00ABNicht \u00FCber die Bahn aufregen. Komplexe Netzwerke sind ein hartes Problem\u2026\u00BB",
  "id" : 278416952911859712,
  "created_at" : "2012-12-11 08:32:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278414763472584704",
  "text" : "\u00ABIch will keinen Politiker. Die sind korrupt und unsexy.\u00BB \u2014 \u00ABWolltest du nicht Politikerin werden?\u00BB \u2014 \u00ABIch bin immerhin nicht korrupt!\u00BB",
  "id" : 278414763472584704,
  "created_at" : "2012-12-11 08:23:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura C. Lorenzana",
      "screen_name" : "ArchivalBiz",
      "indices" : [ 3, 15 ],
      "id_str" : "241641876",
      "id" : 241641876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "German",
      "indices" : [ 61, 68 ]
    }, {
      "text" : "POWs",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "WWII",
      "indices" : [ 80, 85 ]
    }, {
      "text" : "army",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278292177707208704",
  "text" : "RT @ArchivalBiz: Wondering if there is a resource for either #German #POWs from #WWII or German #army records available? I can do Deutsc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "German",
        "indices" : [ 44, 51 ]
      }, {
        "text" : "POWs",
        "indices" : [ 52, 57 ]
      }, {
        "text" : "WWII",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "army",
        "indices" : [ 79, 84 ]
      }, {
        "text" : "genealogy",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278291864455622656",
    "text" : "Wondering if there is a resource for either #German #POWs from #WWII or German #army records available? I can do Deutsche ;-) #genealogy",
    "id" : 278291864455622656,
    "created_at" : "2012-12-11 00:15:25 +0000",
    "user" : {
      "name" : "Laura C. Lorenzana",
      "screen_name" : "ArchivalBiz",
      "protected" : false,
      "id_str" : "241641876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744137277840883713\/9fPzwmxa_normal.jpg",
      "id" : 241641876,
      "verified" : false
    }
  },
  "id" : 278292177707208704,
  "created_at" : "2012-12-11 00:16:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278290957445783555",
  "geo" : { },
  "id_str" : "278291467502514177",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks ah, too bad. Well, maybe next time :)",
  "id" : 278291467502514177,
  "in_reply_to_status_id" : 278290957445783555,
  "created_at" : "2012-12-11 00:13:50 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278289499778347008",
  "geo" : { },
  "id_str" : "278290605258457088",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks can\u2019t make it. Any chance that you visit Germany? :)",
  "id" : 278290605258457088,
  "in_reply_to_status_id" : 278289499778347008,
  "created_at" : "2012-12-11 00:10:25 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason G. Goldman",
      "screen_name" : "jgold85",
      "indices" : [ 3, 11 ],
      "id_str" : "118975084",
      "id" : 118975084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LWON",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/Q0SXYTyA",
      "expanded_url" : "http:\/\/bit.ly\/VvO6sq",
      "display_url" : "bit.ly\/VvO6sq"
    } ]
  },
  "geo" : { },
  "id_str" : "278280273005780992",
  "text" : "RT @jgold85: Guest Post: The Wine Grapes of Westeros http:\/\/t.co\/Q0SXYTyA fantastically pedantic guest post at #LWON by @seanwtracey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LWON",
        "indices" : [ 98, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/Q0SXYTyA",
        "expanded_url" : "http:\/\/bit.ly\/VvO6sq",
        "display_url" : "bit.ly\/VvO6sq"
      } ]
    },
    "geo" : { },
    "id_str" : "278279025443622913",
    "text" : "Guest Post: The Wine Grapes of Westeros http:\/\/t.co\/Q0SXYTyA fantastically pedantic guest post at #LWON by @seanwtracey",
    "id" : 278279025443622913,
    "created_at" : "2012-12-10 23:24:24 +0000",
    "user" : {
      "name" : "Jason G. Goldman",
      "screen_name" : "jgold85",
      "protected" : false,
      "id_str" : "118975084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676897926065598466\/Y-KCceMv_normal.jpg",
      "id" : 118975084,
      "verified" : true
    }
  },
  "id" : 278280273005780992,
  "created_at" : "2012-12-10 23:29:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/i8wI46fa",
      "expanded_url" : "http:\/\/j.mp\/T2lEQb",
      "display_url" : "j.mp\/T2lEQb"
    } ]
  },
  "geo" : { },
  "id_str" : "278270707916472320",
  "text" : "Historic explosions recreated in cauliflower http:\/\/t.co\/i8wI46fa",
  "id" : 278270707916472320,
  "created_at" : "2012-12-10 22:51:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/Wll5VkPl",
      "expanded_url" : "http:\/\/amzn.com\/k\/hi_Lm7O1QjqHVlr9uE0Lxw",
      "display_url" : "amzn.com\/k\/hi_Lm7O1QjqH\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278266362797895680",
  "text" : "The limits of our reason http:\/\/t.co\/Wll5VkPl And so, whether George killed himself because of illness, unrequited love, confusion,...",
  "id" : 278266362797895680,
  "created_at" : "2012-12-10 22:34:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278264367890436099",
  "text" : "\u00ABThe last letters from him spoke of wanting to make love in threesomes, and of Jesus[\u2026]\u00BB",
  "id" : 278264367890436099,
  "created_at" : "2012-12-10 22:26:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/y6fDos5M",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/life-unbounded\/2012\/12\/10\/the-calculus-of-love\/",
      "display_url" : "blogs.scientificamerican.com\/life-unbounded\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278250483246825472",
  "text" : "The Calculus of Love http:\/\/t.co\/y6fDos5M",
  "id" : 278250483246825472,
  "created_at" : "2012-12-10 21:30:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/yunBuM5N",
      "expanded_url" : "http:\/\/www.wired.com\/wiredscience\/2012\/12\/birds-of-paradise\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+wired%2Findex+%28Wired%3A+Top+Stories%29&pid=5632",
      "display_url" : "wired.com\/wiredscience\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278245086930821120",
  "text" : "Birds-of-Paradise Soft Porn http:\/\/t.co\/yunBuM5N",
  "id" : 278245086930821120,
  "created_at" : "2012-12-10 21:09:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joerg Roehlig",
      "screen_name" : "JoergR",
      "indices" : [ 0, 7 ],
      "id_str" : "774628164177985537",
      "id" : 774628164177985537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278241823007334401",
  "text" : "@JoergR Keeping my sanity. That\u2019s the reason why I don\u2019t turn them :D",
  "id" : 278241823007334401,
  "created_at" : "2012-12-10 20:56:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/fbdj5gmA",
      "expanded_url" : "http:\/\/instagr.am\/p\/TEa4OnBwkk\/",
      "display_url" : "instagr.am\/p\/TEa4OnBwkk\/"
    } ]
  },
  "geo" : { },
  "id_str" : "278231744703000576",
  "text" : "\u00ABIch glaube wir brauchen einen Blood Spatter Analyst der auf Katzen spezialisiert ist\u00BB http:\/\/t.co\/fbdj5gmA",
  "id" : 278231744703000576,
  "created_at" : "2012-12-10 20:16:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278222593155293184",
  "text" : "\u00ABStrickst du da eine Katzenzwangsjacke?\u00BB",
  "id" : 278222593155293184,
  "created_at" : "2012-12-10 19:40:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr24hours",
      "screen_name" : "Dr24hours",
      "indices" : [ 3, 13 ],
      "id_str" : "260886966",
      "id" : 260886966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278215578718711809",
  "text" : "RT @Dr24hours: There needs to be an ecology journal called \"Nurture\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278212363633713152",
    "text" : "There needs to be an ecology journal called \"Nurture\".",
    "id" : 278212363633713152,
    "created_at" : "2012-12-10 18:59:31 +0000",
    "user" : {
      "name" : "Dr24hours",
      "screen_name" : "Dr24hours",
      "protected" : false,
      "id_str" : "260886966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793809040971296768\/-gj8sI1w_normal.jpg",
      "id" : 260886966,
      "verified" : false
    }
  },
  "id" : 278215578718711809,
  "created_at" : "2012-12-10 19:12:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278209936268357632",
  "text" : "\u00ABScratch an \u2018altruist\u2019 and watch a \u2018hypocrite\u2019 bleed\u00BB \u2014 Michael Ghiselin",
  "id" : 278209936268357632,
  "created_at" : "2012-12-10 18:49:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobias Wolter",
      "screen_name" : "towo",
      "indices" : [ 0, 5 ],
      "id_str" : "14095571",
      "id" : 14095571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278152138847313920",
  "geo" : { },
  "id_str" : "278152949644013568",
  "in_reply_to_user_id" : 14095571,
  "text" : "@towo I for one welcome our new meta-human overlords!",
  "id" : 278152949644013568,
  "in_reply_to_status_id" : 278152138847313920,
  "created_at" : "2012-12-10 15:03:25 +0000",
  "in_reply_to_screen_name" : "towo",
  "in_reply_to_user_id_str" : "14095571",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278152582344634369",
  "geo" : { },
  "id_str" : "278152825442287616",
  "in_reply_to_user_id" : 44625441,
  "text" : "@tuxwurf aber so wahr :D",
  "id" : 278152825442287616,
  "in_reply_to_status_id" : 278152582344634369,
  "created_at" : "2012-12-10 15:02:56 +0000",
  "in_reply_to_screen_name" : "juriroemer",
  "in_reply_to_user_id_str" : "44625441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/rqNqGr5j",
      "expanded_url" : "http:\/\/instagr.am\/p\/TD2MApBwrW\/",
      "display_url" : "instagr.am\/p\/TD2MApBwrW\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1151020599, 8.6716675758 ]
  },
  "id_str" : "278150834896896000",
  "text" : "B\u00E4llebad @ Opernplatz http:\/\/t.co\/rqNqGr5j",
  "id" : 278150834896896000,
  "created_at" : "2012-12-10 14:55:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Erik J. Cox",
      "screen_name" : "ErikJCox",
      "indices" : [ 0, 9 ],
      "id_str" : "33462874",
      "id" : 33462874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278141778949976065",
  "geo" : { },
  "id_str" : "278144184702095360",
  "in_reply_to_user_id" : 33462874,
  "text" : "@erikjcox We're getting there. But thanks to the lack of domain knowledge those people have in biotech etc. it might take a while ;)",
  "id" : 278144184702095360,
  "in_reply_to_status_id" : 278141778949976065,
  "created_at" : "2012-12-10 14:28:35 +0000",
  "in_reply_to_screen_name" : "ErikJCox",
  "in_reply_to_user_id_str" : "33462874",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "retrolove",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/YndHZ3Y2",
      "expanded_url" : "http:\/\/ascii.textfiles.com\/archives\/3786",
      "display_url" : "ascii.textfiles.com\/archives\/3786"
    } ]
  },
  "geo" : { },
  "id_str" : "278143990296096768",
  "text" : "Emulating CRTs: What a Wonder is a Terrible Monitor #retrolove http:\/\/t.co\/YndHZ3Y2",
  "id" : 278143990296096768,
  "created_at" : "2012-12-10 14:27:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/QTjaCwe1",
      "expanded_url" : "http:\/\/tinyurl.com\/c7djel7",
      "display_url" : "tinyurl.com\/c7djel7"
    } ]
  },
  "geo" : { },
  "id_str" : "278141225759014912",
  "text" : "Do you want to live in a world run by messianic geeks (with apparently zero domain knowledge) with robot limbs? http:\/\/t.co\/QTjaCwe1",
  "id" : 278141225759014912,
  "created_at" : "2012-12-10 14:16:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/qD3BJbb7",
      "expanded_url" : "http:\/\/tinyurl.com\/bp6vcsc",
      "display_url" : "tinyurl.com\/bp6vcsc"
    } ]
  },
  "geo" : { },
  "id_str" : "278140333148233728",
  "text" : "Do music and language share the same resources? http:\/\/t.co\/qD3BJbb7",
  "id" : 278140333148233728,
  "created_at" : "2012-12-10 14:13:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/VLPPzyHY",
      "expanded_url" : "http:\/\/tinyurl.com\/bpyjveo",
      "display_url" : "tinyurl.com\/bpyjveo"
    } ]
  },
  "geo" : { },
  "id_str" : "278133071201570817",
  "text" : "When push comes to nudge \u2013 playing on behaviours to generate healthy action http:\/\/t.co\/VLPPzyHY",
  "id" : 278133071201570817,
  "created_at" : "2012-12-10 13:44:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Fong",
      "screen_name" : "Kevin_Fong",
      "indices" : [ 3, 14 ],
      "id_str" : "90146016",
      "id" : 90146016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WTHack",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/7q0YMvrA",
      "expanded_url" : "http:\/\/hacks.rewiredstate.org\/events\/wthack-2012\/",
      "display_url" : "hacks.rewiredstate.org\/events\/wthack-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "278126644491874304",
  "text" : "RT @Kevin_Fong: What our Open Science Hack Weekend produced: http:\/\/t.co\/7q0YMvrA Massive round of applause to all involved  #WTHack",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WTHack",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/7q0YMvrA",
        "expanded_url" : "http:\/\/hacks.rewiredstate.org\/events\/wthack-2012\/",
        "display_url" : "hacks.rewiredstate.org\/events\/wthack-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "278118681693806592",
    "text" : "What our Open Science Hack Weekend produced: http:\/\/t.co\/7q0YMvrA Massive round of applause to all involved  #WTHack",
    "id" : 278118681693806592,
    "created_at" : "2012-12-10 12:47:15 +0000",
    "user" : {
      "name" : "Kevin Fong",
      "screen_name" : "Kevin_Fong",
      "protected" : false,
      "id_str" : "90146016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671702653844484096\/eKKJY8Jy_normal.jpg",
      "id" : 90146016,
      "verified" : false
    }
  },
  "id" : 278126644491874304,
  "created_at" : "2012-12-10 13:18:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Evelo",
      "screen_name" : "Chris_Evelo",
      "indices" : [ 0, 12 ],
      "id_str" : "89169314",
      "id" : 89169314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278125710080626688",
  "geo" : { },
  "id_str" : "278126561918595072",
  "in_reply_to_user_id" : 89169314,
  "text" : "@Chris_Evelo the best thing to battle non-standard file formats.",
  "id" : 278126561918595072,
  "in_reply_to_status_id" : 278125710080626688,
  "created_at" : "2012-12-10 13:18:34 +0000",
  "in_reply_to_screen_name" : "Chris_Evelo",
  "in_reply_to_user_id_str" : "89169314",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278125367049461762",
  "text" : "\u00ABUnd was hast du den ganzen Tag lang so getrieben?\u00BB \u2013 \u00ABgrep, sed, awk. Bioinformatik halt\u00BB",
  "id" : 278125367049461762,
  "created_at" : "2012-12-10 13:13:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278095982368014337",
  "geo" : { },
  "id_str" : "278098571776106497",
  "in_reply_to_user_id" : 121777206,
  "text" : "@philippbayer But nice work so far! Will try to test-drive it later today.",
  "id" : 278098571776106497,
  "in_reply_to_status_id" : 278095982368014337,
  "created_at" : "2012-12-10 11:27:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 3, 13 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/yokofakun\/status\/278086490809040896\/photo\/1",
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/8ZQ6G37I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9v2MKXCAAA8hmJ.jpg",
      "id_str" : "278086490813235200",
      "id" : 278086490813235200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9v2MKXCAAA8hmJ.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/8ZQ6G37I"
    } ],
    "hashtags" : [ {
      "text" : "gephi",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278086953134604288",
  "text" : "RT @yokofakun: My NGS workflow (16 exomes) visualized in #gephi. http:\/\/t.co\/8ZQ6G37I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/yokofakun\/status\/278086490809040896\/photo\/1",
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/8ZQ6G37I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A9v2MKXCAAA8hmJ.jpg",
        "id_str" : "278086490813235200",
        "id" : 278086490813235200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9v2MKXCAAA8hmJ.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/8ZQ6G37I"
      } ],
      "hashtags" : [ {
        "text" : "gephi",
        "indices" : [ 42, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278086490809040896",
    "text" : "My NGS workflow (16 exomes) visualized in #gephi. http:\/\/t.co\/8ZQ6G37I",
    "id" : 278086490809040896,
    "created_at" : "2012-12-10 10:39:21 +0000",
    "user" : {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "protected" : false,
      "id_str" : "7431072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667105051664609280\/jQ6Ile6W_normal.jpg",
      "id" : 7431072,
      "verified" : false
    }
  },
  "id" : 278086953134604288,
  "created_at" : "2012-12-10 10:41:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Lombra\u00F1a",
      "screen_name" : "teleyinex",
      "indices" : [ 0, 10 ],
      "id_str" : "114682872",
      "id" : 114682872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278061824665063424",
  "geo" : { },
  "id_str" : "278064275745026048",
  "in_reply_to_user_id" : 114682872,
  "text" : "@teleyinex No problem. PyPi is nice, but imho it can't compete with the ruby gems &amp; Bundler ;)",
  "id" : 278064275745026048,
  "in_reply_to_status_id" : 278061824665063424,
  "created_at" : "2012-12-10 09:11:04 +0000",
  "in_reply_to_screen_name" : "teleyinex",
  "in_reply_to_user_id_str" : "114682872",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278046706371809280",
  "text" : "\u00ABI expect that one cover-illustrated article in Nature compensates for one urination at the front entrance to the building\u00BB",
  "id" : 278046706371809280,
  "created_at" : "2012-12-10 08:01:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 0, 8 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/mBiYu7O6",
      "expanded_url" : "http:\/\/themetapicture.com\/27-hit-combo\/",
      "display_url" : "themetapicture.com\/27-hit-combo\/"
    } ]
  },
  "in_reply_to_status_id_str" : "277895057711976448",
  "geo" : { },
  "id_str" : "277896588125425664",
  "in_reply_to_user_id" : 32865583,
  "text" : "@raichoo Fighting against the true scotsman! http:\/\/t.co\/mBiYu7O6",
  "id" : 277896588125425664,
  "in_reply_to_status_id" : 277895057711976448,
  "created_at" : "2012-12-09 22:04:44 +0000",
  "in_reply_to_screen_name" : "raichoo",
  "in_reply_to_user_id_str" : "32865583",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 3, 11 ],
      "id_str" : "32865583",
      "id" : 32865583
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/Rufs2D7o",
      "expanded_url" : "http:\/\/img404.imageshack.us\/img404\/6573\/santobluedemon03cd8.jpg",
      "display_url" : "img404.imageshack.us\/img404\/6573\/sa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277896154367283200",
  "text" : "RT @raichoo: @gedankenstuecke Serious Luchadores of reason are serious! http:\/\/t.co\/Rufs2D7o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/Rufs2D7o",
        "expanded_url" : "http:\/\/img404.imageshack.us\/img404\/6573\/santobluedemon03cd8.jpg",
        "display_url" : "img404.imageshack.us\/img404\/6573\/sa\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "277894326355382274",
    "geo" : { },
    "id_str" : "277895057711976448",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Serious Luchadores of reason are serious! http:\/\/t.co\/Rufs2D7o",
    "id" : 277895057711976448,
    "in_reply_to_status_id" : 277894326355382274,
    "created_at" : "2012-12-09 21:58:39 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "protected" : false,
      "id_str" : "32865583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2227439864\/Foto_am_30-06-2010_um_16.53__2_normal.jpg",
      "id" : 32865583,
      "verified" : false
    }
  },
  "id" : 277896154367283200,
  "created_at" : "2012-12-09 22:03:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277895244824064000",
  "geo" : { },
  "id_str" : "277895527520169984",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin Von den Daten her bin ich mit dem Fitbit bislang am besten zufrieden, da ist der Formfaktor halt nur nicht so dolle.",
  "id" : 277895527520169984,
  "in_reply_to_status_id" : 277895244824064000,
  "created_at" : "2012-12-09 22:00:31 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277895067895730177",
  "geo" : { },
  "id_str" : "277895404476055552",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Protipp: Handel dich runter auf einen.",
  "id" : 277895404476055552,
  "in_reply_to_status_id" : 277895067895730177,
  "created_at" : "2012-12-09 22:00:02 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/gn9bRKf1",
      "expanded_url" : "http:\/\/www.indiegogo.com\/misfitshine",
      "display_url" : "indiegogo.com\/misfitshine"
    } ]
  },
  "in_reply_to_status_id_str" : "277894577325735936",
  "geo" : { },
  "id_str" : "277894863700238336",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin Als N\u00E4chstes wollte ich das UP von Jawbone mal testen. Und ich hab das Shine gebackt: http:\/\/t.co\/gn9bRKf1",
  "id" : 277894863700238336,
  "in_reply_to_status_id" : 277894577325735936,
  "created_at" : "2012-12-09 21:57:53 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277894299474071553",
  "geo" : { },
  "id_str" : "277894464549310464",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin Nein, ich trage das sonst 24\/7. Und ja, es kann keinen Schlaf analysieren.",
  "id" : 277894464549310464,
  "in_reply_to_status_id" : 277894299474071553,
  "created_at" : "2012-12-09 21:56:18 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 0, 8 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277894080401395712",
  "geo" : { },
  "id_str" : "277894326355382274",
  "in_reply_to_user_id" : 32865583,
  "text" : "@raichoo Count me in, as long as we don\u2019t have to wear silly costumes :)",
  "id" : 277894326355382274,
  "in_reply_to_status_id" : 277894080401395712,
  "created_at" : "2012-12-09 21:55:45 +0000",
  "in_reply_to_screen_name" : "raichoo",
  "in_reply_to_user_id_str" : "32865583",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277893875778060288",
  "geo" : { },
  "id_str" : "277894169219981312",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin Ist ein nettes Spielzeug, allerdings haben sie halt (noch?) keine API und die Daten sind nicht sonderlich detailliert.",
  "id" : 277894169219981312,
  "in_reply_to_status_id" : 277893875778060288,
  "created_at" : "2012-12-09 21:55:07 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277890302755344384",
  "geo" : { },
  "id_str" : "277893553286438912",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin Ich habe beides schon getestet und stimme dem zu :D",
  "id" : 277893553286438912,
  "in_reply_to_status_id" : 277890302755344384,
  "created_at" : "2012-12-09 21:52:40 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277892853387100161",
  "text" : "\u00ABInterdisciplinary Relations, das klingt nach einem guten Pornonamen.\u00BB \u2014 \u00ABDaf\u00FCr w\u00FCrde man ob des Namens bestimmt sogar EU-Funding bekommen\u00BB",
  "id" : 277892853387100161,
  "created_at" : "2012-12-09 21:49:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus A. Dahlem",
      "screen_name" : "markusdahlem",
      "indices" : [ 0, 13 ],
      "id_str" : "15703122",
      "id" : 15703122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277887221074382849",
  "geo" : { },
  "id_str" : "277887477304401920",
  "in_reply_to_user_id" : 15703122,
  "text" : "@markusdahlem Ok, durch. Jetzt erst recht.",
  "id" : 277887477304401920,
  "in_reply_to_status_id" : 277887221074382849,
  "created_at" : "2012-12-09 21:28:32 +0000",
  "in_reply_to_screen_name" : "markusdahlem",
  "in_reply_to_user_id_str" : "15703122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus A. Dahlem",
      "screen_name" : "markusdahlem",
      "indices" : [ 0, 13 ],
      "id_str" : "15703122",
      "id" : 15703122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277883741504946176",
  "geo" : { },
  "id_str" : "277886885576204290",
  "in_reply_to_user_id" : 15703122,
  "text" : "@markusdahlem ich bin noch nicht ganz durch. Aber das ist jetzt schon nachvollziehbar. :)",
  "id" : 277886885576204290,
  "in_reply_to_status_id" : 277883741504946176,
  "created_at" : "2012-12-09 21:26:11 +0000",
  "in_reply_to_screen_name" : "markusdahlem",
  "in_reply_to_user_id_str" : "15703122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus A. Dahlem",
      "screen_name" : "markusdahlem",
      "indices" : [ 0, 13 ],
      "id_str" : "15703122",
      "id" : 15703122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277871305318100992",
  "geo" : { },
  "id_str" : "277882141164044289",
  "in_reply_to_user_id" : 15703122,
  "text" : "@markusdahlem danke f\u00FCr das Teilen. Sehr cool :)",
  "id" : 277882141164044289,
  "in_reply_to_status_id" : 277871305318100992,
  "created_at" : "2012-12-09 21:07:19 +0000",
  "in_reply_to_screen_name" : "markusdahlem",
  "in_reply_to_user_id_str" : "15703122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277873123603382273",
  "geo" : { },
  "id_str" : "277874917242961921",
  "in_reply_to_user_id" : 40466433,
  "text" : "@PhaidrosDA wir arbeiten dran!",
  "id" : 277874917242961921,
  "in_reply_to_status_id" : 277873123603382273,
  "created_at" : "2012-12-09 20:38:37 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Markus A. Dahlem",
      "screen_name" : "markusdahlem",
      "indices" : [ 3, 16 ],
      "id_str" : "15703122",
      "id" : 15703122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/qccVga2U",
      "expanded_url" : "http:\/\/infoproc.blogspot.de\/2012\/12\/john-von-neumann-documentary.html",
      "display_url" : "infoproc.blogspot.de\/2012\/12\/john-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277874837769306113",
  "text" : "RT @markusdahlem: \"von Neumann could think as a physicist and be sloppy with the best of them.\" *Documentary* http:\/\/t.co\/qccVga2U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/qccVga2U",
        "expanded_url" : "http:\/\/infoproc.blogspot.de\/2012\/12\/john-von-neumann-documentary.html",
        "display_url" : "infoproc.blogspot.de\/2012\/12\/john-v\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "277871305318100992",
    "text" : "\"von Neumann could think as a physicist and be sloppy with the best of them.\" *Documentary* http:\/\/t.co\/qccVga2U",
    "id" : 277871305318100992,
    "created_at" : "2012-12-09 20:24:16 +0000",
    "user" : {
      "name" : "Markus A. Dahlem",
      "screen_name" : "markusdahlem",
      "protected" : false,
      "id_str" : "15703122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/853884969277587456\/AVU2LgEL_normal.jpg",
      "id" : 15703122,
      "verified" : false
    }
  },
  "id" : 277874837769306113,
  "created_at" : "2012-12-09 20:38:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Down",
      "screen_name" : "dasmoth",
      "indices" : [ 117, 125 ],
      "id_str" : "71291461",
      "id" : 71291461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/w3k8zmXy",
      "expanded_url" : "http:\/\/wmbriggs.com\/blog\/?p=6465",
      "display_url" : "wmbriggs.com\/blog\/?p=6465"
    } ]
  },
  "geo" : { },
  "id_str" : "277849274937655296",
  "text" : "\u00ABWhat is frequentism? A walking-dead philosophy of probability\u00BB A ML &amp; Stats FAQ. http:\/\/t.co\/w3k8zmXy \/Link via @dasmoth",
  "id" : 277849274937655296,
  "created_at" : "2012-12-09 18:56:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/kCAENbg9",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/George_R._Price#Conversion",
      "display_url" : "en.wikipedia.org\/wiki\/George_R.\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "277843072937779201",
  "geo" : { },
  "id_str" : "277843362801913856",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon There isn\u2019t too much on it online. But I can de-DRM you the book. http:\/\/t.co\/kCAENbg9",
  "id" : 277843362801913856,
  "in_reply_to_status_id" : 277843072937779201,
  "created_at" : "2012-12-09 18:33:14 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277836930845143042",
  "geo" : { },
  "id_str" : "277837906914209792",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon to be fair that\u2019s an oversimplification. He also thought of the last digits of his phone number and other stuff as signs of god.",
  "id" : 277837906914209792,
  "in_reply_to_status_id" : 277836930845143042,
  "created_at" : "2012-12-09 18:11:33 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277833765374529536",
  "geo" : { },
  "id_str" : "277836360268791809",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon yeah, but \u00ABI met a woman I like, called Anne. That\u2019s also the name of my ex-wife. I now better turn to Jesus for family values\u00BB?",
  "id" : 277836360268791809,
  "in_reply_to_status_id" : 277833765374529536,
  "created_at" : "2012-12-09 18:05:24 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277831608772464640",
  "text" : "It\u2019s amazing how Price, who is basically known for his math, could fail at probability and fall for random encounters as signs of god.",
  "id" : 277831608772464640,
  "created_at" : "2012-12-09 17:46:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 34, 47 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/G4ePkJY3",
      "expanded_url" : "http:\/\/www.scilogs.de\/wblogs\/blog\/bierologie\/biologie\/2008-09-10\/sexuelle-bel-stigung-im-tierreich",
      "display_url" : "scilogs.de\/wblogs\/blog\/bi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "277829104185769984",
  "geo" : { },
  "id_str" : "277829326282559488",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Aber ich habe gelogen. @PhilippBayer hatte dar\u00FCber gebloggt. Ich habe den vergewaltigenden Seeb\u00E4ren gehabt http:\/\/t.co\/G4ePkJY3",
  "id" : 277829326282559488,
  "in_reply_to_status_id" : 277829104185769984,
  "created_at" : "2012-12-09 17:37:27 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277828546876018688",
  "geo" : { },
  "id_str" : "277828769274793984",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente Danke, \u00FCber den Ignobel daf\u00FCr hatte ich irgendwann im Rahmen einer Tiersex-Reihe auch mal gebloggt. :)",
  "id" : 277828769274793984,
  "in_reply_to_status_id" : 277828546876018688,
  "created_at" : "2012-12-09 17:35:15 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277813950991699968",
  "geo" : { },
  "id_str" : "277814855224942592",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy Thanks! That also looks really nice!",
  "id" : 277814855224942592,
  "in_reply_to_status_id" : 277813950991699968,
  "created_at" : "2012-12-09 16:39:57 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277813232469696513",
  "geo" : { },
  "id_str" : "277813320399081472",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Alleine daf\u00FCr will ich weiter in die ML-Richtung!",
  "id" : 277813320399081472,
  "in_reply_to_status_id" : 277813232469696513,
  "created_at" : "2012-12-09 16:33:51 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/HNKmVaO9",
      "expanded_url" : "http:\/\/j.mp\/YQXSgk",
      "display_url" : "j.mp\/YQXSgk"
    } ]
  },
  "geo" : { },
  "id_str" : "277811456374894593",
  "text" : "Watching beautiful agony for Science: It\u2019s a Fine Line between (Sexual) Pleasure and Pain http:\/\/t.co\/HNKmVaO9",
  "id" : 277811456374894593,
  "created_at" : "2012-12-09 16:26:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/uaRMyDBW",
      "expanded_url" : "http:\/\/pyml.sourceforge.net\/index.html",
      "display_url" : "pyml.sourceforge.net\/index.html"
    } ]
  },
  "geo" : { },
  "id_str" : "277809278134411265",
  "text" : "Looks really nice, will have to give it a try: PyML - machine learning in Python http:\/\/t.co\/uaRMyDBW",
  "id" : 277809278134411265,
  "created_at" : "2012-12-09 16:17:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/cTfbKSQO",
      "expanded_url" : "http:\/\/findavet.us\/wp-content\/uploads\/2011\/01\/dog_vomit_toilet.jpg",
      "display_url" : "findavet.us\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "277808624418578433",
  "geo" : { },
  "id_str" : "277808989117501440",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy http:\/\/t.co\/cTfbKSQO",
  "id" : 277808989117501440,
  "in_reply_to_status_id" : 277808624418578433,
  "created_at" : "2012-12-09 16:16:39 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277807099076046849",
  "geo" : { },
  "id_str" : "277807993800769536",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Mopselkotze!",
  "id" : 277807993800769536,
  "in_reply_to_status_id" : 277807099076046849,
  "created_at" : "2012-12-09 16:12:41 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/tRu8gM8X",
      "expanded_url" : "http:\/\/www.fr-online.de\/frankfurt\/wintereinbruch-flugausfaelle-am-frankfurter-flughafen,1472798,21066104.html",
      "display_url" : "fr-online.de\/frankfurt\/wint\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277801520618168320",
  "text" : "Offensichtlich war die Entscheidung schon gestern zur\u00FCckzufliegen noch besser als gedacht. http:\/\/t.co\/tRu8gM8X",
  "id" : 277801520618168320,
  "created_at" : "2012-12-09 15:46:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277771655105884162",
  "text" : "On Robert Trivers: \u00ABHis mania took the form of staying up all night, night after night, reading Wittgenstein and finally collapsing.\u00BB",
  "id" : 277771655105884162,
  "created_at" : "2012-12-09 13:48:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277763495729184769",
  "text" : "Template-Design in LaTeX\u2026 What did I do to deserve this?",
  "id" : 277763495729184769,
  "created_at" : "2012-12-09 13:15:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277568292699389952",
  "geo" : { },
  "id_str" : "277568600150245376",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj I wish I was a neutron bomb!",
  "id" : 277568600150245376,
  "in_reply_to_status_id" : 277568292699389952,
  "created_at" : "2012-12-09 00:21:25 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inhale exhale repeat",
      "screen_name" : "C_Holler",
      "indices" : [ 0, 9 ],
      "id_str" : "65671142",
      "id" : 65671142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277556890152607746",
  "geo" : { },
  "id_str" : "277557842536452096",
  "in_reply_to_user_id" : 65671142,
  "text" : "@C_Holler Seine Doku-Erfolgswelle h\u00E4lt schon doppelt so lange an wie das tausendj\u00E4hrige Reich!",
  "id" : 277557842536452096,
  "in_reply_to_status_id" : 277556890152607746,
  "created_at" : "2012-12-08 23:38:41 +0000",
  "in_reply_to_screen_name" : "C_Holler",
  "in_reply_to_user_id_str" : "65671142",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/SimFmK72",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=UHl4WYBGBDk",
      "display_url" : "youtube.com\/watch?v=UHl4WY\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277543921947656193",
  "text" : "\u00ABJane Austen and Mark Twain. Blood spattered weapons in their hands. Cutting up zombies and saving their brains.\u00BB &lt;3 http:\/\/t.co\/SimFmK72",
  "id" : 277543921947656193,
  "created_at" : "2012-12-08 22:43:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 54, 63 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277539091829100544",
  "geo" : { },
  "id_str" : "277539267721433089",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Das klingt gut. Alternativ lassen wir uns von @Senficon bekochen damit sie auch mitessen kann ;)",
  "id" : 277539267721433089,
  "in_reply_to_status_id" : 277539091829100544,
  "created_at" : "2012-12-08 22:24:52 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Grime",
      "screen_name" : "jamesgrime",
      "indices" : [ 3, 14 ],
      "id_str" : "21349077",
      "id" : 21349077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277538943765991425",
  "text" : "RT @jamesgrime: First minute of Die Hard and I've seen smoking in an airport, a gun on a plane, and Bruce Willis' hair - it's the 80s.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277538294689046528",
    "text" : "First minute of Die Hard and I've seen smoking in an airport, a gun on a plane, and Bruce Willis' hair - it's the 80s.",
    "id" : 277538294689046528,
    "created_at" : "2012-12-08 22:21:00 +0000",
    "user" : {
      "name" : "James Grime",
      "screen_name" : "jamesgrime",
      "protected" : false,
      "id_str" : "21349077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1393049019\/meagain_normal.JPG",
      "id" : 21349077,
      "verified" : false
    }
  },
  "id" : 277538943765991425,
  "created_at" : "2012-12-08 22:23:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277538809430827008",
  "geo" : { },
  "id_str" : "277538889261006848",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Mist, und ich bin echt nicht bereit wieder eine Hose anzuziehen :D",
  "id" : 277538889261006848,
  "in_reply_to_status_id" : 277538809430827008,
  "created_at" : "2012-12-08 22:23:22 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277534068382507009",
  "geo" : { },
  "id_str" : "277538289504903168",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Komm r\u00FCber! :D",
  "id" : 277538289504903168,
  "in_reply_to_status_id" : 277534068382507009,
  "created_at" : "2012-12-08 22:20:59 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277532292925247488",
  "geo" : { },
  "id_str" : "277532740625256448",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer o\/",
  "id" : 277532740625256448,
  "in_reply_to_status_id" : 277532292925247488,
  "created_at" : "2012-12-08 21:58:56 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 3, 16 ],
      "id_str" : "53639020",
      "id" : 53639020
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277532712401764353",
  "text" : "RT @Unsichtbarer: @gedankenstuecke Sehr gut. Slacker-Five! o\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "277531720067190785",
    "geo" : { },
    "id_str" : "277532292925247488",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke Sehr gut. Slacker-Five! o\/",
    "id" : 277532292925247488,
    "in_reply_to_status_id" : 277531720067190785,
    "created_at" : "2012-12-08 21:57:09 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "protected" : false,
      "id_str" : "53639020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/888018080533798912\/tLyWNYBf_normal.jpg",
      "id" : 53639020,
      "verified" : false
    }
  },
  "id" : 277532712401764353,
  "created_at" : "2012-12-08 21:58:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277527297387536384",
  "geo" : { },
  "id_str" : "277531720067190785",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer Jo, works for me :D",
  "id" : 277531720067190785,
  "in_reply_to_status_id" : 277527297387536384,
  "created_at" : "2012-12-08 21:54:53 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277526522947043329",
  "geo" : { },
  "id_str" : "277526713846603776",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer Also das Zeug zu k\u00F6nnen wenn man es wirklich\u2122 regelm\u00E4ssig ben\u00F6tigt ist super. Sonst schl\u00E4gt man es halt nach wenn ben\u00F6tigt",
  "id" : 277526713846603776,
  "in_reply_to_status_id" : 277526522947043329,
  "created_at" : "2012-12-08 21:34:59 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277525676729454592",
  "geo" : { },
  "id_str" : "277525834263306241",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer Ich glaube das ist normal. Das muss sich jeder einfach wie bescheuert in den Sch\u00E4del pr\u00FCgeln.Um es dann wieder zu vergessen :P",
  "id" : 277525834263306241,
  "in_reply_to_status_id" : 277525676729454592,
  "created_at" : "2012-12-08 21:31:29 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277524944630464512",
  "geo" : { },
  "id_str" : "277525314773581824",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer chemische Nomenklatur bzw. Visualisierungen? :D",
  "id" : 277525314773581824,
  "in_reply_to_status_id" : 277524944630464512,
  "created_at" : "2012-12-08 21:29:25 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277514832079626240",
  "geo" : { },
  "id_str" : "277515429788925953",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer Ich kann nur empfehlen Evolutionsbiologe zu werden. Dann hat man f\u00FCr die Themen v\u00F6llige Narren, \u00E4h, Wissenschaftsfreiheit ;)",
  "id" : 277515429788925953,
  "in_reply_to_status_id" : 277514832079626240,
  "created_at" : "2012-12-08 20:50:09 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarauderPixie",
      "screen_name" : "Unsichtbarer",
      "indices" : [ 0, 13 ],
      "id_str" : "53639020",
      "id" : 53639020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277511902005981184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097132525, 8.282994525 ]
  },
  "id_str" : "277513808887562240",
  "in_reply_to_user_id" : 53639020,
  "text" : "@Unsichtbarer Ich kann mit beidem gut leben :)",
  "id" : 277513808887562240,
  "in_reply_to_status_id" : 277511902005981184,
  "created_at" : "2012-12-08 20:43:42 +0000",
  "in_reply_to_screen_name" : "Unsichtbarer",
  "in_reply_to_user_id_str" : "53639020",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277511812528881664",
  "geo" : { },
  "id_str" : "277511920104394752",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ja, vermutlich muss man sich ja irgendwann spezialisieren.",
  "id" : 277511920104394752,
  "in_reply_to_status_id" : 277511812528881664,
  "created_at" : "2012-12-08 20:36:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277511227507355648",
  "text" : "Vom Tiersex- zum Spermaexperten. Not sure if Bef\u00F6rderung.",
  "id" : 277511227507355648,
  "created_at" : "2012-12-08 20:33:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277508909923713024",
  "text" : "Auf der Mailbox: \u00ABHallo, ich bin die Frau von $verlag die sich immer mit Sperma besch\u00E4ftigt und ich h\u00E4tte da mal ein paar Fragen.\u00BB",
  "id" : 277508909923713024,
  "created_at" : "2012-12-08 20:24:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 3, 8 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277506904664707074",
  "text" : "RT @li5a: OR: being off by one is the emperor of all bioinformatics mistakes - it rules them all",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277506484676481026",
    "text" : "OR: being off by one is the emperor of all bioinformatics mistakes - it rules them all",
    "id" : 277506484676481026,
    "created_at" : "2012-12-08 20:14:36 +0000",
    "user" : {
      "name" : "li5a",
      "screen_name" : "li5a",
      "protected" : false,
      "id_str" : "11712822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/42645812\/P1010897_normal.JPG",
      "id" : 11712822,
      "verified" : false
    }
  },
  "id" : 277506904664707074,
  "created_at" : "2012-12-08 20:16:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277493549451317248",
  "text" : "Topfkino",
  "id" : 277493549451317248,
  "created_at" : "2012-12-08 19:23:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/DAoHiraz",
      "expanded_url" : "http:\/\/j.mp\/RK35Dl",
      "display_url" : "j.mp\/RK35Dl"
    } ]
  },
  "geo" : { },
  "id_str" : "277462407855616000",
  "text" : "Hail Photoshop: The Case Of The Missing Parasites http:\/\/t.co\/DAoHiraz",
  "id" : 277462407855616000,
  "created_at" : "2012-12-08 17:19:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277461928606052352",
  "text" : "\u00ABVampIren\u00BB",
  "id" : 277461928606052352,
  "created_at" : "2012-12-08 17:17:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 11, 20 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277457637707243523",
  "geo" : { },
  "id_str" : "277458265036701697",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher @Senficon du meinst geflohen? ;)",
  "id" : 277458265036701697,
  "in_reply_to_status_id" : 277457637707243523,
  "created_at" : "2012-12-08 17:02:59 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277456335812046849",
  "text" : "\u00ABOh nein, die Sonne geht unter. Das hei\u00DFt in 5 Minuten ist hier alles voller betrunkener Iren!\u00BB",
  "id" : 277456335812046849,
  "created_at" : "2012-12-08 16:55:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277434699675209729",
  "geo" : { },
  "id_str" : "277441186770345984",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt wenn ich mir das anschaue bin ich doppelt froh das mein Vortrag nicht angenommen wurde.",
  "id" : 277441186770345984,
  "in_reply_to_status_id" : 277434699675209729,
  "created_at" : "2012-12-08 15:55:08 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277435274634612736",
  "text" : "Schlimmste Aufgabe des Tages: Absagen verschicken\u2026",
  "id" : 277435274634612736,
  "created_at" : "2012-12-08 15:31:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277415681518092288",
  "geo" : { },
  "id_str" : "277424661288062976",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer Great, I \u2018ll give it a test on my end as well (probably tomorrow).",
  "id" : 277424661288062976,
  "in_reply_to_status_id" : 277415681518092288,
  "created_at" : "2012-12-08 14:49:28 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277406344158515201",
  "geo" : { },
  "id_str" : "277411988735422464",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer 1.9.2 iirc.",
  "id" : 277411988735422464,
  "in_reply_to_status_id" : 277406344158515201,
  "created_at" : "2012-12-08 13:59:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277379927551115264",
  "text" : "\u00ABHowever much he believed in worker solidarity, Haldane was a lover of mankind who trusted no one.\u00BB",
  "id" : 277379927551115264,
  "created_at" : "2012-12-08 11:51:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/XufZqZJN",
      "expanded_url" : "http:\/\/j.mp\/XBDNZO",
      "display_url" : "j.mp\/XBDNZO"
    } ]
  },
  "geo" : { },
  "id_str" : "277367041118322688",
  "text" : "Genomic variation landscape of the gut microbiome http:\/\/t.co\/XufZqZJN",
  "id" : 277367041118322688,
  "created_at" : "2012-12-08 11:00:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277366936613048320",
  "geo" : { },
  "id_str" : "277367010172747776",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ah, okay.",
  "id" : 277367010172747776,
  "in_reply_to_status_id" : 277366936613048320,
  "created_at" : "2012-12-08 11:00:23 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277362008398131200",
  "geo" : { },
  "id_str" : "277362162635255808",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon stimmt, aber f\u00FCr die anderen 99% :)",
  "id" : 277362162635255808,
  "in_reply_to_status_id" : 277362008398131200,
  "created_at" : "2012-12-08 10:41:07 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277359309665476608",
  "geo" : { },
  "id_str" : "277359749916409856",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon \u201Eich kandidiere nicht\u201C-Buttons w\u00E4ren eventuell effizienter im Materialverbrauch. ;)",
  "id" : 277359749916409856,
  "in_reply_to_status_id" : 277359309665476608,
  "created_at" : "2012-12-08 10:31:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 27, 36 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277355217119490049",
  "geo" : { },
  "id_str" : "277355761888284672",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer @Senficon it\u2019s like OkCupid, for people who are to lazy to answer questions!",
  "id" : 277355761888284672,
  "in_reply_to_status_id" : 277355217119490049,
  "created_at" : "2012-12-08 10:15:41 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 27, 36 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277347901791956992",
  "geo" : { },
  "id_str" : "277354048229888000",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer @Senficon freemium with additional plans for high velocity access to our big data.",
  "id" : 277354048229888000,
  "in_reply_to_status_id" : 277347901791956992,
  "created_at" : "2012-12-08 10:08:52 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3422357504, -6.2646538213 ]
  },
  "id_str" : "277353545274122240",
  "text" : "TIL that some piano stores have their own \u201Eno stairway\u201C-policy: \u00ABStrictly no Adele or Fur Elise\u00BB",
  "id" : 277353545274122240,
  "created_at" : "2012-12-08 10:06:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 27, 36 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277345763376394241",
  "geo" : { },
  "id_str" : "277346604355313664",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer @Senficon I\u2019m pretty sure that this won\u2019t happen. (Was refreshing that no one asked about our business model) :p",
  "id" : 277346604355313664,
  "in_reply_to_status_id" : 277345763376394241,
  "created_at" : "2012-12-08 09:39:17 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277307412401242113",
  "geo" : { },
  "id_str" : "277344340492312577",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @PhilippBayer @helgerausch \u201Ethe award for the best use of swear words and cat pictures in an academic presentation goes to\u2026\u201C",
  "id" : 277344340492312577,
  "in_reply_to_status_id" : 277307412401242113,
  "created_at" : "2012-12-08 09:30:18 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 27, 36 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277196879551422464",
  "geo" : { },
  "id_str" : "277260346035687424",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch @Senficon (damn, this sounds like a weird gospel\/marketing speech, but I mean it!)",
  "id" : 277260346035687424,
  "in_reply_to_status_id" : 277196879551422464,
  "created_at" : "2012-12-08 03:56:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 14, 26 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 27, 36 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277196879551422464",
  "geo" : { },
  "id_str" : "277260210417065985",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @helgerausch @Senficon thanks, but it\u2019s a team effort. Without the work of all of us this wouldn\u2019t have been possible. :)",
  "id" : 277260210417065985,
  "in_reply_to_status_id" : 277196879551422464,
  "created_at" : "2012-12-08 03:56:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Grant",
      "screen_name" : "stephencgrant",
      "indices" : [ 3, 17 ],
      "id_str" : "35887286",
      "id" : 35887286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277133910100549632",
  "text" : "RT @stephencgrant: Congratulations to Belize for being the first people to successfully uninstall McAfee.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "276612602950475776",
    "text" : "Congratulations to Belize for being the first people to successfully uninstall McAfee.",
    "id" : 276612602950475776,
    "created_at" : "2012-12-06 09:02:38 +0000",
    "user" : {
      "name" : "Stephen Grant",
      "screen_name" : "stephencgrant",
      "protected" : false,
      "id_str" : "35887286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/882180905619640322\/-x6AkVXQ_normal.jpg",
      "id" : 35887286,
      "verified" : true
    }
  },
  "id" : 277133910100549632,
  "created_at" : "2012-12-07 19:34:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277118245843120128",
  "geo" : { },
  "id_str" : "277129417745133569",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon oh, und was h\u00E4ltst du davon nach Dublin zu gehen? :P",
  "id" : 277129417745133569,
  "in_reply_to_status_id" : 277118245843120128,
  "created_at" : "2012-12-07 19:16:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277118245843120128",
  "geo" : { },
  "id_str" : "277128123332583424",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @PhilippBayer @helgerausch na der Preis geht doch mit an die Co-Autoren. :)",
  "id" : 277128123332583424,
  "in_reply_to_status_id" : 277118245843120128,
  "created_at" : "2012-12-07 19:11:08 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 44, 57 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 58, 70 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 71, 80 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277114023026257920",
  "text" : "Yeah, \u00ABBest Talk\u00BB-Award. Congratulations to @PhilippBayer @helgerausch @Senficon :)",
  "id" : 277114023026257920,
  "created_at" : "2012-12-07 18:15:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "indices" : [ 3, 14 ],
      "id_str" : "4339911",
      "id" : 4339911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277096899662737409",
  "text" : "RT @IanMulvany: Science just ran a one sentence story about eLife, cost of the story - $20. content - we are launching next week, there  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277096063670841344",
    "text" : "Science just ran a one sentence story about eLife, cost of the story - $20. content - we are launching next week, there I just saved you $20",
    "id" : 277096063670841344,
    "created_at" : "2012-12-07 17:03:44 +0000",
    "user" : {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "protected" : false,
      "id_str" : "4339911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605109727404638208\/p6BLA4Ub_normal.jpg",
      "id" : 4339911,
      "verified" : false
    }
  },
  "id" : 277096899662737409,
  "created_at" : "2012-12-07 17:07:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277086031453503488",
  "text" : "\u00ABHow to protect your intellectual property\u00BB Yeah, that\u2019s how academia should work\u2026",
  "id" : 277086031453503488,
  "created_at" : "2012-12-07 16:23:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277069638607704064",
  "geo" : { },
  "id_str" : "277074714579578880",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal I\u2019d love to, but I won\u2019t make it this time. I\u2019m leaving tomorrow afternoon, there\u2019s too much work piling up back home.",
  "id" : 277074714579578880,
  "in_reply_to_status_id" : 277069638607704064,
  "created_at" : "2012-12-07 15:38:54 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277063366521012224",
  "geo" : { },
  "id_str" : "277063542509826048",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal yes, at UCD for a Symposium on Computational Biology &amp; Innovation. :)",
  "id" : 277063542509826048,
  "in_reply_to_status_id" : 277063366521012224,
  "created_at" : "2012-12-07 14:54:30 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277060301671763969",
  "text" : "\u00ABDiscover More, Sequence Less\u00BB is included in the title of the Roche talk. Well\u2026",
  "id" : 277060301671763969,
  "created_at" : "2012-12-07 14:41:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277049355821789184",
  "text" : "\u00ABDublin\u2019s bus drivers have more of a probabilistic approach to bus fare\u00BB",
  "id" : 277049355821789184,
  "created_at" : "2012-12-07 13:58:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "indices" : [ 3, 11 ],
      "id_str" : "19863141",
      "id" : 19863141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277026315067084800",
  "text" : "RT @cdarwin: Returned home very disconsolate, but mean to treat myself with sleeping, for the last time, on a firm flat steady bed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.thebeaglevoyage.com\/\" rel=\"nofollow\"\u003EHMSBeagle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "276383189600178176",
    "text" : "Returned home very disconsolate, but mean to treat myself with sleeping, for the last time, on a firm flat steady bed",
    "id" : 276383189600178176,
    "created_at" : "2012-12-05 17:51:02 +0000",
    "user" : {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "protected" : false,
      "id_str" : "19863141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/75125076\/darwin_normal.jpg",
      "id" : 19863141,
      "verified" : false
    }
  },
  "id" : 277026315067084800,
  "created_at" : "2012-12-07 12:26:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 90, 103 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/732Ydo3n",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1002802",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277023558092345344",
  "text" : "Ten Simple Rules for the Open Development of Scientific Software http:\/\/t.co\/732Ydo3n \/cc @PhilippBayer",
  "id" : 277023558092345344,
  "created_at" : "2012-12-07 12:15:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/Xk73qrvW",
      "expanded_url" : "http:\/\/j.mp\/YIKnPu",
      "display_url" : "j.mp\/YIKnPu"
    } ]
  },
  "geo" : { },
  "id_str" : "277021530372833280",
  "text" : "Parallel evolution in adaptive phenotypes: the case of the threespine stickleback http:\/\/t.co\/Xk73qrvW",
  "id" : 277021530372833280,
  "created_at" : "2012-12-07 12:07:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Eo9bFaCl",
      "expanded_url" : "http:\/\/j.mp\/YIJsyN",
      "display_url" : "j.mp\/YIJsyN"
    } ]
  },
  "geo" : { },
  "id_str" : "277020579826126848",
  "text" : "Electroejaculation: Getting sperm from Tasmanian devils http:\/\/t.co\/Eo9bFaCl",
  "id" : 277020579826126848,
  "created_at" : "2012-12-07 12:03:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276986353466609664",
  "text" : "Im Hostel das Zimmer direkt neben der Kondom-Vending Machine zu haben ist auch ideal wenn man schlafen will.",
  "id" : 276986353466609664,
  "created_at" : "2012-12-07 09:47:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mopple The Whale",
      "screen_name" : "MoppleTheWhale",
      "indices" : [ 0, 15 ],
      "id_str" : "33013301",
      "id" : 33013301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276845853954682880",
  "geo" : { },
  "id_str" : "276981359917006849",
  "in_reply_to_user_id" : 33013301,
  "text" : "@MoppleTheWhale sorry!",
  "id" : 276981359917006849,
  "in_reply_to_status_id" : 276845853954682880,
  "created_at" : "2012-12-07 09:27:56 +0000",
  "in_reply_to_screen_name" : "MoppleTheWhale",
  "in_reply_to_user_id_str" : "33013301",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276841678424399872",
  "text" : "Venn diagrams that look like Hitler.",
  "id" : 276841678424399872,
  "created_at" : "2012-12-07 00:12:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 12, 19 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276841143784837122",
  "geo" : { },
  "id_str" : "276841320641875968",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ausser @lsanoj hat sich von uns abgewendet.",
  "id" : 276841320641875968,
  "in_reply_to_status_id" : 276841143784837122,
  "created_at" : "2012-12-07 00:11:28 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Mopple The Whale",
      "screen_name" : "MoppleTheWhale",
      "indices" : [ 5, 20 ],
      "id_str" : "33013301",
      "id" : 33013301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276840644717191168",
  "geo" : { },
  "id_str" : "276840966651006976",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @MoppleTheWhale ich denke das mit der Mengenlehre wird er hinbekommen. ;)",
  "id" : 276840966651006976,
  "in_reply_to_status_id" : 276840644717191168,
  "created_at" : "2012-12-07 00:10:04 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276839676998983680",
  "geo" : { },
  "id_str" : "276839915919138818",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy weisst du wer noch nicht schlafen konnte?!",
  "id" : 276839915919138818,
  "in_reply_to_status_id" : 276839676998983680,
  "created_at" : "2012-12-07 00:05:54 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 3, 14 ],
      "id_str" : "18372260",
      "id" : 18372260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276829714885251072",
  "text" : "RT @grapealope: \"Right now you have to build a power supply if you want a power supply--at some point this will be a library you can dow ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hardware20",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "276829470172782592",
    "text" : "\"Right now you have to build a power supply if you want a power supply--at some point this will be a library you can download.\" #hardware20",
    "id" : 276829470172782592,
    "created_at" : "2012-12-06 23:24:23 +0000",
    "user" : {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "protected" : false,
      "id_str" : "18372260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780881616\/rachelPortraitSq-sm_normal.jpg",
      "id" : 18372260,
      "verified" : false
    }
  },
  "id" : 276829714885251072,
  "created_at" : "2012-12-06 23:25:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ananyo Bhattacharya",
      "screen_name" : "Ananyo",
      "indices" : [ 3, 10 ],
      "id_str" : "21218554",
      "id" : 21218554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/Tdl0RbBB",
      "expanded_url" : "http:\/\/bit.ly\/TF4s1D",
      "display_url" : "bit.ly\/TF4s1D"
    } ]
  },
  "geo" : { },
  "id_str" : "276824927905128448",
  "text" : "RT @Ananyo: \"What all this tells you is that Nature is a bitch who likes to make life hard for scientists\" http:\/\/t.co\/Tdl0RbBB by @step ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twhirl.org\" rel=\"nofollow\"\u003ESeesmic twhirl\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen Curry",
        "screen_name" : "Stephen_Curry",
        "indices" : [ 119, 133 ],
        "id_str" : "41358714",
        "id" : 41358714
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/Tdl0RbBB",
        "expanded_url" : "http:\/\/bit.ly\/TF4s1D",
        "display_url" : "bit.ly\/TF4s1D"
      } ]
    },
    "geo" : { },
    "id_str" : "276739261389217793",
    "text" : "\"What all this tells you is that Nature is a bitch who likes to make life hard for scientists\" http:\/\/t.co\/Tdl0RbBB by @stephen_curry",
    "id" : 276739261389217793,
    "created_at" : "2012-12-06 17:25:56 +0000",
    "user" : {
      "name" : "Ananyo Bhattacharya",
      "screen_name" : "Ananyo",
      "protected" : false,
      "id_str" : "21218554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746339881689976832\/8g2yocc7_normal.jpg",
      "id" : 21218554,
      "verified" : true
    }
  },
  "id" : 276824927905128448,
  "created_at" : "2012-12-06 23:06:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/MyAmdjvO",
      "expanded_url" : "http:\/\/j.mp\/YSJAdD",
      "display_url" : "j.mp\/YSJAdD"
    } ]
  },
  "geo" : { },
  "id_str" : "276817244623884289",
  "text" : "How to push your neuroscience: Just target those brain regions! http:\/\/t.co\/MyAmdjvO",
  "id" : 276817244623884289,
  "created_at" : "2012-12-06 22:35:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276816138611077120",
  "text" : "I really would love to see more predictive models for the Zombie Apocalypse\u2026",
  "id" : 276816138611077120,
  "created_at" : "2012-12-06 22:31:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/frjMxJGJ",
      "expanded_url" : "http:\/\/news.nationalpost.com\/2012\/12\/05\/graphic-stopping-the-dead-a-statistical-look-back-at-the-walking-dead-series-so-far\/",
      "display_url" : "news.nationalpost.com\/2012\/12\/05\/gra\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.340916, -6.263379 ]
  },
  "id_str" : "276814113601118209",
  "text" : "In case of Zombie apocalypse data scientists will be needed: \u00ABStatistical look back at the Walking Dead series so far\u00BB http:\/\/t.co\/frjMxJGJ",
  "id" : 276814113601118209,
  "created_at" : "2012-12-06 22:23:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276801487085121536",
  "text" : "\u00ABThis is Ireland: Never try to bum a fag. And always say \u2018yes\u2019 when asked whether you\u2019d like a drink\u00BB &lt;3",
  "id" : 276801487085121536,
  "created_at" : "2012-12-06 21:33:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276782840186818560",
  "geo" : { },
  "id_str" : "276786551160201216",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot du magst von den PhD Comics in die irre gef\u00FChrt worden sein. Hier werden alle Klischees erf\u00FCllt. ;)",
  "id" : 276786551160201216,
  "in_reply_to_status_id" : 276782840186818560,
  "created_at" : "2012-12-06 20:33:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276767751320768512",
  "text" : "\u00ABKonferenzen sind schon cool. Man kann sich erwachsen f\u00FChlen, muss nicht arbeiten und es gibt kostenloses Essen und Alkohol!\u00BB",
  "id" : 276767751320768512,
  "created_at" : "2012-12-06 19:19:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/kzre34L0",
      "expanded_url" : "http:\/\/j.mp\/QK3qVc",
      "display_url" : "j.mp\/QK3qVc"
    } ]
  },
  "geo" : { },
  "id_str" : "276715281047486464",
  "text" : "Not so breaking news: Most genetic variants actually don't do a thing! http:\/\/t.co\/kzre34L0",
  "id" : 276715281047486464,
  "created_at" : "2012-12-06 15:50:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/rruUJKRw",
      "expanded_url" : "http:\/\/j.mp\/WLOvb7",
      "display_url" : "j.mp\/WLOvb7"
    } ]
  },
  "geo" : { },
  "id_str" : "276713446853197824",
  "text" : "The Psychology of Workplace Boredom http:\/\/t.co\/rruUJKRw",
  "id" : 276713446853197824,
  "created_at" : "2012-12-06 15:43:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276665812809560065",
  "text" : "\u00ABI wanted a Guinness, but I only found stupid Starbucks!\u00BB \u2013 \u00ABOh, they have Guinness-lattes!\u00BB",
  "id" : 276665812809560065,
  "created_at" : "2012-12-06 12:34:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/2NTjFQev",
      "expanded_url" : "http:\/\/www.goodreads.com\/book\/show\/7994650-the-price-of-altruism",
      "display_url" : "goodreads.com\/book\/show\/7994\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.339609, -6.266358 ]
  },
  "id_str" : "276483588529197056",
  "text" : "Up next: On one of the most tragic stories in evolutionary (biology|game theory) http:\/\/t.co\/2NTjFQev",
  "id" : 276483588529197056,
  "created_at" : "2012-12-06 00:29:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Bolser",
      "screen_name" : "danbolser",
      "indices" : [ 0, 10 ],
      "id_str" : "16325864",
      "id" : 16325864
    }, {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 18, 27 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276461040970113024",
  "geo" : { },
  "id_str" : "276461727045013505",
  "in_reply_to_user_id" : 16325864,
  "text" : "@danbolser I know @Drahflow is\/was(?) working on a tool similar to the idea proposed in the blogpost to maximize his efficiency.",
  "id" : 276461727045013505,
  "in_reply_to_status_id" : 276461040970113024,
  "created_at" : "2012-12-05 23:03:06 +0000",
  "in_reply_to_screen_name" : "danbolser",
  "in_reply_to_user_id_str" : "16325864",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens-Wolfhard",
      "screen_name" : "Drahflow",
      "indices" : [ 107, 116 ],
      "id_str" : "92904426",
      "id" : 92904426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/CpiEM8Uq",
      "expanded_url" : "http:\/\/j.mp\/Vnvmej",
      "display_url" : "j.mp\/Vnvmej"
    } ]
  },
  "geo" : { },
  "id_str" : "276459090903969793",
  "text" : "Email is a to-do list made by other people \u2013 can someone make it more efficient?! http:\/\/t.co\/CpiEM8Uq \/cc @Drahflow",
  "id" : 276459090903969793,
  "created_at" : "2012-12-05 22:52:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/l9wMzxpk",
      "expanded_url" : "http:\/\/j.mp\/QIedzf",
      "display_url" : "j.mp\/QIedzf"
    } ]
  },
  "geo" : { },
  "id_str" : "276457891152674817",
  "text" : "Cracking passwords with 25 GPUs http:\/\/t.co\/l9wMzxpk",
  "id" : 276457891152674817,
  "created_at" : "2012-12-05 22:47:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/1cwWpopG",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Candida_parapsilosis",
      "display_url" : "en.wikipedia.org\/wiki\/Candida_p\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "276373362564009984",
  "geo" : { },
  "id_str" : "276373550124920832",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn http:\/\/t.co\/1cwWpopG (iirc)",
  "id" : 276373550124920832,
  "in_reply_to_status_id" : 276373362564009984,
  "created_at" : "2012-12-05 17:12:43 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276371849145884672",
  "text" : "\u00ABThink of this pathogenic fungi as something shapeshifting and dangerous. Like a Pokemon. Just inside your body.\u00BB",
  "id" : 276371849145884672,
  "created_at" : "2012-12-05 17:05:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/nsPpLk6C",
      "expanded_url" : "http:\/\/j.mp\/TQePzE",
      "display_url" : "j.mp\/TQePzE"
    } ]
  },
  "geo" : { },
  "id_str" : "276368296637521920",
  "text" : "We are forever doomed! http:\/\/t.co\/nsPpLk6C",
  "id" : 276368296637521920,
  "created_at" : "2012-12-05 16:51:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276367039533314050",
  "geo" : { },
  "id_str" : "276367410070695936",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn featuring BIG DATA (nearly shouted \u201Cdon\u2019t forget HIGH VELOCITY\u201D) &amp; THE CLOUD slides. :D",
  "id" : 276367410070695936,
  "in_reply_to_status_id" : 276367039533314050,
  "created_at" : "2012-12-05 16:48:19 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notyourtargetaudience",
      "indices" : [ 114, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276365978865127424",
  "text" : "Presenting commercial tools for biologists who can\u2019t use the command line. At a computational biology conference\u2026 #notyourtargetaudience",
  "id" : 276365978865127424,
  "created_at" : "2012-12-05 16:42:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276341743299989504",
  "geo" : { },
  "id_str" : "276342952404590592",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog bei dir rechne ich halt mit allem. ;)",
  "id" : 276342952404590592,
  "in_reply_to_status_id" : 276341743299989504,
  "created_at" : "2012-12-05 15:11:08 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276338113478012928",
  "geo" : { },
  "id_str" : "276341285693050880",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog kurz hatte ich mich gefragt wieso du dein Blog pimpern willst. ;)",
  "id" : 276341285693050880,
  "in_reply_to_status_id" : 276338113478012928,
  "created_at" : "2012-12-05 15:04:31 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "indices" : [ 0, 11 ],
      "id_str" : "4339911",
      "id" : 4339911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276299729837625345",
  "geo" : { },
  "id_str" : "276302832540450816",
  "in_reply_to_user_id" : 4339911,
  "text" : "@IanMulvany LaTeX &amp; git ;)",
  "id" : 276302832540450816,
  "in_reply_to_status_id" : 276299729837625345,
  "created_at" : "2012-12-05 12:31:43 +0000",
  "in_reply_to_screen_name" : "IanMulvany",
  "in_reply_to_user_id_str" : "4339911",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rOpenSci",
      "screen_name" : "rOpenSci",
      "indices" : [ 17, 26 ],
      "id_str" : "342250615",
      "id" : 342250615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rstats",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/GbibGi4W",
      "expanded_url" : "http:\/\/bit.ly\/PGkbRt",
      "display_url" : "bit.ly\/PGkbRt"
    } ]
  },
  "geo" : { },
  "id_str" : "276292647340105728",
  "text" : "Thanks a lot! RT @rOpenSci: New minor version of ropensnp heading to CRAN now, bug fixes #rstats http:\/\/t.co\/GbibGi4W",
  "id" : 276292647340105728,
  "created_at" : "2012-12-05 11:51:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/PRQt1Gpn",
      "expanded_url" : "http:\/\/instagr.am\/p\/S2ZRgIBwmw\/",
      "display_url" : "instagr.am\/p\/S2ZRgIBwmw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "276257817776754688",
  "text" : "Roche faces it's Panda-like fate: No mate pairs. http:\/\/t.co\/PRQt1Gpn",
  "id" : 276257817776754688,
  "created_at" : "2012-12-05 09:32:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276228392196648961",
  "geo" : { },
  "id_str" : "276229897750458368",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ist schon wieder Woche des blinden Aktionismus?",
  "id" : 276229897750458368,
  "in_reply_to_status_id" : 276228392196648961,
  "created_at" : "2012-12-05 07:41:54 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276120957729529856",
  "geo" : { },
  "id_str" : "276121665346359298",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019m not sure if you could do a second try by choice. Then it would have been 6 (2x2 at the first try, 2 at the second) ;)",
  "id" : 276121665346359298,
  "in_reply_to_status_id" : 276120957729529856,
  "created_at" : "2012-12-05 00:31:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276121134796247040",
  "geo" : { },
  "id_str" : "276121394151051264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yep, you don\u2019t have to request those. You can generate as many as you like through their site (it\u2019s not 23andMe after all) ;)",
  "id" : 276121394151051264,
  "in_reply_to_status_id" : 276121134796247040,
  "created_at" : "2012-12-05 00:30:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276119776839999488",
  "geo" : { },
  "id_str" : "276121108074332160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but I will have a look into it tomorrow, the 3G is too shaky for SSH right now. (But you could compare to production as well)",
  "id" : 276121108074332160,
  "in_reply_to_status_id" : 276119776839999488,
  "created_at" : "2012-12-05 00:29:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276119776839999488",
  "geo" : { },
  "id_str" : "276120903648157696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer oh, re API-key: I\u2019m pretty sure that I only committed the one that exclusively listens on localhost:3000 &amp; not actual one.",
  "id" : 276120903648157696,
  "in_reply_to_status_id" : 276119776839999488,
  "created_at" : "2012-12-05 00:28:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276119776839999488",
  "geo" : { },
  "id_str" : "276119973057941504",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you can\u2019t complain. I failed the first try on each of the exams and had to stand each torture twice! :P",
  "id" : 276119973057941504,
  "in_reply_to_status_id" : 276119776839999488,
  "created_at" : "2012-12-05 00:25:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276119299779874817",
  "geo" : { },
  "id_str" : "276119477454778368",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer who wouldn\u2019t love to write his exams on a saturday morning at 8am!",
  "id" : 276119477454778368,
  "in_reply_to_status_id" : 276119299779874817,
  "created_at" : "2012-12-05 00:23:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276118972502507520",
  "geo" : { },
  "id_str" : "276119380360822784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my supervisor gave me two sightseeing advices: A small (microbrewery\/pub\/restaurant) and the zoo :P",
  "id" : 276119380360822784,
  "in_reply_to_status_id" : 276118972502507520,
  "created_at" : "2012-12-05 00:22:44 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276117906549522432",
  "geo" : { },
  "id_str" : "276119110193131520",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer srsly, who thought it would be a good idea to start a conference on comp. biology at 9:30am?",
  "id" : 276119110193131520,
  "in_reply_to_status_id" : 276117906549522432,
  "created_at" : "2012-12-05 00:21:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276117906549522432",
  "geo" : { },
  "id_str" : "276118671359897600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer pretty warm (compared to home, not AUS). Haven\u2019t seen too much so far. Will do larger exploration before conf starts tomorrow.",
  "id" : 276118671359897600,
  "in_reply_to_status_id" : 276117906549522432,
  "created_at" : "2012-12-05 00:19:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/yT73dZnh",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Boeing_YAL-1",
      "display_url" : "en.wikipedia.org\/wiki\/Boeing_YA\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "276117251843825665",
  "geo" : { },
  "id_str" : "276117513190920193",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer or tactical ballistic missiles! http:\/\/t.co\/yT73dZnh",
  "id" : 276117513190920193,
  "in_reply_to_status_id" : 276117251843825665,
  "created_at" : "2012-12-05 00:15:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276115178192502784",
  "geo" : { },
  "id_str" : "276116504871854080",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer happiness is a warm megawatt laser *pew pew pew*",
  "id" : 276116504871854080,
  "in_reply_to_status_id" : 276115178192502784,
  "created_at" : "2012-12-05 00:11:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276115401442742272",
  "text" : "RT @PhilippBayer: @gedankenstuecke ... they only have feelings",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "276114770518761472",
    "geo" : { },
    "id_str" : "276115178192502784",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke ... they only have feelings",
    "id" : 276115178192502784,
    "in_reply_to_status_id" : 276114770518761472,
    "created_at" : "2012-12-05 00:06:03 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 276115401442742272,
  "created_at" : "2012-12-05 00:06:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 18, 34 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276115388775936000",
  "text" : "RT @PhilippBayer: @gedankenstuecke We have the giant lasers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "276114770518761472",
    "geo" : { },
    "id_str" : "276115133464453121",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke We have the giant lasers.",
    "id" : 276115133464453121,
    "in_reply_to_status_id" : 276114770518761472,
    "created_at" : "2012-12-05 00:05:52 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 276115388775936000,
  "created_at" : "2012-12-05 00:06:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 74, 87 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/DvX47PPe",
      "expanded_url" : "http:\/\/birdandmoon.com\/sciencevsart.html",
      "display_url" : "birdandmoon.com\/sciencevsart.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276114770518761472",
  "text" : "But seriously, we all know which team would win\u2026 http:\/\/t.co\/DvX47PPe \/HT @PhilippBayer",
  "id" : 276114770518761472,
  "created_at" : "2012-12-05 00:04:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/xpw4z2Df",
      "expanded_url" : "http:\/\/birdandmoon.com\/biologistvacation.html",
      "display_url" : "birdandmoon.com\/biologistvacat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276112494265782272",
  "text" : "RT @PhilippBayer: \"Biologist vacation photos\" http:\/\/t.co\/xpw4z2Df",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/xpw4z2Df",
        "expanded_url" : "http:\/\/birdandmoon.com\/biologistvacation.html",
        "display_url" : "birdandmoon.com\/biologistvacat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "276112096771579904",
    "text" : "\"Biologist vacation photos\" http:\/\/t.co\/xpw4z2Df",
    "id" : 276112096771579904,
    "created_at" : "2012-12-04 23:53:48 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 276112494265782272,
  "created_at" : "2012-12-04 23:55:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276103825872527362",
  "text" : "\u00ABIf you feel smug about your personal energy decisions, you\u2019re doing it wrong.\u00BB",
  "id" : 276103825872527362,
  "created_at" : "2012-12-04 23:20:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276101736974913536",
  "geo" : { },
  "id_str" : "276101950276255744",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog wenn du nicht mehr trinken willst muss es ernst sein. Gute Besserung!",
  "id" : 276101950276255744,
  "in_reply_to_status_id" : 276101736974913536,
  "created_at" : "2012-12-04 23:13:29 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276100438665854976",
  "geo" : { },
  "id_str" : "276100688206000128",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog du musst nur schneller trinken als das Bier was du schon getrunken hast wieder raus will. :)",
  "id" : 276100688206000128,
  "in_reply_to_status_id" : 276100438665854976,
  "created_at" : "2012-12-04 23:08:28 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Seemann",
      "screen_name" : "mspro",
      "indices" : [ 0, 6 ],
      "id_str" : "5751892",
      "id" : 5751892
    }, {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 7, 18 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276093412300693504",
  "geo" : { },
  "id_str" : "276098976992874496",
  "in_reply_to_user_id" : 5751892,
  "text" : "@mspro @sofakissen ich sage nicht das es dieses Verhalten nicht gibt. Gleichzeitig ist meine TL voll von Leuten die es ganz anders nutzen.",
  "id" : 276098976992874496,
  "in_reply_to_status_id" : 276093412300693504,
  "created_at" : "2012-12-04 23:01:40 +0000",
  "in_reply_to_screen_name" : "mspro",
  "in_reply_to_user_id_str" : "5751892",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrorzicke",
      "screen_name" : "terrorzicke",
      "indices" : [ 0, 12 ],
      "id_str" : "14728378",
      "id" : 14728378
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 13, 23 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276097865506516992",
  "geo" : { },
  "id_str" : "276098459554152449",
  "in_reply_to_user_id" : 14728378,
  "text" : "@terrorzicke @Fischblog mehr Bier. Ab ausreichender Menge ist das schmerzstillend. ;)",
  "id" : 276098459554152449,
  "in_reply_to_status_id" : 276097865506516992,
  "created_at" : "2012-12-04 22:59:37 +0000",
  "in_reply_to_screen_name" : "terrorzicke",
  "in_reply_to_user_id_str" : "14728378",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276090487830634496",
  "geo" : { },
  "id_str" : "276090839904681984",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen Ja, galt dem Inhalt. Der ganze Artikel leidet an der \u201Emein Twitterverhalten ist typisch\u201C-Fallacy.",
  "id" : 276090839904681984,
  "in_reply_to_status_id" : 276090487830634496,
  "created_at" : "2012-12-04 22:29:20 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 0, 11 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276089264356331520",
  "geo" : { },
  "id_str" : "276090349456338946",
  "in_reply_to_user_id" : 16084074,
  "text" : "@sofakissen Der ganze Artikel ist wirr. \u00ABTwitter is outsourced schizophrenia\u00BB, ist klar.",
  "id" : 276090349456338946,
  "in_reply_to_status_id" : 276089264356331520,
  "created_at" : "2012-12-04 22:27:23 +0000",
  "in_reply_to_screen_name" : "sofakissen",
  "in_reply_to_user_id_str" : "16084074",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/YeuXvNrz",
      "expanded_url" : "http:\/\/flpbd.it\/nsgR7",
      "display_url" : "flpbd.it\/nsgR7"
    } ]
  },
  "geo" : { },
  "id_str" : "276088563291004929",
  "text" : "Now popular on Twitter: How I quit Twitter and changed my life! m( http:\/\/t.co\/YeuXvNrz",
  "id" : 276088563291004929,
  "created_at" : "2012-12-04 22:20:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genetics watch",
      "screen_name" : "Geneticswatch",
      "indices" : [ 3, 17 ],
      "id_str" : "587875290",
      "id" : 587875290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/x3Sw583p",
      "expanded_url" : "http:\/\/dlvr.it\/2ZvLxF",
      "display_url" : "dlvr.it\/2ZvLxF"
    } ]
  },
  "geo" : { },
  "id_str" : "276086150203047936",
  "text" : "RT @Geneticswatch: 23andMe Scientists Receive More Than $500000 In Funding from the National ... - Sacramento Bee http:\/\/t.co\/x3Sw583p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/x3Sw583p",
        "expanded_url" : "http:\/\/dlvr.it\/2ZvLxF",
        "display_url" : "dlvr.it\/2ZvLxF"
      } ]
    },
    "geo" : { },
    "id_str" : "276056799638073345",
    "text" : "23andMe Scientists Receive More Than $500000 In Funding from the National ... - Sacramento Bee http:\/\/t.co\/x3Sw583p",
    "id" : 276056799638073345,
    "created_at" : "2012-12-04 20:14:04 +0000",
    "user" : {
      "name" : "Genetics watch",
      "screen_name" : "Geneticswatch",
      "protected" : false,
      "id_str" : "587875290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2306891371\/99as6x1837u5jrjcda1i_normal.gif",
      "id" : 587875290,
      "verified" : false
    }
  },
  "id" : 276086150203047936,
  "created_at" : "2012-12-04 22:10:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/ZZ5pQSuS",
      "expanded_url" : "http:\/\/j.mp\/VkuLtI",
      "display_url" : "j.mp\/VkuLtI"
    } ]
  },
  "geo" : { },
  "id_str" : "276084596586708993",
  "text" : "electric lighting from trash http:\/\/t.co\/ZZ5pQSuS",
  "id" : 276084596586708993,
  "created_at" : "2012-12-04 22:04:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neuroskeptic",
      "screen_name" : "Neuro_Skeptic",
      "indices" : [ 42, 56 ],
      "id_str" : "316327930",
      "id" : 316327930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/VXqq1oEc",
      "expanded_url" : "http:\/\/www.ncbi.nlm.nih.gov\/pubmed\/23202832?dopt=Abstract",
      "display_url" : "ncbi.nlm.nih.gov\/pubmed\/2320283\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276081508664627200",
  "text" : "237 bar visits in the name of science: MT @Neuro_Skeptic: Ppl are more likely to get drunk in bars with a dance floor  http:\/\/t.co\/VXqq1oEc",
  "id" : 276081508664627200,
  "created_at" : "2012-12-04 21:52:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/Hhzg9tE1",
      "expanded_url" : "http:\/\/instagr.am\/p\/S1Huophwqr\/",
      "display_url" : "instagr.am\/p\/S1Huophwqr\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 53.3401239566, -6.2607908249 ]
  },
  "id_str" : "276079106817396737",
  "text" : "Please make the Xmas-songs stop! @ Grafton Street http:\/\/t.co\/Hhzg9tE1",
  "id" : 276079106817396737,
  "created_at" : "2012-12-04 21:42:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276047181029449729",
  "geo" : { },
  "id_str" : "276047511871967232",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil der Zeitpunkt wo man anf\u00E4ngt panisch u zu dr\u00FCcken!",
  "id" : 276047511871967232,
  "in_reply_to_status_id" : 276047181029449729,
  "created_at" : "2012-12-04 19:37:10 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/I789Gixe",
      "expanded_url" : "http:\/\/j.mp\/UdeTIA",
      "display_url" : "j.mp\/UdeTIA"
    } ]
  },
  "geo" : { },
  "id_str" : "276042345395408896",
  "text" : "The Cost of Curation http:\/\/t.co\/I789Gixe",
  "id" : 276042345395408896,
  "created_at" : "2012-12-04 19:16:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276035804600614913",
  "geo" : { },
  "id_str" : "276039394786422784",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot au\u00DFerdem ist das total sinnvoll: Erst Google Maps wieder herstellen, dann weiter einkaufen. ;)",
  "id" : 276039394786422784,
  "in_reply_to_status_id" : 276035804600614913,
  "created_at" : "2012-12-04 19:04:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276035837609771008",
  "geo" : { },
  "id_str" : "276039048290775040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich hatte Schafe erwartet. ;)",
  "id" : 276039048290775040,
  "in_reply_to_status_id" : 276035837609771008,
  "created_at" : "2012-12-04 19:03:32 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276035067606872065",
  "text" : "Die Einkaufsreihenfolge verr\u00E4t die Priorit\u00E4ten. Erst die Daten-SIM, dann die Zahnpasta.",
  "id" : 276035067606872065,
  "created_at" : "2012-12-04 18:47:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275966349640089602",
  "text" : "RT @Lobot: \"Eine aus unserer Truppe hat nach der Faschingsparty betrunken ihren VW K\u00E4fer zu Schrott gefahren. Seitdem feiern wir kein Fa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275965933338640384",
    "text" : "\"Eine aus unserer Truppe hat nach der Faschingsparty betrunken ihren VW K\u00E4fer zu Schrott gefahren. Seitdem feiern wir kein Fasching mehr.\"",
    "id" : 275965933338640384,
    "created_at" : "2012-12-04 14:13:00 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 275966349640089602,
  "created_at" : "2012-12-04 14:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/WgsgD8Dd",
      "expanded_url" : "http:\/\/j.mp\/XlXlBa",
      "display_url" : "j.mp\/XlXlBa"
    } ]
  },
  "geo" : { },
  "id_str" : "275961994555846656",
  "text" : "Portal on a Calculator http:\/\/t.co\/WgsgD8Dd",
  "id" : 275961994555846656,
  "created_at" : "2012-12-04 13:57:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275958958970257409",
  "geo" : { },
  "id_str" : "275959278727229442",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Dramatischer: Geb\u00E4ckaufgabe",
  "id" : 275959278727229442,
  "in_reply_to_status_id" : 275958958970257409,
  "created_at" : "2012-12-04 13:46:33 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275958638290534401",
  "geo" : { },
  "id_str" : "275958950011219968",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube ja, gelobt sei der Zusatzakku. Es geht nach Dublin zum PhD Symposium on Computational Biology &amp; Innovation.",
  "id" : 275958950011219968,
  "in_reply_to_status_id" : 275958638290534401,
  "created_at" : "2012-12-04 13:45:15 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "enzyme",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275957173073362944",
  "text" : "RT @Lobot: \"Meine Mutter hat dann die Ananas f\u00FCr sich entdeckt. Wegen der Ekzeme, die sollen ja so gesund sein.\" #enzyme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "enzyme",
        "indices" : [ 102, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275957099182309376",
    "text" : "\"Meine Mutter hat dann die Ananas f\u00FCr sich entdeckt. Wegen der Ekzeme, die sollen ja so gesund sein.\" #enzyme",
    "id" : 275957099182309376,
    "created_at" : "2012-12-04 13:37:54 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 275957173073362944,
  "created_at" : "2012-12-04 13:38:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275953500423344128",
  "geo" : { },
  "id_str" : "275954012484947968",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker du bist so eine gro\u00DFe Hilfe! ;)",
  "id" : 275954012484947968,
  "in_reply_to_status_id" : 275953500423344128,
  "created_at" : "2012-12-04 13:25:38 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275946064991879168",
  "text" : "Den Boardingpass nur digital in Passbook haben. Ein Wettlauf mit dem Akku.",
  "id" : 275946064991879168,
  "created_at" : "2012-12-04 12:54:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275941836961497088",
  "geo" : { },
  "id_str" : "275942941099454464",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog *hug*",
  "id" : 275942941099454464,
  "in_reply_to_status_id" : 275941836961497088,
  "created_at" : "2012-12-04 12:41:38 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/wF8LKzPq",
      "expanded_url" : "http:\/\/j.mp\/QEh0cI",
      "display_url" : "j.mp\/QEh0cI"
    } ]
  },
  "geo" : { },
  "id_str" : "275942548734877697",
  "text" : "Finish me quick! http:\/\/t.co\/wF8LKzPq",
  "id" : 275942548734877697,
  "created_at" : "2012-12-04 12:40:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Matthews",
      "screen_name" : "Bookgirl96",
      "indices" : [ 3, 14 ],
      "id_str" : "15098005",
      "id" : 15098005
    }, {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 92, 98 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/3MqhURTO",
      "expanded_url" : "http:\/\/www.salon.com\/2012\/12\/03\/why_are_women_scared_to_call_themselves_feminists\/",
      "display_url" : "salon.com\/2012\/12\/03\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275937427225456640",
  "text" : "RT @Bookgirl96: Why are women scared to call themselves feminists? http:\/\/t.co\/3MqhURTO via @Salon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salon",
        "screen_name" : "Salon",
        "indices" : [ 76, 82 ],
        "id_str" : "16955991",
        "id" : 16955991
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/3MqhURTO",
        "expanded_url" : "http:\/\/www.salon.com\/2012\/12\/03\/why_are_women_scared_to_call_themselves_feminists\/",
        "display_url" : "salon.com\/2012\/12\/03\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "275936441077469186",
    "text" : "Why are women scared to call themselves feminists? http:\/\/t.co\/3MqhURTO via @Salon",
    "id" : 275936441077469186,
    "created_at" : "2012-12-04 12:15:48 +0000",
    "user" : {
      "name" : "Kathleen Matthews",
      "screen_name" : "Bookgirl96",
      "protected" : false,
      "id_str" : "15098005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/919898696396963841\/Nul68EtG_normal.jpg",
      "id" : 15098005,
      "verified" : false
    }
  },
  "id" : 275937427225456640,
  "created_at" : "2012-12-04 12:19:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 30, 40 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275933734908342272",
  "text" : "Jetzt wo ich ohne Multitalent @Fischblog reise habe ich sogar ausnahmsweise mal an einen SIM-Karten-Extrahierer (aka B\u00FCroklammer gedacht)!",
  "id" : 275933734908342272,
  "created_at" : "2012-12-04 12:05:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 14, 27 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/TPwrDLp7",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Doomsday_Clock",
      "display_url" : "en.wikipedia.org\/wiki\/Doomsday_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "275761751730053121",
  "geo" : { },
  "id_str" : "275926326194630657",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @iameltonjohn plus the clock image was actually used to symbolize atomic risk during the Cold War: http:\/\/t.co\/TPwrDLp7",
  "id" : 275926326194630657,
  "in_reply_to_status_id" : 275761751730053121,
  "created_at" : "2012-12-04 11:35:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 3, 17 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/4hOudTUf",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/magazine-20578627",
      "display_url" : "bbc.co.uk\/news\/magazine-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275893983459295232",
  "text" : "RT @zoonpolitikon: Things you really need to know: A lego brick can withstand 4200 Newton (432kg)! http:\/\/t.co\/4hOudTUf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/4hOudTUf",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/magazine-20578627",
        "display_url" : "bbc.co.uk\/news\/magazine-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "275893831885549568",
    "text" : "Things you really need to know: A lego brick can withstand 4200 Newton (432kg)! http:\/\/t.co\/4hOudTUf",
    "id" : 275893831885549568,
    "created_at" : "2012-12-04 09:26:30 +0000",
    "user" : {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "protected" : false,
      "id_str" : "13040652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702734921629697\/1TUbd7IS_normal.jpg",
      "id" : 13040652,
      "verified" : false
    }
  },
  "id" : 275893983459295232,
  "created_at" : "2012-12-04 09:27:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275758705100877824",
  "geo" : { },
  "id_str" : "275759021368168448",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy don\u2019t underestimate the psychological component of Python IDE vs shell. :)",
  "id" : 275759021368168448,
  "in_reply_to_status_id" : 275758705100877824,
  "created_at" : "2012-12-04 00:30:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275757653970542592",
  "geo" : { },
  "id_str" : "275758710968700928",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @PhilippBayer yes, it\u2019s a shame. But in that case it might be easier to give them basic Python, even if that\u2019s the subpar solution.",
  "id" : 275758710968700928,
  "in_reply_to_status_id" : 275757653970542592,
  "created_at" : "2012-12-04 00:29:34 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275757653970542592",
  "geo" : { },
  "id_str" : "275757967155032066",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @PhilippBayer at least in my department there are virtually no people using *nix. And I don\u2019t see them changing their OS soon.",
  "id" : 275757967155032066,
  "in_reply_to_status_id" : 275757653970542592,
  "created_at" : "2012-12-04 00:26:37 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275756400955764736",
  "geo" : { },
  "id_str" : "275756643831148544",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, Did you participate in the Python course Andreas used to give in M\u00FCnster?",
  "id" : 275756643831148544,
  "in_reply_to_status_id" : 275756400955764736,
  "created_at" : "2012-12-04 00:21:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275755683243249665",
  "geo" : { },
  "id_str" : "275755914156441600",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer most people here use Excel. So they wouldn\u2019t switch in a sense, they would get a completely new skill. ;)",
  "id" : 275755914156441600,
  "in_reply_to_status_id" : 275755683243249665,
  "created_at" : "2012-12-04 00:18:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275754752921464832",
  "geo" : { },
  "id_str" : "275755054118629376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer switched from which language\/tool?",
  "id" : 275755054118629376,
  "in_reply_to_status_id" : 275754752921464832,
  "created_at" : "2012-12-04 00:15:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275753883517730816",
  "geo" : { },
  "id_str" : "275754379947163648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I always thought about doing a small Python-workshop at my Institute. So I can stop writing 1-off csv-parsing-stuff for others",
  "id" : 275754379947163648,
  "in_reply_to_status_id" : 275753883517730816,
  "created_at" : "2012-12-04 00:12:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 14, 27 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275752794785472513",
  "geo" : { },
  "id_str" : "275753714600538112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @iameltonjohn ha, great! :)",
  "id" : 275753714600538112,
  "in_reply_to_status_id" : 275752794785472513,
  "created_at" : "2012-12-04 00:09:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275752363594240000",
  "geo" : { },
  "id_str" : "275753644312363008",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer unfortunately I don\u2019t have any connections to the relevant departments here in Frankfurt.",
  "id" : 275753644312363008,
  "in_reply_to_status_id" : 275752363594240000,
  "created_at" : "2012-12-04 00:09:26 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275752363594240000",
  "geo" : { },
  "id_str" : "275753450585849856",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sure, that sounded like a thing you might be totally interested in. :)",
  "id" : 275753450585849856,
  "in_reply_to_status_id" : 275752363594240000,
  "created_at" : "2012-12-04 00:08:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275750338760421376",
  "text" : "1a Verleser: Lustschutzsirene.",
  "id" : 275750338760421376,
  "created_at" : "2012-12-03 23:56:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275749987420340224",
  "geo" : { },
  "id_str" : "275750204462989312",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn GENTLEMEN! You can\u2019t fight in here, this is the war room! :P (glad you liked it!)",
  "id" : 275750204462989312,
  "in_reply_to_status_id" : 275749987420340224,
  "created_at" : "2012-12-03 23:55:46 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/q2mf8FXe",
      "expanded_url" : "http:\/\/readwrite.com\/2012\/12\/03\/lets-all-shed-tears-for-the-crappy-startups-that-cant-raise-any-more-money",
      "display_url" : "readwrite.com\/2012\/12\/03\/let\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275725621546610688",
  "text" : "\u00ABLet's All Shed Tears For The Crappy Startups That Can't Raise Any More Money\u00BB http:\/\/t.co\/q2mf8FXe",
  "id" : 275725621546610688,
  "created_at" : "2012-12-03 22:18:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275688320774848512",
  "geo" : { },
  "id_str" : "275691255965569024",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj Nudeln und dann Mid-Season-Finale!",
  "id" : 275691255965569024,
  "in_reply_to_status_id" : 275688320774848512,
  "created_at" : "2012-12-03 20:01:32 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 3, 10 ],
      "id_str" : "125928028",
      "id" : 125928028
    }, {
      "name" : "kolchak",
      "screen_name" : "kolchakdev",
      "indices" : [ 110, 121 ],
      "id_str" : "245544344",
      "id" : 245544344
    }, {
      "name" : "Anna Webb",
      "screen_name" : "Anna_Webb",
      "indices" : [ 122, 132 ],
      "id_str" : "296255607",
      "id" : 296255607
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womeninscience",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/jJHXfHq5",
      "expanded_url" : "http:\/\/hydrogeneportfolio.tumblr.com\/post\/32224401551\/minimal-posters-six-women-who-changed-science",
      "display_url" : "hydrogeneportfolio.tumblr.com\/post\/322244015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275683699562008577",
  "text" : "RT @Gurdur: Terrific \"Women who changed science\" poster designs: http:\/\/t.co\/jJHXfHq5 --- #womeninscience via @kolchakdev @Anna_Webb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kolchak",
        "screen_name" : "kolchakdev",
        "indices" : [ 98, 109 ],
        "id_str" : "245544344",
        "id" : 245544344
      }, {
        "name" : "Anna Webb",
        "screen_name" : "Anna_Webb",
        "indices" : [ 110, 120 ],
        "id_str" : "296255607",
        "id" : 296255607
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womeninscience",
        "indices" : [ 78, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/jJHXfHq5",
        "expanded_url" : "http:\/\/hydrogeneportfolio.tumblr.com\/post\/32224401551\/minimal-posters-six-women-who-changed-science",
        "display_url" : "hydrogeneportfolio.tumblr.com\/post\/322244015\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "275683388013309954",
    "text" : "Terrific \"Women who changed science\" poster designs: http:\/\/t.co\/jJHXfHq5 --- #womeninscience via @kolchakdev @Anna_Webb",
    "id" : 275683388013309954,
    "created_at" : "2012-12-03 19:30:16 +0000",
    "user" : {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "protected" : false,
      "id_str" : "125928028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721158367398506496\/c4cchuLu_normal.jpg",
      "id" : 125928028,
      "verified" : false
    }
  },
  "id" : 275683699562008577,
  "created_at" : "2012-12-03 19:31:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275676517667852288",
  "text" : "Carbonstahl &lt;3",
  "id" : 275676517667852288,
  "created_at" : "2012-12-03 19:02:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275654365233160192",
  "text" : "\u00ABWir k\u00F6nnen diskutieren wie gro\u00DF p(Verlasse dich f\u00FCr Nat.-Wissenschaflerin|H\u00FCndchen) ist. Aber daf\u00FCr musst du erst ins Bayes-Camp kommen\u00BB",
  "id" : 275654365233160192,
  "created_at" : "2012-12-03 17:34:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "German Psycho",
      "screen_name" : "germanpsycho",
      "indices" : [ 86, 99 ],
      "id_str" : "14972477",
      "id" : 14972477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275631692453126144",
  "text" : "Montags f\u00FCr 2 Stunden ins B\u00FCro und dann ins Wochenende gehen. Ich lebe einen Teil des @germanpsycho-Traums.",
  "id" : 275631692453126144,
  "created_at" : "2012-12-03 16:04:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 34, 44 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/n2JJ9jDh",
      "expanded_url" : "http:\/\/www.studioneat.com\/products\/cosmonaut",
      "display_url" : "studioneat.com\/products\/cosmo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "275615450648416256",
  "geo" : { },
  "id_str" : "275615780408795136",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley Haven\u2019t tried it, but @e_ramirez does all his drawings with this one iirc: http:\/\/t.co\/n2JJ9jDh",
  "id" : 275615780408795136,
  "in_reply_to_status_id" : 275615450648416256,
  "created_at" : "2012-12-03 15:01:37 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/mKd0bSIQ",
      "expanded_url" : "http:\/\/j.mp\/THctD2",
      "display_url" : "j.mp\/THctD2"
    } ]
  },
  "geo" : { },
  "id_str" : "275614843694899201",
  "text" : "When investors discover than all my service is made on external APIs http:\/\/t.co\/mKd0bSIQ",
  "id" : 275614843694899201,
  "created_at" : "2012-12-03 14:57:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 55, 64 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/yrYsMUG2",
      "expanded_url" : "http:\/\/j.mp\/11qVjzR",
      "display_url" : "j.mp\/11qVjzR"
    } ]
  },
  "geo" : { },
  "id_str" : "275613887624261632",
  "text" : "Baldur's Gate selbst enhanced http:\/\/t.co\/yrYsMUG2 \/cc @senficon",
  "id" : 275613887624261632,
  "created_at" : "2012-12-03 14:54:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275607787604688896",
  "text" : "\u00ABIm grunde genommen wollen wir ein IRB ignorance statement\u00BB",
  "id" : 275607787604688896,
  "created_at" : "2012-12-03 14:29:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 0, 11 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : ".",
      "screen_name" : "kevusch",
      "indices" : [ 33, 41 ],
      "id_str" : "90213634",
      "id" : 90213634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275603559125512192",
  "geo" : { },
  "id_str" : "275604341346410496",
  "in_reply_to_user_id" : 20342875,
  "text" : "@LouWoodley I somehow doubt that @kevusch will fly to NYC for a badge. ;)",
  "id" : 275604341346410496,
  "in_reply_to_status_id" : 275603559125512192,
  "created_at" : "2012-12-03 14:16:10 +0000",
  "in_reply_to_screen_name" : "LouWoodley",
  "in_reply_to_user_id_str" : "20342875",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "kevusch",
      "indices" : [ 0, 8 ],
      "id_str" : "90213634",
      "id" : 90213634
    }, {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 65, 76 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solo12",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275602852905353218",
  "geo" : { },
  "id_str" : "275603205822496770",
  "in_reply_to_user_id" : 90213634,
  "text" : "@kevusch I got it at the #solo12 conference in London, but maybe @LouWoodley can help you out on where to find them :)",
  "id" : 275603205822496770,
  "in_reply_to_status_id" : 275602852905353218,
  "created_at" : "2012-12-03 14:11:39 +0000",
  "in_reply_to_screen_name" : "kevusch",
  "in_reply_to_user_id_str" : "90213634",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275601184205725697",
  "text" : "*sigh* Just remembered why \u00ABzero connections to bioethics\u00BB is the way to go\u2026",
  "id" : 275601184205725697,
  "created_at" : "2012-12-03 14:03:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275565287418507264",
  "geo" : { },
  "id_str" : "275584258314207232",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer me neither, but I hadn\u2019t looked into it since the first time you mentioned and benchmarked it. :)",
  "id" : 275584258314207232,
  "in_reply_to_status_id" : 275565287418507264,
  "created_at" : "2012-12-03 12:56:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth\u00E4us Cebulla",
      "screen_name" : "MattCeb",
      "indices" : [ 0, 8 ],
      "id_str" : "180457928",
      "id" : 180457928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275552553863872512",
  "geo" : { },
  "id_str" : "275553014062936064",
  "in_reply_to_user_id" : 180457928,
  "text" : "@MattCeb i know! I briefly considered adding \u201Ein the programming language\u201C. But in the end I thought it would be more fun this way ;)",
  "id" : 275553014062936064,
  "in_reply_to_status_id" : 275552553863872512,
  "created_at" : "2012-12-03 10:52:12 +0000",
  "in_reply_to_screen_name" : "MattCeb",
  "in_reply_to_user_id_str" : "180457928",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 58, 71 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/u0eNS0vA",
      "expanded_url" : "http:\/\/www.johnmyleswhite.com\/notebook\/2012\/12\/02\/the-state-of-statistics-in-julia\/",
      "display_url" : "johnmyleswhite.com\/notebook\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275547134466605057",
  "text" : "The State of Statistics in Julia http:\/\/t.co\/u0eNS0vA \/cc @PhilippBayer",
  "id" : 275547134466605057,
  "created_at" : "2012-12-03 10:28:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 0, 8 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275544587009945600",
  "geo" : { },
  "id_str" : "275546558626418688",
  "in_reply_to_user_id" : 322062420,
  "text" : "@h_wicht Kein Problem. Ich h\u00E4tte auch auf 2s getippt und war erst verwirrt.",
  "id" : 275546558626418688,
  "in_reply_to_status_id" : 275544587009945600,
  "created_at" : "2012-12-03 10:26:33 +0000",
  "in_reply_to_screen_name" : "h_wicht",
  "in_reply_to_user_id_str" : "322062420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 0, 8 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/M1El5PcO",
      "expanded_url" : "http:\/\/tinyurl.com\/pgddu",
      "display_url" : "tinyurl.com\/pgddu"
    } ]
  },
  "in_reply_to_status_id_str" : "275530709186252800",
  "geo" : { },
  "id_str" : "275531147713331200",
  "in_reply_to_user_id" : 322062420,
  "text" : "@h_wicht Das dachte ich auch und hab deshalb vorher die Wikipedia befragt. Die sagt ein \"s\" ist richtig: http:\/\/t.co\/M1El5PcO",
  "id" : 275531147713331200,
  "in_reply_to_status_id" : 275530709186252800,
  "created_at" : "2012-12-03 09:25:19 +0000",
  "in_reply_to_screen_name" : "h_wicht",
  "in_reply_to_user_id_str" : "322062420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/ifABW3UN",
      "expanded_url" : "http:\/\/tinyurl.com\/d7r8pve",
      "display_url" : "tinyurl.com\/d7r8pve"
    } ]
  },
  "geo" : { },
  "id_str" : "275526029525778432",
  "text" : "Too bad that I don't believe in the transubstantiation... http:\/\/t.co\/ifABW3UN",
  "id" : 275526029525778432,
  "created_at" : "2012-12-03 09:04:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275523958428794880",
  "text" : "Google Translate really needs to include the genetic code(s).",
  "id" : 275523958428794880,
  "created_at" : "2012-12-03 08:56:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/Uj6nGzqh",
      "expanded_url" : "http:\/\/amzn.com\/k\/2t9-rDngRD6vbV-Xp1Tr9Q",
      "display_url" : "amzn.com\/k\/2t9-rDngRD6v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275515385099456512",
  "text" : "At the frontier of scientific debates.  http:\/\/t.co\/Uj6nGzqh Other economists have built computer models that show Jevons paradoxes...",
  "id" : 275515385099456512,
  "created_at" : "2012-12-03 08:22:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275507044788879360",
  "text" : "\u00ABThe truth is, it\u2019s not the planet that needs saving. It\u2019s our way of life.\u00BB Finally started reading Before The Lights Go Out.",
  "id" : 275507044788879360,
  "created_at" : "2012-12-03 07:49:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275407121779138561",
  "geo" : { },
  "id_str" : "275408033079783425",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ich kann mich nur wiederholen: Inconsiderate Cats in Amateur Porn. ;)",
  "id" : 275408033079783425,
  "in_reply_to_status_id" : 275407121779138561,
  "created_at" : "2012-12-03 01:16:06 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275406081868570624",
  "text" : "\u00ABDu k\u00F6nntest dich auch mal wieder rasieren.\u00BB \u2014 \u00ABDu hast da den Schwanz der Katze\u2026\u00BB",
  "id" : 275406081868570624,
  "created_at" : "2012-12-03 01:08:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275394746422267905",
  "geo" : { },
  "id_str" : "275394986525220864",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher meinten sie: Confirmation Bias? :P",
  "id" : 275394986525220864,
  "in_reply_to_status_id" : 275394746422267905,
  "created_at" : "2012-12-03 00:24:16 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 10, 17 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 29, 38 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275385580718813184",
  "geo" : { },
  "id_str" : "275389112280813568",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @lutoma no offense @snooze82, aber das ist einer der F\u00E4lle wo selbst ich dem Algorithmus nicht vertraue. ;)",
  "id" : 275389112280813568,
  "in_reply_to_status_id" : 275385580718813184,
  "created_at" : "2012-12-03 00:00:55 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275387408390959104",
  "text" : "Erwartungshaltungen von Katzenbesitzern: \u00ABNa Miezi, war die langweilig als wir weg waren?\u00BB \u2014 \u00ABOh nein, ist es Durchfall oder Kotze?\u00BB",
  "id" : 275387408390959104,
  "created_at" : "2012-12-02 23:54:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Marc Henklein",
      "screen_name" : "snooze82",
      "indices" : [ 55, 64 ],
      "id_str" : "14094265",
      "id" : 14094265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275383330801856512",
  "geo" : { },
  "id_str" : "275383790615007232",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma @Senficon klappt nur nicht vice versa. Da wird @snooze82 herausgepickt. :)",
  "id" : 275383790615007232,
  "in_reply_to_status_id" : 275383330801856512,
  "created_at" : "2012-12-02 23:39:46 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deborah Blum",
      "screen_name" : "deborahblum",
      "indices" : [ 3, 15 ],
      "id_str" : "72842277",
      "id" : 72842277
    }, {
      "name" : "Molecule Of The Day",
      "screen_name" : "dailymolecule",
      "indices" : [ 41, 55 ],
      "id_str" : "575564856",
      "id" : 575564856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moron",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275379361639706624",
  "text" : "RT @deborahblum: Best named acid ever MT @dailymolecule Moronic acid, found in mistletoe. Remember this at your Christmas party #moron h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Molecule Of The Day",
        "screen_name" : "dailymolecule",
        "indices" : [ 24, 38 ],
        "id_str" : "575564856",
        "id" : 575564856
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailymolecule\/status\/239041258738302976\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/SwVT5dzU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A1E-wiTCQAI9trW.jpg",
        "id_str" : "239041258788634626",
        "id" : 239041258788634626,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1E-wiTCQAI9trW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 378
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 378
        } ],
        "display_url" : "pic.twitter.com\/SwVT5dzU"
      } ],
      "hashtags" : [ {
        "text" : "moron",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275379061860229120",
    "text" : "Best named acid ever MT @dailymolecule Moronic acid, found in mistletoe. Remember this at your Christmas party #moron http:\/\/t.co\/SwVT5dzU",
    "id" : 275379061860229120,
    "created_at" : "2012-12-02 23:20:59 +0000",
    "user" : {
      "name" : "Deborah Blum",
      "screen_name" : "deborahblum",
      "protected" : false,
      "id_str" : "72842277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425431154385108992\/UzYxcmWl_normal.jpeg",
      "id" : 72842277,
      "verified" : false
    }
  },
  "id" : 275379361639706624,
  "created_at" : "2012-12-02 23:22:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275372099722420224",
  "text" : "Das \u00D6kosystem der Hauptwache beobachten. Tauben, M\u00E4use, Kakerlaken.",
  "id" : 275372099722420224,
  "created_at" : "2012-12-02 22:53:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275368229722013696",
  "geo" : { },
  "id_str" : "275368393798987776",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 du hast da jemanden vergessen.",
  "id" : 275368393798987776,
  "in_reply_to_status_id" : 275368229722013696,
  "created_at" : "2012-12-02 22:38:35 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 10, 17 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275362944324366336",
  "geo" : { },
  "id_str" : "275363107692503041",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Seb666 ich musste ja aufpassen das wir nicht gewinnen. Ich wollte nicht wieder auf dem Sofa schlafen m\u00FCssen.",
  "id" : 275363107692503041,
  "in_reply_to_status_id" : 275362944324366336,
  "created_at" : "2012-12-02 22:17:35 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 49, 56 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275362734902755329",
  "text" : "In der letzten Runde der Revolution zusammen mit @Seb666 vom letzten Platz auf die #2 vorgearbeitet.",
  "id" : 275362734902755329,
  "created_at" : "2012-12-02 22:16:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275345139625500672",
  "text" : "RT @Lobot: \"Wenn ich meine Cousine in Polen besucht habe, wollte sie immer mit mir Panzer spielen. 'Du bist Polen, ich bin Deutschland', ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275343715147595776",
    "text" : "\"Wenn ich meine Cousine in Polen besucht habe, wollte sie immer mit mir Panzer spielen. 'Du bist Polen, ich bin Deutschland', sagte sie.\"",
    "id" : 275343715147595776,
    "created_at" : "2012-12-02 21:00:31 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 275345139625500672,
  "created_at" : "2012-12-02 21:06:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275337835484176384",
  "text" : "\u00ABDie Deutsch-Humanistische Computer Partei vergibt ihre Posten ganz automatisch\u00BB",
  "id" : 275337835484176384,
  "created_at" : "2012-12-02 20:37:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275333631982063617",
  "geo" : { },
  "id_str" : "275334775689060353",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon alternativ: Technokratische Computer Partei gegen Intellectual Property.",
  "id" : 275334775689060353,
  "in_reply_to_status_id" : 275333631982063617,
  "created_at" : "2012-12-02 20:25:00 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275333631982063617",
  "geo" : { },
  "id_str" : "275334087835807744",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Ich finde die Universelle Digitale Partei besser.",
  "id" : 275334087835807744,
  "in_reply_to_status_id" : 275333631982063617,
  "created_at" : "2012-12-02 20:22:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275328378452705280",
  "text" : "\u00ABIch hab nur mit einem Ohr zugeh\u00F6rt. Geht es um Trabbi- oder Transenpornos?\u00BB",
  "id" : 275328378452705280,
  "created_at" : "2012-12-02 19:59:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275324005689462785",
  "text" : "\u00ABFisteln kommen ja auch vom fisten\u2026 Also nicht der Wortstamm!\u00BB",
  "id" : 275324005689462785,
  "created_at" : "2012-12-02 19:42:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275322402995597313",
  "geo" : { },
  "id_str" : "275322854009081856",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj ich w\u00FCrde die Handknochen nicht mehr als Hand bezeichnen. ;)",
  "id" : 275322854009081856,
  "in_reply_to_status_id" : 275322402995597313,
  "created_at" : "2012-12-02 19:37:38 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275320912910381056",
  "text" : "\u00ABKeine Grabsteine aus Kinderhand\u00BB \u2014 \u00ABDie verwesen auch viel zu schnell.\u00BB",
  "id" : 275320912910381056,
  "created_at" : "2012-12-02 19:29:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275312396665487360",
  "text" : "Lighthammel",
  "id" : 275312396665487360,
  "created_at" : "2012-12-02 18:56:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 22, 29 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275288072537665537",
  "text" : "\u00ABOk, ich komme mit zu @Seb666. Dann kann ich endlich das Mayorship vom Bahnhof klauen.\u00BB",
  "id" : 275288072537665537,
  "created_at" : "2012-12-02 17:19:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275284106215047168",
  "geo" : { },
  "id_str" : "275285765754327040",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko danke :)",
  "id" : 275285765754327040,
  "in_reply_to_status_id" : 275284106215047168,
  "created_at" : "2012-12-02 17:10:15 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fressesprecher",
      "screen_name" : "Bediko",
      "indices" : [ 0, 7 ],
      "id_str" : "56530362",
      "id" : 56530362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275282474190397441",
  "geo" : { },
  "id_str" : "275283996504629249",
  "in_reply_to_user_id" : 56530362,
  "text" : "@Bediko Messung auf dem Nike Fuelband. Immer das selbstgestellte Tagesziel erreicht.",
  "id" : 275283996504629249,
  "in_reply_to_status_id" : 275282474190397441,
  "created_at" : "2012-12-02 17:03:13 +0000",
  "in_reply_to_screen_name" : "Bediko",
  "in_reply_to_user_id_str" : "56530362",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275282420813688834",
  "text" : "42 day activity streak!",
  "id" : 275282420813688834,
  "created_at" : "2012-12-02 16:56:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275273683516403712",
  "text" : "RT @edyong209: Everyone's talking about the NYT's immortal jellyfish story. Except it's not immortal &amp; the story's credulous http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/IF1V4QJB",
        "expanded_url" : "http:\/\/ksj.mit.edu\/tracker\/2012\/11\/first-we-get-proof-heaven-now-secret-imm",
        "display_url" : "ksj.mit.edu\/tracker\/2012\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "274502663280947202",
    "text" : "Everyone's talking about the NYT's immortal jellyfish story. Except it's not immortal &amp; the story's credulous http:\/\/t.co\/IF1V4QJB",
    "id" : 274502663280947202,
    "created_at" : "2012-11-30 13:18:29 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 275273683516403712,
  "created_at" : "2012-12-02 16:22:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/xlZecbsC",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6ieEd7mOWUs",
      "display_url" : "youtube.com\/watch?v=6ieEd7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275233556962344960",
  "text" : "\u00ABOoooo, no one cares if you're alive when you're seventy five, go get out and drive.\u00BB http:\/\/t.co\/xlZecbsC",
  "id" : 275233556962344960,
  "created_at" : "2012-12-02 13:42:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/zwe0WqFw",
      "expanded_url" : "http:\/\/instagr.am\/p\/Su_pbuhwgU\/",
      "display_url" : "instagr.am\/p\/Su_pbuhwgU\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0066633432, 8.2810735703 ]
  },
  "id_str" : "275216397800464385",
  "text" : "\u00ABDer Marshmellow-Man!\u00BB \u2014 \u00ABEs gibt KEINE Geister!\u00BB  @ Reduit http:\/\/t.co\/zwe0WqFw",
  "id" : 275216397800464385,
  "created_at" : "2012-12-02 12:34:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/3r5XgaVC",
      "expanded_url" : "http:\/\/j.mp\/TCZL8i",
      "display_url" : "j.mp\/TCZL8i"
    } ]
  },
  "geo" : { },
  "id_str" : "275205388339650560",
  "text" : "\u00ABRelax ladies, I\u2019m a scientist\u00BB Mum, there's a monster\/psychologist hiding under my bed! http:\/\/t.co\/3r5XgaVC",
  "id" : 275205388339650560,
  "created_at" : "2012-12-02 11:50:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/vhRAcosO",
      "expanded_url" : "http:\/\/j.mp\/TCZ1QI",
      "display_url" : "j.mp\/TCZ1QI"
    } ]
  },
  "geo" : { },
  "id_str" : "275204401034035201",
  "text" : "\u00ABLack of peer review makes findings less credible, more awesome\u00BB Uncovering the global league of mythical creatures http:\/\/t.co\/vhRAcosO",
  "id" : 275204401034035201,
  "created_at" : "2012-12-02 11:46:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275035142286876673",
  "text" : "RT @leonidkruglyak: \u201CThe Bachelor\u201D is this generation\u2019s Stanford Prison Experiment. He's the prison guard, potential fianc\u00E9es are inmate ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/iRbDxdxz",
        "expanded_url" : "http:\/\/nyti.ms\/Vi5mD1",
        "display_url" : "nyti.ms\/Vi5mD1"
      } ]
    },
    "geo" : { },
    "id_str" : "275033326199398400",
    "text" : "\u201CThe Bachelor\u201D is this generation\u2019s Stanford Prison Experiment. He's the prison guard, potential fianc\u00E9es are inmates. http:\/\/t.co\/iRbDxdxz",
    "id" : 275033326199398400,
    "created_at" : "2012-12-02 00:27:09 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 275035142286876673,
  "created_at" : "2012-12-02 00:34:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274947215728988160",
  "text" : "\u00ABNicht das naive Oliven\u00F6l in die Fritteuse. Das Arme wei\u00DF doch gar nicht wie ihm geschieht!\u00BB",
  "id" : 274947215728988160,
  "created_at" : "2012-12-01 18:44:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274919479027310592",
  "text" : "\u00ABDu kannst dir gerne die Br\u00FCste amputieren lassen, wenn es dir so wichtig ist in der K\u00F6rperfettkategorie zu gewinnen!\u00BB",
  "id" : 274919479027310592,
  "created_at" : "2012-12-01 16:54:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Ca8Acdot",
      "expanded_url" : "http:\/\/j.mp\/U88WwD",
      "display_url" : "j.mp\/U88WwD"
    } ]
  },
  "geo" : { },
  "id_str" : "274888765317726209",
  "text" : "Evaluating High-Throughput Ab Initio Gene Finders. Yet another branch of bioinformatics that's basically black magic http:\/\/t.co\/Ca8Acdot",
  "id" : 274888765317726209,
  "created_at" : "2012-12-01 14:52:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/RX0fv83l",
      "expanded_url" : "http:\/\/j.mp\/U882QL",
      "display_url" : "j.mp\/U882QL"
    } ]
  },
  "geo" : { },
  "id_str" : "274885936863649794",
  "text" : "Statistical illiteracy may lead to parents panicking about Autism. http:\/\/t.co\/RX0fv83l",
  "id" : 274885936863649794,
  "created_at" : "2012-12-01 14:41:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/k5PhgTPi",
      "expanded_url" : "http:\/\/j.mp\/U87R7W",
      "display_url" : "j.mp\/U87R7W"
    } ]
  },
  "geo" : { },
  "id_str" : "274885398218543104",
  "text" : "US Supreme Court to decide on gene patents in Myriad case http:\/\/t.co\/k5PhgTPi",
  "id" : 274885398218543104,
  "created_at" : "2012-12-01 14:39:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/f3kS0cxW",
      "expanded_url" : "http:\/\/j.mp\/11fCDTP",
      "display_url" : "j.mp\/11fCDTP"
    } ]
  },
  "geo" : { },
  "id_str" : "274869266929553409",
  "text" : "Is the NIH a cult? http:\/\/t.co\/f3kS0cxW",
  "id" : 274869266929553409,
  "created_at" : "2012-12-01 13:35:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274831810402332672",
  "geo" : { },
  "id_str" : "274835092952727552",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I won\u2019t stop you. Paper_draft.tex should be the file you\u2019re looking for ;)",
  "id" : 274835092952727552,
  "in_reply_to_status_id" : 274831810402332672,
  "created_at" : "2012-12-01 11:19:27 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 95 ],
      "url" : "https:\/\/t.co\/J9dCPDQe",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/opensnp_paper",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "274831060464959488",
  "geo" : { },
  "id_str" : "274831420340449280",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a I guess you\u2019re busy as well. But just in case, here\u2019s the git-repo: https:\/\/t.co\/J9dCPDQe",
  "id" : 274831420340449280,
  "in_reply_to_status_id" : 274831060464959488,
  "created_at" : "2012-12-01 11:04:51 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274829685760856064",
  "geo" : { },
  "id_str" : "274830633946206208",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a we could do this on the openSNP-paper. git, LaTeX, multiple authors. Should work.",
  "id" : 274830633946206208,
  "in_reply_to_status_id" : 274829685760856064,
  "created_at" : "2012-12-01 11:01:43 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]