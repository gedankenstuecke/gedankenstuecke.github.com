Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 3, 11 ],
      "id_str" : "14783339",
      "id" : 14783339
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 23, 39 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/kJBp9HUv8r",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/blink1_morse",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307233088231071744",
  "text" : "RT @voelker: Thanks to @gedankenstuecke's script (https:\/\/t.co\/kJBp9HUv8r) for blink(1) I'm having a wonderful evening of morse coding s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 10, 26 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/kJBp9HUv8r",
        "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/blink1_morse",
        "display_url" : "github.com\/gedankenstueck\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307233039916875776",
    "text" : "Thanks to @gedankenstuecke's script (https:\/\/t.co\/kJBp9HUv8r) for blink(1) I'm having a wonderful evening of morse coding swear-words",
    "id" : 307233039916875776,
    "created_at" : "2013-02-28 20:57:19 +0000",
    "user" : {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "protected" : false,
      "id_str" : "14783339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595572463381172224\/xb2DDLGV_normal.jpg",
      "id" : 14783339,
      "verified" : false
    }
  },
  "id" : 307233088231071744,
  "created_at" : "2013-02-28 20:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307230663738814464",
  "geo" : { },
  "id_str" : "307230777698041856",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker I\u2019m not slacking off, my morse code is running ;)",
  "id" : 307230777698041856,
  "in_reply_to_status_id" : 307230663738814464,
  "created_at" : "2013-02-28 20:48:20 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307230292165419009",
  "geo" : { },
  "id_str" : "307230401699663872",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker 30 Tage bis zur Abgabe der Masterarbeit. Geschrieben bislang: 35 Worte ;)",
  "id" : 307230401699663872,
  "in_reply_to_status_id" : 307230292165419009,
  "created_at" : "2013-02-28 20:46:50 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307230015534272512",
  "geo" : { },
  "id_str" : "307230131380957184",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Ja, die Idee hatte ich auch schon. Bin aber noch nicht dazu gekommen es zu implementieren. :)",
  "id" : 307230131380957184,
  "in_reply_to_status_id" : 307230015534272512,
  "created_at" : "2013-02-28 20:45:46 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307227275533897729",
  "geo" : { },
  "id_str" : "307227468698357760",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker und dann kannst du also \u201Cwer das liest ist doof!\u201D blinken lassen ;)",
  "id" : 307227468698357760,
  "in_reply_to_status_id" : 307227275533897729,
  "created_at" : "2013-02-28 20:35:11 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307227275533897729",
  "geo" : { },
  "id_str" : "307227400918429696",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker stimmt, das auch. Aber das Applications ist auch schon typisch :)",
  "id" : 307227400918429696,
  "in_reply_to_status_id" : 307227275533897729,
  "created_at" : "2013-02-28 20:34:55 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307226369392271360",
  "geo" : { },
  "id_str" : "307226755352121344",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Aber \/Applications hat ja verraten was du nutzt. ;)",
  "id" : 307226755352121344,
  "in_reply_to_status_id" : 307226369392271360,
  "created_at" : "2013-02-28 20:32:21 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307226369392271360",
  "geo" : { },
  "id_str" : "307226683788906496",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Und es gibt f\u00FCr jedes OS eine Version vom blink1-tool, also muss man auch da die \u201Crichtige\u201D Version erwischen.",
  "id" : 307226683788906496,
  "in_reply_to_status_id" : 307226369392271360,
  "created_at" : "2013-02-28 20:32:04 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307226369392271360",
  "geo" : { },
  "id_str" : "307226589182173184",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker vielleicht findest du jemanden der ebenfalls eins hat und ihr k\u00F6nnt euch nachrichten schicken ;)",
  "id" : 307226589182173184,
  "in_reply_to_status_id" : 307226369392271360,
  "created_at" : "2013-02-28 20:31:41 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307225860400877569",
  "geo" : { },
  "id_str" : "307225980957769728",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker yay! Great to see that it works!",
  "id" : 307225980957769728,
  "in_reply_to_status_id" : 307225860400877569,
  "created_at" : "2013-02-28 20:29:16 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/9NoOvEc8l7",
      "expanded_url" : "http:\/\/thingm.com\/blink1\/downloads\/blink1-tool-mac.zip",
      "display_url" : "thingm.com\/blink1\/downloa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "307223125840506880",
  "geo" : { },
  "id_str" : "307224495960236032",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Das ist das falsche Programm, du willst http:\/\/t.co\/9NoOvEc8l7 was die Commandozeilen-Variante ist :)",
  "id" : 307224495960236032,
  "in_reply_to_status_id" : 307223125840506880,
  "created_at" : "2013-02-28 20:23:22 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307216799722782720",
  "geo" : { },
  "id_str" : "307217062139408384",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker f\u00FCr es in der Shell mit \"python script.py -h\" aus. Dann sollte es dir die Commands anzeigen die gehen.",
  "id" : 307217062139408384,
  "in_reply_to_status_id" : 307216799722782720,
  "created_at" : "2013-02-28 19:53:50 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307176469703053312",
  "text" : "\u00ABWe have a saying for this: If you can\u2019t stand the heat, don\u2019t light up your hair!\u00BB",
  "id" : 307176469703053312,
  "created_at" : "2013-02-28 17:12:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mem_somerville",
      "screen_name" : "mem_somerville",
      "indices" : [ 3, 18 ],
      "id_str" : "15201021",
      "id" : 15201021
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mem_somerville\/status\/307162593771012096\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/s9N9T9DtFF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BENCwGqCQAABqw1.png",
      "id_str" : "307162593779400704",
      "id" : 307162593779400704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BENCwGqCQAABqw1.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 129
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 129
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 129
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 129
      }, {
        "h" : 129,
        "resize" : "crop",
        "w" : 129
      } ],
      "display_url" : "pic.twitter.com\/s9N9T9DtFF"
    } ],
    "hashtags" : [ {
      "text" : "ENCODE",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/gs9gsK28CB",
      "expanded_url" : "http:\/\/bit.ly\/15Ts6Qt",
      "display_url" : "bit.ly\/15Ts6Qt"
    } ]
  },
  "geo" : { },
  "id_str" : "307163829102587905",
  "text" : "RT @mem_somerville: More #ENCODE drama. What I hear: http:\/\/t.co\/gs9gsK28CB What I imagine: http:\/\/t.co\/s9N9T9DtFF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mem_somerville\/status\/307162593771012096\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/s9N9T9DtFF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BENCwGqCQAABqw1.png",
        "id_str" : "307162593779400704",
        "id" : 307162593779400704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BENCwGqCQAABqw1.png",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 129
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 129
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 129
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 129
        }, {
          "h" : 129,
          "resize" : "crop",
          "w" : 129
        } ],
        "display_url" : "pic.twitter.com\/s9N9T9DtFF"
      } ],
      "hashtags" : [ {
        "text" : "ENCODE",
        "indices" : [ 5, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/gs9gsK28CB",
        "expanded_url" : "http:\/\/bit.ly\/15Ts6Qt",
        "display_url" : "bit.ly\/15Ts6Qt"
      } ]
    },
    "geo" : { },
    "id_str" : "307162593771012096",
    "text" : "More #ENCODE drama. What I hear: http:\/\/t.co\/gs9gsK28CB What I imagine: http:\/\/t.co\/s9N9T9DtFF",
    "id" : 307162593771012096,
    "created_at" : "2013-02-28 16:17:23 +0000",
    "user" : {
      "name" : "mem_somerville",
      "screen_name" : "mem_somerville",
      "protected" : false,
      "id_str" : "15201021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929049262591115264\/ZIPrsQlr_normal.jpg",
      "id" : 15201021,
      "verified" : false
    }
  },
  "id" : 307163829102587905,
  "created_at" : "2013-02-28 16:22:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/PKRIZ0p8h0",
      "expanded_url" : "http:\/\/tinyurl.com\/btujknn",
      "display_url" : "tinyurl.com\/btujknn"
    }, {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ulJUWDxPpa",
      "expanded_url" : "http:\/\/tinyurl.com\/d8gt3z4",
      "display_url" : "tinyurl.com\/d8gt3z4"
    } ]
  },
  "geo" : { },
  "id_str" : "307143861086584832",
  "text" : "\"Changing just a tiny bit in my LaTeX tabular\" http:\/\/t.co\/PKRIZ0p8h0 \/via http:\/\/t.co\/ulJUWDxPpa",
  "id" : 307143861086584832,
  "created_at" : "2013-02-28 15:02:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ivYNMVaYEE",
      "expanded_url" : "http:\/\/i.imgur.com\/13aFWRZ.jpg",
      "display_url" : "i.imgur.com\/13aFWRZ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "307098461814259712",
  "text" : "Budget cuts in the subtitle department http:\/\/t.co\/ivYNMVaYEE",
  "id" : 307098461814259712,
  "created_at" : "2013-02-28 12:02:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/dzFFkC3CVR",
      "expanded_url" : "http:\/\/i.imgur.com\/U6YRgUp.jpg",
      "display_url" : "i.imgur.com\/U6YRgUp.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "307097101697949696",
  "text" : "Life is short http:\/\/t.co\/dzFFkC3CVR",
  "id" : 307097101697949696,
  "created_at" : "2013-02-28 11:57:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307089541746003969",
  "geo" : { },
  "id_str" : "307089908667928576",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Alles klar, heute Abend mal schauen ob Calibre das hinbekommt. :)",
  "id" : 307089908667928576,
  "in_reply_to_status_id" : 307089541746003969,
  "created_at" : "2013-02-28 11:28:34 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307080033330135041",
  "geo" : { },
  "id_str" : "307083617442619392",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a da f\u00E4llt mir ein das ich dir den Emperor of all Maladies noch nicht gegeben habe. Bekommst du heute Abend. Hast du Formatw\u00FCnsche?",
  "id" : 307083617442619392,
  "in_reply_to_status_id" : 307080033330135041,
  "created_at" : "2013-02-28 11:03:34 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307078262067183616",
  "geo" : { },
  "id_str" : "307080147524255744",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Okay, ich werde versuchen diesmal nicht 1 Jahr zu warten. ;)",
  "id" : 307080147524255744,
  "in_reply_to_status_id" : 307078262067183616,
  "created_at" : "2013-02-28 10:49:47 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307078262067183616",
  "geo" : { },
  "id_str" : "307078679463354368",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Nein, ich bin mit Feyerabend nur ganz rudiment\u00E4r vertraut. Sollte ich? :)",
  "id" : 307078679463354368,
  "in_reply_to_status_id" : 307078262067183616,
  "created_at" : "2013-02-28 10:43:57 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307074161291980800",
  "geo" : { },
  "id_str" : "307076189888069632",
  "in_reply_to_user_id" : 14700783,
  "text" : "@fischblog I had to remove the \"for most of us\" to make it fit into 140 characters ;)",
  "id" : 307076189888069632,
  "in_reply_to_status_id" : 307074161291980800,
  "created_at" : "2013-02-28 10:34:03 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CJCDwufi0J",
      "expanded_url" : "http:\/\/tinyurl.com\/cgyfa8t",
      "display_url" : "tinyurl.com\/cgyfa8t"
    } ]
  },
  "geo" : { },
  "id_str" : "307073882530127874",
  "text" : "\"With all the terrible ways that sex &amp; reproduction can go wrong it\u2019s amazing that [.] the system actually works\" http:\/\/t.co\/CJCDwufi0J",
  "id" : 307073882530127874,
  "created_at" : "2013-02-28 10:24:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/4OPQMbcX0T",
      "expanded_url" : "http:\/\/j.mp\/WjaGev",
      "display_url" : "j.mp\/WjaGev"
    } ]
  },
  "geo" : { },
  "id_str" : "307050815305170944",
  "text" : "Shaking Through: online documentary series about the birth of a song http:\/\/t.co\/4OPQMbcX0T",
  "id" : 307050815305170944,
  "created_at" : "2013-02-28 08:53:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/GgdcI7TYT0",
      "expanded_url" : "http:\/\/j.mp\/YHWdXD",
      "display_url" : "j.mp\/YHWdXD"
    } ]
  },
  "geo" : { },
  "id_str" : "307049109460754432",
  "text" : "Said to Lady Journos http:\/\/t.co\/GgdcI7TYT0",
  "id" : 307049109460754432,
  "created_at" : "2013-02-28 08:46:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/uZxnvhAp0x",
      "expanded_url" : "http:\/\/j.mp\/YC6Qto",
      "display_url" : "j.mp\/YC6Qto"
    } ]
  },
  "geo" : { },
  "id_str" : "307048838450003968",
  "text" : "Die H\u00F6lle f\u00FCr Atheisten http:\/\/t.co\/uZxnvhAp0x",
  "id" : 307048838450003968,
  "created_at" : "2013-02-28 08:45:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306996654031114240",
  "geo" : { },
  "id_str" : "307044207997108224",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat ab April hab ich daf\u00FCr wieder Zeit, dann komme ich mal rum. :)",
  "id" : 307044207997108224,
  "in_reply_to_status_id" : 306996654031114240,
  "created_at" : "2013-02-28 08:26:58 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307043091410468864",
  "text" : "Penis Percussionist",
  "id" : 307043091410468864,
  "created_at" : "2013-02-28 08:22:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Zauner",
      "screen_name" : "HansZauner",
      "indices" : [ 0, 11 ],
      "id_str" : "995259308",
      "id" : 995259308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307042351166132224",
  "geo" : { },
  "id_str" : "307042627251994626",
  "in_reply_to_user_id" : 995259308,
  "text" : "@HansZauner danke, ich lese gerade \u00ABThe Dark Lady of DNA\u00BB",
  "id" : 307042627251994626,
  "in_reply_to_status_id" : 307042351166132224,
  "created_at" : "2013-02-28 08:20:41 +0000",
  "in_reply_to_screen_name" : "HansZauner",
  "in_reply_to_user_id_str" : "995259308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307041799678095360",
  "text" : "\u00ABRosalind Franklin has become a feminist icon, the woman whose gifts were sacrificed to the greater glory of the male. \u00BB",
  "id" : 307041799678095360,
  "created_at" : "2013-02-28 08:17:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "ChaosTom",
      "screen_name" : "chaostom",
      "indices" : [ 7, 16 ],
      "id_str" : "71142746",
      "id" : 71142746
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 40, 44 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307035215451271168",
  "geo" : { },
  "id_str" : "307035558939607040",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @chaostom genau das, da muss der @scy sich ranhalten um erfolgreich zu sein.",
  "id" : 307035558939607040,
  "in_reply_to_status_id" : 307035215451271168,
  "created_at" : "2013-02-28 07:52:36 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 7, 11 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307031287124881408",
  "geo" : { },
  "id_str" : "307031516477812736",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ @scy nein...",
  "id" : 307031516477812736,
  "in_reply_to_status_id" : 307031287124881408,
  "created_at" : "2013-02-28 07:36:32 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/5M9UkDTLs2",
      "expanded_url" : "http:\/\/j.mp\/Z0qIGj",
      "display_url" : "j.mp\/Z0qIGj"
    } ]
  },
  "geo" : { },
  "id_str" : "306904709002850306",
  "text" : "Book Recommendations http:\/\/t.co\/5M9UkDTLs2",
  "id" : 306904709002850306,
  "created_at" : "2013-02-27 23:12:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neat",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306904340201889792",
  "text" : "RT @PhilippBayer: That's a nice university reading list. For one semester (4 mths), 6000 pages required reading. #neat https:\/\/t.co\/plyn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "neat",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/plynyeAvAr",
        "expanded_url" : "https:\/\/www.nydailynews.com\/blogs\/pageviews\/2013\/02\/w-h-audens-syllabus-will-make-your-college-courses-look-like-a-piece-of-cake",
        "display_url" : "nydailynews.com\/blogs\/pageview\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306903465844695041",
    "text" : "That's a nice university reading list. For one semester (4 mths), 6000 pages required reading. #neat https:\/\/t.co\/plynyeAvAr",
    "id" : 306903465844695041,
    "created_at" : "2013-02-27 23:07:42 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 306904340201889792,
  "created_at" : "2013-02-27 23:11:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/BvmwkPgvnM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zihp2Oepl4A",
      "display_url" : "youtube.com\/watch?v=zihp2O\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306902805866749952",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat Alles Gute! Trink ein Glas von dem billigen Gin f\u00FCr mich mit :) http:\/\/t.co\/BvmwkPgvnM",
  "id" : 306902805866749952,
  "created_at" : "2013-02-27 23:05:05 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/EOrVfMi1Pk",
      "expanded_url" : "http:\/\/i.imgur.com\/lR0DB92.jpg",
      "display_url" : "i.imgur.com\/lR0DB92.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "306894783245324288",
  "text" : "If you give me one more indian burn\u2026 http:\/\/t.co\/EOrVfMi1Pk",
  "id" : 306894783245324288,
  "created_at" : "2013-02-27 22:33:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306870356868726790",
  "text" : "\u00ABAlso Dr. Nippelhase hat gesagt du sollst weniger empfinden wenn wir knutschen.\u00BB",
  "id" : 306870356868726790,
  "created_at" : "2013-02-27 20:56:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "indices" : [ 3, 13 ],
      "id_str" : "7431072",
      "id" : 7431072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "job",
      "indices" : [ 15, 19 ]
    }, {
      "text" : "bioinformatics",
      "indices" : [ 20, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/C48fiAeC08",
      "expanded_url" : "http:\/\/careers.stackoverflow.com\/jobs\/31158",
      "display_url" : "careers.stackoverflow.com\/jobs\/31158"
    } ]
  },
  "geo" : { },
  "id_str" : "306865012151033857",
  "text" : "RT @yokofakun: #job #bioinformatics Web Programmer  at The Scripps Research Institute  http:\/\/t.co\/C48fiAeC08",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "job",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "bioinformatics",
        "indices" : [ 5, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/C48fiAeC08",
        "expanded_url" : "http:\/\/careers.stackoverflow.com\/jobs\/31158",
        "display_url" : "careers.stackoverflow.com\/jobs\/31158"
      } ]
    },
    "geo" : { },
    "id_str" : "306864735331172352",
    "text" : "#job #bioinformatics Web Programmer  at The Scripps Research Institute  http:\/\/t.co\/C48fiAeC08",
    "id" : 306864735331172352,
    "created_at" : "2013-02-27 20:33:48 +0000",
    "user" : {
      "name" : "Pierre Lindenbaum",
      "screen_name" : "yokofakun",
      "protected" : false,
      "id_str" : "7431072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667105051664609280\/jQ6Ile6W_normal.jpg",
      "id" : 7431072,
      "verified" : false
    }
  },
  "id" : 306865012151033857,
  "created_at" : "2013-02-27 20:34:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xeni Jardin \uD83E\uDD2F",
      "screen_name" : "xeni",
      "indices" : [ 3, 8 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306864091014774784",
  "text" : "RT @xeni: o_O Oh Sergey. Imagine if a female CEO said, \u201Cthis gadget makes one\u2019s vajayjay shrivel up.\u201D No, wait. Hilarious. There are no  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306863484094799872",
    "text" : "o_O Oh Sergey. Imagine if a female CEO said, \u201Cthis gadget makes one\u2019s vajayjay shrivel up.\u201D No, wait. Hilarious. There are no female CEOs!",
    "id" : 306863484094799872,
    "created_at" : "2013-02-27 20:28:50 +0000",
    "user" : {
      "name" : "Xeni Jardin \uD83E\uDD2F",
      "screen_name" : "xeni",
      "protected" : false,
      "id_str" : "767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879456546119311360\/sigIHyFi_normal.jpg",
      "id" : 767,
      "verified" : true
    }
  },
  "id" : 306864091014774784,
  "created_at" : "2013-02-27 20:31:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/TIIgJBRTwH",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?feature=player_embedded&v=GuKV2Z3eYTY#",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306860816391614465",
  "text" : "How Jesus started the zombie apocalypse: Fist of Jesus https:\/\/t.co\/TIIgJBRTwH!",
  "id" : 306860816391614465,
  "created_at" : "2013-02-27 20:18:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306856497340612608",
  "text" : "\u00ABZeig mir doch mal am Dramadreieck in welchem Winkel du hier zum Opfer gemacht wurdest.\u00BB",
  "id" : 306856497340612608,
  "created_at" : "2013-02-27 20:01:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306851007969783808",
  "geo" : { },
  "id_str" : "306851922671968256",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot and every hunter needs a dog ;)",
  "id" : 306851922671968256,
  "in_reply_to_status_id" : 306851007969783808,
  "created_at" : "2013-02-27 19:42:54 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306849179555221504",
  "geo" : { },
  "id_str" : "306850191347171328",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot (I always suspected that Dirty Paws is about gunshot residue...)",
  "id" : 306850191347171328,
  "in_reply_to_status_id" : 306849179555221504,
  "created_at" : "2013-02-27 19:36:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306849179555221504",
  "geo" : { },
  "id_str" : "306849812224040960",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot this is why you should never put a gun into my paw.",
  "id" : 306849812224040960,
  "in_reply_to_status_id" : 306849179555221504,
  "created_at" : "2013-02-27 19:34:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/RAwSojGhAp",
      "expanded_url" : "http:\/\/j.mp\/VadvNr",
      "display_url" : "j.mp\/VadvNr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0788364886, 8.5021040216 ]
  },
  "id_str" : "306848386152267776",
  "text" : "\u00ABcite all methods papers in helvetica neue\u00BB Scientists receive 12 million dollar grant to format references correctly http:\/\/t.co\/RAwSojGhAp",
  "id" : 306848386152267776,
  "created_at" : "2013-02-27 19:28:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "research",
      "indices" : [ 107, 116 ]
    }, {
      "text" : "phdchat",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "academia",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306846212563288064",
  "text" : "RT @mslogophiliac: The browser of a scientiest. Sadly, it's exactly what my computer in the lab looks like #research #phdchat #academia  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mslogophiliac\/status\/306760634182275072\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ORxH5BfYuI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BEHVK-gCEAAoga4.jpg",
        "id_str" : "306760634190663680",
        "id" : 306760634190663680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEHVK-gCEAAoga4.jpg",
        "sizes" : [ {
          "h" : 804,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/ORxH5BfYuI"
      } ],
      "hashtags" : [ {
        "text" : "research",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "phdchat",
        "indices" : [ 98, 106 ]
      }, {
        "text" : "academia",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306760634182275072",
    "text" : "The browser of a scientiest. Sadly, it's exactly what my computer in the lab looks like #research #phdchat #academia http:\/\/t.co\/ORxH5BfYuI",
    "id" : 306760634182275072,
    "created_at" : "2013-02-27 13:40:09 +0000",
    "user" : {
      "name" : "Yana Kuchirko",
      "screen_name" : "yanakuchirko",
      "protected" : false,
      "id_str" : "260021840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932378170073939969\/Z3FC4qLD_normal.jpg",
      "id" : 260021840,
      "verified" : false
    }
  },
  "id" : 306846212563288064,
  "created_at" : "2013-02-27 19:20:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/oiLjMy8ACQ",
      "expanded_url" : "http:\/\/j.mp\/VaboZO",
      "display_url" : "j.mp\/VaboZO"
    } ]
  },
  "geo" : { },
  "id_str" : "306845150825558016",
  "text" : "Man shot by dog? (Yes, it's Florida Man again) http:\/\/t.co\/oiLjMy8ACQ",
  "id" : 306845150825558016,
  "created_at" : "2013-02-27 19:15:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/XHswKgroVK",
      "expanded_url" : "http:\/\/j.mp\/Y0SCjq",
      "display_url" : "j.mp\/Y0SCjq"
    } ]
  },
  "geo" : { },
  "id_str" : "306843369827598336",
  "text" : "Was that all you wanted? http:\/\/t.co\/XHswKgroVK",
  "id" : 306843369827598336,
  "created_at" : "2013-02-27 19:08:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306818935246966785",
  "geo" : { },
  "id_str" : "306842123729244161",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube ehrlich gesagt haben wir den mehr weil ich unglaublich faul bin was Haushaltsarbeit angeht.",
  "id" : 306842123729244161,
  "in_reply_to_status_id" : 306818935246966785,
  "created_at" : "2013-02-27 19:03:57 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306777898088558593",
  "geo" : { },
  "id_str" : "306778462931275776",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel Kunst!",
  "id" : 306778462931275776,
  "in_reply_to_status_id" : 306777898088558593,
  "created_at" : "2013-02-27 14:50:59 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/rRVkeMQTXk",
      "expanded_url" : "http:\/\/instagr.am\/p\/WPPHtOBwui\/",
      "display_url" : "instagr.am\/p\/WPPHtOBwui\/"
    } ]
  },
  "geo" : { },
  "id_str" : "306775430558535681",
  "text" : "Street Art http:\/\/t.co\/rRVkeMQTXk",
  "id" : 306775430558535681,
  "created_at" : "2013-02-27 14:38:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306758554180792320",
  "text" : "\"Du hast da was Gelbes...\" - \"Ups, da hat sich ein Post-It in meinem Bart versteckt.\"",
  "id" : 306758554180792320,
  "created_at" : "2013-02-27 13:31:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306753852412133377",
  "geo" : { },
  "id_str" : "306754683622539264",
  "in_reply_to_user_id" : 1492631,
  "text" : "@lobot But maybe it's a donda?",
  "id" : 306754683622539264,
  "in_reply_to_status_id" : 306753852412133377,
  "created_at" : "2013-02-27 13:16:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/TC1ByHohWd",
      "expanded_url" : "http:\/\/i.imgur.com\/wxphyIt.jpg",
      "display_url" : "i.imgur.com\/wxphyIt.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "306753303776206848",
  "text" : "Identity crisis http:\/\/t.co\/TC1ByHohWd",
  "id" : 306753303776206848,
  "created_at" : "2013-02-27 13:11:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/51meNgW01K",
      "expanded_url" : "http:\/\/www.plosbiology.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pbio.1001498",
      "display_url" : "plosbiology.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306752779345596416",
  "text" : "Hitchhiking to Speciation http:\/\/t.co\/51meNgW01K",
  "id" : 306752779345596416,
  "created_at" : "2013-02-27 13:08:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/toYV4NSbIr",
      "expanded_url" : "http:\/\/www.plosmedicine.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pmed.1001395",
      "display_url" : "plosmedicine.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306748001446141952",
  "text" : "A Reality Checkpoint for Mobile Health: Three Challenges to Overcome http:\/\/t.co\/toYV4NSbIr",
  "id" : 306748001446141952,
  "created_at" : "2013-02-27 12:49:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/76ToXJviWd",
      "expanded_url" : "http:\/\/omicsomics.blogspot.de\/2013\/02\/post-agbt-longish-item-on-long.html",
      "display_url" : "omicsomics.blogspot.de\/2013\/02\/post-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306719125869309952",
  "text" : "A Longish Item on Long Sequencing http:\/\/t.co\/76ToXJviWd",
  "id" : 306719125869309952,
  "created_at" : "2013-02-27 10:55:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiveWordTEDTalks",
      "indices" : [ 19, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306717494255693824",
  "text" : "There is an actual #FiveWordTEDTalks that's titled \u00ABA giant bubble for debate\u00BB.",
  "id" : 306717494255693824,
  "created_at" : "2013-02-27 10:48:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306716535496519680",
  "text" : "Ich glaube ich habe zu lange in die Gene Ontology gestarrt. Ich kann die ersten Terms mit vollem Namen und Childnodes ansprechen.",
  "id" : 306716535496519680,
  "created_at" : "2013-02-27 10:44:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/cqwdPg5Er0",
      "expanded_url" : "http:\/\/animalnewyork.com\/2013\/veryshortfilmfest-winners-exhibit\/",
      "display_url" : "animalnewyork.com\/2013\/veryshort\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306709962921504769",
  "text" : "Wall of Vines: NSFW Very Short Film Festival Winners http:\/\/t.co\/cqwdPg5Er0",
  "id" : 306709962921504769,
  "created_at" : "2013-02-27 10:18:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306697826522525696",
  "geo" : { },
  "id_str" : "306698386889908224",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Great, let me know how well it works. :)",
  "id" : 306698386889908224,
  "in_reply_to_status_id" : 306697826522525696,
  "created_at" : "2013-02-27 09:32:48 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306695867639951360",
  "text" : "\u00ABLooks like reproductive isolation. Well, I guess that's life.\u00BB\u2014\u00ABI know: the only winning move is not to play\u2026\u00BB",
  "id" : 306695867639951360,
  "created_at" : "2013-02-27 09:22:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306573520090046465",
  "geo" : { },
  "id_str" : "306671208097796096",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv and it directly relates to your work. I always look out for conferences where you could submit it. :)",
  "id" : 306671208097796096,
  "in_reply_to_status_id" : 306573520090046465,
  "created_at" : "2013-02-27 07:44:48 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 3, 10 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/I8Lbu1aAxw",
      "expanded_url" : "http:\/\/feedly.com\/k\/X9ZBe4",
      "display_url" : "feedly.com\/k\/X9ZBe4"
    } ]
  },
  "geo" : { },
  "id_str" : "306663859857530880",
  "text" : "RT @mrgunn: Science and gun violence: why is the research so weak? http:\/\/t.co\/I8Lbu1aAxw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.feedly.com\" rel=\"nofollow\"\u003Efeedly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/I8Lbu1aAxw",
        "expanded_url" : "http:\/\/feedly.com\/k\/X9ZBe4",
        "display_url" : "feedly.com\/k\/X9ZBe4"
      } ]
    },
    "geo" : { },
    "id_str" : "306662326700998656",
    "text" : "Science and gun violence: why is the research so weak? http:\/\/t.co\/I8Lbu1aAxw",
    "id" : 306662326700998656,
    "created_at" : "2013-02-27 07:09:30 +0000",
    "user" : {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "protected" : false,
      "id_str" : "15237935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679914371770798080\/FBcokUq2_normal.jpg",
      "id" : 15237935,
      "verified" : false
    }
  },
  "id" : 306663859857530880,
  "created_at" : "2013-02-27 07:15:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0430\u0448\u0430 \u0412\u0430\u043B\u044C\u0442\u0435\u0440",
      "screen_name" : "BGI_Tech",
      "indices" : [ 0, 9 ],
      "id_str" : "57678427",
      "id" : 57678427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306582591673352192",
  "geo" : { },
  "id_str" : "306661100601102336",
  "in_reply_to_user_id" : 1077802308,
  "text" : "@BGI_Tech thx! :)",
  "id" : 306661100601102336,
  "in_reply_to_status_id" : 306582591673352192,
  "created_at" : "2013-02-27 07:04:38 +0000",
  "in_reply_to_screen_name" : "BGI_Genomics",
  "in_reply_to_user_id_str" : "1077802308",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306560229829668864",
  "geo" : { },
  "id_str" : "306660923895058432",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn lolnope, deadline is April 2.",
  "id" : 306660923895058432,
  "in_reply_to_status_id" : 306560229829668864,
  "created_at" : "2013-02-27 07:03:56 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 82, 88 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/Ep1lnQTWpS",
      "expanded_url" : "http:\/\/j.mp\/V6Q0EY",
      "display_url" : "j.mp\/V6Q0EY"
    } ]
  },
  "geo" : { },
  "id_str" : "306552856444534784",
  "text" : "Integrating Art and Science in Undergraduate Education http:\/\/t.co\/Ep1lnQTWpS \/cc @dvzrv",
  "id" : 306552856444534784,
  "created_at" : "2013-02-26 23:54:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306542234306740225",
  "geo" : { },
  "id_str" : "306542450602815488",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj die Per\u00FCcke? ;)",
  "id" : 306542450602815488,
  "in_reply_to_status_id" : 306542234306740225,
  "created_at" : "2013-02-26 23:13:10 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306541880865325058",
  "text" : "\u00ABGanz heimlich unter der Bettdecke lese ich Sascha Lobo.\u00BB",
  "id" : 306541880865325058,
  "created_at" : "2013-02-26 23:10:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306538455322726401",
  "geo" : { },
  "id_str" : "306539037555044352",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer und wo wir bei SRAs sind: Ich teste SNAP morgen, heute waren alle Cores belegt bei mir.",
  "id" : 306539037555044352,
  "in_reply_to_status_id" : 306538455322726401,
  "created_at" : "2013-02-26 22:59:36 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 14, 21 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/60H8jwtfQm",
      "expanded_url" : "http:\/\/varscan.sourceforge.net\/",
      "display_url" : "varscan.sourceforge.net"
    } ]
  },
  "in_reply_to_status_id_str" : "306538455322726401",
  "geo" : { },
  "id_str" : "306538728019615745",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @ewyler Eine war IIRC http:\/\/t.co\/60H8jwtfQm",
  "id" : 306538728019615745,
  "in_reply_to_status_id" : 306538455322726401,
  "created_at" : "2013-02-26 22:58:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 14, 21 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306538387366633472",
  "geo" : { },
  "id_str" : "306538628753010689",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @ewyler Aber ich bin sicher die wird sie noch nachliefern :)",
  "id" : 306538628753010689,
  "in_reply_to_status_id" : 306538387366633472,
  "created_at" : "2013-02-26 22:57:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 14, 21 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 27, 32 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306538387366633472",
  "geo" : { },
  "id_str" : "306538565221879808",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @ewyler Also @li5a hatte noch Alternativen vorgeschlagen die besser sein k\u00F6nnten. Habe nur die Namen schon vergessen.",
  "id" : 306538565221879808,
  "in_reply_to_status_id" : 306538387366633472,
  "created_at" : "2013-02-26 22:57:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306536345864638464",
  "text" : "RT @edyong209: It's important not to judge animal behaviour according to human values. Except for these frogs which are just wrong. http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/6e1ohNIFMg",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2013\/02\/26\/male-frog-extracts-and-fertilises-eggs-from-dead-female\/",
        "display_url" : "phenomena.nationalgeographic.com\/2013\/02\/26\/mal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306535836097335297",
    "text" : "It's important not to judge animal behaviour according to human values. Except for these frogs which are just wrong. http:\/\/t.co\/6e1ohNIFMg",
    "id" : 306535836097335297,
    "created_at" : "2013-02-26 22:46:53 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 306536345864638464,
  "created_at" : "2013-02-26 22:48:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Heller",
      "screen_name" : "plomlompom",
      "indices" : [ 94, 105 ],
      "id_str" : "7941582",
      "id" : 7941582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/VALDAruci0",
      "expanded_url" : "http:\/\/www.aaai.org\/ocs\/index.php\/ICWSM\/ICWSM11\/paper\/view\/2757\/3304",
      "display_url" : "aaai.org\/ocs\/index.php\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306533269632069632",
  "text" : "Modeling Internet Meme dynamics using SIR &amp; log-normal models. http:\/\/t.co\/VALDAruci0 \/HT @plomlompom",
  "id" : 306533269632069632,
  "created_at" : "2013-02-26 22:36:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/5We2H52aNq",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/blink1_morse",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "306337290685390848",
  "geo" : { },
  "id_str" : "306530259682082816",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker as promised: https:\/\/t.co\/5We2H52aNq",
  "id" : 306530259682082816,
  "in_reply_to_status_id" : 306337290685390848,
  "created_at" : "2013-02-26 22:24:43 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "indices" : [ 0, 10 ],
      "id_str" : "52584039",
      "id" : 52584039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306509869312262144",
  "geo" : { },
  "id_str" : "306510423975395328",
  "in_reply_to_user_id" : 52584039,
  "text" : "@johnhawks oh yes! I once stumbled upon a case where the rented ebook was still more expensive than the printed version bought\u2026",
  "id" : 306510423975395328,
  "in_reply_to_status_id" : 306509869312262144,
  "created_at" : "2013-02-26 21:05:54 +0000",
  "in_reply_to_screen_name" : "johnhawks",
  "in_reply_to_user_id_str" : "52584039",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hawks",
      "screen_name" : "johnhawks",
      "indices" : [ 0, 10 ],
      "id_str" : "52584039",
      "id" : 52584039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306509182939586560",
  "geo" : { },
  "id_str" : "306509690085453824",
  "in_reply_to_user_id" : 52584039,
  "text" : "@johnhawks and at the same time you can feel lucky if they offer an ebook version at all\u2026",
  "id" : 306509690085453824,
  "in_reply_to_status_id" : 306509182939586560,
  "created_at" : "2013-02-26 21:02:59 +0000",
  "in_reply_to_screen_name" : "johnhawks",
  "in_reply_to_user_id_str" : "52584039",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/8Vv8h0hSyk",
      "expanded_url" : "http:\/\/j.mp\/15gVxuC",
      "display_url" : "j.mp\/15gVxuC"
    } ]
  },
  "geo" : { },
  "id_str" : "306499613106524160",
  "text" : "Whorfian economics reconsidered: Why future tense? http:\/\/t.co\/8Vv8h0hSyk",
  "id" : 306499613106524160,
  "created_at" : "2013-02-26 20:22:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 0, 6 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306498146920439809",
  "geo" : { },
  "id_str" : "306498209038094336",
  "in_reply_to_user_id" : 21739255,
  "text" : "@fasel Gut, dann ist der Credit ja richtig angekommen :)",
  "id" : 306498209038094336,
  "in_reply_to_status_id" : 306498146920439809,
  "created_at" : "2013-02-26 20:17:22 +0000",
  "in_reply_to_screen_name" : "fasel",
  "in_reply_to_user_id_str" : "21739255",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Mulvany",
      "screen_name" : "IanMulvany",
      "indices" : [ 52, 63 ],
      "id_str" : "4339911",
      "id" : 4339911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/eFRzAiS873",
      "expanded_url" : "http:\/\/j.mp\/15gUtXF",
      "display_url" : "j.mp\/15gUtXF"
    } ]
  },
  "geo" : { },
  "id_str" : "306497330000044032",
  "text" : "XML jokes never get old. http:\/\/t.co\/eFRzAiS873 \/cc @IanMulvany",
  "id" : 306497330000044032,
  "created_at" : "2013-02-26 20:13:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/b6HMYVAEbv",
      "expanded_url" : "http:\/\/blogs.plos.org\/neuroanthropology\/2013\/02\/25\/funny-depictions-of-reactions-to-peer-review\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+plos%2Fblogs%2Fmain+%28Blogs+-+Main%29",
      "display_url" : "blogs.plos.org\/neuroanthropol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306495608972259328",
  "text" : "Reactions to Peer Review http:\/\/t.co\/b6HMYVAEbv",
  "id" : 306495608972259328,
  "created_at" : "2013-02-26 20:07:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fasel",
      "screen_name" : "fasel",
      "indices" : [ 63, 69 ],
      "id_str" : "21739255",
      "id" : 21739255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/3K1NTiRGTa",
      "expanded_url" : "http:\/\/www.dipity.com\/tatercakes\/Internet_Memes\/?mode=embed",
      "display_url" : "dipity.com\/tatercakes\/Int\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306494321983643649",
  "text" : "Awesome: The Internet Meme Timeline http:\/\/t.co\/3K1NTiRGTa \/HT @fasel (?)",
  "id" : 306494321983643649,
  "created_at" : "2013-02-26 20:01:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306485137477095424",
  "geo" : { },
  "id_str" : "306487221123420160",
  "in_reply_to_user_id" : 44625441,
  "text" : "@tuxwurf du wirst dich vielleicht nie wieder sorgenfrei anziehen k\u00F6nnen. Aber du wirst so auch nicht gebissen werden. ;)",
  "id" : 306487221123420160,
  "in_reply_to_status_id" : 306485137477095424,
  "created_at" : "2013-02-26 19:33:42 +0000",
  "in_reply_to_screen_name" : "juriroemer",
  "in_reply_to_user_id_str" : "44625441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306484571665469441",
  "geo" : { },
  "id_str" : "306484821956390912",
  "in_reply_to_user_id" : 44625441,
  "text" : "@tuxwurf du solltest mir dankbar sein! The more you know...",
  "id" : 306484821956390912,
  "in_reply_to_status_id" : 306484571665469441,
  "created_at" : "2013-02-26 19:24:10 +0000",
  "in_reply_to_screen_name" : "juriroemer",
  "in_reply_to_user_id_str" : "44625441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/G69wAbP6Zg",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Brown_recluse_spider",
      "display_url" : "en.m.wikipedia.org\/wiki\/Brown_rec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306483648146853889",
  "text" : "This is the spider that you should avoid: http:\/\/t.co\/G69wAbP6Zg",
  "id" : 306483648146853889,
  "created_at" : "2013-02-26 19:19:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/eobYoblM4A",
      "expanded_url" : "http:\/\/amzn.com\/k\/wSm8ewwDSnC6_-dAzvaomw",
      "display_url" : "amzn.com\/k\/wSm8ewwDSnC6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306482569430573056",
  "text" : "A spider's bite: This is in the US, not in Australia! http:\/\/t.co\/eobYoblM4A From here, there are two paths: lucky, and not-so-lucky....",
  "id" : 306482569430573056,
  "created_at" : "2013-02-26 19:15:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306479091916345344",
  "geo" : { },
  "id_str" : "306479350834929664",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lobot dass ich mich gerne ansabbern lasse hei\u00DFt nicht das der Hund dabei nicht gut riechen darf...",
  "id" : 306479350834929664,
  "in_reply_to_status_id" : 306479091916345344,
  "created_at" : "2013-02-26 19:02:26 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 10, 16 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306476362057781249",
  "geo" : { },
  "id_str" : "306478411004641280",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Lobot Hundeohrengeruch ist mein Fetisch. Nicht Mundgeruch!",
  "id" : 306478411004641280,
  "in_reply_to_status_id" : 306476362057781249,
  "created_at" : "2013-02-26 18:58:41 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306457055877804032",
  "geo" : { },
  "id_str" : "306457277001498624",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot that's a mixed martial arts move I'd love to see!",
  "id" : 306457277001498624,
  "in_reply_to_status_id" : 306457055877804032,
  "created_at" : "2013-02-26 17:34:43 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/kNFX9h75Fr",
      "expanded_url" : "http:\/\/bit.ly\/OVKD9w",
      "display_url" : "bit.ly\/OVKD9w"
    } ]
  },
  "geo" : { },
  "id_str" : "306456318166831105",
  "text" : "Following the last Florida Man story I'm not sure I want to know where he kept his squirrel... http:\/\/t.co\/kNFX9h75Fr",
  "id" : 306456318166831105,
  "created_at" : "2013-02-26 17:30:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bonk",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306454355991740416",
  "geo" : { },
  "id_str" : "306454538825654272",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot use the female erection knowledge you gained by reading #bonk!",
  "id" : 306454538825654272,
  "in_reply_to_status_id" : 306454355991740416,
  "created_at" : "2013-02-26 17:23:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306452471667126272",
  "geo" : { },
  "id_str" : "306452699438804993",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot just add the small penis. I doubt many females would come forward as well.",
  "id" : 306452699438804993,
  "in_reply_to_status_id" : 306452471667126272,
  "created_at" : "2013-02-26 17:16:31 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/wGXkkkfqSj",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Small_penis_rule",
      "display_url" : "en.wikipedia.org\/wiki\/Small_pen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306451578364243968",
  "text" : "RT @edyong209: Until Britain's libel laws are fixed, here's a guide to avoiding libel suits, using small penises http:\/\/t.co\/wGXkkkfqSj  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Choi \uD83D\uDE80",
        "screen_name" : "cqchoi",
        "indices" : [ 124, 131 ],
        "id_str" : "247336430",
        "id" : 247336430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/wGXkkkfqSj",
        "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Small_penis_rule",
        "display_url" : "en.wikipedia.org\/wiki\/Small_pen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306451379273207808",
    "text" : "Until Britain's libel laws are fixed, here's a guide to avoiding libel suits, using small penises http:\/\/t.co\/wGXkkkfqSj HT @cqchoi",
    "id" : 306451379273207808,
    "created_at" : "2013-02-26 17:11:17 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 306451578364243968,
  "created_at" : "2013-02-26 17:12:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306432203489943552",
  "text" : "\"What could possibly go wrong?\" - \"You could fall down 3 stories and break your neck.\" - \"Well, besides that... Help me get on that chair!\"",
  "id" : 306432203489943552,
  "created_at" : "2013-02-26 15:55:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306428908885131264",
  "text" : "\"Du willst das ich die Jalousie abreisse?\" - \"Abreissen ist so ein harscher Ausdruck. Sagen wir ich will, dass du der Schwerkraft aushilfst\"",
  "id" : 306428908885131264,
  "created_at" : "2013-02-26 15:41:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306418211216293892",
  "text" : "\"How do you solve this problem usually?\" - \"I just keep pushing random buttons until the beeping finally stops, works most of the time.\"",
  "id" : 306418211216293892,
  "created_at" : "2013-02-26 14:59:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/1ICM3MbCMj",
      "expanded_url" : "http:\/\/i.imgur.com\/8L4AVhj.jpg",
      "display_url" : "i.imgur.com\/8L4AVhj.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "306402923460579328",
  "text" : "It's dangerous... http:\/\/t.co\/1ICM3MbCMj",
  "id" : 306402923460579328,
  "created_at" : "2013-02-26 13:58:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/PvYOLZrmXy",
      "expanded_url" : "http:\/\/theoatmeal.com\/djtaf",
      "display_url" : "theoatmeal.com\/djtaf"
    } ]
  },
  "geo" : { },
  "id_str" : "306396179325911041",
  "text" : "Dumb Jokes That Are Funny http:\/\/t.co\/PvYOLZrmXy",
  "id" : 306396179325911041,
  "created_at" : "2013-02-26 13:31:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Richard Conniff",
      "screen_name" : "RichardConniff",
      "indices" : [ 61, 76 ],
      "id_str" : "25983346",
      "id" : 25983346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/yeDBRM9h4h",
      "expanded_url" : "https:\/\/fbcdn-sphotos-a-a.akamaihd.net\/hphotos-ak-prn1\/13050_4218828159969_1928642359_n.jpg",
      "display_url" : "fbcdn-sphotos-a-a.akamaihd.net\/hphotos-ak-prn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306385896394076160",
  "text" : "RT @edyong209: Juxtaposition win! https:\/\/t.co\/yeDBRM9h4h HT @richardconniff",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Conniff",
        "screen_name" : "RichardConniff",
        "indices" : [ 46, 61 ],
        "id_str" : "25983346",
        "id" : 25983346
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/yeDBRM9h4h",
        "expanded_url" : "https:\/\/fbcdn-sphotos-a-a.akamaihd.net\/hphotos-ak-prn1\/13050_4218828159969_1928642359_n.jpg",
        "display_url" : "fbcdn-sphotos-a-a.akamaihd.net\/hphotos-ak-prn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306383629435666432",
    "text" : "Juxtaposition win! https:\/\/t.co\/yeDBRM9h4h HT @richardconniff",
    "id" : 306383629435666432,
    "created_at" : "2013-02-26 12:42:04 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 306385896394076160,
  "created_at" : "2013-02-26 12:51:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/HZZML1RDqu",
      "expanded_url" : "http:\/\/tinyurl.com\/b3jf6bq",
      "display_url" : "tinyurl.com\/b3jf6bq"
    } ]
  },
  "geo" : { },
  "id_str" : "306368270670368768",
  "text" : "Effects of Individual Heterozygosity on Parasite Load &amp; Fitness http:\/\/t.co\/HZZML1RDqu",
  "id" : 306368270670368768,
  "created_at" : "2013-02-26 11:41:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/6L3WtW0mG6",
      "expanded_url" : "http:\/\/tinyurl.com\/avmr9ea",
      "display_url" : "tinyurl.com\/avmr9ea"
    } ]
  },
  "geo" : { },
  "id_str" : "306364158188855297",
  "text" : "Wow, I never thought about that before: Causes and Implications of Codon Usage Bias in RNA Viruses http:\/\/t.co\/6L3WtW0mG6",
  "id" : 306364158188855297,
  "created_at" : "2013-02-26 11:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/nnZnAVb4wy",
      "expanded_url" : "http:\/\/tinyurl.com\/bcsbn42",
      "display_url" : "tinyurl.com\/bcsbn42"
    } ]
  },
  "geo" : { },
  "id_str" : "306361418352037888",
  "text" : "Impact of Gene Duplication, Insertion, Deletion, Lateral Gene Transfer &amp; Sequencing Error on Orthology Inference http:\/\/t.co\/nnZnAVb4wy",
  "id" : 306361418352037888,
  "created_at" : "2013-02-26 11:13:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/3TozhiTeHt",
      "expanded_url" : "http:\/\/i.imgur.com\/HaZF55S.gif",
      "display_url" : "i.imgur.com\/HaZF55S.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "306359188311912448",
  "text" : "hypnotic cat gif http:\/\/t.co\/3TozhiTeHt",
  "id" : 306359188311912448,
  "created_at" : "2013-02-26 11:04:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306355704149733376",
  "geo" : { },
  "id_str" : "306356409543561216",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler Ich hatte bislang immer eine so miese Coverage das ich handgekl\u00F6ppelte L\u00F6sungen benutzt habe um \u00FCberhaupt was zu finden. ;)",
  "id" : 306356409543561216,
  "in_reply_to_status_id" : 306355704149733376,
  "created_at" : "2013-02-26 10:53:54 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 63, 68 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306355704149733376",
  "geo" : { },
  "id_str" : "306356274335985665",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler Dann w\u00FCrde ich es mit den samtools mal versuchen. Aber @li5a kann dir da vermutlich mehr zu sagen.",
  "id" : 306356274335985665,
  "in_reply_to_status_id" : 306355704149733376,
  "created_at" : "2013-02-26 10:53:22 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306355444060930050",
  "text" : "First world Open Access problems: My PLOS ONE RSS feed delivered too many interesting papers, I won't get any work done today.",
  "id" : 306355444060930050,
  "created_at" : "2013-02-26 10:50:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/HMIQ4f4k79",
      "expanded_url" : "http:\/\/elfaproject.wordpress.com\/2013\/02\/23\/getting-serious-about-laughter\/",
      "display_url" : "elfaproject.wordpress.com\/2013\/02\/23\/get\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306353749339811840",
  "text" : "Getting serious about laughter in academic talk http:\/\/t.co\/HMIQ4f4k79",
  "id" : 306353749339811840,
  "created_at" : "2013-02-26 10:43:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emanuel Wyler",
      "screen_name" : "ewyler",
      "indices" : [ 0, 7 ],
      "id_str" : "122329006",
      "id" : 122329006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306349733377617921",
  "geo" : { },
  "id_str" : "306350640358100993",
  "in_reply_to_user_id" : 122329006,
  "text" : "@ewyler Das kommt ein bisschen auf deine Read Depth an. Wie tief sind deine mRNA-Sequenzen?",
  "id" : 306350640358100993,
  "in_reply_to_status_id" : 306349733377617921,
  "created_at" : "2013-02-26 10:30:59 +0000",
  "in_reply_to_screen_name" : "ewyler",
  "in_reply_to_user_id_str" : "122329006",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan Kwan",
      "screen_name" : "hai_ren",
      "indices" : [ 3, 11 ],
      "id_str" : "625243",
      "id" : 625243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/iD9vNPqqx5",
      "expanded_url" : "http:\/\/twitpic.com\/c6y9c9",
      "display_url" : "twitpic.com\/c6y9c9"
    } ]
  },
  "geo" : { },
  "id_str" : "306348476571193344",
  "text" : "RT @hai_ren: Useful information to read while peeing http:\/\/t.co\/iD9vNPqqx5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/iD9vNPqqx5",
        "expanded_url" : "http:\/\/twitpic.com\/c6y9c9",
        "display_url" : "twitpic.com\/c6y9c9"
      } ]
    },
    "geo" : { },
    "id_str" : "306346631060656130",
    "text" : "Useful information to read while peeing http:\/\/t.co\/iD9vNPqqx5",
    "id" : 306346631060656130,
    "created_at" : "2013-02-26 10:15:03 +0000",
    "user" : {
      "name" : "Ivan Kwan",
      "screen_name" : "hai_ren",
      "protected" : false,
      "id_str" : "625243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/877793866849464321\/svsshVF0_normal.jpg",
      "id" : 625243,
      "verified" : false
    }
  },
  "id" : 306348476571193344,
  "created_at" : "2013-02-26 10:22:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306334885210116097",
  "geo" : { },
  "id_str" : "306335828928516096",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker I'll put the morse-code on github this evening if you're interested ;)",
  "id" : 306335828928516096,
  "in_reply_to_status_id" : 306334885210116097,
  "created_at" : "2013-02-26 09:32:07 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/sepA37QiIH",
      "expanded_url" : "http:\/\/j.mp\/YUpgFs",
      "display_url" : "j.mp\/YUpgFs"
    } ]
  },
  "geo" : { },
  "id_str" : "306319849125195776",
  "text" : "How to turn Morrissey into John Lennon http:\/\/t.co\/sepA37QiIH",
  "id" : 306319849125195776,
  "created_at" : "2013-02-26 08:28:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/uJKySoEXD7",
      "expanded_url" : "http:\/\/j.mp\/13ctJJq",
      "display_url" : "j.mp\/13ctJJq"
    } ]
  },
  "geo" : { },
  "id_str" : "306318103292309504",
  "text" : "Most things are better if\u2026 http:\/\/t.co\/uJKySoEXD7",
  "id" : 306318103292309504,
  "created_at" : "2013-02-26 08:21:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 3, 10 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/p2ocz3BTMC",
      "expanded_url" : "http:\/\/nym.ag\/Zw0xYS",
      "display_url" : "nym.ag\/Zw0xYS"
    } ]
  },
  "geo" : { },
  "id_str" : "306172789671481344",
  "text" : "RT @arikia: \"The vulva-submitters confess that they\u2019re sizing themselves up against women they see in porn.\" http:\/\/t.co\/p2ocz3BTMC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/p2ocz3BTMC",
        "expanded_url" : "http:\/\/nym.ag\/Zw0xYS",
        "display_url" : "nym.ag\/Zw0xYS"
      } ]
    },
    "geo" : { },
    "id_str" : "306172268818620416",
    "text" : "\"The vulva-submitters confess that they\u2019re sizing themselves up against women they see in porn.\" http:\/\/t.co\/p2ocz3BTMC",
    "id" : 306172268818620416,
    "created_at" : "2013-02-25 22:42:11 +0000",
    "user" : {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "protected" : false,
      "id_str" : "71654283",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897255084073025537\/5uB8YwJG_normal.jpg",
      "id" : 71654283,
      "verified" : false
    }
  },
  "id" : 306172789671481344,
  "created_at" : "2013-02-25 22:44:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306168688187432962",
  "text" : "\u00ABAlso du bist ganz okay f\u00FCr einen Menschen, nur im Vergleich zu den Katzen\u2026\u00BB",
  "id" : 306168688187432962,
  "created_at" : "2013-02-25 22:27:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/j8uLag8l9t",
      "expanded_url" : "http:\/\/cache.gawkerassets.com\/assets\/images\/4\/2010\/11\/shark-stealing-a-camera-lasers_01.jpg",
      "display_url" : "cache.gawkerassets.com\/assets\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306163988130045952",
  "text" : "Brain reacts to \u00ABPew Environment Group\u00BB http:\/\/t.co\/j8uLag8l9t",
  "id" : 306163988130045952,
  "created_at" : "2013-02-25 22:09:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/40BgJMjx18",
      "expanded_url" : "http:\/\/j.mp\/XBTpYX",
      "display_url" : "j.mp\/XBTpYX"
    } ]
  },
  "geo" : { },
  "id_str" : "306163492862427136",
  "text" : "Interpol establishes unit to fight illegal fishing http:\/\/t.co\/40BgJMjx18",
  "id" : 306163492862427136,
  "created_at" : "2013-02-25 22:07:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306162570451091457",
  "geo" : { },
  "id_str" : "306162763191967745",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Die haben mir hier in Frankfurt schon oft den Arsch gerettet weil seine Folien so gut waren :D",
  "id" : 306162763191967745,
  "in_reply_to_status_id" : 306162570451091457,
  "created_at" : "2013-02-25 22:04:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306161419903193089",
  "geo" : { },
  "id_str" : "306161815673511937",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Die guten, kurtzschen Evo\/Pop-Gen lectures. (The Horror! ;))",
  "id" : 306161815673511937,
  "in_reply_to_status_id" : 306161419903193089,
  "created_at" : "2013-02-25 22:00:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306161198968238080",
  "geo" : { },
  "id_str" : "306161430766448640",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Kein Problem, f\u00FCr irgendwas muss man ja diesen ganzen Popgen-Krams mal gelernt haben ;)",
  "id" : 306161430766448640,
  "in_reply_to_status_id" : 306161198968238080,
  "created_at" : "2013-02-25 21:59:07 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/lZc8YxeG5a",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Race_and_genetics#Lewontin.27s_argument_and_criticism",
      "display_url" : "en.wikipedia.org\/wiki\/Race_and_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "306142218408849409",
  "geo" : { },
  "id_str" : "306160763733688320",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Ich denke diese Arbeiten von Lewontin et al sind was du suchst: http:\/\/t.co\/lZc8YxeG5a",
  "id" : 306160763733688320,
  "in_reply_to_status_id" : 306142218408849409,
  "created_at" : "2013-02-25 21:56:28 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "indices" : [ 3, 9 ],
      "id_str" : "17567533",
      "id" : 17567533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/IT6BoMpEg0",
      "expanded_url" : "http:\/\/www.bbc.com\/future\/story\/20130221-the-wilder-side-of-sex",
      "display_url" : "bbc.com\/future\/story\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306135505391734784",
  "text" : "RT @BoraZ: The wilder side of sex http:\/\/t.co\/IT6BoMpEg0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/IT6BoMpEg0",
        "expanded_url" : "http:\/\/www.bbc.com\/future\/story\/20130221-the-wilder-side-of-sex",
        "display_url" : "bbc.com\/future\/story\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306134397080453120",
    "text" : "The wilder side of sex http:\/\/t.co\/IT6BoMpEg0",
    "id" : 306134397080453120,
    "created_at" : "2013-02-25 20:11:42 +0000",
    "user" : {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "protected" : false,
      "id_str" : "17567533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651779136\/b927bab618cdf46063f9c265817f3a8a_normal.jpeg",
      "id" : 17567533,
      "verified" : false
    }
  },
  "id" : 306135505391734784,
  "created_at" : "2013-02-25 20:16:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306133201137594368",
  "text" : "\u00ABWir sind auch n\u00E4her an den Hamster-Menschen als an der Durchschnittsbev\u00F6lkerung, oder?\u00BB",
  "id" : 306133201137594368,
  "created_at" : "2013-02-25 20:06:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306119402401697792",
  "geo" : { },
  "id_str" : "306131777121042432",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall das kenne ich auch, ich such dir nachher die Quelle raus wenn ich sie finde.",
  "id" : 306131777121042432,
  "in_reply_to_status_id" : 306119402401697792,
  "created_at" : "2013-02-25 20:01:17 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 3, 11 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/PAuIxqwg2P",
      "expanded_url" : "https:\/\/github.com\/jrnold\/ggthemes#excel-2003-theme",
      "display_url" : "github.com\/jrnold\/ggtheme\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306109953792434178",
  "text" : "RT @heyaudy: Excel 2003 theme for ggplot2 https:\/\/t.co\/PAuIxqwg2P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/PAuIxqwg2P",
        "expanded_url" : "https:\/\/github.com\/jrnold\/ggthemes#excel-2003-theme",
        "display_url" : "github.com\/jrnold\/ggtheme\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306109277070835712",
    "text" : "Excel 2003 theme for ggplot2 https:\/\/t.co\/PAuIxqwg2P",
    "id" : 306109277070835712,
    "created_at" : "2013-02-25 18:31:53 +0000",
    "user" : {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "protected" : false,
      "id_str" : "14534523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/923034147777474561\/zZvXWmSQ_normal.jpg",
      "id" : 14534523,
      "verified" : false
    }
  },
  "id" : 306109953792434178,
  "created_at" : "2013-02-25 18:34:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/RnAmMWY5yV",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/BpsResearchDigest\/~3\/t3qXuKMTjag\/witty-people-considered-particularly.html",
      "display_url" : "feedproxy.google.com\/~r\/BpsResearch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306109102319349762",
  "text" : "Those researchers should just spend time on Twitter: Are witty people considered particularly suitable for a fling? http:\/\/t.co\/RnAmMWY5yV",
  "id" : 306109102319349762,
  "created_at" : "2013-02-25 18:31:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/PwRgtPZy2A",
      "expanded_url" : "http:\/\/j.mp\/XWEDuU",
      "display_url" : "j.mp\/XWEDuU"
    } ]
  },
  "geo" : { },
  "id_str" : "306105139842928640",
  "text" : "Science kept posing interesting questions for monogamous mating systems http:\/\/t.co\/PwRgtPZy2A",
  "id" : 306105139842928640,
  "created_at" : "2013-02-25 18:15:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1083977879, 8.6915107662 ]
  },
  "id_str" : "306103182243819520",
  "text" : "\u00ABImmerhin, bald wissen wir was 'Nehmt euch ein Zimmer' in ganz vielen verschiedenen Sprachen hei\u00DFt!\u00BB",
  "id" : 306103182243819520,
  "created_at" : "2013-02-25 18:07:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306074581792342016",
  "geo" : { },
  "id_str" : "306101415745568768",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall spontan w\u00FCrde ich an HapMap und die 1000Genomes-Datens\u00E4tze denken. Meinst du sowas oder willst du Literatur?",
  "id" : 306101415745568768,
  "in_reply_to_status_id" : 306074581792342016,
  "created_at" : "2013-02-25 18:00:39 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "indices" : [ 3, 11 ],
      "id_str" : "14317484",
      "id" : 14317484
    }, {
      "name" : "Sam Steiner",
      "screen_name" : "samsteiner",
      "indices" : [ 88, 99 ],
      "id_str" : "179610168",
      "id" : 179610168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/nxxne2kBfO",
      "expanded_url" : "http:\/\/www.businessinsider.com\/captain-announcement-after-all-four-engines-failed-2013-2",
      "display_url" : "businessinsider.com\/captain-announ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306030779685810177",
  "text" : "RT @philbee: \u201EWe have a small problem. All four engines have stopped.\u201C Grossartig. (via @samsteiner)\nhttp:\/\/t.co\/nxxne2kBfO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Steiner",
        "screen_name" : "samsteiner",
        "indices" : [ 75, 86 ],
        "id_str" : "179610168",
        "id" : 179610168
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/nxxne2kBfO",
        "expanded_url" : "http:\/\/www.businessinsider.com\/captain-announcement-after-all-four-engines-failed-2013-2",
        "display_url" : "businessinsider.com\/captain-announ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "306028106060275712",
    "text" : "\u201EWe have a small problem. All four engines have stopped.\u201C Grossartig. (via @samsteiner)\nhttp:\/\/t.co\/nxxne2kBfO",
    "id" : 306028106060275712,
    "created_at" : "2013-02-25 13:09:20 +0000",
    "user" : {
      "name" : "philippe braun",
      "screen_name" : "philbee",
      "protected" : false,
      "id_str" : "14317484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478561547107573761\/Ha5geiUM_normal.jpeg",
      "id" : 14317484,
      "verified" : false
    }
  },
  "id" : 306030779685810177,
  "created_at" : "2013-02-25 13:19:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/a0mWIeoBn2",
      "expanded_url" : "http:\/\/imgur.com\/OnI8iez",
      "display_url" : "imgur.com\/OnI8iez"
    } ]
  },
  "geo" : { },
  "id_str" : "306012997225168897",
  "text" : "Jesus has all the answers! http:\/\/t.co\/a0mWIeoBn2",
  "id" : 306012997225168897,
  "created_at" : "2013-02-25 12:09:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/rRiUnPYR8d",
      "expanded_url" : "http:\/\/gedankentraeger.de\/?p=3237",
      "display_url" : "gedankentraeger.de\/?p=3237"
    } ]
  },
  "geo" : { },
  "id_str" : "306007317109936128",
  "text" : "Der Autismus unserer Zeit. Zur Popularit\u00E4t einer Metapher http:\/\/t.co\/rRiUnPYR8d",
  "id" : 306007317109936128,
  "created_at" : "2013-02-25 11:46:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/nfTz22C56I",
      "expanded_url" : "http:\/\/tinyurl.com\/asxmxhe",
      "display_url" : "tinyurl.com\/asxmxhe"
    } ]
  },
  "geo" : { },
  "id_str" : "306006191862079488",
  "text" : "Cookie withdrawal: \"my brain starts telling me that chocolate is the breakfast of champions!\" http:\/\/t.co\/nfTz22C56I",
  "id" : 306006191862079488,
  "created_at" : "2013-02-25 11:42:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305982817106542593",
  "text" : "Is anyone aware whether BGI offers de novo sequencing or just re-sequencing?",
  "id" : 305982817106542593,
  "created_at" : "2013-02-25 10:09:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305832634183987201",
  "text" : "RT @genetics_blog: Assemblathon 2 paper an indictment of de novo assembly. We're doing it all wrong in #bioinformatics http:\/\/t.co\/gCmg3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 84, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/gCmg36zDXZ",
        "expanded_url" : "http:\/\/ivory.idyll.org\/blog\/thoughts-on-assemblathon-2.html",
        "display_url" : "ivory.idyll.org\/blog\/thoughts-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305671958597603328",
    "text" : "Assemblathon 2 paper an indictment of de novo assembly. We're doing it all wrong in #bioinformatics http:\/\/t.co\/gCmg36zDXZ",
    "id" : 305671958597603328,
    "created_at" : "2013-02-24 13:34:08 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "strnr",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 305832634183987201,
  "created_at" : "2013-02-25 00:12:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cae Vye",
      "screen_name" : "CaeVye",
      "indices" : [ 70, 77 ],
      "id_str" : "31104704",
      "id" : 31104704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/FLHMWXHyGn",
      "expanded_url" : "http:\/\/youtu.be\/PpBVnunZg-w",
      "display_url" : "youtu.be\/PpBVnunZg-w"
    } ]
  },
  "geo" : { },
  "id_str" : "305830151625785344",
  "text" : "Extremschlittenfahrer, eine Dokumentation: http:\/\/t.co\/FLHMWXHyGn \/HT @CaeVye",
  "id" : 305830151625785344,
  "created_at" : "2013-02-25 00:02:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 8, 18 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305827067986059265",
  "geo" : { },
  "id_str" : "305827143760351232",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Fischblog dich habe ich schon mit eingerechnet ;)",
  "id" : 305827143760351232,
  "in_reply_to_status_id" : 305827067986059265,
  "created_at" : "2013-02-24 23:50:47 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305822325490720768",
  "geo" : { },
  "id_str" : "305826788997754880",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog meiner Timeline nach zu urteilen geht es noch mindestens 5 weiteren Leuten neben euch genauso. ;)",
  "id" : 305826788997754880,
  "in_reply_to_status_id" : 305822325490720768,
  "created_at" : "2013-02-24 23:49:23 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305817445854232576",
  "geo" : { },
  "id_str" : "305817842304028672",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus told ya!",
  "id" : 305817842304028672,
  "in_reply_to_status_id" : 305817445854232576,
  "created_at" : "2013-02-24 23:13:50 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305817048892706816",
  "geo" : { },
  "id_str" : "305817335548235777",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus you will be puzzled. and then there will be Nutella.",
  "id" : 305817335548235777,
  "in_reply_to_status_id" : 305817048892706816,
  "created_at" : "2013-02-24 23:11:49 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/UKY7LKGylZ",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/02\/24\/nutellaaarrghhhh.html",
      "display_url" : "boingboing.net\/2013\/02\/24\/nut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305815608740700163",
  "text" : "Not sure why I invested this 8 minutes of my life. http:\/\/t.co\/UKY7LKGylZ",
  "id" : 305815608740700163,
  "created_at" : "2013-02-24 23:04:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 25, 32 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "L3viathan",
      "screen_name" : "L3viathan2142",
      "indices" : [ 96, 110 ],
      "id_str" : "23305817",
      "id" : 23305817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/rJ5dN7FtWf",
      "expanded_url" : "http:\/\/robrhinehart.com\/?p=298",
      "display_url" : "robrhinehart.com\/?p=298"
    } ]
  },
  "geo" : { },
  "id_str" : "305782798877331456",
  "text" : "This probably will drive @mrgunn insane: \u00ABHow I Stopped Eating Food\u00BB http:\/\/t.co\/rJ5dN7FtWf \/HT @L3viathan2142",
  "id" : 305782798877331456,
  "created_at" : "2013-02-24 20:54:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/HJlDBM6DwA",
      "expanded_url" : "http:\/\/i.imgur.com\/RxLkcuL.jpg",
      "display_url" : "i.imgur.com\/RxLkcuL.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "305778310284206080",
  "text" : "Uh oh, the sea level rise is real after all! http:\/\/t.co\/HJlDBM6DwA",
  "id" : 305778310284206080,
  "created_at" : "2013-02-24 20:36:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon J Dixon",
      "screen_name" : "WoodinRivers",
      "indices" : [ 3, 16 ],
      "id_str" : "422971305",
      "id" : 422971305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305754003738861568",
  "text" : "RT @WoodinRivers: Oh goody. Just what the world needs, another animal-cock-science study. Otter penises = ecological health http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/kDKkqErfHY",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/nature\/21534742",
        "display_url" : "bbc.co.uk\/nature\/21534742"
      } ]
    },
    "geo" : { },
    "id_str" : "305749961876856832",
    "text" : "Oh goody. Just what the world needs, another animal-cock-science study. Otter penises = ecological health http:\/\/t.co\/kDKkqErfHY",
    "id" : 305749961876856832,
    "created_at" : "2013-02-24 18:44:06 +0000",
    "user" : {
      "name" : "Simon J Dixon",
      "screen_name" : "WoodinRivers",
      "protected" : false,
      "id_str" : "422971305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/865165715967328256\/2a0JRmeZ_normal.jpg",
      "id" : 422971305,
      "verified" : false
    }
  },
  "id" : 305754003738861568,
  "created_at" : "2013-02-24 19:00:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/xiU44D8EdV",
      "expanded_url" : "http:\/\/i2.kym-cdn.com\/photos\/images\/newsfeed\/000\/189\/868\/7dd846ea-97c1-45fc-bba8-8840b683836a.jpg",
      "display_url" : "i2.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "305751326871150592",
  "geo" : { },
  "id_str" : "305752474130718720",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj http:\/\/t.co\/xiU44D8EdV",
  "id" : 305752474130718720,
  "in_reply_to_status_id" : 305751326871150592,
  "created_at" : "2013-02-24 18:54:05 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305750808715227136",
  "geo" : { },
  "id_str" : "305750908212502528",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon Klar, den Kerl der mich an Dawkins erinnert, right? ;)",
  "id" : 305750908212502528,
  "in_reply_to_status_id" : 305750808715227136,
  "created_at" : "2013-02-24 18:47:51 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 10, 17 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305750011407392768",
  "geo" : { },
  "id_str" : "305750233177014272",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @lsanoj \u00ABwenn du nicht so abstimmst wie ich will dann machst du einen kleinen Spaziergang zum Grund des Rhein in Betonschuhen\u00BB?",
  "id" : 305750233177014272,
  "in_reply_to_status_id" : 305750011407392768,
  "created_at" : "2013-02-24 18:45:10 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 10, 17 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305749233829560320",
  "geo" : { },
  "id_str" : "305749412297187328",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @lsanoj Jaja, ich weiss. Da kann ich dir nicht einfach den Voting-Key per Mail forwarden ;)",
  "id" : 305749412297187328,
  "in_reply_to_status_id" : 305749233829560320,
  "created_at" : "2013-02-24 18:41:55 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305749010831007744",
  "geo" : { },
  "id_str" : "305749064576811008",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon fair enough.",
  "id" : 305749064576811008,
  "in_reply_to_status_id" : 305749010831007744,
  "created_at" : "2013-02-24 18:40:32 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 28, 37 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305748309925056512",
  "geo" : { },
  "id_str" : "305748818434068480",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj sehr gut. Dann wird @Senficon nicht b\u00F6se sein das ich ganz vergessen habe zur Wahl zur gehen :P",
  "id" : 305748818434068480,
  "in_reply_to_status_id" : 305748309925056512,
  "created_at" : "2013-02-24 18:39:33 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "indices" : [ 3, 12 ],
      "id_str" : "3453971",
      "id" : 3453971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305744529686921217",
  "text" : "RT @blacktar: Interesting; AirBnB for places to camp, park your RV\/Camper. \"hostacamper - quiet campsites in urban neighbourhoods\" http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/50KPWSPHTi",
        "expanded_url" : "http:\/\/buff.ly\/YqzhMC",
        "display_url" : "buff.ly\/YqzhMC"
      } ]
    },
    "geo" : { },
    "id_str" : "305744424728678400",
    "text" : "Interesting; AirBnB for places to camp, park your RV\/Camper. \"hostacamper - quiet campsites in urban neighbourhoods\" http:\/\/t.co\/50KPWSPHTi",
    "id" : 305744424728678400,
    "created_at" : "2013-02-24 18:22:05 +0000",
    "user" : {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "protected" : false,
      "id_str" : "3453971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897036682721153024\/sPNcTIBm_normal.jpg",
      "id" : 3453971,
      "verified" : false
    }
  },
  "id" : 305744529686921217,
  "created_at" : "2013-02-24 18:22:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/5bTm0NiQzZ",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/2013\/02\/24\/the-language-gene-and-womens-wagging-tongues\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305742910840795136",
  "text" : "The \u201CLanguage\u201D Gene and Women\u2019s Wagging Tongues http:\/\/t.co\/5bTm0NiQzZ",
  "id" : 305742910840795136,
  "created_at" : "2013-02-24 18:16:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "overlyhonestmethods",
      "indices" : [ 84, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/yM4ygrxth9",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/biology\/comments\/193fj5\/these_fucking_scissors\/c8kf5t4",
      "display_url" : "reddit.com\/r\/biology\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305733579604914176",
  "text" : "Useless things you can find in any biology lab. Many which aren\u2019t  mentioned in the #overlyhonestmethods http:\/\/t.co\/yM4ygrxth9",
  "id" : 305733579604914176,
  "created_at" : "2013-02-24 17:39:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305720111858339840",
  "geo" : { },
  "id_str" : "305728920395841538",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Ah, okay. I look forward to hear what you\u2019ve been up to since finishing your thesis. :)",
  "id" : 305728920395841538,
  "in_reply_to_status_id" : 305720111858339840,
  "created_at" : "2013-02-24 17:20:29 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 3, 10 ],
      "id_str" : "15237935",
      "id" : 15237935
    }, {
      "name" : "Drug Monkey",
      "screen_name" : "drugmonkeyblog",
      "indices" : [ 84, 99 ],
      "id_str" : "26589498",
      "id" : 26589498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MDe7a7mcSc",
      "expanded_url" : "http:\/\/j.mp\/123PPyg",
      "display_url" : "j.mp\/123PPyg"
    } ]
  },
  "geo" : { },
  "id_str" : "305716026262290433",
  "text" : "RT @mrgunn: I had no idea there was a legal limit, but clearly it's set too low. RT @drugmonkeyblog Driving test http:\/\/t.co\/MDe7a7mcSc  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Drug Monkey",
        "screen_name" : "drugmonkeyblog",
        "indices" : [ 72, 87 ],
        "id_str" : "26589498",
        "id" : 26589498
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cannabis",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/MDe7a7mcSc",
        "expanded_url" : "http:\/\/j.mp\/123PPyg",
        "display_url" : "j.mp\/123PPyg"
      } ]
    },
    "geo" : { },
    "id_str" : "305715190513668096",
    "text" : "I had no idea there was a legal limit, but clearly it's set too low. RT @drugmonkeyblog Driving test http:\/\/t.co\/MDe7a7mcSc #cannabis",
    "id" : 305715190513668096,
    "created_at" : "2013-02-24 16:25:55 +0000",
    "user" : {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "protected" : false,
      "id_str" : "15237935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679914371770798080\/FBcokUq2_normal.jpg",
      "id" : 15237935,
      "verified" : false
    }
  },
  "id" : 305716026262290433,
  "created_at" : "2013-02-24 16:29:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FauxEncode",
      "screen_name" : "FakeEncode",
      "indices" : [ 3, 14 ],
      "id_str" : "1214359279",
      "id" : 1214359279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305714132265627649",
  "text" : "RT @FakeEncode: Looking for things to do after ENCODE? Join me in working on the NIH BRAIN MAP project - BIG SCIENCE for the win.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305713312698626048",
    "text" : "Looking for things to do after ENCODE? Join me in working on the NIH BRAIN MAP project - BIG SCIENCE for the win.",
    "id" : 305713312698626048,
    "created_at" : "2013-02-24 16:18:28 +0000",
    "user" : {
      "name" : "FauxEncode",
      "screen_name" : "FakeEncode",
      "protected" : false,
      "id_str" : "1214359279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3299719190\/35657fcf93bb0824f120cea1e6439be3_normal.png",
      "id" : 1214359279,
      "verified" : false
    }
  },
  "id" : 305714132265627649,
  "created_at" : "2013-02-24 16:21:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/oQfxXVAf3F",
      "expanded_url" : "http:\/\/i.imgur.com\/tuWCYos.jpg",
      "display_url" : "i.imgur.com\/tuWCYos.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "305712138356396032",
  "text" : "The science of dog whistles http:\/\/t.co\/oQfxXVAf3F",
  "id" : 305712138356396032,
  "created_at" : "2013-02-24 16:13:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305700609489776642",
  "geo" : { },
  "id_str" : "305702010706096128",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a great, you're back in for work?",
  "id" : 305702010706096128,
  "in_reply_to_status_id" : 305700609489776642,
  "created_at" : "2013-02-24 15:33:33 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305697756889088000",
  "geo" : { },
  "id_str" : "305700476253532160",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a if you don't mind a half hour commute into downtown: yes.",
  "id" : 305700476253532160,
  "in_reply_to_status_id" : 305697756889088000,
  "created_at" : "2013-02-24 15:27:27 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovelocks",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305686361296486401",
  "text" : "Der \u00ABKnotenk\u00F6nig\u00BB ben\u00F6tigt ein Vorh\u00E4ngeschloss um sich ewig zu binden. Ich lasse das mal so stehen... #lovelocks",
  "id" : 305686361296486401,
  "created_at" : "2013-02-24 14:31:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/OqRjBdhmqZ",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/funny\/comments\/194ilz\/my_boyfriend_of_7_years_and_i_are_both_physicists\/",
      "display_url" : "reddit.com\/r\/funny\/commen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305664143875268608",
  "text" : "\u00ABI\u2019d marry someone who can write a proposal using LaTeX.\u00BB \u2013 \u00ABShould have used the microtype package, though.\u00BB http:\/\/t.co\/OqRjBdhmqZ",
  "id" : 305664143875268608,
  "created_at" : "2013-02-24 13:03:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/uXZMsdlNdP",
      "expanded_url" : "http:\/\/gifrific.com\/wp-content\/uploads\/2013\/02\/Gorilla-Rolling-Around-in-Leaves.gif",
      "display_url" : "gifrific.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305658890824069120",
  "text" : "They See Me Rollin\u2019\u2026 http:\/\/t.co\/uXZMsdlNdP",
  "id" : 305658890824069120,
  "created_at" : "2013-02-24 12:42:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305651204803923968",
  "geo" : { },
  "id_str" : "305651687052419072",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Ja, es gibt schon einen Grund wieso Gould \u00ABThe Mismeasure of Man\u00BB Anfang der 80er geschrieben hat ;)",
  "id" : 305651687052419072,
  "in_reply_to_status_id" : 305651204803923968,
  "created_at" : "2013-02-24 12:13:35 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/3NYlHp8Ltr",
      "expanded_url" : "http:\/\/j.mp\/W2j8Ph",
      "display_url" : "j.mp\/W2j8Ph"
    } ]
  },
  "geo" : { },
  "id_str" : "305651468667596800",
  "text" : "Cardboard Computer http:\/\/t.co\/3NYlHp8Ltr",
  "id" : 305651468667596800,
  "created_at" : "2013-02-24 12:12:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305643481420935168",
  "geo" : { },
  "id_str" : "305646444466040833",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Und dann will er Probanden aus allen L\u00E4ndern mixen? Da wird ihm leicht die Populationsgenetik auf die F\u00FC\u00DFe fallen\u2026",
  "id" : 305646444466040833,
  "in_reply_to_status_id" : 305643481420935168,
  "created_at" : "2013-02-24 11:52:45 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "indices" : [ 3, 15 ],
      "id_str" : "561297215",
      "id" : 561297215
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jrossibarra\/status\/305461845827919873\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/wbf3KhQNEm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD037i2CIAA3cde.jpg",
      "id_str" : "305461845836308480",
      "id" : 305461845836308480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD037i2CIAA3cde.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/wbf3KhQNEm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305488134672625664",
  "text" : "RT @jrossibarra: Just purchased some new custom-designed DNA simulation hardware. Awesome stuff. http:\/\/t.co\/wbf3KhQNEm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jrossibarra\/status\/305461845827919873\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/wbf3KhQNEm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BD037i2CIAA3cde.jpg",
        "id_str" : "305461845836308480",
        "id" : 305461845836308480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD037i2CIAA3cde.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/wbf3KhQNEm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305461845827919873",
    "text" : "Just purchased some new custom-designed DNA simulation hardware. Awesome stuff. http:\/\/t.co\/wbf3KhQNEm",
    "id" : 305461845827919873,
    "created_at" : "2013-02-23 23:39:14 +0000",
    "user" : {
      "name" : "Jeffrey Ross-Ibarra",
      "screen_name" : "jrossibarra",
      "protected" : false,
      "id_str" : "561297215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656691317519466496\/tJ966bzU_normal.png",
      "id" : 561297215,
      "verified" : false
    }
  },
  "id" : 305488134672625664,
  "created_at" : "2013-02-24 01:23:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/uwo4MlOKsW",
      "expanded_url" : "http:\/\/imgur.com\/8veFouN",
      "display_url" : "imgur.com\/8veFouN"
    } ]
  },
  "geo" : { },
  "id_str" : "305485678043598848",
  "text" : "I\u2019ve smelled things you people wouldn\u2019t believe\u2026 http:\/\/t.co\/uwo4MlOKsW",
  "id" : 305485678043598848,
  "created_at" : "2013-02-24 01:13:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "indices" : [ 3, 12 ],
      "id_str" : "43360175",
      "id" : 43360175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grammar",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/yHsrqIM3qf",
      "expanded_url" : "http:\/\/bit.ly\/15Ehgxw",
      "display_url" : "bit.ly\/15Ehgxw"
    } ]
  },
  "geo" : { },
  "id_str" : "305479164008484865",
  "text" : "RT @JoonasD6: Grey or gray? It depends on the context... http:\/\/t.co\/yHsrqIM3qf #grammar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grammar",
        "indices" : [ 66, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/yHsrqIM3qf",
        "expanded_url" : "http:\/\/bit.ly\/15Ehgxw",
        "display_url" : "bit.ly\/15Ehgxw"
      } ]
    },
    "geo" : { },
    "id_str" : "305478912224403458",
    "text" : "Grey or gray? It depends on the context... http:\/\/t.co\/yHsrqIM3qf #grammar",
    "id" : 305478912224403458,
    "created_at" : "2013-02-24 00:47:02 +0000",
    "user" : {
      "name" : "Joonas M\u00E4kinen",
      "screen_name" : "JoonasD6",
      "protected" : false,
      "id_str" : "43360175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/238120339\/Pi3_150x150_normal.jpg",
      "id" : 43360175,
      "verified" : false
    }
  },
  "id" : 305479164008484865,
  "created_at" : "2013-02-24 00:48:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/EgiQY6NjrZ",
      "expanded_url" : "http:\/\/j.mp\/13AvN9D",
      "display_url" : "j.mp\/13AvN9D"
    } ]
  },
  "geo" : { },
  "id_str" : "305475385590702080",
  "text" : "\u00ABMy results would have been significant, if it wasn\u2019t for those other meddling tests!\u00BB http:\/\/t.co\/EgiQY6NjrZ",
  "id" : 305475385590702080,
  "created_at" : "2013-02-24 00:33:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/oEJHcX3ghz",
      "expanded_url" : "http:\/\/myrmecos.net\/2013\/02\/23\/a-simpler-explanation-for-the-sociality-haplodiploidy-connection\/",
      "display_url" : "myrmecos.net\/2013\/02\/23\/a-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305470843381764096",
  "text" : "news on \u00ABthe kin selection debate- where happy, well-adjusted biologists transform into livid, spittle-flecked orcs\u00BB http:\/\/t.co\/oEJHcX3ghz",
  "id" : 305470843381764096,
  "created_at" : "2013-02-24 00:14:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305469311131217920",
  "text" : "\u00AB[\u2026] while I continue to have considerable respect for your versatility as scientist [\u2026], I am unable to respect you as a person.\u00BB",
  "id" : 305469311131217920,
  "created_at" : "2013-02-24 00:08:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Elsevier",
      "screen_name" : "FakeElsevier",
      "indices" : [ 3, 16 ],
      "id_str" : "486169804",
      "id" : 486169804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305458877997133824",
  "text" : "RT @FakeElsevier: WH orders all fed-funded research to be OA after 1yr. Thankfully, as of Mar 1, very few of you will have any federal f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "glasshalffull",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305141794302205953",
    "text" : "WH orders all fed-funded research to be OA after 1yr. Thankfully, as of Mar 1, very few of you will have any federal funding. #glasshalffull",
    "id" : 305141794302205953,
    "created_at" : "2013-02-23 02:27:27 +0000",
    "user" : {
      "name" : "Fake Elsevier",
      "screen_name" : "FakeElsevier",
      "protected" : false,
      "id_str" : "486169804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1812182734\/6799831691_84690009a5_normal.jpg",
      "id" : 486169804,
      "verified" : false
    }
  },
  "id" : 305458877997133824,
  "created_at" : "2013-02-23 23:27:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZoraMonsterchen",
      "screen_name" : "ZoraMonsterchen",
      "indices" : [ 0, 16 ],
      "id_str" : "2542056559",
      "id" : 2542056559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305449211657347072",
  "text" : "@ZoraMonsterchen Ich hab auch nur das Abstract gelesen, aber scheint so weit zu stimmen.",
  "id" : 305449211657347072,
  "created_at" : "2013-02-23 22:49:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZoraMonsterchen",
      "screen_name" : "ZoraMonsterchen",
      "indices" : [ 0, 16 ],
      "id_str" : "2542056559",
      "id" : 2542056559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/DA37cEVKoO",
      "expanded_url" : "http:\/\/www.vrg.org\/nutrition\/2009_ADA_position_paper.pdf",
      "display_url" : "vrg.org\/nutrition\/2009\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305446171919409152",
  "text" : "@ZoraMonsterchen http:\/\/t.co\/DA37cEVKoO",
  "id" : 305446171919409152,
  "created_at" : "2013-02-23 22:36:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/O3iMKNB3CP",
      "expanded_url" : "http:\/\/www.toymakerproject.com\/doctor_xtreme\/",
      "display_url" : "toymakerproject.com\/doctor_xtreme\/"
    } ]
  },
  "geo" : { },
  "id_str" : "305441824326172672",
  "text" : "A PhD in applied physics seems to prepare you well for building mechanical impedance matched vibrators http:\/\/t.co\/O3iMKNB3CP",
  "id" : 305441824326172672,
  "created_at" : "2013-02-23 22:19:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/fwW61dFee2",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/02\/22\/how-to-cheat-in-the-leaving-ce.html",
      "display_url" : "boingboing.net\/2013\/02\/22\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305425229138755584",
  "text" : "Nice:\u00A0\u00ABHow to Cheat in the Leaving Certificate\u00BB by Graham Jones is on YouTube in 1080p http:\/\/t.co\/fwW61dFee2",
  "id" : 305425229138755584,
  "created_at" : "2013-02-23 21:13:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    }, {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 9, 16 ],
      "id_str" : "15353398",
      "id" : 15353398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305407001222062080",
  "geo" : { },
  "id_str" : "305407202364116992",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker @zinken gerne, ich bin gespannt :)",
  "id" : 305407202364116992,
  "in_reply_to_status_id" : 305407001222062080,
  "created_at" : "2013-02-23 20:02:05 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 0, 7 ],
      "id_str" : "15353398",
      "id" : 15353398
    }, {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 8, 16 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305406526313598977",
  "geo" : { },
  "id_str" : "305406879369158658",
  "in_reply_to_user_id" : 15353398,
  "text" : "@zinken @voelker also mir reicht das als erste Qualifikation v\u00F6llig aus ;)",
  "id" : 305406879369158658,
  "in_reply_to_status_id" : 305406526313598977,
  "created_at" : "2013-02-23 20:00:48 +0000",
  "in_reply_to_screen_name" : "zinken",
  "in_reply_to_user_id_str" : "15353398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    }, {
      "name" : "Richard",
      "screen_name" : "zinken",
      "indices" : [ 31, 38 ],
      "id_str" : "15353398",
      "id" : 15353398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305405278738853888",
  "geo" : { },
  "id_str" : "305405533471522816",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker und dann musst du den @zinken noch \u00FCberreden uns aus Deidesheim zu euch zu verlegen. ;)",
  "id" : 305405533471522816,
  "in_reply_to_status_id" : 305405278738853888,
  "created_at" : "2013-02-23 19:55:27 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305404054950006784",
  "geo" : { },
  "id_str" : "305404698297524225",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker ha, damals klang es alles noch sehr ungewiss. Aber ich dr\u00FCck euch die Daumen! (Und muss euch dann mal besuchen kommen :))",
  "id" : 305404698297524225,
  "in_reply_to_status_id" : 305404054950006784,
  "created_at" : "2013-02-23 19:52:08 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305402737976283138",
  "geo" : { },
  "id_str" : "305403057489997824",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Wow, I totally missed that you\u2019re going for that plan you told me while I visited you in November :)",
  "id" : 305403057489997824,
  "in_reply_to_status_id" : 305402737976283138,
  "created_at" : "2013-02-23 19:45:37 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/xWEgm5Ybm4",
      "expanded_url" : "http:\/\/imgur.com\/r\/funny\/hcHmX35",
      "display_url" : "imgur.com\/r\/funny\/hcHmX35"
    } ]
  },
  "geo" : { },
  "id_str" : "305402069974667265",
  "text" : "1EARUP http:\/\/t.co\/xWEgm5Ybm4",
  "id" : 305402069974667265,
  "created_at" : "2013-02-23 19:41:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/AtXKfIR3nW",
      "expanded_url" : "http:\/\/didyouknowgaming.com\/post\/43742595297\/rock-band-source",
      "display_url" : "didyouknowgaming.com\/post\/437425952\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305371500347789312",
  "text" : "Rock Band: Nickelback http:\/\/t.co\/AtXKfIR3nW",
  "id" : 305371500347789312,
  "created_at" : "2013-02-23 17:40:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/zfZla76ygT",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/d55945f3db38e129c7233f39be3ada58\/tumblr_mim0awJ7Uz1qz6f9yo1_500.png",
      "display_url" : "25.media.tumblr.com\/d55945f3db38e1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305368585348448256",
  "text" : "RT @Tolles_Frollein: Jetpack solves everything: http:\/\/t.co\/zfZla76ygT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/zfZla76ygT",
        "expanded_url" : "http:\/\/25.media.tumblr.com\/d55945f3db38e129c7233f39be3ada58\/tumblr_mim0awJ7Uz1qz6f9yo1_500.png",
        "display_url" : "25.media.tumblr.com\/d55945f3db38e1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305362667659481091",
    "text" : "Jetpack solves everything: http:\/\/t.co\/zfZla76ygT",
    "id" : 305362667659481091,
    "created_at" : "2013-02-23 17:05:07 +0000",
    "user" : {
      "name" : "Claire",
      "screen_name" : "_LoudandClaire",
      "protected" : false,
      "id_str" : "54678641",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/815897044275593217\/ud_at4r-_normal.jpg",
      "id" : 54678641,
      "verified" : false
    }
  },
  "id" : 305368585348448256,
  "created_at" : "2013-02-23 17:28:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "Charles Choi \uD83D\uDE80",
      "screen_name" : "cqchoi",
      "indices" : [ 113, 120 ],
      "id_str" : "247336430",
      "id" : 247336430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/xMXMyBrESV",
      "expanded_url" : "http:\/\/txchnologist.com\/post\/43496630304\/temporary-tattoos-could-make-electronic-telepathy",
      "display_url" : "txchnologist.com\/post\/434966303\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305366949725093889",
  "text" : "RT @edyong209: Temporary Tattoos Could Make Electronic Telepathy, Telekinesis Possible http:\/\/t.co\/xMXMyBrESV By @cqchoi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Choi \uD83D\uDE80",
        "screen_name" : "cqchoi",
        "indices" : [ 98, 105 ],
        "id_str" : "247336430",
        "id" : 247336430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/xMXMyBrESV",
        "expanded_url" : "http:\/\/txchnologist.com\/post\/43496630304\/temporary-tattoos-could-make-electronic-telepathy",
        "display_url" : "txchnologist.com\/post\/434966303\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305366729490579458",
    "text" : "Temporary Tattoos Could Make Electronic Telepathy, Telekinesis Possible http:\/\/t.co\/xMXMyBrESV By @cqchoi",
    "id" : 305366729490579458,
    "created_at" : "2013-02-23 17:21:16 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 305366949725093889,
  "created_at" : "2013-02-23 17:22:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305365063122964481",
  "text" : "Random Mating With Loaded Dice.",
  "id" : 305365063122964481,
  "created_at" : "2013-02-23 17:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 0, 12 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305363477957058560",
  "geo" : { },
  "id_str" : "305364769559420930",
  "in_reply_to_user_id" : 214099847,
  "text" : "@jonfwilkins by now we could start to combine some of the phrases to name indie bands.",
  "id" : 305364769559420930,
  "in_reply_to_status_id" : 305363477957058560,
  "created_at" : "2013-02-23 17:13:29 +0000",
  "in_reply_to_screen_name" : "jonfwilkins",
  "in_reply_to_user_id_str" : "214099847",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 0, 12 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305360764552761347",
  "geo" : { },
  "id_str" : "305361458743619585",
  "in_reply_to_user_id" : 214099847,
  "text" : "@jonfwilkins another favorite: Cryptic male choice.",
  "id" : 305361458743619585,
  "in_reply_to_status_id" : 305360764552761347,
  "created_at" : "2013-02-23 17:00:19 +0000",
  "in_reply_to_screen_name" : "jonfwilkins",
  "in_reply_to_user_id_str" : "214099847",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 0, 12 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "305358528560906242",
  "geo" : { },
  "id_str" : "305359620761874432",
  "in_reply_to_user_id" : 214099847,
  "text" : "@jonfwilkins maybe \u00ABrough endoplasmic reticulum\u00BB wasn\u2019t the best word choice after all. ;)",
  "id" : 305359620761874432,
  "in_reply_to_status_id" : 305358528560906242,
  "created_at" : "2013-02-23 16:53:01 +0000",
  "in_reply_to_screen_name" : "jonfwilkins",
  "in_reply_to_user_id_str" : "214099847",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/nu31bwRYWu",
      "expanded_url" : "http:\/\/j.mp\/XrTO3g",
      "display_url" : "j.mp\/XrTO3g"
    } ]
  },
  "geo" : { },
  "id_str" : "305315379276828673",
  "text" : "\u00ABIs that what an ideal mate looks like to you?\u00BB http:\/\/t.co\/nu31bwRYWu",
  "id" : 305315379276828673,
  "created_at" : "2013-02-23 13:57:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/6rosDa1CHr",
      "expanded_url" : "http:\/\/j.mp\/XrSMUM",
      "display_url" : "j.mp\/XrSMUM"
    } ]
  },
  "geo" : { },
  "id_str" : "305313113413132289",
  "text" : "\u00ABMonty Arnold hat aus der Text-Bild-Schere eine Kunstform gemacht.\u00BB http:\/\/t.co\/6rosDa1CHr",
  "id" : 305313113413132289,
  "created_at" : "2013-02-23 13:48:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305305362305794049",
  "text" : "\u00ABW\u00E4hrend du eruierst ob du schwanger werden k\u00F6nntest werde ich versuchen nicht zu ejakulieren.\u00BB",
  "id" : 305305362305794049,
  "created_at" : "2013-02-23 13:17:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 3, 10 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/FMTQu2aa7D",
      "expanded_url" : "http:\/\/wh.gov\/6TH",
      "display_url" : "wh.gov\/6TH"
    } ]
  },
  "geo" : { },
  "id_str" : "305292892396728320",
  "text" : "RT @mrgunn: Personal, heartfelt thanks to everyone who signed http:\/\/t.co\/FMTQu2aa7D and especially to those who helped \"get out the vot ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/FMTQu2aa7D",
        "expanded_url" : "http:\/\/wh.gov\/6TH",
        "display_url" : "wh.gov\/6TH"
      } ]
    },
    "geo" : { },
    "id_str" : "305223743209340929",
    "text" : "Personal, heartfelt thanks to everyone who signed http:\/\/t.co\/FMTQu2aa7D and especially to those who helped \"get out the vote\". #openaccess",
    "id" : 305223743209340929,
    "created_at" : "2013-02-23 07:53:05 +0000",
    "user" : {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "protected" : false,
      "id_str" : "15237935",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679914371770798080\/FBcokUq2_normal.jpg",
      "id" : 15237935,
      "verified" : false
    }
  },
  "id" : 305292892396728320,
  "created_at" : "2013-02-23 12:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305075019048964096",
  "text" : "RT @Lobot: \u00BBOh, bitte keinen Kaffee mehr um die Uhrzeit. Es sei denn, du m\u00F6chtest die ganze Nacht Spa\u00DF mit mir haben.\u00AB - \u00BBSchwarz oder m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305070062363082756",
    "text" : "\u00BBOh, bitte keinen Kaffee mehr um die Uhrzeit. Es sei denn, du m\u00F6chtest die ganze Nacht Spa\u00DF mit mir haben.\u00AB - \u00BBSchwarz oder mit Zucker?\u00AB",
    "id" : 305070062363082756,
    "created_at" : "2013-02-22 21:42:25 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 305075019048964096,
  "created_at" : "2013-02-22 22:02:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarcozona",
      "screen_name" : "sarcozona",
      "indices" : [ 3, 13 ],
      "id_str" : "15008777",
      "id" : 15008777
    }, {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 19, 29 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jH2zWShrK9",
      "expanded_url" : "http:\/\/bit.ly\/159d0oF",
      "display_url" : "bit.ly\/159d0oF"
    } ]
  },
  "geo" : { },
  "id_str" : "304991012147830784",
  "text" : "RT @sarcozona: :( \u00AB@edyong209 Jared Diamond: the more you know about what he's writing about, the less you trust him http:\/\/t.co\/jH2zWShrK9\u00BB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ed Yong",
        "screen_name" : "edyong209",
        "indices" : [ 4, 14 ],
        "id_str" : "19767193",
        "id" : 19767193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/jH2zWShrK9",
        "expanded_url" : "http:\/\/bit.ly\/159d0oF",
        "display_url" : "bit.ly\/159d0oF"
      } ]
    },
    "geo" : { },
    "id_str" : "304990114986213378",
    "text" : ":( \u00AB@edyong209 Jared Diamond: the more you know about what he's writing about, the less you trust him http:\/\/t.co\/jH2zWShrK9\u00BB",
    "id" : 304990114986213378,
    "created_at" : "2013-02-22 16:24:44 +0000",
    "user" : {
      "name" : "Sarcozona",
      "screen_name" : "sarcozona",
      "protected" : false,
      "id_str" : "15008777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356183472\/bigfavicon_normal.jpg",
      "id" : 15008777,
      "verified" : false
    }
  },
  "id" : 304991012147830784,
  "created_at" : "2013-02-22 16:28:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/GD8eliaNCf",
      "expanded_url" : "http:\/\/tinyurl.com\/9wqwddu",
      "display_url" : "tinyurl.com\/9wqwddu"
    } ]
  },
  "geo" : { },
  "id_str" : "304928359153029120",
  "text" : "Sex Ratios: \"No Trivers-Willard effect could be discerned in the full sample of U.S. billionaires\" http:\/\/t.co\/GD8eliaNCf",
  "id" : 304928359153029120,
  "created_at" : "2013-02-22 12:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/i0qRGgbTXE",
      "expanded_url" : "http:\/\/i.imgur.com\/8psZmXe.jpg",
      "display_url" : "i.imgur.com\/8psZmXe.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "304927465657233408",
  "text" : "Plotting Revenge http:\/\/t.co\/i0qRGgbTXE",
  "id" : 304927465657233408,
  "created_at" : "2013-02-22 12:15:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304921337321893889",
  "text" : "The internet connection at work and I: The prototype of the on-again, off-again relationship model...",
  "id" : 304921337321893889,
  "created_at" : "2013-02-22 11:51:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/E17xoQCiMe",
      "expanded_url" : "http:\/\/i1.kym-cdn.com\/photos\/images\/newsfeed\/000\/332\/961\/c9d.gif",
      "display_url" : "i1.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304888209563844608",
  "geo" : { },
  "id_str" : "304888702331678720",
  "in_reply_to_user_id" : 14700783,
  "text" : "@fischblog Die schweigende Mehrheit in meiner Timeline in etwa: http:\/\/t.co\/E17xoQCiMe",
  "id" : 304888702331678720,
  "in_reply_to_status_id" : 304888209563844608,
  "created_at" : "2013-02-22 09:41:45 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304738333404323840",
  "geo" : { },
  "id_str" : "304739124273885184",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u00ABjust another way of saying that you\u2019ll be fumbling through a messy file explosion.\u00BB :D",
  "id" : 304739124273885184,
  "in_reply_to_status_id" : 304738333404323840,
  "created_at" : "2013-02-21 23:47:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/1CbqSkH4V1",
      "expanded_url" : "http:\/\/discursive.com\/2013\/02\/19\/rails-you-have-turned-into-java-congratulations\/",
      "display_url" : "discursive.com\/2013\/02\/19\/rai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304738818999869440",
  "text" : "RT @PhilippBayer: \"Rails, You Have Turned into Java. Congratulations!\" http:\/\/t.co\/1CbqSkH4V1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/1CbqSkH4V1",
        "expanded_url" : "http:\/\/discursive.com\/2013\/02\/19\/rails-you-have-turned-into-java-congratulations\/",
        "display_url" : "discursive.com\/2013\/02\/19\/rai\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304738333404323840",
    "text" : "\"Rails, You Have Turned into Java. Congratulations!\" http:\/\/t.co\/1CbqSkH4V1",
    "id" : 304738333404323840,
    "created_at" : "2013-02-21 23:44:15 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 304738818999869440,
  "created_at" : "2013-02-21 23:46:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/MDKCMRUVYC",
      "expanded_url" : "http:\/\/massgenomics.org\/2013\/02\/ngs-commandments.html",
      "display_url" : "massgenomics.org\/2013\/02\/ngs-co\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304733035591499776",
  "geo" : { },
  "id_str" : "304734441505452032",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer in general I\u2019d point to commandments 3 &amp; 4: http:\/\/t.co\/MDKCMRUVYC ;)",
  "id" : 304734441505452032,
  "in_reply_to_status_id" : 304733035591499776,
  "created_at" : "2013-02-21 23:28:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4G8yOUbHqc",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/the-curious-wavefunction\/2013\/02\/21\/encode-applemaps-and-function-why-definitions-matter\/",
      "display_url" : "blogs.scientificamerican.com\/the-curious-wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304733778528571394",
  "text" : "If you don\u2019t want to read the whole publication: The Curious Wavefunction has a good take on the snarky ENCODE reply. http:\/\/t.co\/4G8yOUbHqc",
  "id" : 304733778528571394,
  "created_at" : "2013-02-21 23:26:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304731781448495104",
  "geo" : { },
  "id_str" : "304733222665850881",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer the lulz in this will definitely bring more attention it than a standard reply would have achieved, yes.",
  "id" : 304733222665850881,
  "in_reply_to_status_id" : 304731781448495104,
  "created_at" : "2013-02-21 23:23:56 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304731781448495104",
  "geo" : { },
  "id_str" : "304732815692546049",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I think it\u2019s okay, after all the publicity the 80% claim got there weren\u2019t that many options to achieve a similar impact.",
  "id" : 304732815692546049,
  "in_reply_to_status_id" : 304731781448495104,
  "created_at" : "2013-02-21 23:22:19 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304731001991610368",
  "geo" : { },
  "id_str" : "304731457325260801",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer (a bit like the \u201Cwhy bioinformatics sucks!!!!1\u201D-post a while back: Entertaining if not 100% spot on)",
  "id" : 304731457325260801,
  "in_reply_to_status_id" : 304731001991610368,
  "created_at" : "2013-02-21 23:16:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304731001991610368",
  "geo" : { },
  "id_str" : "304731248851562498",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I also do not completely agree with their take, but it was a fun rant to read.",
  "id" : 304731248851562498,
  "in_reply_to_status_id" : 304731001991610368,
  "created_at" : "2013-02-21 23:16:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/LfmHrOTIZj",
      "expanded_url" : "http:\/\/gbe.oxfordjournals.org\/content\/early\/2013\/02\/20\/gbe.evt028.full.pdf",
      "display_url" : "gbe.oxfordjournals.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304730489326022658",
  "text" : "Harsh (albeit funny) take: \u00ABENCODE\u2019s biggest scientific sin was not being satisfied with its role as data provider\u00BB http:\/\/t.co\/LfmHrOTIZj",
  "id" : 304730489326022658,
  "created_at" : "2013-02-21 23:13:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304726866265260035",
  "geo" : { },
  "id_str" : "304728332942053376",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer good luck getting it fixed. Would love to have the meeting on sunday\/monday! :)",
  "id" : 304728332942053376,
  "in_reply_to_status_id" : 304726866265260035,
  "created_at" : "2013-02-21 23:04:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/BIQRok0Bdr",
      "expanded_url" : "http:\/\/www.darwineatscake.com\/?id=151",
      "display_url" : "darwineatscake.com\/?id=151"
    } ]
  },
  "geo" : { },
  "id_str" : "304714839497007104",
  "text" : "\u00ABEvolution needs a better safe word\u00BB http:\/\/t.co\/BIQRok0Bdr",
  "id" : 304714839497007104,
  "created_at" : "2013-02-21 22:10:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "indices" : [ 3, 12 ],
      "id_str" : "19146944",
      "id" : 19146944
    }, {
      "name" : "GrrlScientist",
      "screen_name" : "GrrlScientist",
      "indices" : [ 72, 86 ],
      "id_str" : "27834920",
      "id" : 27834920
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 123, 132 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/hAoemgl5tC",
      "expanded_url" : "http:\/\/gu.com\/p\/3ex93\/tw",
      "display_url" : "gu.com\/p\/3ex93\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "304713879706025985",
  "text" : "RT @BobOHara: New Breakthrough Prize in Life Sciences is misguided | by @GrrlScientist &amp; me http:\/\/t.co\/hAoemgl5tC via @guardian",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GrrlScientist",
        "screen_name" : "GrrlScientist",
        "indices" : [ 58, 72 ],
        "id_str" : "27834920",
        "id" : 27834920
      }, {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 109, 118 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/hAoemgl5tC",
        "expanded_url" : "http:\/\/gu.com\/p\/3ex93\/tw",
        "display_url" : "gu.com\/p\/3ex93\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "304685693601476608",
    "text" : "New Breakthrough Prize in Life Sciences is misguided | by @GrrlScientist &amp; me http:\/\/t.co\/hAoemgl5tC via @guardian",
    "id" : 304685693601476608,
    "created_at" : "2013-02-21 20:15:04 +0000",
    "user" : {
      "name" : "Bob O'Hara",
      "screen_name" : "BobOHara",
      "protected" : false,
      "id_str" : "19146944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624292977\/twitterProfilePhoto_normal.jpg",
      "id" : 19146944,
      "verified" : false
    }
  },
  "id" : 304713879706025985,
  "created_at" : "2013-02-21 22:07:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arikia\uD83D\uDCAB",
      "screen_name" : "arikia",
      "indices" : [ 74, 81 ],
      "id_str" : "71654283",
      "id" : 71654283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/ekE1kihUix",
      "expanded_url" : "http:\/\/dish.andrewsullivan.com\/2013\/02\/21\/the-saddest-map-in-america\/",
      "display_url" : "dish.andrewsullivan.com\/2013\/02\/21\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304712837845098496",
  "text" : "Missed Connections: The Saddest Map In\u00A0America http:\/\/t.co\/ekE1kihUix \/HT @arikia",
  "id" : 304712837845098496,
  "created_at" : "2013-02-21 22:02:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qokhhFu1mh",
      "expanded_url" : "http:\/\/www.scilogs.com\/do_you_speak_science\/introducing-my-false-friend\/",
      "display_url" : "scilogs.com\/do_you_speak_s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304710723467087873",
  "text" : "\u00ABSo, it seems \"false friend\" is itself a false friend, of sorts\u00BB (This is a post where reading the comments is fun!) http:\/\/t.co\/qokhhFu1mh",
  "id" : 304710723467087873,
  "created_at" : "2013-02-21 21:54:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304710096573849600",
  "geo" : { },
  "id_str" : "304710258394275842",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Vorsicht, das war keine DM ;)",
  "id" : 304710258394275842,
  "in_reply_to_status_id" : 304710096573849600,
  "created_at" : "2013-02-21 21:52:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/fcaQWozLtx",
      "expanded_url" : "http:\/\/io9.com\/5985751\/when-cats-are-outlawed-what-animals-should-replace-them-as-pets",
      "display_url" : "io9.com\/5985751\/when-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304708194050138112",
  "text" : "When cats are outlawed, what animals should replace them as pets? Skunks! http:\/\/t.co\/fcaQWozLtx",
  "id" : 304708194050138112,
  "created_at" : "2013-02-21 21:44:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304697301316816896",
  "text" : "On a related note: Die \u00ABUrologische Praxis im Palmengarten\u00BB bringt mich jedes mal aufs Neue zum schmunzeln.",
  "id" : 304697301316816896,
  "created_at" : "2013-02-21 21:01:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304696549194219521",
  "text" : "\u00ABDas ist wie mit den Inuit und W\u00F6rtern f\u00FCr Schnee.\u00BB \u2013 \u00ABDu meinst die haben dazu auch noch 100 W\u00F6rter f\u00FCr Penis?\u00BB",
  "id" : 304696549194219521,
  "created_at" : "2013-02-21 20:58:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 3, 15 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/IkZjTdHNAq",
      "expanded_url" : "http:\/\/www.darwineatscake.com\/?id=156",
      "display_url" : "darwineatscake.com\/?id=156"
    } ]
  },
  "geo" : { },
  "id_str" : "304686948826628097",
  "text" : "RT @jonfwilkins: New comic, third in the series: Darwin Eats Cake: Gay Friends III http:\/\/t.co\/IkZjTdHNAq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/IkZjTdHNAq",
        "expanded_url" : "http:\/\/www.darwineatscake.com\/?id=156",
        "display_url" : "darwineatscake.com\/?id=156"
      } ]
    },
    "geo" : { },
    "id_str" : "304686370788610049",
    "text" : "New comic, third in the series: Darwin Eats Cake: Gay Friends III http:\/\/t.co\/IkZjTdHNAq",
    "id" : 304686370788610049,
    "created_at" : "2013-02-21 20:17:46 +0000",
    "user" : {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "protected" : false,
      "id_str" : "214099847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1279449740\/Dev2DEC_normal.jpg",
      "id" : 214099847,
      "verified" : false
    }
  },
  "id" : 304686948826628097,
  "created_at" : "2013-02-21 20:20:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Regalado",
      "screen_name" : "antonioregalado",
      "indices" : [ 3, 19 ],
      "id_str" : "23085502",
      "id" : 23085502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304643786024308736",
  "text" : "RT @antonioregalado: \u201CDidn\u2019t believe it at first\u2014people taking a lot of pictures of Starbucks mugs.\u201D Datamining Instagram for brands. ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/lBtn0ZYVd4",
        "expanded_url" : "http:\/\/www.technologyreview.com\/news\/511461\/software-with-an-eye-for-starbucks-and-nike-and-coke\/",
        "display_url" : "technologyreview.com\/news\/511461\/so\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304610347304771584",
    "text" : "\u201CDidn\u2019t believe it at first\u2014people taking a lot of pictures of Starbucks mugs.\u201D Datamining Instagram for brands. http:\/\/t.co\/lBtn0ZYVd4",
    "id" : 304610347304771584,
    "created_at" : "2013-02-21 15:15:40 +0000",
    "user" : {
      "name" : "Antonio Regalado",
      "screen_name" : "antonioregalado",
      "protected" : false,
      "id_str" : "23085502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785868761282797568\/Z_Ezx-38_normal.jpg",
      "id" : 23085502,
      "verified" : true
    }
  },
  "id" : 304643786024308736,
  "created_at" : "2013-02-21 17:28:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 3, 14 ],
      "id_str" : "14085070",
      "id" : 14085070
    }, {
      "name" : "emily bell",
      "screen_name" : "emilybell",
      "indices" : [ 110, 120 ],
      "id_str" : "1489691",
      "id" : 1489691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/pLkUhILcob",
      "expanded_url" : "http:\/\/towcenter.org\/blog\/what-the-tesla-affair-tells-us-about-data-journalism\/",
      "display_url" : "towcenter.org\/blog\/what-the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304640100304822272",
  "text" : "RT @carlzimmer: Big Data cannot speak for itself, as the Tesla affair illustrates. http:\/\/t.co\/pLkUhILcob via @emilybell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "emily bell",
        "screen_name" : "emilybell",
        "indices" : [ 94, 104 ],
        "id_str" : "1489691",
        "id" : 1489691
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/pLkUhILcob",
        "expanded_url" : "http:\/\/towcenter.org\/blog\/what-the-tesla-affair-tells-us-about-data-journalism\/",
        "display_url" : "towcenter.org\/blog\/what-the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304639071500783617",
    "text" : "Big Data cannot speak for itself, as the Tesla affair illustrates. http:\/\/t.co\/pLkUhILcob via @emilybell",
    "id" : 304639071500783617,
    "created_at" : "2013-02-21 17:09:49 +0000",
    "user" : {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "protected" : false,
      "id_str" : "14085070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916034313069715457\/url2G14j_normal.jpg",
      "id" : 14085070,
      "verified" : true
    }
  },
  "id" : 304640100304822272,
  "created_at" : "2013-02-21 17:13:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304637752945823744",
  "geo" : { },
  "id_str" : "304638802889154560",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe thanks, that was fun!",
  "id" : 304638802889154560,
  "in_reply_to_status_id" : 304637752945823744,
  "created_at" : "2013-02-21 17:08:45 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/8dCEQu2KGy",
      "expanded_url" : "http:\/\/j.mp\/YEf97w",
      "display_url" : "j.mp\/YEf97w"
    } ]
  },
  "geo" : { },
  "id_str" : "304625650642329601",
  "text" : "Lying is common at age two, becomes the norm by three http:\/\/t.co\/8dCEQu2KGy",
  "id" : 304625650642329601,
  "created_at" : "2013-02-21 16:16:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304618754631929856",
  "geo" : { },
  "id_str" : "304619082651672576",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy w\u00FCrde ich zwischen Fisher &amp; Kafka einsortieren. ;)",
  "id" : 304619082651672576,
  "in_reply_to_status_id" : 304618754631929856,
  "created_at" : "2013-02-21 15:50:23 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hamilton",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304618605742546944",
  "text" : "\u00ABNot even Kafka, whom I was reading at the time, could depress me so much as The Genetical Theory of Natural Selection.\u00BB &lt;3 #hamilton",
  "id" : 304618605742546944,
  "created_at" : "2013-02-21 15:48:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304602160363081729",
  "text" : "\u00ABThere is a famous New Zealand expression: 'Anything can be fixed with a number 8 wire.'\u00BB",
  "id" : 304602160363081729,
  "created_at" : "2013-02-21 14:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 0, 11 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "John Romano",
      "screen_name" : "PaleoRomano",
      "indices" : [ 12, 24 ],
      "id_str" : "116329256",
      "id" : 116329256
    }, {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 25, 41 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 42, 55 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304601013262888960",
  "geo" : { },
  "id_str" : "304601362883301376",
  "in_reply_to_user_id" : 46743752,
  "text" : "@joshwitten @PaleoRomano @mattrussell_PhD @2footgiraffe learning all the different reproductive cycles made me head nearly explode :)",
  "id" : 304601362883301376,
  "in_reply_to_status_id" : 304601013262888960,
  "created_at" : "2013-02-21 14:39:58 +0000",
  "in_reply_to_screen_name" : "joshwitten",
  "in_reply_to_user_id_str" : "46743752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 0, 11 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "John Romano",
      "screen_name" : "PaleoRomano",
      "indices" : [ 12, 24 ],
      "id_str" : "116329256",
      "id" : 116329256
    }, {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 25, 41 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 42, 55 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304600921151774721",
  "geo" : { },
  "id_str" : "304601175880253441",
  "in_reply_to_user_id" : 46743752,
  "text" : "@joshwitten @PaleoRomano @mattrussell_PhD @2footgiraffe especially fungi (including \"untrue\" fungi) with all their different lifestyles.",
  "id" : 304601175880253441,
  "in_reply_to_status_id" : 304600921151774721,
  "created_at" : "2013-02-21 14:39:14 +0000",
  "in_reply_to_screen_name" : "joshwitten",
  "in_reply_to_user_id_str" : "46743752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 0, 11 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "John Romano",
      "screen_name" : "PaleoRomano",
      "indices" : [ 12, 24 ],
      "id_str" : "116329256",
      "id" : 116329256
    }, {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 25, 41 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 42, 55 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304599901122228224",
  "geo" : { },
  "id_str" : "304600460495572992",
  "in_reply_to_user_id" : 46743752,
  "text" : "@joshwitten @PaleoRomano @mattrussell_PhD @2footgiraffe ah, that's what you're aiming for. I misunderstood your first point. :)",
  "id" : 304600460495572992,
  "in_reply_to_status_id" : 304599901122228224,
  "created_at" : "2013-02-21 14:36:23 +0000",
  "in_reply_to_screen_name" : "joshwitten",
  "in_reply_to_user_id_str" : "46743752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 0, 11 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "John Romano",
      "screen_name" : "PaleoRomano",
      "indices" : [ 12, 24 ],
      "id_str" : "116329256",
      "id" : 116329256
    }, {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 25, 41 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 42, 55 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304599147867168769",
  "geo" : { },
  "id_str" : "304599809547972608",
  "in_reply_to_user_id" : 46743752,
  "text" : "@joshwitten @PaleoRomano @mattrussell_PhD @2footgiraffe yes, it's not single cell iirc.",
  "id" : 304599809547972608,
  "in_reply_to_status_id" : 304599147867168769,
  "created_at" : "2013-02-21 14:33:48 +0000",
  "in_reply_to_screen_name" : "joshwitten",
  "in_reply_to_user_id_str" : "46743752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 0, 11 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "John Romano",
      "screen_name" : "PaleoRomano",
      "indices" : [ 12, 24 ],
      "id_str" : "116329256",
      "id" : 116329256
    }, {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 25, 41 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 42, 55 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304596192552181760",
  "geo" : { },
  "id_str" : "304596400556101632",
  "in_reply_to_user_id" : 46743752,
  "text" : "@joshwitten @PaleoRomano @mattrussell_PhD @2footgiraffe yes, but I didn't know that they also reach that impressive sizes :)",
  "id" : 304596400556101632,
  "in_reply_to_status_id" : 304596192552181760,
  "created_at" : "2013-02-21 14:20:15 +0000",
  "in_reply_to_screen_name" : "joshwitten",
  "in_reply_to_user_id_str" : "46743752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miranda Lewis",
      "screen_name" : "MirandaLB5",
      "indices" : [ 0, 11 ],
      "id_str" : "757170667",
      "id" : 757170667
    }, {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 12, 23 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "Zombie Bug Girl",
      "screen_name" : "bug_girl",
      "indices" : [ 24, 33 ],
      "id_str" : "2335958610",
      "id" : 2335958610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304595139890905089",
  "geo" : { },
  "id_str" : "304595293062709249",
  "in_reply_to_user_id" : 757170667,
  "text" : "@MirandaLB5 @joshwitten @bug_girl thanks for inviting us! #scistuchat",
  "id" : 304595293062709249,
  "in_reply_to_status_id" : 304595139890905089,
  "created_at" : "2013-02-21 14:15:51 +0000",
  "in_reply_to_screen_name" : "MirandaLB5",
  "in_reply_to_user_id_str" : "757170667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 0, 11 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "John Romano",
      "screen_name" : "PaleoRomano",
      "indices" : [ 12, 24 ],
      "id_str" : "116329256",
      "id" : 116329256
    }, {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 25, 41 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 42, 55 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304594140153389056",
  "geo" : { },
  "id_str" : "304595047419101186",
  "in_reply_to_user_id" : 46743752,
  "text" : "@joshwitten @PaleoRomano @mattrussell_PhD @2footgiraffe wow, I didn't know that!",
  "id" : 304595047419101186,
  "in_reply_to_status_id" : 304594140153389056,
  "created_at" : "2013-02-21 14:14:53 +0000",
  "in_reply_to_screen_name" : "joshwitten",
  "in_reply_to_user_id_str" : "46743752",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zombie Bug Girl",
      "screen_name" : "bug_girl",
      "indices" : [ 0, 9 ],
      "id_str" : "2335958610",
      "id" : 2335958610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304592541033062400",
  "geo" : { },
  "id_str" : "304594107521699840",
  "in_reply_to_user_id" : 19563103,
  "text" : "@bug_girl #scistuchat Get a bunch of scientists together and they still can discuss \"what's life\" on for hours. :)",
  "id" : 304594107521699840,
  "in_reply_to_status_id" : 304592541033062400,
  "created_at" : "2013-02-21 14:11:08 +0000",
  "in_reply_to_screen_name" : "bug_gwen",
  "in_reply_to_user_id_str" : "19563103",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Romano",
      "screen_name" : "PaleoRomano",
      "indices" : [ 0, 12 ],
      "id_str" : "116329256",
      "id" : 116329256
    }, {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 13, 24 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 25, 41 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 42, 55 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304592242004340736",
  "geo" : { },
  "id_str" : "304593240668139520",
  "in_reply_to_user_id" : 116329256,
  "text" : "@PaleoRomano @joshwitten @mattrussell_PhD @2footgiraffe ... even true fungi in the taxonomical\/phylogenetic sense. #scistuchat",
  "id" : 304593240668139520,
  "in_reply_to_status_id" : 304592242004340736,
  "created_at" : "2013-02-21 14:07:42 +0000",
  "in_reply_to_screen_name" : "PaleoRomano",
  "in_reply_to_user_id_str" : "116329256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Romano",
      "screen_name" : "PaleoRomano",
      "indices" : [ 0, 12 ],
      "id_str" : "116329256",
      "id" : 116329256
    }, {
      "name" : "Josh Witten \uD83C\uDFC9 \uD83D\uDD2C",
      "screen_name" : "joshwitten",
      "indices" : [ 13, 24 ],
      "id_str" : "46743752",
      "id" : 46743752
    }, {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 25, 41 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 42, 55 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304592242004340736",
  "geo" : { },
  "id_str" : "304593124502695936",
  "in_reply_to_user_id" : 116329256,
  "text" : "@PaleoRomano @joshwitten @mattrussell_PhD @2footgiraffe #scistuchat the example isn't single-cell. IIRC those amoeba-like fungi aren't...",
  "id" : 304593124502695936,
  "in_reply_to_status_id" : 304592242004340736,
  "created_at" : "2013-02-21 14:07:14 +0000",
  "in_reply_to_screen_name" : "PaleoRomano",
  "in_reply_to_user_id_str" : "116329256",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Russell",
      "screen_name" : "mattrussell_PhD",
      "indices" : [ 0, 16 ],
      "id_str" : "221568800",
      "id" : 221568800
    }, {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 17, 30 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/lgs8wYMxgG",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=strange-but-true-largest-organism-is-fungus",
      "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304589982750871552",
  "geo" : { },
  "id_str" : "304590529457434624",
  "in_reply_to_user_id" : 221568800,
  "text" : "@mattrussell_PhD @2footgiraffe in terms of area covered it's a fungus #scistuchat http:\/\/t.co\/lgs8wYMxgG",
  "id" : 304590529457434624,
  "in_reply_to_status_id" : 304589982750871552,
  "created_at" : "2013-02-21 13:56:55 +0000",
  "in_reply_to_screen_name" : "mattrussell_PhD",
  "in_reply_to_user_id_str" : "221568800",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Weigel",
      "screen_name" : "Choosy_Female",
      "indices" : [ 0, 14 ],
      "id_str" : "881369844",
      "id" : 881369844
    }, {
      "name" : "Nicole Gugliucci",
      "screen_name" : "NoisyAstronomer",
      "indices" : [ 15, 31 ],
      "id_str" : "15099133",
      "id" : 15099133
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304588406854402048",
  "geo" : { },
  "id_str" : "304588681883308033",
  "in_reply_to_user_id" : 881369844,
  "text" : "@Choosy_Female @NoisyAstronomer so it boils down on whether you want to argue for organization in general or in tradit. cells #scistuchat",
  "id" : 304588681883308033,
  "in_reply_to_status_id" : 304588406854402048,
  "created_at" : "2013-02-21 13:49:35 +0000",
  "in_reply_to_screen_name" : "Choosy_Female",
  "in_reply_to_user_id_str" : "881369844",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Weigel",
      "screen_name" : "Choosy_Female",
      "indices" : [ 0, 14 ],
      "id_str" : "881369844",
      "id" : 881369844
    }, {
      "name" : "Nicole Gugliucci",
      "screen_name" : "NoisyAstronomer",
      "indices" : [ 15, 31 ],
      "id_str" : "15099133",
      "id" : 15099133
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304587645017792514",
  "geo" : { },
  "id_str" : "304588234158141440",
  "in_reply_to_user_id" : 881369844,
  "text" : "@Choosy_Female @NoisyAstronomer they tend to have their own protein coat\/some cases an envelope. So they are somewhat organized #scistuchat",
  "id" : 304588234158141440,
  "in_reply_to_status_id" : 304587645017792514,
  "created_at" : "2013-02-21 13:47:48 +0000",
  "in_reply_to_screen_name" : "Choosy_Female",
  "in_reply_to_user_id_str" : "881369844",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Weigel",
      "screen_name" : "Choosy_Female",
      "indices" : [ 0, 14 ],
      "id_str" : "881369844",
      "id" : 881369844
    }, {
      "name" : "Nicole Gugliucci",
      "screen_name" : "NoisyAstronomer",
      "indices" : [ 15, 31 ],
      "id_str" : "15099133",
      "id" : 15099133
    }, {
      "name" : "Zombie Bug Girl",
      "screen_name" : "bug_girl",
      "indices" : [ 32, 41 ],
      "id_str" : "2335958610",
      "id" : 2335958610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304586491840040960",
  "geo" : { },
  "id_str" : "304587226501763073",
  "in_reply_to_user_id" : 881369844,
  "text" : "@Choosy_Female @NoisyAstronomer @bug_girl one is the lack of metabolism, what\u2019s the second you\u2019re thinking about? #scistuchat",
  "id" : 304587226501763073,
  "in_reply_to_status_id" : 304586491840040960,
  "created_at" : "2013-02-21 13:43:48 +0000",
  "in_reply_to_screen_name" : "Choosy_Female",
  "in_reply_to_user_id_str" : "881369844",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    }, {
      "name" : "Elijah Sloan",
      "screen_name" : "Elijah_Sloan",
      "indices" : [ 14, 27 ],
      "id_str" : "411141022",
      "id" : 411141022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304585098609717248",
  "geo" : { },
  "id_str" : "304586001806921731",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe @Elijah_Sloan #scistuchat not everything that\u2019s alive has a breath. But they all need some food! Watch out if it eats!",
  "id" : 304586001806921731,
  "in_reply_to_status_id" : 304585098609717248,
  "created_at" : "2013-02-21 13:38:56 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scistuchat",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304582727594831872",
  "geo" : { },
  "id_str" : "304583401892102144",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe great, finally a time that\u2019s manageable for us in Europe. :) #scistuchat",
  "id" : 304583401892102144,
  "in_reply_to_status_id" : 304582727594831872,
  "created_at" : "2013-02-21 13:28:36 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304555136955600897",
  "geo" : { },
  "id_str" : "304555510420615169",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn argh, too bad. Would have loved a quick trip to London next week but tomorrow is impossible. :(",
  "id" : 304555510420615169,
  "in_reply_to_status_id" : 304555136955600897,
  "created_at" : "2013-02-21 11:37:46 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304554991375511552",
  "geo" : { },
  "id_str" : "304555086120632320",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn how long are you staying?",
  "id" : 304555086120632320,
  "in_reply_to_status_id" : 304554991375511552,
  "created_at" : "2013-02-21 11:36:05 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrgunn",
      "screen_name" : "mrgunn",
      "indices" : [ 0, 7 ],
      "id_str" : "15237935",
      "id" : 15237935
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304554182671736832",
  "geo" : { },
  "id_str" : "304554881992257537",
  "in_reply_to_user_id" : 15237935,
  "text" : "@mrgunn you're in Europe right now?!",
  "id" : 304554881992257537,
  "in_reply_to_status_id" : 304554182671736832,
  "created_at" : "2013-02-21 11:35:16 +0000",
  "in_reply_to_screen_name" : "mrgunn",
  "in_reply_to_user_id_str" : "15237935",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304539287825821696",
  "text" : "Lovelocks die nur den eigenen Namen oder \u00ABBier!\u00BB eingraviert haben. Schwer zu sagen was ich sympathischer finde.",
  "id" : 304539287825821696,
  "created_at" : "2013-02-21 10:33:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "planetinspace",
      "screen_name" : "planetinspace",
      "indices" : [ 0, 14 ],
      "id_str" : "27800574",
      "id" : 27800574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304522415856304128",
  "geo" : { },
  "id_str" : "304522753703292928",
  "in_reply_to_user_id" : 27800574,
  "text" : "@planetinspace du hast noch nicht erlebt wie er um 03:30 vor der offenen T\u00FCr sitzt und schreit weil er es nicht merkt. ;)",
  "id" : 304522753703292928,
  "in_reply_to_status_id" : 304522415856304128,
  "created_at" : "2013-02-21 09:27:36 +0000",
  "in_reply_to_screen_name" : "planetinspace",
  "in_reply_to_user_id_str" : "27800574",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304521894697238528",
  "text" : "\u00ABDer Kater ist nicht dumm\u00BB S\u00E4tze die man nicht ganz aussprechen wollte weil er vorher aus dem Bett gefallen ist...",
  "id" : 304521894697238528,
  "created_at" : "2013-02-21 09:24:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    }, {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 8, 15 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304379470943506435",
  "geo" : { },
  "id_str" : "304379726561165312",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen @acid23 als ich noch FF statt Chrome benutzt habe war TabKit immer mein Must-Have Plugin. Gute Nacht. :)",
  "id" : 304379726561165312,
  "in_reply_to_status_id" : 304379470943506435,
  "created_at" : "2013-02-20 23:59:16 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/cFiEb4Qhlw",
      "expanded_url" : "http:\/\/3.bp.blogspot.com\/-hMu4YeQJGsw\/UJL8QCYGeiI\/AAAAAAAAdn8\/LSU8od7xglE\/s1600\/diy-dog-costume-banana-slug.jpg",
      "display_url" : "3.bp.blogspot.com\/-hMu4YeQJGsw\/U\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304377697499508736",
  "geo" : { },
  "id_str" : "304379007804243968",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/cFiEb4Qhlw",
  "id" : 304379007804243968,
  "in_reply_to_status_id" : 304377697499508736,
  "created_at" : "2013-02-20 23:56:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    }, {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 8, 15 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304378196055441408",
  "geo" : { },
  "id_str" : "304378308332769280",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 @foxeen Tabkit?",
  "id" : 304378308332769280,
  "in_reply_to_status_id" : 304378196055441408,
  "created_at" : "2013-02-20 23:53:38 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 3, 14 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/C8u95NgVmx",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/",
      "display_url" : "reddit.com\/r\/IAmA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "304377655451602944",
  "text" : "RT @carlzimmer: Wow--genome guru Eric Lander is taking questions on Reddit tomorrow (12\/21) at noon ET. http:\/\/t.co\/C8u95NgVmx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/C8u95NgVmx",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/",
        "display_url" : "reddit.com\/r\/IAmA\/"
      } ]
    },
    "geo" : { },
    "id_str" : "304377437066760192",
    "text" : "Wow--genome guru Eric Lander is taking questions on Reddit tomorrow (12\/21) at noon ET. http:\/\/t.co\/C8u95NgVmx",
    "id" : 304377437066760192,
    "created_at" : "2013-02-20 23:50:10 +0000",
    "user" : {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "protected" : false,
      "id_str" : "14085070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916034313069715457\/url2G14j_normal.jpg",
      "id" : 14085070,
      "verified" : true
    }
  },
  "id" : 304377655451602944,
  "created_at" : "2013-02-20 23:51:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304373036545634304",
  "geo" : { },
  "id_str" : "304373227382259712",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot bin schon dabei!",
  "id" : 304373227382259712,
  "in_reply_to_status_id" : 304373036545634304,
  "created_at" : "2013-02-20 23:33:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/Ue4iceIUZH",
      "expanded_url" : "http:\/\/i0.kym-cdn.com\/photos\/images\/newsfeed\/000\/284\/499\/a69.jpg",
      "display_url" : "i0.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304369907393519616",
  "text" : "Let me just tune this guitar\u2026 http:\/\/t.co\/Ue4iceIUZH",
  "id" : 304369907393519616,
  "created_at" : "2013-02-20 23:20:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/CF7NIXILfg",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/02\/astronauts-on-the-iss-have-trouble-with-work-life-balance-too\/273347\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304360491084546048",
  "text" : "RT @edyong209: You think you have problems with work-life balance? At least you have gravity http:\/\/t.co\/CF7NIXILfg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/CF7NIXILfg",
        "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/02\/astronauts-on-the-iss-have-trouble-with-work-life-balance-too\/273347\/",
        "display_url" : "theatlantic.com\/technology\/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304359982898483202",
    "text" : "You think you have problems with work-life balance? At least you have gravity http:\/\/t.co\/CF7NIXILfg",
    "id" : 304359982898483202,
    "created_at" : "2013-02-20 22:40:49 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 304360491084546048,
  "created_at" : "2013-02-20 22:42:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304355923407810560",
  "text" : "\u00ABDo I really have to read all your publications on this species? Couldn't you just give me some fun factoids &amp; trivia for my introduction?\u00BB",
  "id" : 304355923407810560,
  "created_at" : "2013-02-20 22:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304348109595635712",
  "geo" : { },
  "id_str" : "304348299056537600",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot tell me about it. ;)",
  "id" : 304348299056537600,
  "in_reply_to_status_id" : 304348109595635712,
  "created_at" : "2013-02-20 21:54:23 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304347383775502336",
  "text" : "\u00ABWenn du daf\u00FCr den Kater reinl\u00E4sst bekommst du einen Schuss Nasenspray f\u00FCr den Weg. Deal?\u00BB",
  "id" : 304347383775502336,
  "created_at" : "2013-02-20 21:50:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304343652296183809",
  "geo" : { },
  "id_str" : "304345521869438978",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das ist aber die harmlose Variante von DM-Fail ;)",
  "id" : 304345521869438978,
  "in_reply_to_status_id" : 304343652296183809,
  "created_at" : "2013-02-20 21:43:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/3sQnCeRI",
      "expanded_url" : "http:\/\/youtu.be\/78bDZGiPYO8?t=51s",
      "display_url" : "youtu.be\/78bDZGiPYO8?t=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304337499390615552",
  "geo" : { },
  "id_str" : "304337744501538816",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon http:\/\/t.co\/3sQnCeRI",
  "id" : 304337744501538816,
  "in_reply_to_status_id" : 304337499390615552,
  "created_at" : "2013-02-20 21:12:27 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304336716699947008",
  "geo" : { },
  "id_str" : "304337198751297538",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Die FAZ wollte mir leider keinen Platz geben um dar\u00FCber in epischerer Breite zu schreiben.",
  "id" : 304337198751297538,
  "in_reply_to_status_id" : 304336716699947008,
  "created_at" : "2013-02-20 21:10:17 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "ausgegruschelt",
      "screen_name" : "nutellaberliner",
      "indices" : [ 83, 99 ],
      "id_str" : "393055647",
      "id" : 393055647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304336296749441024",
  "geo" : { },
  "id_str" : "304336574173306881",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Mrs. \u00ABWenn du am Freitag die Wohnung f\u00FCr dich willst, dann w\u00E4hlst du den @nutellaberliner\u00BB. Klickhilfe, ist klar. ;)",
  "id" : 304336574173306881,
  "in_reply_to_status_id" : 304336296749441024,
  "created_at" : "2013-02-20 21:07:48 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304335991106318336",
  "geo" : { },
  "id_str" : "304336144101945346",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du meinst du m\u00F6chtest nicht in meiner Umfrage dar\u00FCber abstimmen ob ich einen Wahlcomputer unterst\u00FCtze? :P",
  "id" : 304336144101945346,
  "in_reply_to_status_id" : 304335991106318336,
  "created_at" : "2013-02-20 21:06:05 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 5, 14 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304335251767959552",
  "text" : "Also @Senficon bietet mir ein Abendessen f\u00FCr meinen BuVo-Abwahl-Key. H\u00F6re ich bessere Gebote?",
  "id" : 304335251767959552,
  "created_at" : "2013-02-20 21:02:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/a9PdmSev",
      "expanded_url" : "http:\/\/j.mp\/135f02K",
      "display_url" : "j.mp\/135f02K"
    } ]
  },
  "geo" : { },
  "id_str" : "304334280367149059",
  "text" : "Parallel Evolutionary Dynamics of Adaptive Diversification in Escherichia coli http:\/\/t.co\/a9PdmSev",
  "id" : 304334280367149059,
  "created_at" : "2013-02-20 20:58:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304330824881410048",
  "text" : "Fellow pop-gens: Do you know whether there\u2019s a good biography of JBS Haldane?",
  "id" : 304330824881410048,
  "created_at" : "2013-02-20 20:44:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    }, {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 13, 24 ],
      "id_str" : "16084074",
      "id" : 16084074
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 91, 100 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304325215398289408",
  "geo" : { },
  "id_str" : "304325512321462273",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt @sofakissen danke und gerne. Ich warte immer noch auf die Vergleichsdaten von @Senficon ob das andersrum auch gilt.",
  "id" : 304325512321462273,
  "in_reply_to_status_id" : 304325215398289408,
  "created_at" : "2013-02-20 20:23:50 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    }, {
      "name" : "Daniel Ziegener",
      "screen_name" : "sofakissen",
      "indices" : [ 13, 24 ],
      "id_str" : "16084074",
      "id" : 16084074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/IE13dBT2",
      "expanded_url" : "http:\/\/gedankenstuecke.github.com\/blog\/2012\/09\/26\/on-getting-sleep\/",
      "display_url" : "gedankenstuecke.github.com\/blog\/2012\/09\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "304322820492632066",
  "geo" : { },
  "id_str" : "304323587521781761",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt @sofakissen per Tracker-Hardware, nicht nur Smartphone-App, siehe http:\/\/t.co\/IE13dBT2",
  "id" : 304323587521781761,
  "in_reply_to_status_id" : 304322820492632066,
  "created_at" : "2013-02-20 20:16:11 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave-Kay",
      "screen_name" : "Dave_Kay",
      "indices" : [ 0, 9 ],
      "id_str" : "10487642",
      "id" : 10487642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304314937281499136",
  "geo" : { },
  "id_str" : "304315008114892801",
  "in_reply_to_user_id" : 10487642,
  "text" : "@Dave_Kay Nur schon l\u00E4nger nicht mehr rasiert!",
  "id" : 304315008114892801,
  "in_reply_to_status_id" : 304314937281499136,
  "created_at" : "2013-02-20 19:42:06 +0000",
  "in_reply_to_screen_name" : "Dave_Kay",
  "in_reply_to_user_id_str" : "10487642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/rF0bUQD4",
      "expanded_url" : "http:\/\/i.imgur.com\/k9cP7.gif",
      "display_url" : "i.imgur.com\/k9cP7.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "304314847401742336",
  "text" : "Hauptsache den Bauch gekrault bekommen. http:\/\/t.co\/rF0bUQD4",
  "id" : 304314847401742336,
  "created_at" : "2013-02-20 19:41:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 0, 10 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304310754272743426",
  "geo" : { },
  "id_str" : "304311667930570755",
  "in_reply_to_user_id" : 19767193,
  "text" : "@edyong209 D. melanogaster and C. elegans immediately come to mind.",
  "id" : 304311667930570755,
  "in_reply_to_status_id" : 304310754272743426,
  "created_at" : "2013-02-20 19:28:50 +0000",
  "in_reply_to_screen_name" : "edyong209",
  "in_reply_to_user_id_str" : "19767193",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304303849726943234",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng alles gute!",
  "id" : 304303849726943234,
  "created_at" : "2013-02-20 18:57:46 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304300216037830657",
  "geo" : { },
  "id_str" : "304300545466826753",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy Jetzt muss ich nur noch schnell genug Morse lesen k\u00F6nnen damit ich es sinnvoll an Growl-Notifications koppeln kann ;)",
  "id" : 304300545466826753,
  "in_reply_to_status_id" : 304300216037830657,
  "created_at" : "2013-02-20 18:44:38 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/VgyqJDzz",
      "expanded_url" : "http:\/\/vine.co\/v\/b6wwHZJJUAQ",
      "display_url" : "vine.co\/v\/b6wwHZJJUAQ"
    } ]
  },
  "geo" : { },
  "id_str" : "304300034374123520",
  "text" : "Morse mit Farbverlauf. http:\/\/t.co\/VgyqJDzz",
  "id" : 304300034374123520,
  "created_at" : "2013-02-20 18:42:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304262349089558528",
  "text" : "Papier &amp; Ich: Immer wieder das lustige \u00ABWo ist eigentlich mein Bachelorzeugnis?\u00BB-Spiel\u2026",
  "id" : 304262349089558528,
  "created_at" : "2013-02-20 16:12:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/u2hDJ7pK",
      "expanded_url" : "http:\/\/biologicalexceptions.blogspot.de\/2013\/02\/males-cant-live-without-them.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+ResearchBloggingBiologyEnglish+(Research+Blogging+-+English+-+Biology",
      "display_url" : "biologicalexceptions.blogspot.de\/2013\/02\/males-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304258378836881409",
  "text" : "On gynogenesis: Males \u2013 Can\u2019t Live Without Them? http:\/\/t.co\/u2hDJ7pK)",
  "id" : 304258378836881409,
  "created_at" : "2013-02-20 15:57:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304235077326479360",
  "geo" : { },
  "id_str" : "304235264308572160",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab I know. But at the same time I also feel highly annoyed by them ;)",
  "id" : 304235264308572160,
  "in_reply_to_status_id" : 304235077326479360,
  "created_at" : "2013-02-20 14:25:14 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304233857165705217",
  "text" : "\u00ABJudging from your hair color I feel I have to remind you: In the US if we say \u2018socialized\u2019 we don\u2019t mean it positive.\u00BB",
  "id" : 304233857165705217,
  "created_at" : "2013-02-20 14:19:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 3, 13 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/IoqqfLZO",
      "expanded_url" : "http:\/\/researchinprogress.tumblr.com\/post\/35472361647\/industry-vs-academia",
      "display_url" : "researchinprogress.tumblr.com\/post\/354723616\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304232180412981248",
  "text" : "RT @Fischblog: Industrie vs. Akademie - die Realit\u00E4t. http:\/\/t.co\/IoqqfLZO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/IoqqfLZO",
        "expanded_url" : "http:\/\/researchinprogress.tumblr.com\/post\/35472361647\/industry-vs-academia",
        "display_url" : "researchinprogress.tumblr.com\/post\/354723616\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304231175629709312",
    "text" : "Industrie vs. Akademie - die Realit\u00E4t. http:\/\/t.co\/IoqqfLZO",
    "id" : 304231175629709312,
    "created_at" : "2013-02-20 14:08:59 +0000",
    "user" : {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "protected" : false,
      "id_str" : "14700783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/929627167125921792\/t5PPk1W-_normal.jpg",
      "id" : 14700783,
      "verified" : false
    }
  },
  "id" : 304232180412981248,
  "created_at" : "2013-02-20 14:12:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Massgenomics",
      "screen_name" : "Massgenomics",
      "indices" : [ 3, 16 ],
      "id_str" : "492806249",
      "id" : 492806249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/4pQr6kCf",
      "expanded_url" : "http:\/\/wp.me\/pg7rI-B9",
      "display_url" : "wp.me\/pg7rI-B9"
    } ]
  },
  "geo" : { },
  "id_str" : "304231143933366274",
  "text" : "RT @Massgenomics: Ten Commandments for Next-Gen Sequencing http:\/\/t.co\/4pQr6kCf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/4pQr6kCf",
        "expanded_url" : "http:\/\/wp.me\/pg7rI-B9",
        "display_url" : "wp.me\/pg7rI-B9"
      } ]
    },
    "geo" : { },
    "id_str" : "304230516465471488",
    "text" : "Ten Commandments for Next-Gen Sequencing http:\/\/t.co\/4pQr6kCf",
    "id" : 304230516465471488,
    "created_at" : "2013-02-20 14:06:22 +0000",
    "user" : {
      "name" : "Massgenomics",
      "screen_name" : "Massgenomics",
      "protected" : false,
      "id_str" : "492806249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540255902150832129\/LUxMTdK5_normal.jpeg",
      "id" : 492806249,
      "verified" : false
    }
  },
  "id" : 304231143933366274,
  "created_at" : "2013-02-20 14:08:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 3, 15 ],
      "id_str" : "16629477",
      "id" : 16629477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/6DtBMy8T",
      "expanded_url" : "http:\/\/j.mp\/12ZIYVD",
      "display_url" : "j.mp\/12ZIYVD"
    } ]
  },
  "geo" : { },
  "id_str" : "304230642546253824",
  "text" : "RT @dgmacarthur: An American watches his father die in the UK - a poignant tribute to socialised healthcare: http:\/\/t.co\/6DtBMy8T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/6DtBMy8T",
        "expanded_url" : "http:\/\/j.mp\/12ZIYVD",
        "display_url" : "j.mp\/12ZIYVD"
      } ]
    },
    "geo" : { },
    "id_str" : "304226500499087361",
    "text" : "An American watches his father die in the UK - a poignant tribute to socialised healthcare: http:\/\/t.co\/6DtBMy8T",
    "id" : 304226500499087361,
    "created_at" : "2013-02-20 13:50:24 +0000",
    "user" : {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "protected" : false,
      "id_str" : "16629477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856238606507180033\/GWLCCqUC_normal.jpg",
      "id" : 16629477,
      "verified" : false
    }
  },
  "id" : 304230642546253824,
  "created_at" : "2013-02-20 14:06:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffa",
      "screen_name" : "rei_in_der_tube",
      "indices" : [ 0, 16 ],
      "id_str" : "19707954",
      "id" : 19707954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "304218898469888000",
  "geo" : { },
  "id_str" : "304219511601643520",
  "in_reply_to_user_id" : 19707954,
  "text" : "@rei_in_der_tube don't get me wrong: Ich finde das - besonders unbezahlt - auch nicht toll.",
  "id" : 304219511601643520,
  "in_reply_to_status_id" : 304218898469888000,
  "created_at" : "2013-02-20 13:22:38 +0000",
  "in_reply_to_screen_name" : "rei_in_der_tube",
  "in_reply_to_user_id_str" : "19707954",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304207033555628033",
  "text" : "Universit\u00E4re Forschung: Empfehlungsschreiben enthalten als positives Merkmal \u00ABArbeitet auch an Wochenenden durch\u00BB.",
  "id" : 304207033555628033,
  "created_at" : "2013-02-20 12:33:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/H594BYgk",
      "expanded_url" : "http:\/\/tinyurl.com\/aef8xmm",
      "display_url" : "tinyurl.com\/aef8xmm"
    } ]
  },
  "geo" : { },
  "id_str" : "304204462845730818",
  "text" : "Dog recognition: \"He believes his results show that dogs have a 'concept of dog.'\" http:\/\/t.co\/H594BYgk",
  "id" : 304204462845730818,
  "created_at" : "2013-02-20 12:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/i4y2qQaW",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0056180",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304203077030916097",
  "text" : "High Impact = High Statistical Standards? Not Necessarily So http:\/\/t.co\/i4y2qQaW",
  "id" : 304203077030916097,
  "created_at" : "2013-02-20 12:17:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roderic Page",
      "screen_name" : "rdmpage",
      "indices" : [ 3, 11 ],
      "id_str" : "14568034",
      "id" : 14568034
    }, {
      "name" : "JSTOR Global Plants",
      "screen_name" : "JSTORPlants",
      "indices" : [ 109, 121 ],
      "id_str" : "121775375",
      "id" : 121775375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304191359613542400",
  "text" : "RT @rdmpage: What is it with plant taxonomists? Plant List locked up by bad license, herbarium sheets behind @JSTORPlants paywall. Serio ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JSTOR Global Plants",
        "screen_name" : "JSTORPlants",
        "indices" : [ 96, 108 ],
        "id_str" : "121775375",
        "id" : 121775375
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304190232188821504",
    "text" : "What is it with plant taxonomists? Plant List locked up by bad license, herbarium sheets behind @JSTORPlants paywall. Seriously, WTF!?",
    "id" : 304190232188821504,
    "created_at" : "2013-02-20 11:26:17 +0000",
    "user" : {
      "name" : "Roderic Page",
      "screen_name" : "rdmpage",
      "protected" : false,
      "id_str" : "14568034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/413219696738328576\/NqWGhi5W_normal.jpeg",
      "id" : 14568034,
      "verified" : false
    }
  },
  "id" : 304191359613542400,
  "created_at" : "2013-02-20 11:30:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/eDVg5ROE",
      "expanded_url" : "http:\/\/tinyurl.com\/am9g38n",
      "display_url" : "tinyurl.com\/am9g38n"
    } ]
  },
  "geo" : { },
  "id_str" : "304190643108978688",
  "text" : "Cool, even though it's not the prisoner's dilemma: Students get class-wide As by boycotting test http:\/\/t.co\/eDVg5ROE",
  "id" : 304190643108978688,
  "created_at" : "2013-02-20 11:27:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/6CAOFnep",
      "expanded_url" : "http:\/\/www.doublexscience.org\/is-there-a-season-for-births\/",
      "display_url" : "doublexscience.org\/is-there-a-sea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304189308477251584",
  "text" : "Is there a season for births? http:\/\/t.co\/6CAOFnep",
  "id" : 304189308477251584,
  "created_at" : "2013-02-20 11:22:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/840pMxYp",
      "expanded_url" : "http:\/\/www.chillhour.com\/legion-of-supervillains",
      "display_url" : "chillhour.com\/legion-of-supe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304163529286643712",
  "text" : "The Legion of Real Life Supervillains. http:\/\/t.co\/840pMxYp",
  "id" : 304163529286643712,
  "created_at" : "2013-02-20 09:40:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304012326980431873",
  "text" : "\u00ABAlso so langsam hat Walking Dead den Nutzen von daryl ex machina perfektioniert.\u00BB",
  "id" : 304012326980431873,
  "created_at" : "2013-02-19 23:39:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303989905321758720",
  "text" : "\u00ABI entered graduate school determined to use gene and stem cell therapy to cure the entire F\u2019ing planet. Spoiler alert, I failed.\u00BB",
  "id" : 303989905321758720,
  "created_at" : "2013-02-19 22:10:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/ItKuiH6a",
      "expanded_url" : "http:\/\/enjoythedisruption.com\/post\/43512317523\/biology-is-in-a-slump-we-need-error-logs-to-get-out",
      "display_url" : "enjoythedisruption.com\/post\/435123175\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303989760068837376",
  "text" : "Why biology \u2013 yes, the wet lab as well \u2013 needs error logs. http:\/\/t.co\/ItKuiH6a",
  "id" : 303989760068837376,
  "created_at" : "2013-02-19 22:09:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/cIG1LwuY",
      "expanded_url" : "http:\/\/events.embo.org\/science-society-conference\/index.html",
      "display_url" : "events.embo.org\/science-societ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303988756992643072",
  "text" : "Nice, EMBO\/EMBL has a conference on \u00ABGenomics, Medicine &amp; Society\u00BB in Heidelberg this November. http:\/\/t.co\/cIG1LwuY",
  "id" : 303988756992643072,
  "created_at" : "2013-02-19 22:05:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/LlLr4ZhA",
      "expanded_url" : "http:\/\/instagr.am\/p\/V63sLBhwiu\/",
      "display_url" : "instagr.am\/p\/V63sLBhwiu\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1194266858, 8.6615010866 ]
  },
  "id_str" : "303909149924794368",
  "text" : "Schafe gegen Gentrifizierung. @ Westend http:\/\/t.co\/LlLr4ZhA",
  "id" : 303909149924794368,
  "created_at" : "2013-02-19 16:49:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/eyYzZbDg",
      "expanded_url" : "http:\/\/tinyurl.com\/bc5e97y",
      "display_url" : "tinyurl.com\/bc5e97y"
    } ]
  },
  "geo" : { },
  "id_str" : "303876534542950400",
  "text" : "Why Did the Meerkat Cross the Road? Flexible Adaptation of Behavioural Strategies to Modern-Day Threats http:\/\/t.co\/eyYzZbDg",
  "id" : 303876534542950400,
  "created_at" : "2013-02-19 14:39:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303858924078129154",
  "text" : "\"Es ist nicht so wie es aussieht. Wir ziehen uns aus weil die Heizung mal wieder Amok l\u00E4uft!\"",
  "id" : 303858924078129154,
  "created_at" : "2013-02-19 13:29:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/yWcdcNhZ",
      "expanded_url" : "http:\/\/tinyurl.com\/bk9v8ry",
      "display_url" : "tinyurl.com\/bk9v8ry"
    } ]
  },
  "geo" : { },
  "id_str" : "303854383186198528",
  "text" : "The 6 greatest acts of trolling in the history of science http:\/\/t.co\/yWcdcNhZ",
  "id" : 303854383186198528,
  "created_at" : "2013-02-19 13:11:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/r6ciMpiD",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1562",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303835698329440256",
  "text" : "Budget Cuts http:\/\/t.co\/r6ciMpiD",
  "id" : 303835698329440256,
  "created_at" : "2013-02-19 11:57:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303653640059629568",
  "geo" : { },
  "id_str" : "303834705529282560",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thx, already read about half of them. Most of them due to your recommendations ;)",
  "id" : 303834705529282560,
  "in_reply_to_status_id" : 303653640059629568,
  "created_at" : "2013-02-19 11:53:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/AW2q5blk",
      "expanded_url" : "http:\/\/i.qkme.me\/3t1oky.jpg",
      "display_url" : "i.qkme.me\/3t1oky.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "303815023627755520",
  "text" : "Better check your phone to see what pictures you took last night. http:\/\/t.co\/AW2q5blk",
  "id" : 303815023627755520,
  "created_at" : "2013-02-19 10:35:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303795610497191936",
  "text" : "\u00ABIst dein Bart eingeschneit?\u00BB \u2013 \u00ABExterne Regulierung des Fl\u00FCssigkeitshaushalts.\u00BB",
  "id" : 303795610497191936,
  "created_at" : "2013-02-19 09:18:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 89 ],
      "url" : "https:\/\/t.co\/m8KUAZmT",
      "expanded_url" : "https:\/\/github.com\/jayferd\/balls",
      "display_url" : "github.com\/jayferd\/balls"
    } ]
  },
  "geo" : { },
  "id_str" : "303648637051875329",
  "text" : "RT @PhilippBayer: A web-framework written in Bash. Because reasons. https:\/\/t.co\/m8KUAZmT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 71 ],
        "url" : "https:\/\/t.co\/m8KUAZmT",
        "expanded_url" : "https:\/\/github.com\/jayferd\/balls",
        "display_url" : "github.com\/jayferd\/balls"
      } ]
    },
    "geo" : { },
    "id_str" : "303647786287628290",
    "text" : "A web-framework written in Bash. Because reasons. https:\/\/t.co\/m8KUAZmT",
    "id" : 303647786287628290,
    "created_at" : "2013-02-18 23:30:48 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 303648637051875329,
  "created_at" : "2013-02-18 23:34:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Lunt",
      "screen_name" : "davelunt",
      "indices" : [ 3, 12 ],
      "id_str" : "19360666",
      "id" : 19360666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303640716238794752",
  "text" : "RT @davelunt: With regret, Prof Godfrey Hewitt, evolutionary geneticist, great mentor, excellent guy, died today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303632297578606593",
    "text" : "With regret, Prof Godfrey Hewitt, evolutionary geneticist, great mentor, excellent guy, died today.",
    "id" : 303632297578606593,
    "created_at" : "2013-02-18 22:29:15 +0000",
    "user" : {
      "name" : "Dave Lunt",
      "screen_name" : "davelunt",
      "protected" : false,
      "id_str" : "19360666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926919522841518080\/4MgFLnSg_normal.jpg",
      "id" : 19360666,
      "verified" : false
    }
  },
  "id" : 303640716238794752,
  "created_at" : "2013-02-18 23:02:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/LEsPshwf",
      "expanded_url" : "http:\/\/i.imgur.com\/3jpRn.jpg",
      "display_url" : "i.imgur.com\/3jpRn.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "303626751983112192",
  "text" : "The X marks the spot http:\/\/t.co\/LEsPshwf",
  "id" : 303626751983112192,
  "created_at" : "2013-02-18 22:07:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/Wv47Dn81",
      "expanded_url" : "http:\/\/on.mash.to\/12DX0wn",
      "display_url" : "on.mash.to\/12DX0wn"
    } ]
  },
  "geo" : { },
  "id_str" : "303622470261424128",
  "text" : "RT @mashable: Sex on Mars: A Dangerous Love Story http:\/\/t.co\/Wv47Dn81",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/Wv47Dn81",
        "expanded_url" : "http:\/\/on.mash.to\/12DX0wn",
        "display_url" : "on.mash.to\/12DX0wn"
      } ]
    },
    "geo" : { },
    "id_str" : "303621274012377091",
    "text" : "Sex on Mars: A Dangerous Love Story http:\/\/t.co\/Wv47Dn81",
    "id" : 303621274012377091,
    "created_at" : "2013-02-18 21:45:27 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/884451753940451333\/XjbzDyYL_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 303622470261424128,
  "created_at" : "2013-02-18 21:50:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/tO3gnOaK",
      "expanded_url" : "http:\/\/i.imgur.com\/0Q4sQ.jpg",
      "display_url" : "i.imgur.com\/0Q4sQ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "303620037003075584",
  "text" : "Animal Welfare, am I doing it right? http:\/\/t.co\/tO3gnOaK",
  "id" : 303620037003075584,
  "created_at" : "2013-02-18 21:40:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/n3ZERfDC",
      "expanded_url" : "http:\/\/j.mp\/Znj4dP",
      "display_url" : "j.mp\/Znj4dP"
    } ]
  },
  "geo" : { },
  "id_str" : "303613572473307136",
  "text" : "Father &amp; Son visit Burning Man: \u00ABDid I mention that my father is [\u2026] a professor of economics who once voted for Bush?\u00BB http:\/\/t.co\/n3ZERfDC",
  "id" : 303613572473307136,
  "created_at" : "2013-02-18 21:14:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303612445166022656",
  "geo" : { },
  "id_str" : "303612637244174336",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Das CLI Tool kann wohl auch parallel mehrere Dinger ansprechen wenn du mini-blinkenlights willst ;)",
  "id" : 303612637244174336,
  "in_reply_to_status_id" : 303612445166022656,
  "created_at" : "2013-02-18 21:11:08 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303612182904582144",
  "geo" : { },
  "id_str" : "303612303738273792",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen e.g. das Morse-Dings sind 80 Zeilen Python, ~40 davon f\u00FCr die Translation-Table ;)",
  "id" : 303612303738273792,
  "in_reply_to_status_id" : 303612182904582144,
  "created_at" : "2013-02-18 21:09:48 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303611609497088002",
  "geo" : { },
  "id_str" : "303611979388575744",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen L\u00E4sst sich also bequem in einer Sprache deiner Wahl wrappen.",
  "id" : 303611979388575744,
  "in_reply_to_status_id" : 303611609497088002,
  "created_at" : "2013-02-18 21:08:31 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303611609497088002",
  "geo" : { },
  "id_str" : "303611825419853826",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen Die Integration in IFTTT ist cool. Und es gibt f\u00FCr ungef\u00E4hr jedes OS ein CLI-Tool.",
  "id" : 303611825419853826,
  "in_reply_to_status_id" : 303611609497088002,
  "created_at" : "2013-02-18 21:07:54 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/Tby1lcKs",
      "expanded_url" : "http:\/\/j.mp\/ZnhLLJ",
      "display_url" : "j.mp\/ZnhLLJ"
    } ]
  },
  "geo" : { },
  "id_str" : "303610882074750976",
  "text" : "Slang Dictionary from 1874 http:\/\/t.co\/Tby1lcKs",
  "id" : 303610882074750976,
  "created_at" : "2013-02-18 21:04:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303609542913175552",
  "geo" : { },
  "id_str" : "303609881196392449",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen ~2 Wochen glaube ich. Versand waren ~USD 10 (beides iirc)",
  "id" : 303609881196392449,
  "in_reply_to_status_id" : 303609542913175552,
  "created_at" : "2013-02-18 21:00:11 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/DCx7Y1cD",
      "expanded_url" : "http:\/\/shop.thingm.com\/blink1\/",
      "display_url" : "shop.thingm.com\/blink1\/"
    } ]
  },
  "in_reply_to_status_id_str" : "303608501563977728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00975071, 8.28353528 ]
  },
  "id_str" : "303608597651271680",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen http:\/\/t.co\/DCx7Y1cD",
  "id" : 303608597651271680,
  "in_reply_to_status_id" : 303608501563977728,
  "created_at" : "2013-02-18 20:55:05 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blink1",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/sup7NcNJ",
      "expanded_url" : "http:\/\/vine.co\/v\/b6ZtaiFzQWF",
      "display_url" : "vine.co\/v\/b6ZtaiFzQWF"
    } ]
  },
  "geo" : { },
  "id_str" : "303606233833820160",
  "text" : "Hello World! #blink1 http:\/\/t.co\/sup7NcNJ",
  "id" : 303606233833820160,
  "created_at" : "2013-02-18 20:45:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shiner Things",
      "screen_name" : "miss_shiny",
      "indices" : [ 3, 14 ],
      "id_str" : "32311971",
      "id" : 32311971
    }, {
      "name" : "First Dog on the Moon",
      "screen_name" : "firstdogonmoon",
      "indices" : [ 16, 31 ],
      "id_str" : "14879825",
      "id" : 14879825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/D5RYYpGB",
      "expanded_url" : "http:\/\/i.imgur.com\/thsGl.gif",
      "display_url" : "i.imgur.com\/thsGl.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "303598411662385152",
  "text" : "RT @miss_shiny: @firstdogonmoon The brakes work http:\/\/t.co\/D5RYYpGB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "First Dog on the Moon",
        "screen_name" : "firstdogonmoon",
        "indices" : [ 0, 15 ],
        "id_str" : "14879825",
        "id" : 14879825
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/D5RYYpGB",
        "expanded_url" : "http:\/\/i.imgur.com\/thsGl.gif",
        "display_url" : "i.imgur.com\/thsGl.gif"
      } ]
    },
    "geo" : { },
    "id_str" : "303514657082191872",
    "in_reply_to_user_id" : 14879825,
    "text" : "@firstdogonmoon The brakes work http:\/\/t.co\/D5RYYpGB",
    "id" : 303514657082191872,
    "created_at" : "2013-02-18 14:41:47 +0000",
    "in_reply_to_screen_name" : "firstdogonmoon",
    "in_reply_to_user_id_str" : "14879825",
    "user" : {
      "name" : "Shiner Things",
      "screen_name" : "miss_shiny",
      "protected" : false,
      "id_str" : "32311971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906084563985645568\/NrfdgKP6_normal.jpg",
      "id" : 32311971,
      "verified" : false
    }
  },
  "id" : 303598411662385152,
  "created_at" : "2013-02-18 20:14:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/pA4icqYk",
      "expanded_url" : "http:\/\/i.imgur.com\/iT2GSdA.jpg",
      "display_url" : "i.imgur.com\/iT2GSdA.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "303573415032410112",
  "text" : "Wine experts http:\/\/t.co\/pA4icqYk",
  "id" : 303573415032410112,
  "created_at" : "2013-02-18 18:35:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303564890843533313",
  "text" : "Is anyone aware whether there are blink(1)-libs that translate text to color-morse?",
  "id" : 303564890843533313,
  "created_at" : "2013-02-18 18:01:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303554162476605441",
  "text" : "\u00ABEntschuldige, ich wollte dir nicht mit dem Bart die Brille von der Nase rei\u00DFen.\u00BB",
  "id" : 303554162476605441,
  "created_at" : "2013-02-18 17:18:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303552837152026625",
  "text" : "Verwirrend: Der OB-Kandidat der CDU sieht ein bisschen so aus wie eine j\u00FCngere &amp; etwas dickere Version von Richard Dawkins.",
  "id" : 303552837152026625,
  "created_at" : "2013-02-18 17:13:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303519626833317888",
  "geo" : { },
  "id_str" : "303519850716856321",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Danke, hatte ich noch nicht gesehen :)",
  "id" : 303519850716856321,
  "in_reply_to_status_id" : 303519626833317888,
  "created_at" : "2013-02-18 15:02:26 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303519145335595008",
  "geo" : { },
  "id_str" : "303519629920321536",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Slides habe ich mal gemacht, war mir dann aber doch zu aufw\u00E4ndig bzw. sah immer mies aus im Vergleich zu Keynote.",
  "id" : 303519629920321536,
  "in_reply_to_status_id" : 303519145335595008,
  "created_at" : "2013-02-18 15:01:33 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303518388666372096",
  "geo" : { },
  "id_str" : "303518633768914945",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon Ich bin ja auch noch nicht fertig. ;)",
  "id" : 303518633768914945,
  "in_reply_to_status_id" : 303518388666372096,
  "created_at" : "2013-02-18 14:57:36 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303516444581314560",
  "geo" : { },
  "id_str" : "303516695354564608",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil Ich weiss, aber das ist mehr Zeit als ich noch habe. Deshalb jetzt aus der Kategorie \u201Cgood enough\u201D ;)",
  "id" : 303516695354564608,
  "in_reply_to_status_id" : 303516444581314560,
  "created_at" : "2013-02-18 14:49:53 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert",
      "screen_name" : "kventil",
      "indices" : [ 0, 8 ],
      "id_str" : "7431192",
      "id" : 7431192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303515854811840513",
  "geo" : { },
  "id_str" : "303516190742040576",
  "in_reply_to_user_id" : 7431192,
  "text" : "@kventil Ja, die upfront Investition ist nur h\u00F6her als ich vermutet hatte ;)",
  "id" : 303516190742040576,
  "in_reply_to_status_id" : 303515854811840513,
  "created_at" : "2013-02-18 14:47:53 +0000",
  "in_reply_to_screen_name" : "kventil",
  "in_reply_to_user_id_str" : "7431192",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303515640172511233",
  "text" : "\u00ABIch mach den CV nur schnell in LaTeX noch mal sch\u00F6n.\u00BB 3 1\/2 Stunden sp\u00E4ter\u2026",
  "id" : 303515640172511233,
  "created_at" : "2013-02-18 14:45:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303502265518530560",
  "geo" : { },
  "id_str" : "303504564341047296",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Dem Little Printer konnte ich auch nur sehr schwer widerstehen :)",
  "id" : 303504564341047296,
  "in_reply_to_status_id" : 303502265518530560,
  "created_at" : "2013-02-18 14:01:41 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303501276476481536",
  "geo" : { },
  "id_str" : "303501971145502720",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Danke!",
  "id" : 303501971145502720,
  "in_reply_to_status_id" : 303501276476481536,
  "created_at" : "2013-02-18 13:51:23 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303499943748984832",
  "geo" : { },
  "id_str" : "303500239535501313",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Das ist eine geniale Idee! Weisst du ob die gerade lieferbar sind?",
  "id" : 303500239535501313,
  "in_reply_to_status_id" : 303499943748984832,
  "created_at" : "2013-02-18 13:44:30 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Voelker",
      "screen_name" : "voelker",
      "indices" : [ 0, 8 ],
      "id_str" : "14783339",
      "id" : 14783339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303484682367037440",
  "geo" : { },
  "id_str" : "303485434275692544",
  "in_reply_to_user_id" : 14783339,
  "text" : "@voelker Ist ein lustiges Spielzeug, ich muss mal einen Rechner nur daf\u00FCr aufsetzen. ;)",
  "id" : 303485434275692544,
  "in_reply_to_status_id" : 303484682367037440,
  "created_at" : "2013-02-18 12:45:40 +0000",
  "in_reply_to_screen_name" : "voelker",
  "in_reply_to_user_id_str" : "14783339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 6, 12 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303483195318468608",
  "text" : "RSS + @IFTTT + blink(1) = Colorful office illumination for each new genotyping on openSNP.",
  "id" : 303483195318468608,
  "created_at" : "2013-02-18 12:36:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303469385727750145",
  "geo" : { },
  "id_str" : "303472230707363840",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe sure, I\u2019m looking forward to it! :)",
  "id" : 303472230707363840,
  "in_reply_to_status_id" : 303469385727750145,
  "created_at" : "2013-02-18 11:53:12 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303321628849369088",
  "geo" : { },
  "id_str" : "303467350190088192",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe I\u2019ll join on thursday 7:30am for \u201Cwhat\u2019s life\u201D :)",
  "id" : 303467350190088192,
  "in_reply_to_status_id" : 303321628849369088,
  "created_at" : "2013-02-18 11:33:49 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303450796878602241",
  "text" : "\u00ABI could either write my application for the PhD position or set up the blink(1). Oh look, the LEDs are pulsing in blue!\u00BB",
  "id" : 303450796878602241,
  "created_at" : "2013-02-18 10:28:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303437295468568578",
  "geo" : { },
  "id_str" : "303438617559322624",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot m\u00F6ge die n\u00E4chste Lieferung kommen. :)",
  "id" : 303438617559322624,
  "in_reply_to_status_id" : 303437295468568578,
  "created_at" : "2013-02-18 09:39:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303433508167237632",
  "geo" : { },
  "id_str" : "303435487425736704",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das klingt aber mehr nach Cargo Cult. ;)",
  "id" : 303435487425736704,
  "in_reply_to_status_id" : 303433508167237632,
  "created_at" : "2013-02-18 09:27:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303408027304878080",
  "geo" : { },
  "id_str" : "303421223235354624",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 bei der piratenfreien Kontrolle verdoppelt sich das Ergebnis immerhin. ;)",
  "id" : 303421223235354624,
  "in_reply_to_status_id" : 303408027304878080,
  "created_at" : "2013-02-18 08:30:31 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303408027304878080",
  "geo" : { },
  "id_str" : "303421074698280961",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 aber die Ergebnisse von dem Test den ich gestern gemacht habe sind in der Tat unterschiedlich vom Normalzustand. :D",
  "id" : 303421074698280961,
  "in_reply_to_status_id" : 303408027304878080,
  "created_at" : "2013-02-18 08:29:56 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303414242181267456",
  "text" : "\u00ABDie Katzen haben auf meinen Rucksack gepinkelt. Joke's on them: Ich wollte ihn sowieso wegschmei\u00DFen.\u00BB",
  "id" : 303414242181267456,
  "created_at" : "2013-02-18 08:02:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/E6j3FbnB",
      "expanded_url" : "http:\/\/boundarylayerphysiology.com\/2013\/02\/17\/why-im-worried-about-ethical-shenanigans-in-the-citizen-science-movement\/",
      "display_url" : "boundarylayerphysiology.com\/2013\/02\/17\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303264221733478400",
  "text" : "This doesn\u2019t touch the problem of how citizen scientists could possibly get IRB approval &amp; ethical oversight at all\u2026 http:\/\/t.co\/E6j3FbnB",
  "id" : 303264221733478400,
  "created_at" : "2013-02-17 22:06:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 3, 13 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/0R0jgLMj",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2013\/02\/03\/magazine\/look-stars.html",
      "display_url" : "nytimes.com\/interactive\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303260350877405184",
  "text" : "RT @fragmente: Der Himmel ohne Lichtverschmutzung: http:\/\/t.co\/0R0jgLMj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/0R0jgLMj",
        "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/2013\/02\/03\/magazine\/look-stars.html",
        "display_url" : "nytimes.com\/interactive\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "303256922210050048",
    "text" : "Der Himmel ohne Lichtverschmutzung: http:\/\/t.co\/0R0jgLMj",
    "id" : 303256922210050048,
    "created_at" : "2013-02-17 21:37:39 +0000",
    "user" : {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "protected" : false,
      "id_str" : "7207642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457425277317120\/emEVfsV-_normal.jpg",
      "id" : 7207642,
      "verified" : false
    }
  },
  "id" : 303260350877405184,
  "created_at" : "2013-02-17 21:51:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303197262287360001",
  "text" : "\u00ABIch habe 9 von 80 Punkten beim Empathie-Test. Aber ich glaube das normalisiert sich mit mehr Abstand von den Piraten wieder.\u00BB",
  "id" : 303197262287360001,
  "created_at" : "2013-02-17 17:40:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michael_nielsen",
      "screen_name" : "michael_nielsen",
      "indices" : [ 39, 55 ],
      "id_str" : "15626406",
      "id" : 15626406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303165027064627200",
  "text" : "My next read: Reinventing Discovery by @michael_nielsen",
  "id" : 303165027064627200,
  "created_at" : "2013-02-17 15:32:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303157201181237248",
  "text" : "\u00ABTo those early explorers Inuit morals were merely lax, but a godsend for the likes of Knud Ramussen so far from their wives &amp; girlfriends\u00BB",
  "id" : 303157201181237248,
  "created_at" : "2013-02-17 15:01:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "promiscuity",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303150896970338304",
  "text" : "Free food: \u00ABFlatworms excel at few things, but they are extremely good at digesting sperm.\u00BB #promiscuity",
  "id" : 303150896970338304,
  "created_at" : "2013-02-17 14:36:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "indices" : [ 3, 11 ],
      "id_str" : "19863141",
      "id" : 19863141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303124501376425984",
  "text" : "RT @cdarwin: We have crossed the Equator. I have undergone the disagreeable operation of being shaved",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.thebeaglevoyage.com\/\" rel=\"nofollow\"\u003EHMSBeagle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303124339539181568",
    "text" : "We have crossed the Equator. I have undergone the disagreeable operation of being shaved",
    "id" : 303124339539181568,
    "created_at" : "2013-02-17 12:50:48 +0000",
    "user" : {
      "name" : "Charles Darwin",
      "screen_name" : "cdarwin",
      "protected" : false,
      "id_str" : "19863141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/75125076\/darwin_normal.jpg",
      "id" : 19863141,
      "verified" : false
    }
  },
  "id" : 303124501376425984,
  "created_at" : "2013-02-17 12:51:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/GHv3yYL5",
      "expanded_url" : "http:\/\/mostlyopenocean.blogspot.de\/2013\/02\/flying-squid-really-fly.html",
      "display_url" : "mostlyopenocean.blogspot.de\/2013\/02\/flying\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303124006272372738",
  "text" : "Flying squid really fly http:\/\/t.co\/GHv3yYL5",
  "id" : 303124006272372738,
  "created_at" : "2013-02-17 12:49:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 1, 10 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/QohYtIBG",
      "expanded_url" : "http:\/\/i.imgur.com\/WoKWskj.gif",
      "display_url" : "i.imgur.com\/WoKWskj.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "303122141954576384",
  "text" : ".@senficon, jedes mal wenn sie sauer auf die Katzen ist http:\/\/t.co\/QohYtIBG",
  "id" : 303122141954576384,
  "created_at" : "2013-02-17 12:42:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303109644434415616",
  "text" : "\u00ABKlar kann ich dich mit nach 2009 nehmen. Steig auf meinen \u00C4nderhaken und wir reiten los.\u00BB",
  "id" : 303109644434415616,
  "created_at" : "2013-02-17 11:52:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "promiscuity",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303106862499389440",
  "text" : "\u00ABFertilization is equivalent to the moment you learn that you have the winning lottery ticket\u00BB #promiscuity",
  "id" : 303106862499389440,
  "created_at" : "2013-02-17 11:41:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303099325687414784",
  "text" : "\u00AB'Es sind doch alles m\u00FCndige B\u00FCrger'? Hat der sich mal im Saal umgeschaut?\u00BB",
  "id" : 303099325687414784,
  "created_at" : "2013-02-17 11:11:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 8, 23 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303090945556107265",
  "geo" : { },
  "id_str" : "303092006694047744",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me @gedankenabfall das wird ein Spass.",
  "id" : 303092006694047744,
  "in_reply_to_status_id" : 303090945556107265,
  "created_at" : "2013-02-17 10:42:20 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 15, 30 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303090423780478978",
  "geo" : { },
  "id_str" : "303090715167186944",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me m\u00FCssen @gedankenabfall und ich alleine feiern?",
  "id" : 303090715167186944,
  "in_reply_to_status_id" : 303090423780478978,
  "created_at" : "2013-02-17 10:37:12 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303089889476481024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.5944386685, 8.9560887183 ]
  },
  "id_str" : "303090020665921536",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me die sind mir zu seri\u00F6s.",
  "id" : 303090020665921536,
  "in_reply_to_status_id" : 303089889476481024,
  "created_at" : "2013-02-17 10:34:26 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/EXuTxpmC",
      "expanded_url" : "http:\/\/instagr.am\/p\/UmMJkGhwpv\/",
      "display_url" : "instagr.am\/p\/UmMJkGhwpv\/"
    } ]
  },
  "in_reply_to_status_id_str" : "303089384079642624",
  "geo" : { },
  "id_str" : "303089764679184384",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me dazu sage ich: http:\/\/t.co\/EXuTxpmC :)",
  "id" : 303089764679184384,
  "in_reply_to_status_id" : 303089384079642624,
  "created_at" : "2013-02-17 10:33:25 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303088920755834881",
  "geo" : { },
  "id_str" : "303089211655999489",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me Nach aktuellem Stand werde ich die Landesliste w\u00E4hlen die ich dann bei der BTW nicht w\u00E4hlen werde. ;)",
  "id" : 303089211655999489,
  "in_reply_to_status_id" : 303088920755834881,
  "created_at" : "2013-02-17 10:31:13 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303088777386151937",
  "text" : "\u00ABDie Piraten sind auch f\u00FCr Frauen w\u00E4hlbar.\u00BB Es klatschen: Ausschlie\u00DFlich M\u00E4nner. Well...",
  "id" : 303088777386151937,
  "created_at" : "2013-02-17 10:29:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "promiscuity",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303068277863763968",
  "text" : "TIL: There are anti-aphrodisiac compounds in the seminal fluid of house flies that puts females off sex for life. #promiscuity",
  "id" : 303068277863763968,
  "created_at" : "2013-02-17 09:08:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/RHYCHWzV",
      "expanded_url" : "http:\/\/instagr.am\/p\/V03eyLBwoJ\/",
      "display_url" : "instagr.am\/p\/V03eyLBwoJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "303064240653217792",
  "text" : "Sicherheitsbedachte Piraten http:\/\/t.co\/RHYCHWzV",
  "id" : 303064240653217792,
  "created_at" : "2013-02-17 08:52:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niclas Hagen",
      "screen_name" : "Tycho5s",
      "indices" : [ 3, 11 ],
      "id_str" : "244600765",
      "id" : 244600765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/IOTQQrZ9",
      "expanded_url" : "http:\/\/gu.com\/p\/3dzbc\/tw",
      "display_url" : "gu.com\/p\/3dzbc\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "303063048556535809",
  "text" : "RT @Tycho5s: Are scientists normal people? http:\/\/t.co\/IOTQQrZ9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/IOTQQrZ9",
        "expanded_url" : "http:\/\/gu.com\/p\/3dzbc\/tw",
        "display_url" : "gu.com\/p\/3dzbc\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "303058870136369152",
    "text" : "Are scientists normal people? http:\/\/t.co\/IOTQQrZ9",
    "id" : 303058870136369152,
    "created_at" : "2013-02-17 08:30:39 +0000",
    "user" : {
      "name" : "Niclas Hagen",
      "screen_name" : "Tycho5s",
      "protected" : false,
      "id_str" : "244600765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1752818560\/154435_10150099348682953_698177952_7146966_5845433_n_normal.jpg",
      "id" : 244600765,
      "verified" : false
    }
  },
  "id" : 303063048556535809,
  "created_at" : "2013-02-17 08:47:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303037873718968320",
  "text" : "\u00ABWehe ihr bringt den Wagen mit Kratzern wieder!\u00BB\u2014\u00ABWer sagt denn das wir ihn \u00FCberhaupt zur\u00FCckbringen?\u00BB",
  "id" : 303037873718968320,
  "created_at" : "2013-02-17 07:07:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Alexander",
      "screen_name" : "thecancergeek",
      "indices" : [ 3, 17 ],
      "id_str" : "14155350",
      "id" : 14155350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302889270786531328",
  "text" : "RT @thecancergeek: Uber-productive people \"see fear the same way other people view lunch\" (ie its going to happen!)....more here -&gt; h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/3fiubVGv",
        "expanded_url" : "http:\/\/buff.ly\/XbtBT2",
        "display_url" : "buff.ly\/XbtBT2"
      } ]
    },
    "geo" : { },
    "id_str" : "302887114134134784",
    "text" : "Uber-productive people \"see fear the same way other people view lunch\" (ie its going to happen!)....more here -&gt; http:\/\/t.co\/3fiubVGv",
    "id" : 302887114134134784,
    "created_at" : "2013-02-16 21:08:10 +0000",
    "user" : {
      "name" : "Angela Alexander",
      "screen_name" : "thecancergeek",
      "protected" : false,
      "id_str" : "14155350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430641398031740928\/Edjlb7tB_normal.jpeg",
      "id" : 14155350,
      "verified" : false
    }
  },
  "id" : 302889270786531328,
  "created_at" : "2013-02-16 21:16:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/3uTI7tGC",
      "expanded_url" : "http:\/\/instagr.am\/p\/VzncjPBwqL\/",
      "display_url" : "instagr.am\/p\/VzncjPBwqL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302888224915877888",
  "text" : "\u00ABI promise what you want!\u00BB http:\/\/t.co\/3uTI7tGC",
  "id" : 302888224915877888,
  "created_at" : "2013-02-16 21:12:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia",
      "screen_name" : "nad_no_ennas",
      "indices" : [ 4, 17 ],
      "id_str" : "1702539380",
      "id" : 1702539380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302859514795929600",
  "text" : "Die @nad_no_ennas l\u00E4sst mich nach Hause fahren. Fools!",
  "id" : 302859514795929600,
  "created_at" : "2013-02-16 19:18:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 0, 7 ],
      "id_str" : "111716214",
      "id" : 111716214
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302852520919851008",
  "geo" : { },
  "id_str" : "302853804339126272",
  "in_reply_to_user_id" : 111716214,
  "text" : "@nplhse @Senficon ich muss mal schauen ob ich das erkl\u00E4rende Sommerfest-Foto noch finde. ;)",
  "id" : 302853804339126272,
  "in_reply_to_status_id" : 302852520919851008,
  "created_at" : "2013-02-16 18:55:48 +0000",
  "in_reply_to_screen_name" : "nplhse",
  "in_reply_to_user_id_str" : "111716214",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302847569241989121",
  "geo" : { },
  "id_str" : "302847683490611200",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng living the dream! :)",
  "id" : 302847683490611200,
  "in_reply_to_status_id" : 302847569241989121,
  "created_at" : "2013-02-16 18:31:29 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302845979877593088",
  "geo" : { },
  "id_str" : "302847334574862336",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng verr\u00FCckter Wissenschaftler!",
  "id" : 302847334574862336,
  "in_reply_to_status_id" : 302845979877593088,
  "created_at" : "2013-02-16 18:30:05 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemeinhorn \uD83E\uDD84",
      "screen_name" : "Blunicorn",
      "indices" : [ 0, 10 ],
      "id_str" : "2524949447",
      "id" : 2524949447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302844699062960128",
  "geo" : { },
  "id_str" : "302845135723577344",
  "in_reply_to_user_id" : 383936036,
  "text" : "@Blunicorn awww.",
  "id" : 302845135723577344,
  "in_reply_to_status_id" : 302844699062960128,
  "created_at" : "2013-02-16 18:21:21 +0000",
  "in_reply_to_screen_name" : "offisir",
  "in_reply_to_user_id_str" : "383936036",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "promiscuity",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302839877844758529",
  "text" : "\u00ABIn the 1960s, in the days before sperm competition was even a twinkle in Geoff Parker's eye\u2026\u00BB &lt;3 #promiscuity",
  "id" : 302839877844758529,
  "created_at" : "2013-02-16 18:00:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 15, 24 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 25, 32 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302822350037078016",
  "geo" : { },
  "id_str" : "302822568900059136",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @Roterhai @Evo2Me Ich dachte die w\u00E4ren in der Achterbahn!?",
  "id" : 302822568900059136,
  "in_reply_to_status_id" : 302822350037078016,
  "created_at" : "2013-02-16 16:51:41 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hermann J. Leopold im Herbst aus Bremen  \uD83C\uDF42",
      "screen_name" : "Hgulf",
      "indices" : [ 0, 6 ],
      "id_str" : "20705742",
      "id" : 20705742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 87 ],
      "url" : "https:\/\/t.co\/XQYuRmB2",
      "expanded_url" : "https:\/\/lqfb.piratenpartei.de\/lf\/initiative\/show\/5789.html?tab=suggestions",
      "display_url" : "lqfb.piratenpartei.de\/lf\/initiative\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "302821820816572417",
  "geo" : { },
  "id_str" : "302822131882946560",
  "in_reply_to_user_id" : 20705742,
  "text" : "@Hgulf Nein, der gesamte Initiativentext d\u00FCrfte da deutlich sein: https:\/\/t.co\/XQYuRmB2 ;)",
  "id" : 302822131882946560,
  "in_reply_to_status_id" : 302821820816572417,
  "created_at" : "2013-02-16 16:49:57 +0000",
  "in_reply_to_screen_name" : "Hgulf",
  "in_reply_to_user_id_str" : "20705742",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EuropeBeyondDivision",
      "screen_name" : "jungePiraten",
      "indices" : [ 44, 57 ],
      "id_str" : "736908496055205888",
      "id" : 736908496055205888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 112 ],
      "url" : "https:\/\/t.co\/fnpynjdq",
      "expanded_url" : "https:\/\/lqfb.piratenpartei.de\/lf\/suggestion\/show\/11754.html",
      "display_url" : "lqfb.piratenpartei.de\/lf\/suggestion\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302821004240105472",
  "text" : "Aufl\u00F6sung der Piratenpartei? Nicht ohne das @JungePiraten die Abschlussparty organisieren! https:\/\/t.co\/fnpynjdq",
  "id" : 302821004240105472,
  "created_at" : "2013-02-16 16:45:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/MloheksC",
      "expanded_url" : "http:\/\/i.imgur.com\/KIYlSz6.gif",
      "display_url" : "i.imgur.com\/KIYlSz6.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "302803074970443778",
  "text" : "The great leap forward. http:\/\/t.co\/MloheksC",
  "id" : 302803074970443778,
  "created_at" : "2013-02-16 15:34:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302802320507420672",
  "geo" : { },
  "id_str" : "302802611709562881",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe Okay, count me in. :)",
  "id" : 302802611709562881,
  "in_reply_to_status_id" : 302802320507420672,
  "created_at" : "2013-02-16 15:32:23 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302802470554456064",
  "text" : "\u00ABDas Internet ist der Buchdruck der Reformationszeit.\u00BB Wait, what?",
  "id" : 302802470554456064,
  "created_at" : "2013-02-16 15:31:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302800973066297344",
  "geo" : { },
  "id_str" : "302801891962802179",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe Okay, Thu\/Fri and 7:30\/9:00am your time are all okay for me. What\u2019s the topic?",
  "id" : 302801891962802179,
  "in_reply_to_status_id" : 302800973066297344,
  "created_at" : "2013-02-16 15:29:31 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "promiscuity",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302801218718273536",
  "text" : "\u00ABSix ejaculations in 24 hours is enough to deplete the epididymal sperm stores completely\u00BB (Don\u2019t try this at home!) #promiscuity",
  "id" : 302801218718273536,
  "created_at" : "2013-02-16 15:26:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302800433196453888",
  "geo" : { },
  "id_str" : "302800506831663104",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe 4:30 pm right now.",
  "id" : 302800506831663104,
  "in_reply_to_status_id" : 302800433196453888,
  "created_at" : "2013-02-16 15:24:01 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "2footgiraffe",
      "indices" : [ 0, 13 ],
      "id_str" : "89859520",
      "id" : 89859520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302800019780665344",
  "geo" : { },
  "id_str" : "302800277239631873",
  "in_reply_to_user_id" : 89859520,
  "text" : "@2footgiraffe could you translate that into my (CET) time zone? :)",
  "id" : 302800277239631873,
  "in_reply_to_status_id" : 302800019780665344,
  "created_at" : "2013-02-16 15:23:06 +0000",
  "in_reply_to_screen_name" : "2footgiraffe",
  "in_reply_to_user_id_str" : "89859520",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dvzrv",
      "screen_name" : "dvzrv",
      "indices" : [ 0, 6 ],
      "id_str" : "30868098",
      "id" : 30868098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302798091239710721",
  "geo" : { },
  "id_str" : "302799041178238977",
  "in_reply_to_user_id" : 30868098,
  "text" : "@dvzrv Great, can\u2019t wait for the results. The sonification always is a great example of how open data is used. :)",
  "id" : 302799041178238977,
  "in_reply_to_status_id" : 302798091239710721,
  "created_at" : "2013-02-16 15:18:11 +0000",
  "in_reply_to_screen_name" : "dvzrv",
  "in_reply_to_user_id_str" : "30868098",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302786257103237120",
  "text" : "\u00ABMale bats exploit over-winter period of female sperm storage, rousing themselves from their midwinter sleep to copulate w\/ torpid females\u00BB",
  "id" : 302786257103237120,
  "created_at" : "2013-02-16 14:27:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/l6rTf7Y3",
      "expanded_url" : "http:\/\/j.mp\/12QRhyS",
      "display_url" : "j.mp\/12QRhyS"
    } ]
  },
  "geo" : { },
  "id_str" : "302784378042478593",
  "text" : "Physicists try to do biology. WTFness ensues. http:\/\/t.co\/l6rTf7Y3",
  "id" : 302784378042478593,
  "created_at" : "2013-02-16 14:19:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/GD9Cipt8",
      "expanded_url" : "http:\/\/j.mp\/11Mx9Tu",
      "display_url" : "j.mp\/11Mx9Tu"
    } ]
  },
  "geo" : { },
  "id_str" : "302783901586313218",
  "text" : "Puppies everywhere! http:\/\/t.co\/GD9Cipt8",
  "id" : 302783901586313218,
  "created_at" : "2013-02-16 14:18:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/11UyJol8",
      "expanded_url" : "http:\/\/i.imgur.com\/314OPf2.gif",
      "display_url" : "i.imgur.com\/314OPf2.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "302783049869971456",
  "text" : "Run! http:\/\/t.co\/11UyJol8",
  "id" : 302783049869971456,
  "created_at" : "2013-02-16 14:14:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302771085865271297",
  "text" : "Kandidaten die schon mal vorsorglich ihre Geburtsurkunde mitbringen. USA you very much.",
  "id" : 302771085865271297,
  "created_at" : "2013-02-16 13:27:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302761797004443648",
  "text" : "Selbsterm\u00E4chtigungsgesetz.",
  "id" : 302761797004443648,
  "created_at" : "2013-02-16 12:50:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Horak",
      "screen_name" : "fatmike182",
      "indices" : [ 0, 11 ],
      "id_str" : "15271509",
      "id" : 15271509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302758240146583552",
  "geo" : { },
  "id_str" : "302758643441467392",
  "in_reply_to_user_id" : 15271509,
  "text" : "@fatmike182 Aus dem Kontext (Monogamie im Tierreich) heraus gehe ich von absichtlich aus. Leider gibt es keine Citation\/welche Arten.",
  "id" : 302758643441467392,
  "in_reply_to_status_id" : 302758240146583552,
  "created_at" : "2013-02-16 12:37:40 +0000",
  "in_reply_to_screen_name" : "fatmike182",
  "in_reply_to_user_id_str" : "15271509",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "promiscuity",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302751934723547136",
  "text" : "\u00ABAmong certain butterflies, males locate female pupae, penetrate their hard outer casing with their penis, and inseminate them\u00BB #promiscuity",
  "id" : 302751934723547136,
  "created_at" : "2013-02-16 12:11:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302750307065155584",
  "text" : "\u00ABMales &amp; females of some worm species pair for life\u2014fusing their genitalia together before sex. maturity &amp; remaining bonded for ever after.\u00BB",
  "id" : 302750307065155584,
  "created_at" : "2013-02-16 12:04:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/aVOiiDao",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/answer-sheet\/wp\/2013\/02\/09\/a-warning-to-college-profs-from-a-high-school-teacher\/#",
      "display_url" : "washingtonpost.com\/blogs\/answer-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302746151566856192",
  "text" : "No Child Left Behind &amp; Standardized Testing: A warning to college profs from a high school teacher http:\/\/t.co\/aVOiiDao",
  "id" : 302746151566856192,
  "created_at" : "2013-02-16 11:48:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naturalismus",
      "screen_name" : "naturalismus",
      "indices" : [ 0, 13 ],
      "id_str" : "4562569648",
      "id" : 4562569648
    }, {
      "name" : ".",
      "screen_name" : "kevusch",
      "indices" : [ 22, 30 ],
      "id_str" : "90213634",
      "id" : 90213634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302743097710878721",
  "geo" : { },
  "id_str" : "302743217756053504",
  "in_reply_to_user_id" : 77216385,
  "text" : "@Naturalismus Von dem @kevusch habe ich die bekommen. :)",
  "id" : 302743217756053504,
  "in_reply_to_status_id" : 302743097710878721,
  "created_at" : "2013-02-16 11:36:22 +0000",
  "in_reply_to_screen_name" : "fireantprincess",
  "in_reply_to_user_id_str" : "77216385",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Die m. d. Text zickt",
      "screen_name" : "textzicke",
      "indices" : [ 3, 13 ],
      "id_str" : "34930175",
      "id" : 34930175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302740887274934272",
  "text" : "RT @textzicke: \"Ich w\u00FCnsche mir, dass sich kein Sexarbeiter f\u00FCr seinen Beruf sch\u00E4men muss, denn Scham macht schwach.\" Bitte lest. https: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 136 ],
        "url" : "https:\/\/t.co\/23ovYZ17",
        "expanded_url" : "https:\/\/thehappywhore.wordpress.com\/2013\/02\/09\/warum-eigentlich-der-ganze-zirkus\/",
        "display_url" : "thehappywhore.wordpress.com\/2013\/02\/09\/war\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "302739147716698113",
    "text" : "\"Ich w\u00FCnsche mir, dass sich kein Sexarbeiter f\u00FCr seinen Beruf sch\u00E4men muss, denn Scham macht schwach.\" Bitte lest. https:\/\/t.co\/23ovYZ17",
    "id" : 302739147716698113,
    "created_at" : "2013-02-16 11:20:12 +0000",
    "user" : {
      "name" : "Die m. d. Text zickt",
      "screen_name" : "textzicke",
      "protected" : false,
      "id_str" : "34930175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760091229195472897\/VyuOriE-_normal.jpg",
      "id" : 34930175,
      "verified" : false
    }
  },
  "id" : 302740887274934272,
  "created_at" : "2013-02-16 11:27:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 16, 23 ],
      "id_str" : "22910316",
      "id" : 22910316
    }, {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 24, 39 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "Markus A. Dahlem",
      "screen_name" : "markusdahlem",
      "indices" : [ 40, 53 ],
      "id_str" : "15703122",
      "id" : 15703122
    }, {
      "name" : "Sebastian",
      "screen_name" : "MrEnkapsis",
      "indices" : [ 54, 65 ],
      "id_str" : "115717883",
      "id" : 115717883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302716510890242049",
  "geo" : { },
  "id_str" : "302740109361565696",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall @Evo2Me @astefanowitsch @markusdahlem @MrEnkapsis Ich werde mich dann wieder mit dem Kellerschwamm vergn\u00FCgen m\u00FCssen\u2026",
  "id" : 302740109361565696,
  "in_reply_to_status_id" : 302716510890242049,
  "created_at" : "2013-02-16 11:24:01 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/zdgRA7Mq",
      "expanded_url" : "http:\/\/instagr.am\/p\/VyjypWBwr4\/",
      "display_url" : "instagr.am\/p\/VyjypWBwr4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302739482250190848",
  "text" : "Grumpy Cat Against Racism http:\/\/t.co\/zdgRA7Mq",
  "id" : 302739482250190848,
  "created_at" : "2013-02-16 11:21:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302729806808764416",
  "geo" : { },
  "id_str" : "302729958936162304",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 Je nachdem ob man Stammbesucher vom Stammtisch H\u00F6chst ist oder nicht hab ich geh\u00F6rt ;)",
  "id" : 302729958936162304,
  "in_reply_to_status_id" : 302729806808764416,
  "created_at" : "2013-02-16 10:43:41 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/XYtV6kXL",
      "expanded_url" : "http:\/\/j.mp\/Zhow1C",
      "display_url" : "j.mp\/Zhow1C"
    } ]
  },
  "geo" : { },
  "id_str" : "302729769735290880",
  "text" : "OpenCFU, a New Free and Open-Source Software to Count Cell Colonies and Other Circular Objects http:\/\/t.co\/XYtV6kXL",
  "id" : 302729769735290880,
  "created_at" : "2013-02-16 10:42:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anatol Stefanowitsch",
      "screen_name" : "astefanowitsch",
      "indices" : [ 0, 15 ],
      "id_str" : "73134122",
      "id" : 73134122
    }, {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 16, 31 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    }, {
      "name" : "Markus A. Dahlem",
      "screen_name" : "markusdahlem",
      "indices" : [ 32, 45 ],
      "id_str" : "15703122",
      "id" : 15703122
    }, {
      "name" : "Sebastian",
      "screen_name" : "MrEnkapsis",
      "indices" : [ 46, 57 ],
      "id_str" : "115717883",
      "id" : 115717883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302715430399774720",
  "geo" : { },
  "id_str" : "302715846449590272",
  "in_reply_to_user_id" : 73134122,
  "text" : "@astefanowitsch @gedankenabfall @markusdahlem @MrEnkapsis du wirst vermisst werden, wer soll denn dann die Weinexpertise beisteuern?",
  "id" : 302715846449590272,
  "in_reply_to_status_id" : 302715430399774720,
  "created_at" : "2013-02-16 09:47:36 +0000",
  "in_reply_to_screen_name" : "astefanowitsch",
  "in_reply_to_user_id_str" : "73134122",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/MRrsqnpx",
      "expanded_url" : "http:\/\/instagr.am\/p\/VyUHu6hwj4\/",
      "display_url" : "instagr.am\/p\/VyUHu6hwj4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302704923676663808",
  "text" : "Copy, Remix, Gardinen http:\/\/t.co\/MRrsqnpx",
  "id" : 302704923676663808,
  "created_at" : "2013-02-16 09:04:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kollektiv Raufaser",
      "screen_name" : "insideX",
      "indices" : [ 4, 12 ],
      "id_str" : "14857351",
      "id" : 14857351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/AzOtGNnF",
      "expanded_url" : "http:\/\/instagr.am\/p\/VyOKtbhwgu\/",
      "display_url" : "instagr.am\/p\/VyOKtbhwgu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302691877189193728",
  "text" : "Der @insideX hat mir Fr\u00FChst\u00FCck gemacht! http:\/\/t.co\/AzOtGNnF",
  "id" : 302691877189193728,
  "created_at" : "2013-02-16 08:12:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302687781073866752",
  "text" : "TIL: The victorian moral beliefs of Darwin's daughter made her run a campaign to eradicate Phallus impudicus.",
  "id" : 302687781073866752,
  "created_at" : "2013-02-16 07:56:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "avgrr",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302676977578561536",
  "text" : "\u00ABJetzt w\u00E4hlen wir die Penisparade!\u00BB \u2014 \u00ABF\u00FCr mich ist es mehr Katastrophentourismus\u2026\u00BB #avgrr",
  "id" : 302676977578561536,
  "created_at" : "2013-02-16 07:13:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/nNwwF5gL",
      "expanded_url" : "http:\/\/j.mp\/VZTTri",
      "display_url" : "j.mp\/VZTTri"
    } ]
  },
  "geo" : { },
  "id_str" : "302559348956221441",
  "text" : "Sea cucumbers, the original \u201Cbuttchuggers\u201D? http:\/\/t.co\/nNwwF5gL",
  "id" : 302559348956221441,
  "created_at" : "2013-02-15 23:25:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302549707543158785",
  "text" : "\u00ABDu darfst doch mit jedem Rockstar schlafen.\u00BB\u2014\u00ABIch wei\u00DF, au\u00DFer mit Greg Graffin, den darf ich nicht mal h\u00F6ren.\u00BB",
  "id" : 302549707543158785,
  "created_at" : "2013-02-15 22:47:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302540693681885185",
  "text" : "\u00ABKannst du bitte mal wieder zu deinem Lover gehen? Eddie Vedder wollte vorbeikommen.\u00BB",
  "id" : 302540693681885185,
  "created_at" : "2013-02-15 22:11:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/U7yqpEk1",
      "expanded_url" : "http:\/\/news.discovery.com\/animals\/the-other-side-of-otters.htm",
      "display_url" : "news.discovery.com\/animals\/the-ot\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.115625, 8.683541 ]
  },
  "id_str" : "302493309367091200",
  "text" : "Just like the antarctic fur seals that rape penguins: Polygynous sea otters rape juvenile harbor seals. http:\/\/t.co\/U7yqpEk1",
  "id" : 302493309367091200,
  "created_at" : "2013-02-15 19:03:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302477244452978688",
  "geo" : { },
  "id_str" : "302479031977267201",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn data source the author used has descriptions about what scenes are actors willing to do. Would be fun to compare to our data.",
  "id" : 302479031977267201,
  "in_reply_to_status_id" : 302477244452978688,
  "created_at" : "2013-02-15 18:06:35 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    }, {
      "name" : "Jason Sundram",
      "screen_name" : "jsundram",
      "indices" : [ 14, 23 ],
      "id_str" : "55677993",
      "id" : 55677993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/LwZk6cA3",
      "expanded_url" : "http:\/\/scienceblogs.de\/weitergen\/2013\/02\/deep-inside-10000-pornostars-und-ihre-karrieren\/",
      "display_url" : "scienceblogs.de\/weitergen\/2013\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "302477244452978688",
  "geo" : { },
  "id_str" : "302478039021928450",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn @jsundram too much load right now. See graphs here: http:\/\/t.co\/LwZk6cA3",
  "id" : 302478039021928450,
  "in_reply_to_status_id" : 302477244452978688,
  "created_at" : "2013-02-15 18:02:38 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 32, 45 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    }, {
      "name" : "Jason Sundram",
      "screen_name" : "jsundram",
      "indices" : [ 50, 59 ],
      "id_str" : "55677993",
      "id" : 55677993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/3gN3DJTQ",
      "expanded_url" : "http:\/\/goo.gl\/fb\/I09Hj",
      "display_url" : "goo.gl\/fb\/I09Hj"
    } ]
  },
  "geo" : { },
  "id_str" : "302470672158973952",
  "text" : "Highly relevant for our project @iameltonjohn! RT @jsundram: Data porn + porn data; a study of 10,000 porn stars. http:\/\/t.co\/3gN3DJTQ",
  "id" : 302470672158973952,
  "created_at" : "2013-02-15 17:33:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "samtools",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 127 ],
      "url" : "https:\/\/t.co\/uTilmH4p",
      "expanded_url" : "https:\/\/jobs.sanger.ac.uk\/wd\/plsql\/wd_portal.show_job?p_web_site_id=1764&p_web_page_id=161360",
      "display_url" : "jobs.sanger.ac.uk\/wd\/plsql\/wd_po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302468809372090369",
  "text" : "RT @pjacock: Sanger job on #samtools to \u201Creestablish it as a pre-eminent tool for the genomics community\u201D https:\/\/t.co\/uTilmH4p (Sanger\u2019 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "samtools",
        "indices" : [ 14, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 114 ],
        "url" : "https:\/\/t.co\/uTilmH4p",
        "expanded_url" : "https:\/\/jobs.sanger.ac.uk\/wd\/plsql\/wd_portal.show_job?p_web_site_id=1764&p_web_page_id=161360",
        "display_url" : "jobs.sanger.ac.uk\/wd\/plsql\/wd_po\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "302389932691972097",
    "text" : "Sanger job on #samtools to \u201Creestablish it as a pre-eminent tool for the genomics community\u201D https:\/\/t.co\/uTilmH4p (Sanger\u2019s GATK plan B?)",
    "id" : 302389932691972097,
    "created_at" : "2013-02-15 12:12:32 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 302468809372090369,
  "created_at" : "2013-02-15 17:25:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302468173117140992",
  "text" : "\u00ABKrieg. Ich mag es nicht so wenn man von Krieg redet. Ich nenne es Wettkampf der Nationen.\u00BB",
  "id" : 302468173117140992,
  "created_at" : "2013-02-15 17:23:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/jjaf626c",
      "expanded_url" : "http:\/\/www.nature.com\/news\/data-barriers-limit-genetic-diagnosis-1.12414",
      "display_url" : "nature.com\/news\/data-barr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302466778771111936",
  "text" : "\u00ABPatients with rare, difficult-to-diagnose disorders stand to gain the most from increased data sharing\u00BB http:\/\/t.co\/jjaf626c",
  "id" : 302466778771111936,
  "created_at" : "2013-02-15 17:17:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "indices" : [ 3, 9 ],
      "id_str" : "15276911",
      "id" : 15276911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/qAasFmGd",
      "expanded_url" : "http:\/\/i.imgur.com\/tc0VMmD.png",
      "display_url" : "i.imgur.com\/tc0VMmD.png"
    } ]
  },
  "geo" : { },
  "id_str" : "302466695988133889",
  "text" : "RT @iddux: Seems relevant today: http:\/\/t.co\/qAasFmGd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http:\/\/t.co\/qAasFmGd",
        "expanded_url" : "http:\/\/i.imgur.com\/tc0VMmD.png",
        "display_url" : "i.imgur.com\/tc0VMmD.png"
      } ]
    },
    "geo" : { },
    "id_str" : "302445831716483072",
    "text" : "Seems relevant today: http:\/\/t.co\/qAasFmGd",
    "id" : 302445831716483072,
    "created_at" : "2013-02-15 15:54:40 +0000",
    "user" : {
      "name" : "Iddo Friedberg",
      "screen_name" : "iddux",
      "protected" : false,
      "id_str" : "15276911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/893496089013174272\/l628-eyh_normal.jpg",
      "id" : 15276911,
      "verified" : false
    }
  },
  "id" : 302466695988133889,
  "created_at" : "2013-02-15 17:17:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302462979037876224",
  "geo" : { },
  "id_str" : "302463501912379393",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot pics or didn't happen ;)",
  "id" : 302463501912379393,
  "in_reply_to_status_id" : 302462979037876224,
  "created_at" : "2013-02-15 17:04:53 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302454260724006913",
  "geo" : { },
  "id_str" : "302455502850383872",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy was ist an Craigslist falsch? ;)",
  "id" : 302455502850383872,
  "in_reply_to_status_id" : 302454260724006913,
  "created_at" : "2013-02-15 16:33:05 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/451Kncu1",
      "expanded_url" : "http:\/\/blog.priceonomics.com\/post\/43085729257\/the-street-kids-of-san-francisco",
      "display_url" : "blog.priceonomics.com\/post\/430857292\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302398374219485185",
  "text" : "The Street Kids of San Francisco http:\/\/t.co\/451Kncu1",
  "id" : 302398374219485185,
  "created_at" : "2013-02-15 12:46:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/qpKdcalA",
      "expanded_url" : "http:\/\/instagr.am\/p\/VwEYNohwiv\/",
      "display_url" : "instagr.am\/p\/VwEYNohwiv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302388903351050240",
  "text" : "Ordnung http:\/\/t.co\/qpKdcalA",
  "id" : 302388903351050240,
  "created_at" : "2013-02-15 12:08:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/nwSG9v6U",
      "expanded_url" : "http:\/\/bit.ly\/VkislA",
      "display_url" : "bit.ly\/VkislA"
    } ]
  },
  "geo" : { },
  "id_str" : "302387770268217344",
  "text" : "RT @Lobot: Clams that look like penises. http:\/\/t.co\/nwSG9v6U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/nwSG9v6U",
        "expanded_url" : "http:\/\/bit.ly\/VkislA",
        "display_url" : "bit.ly\/VkislA"
      } ]
    },
    "geo" : { },
    "id_str" : "302374965439774720",
    "text" : "Clams that look like penises. http:\/\/t.co\/nwSG9v6U",
    "id" : 302374965439774720,
    "created_at" : "2013-02-15 11:13:04 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 302387770268217344,
  "created_at" : "2013-02-15 12:03:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 55 ],
      "url" : "https:\/\/t.co\/FxrOj8AU",
      "expanded_url" : "https:\/\/blogs.wellesley.edu\/vanarsdale\/2013\/02\/05\/fossils\/good-advice\/",
      "display_url" : "blogs.wellesley.edu\/vanarsdale\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302379835219644416",
  "text" : "In Case of Neandertal Uprising... https:\/\/t.co\/FxrOj8AU",
  "id" : 302379835219644416,
  "created_at" : "2013-02-15 11:32:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302378039763927042",
  "text" : "\"We're going to yell at the snow. See you later!\"",
  "id" : 302378039763927042,
  "created_at" : "2013-02-15 11:25:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/YzmGw1NX",
      "expanded_url" : "http:\/\/www.nature.com\/ncomms\/journal\/v4\/n2\/full\/ncomms2430.html",
      "display_url" : "nature.com\/ncomms\/journal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302377858347704321",
  "text" : "Bootstrapping: Prosody cues word order in 7-month-old bilingual infants http:\/\/t.co\/YzmGw1NX",
  "id" : 302377858347704321,
  "created_at" : "2013-02-15 11:24:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302362808014757888",
  "text" : "I'm not slacking off, I ran out of disk space! m(",
  "id" : 302362808014757888,
  "created_at" : "2013-02-15 10:24:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/RE1X9MuD",
      "expanded_url" : "http:\/\/tinyurl.com\/bp7l56g",
      "display_url" : "tinyurl.com\/bp7l56g"
    } ]
  },
  "geo" : { },
  "id_str" : "302348264265633793",
  "text" : "I love the smell of compatible MHCs in the morning: Can oral contraceptives change MHC preferences? http:\/\/t.co\/RE1X9MuD",
  "id" : 302348264265633793,
  "created_at" : "2013-02-15 09:26:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302186892139581440",
  "geo" : { },
  "id_str" : "302187035186311168",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot and that\u2019s all they can see during job interviews!",
  "id" : 302187035186311168,
  "in_reply_to_status_id" : 302186892139581440,
  "created_at" : "2013-02-14 22:46:18 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302183792204992513",
  "geo" : { },
  "id_str" : "302184430330593280",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I\u2019m still working on the skilled-part of that description ;)",
  "id" : 302184430330593280,
  "in_reply_to_status_id" : 302183792204992513,
  "created_at" : "2013-02-14 22:35:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/NelZc1vk",
      "expanded_url" : "http:\/\/j.mp\/Ukhuqa",
      "display_url" : "j.mp\/Ukhuqa"
    } ]
  },
  "geo" : { },
  "id_str" : "302181037864271872",
  "text" : "One man's kindly benefactor is another man's fetishist http:\/\/t.co\/NelZc1vk",
  "id" : 302181037864271872,
  "created_at" : "2013-02-14 22:22:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 123 ],
      "url" : "https:\/\/t.co\/xVhGEK5C",
      "expanded_url" : "https:\/\/davidmichaelross.com\/blog\/microsoft-excel-is-everywhere\/",
      "display_url" : "davidmichaelross.com\/blog\/microsoft\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302179650975723522",
  "text" : "RT @PhilippBayer: More on the hilariously ubiquitous Excel and its weird usages in the business world https:\/\/t.co\/xVhGEK5C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 105 ],
        "url" : "https:\/\/t.co\/xVhGEK5C",
        "expanded_url" : "https:\/\/davidmichaelross.com\/blog\/microsoft-excel-is-everywhere\/",
        "display_url" : "davidmichaelross.com\/blog\/microsoft\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "302166375433129985",
    "text" : "More on the hilariously ubiquitous Excel and its weird usages in the business world https:\/\/t.co\/xVhGEK5C",
    "id" : 302166375433129985,
    "created_at" : "2013-02-14 21:24:12 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 302179650975723522,
  "created_at" : "2013-02-14 22:16:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302179053182545921",
  "geo" : { },
  "id_str" : "302179215061708801",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy okay, in that case it will probably be a quick meeting but still it\u2019s good to have a brief chat.",
  "id" : 302179215061708801,
  "in_reply_to_status_id" : 302179053182545921,
  "created_at" : "2013-02-14 22:15:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302178278050000896",
  "geo" : { },
  "id_str" : "302178761615478784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy great, again at 10pm CET \/ 4pm EST?",
  "id" : 302178761615478784,
  "in_reply_to_status_id" : 302178278050000896,
  "created_at" : "2013-02-14 22:13:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 9, 22 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 85, 98 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302177224575053824",
  "geo" : { },
  "id_str" : "302177463352578049",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @PhilippBayer What about a day later? (Monday for you &amp; me, Tuesday for @PhilippBayer)",
  "id" : 302177463352578049,
  "in_reply_to_status_id" : 302177224575053824,
  "created_at" : "2013-02-14 22:08:16 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302176660655058947",
  "geo" : { },
  "id_str" : "302176847725223936",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy btw. the benchmarking should finally be finished tomorrow.",
  "id" : 302176847725223936,
  "in_reply_to_status_id" : 302176660655058947,
  "created_at" : "2013-02-14 22:05:49 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302176660655058947",
  "geo" : { },
  "id_str" : "302176788455501824",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy at least in terms of disk space ;)",
  "id" : 302176788455501824,
  "in_reply_to_status_id" : 302176660655058947,
  "created_at" : "2013-02-14 22:05:35 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "302176144541757440",
  "geo" : { },
  "id_str" : "302176510641569793",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy looks pretty empty to me ;)",
  "id" : 302176510641569793,
  "in_reply_to_status_id" : 302176144541757440,
  "created_at" : "2013-02-14 22:04:28 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/9x2WC9BE",
      "expanded_url" : "http:\/\/instagr.am\/p\/VuUcigBwuv\/",
      "display_url" : "instagr.am\/p\/VuUcigBwuv\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302142870251511808",
  "text" : "Look what arrived just in time for Valentine's Day! http:\/\/t.co\/9x2WC9BE",
  "id" : 302142870251511808,
  "created_at" : "2013-02-14 19:50:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "indices" : [ 3, 9 ],
      "id_str" : "17567533",
      "id" : 17567533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/z44WieMd",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=new-sexual-revolution-polyamory",
      "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "302137257337442305",
  "text" : "RT @BoraZ: New Sexual Revolution: Polyamory May Be Good for You:  http:\/\/t.co\/z44WieMd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/z44WieMd",
        "expanded_url" : "http:\/\/www.scientificamerican.com\/article.cfm?id=new-sexual-revolution-polyamory",
        "display_url" : "scientificamerican.com\/article.cfm?id\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "302135576671428609",
    "text" : "New Sexual Revolution: Polyamory May Be Good for You:  http:\/\/t.co\/z44WieMd",
    "id" : 302135576671428609,
    "created_at" : "2013-02-14 19:21:49 +0000",
    "user" : {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "protected" : false,
      "id_str" : "17567533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651779136\/b927bab618cdf46063f9c265817f3a8a_normal.jpeg",
      "id" : 17567533,
      "verified" : false
    }
  },
  "id" : 302137257337442305,
  "created_at" : "2013-02-14 19:28:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302129513649803264",
  "text" : "\u00ABEr k\u00F6nnte ein bisschen gr\u00F6\u00DFer sein.\u00BB\u2014\u00ABWas du gleich wieder denkst...\u00BB\u2014\u00ABIch meine der gesamte Hund!\u00BB",
  "id" : 302129513649803264,
  "created_at" : "2013-02-14 18:57:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/jF44fyJd",
      "expanded_url" : "http:\/\/tinyurl.com\/a3rrnr6",
      "display_url" : "tinyurl.com\/a3rrnr6"
    } ]
  },
  "geo" : { },
  "id_str" : "302060290080645122",
  "text" : "The 5 stages of hosting: \"But ask not for whom the pager beeps \u2014 for sysadmin, it beeps for thee.\" http:\/\/t.co\/jF44fyJd",
  "id" : 302060290080645122,
  "created_at" : "2013-02-14 14:22:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 34, 43 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/LOlXCnoi",
      "expanded_url" : "http:\/\/i.imgur.com\/KF0dwWO.gif",
      "display_url" : "i.imgur.com\/KF0dwWO.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "302052879643066369",
  "text" : "Awwwww! http:\/\/t.co\/LOlXCnoi \/via @senficon",
  "id" : 302052879643066369,
  "created_at" : "2013-02-14 13:53:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/gxJu57m6",
      "expanded_url" : "http:\/\/tinyurl.com\/cbt5jey",
      "display_url" : "tinyurl.com\/cbt5jey"
    } ]
  },
  "geo" : { },
  "id_str" : "302051128290447360",
  "text" : "\"It turns out that the statistical description we use for gasses matches the behavior of people in mosh pits\" http:\/\/t.co\/gxJu57m6",
  "id" : 302051128290447360,
  "created_at" : "2013-02-14 13:46:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/yxx8PzdL",
      "expanded_url" : "http:\/\/tinyurl.com\/ceb8u4c",
      "display_url" : "tinyurl.com\/ceb8u4c"
    } ]
  },
  "geo" : { },
  "id_str" : "302044137253900288",
  "text" : "\"Although the risk-taking behavior of Democrats and Republicans did not differ, their brain activity did\" http:\/\/t.co\/yxx8PzdL",
  "id" : 302044137253900288,
  "created_at" : "2013-02-14 13:18:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302039906836946944",
  "text" : "Re-reading my own code, with very helpful comments: \"# the possible nonsense ends here (hopefully)\"",
  "id" : 302039906836946944,
  "created_at" : "2013-02-14 13:01:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/uiWna3au",
      "expanded_url" : "http:\/\/tinyurl.com\/aqw47a2",
      "display_url" : "tinyurl.com\/aqw47a2"
    } ]
  },
  "geo" : { },
  "id_str" : "302019519512199168",
  "text" : "Canada: Protecting citizens from zombies (and placing a carbon tax on zombie survival kits) http:\/\/t.co\/uiWna3au",
  "id" : 302019519512199168,
  "created_at" : "2013-02-14 11:40:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 3, 14 ],
      "id_str" : "191004758",
      "id" : 191004758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sciencevalentine",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/dLvwNXXz",
      "expanded_url" : "http:\/\/bit.ly\/WpgmQF",
      "display_url" : "bit.ly\/WpgmQF"
    } ]
  },
  "geo" : { },
  "id_str" : "302015463372767232",
  "text" : "RT @PygmyLoris: Roses are red, violets are blue, ball size is correlated with how many you screw http:\/\/t.co\/dLvwNXXz #Sciencevalentine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sciencevalentine",
        "indices" : [ 102, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/dLvwNXXz",
        "expanded_url" : "http:\/\/bit.ly\/WpgmQF",
        "display_url" : "bit.ly\/WpgmQF"
      } ]
    },
    "geo" : { },
    "id_str" : "302014123896627200",
    "text" : "Roses are red, violets are blue, ball size is correlated with how many you screw http:\/\/t.co\/dLvwNXXz #Sciencevalentine",
    "id" : 302014123896627200,
    "created_at" : "2013-02-14 11:19:12 +0000",
    "user" : {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "protected" : false,
      "id_str" : "191004758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920667159386316801\/BVsCzUy9_normal.jpg",
      "id" : 191004758,
      "verified" : false
    }
  },
  "id" : 302015463372767232,
  "created_at" : "2013-02-14 11:24:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302013213464215552",
  "text" : "\u00ABWenn du dich fragst was du noch machen sollst: Das gerade ist die K\u00FCr, die Pflicht kommt noch.\u00BB\u2014\u00ABClevere Priorit\u00E4tensetzung bei Deadlines?\u00BB",
  "id" : 302013213464215552,
  "created_at" : "2013-02-14 11:15:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/DkrUWUJf",
      "expanded_url" : "http:\/\/instagr.am\/p\/VtY_LJBwq3\/",
      "display_url" : "instagr.am\/p\/VtY_LJBwq3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "302012186883149824",
  "text" : "\u00ABDon't touch that. Nobody knows why it's lying there.\u00BB http:\/\/t.co\/DkrUWUJf",
  "id" : 302012186883149824,
  "created_at" : "2013-02-14 11:11:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/nOTY7iLl",
      "expanded_url" : "http:\/\/imgur.com\/fZbuku3",
      "display_url" : "imgur.com\/fZbuku3"
    } ]
  },
  "geo" : { },
  "id_str" : "301998217971765248",
  "text" : "Gotta Catch 'em All! http:\/\/t.co\/nOTY7iLl",
  "id" : 301998217971765248,
  "created_at" : "2013-02-14 10:16:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301967678103511041",
  "geo" : { },
  "id_str" : "301967926850879488",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that would be great. Otherwise it can wait two more days I guess. :)",
  "id" : 301967926850879488,
  "in_reply_to_status_id" : 301967678103511041,
  "created_at" : "2013-02-14 08:15:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301966017796657152",
  "text" : "\u00ABLachyoga. Eingang um die Ecke durch den Keller.\u00BB",
  "id" : 301966017796657152,
  "created_at" : "2013-02-14 08:08:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301874126514163712",
  "geo" : { },
  "id_str" : "301962852749680640",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i think it should be good to go :)",
  "id" : 301962852749680640,
  "in_reply_to_status_id" : 301874126514163712,
  "created_at" : "2013-02-14 07:55:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301835140701753345",
  "text" : "RT @PhilippBayer: \"Willingness to Share Data Related to Strength of Evidence and Quality of Reporting of Statistical Results\"\nhttp:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/WojlN7oj",
        "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0026828",
        "display_url" : "plosone.org\/article\/info%3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301835032580993024",
    "text" : "\"Willingness to Share Data Related to Strength of Evidence and Quality of Reporting of Statistical Results\"\nhttp:\/\/t.co\/WojlN7oj",
    "id" : 301835032580993024,
    "created_at" : "2013-02-13 23:27:34 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 301835140701753345,
  "created_at" : "2013-02-13 23:28:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/pjPPwWro",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2355",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301814503316811776",
  "text" : "\u00ABWe need to track down a pope!\u00BB Eternal level caps. http:\/\/t.co\/pjPPwWro",
  "id" : 301814503316811776,
  "created_at" : "2013-02-13 22:05:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 27, 37 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301806802473996290",
  "geo" : { },
  "id_str" : "301807468307152897",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer You have to. @fischblog already noticed the recommendation :D",
  "id" : 301807468307152897,
  "in_reply_to_status_id" : 301806802473996290,
  "created_at" : "2013-02-13 21:38:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301791126451527680",
  "geo" : { },
  "id_str" : "301797468423745538",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw: Enjoy Software Carpentry (might be a nice post for Bierologie?)",
  "id" : 301797468423745538,
  "in_reply_to_status_id" : 301791126451527680,
  "created_at" : "2013-02-13 20:58:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301791126451527680",
  "geo" : { },
  "id_str" : "301797269819228160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if that's the case you should dream weird shit more often! I'm waiting for other mails as well. ;)",
  "id" : 301797269819228160,
  "in_reply_to_status_id" : 301791126451527680,
  "created_at" : "2013-02-13 20:57:30 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301790514691317760",
  "geo" : { },
  "id_str" : "301790794103271425",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer is this a metaphor for our paper-journey? :D (for reference: we submitted on 10\/30\/12)",
  "id" : 301790794103271425,
  "in_reply_to_status_id" : 301790514691317760,
  "created_at" : "2013-02-13 20:31:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 70, 83 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 84, 96 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 97, 106 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301789479440637954",
  "text" : "Time to party. The openSNP paper may finally proceed into review! \/cc @PhilippBayer @helgerausch @Senficon",
  "id" : 301789479440637954,
  "created_at" : "2013-02-13 20:26:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301788040421052417",
  "geo" : { },
  "id_str" : "301788099296514048",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy thanks!",
  "id" : 301788099296514048,
  "in_reply_to_status_id" : 301788040421052417,
  "created_at" : "2013-02-13 20:21:04 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/2K6jqNQ1",
      "expanded_url" : "http:\/\/i.imgur.com\/WBdhfVU.gif",
      "display_url" : "i.imgur.com\/WBdhfVU.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "301787156165296129",
  "geo" : { },
  "id_str" : "301787921269260288",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon http:\/\/t.co\/2K6jqNQ1",
  "id" : 301787921269260288,
  "in_reply_to_status_id" : 301787156165296129,
  "created_at" : "2013-02-13 20:20:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301787386290003968",
  "geo" : { },
  "id_str" : "301787660664578048",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy could you mail me the article? :)",
  "id" : 301787660664578048,
  "in_reply_to_status_id" : 301787386290003968,
  "created_at" : "2013-02-13 20:19:19 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/yRyKoKZA",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/natashavc\/when-a-10-year-old-kills-his-nazi-father-whos-to-blame?utm_campaign=socialflow&utm_source=twitter&utm_medium=buzzfeed",
      "display_url" : "buzzfeed.com\/natashavc\/when\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301777951127650304",
  "text" : "\u00ABwho do you punish when a child becomes a cold-blooded killer?\u00BB http:\/\/t.co\/yRyKoKZA",
  "id" : 301777951127650304,
  "created_at" : "2013-02-13 19:40:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/0kajgN9V",
      "expanded_url" : "http:\/\/j.mp\/VSOd7N",
      "display_url" : "j.mp\/VSOd7N"
    } ]
  },
  "geo" : { },
  "id_str" : "301772995934957568",
  "text" : "Bicycle made (in part) from recycled car parts http:\/\/t.co\/0kajgN9V",
  "id" : 301772995934957568,
  "created_at" : "2013-02-13 19:21:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "uBiome",
      "screen_name" : "uBiome",
      "indices" : [ 6, 13 ],
      "id_str" : "852039852",
      "id" : 852039852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/S7TdIfJw",
      "expanded_url" : "http:\/\/www.indiegogo.com\/projects\/ubiome-sequencing-your-microbiome?c=activity",
      "display_url" : "indiegogo.com\/projects\/ubiom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301772003424215040",
  "text" : "Cool, @uBiome offers updates for early backers. This means additional genital microbiome sampling!  http:\/\/t.co\/S7TdIfJw",
  "id" : 301772003424215040,
  "created_at" : "2013-02-13 19:17:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. David Shiffman",
      "screen_name" : "WhySharksMatter",
      "indices" : [ 3, 19 ],
      "id_str" : "66182591",
      "id" : 66182591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shark",
      "indices" : [ 44, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301770255326396418",
  "text" : "RT @WhySharksMatter: 50 Shades of Grey Reef #Shark: A Valentine's Day Special Report on Shark Sex (With Pictures! And Video!): http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Shark",
        "indices" : [ 23, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/PmfGcI85",
        "expanded_url" : "http:\/\/www.southernfriedscience.com\/?p=14393",
        "display_url" : "southernfriedscience.com\/?p=14393"
      } ]
    },
    "geo" : { },
    "id_str" : "301767896353361920",
    "text" : "50 Shades of Grey Reef #Shark: A Valentine's Day Special Report on Shark Sex (With Pictures! And Video!): http:\/\/t.co\/PmfGcI85",
    "id" : 301767896353361920,
    "created_at" : "2013-02-13 19:00:47 +0000",
    "user" : {
      "name" : "Dr. David Shiffman",
      "screen_name" : "WhySharksMatter",
      "protected" : false,
      "id_str" : "66182591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817814996608552960\/jSwEWyxK_normal.jpg",
      "id" : 66182591,
      "verified" : true
    }
  },
  "id" : 301770255326396418,
  "created_at" : "2013-02-13 19:10:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301759788705005569",
  "geo" : { },
  "id_str" : "301761807029248000",
  "in_reply_to_user_id" : 44625441,
  "text" : "@tuxwurf der Unfallmanager hier machte den Eindruck als w\u00FCrde man sich an alles gew\u00F6hnen.",
  "id" : 301761807029248000,
  "in_reply_to_status_id" : 301759788705005569,
  "created_at" : "2013-02-13 18:36:35 +0000",
  "in_reply_to_screen_name" : "juriroemer",
  "in_reply_to_user_id_str" : "44625441",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301759280359555072",
  "text" : "Die Fahrerin des SEV gibt ein Best-Of ihrer Suicide by Train-Stories...",
  "id" : 301759280359555072,
  "created_at" : "2013-02-13 18:26:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/3gOMV9zX",
      "expanded_url" : "http:\/\/www.techdirt.com\/articles\/20130211\/08050521945\/europes-database-right-could-throttle-open-data-moves-there.shtml",
      "display_url" : "techdirt.com\/articles\/20130\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301751291489689600",
  "text" : "RT @wilbanks: If I could kill the EU database right with fire, I would. http:\/\/t.co\/3gOMV9zX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/3gOMV9zX",
        "expanded_url" : "http:\/\/www.techdirt.com\/articles\/20130211\/08050521945\/europes-database-right-could-throttle-open-data-moves-there.shtml",
        "display_url" : "techdirt.com\/articles\/20130\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301750625413263360",
    "text" : "If I could kill the EU database right with fire, I would. http:\/\/t.co\/3gOMV9zX",
    "id" : 301750625413263360,
    "created_at" : "2013-02-13 17:52:10 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 301751291489689600,
  "created_at" : "2013-02-13 17:54:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301748684318728193",
  "text" : "\u00ABDa f\u00E4hrt man einmal mit der S-Bahn und dann sowas!\u00BB\u2014\u00ABSelbstverst\u00E4ndlich, die Leute warten nur darauf vor ihre Bahn zu springen...\u00BB",
  "id" : 301748684318728193,
  "created_at" : "2013-02-13 17:44:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301746248376016896",
  "geo" : { },
  "id_str" : "301746399173828608",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon \u201Esie mussten gar nicht lange leiden!\u201C",
  "id" : 301746399173828608,
  "in_reply_to_status_id" : 301746248376016896,
  "created_at" : "2013-02-13 17:35:22 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301745827423088640",
  "geo" : { },
  "id_str" : "301746100317089793",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon nur weil du Veganerin geworden bist. Sonst w\u00E4re das akkurat!",
  "id" : 301746100317089793,
  "in_reply_to_status_id" : 301745827423088640,
  "created_at" : "2013-02-13 17:34:11 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301742172061974528",
  "geo" : { },
  "id_str" : "301742347736195072",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon er geht auf killing spree?",
  "id" : 301742347736195072,
  "in_reply_to_status_id" : 301742172061974528,
  "created_at" : "2013-02-13 17:19:16 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301741402881138689",
  "geo" : { },
  "id_str" : "301741950942470144",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du meinst dann lernt er nichts? ;)",
  "id" : 301741950942470144,
  "in_reply_to_status_id" : 301741402881138689,
  "created_at" : "2013-02-13 17:17:41 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301740090273718272",
  "geo" : { },
  "id_str" : "301740403139440640",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon er muss halt lernen das man sich manchmal auch selbst aus dem Mist befreien muss in den man sich reinman\u00F6vriert hat.",
  "id" : 301740403139440640,
  "in_reply_to_status_id" : 301740090273718272,
  "created_at" : "2013-02-13 17:11:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301737906714857472",
  "geo" : { },
  "id_str" : "301739549011361792",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Du verletzt seine Gef\u00FChle!",
  "id" : 301739549011361792,
  "in_reply_to_status_id" : 301737906714857472,
  "created_at" : "2013-02-13 17:08:09 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/xYmp0Ud8",
      "expanded_url" : "http:\/\/tinyurl.com\/a7o37w8",
      "display_url" : "tinyurl.com\/a7o37w8"
    } ]
  },
  "geo" : { },
  "id_str" : "301718473745264640",
  "text" : "When you use the wrong parameters for your script and end up with broken fasta-files all over the place... http:\/\/t.co\/xYmp0Ud8",
  "id" : 301718473745264640,
  "created_at" : "2013-02-13 15:44:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301693633885765633",
  "text" : "RT @edyong209: The alligator has a permanently erect, bungee penis. With jaw-dropping video. And a cocktail napkin schematic. http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/GabiQNCC",
        "expanded_url" : "http:\/\/phenomena.nationalgeographic.com\/2013\/02\/13\/the-alligator-has-a-permanently-erect-bungee-penis\/",
        "display_url" : "phenomena.nationalgeographic.com\/2013\/02\/13\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301692452732035074",
    "text" : "The alligator has a permanently erect, bungee penis. With jaw-dropping video. And a cocktail napkin schematic. http:\/\/t.co\/GabiQNCC",
    "id" : 301692452732035074,
    "created_at" : "2013-02-13 14:01:00 +0000",
    "user" : {
      "name" : "Ed Yong",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926063794912153600\/962ygzzx_normal.jpg",
      "id" : 19767193,
      "verified" : true
    }
  },
  "id" : 301693633885765633,
  "created_at" : "2013-02-13 14:05:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 98, 111 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 112, 120 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/WufGgl30",
      "expanded_url" : "http:\/\/tinyurl.com\/bnholah",
      "display_url" : "tinyurl.com\/bnholah"
    } ]
  },
  "geo" : { },
  "id_str" : "301664570332807169",
  "text" : "Improving Microbial Genome Annotations in an Integrated Database Context http:\/\/t.co\/WufGgl30 \/cc @philippbayer @heyaudy",
  "id" : 301664570332807169,
  "created_at" : "2013-02-13 12:10:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/VMmFl4Oi",
      "expanded_url" : "http:\/\/tinyurl.com\/cd3ns48#",
      "display_url" : "tinyurl.com\/cd3ns48#"
    } ]
  },
  "geo" : { },
  "id_str" : "301645231873462274",
  "text" : "\"The Hammer is a test-your-strength game that's an insertable, light-up dildo.\" http:\/\/t.co\/VMmFl4Oi!",
  "id" : 301645231873462274,
  "created_at" : "2013-02-13 10:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 5, 12 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301639244668092416",
  "geo" : { },
  "id_str" : "301640406268014592",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @TnaKng daf\u00FCr kann man den Slogan zu \"schmelzen im Muttermund, nicht in der Hand\" anpassen!",
  "id" : 301640406268014592,
  "in_reply_to_status_id" : 301639244668092416,
  "created_at" : "2013-02-13 10:34:11 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/25TPBkad",
      "expanded_url" : "http:\/\/imgur.com\/iaFyBrG",
      "display_url" : "imgur.com\/iaFyBrG"
    } ]
  },
  "geo" : { },
  "id_str" : "301634831064911872",
  "text" : "Not on the Jedi council, but still... http:\/\/t.co\/25TPBkad",
  "id" : 301634831064911872,
  "created_at" : "2013-02-13 10:12:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/pcbIZYPB",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/science-environment-21431678",
      "display_url" : "bbc.co.uk\/news\/science-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301613087935578112",
  "text" : "RT @AntRyanET: Sea slug 'disposable penis' astounds http:\/\/t.co\/pcbIZYPB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/pcbIZYPB",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/science-environment-21431678",
        "display_url" : "bbc.co.uk\/news\/science-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301572010037870592",
    "text" : "Sea slug 'disposable penis' astounds http:\/\/t.co\/pcbIZYPB",
    "id" : 301572010037870592,
    "created_at" : "2013-02-13 06:02:24 +0000",
    "user" : {
      "name" : "Ant Ryan",
      "screen_name" : "Ant_Writer",
      "protected" : false,
      "id_str" : "275912281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/808030360567222272\/lkn0k9eQ_normal.jpg",
      "id" : 275912281,
      "verified" : true
    }
  },
  "id" : 301613087935578112,
  "created_at" : "2013-02-13 08:45:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Baxter-Reynolds",
      "screen_name" : "mbrit",
      "indices" : [ 0, 6 ],
      "id_str" : "16111664",
      "id" : 16111664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/o8cBiRdw",
      "expanded_url" : "http:\/\/openSNP.org",
      "display_url" : "openSNP.org"
    } ]
  },
  "in_reply_to_status_id_str" : "301434702974312448",
  "geo" : { },
  "id_str" : "301467811228823552",
  "in_reply_to_user_id" : 16111664,
  "text" : "@mbrit we're working on open data genotypes and exomes with http:\/\/t.co\/o8cBiRdw",
  "id" : 301467811228823552,
  "in_reply_to_status_id" : 301434702974312448,
  "created_at" : "2013-02-12 23:08:21 +0000",
  "in_reply_to_screen_name" : "mbrit",
  "in_reply_to_user_id_str" : "16111664",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Dearborn \u03DF",
      "screen_name" : "rdearborn",
      "indices" : [ 3, 13 ],
      "id_str" : "16990628",
      "id" : 16990628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/ShNlUwLR",
      "expanded_url" : "http:\/\/everydayfeminism.com\/2012\/12\/how-to-talk-to-someone-about-privilege\/",
      "display_url" : "everydayfeminism.com\/2012\/12\/how-to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301465670120534017",
  "text" : "RT @rdearborn: How To Talk To Someone About Privilege Who Doesn't Know What That Is http:\/\/t.co\/ShNlUwLR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/ShNlUwLR",
        "expanded_url" : "http:\/\/everydayfeminism.com\/2012\/12\/how-to-talk-to-someone-about-privilege\/",
        "display_url" : "everydayfeminism.com\/2012\/12\/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301462496223588353",
    "text" : "How To Talk To Someone About Privilege Who Doesn't Know What That Is http:\/\/t.co\/ShNlUwLR",
    "id" : 301462496223588353,
    "created_at" : "2013-02-12 22:47:14 +0000",
    "user" : {
      "name" : "Rachel Dearborn \u03DF",
      "screen_name" : "rdearborn",
      "protected" : false,
      "id_str" : "16990628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616686151198482435\/OQa4Jno2_normal.jpg",
      "id" : 16990628,
      "verified" : false
    }
  },
  "id" : 301465670120534017,
  "created_at" : "2013-02-12 22:59:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INACTIVE JOE",
      "screen_name" : "jtotheizzoe",
      "indices" : [ 3, 15 ],
      "id_str" : "809629697193680896",
      "id" : 809629697193680896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301434285951438848",
  "text" : "RT @jtotheizzoe: Just destroyed my biology class's appetites by telling them how much mite poo is on their face. I love science.  http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/waWbAPaN",
        "expanded_url" : "http:\/\/www.itsokaytobesmart.com\/post\/30551863881\/mite-poo-skin-rosacea",
        "display_url" : "itsokaytobesmart.com\/post\/305518638\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301433764616212480",
    "text" : "Just destroyed my biology class's appetites by telling them how much mite poo is on their face. I love science.  http:\/\/t.co\/waWbAPaN",
    "id" : 301433764616212480,
    "created_at" : "2013-02-12 20:53:04 +0000",
    "user" : {
      "name" : "Joe Hanson",
      "screen_name" : "DrJoeHanson",
      "protected" : false,
      "id_str" : "26099938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684812926205562880\/hDwHS2bt_normal.jpg",
      "id" : 26099938,
      "verified" : true
    }
  },
  "id" : 301434285951438848,
  "created_at" : "2013-02-12 20:55:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ds187",
      "screen_name" : "ds187",
      "indices" : [ 0, 6 ],
      "id_str" : "15895350",
      "id" : 15895350
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 25, 38 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301425228079325185",
  "geo" : { },
  "id_str" : "301425380043153408",
  "in_reply_to_user_id" : 15895350,
  "text" : "@ds187 Die Forschung von @PhilippBayer und mir besteht ja vor allem aus trinken ;)",
  "id" : 301425380043153408,
  "in_reply_to_status_id" : 301425228079325185,
  "created_at" : "2013-02-12 20:19:45 +0000",
  "in_reply_to_screen_name" : "ds187",
  "in_reply_to_user_id_str" : "15895350",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301424673546190850",
  "geo" : { },
  "id_str" : "301425174799069185",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog time for \u00ABwill apologize for food\u00BB-posts!",
  "id" : 301425174799069185,
  "in_reply_to_status_id" : 301424673546190850,
  "created_at" : "2013-02-12 20:18:56 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philippos Irmfried Ummo von und zu Eulenspiegel",
      "screen_name" : "pr1miTiv3",
      "indices" : [ 3, 13 ],
      "id_str" : "64841875",
      "id" : 64841875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/6XB4Mqvf",
      "expanded_url" : "http:\/\/static.twoday.net\/gebattmer\/images\/tanzdrauf.jpg",
      "display_url" : "static.twoday.net\/gebattmer\/imag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301423340646723584",
  "text" : "RT @pr1miTiv3: Der rote Elefant hat recht! http:\/\/t.co\/6XB4Mqvf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.destroytwitter.com\" rel=\"nofollow\"\u003EDestroyTwitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/6XB4Mqvf",
        "expanded_url" : "http:\/\/static.twoday.net\/gebattmer\/images\/tanzdrauf.jpg",
        "display_url" : "static.twoday.net\/gebattmer\/imag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301423057589899265",
    "text" : "Der rote Elefant hat recht! http:\/\/t.co\/6XB4Mqvf",
    "id" : 301423057589899265,
    "created_at" : "2013-02-12 20:10:31 +0000",
    "user" : {
      "name" : "Philippos Irmfried Ummo von und zu Eulenspiegel",
      "screen_name" : "pr1miTiv3",
      "protected" : false,
      "id_str" : "64841875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505734036191330306\/TrzW5oqc_normal.jpeg",
      "id" : 64841875,
      "verified" : false
    }
  },
  "id" : 301423340646723584,
  "created_at" : "2013-02-12 20:11:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "indices" : [ 3, 19 ],
      "id_str" : "15150453",
      "id" : 15150453
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lehrer",
      "indices" : [ 120, 127 ]
    }, {
      "text" : "meme",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/K8aTeuyO",
      "expanded_url" : "http:\/\/twitpic.com\/c35o34",
      "display_url" : "twitpic.com\/c35o34"
    } ]
  },
  "geo" : { },
  "id_str" : "301419993684393986",
  "text" : "RT @AndreaKuszewski: \"I don't always apologize for plagiarizing, but when I do, I get paid $20K.\"  http:\/\/t.co\/K8aTeuyO #Lehrer #meme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Lehrer",
        "indices" : [ 99, 106 ]
      }, {
        "text" : "meme",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/K8aTeuyO",
        "expanded_url" : "http:\/\/twitpic.com\/c35o34",
        "display_url" : "twitpic.com\/c35o34"
      } ]
    },
    "geo" : { },
    "id_str" : "301419914466578432",
    "text" : "\"I don't always apologize for plagiarizing, but when I do, I get paid $20K.\"  http:\/\/t.co\/K8aTeuyO #Lehrer #meme",
    "id" : 301419914466578432,
    "created_at" : "2013-02-12 19:58:02 +0000",
    "user" : {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "protected" : false,
      "id_str" : "15150453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879595697800060928\/-tdsZ4nM_normal.jpg",
      "id" : 15150453,
      "verified" : true
    }
  },
  "id" : 301419993684393986,
  "created_at" : "2013-02-12 19:58:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/b8EZMEde",
      "expanded_url" : "http:\/\/j.mp\/XyPsmJ",
      "display_url" : "j.mp\/XyPsmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "301419089866412032",
  "text" : "Giving STDs to goats. For science! http:\/\/t.co\/b8EZMEde",
  "id" : 301419089866412032,
  "created_at" : "2013-02-12 19:54:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301414756814815234",
  "geo" : { },
  "id_str" : "301415236991344640",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon but my lies totally confirm my point!",
  "id" : 301415236991344640,
  "in_reply_to_status_id" : 301414756814815234,
  "created_at" : "2013-02-12 19:39:27 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "indices" : [ 3, 19 ],
      "id_str" : "15150453",
      "id" : 15150453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301413510741651456",
  "text" : "RT @AndreaKuszewski: Someone please photoshop a \"I don't always apologize for plagiarizing, but when I do, I get paid $20K\" meme pic of  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301413408278974464",
    "text" : "Someone please photoshop a \"I don't always apologize for plagiarizing, but when I do, I get paid $20K\" meme pic of Lehrer.",
    "id" : 301413408278974464,
    "created_at" : "2013-02-12 19:32:11 +0000",
    "user" : {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "protected" : false,
      "id_str" : "15150453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879595697800060928\/-tdsZ4nM_normal.jpg",
      "id" : 15150453,
      "verified" : true
    }
  },
  "id" : 301413510741651456,
  "created_at" : "2013-02-12 19:32:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301413134256709634",
  "text" : "Certain German Ex-Ministers should pay attention to Lehrer... They might find great new carrier opportunities...",
  "id" : 301413134256709634,
  "created_at" : "2013-02-12 19:31:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301412274848018432",
  "text" : "So Jonah Lehrer was paid $20,000 to talk about the topic he loves most: Himself. Well played...",
  "id" : 301412274848018432,
  "created_at" : "2013-02-12 19:27:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/bFMFOaQR",
      "expanded_url" : "http:\/\/j.mp\/X2tDzI",
      "display_url" : "j.mp\/X2tDzI"
    } ]
  },
  "geo" : { },
  "id_str" : "301385287681052672",
  "text" : "How to walk on ice http:\/\/t.co\/bFMFOaQR",
  "id" : 301385287681052672,
  "created_at" : "2013-02-12 17:40:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/tMFPyAKT",
      "expanded_url" : "http:\/\/j.mp\/12bNrVi",
      "display_url" : "j.mp\/12bNrVi"
    } ]
  },
  "geo" : { },
  "id_str" : "301372856556716033",
  "text" : "Run! http:\/\/t.co\/tMFPyAKT",
  "id" : 301372856556716033,
  "created_at" : "2013-02-12 16:51:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/NPmWBtEh",
      "expanded_url" : "http:\/\/instagr.am\/p\/VoqQ6hBwtg\/",
      "display_url" : "instagr.am\/p\/VoqQ6hBwtg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "301346328968048640",
  "text" : "Clowns! http:\/\/t.co\/NPmWBtEh",
  "id" : 301346328968048640,
  "created_at" : "2013-02-12 15:05:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301338623649923073",
  "geo" : { },
  "id_str" : "301339744414089216",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy wow, thanks a lot!",
  "id" : 301339744414089216,
  "in_reply_to_status_id" : 301338623649923073,
  "created_at" : "2013-02-12 14:39:28 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301337179123236864",
  "text" : "\u00ABUnd sie bleiben dann auch bitte nicht stehen sondern setzen sich.\u00BB\u2014\u00ABIch wei\u00DF, es gibt nur einen Notfallsessel.\u00BB",
  "id" : 301337179123236864,
  "created_at" : "2013-02-12 14:29:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/qcNP3khX",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/File:Alfred_Russel_Wallace_engraving.jpg",
      "display_url" : "en.wikipedia.org\/wiki\/File:Alfr\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.992883, 8.262981 ]
  },
  "id_str" : "301326781955330048",
  "text" : "Happy Darwin Day! http:\/\/t.co\/qcNP3khX",
  "id" : 301326781955330048,
  "created_at" : "2013-02-12 13:47:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301323133334466560",
  "geo" : { },
  "id_str" : "301324542436073473",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich hab geh\u00F6rt Gleichschaltung ist auch verboten ;)",
  "id" : 301324542436073473,
  "in_reply_to_status_id" : 301323133334466560,
  "created_at" : "2013-02-12 13:39:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301312934934614016",
  "geo" : { },
  "id_str" : "301315481032335360",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen gef\u00E4llt mir nach den ersten ~10% sehr gut. :)",
  "id" : 301315481032335360,
  "in_reply_to_status_id" : 301312934934614016,
  "created_at" : "2013-02-12 13:03:03 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301309801269436416",
  "geo" : { },
  "id_str" : "301312096157712384",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen mal schauen ob ich daf\u00FCr die Lust aufbringe, ich bin eigentlich kein Tatort-Fan.",
  "id" : 301312096157712384,
  "in_reply_to_status_id" : 301309801269436416,
  "created_at" : "2013-02-12 12:49:36 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "tarzun",
      "screen_name" : "tarzun",
      "indices" : [ 10, 17 ],
      "id_str" : "1632280560",
      "id" : 1632280560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/lpfcEWsY",
      "expanded_url" : "http:\/\/www.gedankenstuecke.de\/archives\/2390-Mehr-Details-zu-INDECT.html",
      "display_url" : "gedankenstuecke.de\/archives\/2390-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301309275396001792",
  "geo" : { },
  "id_str" : "301311326460968961",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @tarzun ich vermute es geht um dies: http:\/\/t.co\/lpfcEWsY",
  "id" : 301311326460968961,
  "in_reply_to_status_id" : 301309275396001792,
  "created_at" : "2013-02-12 12:46:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301309189198852096",
  "geo" : { },
  "id_str" : "301309451246387200",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen der Tatort sagt mir nichts, aber das k\u00F6nnte gut sein, zumindest nachdem was ich gestern am Bahnhof gesehen habe. ;)",
  "id" : 301309451246387200,
  "in_reply_to_status_id" : 301309189198852096,
  "created_at" : "2013-02-12 12:39:05 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301307440081801217",
  "geo" : { },
  "id_str" : "301308707478855681",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen ich f\u00FCrchte das sie unangek\u00FCndigt aus \"Krankheitsgr\u00FCnden\" geschlossen haben k\u00F6nnten.",
  "id" : 301308707478855681,
  "in_reply_to_status_id" : 301307440081801217,
  "created_at" : "2013-02-12 12:36:08 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/MtmxpI3x",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/the-curious-wavefunction\/2013\/02\/03\/is-the-age-of-scientific-genius-over\/",
      "display_url" : "blogs.scientificamerican.com\/the-curious-wa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301305885681147905",
  "geo" : { },
  "id_str" : "301308537169137664",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a dieser Artikel (und der dort verlinkte) hatten mich drauf gebracht: http:\/\/t.co\/MtmxpI3x",
  "id" : 301308537169137664,
  "in_reply_to_status_id" : 301305885681147905,
  "created_at" : "2013-02-12 12:35:27 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301307037634162689",
  "text" : "Mal schauen ob man am Tag nach Rosenmontag in Mainz Blutspenden kann.",
  "id" : 301307037634162689,
  "created_at" : "2013-02-12 12:29:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/p1CgT8Ft",
      "expanded_url" : "http:\/\/j.mp\/Y9luaZ",
      "display_url" : "j.mp\/Y9luaZ"
    } ]
  },
  "geo" : { },
  "id_str" : "301302797687742464",
  "text" : "Short Versus Long Term Benefits and the Evolution of Cooperation in the Prisoner's Dilemma Game http:\/\/t.co\/p1CgT8Ft",
  "id" : 301302797687742464,
  "created_at" : "2013-02-12 12:12:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/re052iSM",
      "expanded_url" : "http:\/\/j.mp\/Y9k689",
      "display_url" : "j.mp\/Y9k689"
    } ]
  },
  "geo" : { },
  "id_str" : "301301099741204480",
  "text" : "Phylomemetic Patterns in Science Evolution\u2014The Rise and Fall of Scientific Fields http:\/\/t.co\/re052iSM",
  "id" : 301301099741204480,
  "created_at" : "2013-02-12 12:05:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/VWmQeRmU",
      "expanded_url" : "http:\/\/j.mp\/WGmW75",
      "display_url" : "j.mp\/WGmW75"
    } ]
  },
  "geo" : { },
  "id_str" : "301296039242121216",
  "text" : "\u00AB'Eh, another teddy bear with a vagina, who cares' Bad crafts are like drugs; you have to keep upping the dose to feel\u00BB http:\/\/t.co\/VWmQeRmU",
  "id" : 301296039242121216,
  "created_at" : "2013-02-12 11:45:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/iMfkDAOw",
      "expanded_url" : "http:\/\/j.mp\/Y9h0Rz",
      "display_url" : "j.mp\/Y9h0Rz"
    } ]
  },
  "geo" : { },
  "id_str" : "301295329691697152",
  "text" : "The sad state of Research http:\/\/t.co\/iMfkDAOw",
  "id" : 301295329691697152,
  "created_at" : "2013-02-12 11:42:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301285861125931009",
  "text" : "\u00ABIch bin katholisch, ich muss nicht in die Kirche!\u00BB",
  "id" : 301285861125931009,
  "created_at" : "2013-02-12 11:05:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "indices" : [ 3, 17 ],
      "id_str" : "15154811",
      "id" : 15154811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Coffee",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "Enemas",
      "indices" : [ 117, 124 ]
    }, {
      "text" : "Addition",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301275259905122304",
  "text" : "RT @phylogenomics: This calls out \"Study the microbiome\" or something like that; oh it also calls out \"Ewww\" #Coffee #Enemas #Addition h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Coffee",
        "indices" : [ 90, 97 ]
      }, {
        "text" : "Enemas",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "Addition",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/gcCe5Fbo",
        "expanded_url" : "http:\/\/abcn.ws\/Y7IDua",
        "display_url" : "abcn.ws\/Y7IDua"
      } ]
    },
    "geo" : { },
    "id_str" : "301118400564969473",
    "text" : "This calls out \"Study the microbiome\" or something like that; oh it also calls out \"Ewww\" #Coffee #Enemas #Addition http:\/\/t.co\/gcCe5Fbo",
    "id" : 301118400564969473,
    "created_at" : "2013-02-11 23:59:55 +0000",
    "user" : {
      "name" : "Jonathan Eisen, Guardian of Microbial Diversity \uD83D\uDCA5\uD83D\uDD06",
      "screen_name" : "phylogenomics",
      "protected" : false,
      "id_str" : "15154811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751288576403382273\/AKfTiFxx_normal.jpg",
      "id" : 15154811,
      "verified" : true
    }
  },
  "id" : 301275259905122304,
  "created_at" : "2013-02-12 10:23:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suman Biswas",
      "screen_name" : "amateursuman",
      "indices" : [ 3, 16 ],
      "id_str" : "22247075",
      "id" : 22247075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301257386889469953",
  "text" : "RT @amateursuman: Take me down to the Vatican City,\nWhere the food is great \nBut the nightlife's shitty.\n\nOh won't you please make me Pope?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/drafts\/id502385074?mt=8&uo=4\" rel=\"nofollow\"\u003EDrafts on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301257266290651136",
    "text" : "Take me down to the Vatican City,\nWhere the food is great \nBut the nightlife's shitty.\n\nOh won't you please make me Pope?",
    "id" : 301257266290651136,
    "created_at" : "2013-02-12 09:11:44 +0000",
    "user" : {
      "name" : "Suman Biswas",
      "screen_name" : "amateursuman",
      "protected" : false,
      "id_str" : "22247075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000677237177\/8ff4e5616cfb26ff1381653e0ec8940a_normal.jpeg",
      "id" : 22247075,
      "verified" : false
    }
  },
  "id" : 301257386889469953,
  "created_at" : "2013-02-12 09:12:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301256783203278848",
  "geo" : { },
  "id_str" : "301257314982322179",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog nicht wenn \/b es verhindern kann. ;)",
  "id" : 301257314982322179,
  "in_reply_to_status_id" : 301256783203278848,
  "created_at" : "2013-02-12 09:11:55 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301255107218112513",
  "geo" : { },
  "id_str" : "301255344519270402",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon da hat die Autokorrektur mal passend zugeschlagen ;)",
  "id" : 301255344519270402,
  "in_reply_to_status_id" : 301255107218112513,
  "created_at" : "2013-02-12 09:04:05 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 12, 21 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301253472160997376",
  "geo" : { },
  "id_str" : "301253728781074432",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj als @Senficon meinte \"da liegt ein Pl\u00FCschorga\" dachte ich auch zuerst an einen bei uns im Garten erfrorenen Karnevalisten...",
  "id" : 301253728781074432,
  "in_reply_to_status_id" : 301253472160997376,
  "created_at" : "2013-02-12 08:57:40 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/h4MQzKpk",
      "expanded_url" : "http:\/\/instagr.am\/p\/VoABH8hwhG\/",
      "display_url" : "instagr.am\/p\/VoABH8hwhG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "301253335116296192",
  "text" : "\u00AB\u2018Ground\u2019! That\u2019s it! Ground! Ha! I wonder if it\u2019ll be friends with me? Hello Ground!\u00BB http:\/\/t.co\/h4MQzKpk",
  "id" : 301253335116296192,
  "created_at" : "2013-02-12 08:56:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301249243073609729",
  "text" : "\u00ABWTF?! Da ist ein riesiger Pl\u00FCsch-Orca im Beet!\u00BB",
  "id" : 301249243073609729,
  "created_at" : "2013-02-12 08:39:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    }, {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 10, 17 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301117820605980672",
  "geo" : { },
  "id_str" : "301117915464339456",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai @foxeen ich hab es einfach bei Amazon gekauft ;)",
  "id" : 301117915464339456,
  "in_reply_to_status_id" : 301117820605980672,
  "created_at" : "2013-02-11 23:58:00 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 118, 127 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301115415319412736",
  "geo" : { },
  "id_str" : "301117159118094336",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen Da alle anderen Lieferungen gerade noch nicht angekommen sind bekommt das jetzt auch gleich mal den Vorzug :) @Roterhai",
  "id" : 301117159118094336,
  "in_reply_to_status_id" : 301115415319412736,
  "created_at" : "2013-02-11 23:54:59 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/u6zRchkt",
      "expanded_url" : "http:\/\/www.goodreads.com\/book\/show\/981761.Image_and_Logic",
      "display_url" : "goodreads.com\/book\/show\/9817\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301044436236902401",
  "geo" : { },
  "id_str" : "301116349344796672",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a btw. Hast du Image &amp; Logic gelesen? (ich nicht, und bin momentan nicht bereit daf\u00FCr so viel zu zahlen ;)) http:\/\/t.co\/u6zRchkt",
  "id" : 301116349344796672,
  "in_reply_to_status_id" : 301044436236902401,
  "created_at" : "2013-02-11 23:51:46 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    }, {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 8, 17 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301114648638390272",
  "geo" : { },
  "id_str" : "301114868277325825",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen @Roterhai Danke :)",
  "id" : 301114868277325825,
  "in_reply_to_status_id" : 301114648638390272,
  "created_at" : "2013-02-11 23:45:53 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301114528760995840",
  "geo" : { },
  "id_str" : "301114673598697472",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Ich wollte ja Daten sch\u00FCtzen und anonymisieren. ;)",
  "id" : 301114673598697472,
  "in_reply_to_status_id" : 301114528760995840,
  "created_at" : "2013-02-11 23:45:07 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/fJWDlSKU",
      "expanded_url" : "http:\/\/j.mp\/V0n4Qa",
      "display_url" : "j.mp\/V0n4Qa"
    } ]
  },
  "geo" : { },
  "id_str" : "301114562520956928",
  "text" : "\u00ABThese two figures are not communicating with one another\u2026\u00BB http:\/\/t.co\/fJWDlSKU",
  "id" : 301114562520956928,
  "created_at" : "2013-02-11 23:44:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301112937974734849",
  "text" : "\u00ABIch habe getr\u00E4umt das der Vorstand aus eigener Dummheit fast von einem Hai gefressen wird. Was mir das wohl sagen soll?\u00BB",
  "id" : 301112937974734849,
  "created_at" : "2013-02-11 23:38:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301097523513266176",
  "geo" : { },
  "id_str" : "301097703788658689",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot gef\u00FChlt ist das auch die bessere Wahl :)",
  "id" : 301097703788658689,
  "in_reply_to_status_id" : 301097523513266176,
  "created_at" : "2013-02-11 22:37:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301097215038992384",
  "geo" : { },
  "id_str" : "301097328956293120",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot was findest du schlimmer? :P",
  "id" : 301097328956293120,
  "in_reply_to_status_id" : 301097215038992384,
  "created_at" : "2013-02-11 22:36:11 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301096827565006848",
  "geo" : { },
  "id_str" : "301096947014578176",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich wei\u00DF nicht wovon man mehr trinken kann: Blut oder Roh\u00F6l ;)",
  "id" : 301096947014578176,
  "in_reply_to_status_id" : 301096827565006848,
  "created_at" : "2013-02-11 22:34:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301087721600991232",
  "geo" : { },
  "id_str" : "301087809823965184",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Du bist eine solche Qualit\u00E4tsjournalistin ;)",
  "id" : 301087809823965184,
  "in_reply_to_status_id" : 301087721600991232,
  "created_at" : "2013-02-11 21:58:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301085252443574274",
  "geo" : { },
  "id_str" : "301085366310563840",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Naja, [citation needed] w\u00FCrde ich sagen. ;)",
  "id" : 301085366310563840,
  "in_reply_to_status_id" : 301085252443574274,
  "created_at" : "2013-02-11 21:48:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301073390599561216",
  "geo" : { },
  "id_str" : "301073558019395584",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn Ah, that just saves all the \u201Cnormal\u201D edits you might have done (editing name, avatar, phenotypes etc).",
  "id" : 301073558019395584,
  "in_reply_to_status_id" : 301073390599561216,
  "created_at" : "2013-02-11 21:01:44 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301071019576266752",
  "geo" : { },
  "id_str" : "301071554886922240",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn Every time you step off the Aria the new data should be on openSNP about a minute afterwards without doing a thing on your end",
  "id" : 301071554886922240,
  "in_reply_to_status_id" : 301071019576266752,
  "created_at" : "2013-02-11 20:53:46 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301071019576266752",
  "geo" : { },
  "id_str" : "301071192238989312",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn \u2026the push-API. So you don\u2019t have to do anything to get latest data into openSNP",
  "id" : 301071192238989312,
  "in_reply_to_status_id" : 301071019576266752,
  "created_at" : "2013-02-11 20:52:20 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301071019576266752",
  "geo" : { },
  "id_str" : "301071137209724929",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn not completely: Once you change the settings it will fetch all data again. But new data gets automatically imported using\u2026",
  "id" : 301071137209724929,
  "in_reply_to_status_id" : 301071019576266752,
  "created_at" : "2013-02-11 20:52:07 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301069965174378496",
  "geo" : { },
  "id_str" : "301070728319610881",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn it has your data correctly but doesn\u2019t plot a single data point, try again tomorrow. If it still doesn\u2019t work let me know.",
  "id" : 301070728319610881,
  "in_reply_to_status_id" : 301069965174378496,
  "created_at" : "2013-02-11 20:50:29 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301069865727451136",
  "geo" : { },
  "id_str" : "301070029829586944",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn that has a \u201Csave fitbit-settings\u201D-button, right?",
  "id" : 301070029829586944,
  "in_reply_to_status_id" : 301069865727451136,
  "created_at" : "2013-02-11 20:47:43 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301069324456693760",
  "geo" : { },
  "id_str" : "301069638056419329",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn and let me have a look whether it downloaded your information.",
  "id" : 301069638056419329,
  "in_reply_to_status_id" : 301069324456693760,
  "created_at" : "2013-02-11 20:46:09 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301069209193041921",
  "geo" : { },
  "id_str" : "301069574416257024",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn uh, on which page is it missing?",
  "id" : 301069574416257024,
  "in_reply_to_status_id" : 301069209193041921,
  "created_at" : "2013-02-11 20:45:54 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301068085316706304",
  "geo" : { },
  "id_str" : "301068460635590656",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn great (though I\u2019ve to say I\u2019m impressed how many ppl already connected their fitbit-accounts to openSNP).",
  "id" : 301068460635590656,
  "in_reply_to_status_id" : 301068085316706304,
  "created_at" : "2013-02-11 20:41:29 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301067045523558400",
  "geo" : { },
  "id_str" : "301067372490534913",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn and you need to get an activity tracker as well, as I want to be able to counter-stalk you more efficiently ;)",
  "id" : 301067372490534913,
  "in_reply_to_status_id" : 301067045523558400,
  "created_at" : "2013-02-11 20:37:09 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301065923475951616",
  "geo" : { },
  "id_str" : "301066840120119297",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn you need to connect your account to openSNP! :D",
  "id" : 301066840120119297,
  "in_reply_to_status_id" : 301065923475951616,
  "created_at" : "2013-02-11 20:35:02 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301050692284608512",
  "text" : "Heute \u00FCber den Mainzer Hbf fahren. Ich hatte schon mal bessere Ideen...",
  "id" : 301050692284608512,
  "created_at" : "2013-02-11 19:30:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "indices" : [ 3, 9 ],
      "id_str" : "17567533",
      "id" : 17567533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/m4803v5G",
      "expanded_url" : "http:\/\/www.denimandtweed.com\/2013\/02\/evolutionary-psychology-youre-doing-it.html",
      "display_url" : "denimandtweed.com\/2013\/02\/evolut\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301048781204512768",
  "text" : "RT @BoraZ: Evolutionary psychology: You're doing it wrong (but you could do it better!) http:\/\/t.co\/m4803v5G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/m4803v5G",
        "expanded_url" : "http:\/\/www.denimandtweed.com\/2013\/02\/evolutionary-psychology-youre-doing-it.html",
        "display_url" : "denimandtweed.com\/2013\/02\/evolut\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301047568434085891",
    "text" : "Evolutionary psychology: You're doing it wrong (but you could do it better!) http:\/\/t.co\/m4803v5G",
    "id" : 301047568434085891,
    "created_at" : "2013-02-11 19:18:28 +0000",
    "user" : {
      "name" : "Bora Zivkovic",
      "screen_name" : "BoraZ",
      "protected" : false,
      "id_str" : "17567533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3651779136\/b927bab618cdf46063f9c265817f3a8a_normal.jpeg",
      "id" : 17567533,
      "verified" : false
    }
  },
  "id" : 301048781204512768,
  "created_at" : "2013-02-11 19:23:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301044436236902401",
  "geo" : { },
  "id_str" : "301045308287229953",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a (und ich bereue es wegen des Printformats fast ein Jahr vor mir hergeschoben zu haben ;))",
  "id" : 301045308287229953,
  "in_reply_to_status_id" : 301044436236902401,
  "created_at" : "2013-02-11 19:09:29 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301044436236902401",
  "geo" : { },
  "id_str" : "301045050224295938",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a sehr! Ist fast schade das ich Kuhns Structure erst gelesen habe, werde ich jetzt glaube ich noch mal im Anschluss wiederholen.",
  "id" : 301045050224295938,
  "in_reply_to_status_id" : 301044436236902401,
  "created_at" : "2013-02-11 19:08:27 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301043627759656960",
  "text" : "\u00ABVoll progressiv diese Christen. In 'Du sollst nicht begehren deines N\u00E4chsten Weib' nutzen sie das generische Femininum.\u00BB",
  "id" : 301043627759656960,
  "created_at" : "2013-02-11 19:02:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/meeKycJ8",
      "expanded_url" : "http:\/\/www.megaleecher.net\/uploads\/hp-ink-cost.jpg",
      "display_url" : "megaleecher.net\/uploads\/hp-ink\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "301041246233833472",
  "geo" : { },
  "id_str" : "301041619979862016",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/meeKycJ8",
  "id" : 301041619979862016,
  "in_reply_to_status_id" : 301041246233833472,
  "created_at" : "2013-02-11 18:54:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 49, 53 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301038152477446144",
  "text" : "\u00ABDu warst doch auch auf der Einweihungsparty von @scy. Kennst du dich mit Vaterschaftstests aus?\u00BB",
  "id" : 301038152477446144,
  "created_at" : "2013-02-11 18:41:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/N9vsjAU8",
      "expanded_url" : "http:\/\/www.playdna.co.uk\/",
      "display_url" : "playdna.co.uk"
    } ]
  },
  "geo" : { },
  "id_str" : "300977714121277440",
  "text" : "Why would you pay ~600\u20AC (or more!) for a gel picture featuring 5 lanes? o_O http:\/\/t.co\/N9vsjAU8",
  "id" : 300977714121277440,
  "created_at" : "2013-02-11 14:40:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/VtQoiuiv",
      "expanded_url" : "http:\/\/bit.ly\/155FlNB",
      "display_url" : "bit.ly\/155FlNB"
    } ]
  },
  "geo" : { },
  "id_str" : "300931962011516928",
  "text" : "RT @Lobot: Freak. http:\/\/t.co\/VtQoiuiv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 27 ],
        "url" : "http:\/\/t.co\/VtQoiuiv",
        "expanded_url" : "http:\/\/bit.ly\/155FlNB",
        "display_url" : "bit.ly\/155FlNB"
      } ]
    },
    "geo" : { },
    "id_str" : "300931350419079170",
    "text" : "Freak. http:\/\/t.co\/VtQoiuiv",
    "id" : 300931350419079170,
    "created_at" : "2013-02-11 11:36:39 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 300931962011516928,
  "created_at" : "2013-02-11 11:39:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/c8uLCg4v",
      "expanded_url" : "http:\/\/tinyurl.com\/ayaah65",
      "display_url" : "tinyurl.com\/ayaah65"
    } ]
  },
  "geo" : { },
  "id_str" : "300926316293791744",
  "text" : "Crowdsourced coders take on immunology Big Data http:\/\/t.co\/c8uLCg4v",
  "id" : 300926316293791744,
  "created_at" : "2013-02-11 11:16:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 72 ],
      "url" : "https:\/\/t.co\/o0vGTaFC",
      "expanded_url" : "https:\/\/ifttt.com\/",
      "display_url" : "ifttt.com"
    } ]
  },
  "in_reply_to_status_id_str" : "300921545952468993",
  "geo" : { },
  "id_str" : "300921819861487616",
  "in_reply_to_user_id" : 18362640,
  "text" : "@seb666 Daf\u00FCr nutze ich eine einfache IFTTT Regel: https:\/\/t.co\/o0vGTaFC",
  "id" : 300921819861487616,
  "in_reply_to_status_id" : 300921545952468993,
  "created_at" : "2013-02-11 10:58:47 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/dB7K62nT",
      "expanded_url" : "http:\/\/i.imgur.com\/osnhIqc.jpg",
      "display_url" : "i.imgur.com\/osnhIqc.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "300915657640394752",
  "text" : "Choose the shape of your headstone to get maximum lulz after death http:\/\/t.co\/dB7K62nT",
  "id" : 300915657640394752,
  "created_at" : "2013-02-11 10:34:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/bXQjryHU",
      "expanded_url" : "http:\/\/www.ebi.ac.uk\/QuickGO\/GTerm?id=GO:0045900#term=ancchart",
      "display_url" : "ebi.ac.uk\/QuickGO\/GTerm?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300913830077280259",
  "text" : "I love the EBI's QuickGO ancestor charts http:\/\/t.co\/bXQjryHU",
  "id" : 300913830077280259,
  "created_at" : "2013-02-11 10:27:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/4N9yBfYZ",
      "expanded_url" : "http:\/\/i.imgur.com\/1a6otTJ.jpg",
      "display_url" : "i.imgur.com\/1a6otTJ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "300912425933365248",
  "text" : "Instagram filters http:\/\/t.co\/4N9yBfYZ",
  "id" : 300912425933365248,
  "created_at" : "2013-02-11 10:21:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/Fd2s1Jd9",
      "expanded_url" : "http:\/\/tinyurl.com\/cr4at72",
      "display_url" : "tinyurl.com\/cr4at72"
    } ]
  },
  "geo" : { },
  "id_str" : "300901447212605440",
  "text" : "Mathematical Literacy: A necessary skill for the 21st century http:\/\/t.co\/Fd2s1Jd9",
  "id" : 300901447212605440,
  "created_at" : "2013-02-11 09:37:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 0, 12 ],
      "id_str" : "53560219",
      "id" : 53560219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300888438624903169",
  "geo" : { },
  "id_str" : "300890090455060480",
  "in_reply_to_user_id" : 53560219,
  "text" : "@openscience I agree in general. But I'm a bit skeptical about implementation. Hard to reward \"right\". Otherwise ppl game gamification. ;)",
  "id" : 300890090455060480,
  "in_reply_to_status_id" : 300888438624903169,
  "created_at" : "2013-02-11 08:52:42 +0000",
  "in_reply_to_screen_name" : "openscience",
  "in_reply_to_user_id_str" : "53560219",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Science",
      "screen_name" : "openscience",
      "indices" : [ 0, 12 ],
      "id_str" : "53560219",
      "id" : 53560219
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300887293751861248",
  "geo" : { },
  "id_str" : "300887807860305920",
  "in_reply_to_user_id" : 53560219,
  "text" : "@openscience yes, I read it some years ago. It\u2019s nice to see how the message is transformed with scientists as primary target. :)",
  "id" : 300887807860305920,
  "in_reply_to_status_id" : 300887293751861248,
  "created_at" : "2013-02-11 08:43:38 +0000",
  "in_reply_to_screen_name" : "openscience",
  "in_reply_to_user_id_str" : "53560219",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/Bv0Dp8gc",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/ResearchBloggingSocialScienceEnglish\/~3\/qr5jOXflyis\/why-scientists-should-play-games.html",
      "display_url" : "feedproxy.google.com\/~r\/ResearchBlo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300885055788695552",
  "text" : "Why playing video games is important for scientists? They teach resistance to inevitable failures &amp; rejections http:\/\/t.co\/Bv0Dp8gc",
  "id" : 300885055788695552,
  "created_at" : "2013-02-11 08:32:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 5, 14 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/Swlmrvsg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_-8j8c7iL3E",
      "display_url" : "youtube.com\/watch?v=_-8j8c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096269, 8.28303984 ]
  },
  "id_str" : "300751744751788032",
  "text" : "Wenn @senficon von den Parteiveranstaltungen erz\u00E4hlt auf denen sie war. http:\/\/t.co\/Swlmrvsg",
  "id" : 300751744751788032,
  "created_at" : "2013-02-10 23:42:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "indices" : [ 3, 18 ],
      "id_str" : "19416598",
      "id" : 19416598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300730079527460864",
  "text" : "RT @leonidkruglyak: JMP model \u201Coperated through a series of Excel spreadsheets, completed manually, by a process of copying and pasting\u201D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/mTlpdlTN",
        "expanded_url" : "http:\/\/bit.ly\/WZhTLd",
        "display_url" : "bit.ly\/WZhTLd"
      } ]
    },
    "geo" : { },
    "id_str" : "300729331636903937",
    "text" : "JMP model \u201Coperated through a series of Excel spreadsheets, completed manually, by a process of copying and pasting\u201D http:\/\/t.co\/mTlpdlTN",
    "id" : 300729331636903937,
    "created_at" : "2013-02-10 22:13:54 +0000",
    "user" : {
      "name" : "Leonid Kruglyak",
      "screen_name" : "leonidkruglyak",
      "protected" : false,
      "id_str" : "19416598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1095542276\/MyRecentPhoto_normal.jpg",
      "id" : 19416598,
      "verified" : false
    }
  },
  "id" : 300730079527460864,
  "created_at" : "2013-02-10 22:16:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/qqcDJ6eE",
      "expanded_url" : "http:\/\/ikillmusic.com\/forum\/is-there-any-place-left-for-the-live-album\/",
      "display_url" : "ikillmusic.com\/forum\/is-there\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300729983029088256",
  "text" : "Is There Any Place Left For The Live Album? http:\/\/t.co\/qqcDJ6eE",
  "id" : 300729983029088256,
  "created_at" : "2013-02-10 22:16:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300726619620925440",
  "text" : "\u00ABGiant Death Robot, 3 people hung out.\u00BB It\u2019s science! (insert mad laughter here)",
  "id" : 300726619620925440,
  "created_at" : "2013-02-10 22:03:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Primate Diaries",
      "screen_name" : "primatediaries",
      "indices" : [ 3, 18 ],
      "id_str" : "68641036",
      "id" : 68641036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/P1KNFG6q",
      "expanded_url" : "http:\/\/j.mp\/Yk8dLv",
      "display_url" : "j.mp\/Yk8dLv"
    } ]
  },
  "geo" : { },
  "id_str" : "300694636203233280",
  "text" : "RT @primatediaries: Noam Chomsky on the biology of human language: http:\/\/t.co\/P1KNFG6q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/P1KNFG6q",
        "expanded_url" : "http:\/\/j.mp\/Yk8dLv",
        "display_url" : "j.mp\/Yk8dLv"
      } ]
    },
    "geo" : { },
    "id_str" : "300692951745560576",
    "text" : "Noam Chomsky on the biology of human language: http:\/\/t.co\/P1KNFG6q",
    "id" : 300692951745560576,
    "created_at" : "2013-02-10 19:49:20 +0000",
    "user" : {
      "name" : "The Primate Diaries",
      "screen_name" : "primatediaries",
      "protected" : false,
      "id_str" : "68641036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2264691905\/r5tyfczkfq6jiqha65rc_normal.jpeg",
      "id" : 68641036,
      "verified" : false
    }
  },
  "id" : 300694636203233280,
  "created_at" : "2013-02-10 19:56:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/j9E872Eq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=P2jn_lxrrPg",
      "display_url" : "youtube.com\/watch?v=P2jn_l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300687176553865216",
  "text" : "\u00ABAs a retired classical singer who works as a maid in BDSM clubs (seriously) I approve of this\u00BB http:\/\/t.co\/j9E872Eq",
  "id" : 300687176553865216,
  "created_at" : "2013-02-10 19:26:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 41, 50 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/vbDGh6jy",
      "expanded_url" : "http:\/\/j.mp\/Z3DrfS",
      "display_url" : "j.mp\/Z3DrfS"
    } ]
  },
  "geo" : { },
  "id_str" : "300674239260934145",
  "text" : "Amanda Palmer: \"Hallelujah\" (wie gut das @senficon noch nicht zur\u00FCck ist) http:\/\/t.co\/vbDGh6jy",
  "id" : 300674239260934145,
  "created_at" : "2013-02-10 18:34:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/hbgOKDC9",
      "expanded_url" : "http:\/\/i.qkme.me\/35bu2m.jpg",
      "display_url" : "i.qkme.me\/35bu2m.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "300638999616319489",
  "text" : "The spirit is willing\u2026 http:\/\/t.co\/hbgOKDC9",
  "id" : 300638999616319489,
  "created_at" : "2013-02-10 16:14:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/q090yrfI",
      "expanded_url" : "http:\/\/j.mp\/14LwFdX",
      "display_url" : "j.mp\/14LwFdX"
    } ]
  },
  "geo" : { },
  "id_str" : "300619931211423745",
  "text" : "Behold, tentacle-porn lovers: Air-powered 3D-printed robot tentacle http:\/\/t.co\/q090yrfI",
  "id" : 300619931211423745,
  "created_at" : "2013-02-10 14:59:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300585859521069058",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a Danke das du mich vor einiger Zeit auf Fleck hingewiesen hast :)",
  "id" : 300585859521069058,
  "created_at" : "2013-02-10 12:43:48 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "indices" : [ 3, 8 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300584642912862209",
  "text" : "RT @mims: \"I agree with the weaker version of the singularity \u2013 we will [become] a super-organism of humanity and machines.\" http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/uKFiGG1D",
        "expanded_url" : "http:\/\/hplusmagazine.com\/2011\/01\/19\/what-technology-wants-what-kevin-kelly-says-interview-kevin-kelly\/",
        "display_url" : "hplusmagazine.com\/2011\/01\/19\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "300584021166022656",
    "text" : "\"I agree with the weaker version of the singularity \u2013 we will [become] a super-organism of humanity and machines.\" http:\/\/t.co\/uKFiGG1D",
    "id" : 300584021166022656,
    "created_at" : "2013-02-10 12:36:29 +0000",
    "user" : {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "protected" : false,
      "id_str" : "1769191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805781204381351936\/_P3k7Gmn_normal.jpg",
      "id" : 1769191,
      "verified" : true
    }
  },
  "id" : 300584642912862209,
  "created_at" : "2013-02-10 12:38:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300575077106348032",
  "geo" : { },
  "id_str" : "300575318241067008",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 ich glaube in dem Fall sogar gleichzeitig \u00ABDad of the Year\u00BB-Award. ;)",
  "id" : 300575318241067008,
  "in_reply_to_status_id" : 300575077106348032,
  "created_at" : "2013-02-10 12:01:54 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300574793974026241",
  "text" : "\u00ABNat\u00FCrlich geh\u00F6ren Kinder zum Karneval. Wer soll mir sonst das Bier \u00F6ffnen wenn ich dazu nicht mehr in der Lage bin?\u00BB",
  "id" : 300574793974026241,
  "created_at" : "2013-02-10 11:59:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret Smith",
      "screen_name" : "DrMobs",
      "indices" : [ 3, 10 ],
      "id_str" : "24493624",
      "id" : 24493624
    }, {
      "name" : "Alison",
      "screen_name" : "47ali",
      "indices" : [ 35, 41 ],
      "id_str" : "200819869",
      "id" : 200819869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/GkM7034e",
      "expanded_url" : "https:\/\/twitter.com\/47ali\/status\/300569717607907328\/photo\/1",
      "display_url" : "pic.twitter.com\/GkM7034e"
    } ]
  },
  "geo" : { },
  "id_str" : "300571439159992320",
  "text" : "RT @DrMobs: LOVE LOVE LOVE IT!! RT @47ali: Haha http:\/\/t.co\/GkM7034e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alison",
        "screen_name" : "47ali",
        "indices" : [ 23, 29 ],
        "id_str" : "200819869",
        "id" : 200819869
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/GkM7034e",
        "expanded_url" : "https:\/\/twitter.com\/47ali\/status\/300569717607907328\/photo\/1",
        "display_url" : "pic.twitter.com\/GkM7034e"
      } ]
    },
    "geo" : { },
    "id_str" : "300570928281161728",
    "text" : "LOVE LOVE LOVE IT!! RT @47ali: Haha http:\/\/t.co\/GkM7034e",
    "id" : 300570928281161728,
    "created_at" : "2013-02-10 11:44:28 +0000",
    "user" : {
      "name" : "Margaret Smith",
      "screen_name" : "DrMobs",
      "protected" : false,
      "id_str" : "24493624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1109624241\/MebyJo_normal.jpg",
      "id" : 24493624,
      "verified" : false
    }
  },
  "id" : 300571439159992320,
  "created_at" : "2013-02-10 11:46:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300558465208827905",
  "geo" : { },
  "id_str" : "300559079275905024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy sucks when that happens (hope it's just the internet for the sake of the wetlab-ppl) And: yup, I'm in.",
  "id" : 300559079275905024,
  "in_reply_to_status_id" : 300558465208827905,
  "created_at" : "2013-02-10 10:57:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300557579577339905",
  "geo" : { },
  "id_str" : "300558183963971585",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy eh, Bowtie. :)",
  "id" : 300558183963971585,
  "in_reply_to_status_id" : 300557579577339905,
  "created_at" : "2013-02-10 10:53:49 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300557579577339905",
  "geo" : { },
  "id_str" : "300558124492914688",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy either there a brownout at my campus or the Internet there is broken. Regardless: I can't access the Bowie-results",
  "id" : 300558124492914688,
  "in_reply_to_status_id" : 300557579577339905,
  "created_at" : "2013-02-10 10:53:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300415682770763776",
  "text" : "Jetzt ist es mir zum ersten mal passiert: Swipe-Geste in einem Printbuch gemacht und gewundert wieso nicht umgebl\u00E4ttert wird. m(",
  "id" : 300415682770763776,
  "created_at" : "2013-02-10 01:27:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/E6pdia5i",
      "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2013\/02\/09\/maher-trump-so-mad-at-me-he-could-barely-stop-flinging-his-feces\/",
      "display_url" : "rawstory.com\/rs\/2013\/02\/09\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300369240463126528",
  "text" : "Bill Maher on being sued by Donald Trump and human-orangutan crossbreeding. http:\/\/t.co\/E6pdia5i",
  "id" : 300369240463126528,
  "created_at" : "2013-02-09 22:23:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    }, {
      "name" : "Laughing Squid",
      "screen_name" : "LaughingSquid",
      "indices" : [ 123, 137 ],
      "id_str" : "2172",
      "id" : 2172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/RWRkqrVO",
      "expanded_url" : "http:\/\/laughingsquid.com\/a-high-quality-collection-of-animated-gifs-from-nature-documentaries\/",
      "display_url" : "laughingsquid.com\/a-high-quality\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300361936552460288",
  "text" : "RT @kaythaney: YES. A collection of high-quality animated animal GIFs from nature documentaries. http:\/\/t.co\/RWRkqrVO (via @LaughingSquid)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laughing Squid",
        "screen_name" : "LaughingSquid",
        "indices" : [ 108, 122 ],
        "id_str" : "2172",
        "id" : 2172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/RWRkqrVO",
        "expanded_url" : "http:\/\/laughingsquid.com\/a-high-quality-collection-of-animated-gifs-from-nature-documentaries\/",
        "display_url" : "laughingsquid.com\/a-high-quality\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "300361705748312064",
    "text" : "YES. A collection of high-quality animated animal GIFs from nature documentaries. http:\/\/t.co\/RWRkqrVO (via @LaughingSquid)",
    "id" : 300361705748312064,
    "created_at" : "2013-02-09 21:53:05 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 300361936552460288,
  "created_at" : "2013-02-09 21:54:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Schultz",
      "screen_name" : "_ColinS_",
      "indices" : [ 3, 12 ],
      "id_str" : "56722075",
      "id" : 56722075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/61laHkoa",
      "expanded_url" : "http:\/\/natpo.st\/Mz6jCL",
      "display_url" : "natpo.st\/Mz6jCL"
    } ]
  },
  "geo" : { },
  "id_str" : "300358833895776256",
  "text" : "RT @_ColinS_: Burglar returns family\u2019s stolen goods with apology note. Adds in $50 for broken door http:\/\/t.co\/61laHkoa Oh Guelph",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/61laHkoa",
        "expanded_url" : "http:\/\/natpo.st\/Mz6jCL",
        "display_url" : "natpo.st\/Mz6jCL"
      } ]
    },
    "geo" : { },
    "id_str" : "300357493241020416",
    "text" : "Burglar returns family\u2019s stolen goods with apology note. Adds in $50 for broken door http:\/\/t.co\/61laHkoa Oh Guelph",
    "id" : 300357493241020416,
    "created_at" : "2013-02-09 21:36:21 +0000",
    "user" : {
      "name" : "Colin Schultz",
      "screen_name" : "_ColinS_",
      "protected" : false,
      "id_str" : "56722075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/865602912965316608\/DMfhU5Cd_normal.jpg",
      "id" : 56722075,
      "verified" : false
    }
  },
  "id" : 300358833895776256,
  "created_at" : "2013-02-09 21:41:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SarcasticRover",
      "screen_name" : "SarcasticRover",
      "indices" : [ 3, 18 ],
      "id_str" : "740109097",
      "id" : 740109097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300355718987534337",
  "text" : "RT @SarcasticRover: Upset about snow and delayed flights? Be glad you have oxygen, air pressure, and aren't stranded on Mars forever!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300034532051144704",
    "text" : "Upset about snow and delayed flights? Be glad you have oxygen, air pressure, and aren't stranded on Mars forever!",
    "id" : 300034532051144704,
    "created_at" : "2013-02-09 00:13:01 +0000",
    "user" : {
      "name" : "SarcasticRover",
      "screen_name" : "SarcasticRover",
      "protected" : false,
      "id_str" : "740109097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839728901165203456\/mFZ-sZXQ_normal.jpg",
      "id" : 740109097,
      "verified" : false
    }
  },
  "id" : 300355718987534337,
  "created_at" : "2013-02-09 21:29:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 10, 17 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300350674871414786",
  "geo" : { },
  "id_str" : "300351066627796992",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @lsanoj Adamskost\u00FCm? Check!",
  "id" : 300351066627796992,
  "in_reply_to_status_id" : 300350674871414786,
  "created_at" : "2013-02-09 21:10:49 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300350265851273216",
  "geo" : { },
  "id_str" : "300350512518279168",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Senficon Ich habe den Umzug zur\u00FCckgetrollt und habe nackt im Wohnzimmer getanzt, passend auf Augenh\u00F6he mit den Leuten auf den Wagen",
  "id" : 300350512518279168,
  "in_reply_to_status_id" : 300350265851273216,
  "created_at" : "2013-02-09 21:08:37 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300349746592231424",
  "geo" : { },
  "id_str" : "300350013610012672",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Bei aller Hundeliebe: Er sieht nicht so aus als sollte ich ihn fahren lassen!",
  "id" : 300350013610012672,
  "in_reply_to_status_id" : 300349746592231424,
  "created_at" : "2013-02-09 21:06:38 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/VbEHVJRL",
      "expanded_url" : "http:\/\/i.imgur.com\/kZYcB8c.jpg",
      "display_url" : "i.imgur.com\/kZYcB8c.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "300347977405460480",
  "text" : "Including: How-To get nailed on the cross! http:\/\/t.co\/VbEHVJRL",
  "id" : 300347977405460480,
  "created_at" : "2013-02-09 20:58:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bogdan Rau, MPH",
      "screen_name" : "bogdanrau",
      "indices" : [ 0, 10 ],
      "id_str" : "174942484",
      "id" : 174942484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300344408149196800",
  "geo" : { },
  "id_str" : "300344565393657856",
  "in_reply_to_user_id" : 174942484,
  "text" : "@bogdanrau I wish it was, but it\u2019s just a random dog from reddit. :)",
  "id" : 300344565393657856,
  "in_reply_to_status_id" : 300344408149196800,
  "created_at" : "2013-02-09 20:44:59 +0000",
  "in_reply_to_screen_name" : "bogdanrau",
  "in_reply_to_user_id_str" : "174942484",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/x1a2rTfA",
      "expanded_url" : "http:\/\/i.imgur.com\/l5g8NTQ.jpg",
      "display_url" : "i.imgur.com\/l5g8NTQ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "300343843520409603",
  "text" : "There\u2019s no time to explain. Get in the car! http:\/\/t.co\/x1a2rTfA",
  "id" : 300343843520409603,
  "created_at" : "2013-02-09 20:42:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "indices" : [ 3, 14 ],
      "id_str" : "191004758",
      "id" : 191004758
    }, {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "indices" : [ 85, 96 ],
      "id_str" : "31443503",
      "id" : 31443503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/pXa5IUbi",
      "expanded_url" : "http:\/\/bit.ly\/TTraYn",
      "display_url" : "bit.ly\/TTraYn"
    } ]
  },
  "geo" : { },
  "id_str" : "300327708204863489",
  "text" : "RT @PygmyLoris: A fascinating discussion of pubic-hair-grooming-related injuries, by @scicurious (who else?!) http:\/\/t.co\/pXa5IUbi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sci Curious",
        "screen_name" : "scicurious",
        "indices" : [ 69, 80 ],
        "id_str" : "31443503",
        "id" : 31443503
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/pXa5IUbi",
        "expanded_url" : "http:\/\/bit.ly\/TTraYn",
        "display_url" : "bit.ly\/TTraYn"
      } ]
    },
    "geo" : { },
    "id_str" : "300326439251742720",
    "text" : "A fascinating discussion of pubic-hair-grooming-related injuries, by @scicurious (who else?!) http:\/\/t.co\/pXa5IUbi",
    "id" : 300326439251742720,
    "created_at" : "2013-02-09 19:32:57 +0000",
    "user" : {
      "name" : "Loris",
      "screen_name" : "PygmyLoris",
      "protected" : false,
      "id_str" : "191004758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/920667159386316801\/BVsCzUy9_normal.jpg",
      "id" : 191004758,
      "verified" : false
    }
  },
  "id" : 300327708204863489,
  "created_at" : "2013-02-09 19:38:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/V1OOo1z1",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/guest-blog\/2013\/02\/07\/the-god-of-thunder-and-momentum\/",
      "display_url" : "blogs.scientificamerican.com\/guest-blog\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300323929891934208",
  "text" : "The physics of Thor http:\/\/t.co\/V1OOo1z1",
  "id" : 300323929891934208,
  "created_at" : "2013-02-09 19:22:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300319721440542720",
  "text" : "(Alle die dort das Wetlab benutzen sollten anfangen zu beten das es nur das Internet &amp; nicht der Strom ist\u2026)",
  "id" : 300319721440542720,
  "created_at" : "2013-02-09 19:06:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300319089107275776",
  "text" : "Offensichtlich gibt es mal wieder kein Internet am alten Biocampus\u2026 So viel zur Produktivit\u00E4t am Wochenende.",
  "id" : 300319089107275776,
  "created_at" : "2013-02-09 19:03:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/8BENmZ63",
      "expanded_url" : "http:\/\/op12no2.me\/toys\/herd\/index.php",
      "display_url" : "op12no2.me\/toys\/herd\/inde\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300308787984748544",
  "text" : "Simulation: How herd immunity works http:\/\/t.co\/8BENmZ63",
  "id" : 300308787984748544,
  "created_at" : "2013-02-09 18:22:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/LMHxN678",
      "expanded_url" : "http:\/\/i.imgur.com\/d88we.gif",
      "display_url" : "i.imgur.com\/d88we.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "300306155018805248",
  "text" : "Wenn das Geld nicht mehr f\u00FCr den Schlitten reicht http:\/\/t.co\/LMHxN678",
  "id" : 300306155018805248,
  "created_at" : "2013-02-09 18:12:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/74oCkWB6",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/02\/08\/astronaut-and-barenaked-ladies.html",
      "display_url" : "boingboing.net\/2013\/02\/08\/ast\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300283447115649025",
  "text" : "Chris Hadfield performs via videolink from the ISS, along with the Barenaked Ladies http:\/\/t.co\/74oCkWB6",
  "id" : 300283447115649025,
  "created_at" : "2013-02-09 16:42:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300282325206454273",
  "geo" : { },
  "id_str" : "300282626772713474",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer We thought about it but haven\u2019t implemented it fully (iirc)",
  "id" : 300282626772713474,
  "in_reply_to_status_id" : 300282325206454273,
  "created_at" : "2013-02-09 16:38:51 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/KO7sfLyR",
      "expanded_url" : "http:\/\/j.mp\/XvsUVP",
      "display_url" : "j.mp\/XvsUVP"
    } ]
  },
  "geo" : { },
  "id_str" : "300275504399917056",
  "text" : "Finally, a cure for HIPSTER! http:\/\/t.co\/KO7sfLyR",
  "id" : 300275504399917056,
  "created_at" : "2013-02-09 16:10:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300260072259461122",
  "geo" : { },
  "id_str" : "300261603767640065",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj die Verkleidungen sind \u00E4hnlich.",
  "id" : 300261603767640065,
  "in_reply_to_status_id" : 300260072259461122,
  "created_at" : "2013-02-09 15:15:19 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300258827025129473",
  "geo" : { },
  "id_str" : "300259610869252096",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj der Fachbegriff ist glaube ich \u00ABPforte zur H\u00F6lle\u00BB",
  "id" : 300259610869252096,
  "in_reply_to_status_id" : 300258827025129473,
  "created_at" : "2013-02-09 15:07:24 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300257183977836544",
  "text" : "Wie passend: Jetzt macht Biene Maja vor meinem Fenster mit einer Giraffe rum.",
  "id" : 300257183977836544,
  "created_at" : "2013-02-09 14:57:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/m0cFlOXF",
      "expanded_url" : "http:\/\/j.mp\/Y12itS",
      "display_url" : "j.mp\/Y12itS"
    } ]
  },
  "geo" : { },
  "id_str" : "300231399259127808",
  "text" : "Animal models gone wrong http:\/\/t.co\/m0cFlOXF",
  "id" : 300231399259127808,
  "created_at" : "2013-02-09 13:15:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/dZIsNMqj",
      "expanded_url" : "http:\/\/www.bioinformaticszen.com\/post\/whats-the-point-of-writing-good-scientific-software\/",
      "display_url" : "bioinformaticszen.com\/post\/whats-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "300223932609490944",
  "text" : "\u00ABPeople who start in science underestimate the impact of Zipf\u2019s law.Most research papers have only one single reader\u00BB http:\/\/t.co\/dZIsNMqj",
  "id" : 300223932609490944,
  "created_at" : "2013-02-09 12:45:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300217015640137729",
  "text" : "Entweder es gibt Karnevalslieder die sich beim Star-Spangled Banner bedienen oder die Amerikaner fahren parallel eine Gegenveranstaltung...",
  "id" : 300217015640137729,
  "created_at" : "2013-02-09 12:18:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300012502400520193",
  "geo" : { },
  "id_str" : "300215188978814977",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez thanks! :)",
  "id" : 300215188978814977,
  "in_reply_to_status_id" : 300012502400520193,
  "created_at" : "2013-02-09 12:10:53 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300214489108852737",
  "text" : "\u00ABIch traue dir auch eher Zoophilie als Nekrophilie zu.\u00BB\u2014\u00ABDanke, du machst wirklich die besten Komplimente.\u00BB",
  "id" : 300214489108852737,
  "created_at" : "2013-02-09 12:08:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deef Pirmasens",
      "screen_name" : "Deef",
      "indices" : [ 3, 8 ],
      "id_str" : "2565121",
      "id" : 2565121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299849624439644160",
  "text" : "RT @Deef: When someone tells you they are bi, proper response is not \u201Csure?\u201D or \u201CSo was I before I grew out of it\u201D or \u201CFor now\" http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/BAsmZSzw",
        "expanded_url" : "http:\/\/fliponymous.wordpress.com\/2012\/10\/08\/bi-now-gay-later\/",
        "display_url" : "fliponymous.wordpress.com\/2012\/10\/08\/bi-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299848930278125568",
    "text" : "When someone tells you they are bi, proper response is not \u201Csure?\u201D or \u201CSo was I before I grew out of it\u201D or \u201CFor now\" http:\/\/t.co\/BAsmZSzw",
    "id" : 299848930278125568,
    "created_at" : "2013-02-08 11:55:30 +0000",
    "user" : {
      "name" : "Deef Pirmasens",
      "screen_name" : "Deef",
      "protected" : false,
      "id_str" : "2565121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597818190111121409\/f16zG9eu_normal.jpg",
      "id" : 2565121,
      "verified" : true
    }
  },
  "id" : 299849624439644160,
  "created_at" : "2013-02-08 11:58:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/nuyZIxhm",
      "expanded_url" : "http:\/\/j.mp\/W2yoId",
      "display_url" : "j.mp\/W2yoId"
    } ]
  },
  "geo" : { },
  "id_str" : "299818961527242752",
  "text" : "Octopus sperm is screwed! http:\/\/t.co\/nuyZIxhm",
  "id" : 299818961527242752,
  "created_at" : "2013-02-08 09:56:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/p1ys0JBL",
      "expanded_url" : "http:\/\/j.mp\/XrYORj",
      "display_url" : "j.mp\/XrYORj"
    } ]
  },
  "geo" : { },
  "id_str" : "299814432127717376",
  "text" : "If you're having Perl problems\u2026 http:\/\/t.co\/p1ys0JBL",
  "id" : 299814432127717376,
  "created_at" : "2013-02-08 09:38:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299795405430984706",
  "text" : "\u00ABNa, hast du wieder von deinen Groupies getr\u00E4umt?\u00BB\u2014\u00ABNur von einem!\u00BB",
  "id" : 299795405430984706,
  "created_at" : "2013-02-08 08:22:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 3, 15 ],
      "id_str" : "16629477",
      "id" : 16629477
    }, {
      "name" : "Erika Check Hayden",
      "screen_name" : "Erika_Check",
      "indices" : [ 41, 53 ],
      "id_str" : "17221246",
      "id" : 17221246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/xYqGGKji",
      "expanded_url" : "http:\/\/www.lastwordonnothing.com\/2013\/02\/07\/uninformed-consent\/",
      "display_url" : "lastwordonnothing.com\/2013\/02\/07\/uni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299661066948976641",
  "text" : "RT @dgmacarthur: Disturbing example from @Erika_Check showing how broken the current informed consent system is: http:\/\/t.co\/xYqGGKji",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erika Check Hayden",
        "screen_name" : "Erika_Check",
        "indices" : [ 24, 36 ],
        "id_str" : "17221246",
        "id" : 17221246
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/xYqGGKji",
        "expanded_url" : "http:\/\/www.lastwordonnothing.com\/2013\/02\/07\/uninformed-consent\/",
        "display_url" : "lastwordonnothing.com\/2013\/02\/07\/uni\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299660728871297024",
    "text" : "Disturbing example from @Erika_Check showing how broken the current informed consent system is: http:\/\/t.co\/xYqGGKji",
    "id" : 299660728871297024,
    "created_at" : "2013-02-07 23:27:39 +0000",
    "user" : {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "protected" : false,
      "id_str" : "16629477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856238606507180033\/GWLCCqUC_normal.jpg",
      "id" : 16629477,
      "verified" : false
    }
  },
  "id" : 299661066948976641,
  "created_at" : "2013-02-07 23:29:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299658581165342721",
  "text" : "\u00ABWell I finally realized we\u2019re not compatible. I mean I\u2019m all for fantasy role play, but Abu Ghraib?\u00BB",
  "id" : 299658581165342721,
  "created_at" : "2013-02-07 23:19:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Bork",
      "screen_name" : "sebidotorg",
      "indices" : [ 0, 11 ],
      "id_str" : "751063429",
      "id" : 751063429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/1qK9HXdV",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Linus_Pauling#Molecular_medicine.2C_medical_research.2C_and_vitamin_C_advocacy",
      "display_url" : "en.wikipedia.org\/wiki\/Linus_Pau\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "299642234821828611",
  "geo" : { },
  "id_str" : "299642696526610433",
  "in_reply_to_user_id" : 751063429,
  "text" : "@sebidotorg I'm more skeptical due to this http:\/\/t.co\/1qK9HXdV ;)",
  "id" : 299642696526610433,
  "in_reply_to_status_id" : 299642234821828611,
  "created_at" : "2013-02-07 22:16:00 +0000",
  "in_reply_to_screen_name" : "sebidotorg",
  "in_reply_to_user_id_str" : "751063429",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299641608473808896",
  "text" : "TIL: There's still the \u00ABLinus Pauling Institute\u00BB dedicated to \u00ABMicronutrient Research for Optimum Health\u00BB...",
  "id" : 299641608473808896,
  "created_at" : "2013-02-07 22:11:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/3aXTGrcz",
      "expanded_url" : "http:\/\/gedankenstuecke.github.com\/blog\/2013\/02\/07\/stepcounting-fitbit-vs-fuelband\/",
      "display_url" : "gedankenstuecke.github.com\/blog\/2013\/02\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299615615688257538",
  "text" : "Nope, changing on which wrist you wear the Nike+ Fuelband won\u2019t change how many steps it counts. http:\/\/t.co\/3aXTGrcz",
  "id" : 299615615688257538,
  "created_at" : "2013-02-07 20:28:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 5, 12 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299590594093797376",
  "geo" : { },
  "id_str" : "299590999905296384",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @lsanoj \u00ABNo, it doesn't. There'll be one guy left with one eye. How's the last blind guy gonna take out the eye of the last guy left?\u00BB",
  "id" : 299590999905296384,
  "in_reply_to_status_id" : 299590594093797376,
  "created_at" : "2013-02-07 18:50:35 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    }, {
      "name" : "Mara Grunbaum",
      "screen_name" : "maragrunbaum",
      "indices" : [ 93, 106 ],
      "id_str" : "79836272",
      "id" : 79836272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/ja3u30C6",
      "expanded_url" : "http:\/\/tmblr.co\/ZWELFtdSnLvF",
      "display_url" : "tmblr.co\/ZWELFtdSnLvF"
    } ]
  },
  "geo" : { },
  "id_str" : "299580755338743808",
  "text" : "RT @JBYoder: \"What does it eat?\" \"Baby crocodiles.\" http:\/\/t.co\/ja3u30C6 \u2014WTF, Evolution? by @maragrunbaum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mara Grunbaum",
        "screen_name" : "maragrunbaum",
        "indices" : [ 80, 93 ],
        "id_str" : "79836272",
        "id" : 79836272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/ja3u30C6",
        "expanded_url" : "http:\/\/tmblr.co\/ZWELFtdSnLvF",
        "display_url" : "tmblr.co\/ZWELFtdSnLvF"
      } ]
    },
    "geo" : { },
    "id_str" : "299580388270039041",
    "text" : "\"What does it eat?\" \"Baby crocodiles.\" http:\/\/t.co\/ja3u30C6 \u2014WTF, Evolution? by @maragrunbaum",
    "id" : 299580388270039041,
    "created_at" : "2013-02-07 18:08:25 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 299580755338743808,
  "created_at" : "2013-02-07 18:09:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299574703784333312",
  "geo" : { },
  "id_str" : "299575071012425728",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Ich kann mich nicht entscheiden ob ich \u00ABWall of Smegma\u00BB oder \u00ABSmother Theresa\u00BB besser finden soll.",
  "id" : 299575071012425728,
  "in_reply_to_status_id" : 299574703784333312,
  "created_at" : "2013-02-07 17:47:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/GHavahvL",
      "expanded_url" : "http:\/\/i.imgur.com\/udhhEmO.gif",
      "display_url" : "i.imgur.com\/udhhEmO.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "299573541412671488",
  "text" : "Playing Baby Jesus Hitler? Suspension. Playing Nickelback? Termination! http:\/\/t.co\/GHavahvL",
  "id" : 299573541412671488,
  "created_at" : "2013-02-07 17:41:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/9uHVQj50",
      "expanded_url" : "http:\/\/chuva-inc.com\/sites\/default\/files\/blog_posts\/356merge-conflicts.jpg",
      "display_url" : "chuva-inc.com\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299571800277393408",
  "text" : "I don\u2019t always have CSS problems. But when I do I solve them by randomly using copy &amp; paste. http:\/\/t.co\/9uHVQj50",
  "id" : 299571800277393408,
  "created_at" : "2013-02-07 17:34:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/d60MsrLh",
      "expanded_url" : "http:\/\/j.mp\/X9y5g1",
      "display_url" : "j.mp\/X9y5g1"
    } ]
  },
  "geo" : { },
  "id_str" : "299568690058371073",
  "text" : "No one can know about this! http:\/\/t.co\/d60MsrLh",
  "id" : 299568690058371073,
  "created_at" : "2013-02-07 17:21:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf Heimann",
      "screen_name" : "ralfheimann",
      "indices" : [ 3, 15 ],
      "id_str" : "23431577",
      "id" : 23431577
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ralfheimann\/status\/299564330259726336\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/CKwLmQfC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BChEK9UCQAA4szw.jpg",
      "id_str" : "299564330268114944",
      "id" : 299564330268114944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BChEK9UCQAA4szw.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 543
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 589
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 589
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 738,
        "resize" : "fit",
        "w" : 589
      } ],
      "display_url" : "pic.twitter.com\/CKwLmQfC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299564514280615937",
  "text" : "RT @ralfheimann: Mit dem Dienstwagen unterwegs. So so. Aber darf man vor der Treppe \u00FCberhaupt parken? http:\/\/t.co\/CKwLmQfC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ralfheimann\/status\/299564330259726336\/photo\/1",
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/CKwLmQfC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BChEK9UCQAA4szw.jpg",
        "id_str" : "299564330268114944",
        "id" : 299564330268114944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BChEK9UCQAA4szw.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 543
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 589
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 589
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 738,
          "resize" : "fit",
          "w" : 589
        } ],
        "display_url" : "pic.twitter.com\/CKwLmQfC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299564330259726336",
    "text" : "Mit dem Dienstwagen unterwegs. So so. Aber darf man vor der Treppe \u00FCberhaupt parken? http:\/\/t.co\/CKwLmQfC",
    "id" : 299564330259726336,
    "created_at" : "2013-02-07 17:04:36 +0000",
    "user" : {
      "name" : "Ralf Heimann",
      "screen_name" : "ralfheimann",
      "protected" : false,
      "id_str" : "23431577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843121587561938945\/BfqiFna__normal.jpg",
      "id" : 23431577,
      "verified" : true
    }
  },
  "id" : 299564514280615937,
  "created_at" : "2013-02-07 17:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299563538727456769",
  "geo" : { },
  "id_str" : "299564029125488642",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn (and stress levels and calorie intake have been negatively correlated for me for a while by now)",
  "id" : 299564029125488642,
  "in_reply_to_status_id" : 299563538727456769,
  "created_at" : "2013-02-07 17:03:24 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299563538727456769",
  "geo" : { },
  "id_str" : "299563850355859456",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn that tends to be the opposite for me. Moving around &amp; getting some fresh air helps to think &amp; focus afterwards.",
  "id" : 299563850355859456,
  "in_reply_to_status_id" : 299563538727456769,
  "created_at" : "2013-02-07 17:02:42 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299561901766103041",
  "geo" : { },
  "id_str" : "299563067094728704",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn yup, subjectively rising stress levels in 2013 due to the nearing deadline for my thesis (plus more other work going on).",
  "id" : 299563067094728704,
  "in_reply_to_status_id" : 299561901766103041,
  "created_at" : "2013-02-07 16:59:35 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299561079435059200",
  "geo" : { },
  "id_str" : "299562709769392129",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn (average 2012: 10744 steps, average 2013 so far: 13178 steps)",
  "id" : 299562709769392129,
  "in_reply_to_status_id" : 299561079435059200,
  "created_at" : "2013-02-07 16:58:10 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299561079435059200",
  "geo" : { },
  "id_str" : "299561761936400385",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn Looks like with the beginning of 2013 the mean # of steps is more like 15k instead of 10k.",
  "id" : 299561761936400385,
  "in_reply_to_status_id" : 299561079435059200,
  "created_at" : "2013-02-07 16:54:24 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299561079435059200",
  "geo" : { },
  "id_str" : "299561463008346112",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn overall a drop in calorie intake. And I haven\u2019t run the numbers but the graphs look like more activity as well.",
  "id" : 299561463008346112,
  "in_reply_to_status_id" : 299561079435059200,
  "created_at" : "2013-02-07 16:53:13 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299559780048052224",
  "geo" : { },
  "id_str" : "299560337609486336",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn (but there\u2019s no need to tell you that, as you have access to all the raw data to see it for yourself). ;) Thanks!",
  "id" : 299560337609486336,
  "in_reply_to_status_id" : 299559780048052224,
  "created_at" : "2013-02-07 16:48:44 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299559780048052224",
  "geo" : { },
  "id_str" : "299560120369680384",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn in total ~15 kg since mid-May 2012.",
  "id" : 299560120369680384,
  "in_reply_to_status_id" : 299559780048052224,
  "created_at" : "2013-02-07 16:47:52 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helmut Wicht",
      "screen_name" : "h_wicht",
      "indices" : [ 0, 8 ],
      "id_str" : "322062420",
      "id" : 322062420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299555477325479936",
  "geo" : { },
  "id_str" : "299555566861299712",
  "in_reply_to_user_id" : 322062420,
  "text" : "@h_wicht Danke f\u00FCrs Teilhaben lassen an dem sch\u00F6nen Beruf :)",
  "id" : 299555566861299712,
  "in_reply_to_status_id" : 299555477325479936,
  "created_at" : "2013-02-07 16:29:47 +0000",
  "in_reply_to_screen_name" : "h_wicht",
  "in_reply_to_user_id_str" : "322062420",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/TVpe7LlC",
      "expanded_url" : "http:\/\/www.scilogs.de\/blogs\/blog\/anatomisches-allerlei\/2013-02-07\/dinge-die-ich-heute-tat",
      "display_url" : "scilogs.de\/blogs\/blog\/ana\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299548854477549570",
  "text" : "\u00ABWas ich mit diesem Blog-Eintrag gesagt haben will? Gar nichts. Ausser, dass ich einen sch\u00F6nen Beruf habe.\u00BB http:\/\/t.co\/TVpe7LlC",
  "id" : 299548854477549570,
  "created_at" : "2013-02-07 16:03:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299546143552045058",
  "text" : "Catch-22, jetzt in der Ethics Approval-Variante\u2026",
  "id" : 299546143552045058,
  "created_at" : "2013-02-07 15:52:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "indices" : [ 3, 8 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/HjUsT6vS",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/AskHistorians\/comments\/17zztg\/how_common_was_casual_sex_throughout_history\/",
      "display_url" : "reddit.com\/r\/AskHistorian\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299522411685085184",
  "text" : "RT @mims: Awesome Reddit thread on how culturally specific sex is. http:\/\/t.co\/HjUsT6vS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/HjUsT6vS",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/AskHistorians\/comments\/17zztg\/how_common_was_casual_sex_throughout_history\/",
        "display_url" : "reddit.com\/r\/AskHistorian\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299519414888460290",
    "text" : "Awesome Reddit thread on how culturally specific sex is. http:\/\/t.co\/HjUsT6vS",
    "id" : 299519414888460290,
    "created_at" : "2013-02-07 14:06:07 +0000",
    "user" : {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "protected" : false,
      "id_str" : "1769191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805781204381351936\/_P3k7Gmn_normal.jpg",
      "id" : 1769191,
      "verified" : true
    }
  },
  "id" : 299522411685085184,
  "created_at" : "2013-02-07 14:18:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/SQlJa1io",
      "expanded_url" : "http:\/\/tinyurl.com\/ahm5jao",
      "display_url" : "tinyurl.com\/ahm5jao"
    } ]
  },
  "geo" : { },
  "id_str" : "299502372357554176",
  "text" : "How to Deflect Killer Asteroids With Spray Paint http:\/\/t.co\/SQlJa1io",
  "id" : 299502372357554176,
  "created_at" : "2013-02-07 12:58:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299486974098690048",
  "text" : "Is there a # designated for \"Fails to correctly apply the Type-N error labels\"-errors?",
  "id" : 299486974098690048,
  "created_at" : "2013-02-07 11:57:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/f8zekNqU",
      "expanded_url" : "http:\/\/www.livememe.com\/3y64eqp\/pid\/gkzzat\/",
      "display_url" : "livememe.com\/3y64eqp\/pid\/gk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299480868500668416",
  "text" : "What if I told you... http:\/\/t.co\/f8zekNqU",
  "id" : 299480868500668416,
  "created_at" : "2013-02-07 11:32:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299468906786074625",
  "geo" : { },
  "id_str" : "299469613199130624",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch Maybe Breakout?",
  "id" : 299469613199130624,
  "in_reply_to_status_id" : 299468906786074625,
  "created_at" : "2013-02-07 10:48:14 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 102, 115 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/1ybwWfpw",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2367",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299468392128184322",
  "text" : "I wasn't aware that the life of George Price was made into a dinosaur comic! http:\/\/t.co\/1ybwWfpw \/HT @philippbayer",
  "id" : 299468392128184322,
  "created_at" : "2013-02-07 10:43:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299467100412596224",
  "geo" : { },
  "id_str" : "299467565791604736",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch The drum stick made me think of Tetris!",
  "id" : 299467565791604736,
  "in_reply_to_status_id" : 299467100412596224,
  "created_at" : "2013-02-07 10:40:06 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299467331199979520",
  "text" : "\"Meinst du ich w\u00E4re der IT Guy wenn ich handwerklich geschickt w\u00E4re und mich im Keller auskennen w\u00FCrde?\"",
  "id" : 299467331199979520,
  "created_at" : "2013-02-07 10:39:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299465043953713152",
  "geo" : { },
  "id_str" : "299465505721442305",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch mildly interesting but it still gives you a short moment of joy to see things fit. :)",
  "id" : 299465505721442305,
  "in_reply_to_status_id" : 299465043953713152,
  "created_at" : "2013-02-07 10:31:55 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/i3UC5xb7",
      "expanded_url" : "http:\/\/thingsfittingperfectlyintothings.tumblr.com\/",
      "display_url" : "\u2026fittingperfectlyintothings.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "299462086503849985",
  "text" : "Things Fitting Perfectly Into Other Things http:\/\/t.co\/i3UC5xb7",
  "id" : 299462086503849985,
  "created_at" : "2013-02-07 10:18:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299442296355696640",
  "text" : "\u00ABDu nimmst doch nur ab damit du auf dem R\u00FCcken eines frisch geschorenen Alpaka durchbrennen kannst!\u00BB",
  "id" : 299442296355696640,
  "created_at" : "2013-02-07 08:59:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299426984306561024",
  "text" : "\u00ABDu Heuchler nutzt doch auch heimlich t-Tests!\u00BB",
  "id" : 299426984306561024,
  "created_at" : "2013-02-07 07:58:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299315602076622848",
  "text" : "\u00ABIch weine nicht wegen dir. Ich weine wegen der Dinge die du getan hast.\u00BB",
  "id" : 299315602076622848,
  "created_at" : "2013-02-07 00:36:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason H. Moore, PhD",
      "screen_name" : "moorejh",
      "indices" : [ 3, 11 ],
      "id_str" : "15496407",
      "id" : 15496407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "datascience",
      "indices" : [ 89, 101 ]
    }, {
      "text" : "datamining",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/HUaJo5QF",
      "expanded_url" : "http:\/\/www.statisticalanalysisconsulting.com\/book-review-statistics-as-principled-argument-by-robert-abelson\/#more-67",
      "display_url" : "statisticalanalysisconsulting.com\/book-review-st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299303601510174720",
  "text" : "RT @moorejh: five criteria by which to judge a statistical argument http:\/\/t.co\/HUaJo5QF #datascience #datamining",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "datascience",
        "indices" : [ 76, 88 ]
      }, {
        "text" : "datamining",
        "indices" : [ 89, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/HUaJo5QF",
        "expanded_url" : "http:\/\/www.statisticalanalysisconsulting.com\/book-review-statistics-as-principled-argument-by-robert-abelson\/#more-67",
        "display_url" : "statisticalanalysisconsulting.com\/book-review-st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299303293270753280",
    "text" : "five criteria by which to judge a statistical argument http:\/\/t.co\/HUaJo5QF #datascience #datamining",
    "id" : 299303293270753280,
    "created_at" : "2013-02-06 23:47:20 +0000",
    "user" : {
      "name" : "Jason H. Moore, PhD",
      "screen_name" : "moorejh",
      "protected" : false,
      "id_str" : "15496407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550024402142625793\/5aw9u9E8_normal.jpeg",
      "id" : 15496407,
      "verified" : false
    }
  },
  "id" : 299303601510174720,
  "created_at" : "2013-02-06 23:48:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemeinhorn \uD83E\uDD84",
      "screen_name" : "Blunicorn",
      "indices" : [ 0, 10 ],
      "id_str" : "2524949447",
      "id" : 2524949447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299293147593318400",
  "geo" : { },
  "id_str" : "299294564164960257",
  "in_reply_to_user_id" : 383936036,
  "text" : "@Blunicorn gerne doch :)",
  "id" : 299294564164960257,
  "in_reply_to_status_id" : 299293147593318400,
  "created_at" : "2013-02-06 23:12:39 +0000",
  "in_reply_to_screen_name" : "offisir",
  "in_reply_to_user_id_str" : "383936036",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackinghealthcare",
      "indices" : [ 123, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299294305997189121",
  "text" : "\u00ABChecking to see how many options are available for gender is a great way to determine how mature an EHR system is.\u00BB &lt;3 #hackinghealthcare",
  "id" : 299294305997189121,
  "created_at" : "2013-02-06 23:11:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gemeinhorn \uD83E\uDD84",
      "screen_name" : "Blunicorn",
      "indices" : [ 0, 10 ],
      "id_str" : "2524949447",
      "id" : 2524949447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/fnC9yoqT",
      "expanded_url" : "http:\/\/tinyurl.com\/a8lprow",
      "display_url" : "tinyurl.com\/a8lprow"
    } ]
  },
  "in_reply_to_status_id_str" : "299289507897954305",
  "geo" : { },
  "id_str" : "299291023425818625",
  "in_reply_to_user_id" : 383936036,
  "text" : "@Blunicorn falls Fetisch solltest du dir die spermcasting barnacles nicht entgehen lassen ;) http:\/\/t.co\/fnC9yoqT",
  "id" : 299291023425818625,
  "in_reply_to_status_id" : 299289507897954305,
  "created_at" : "2013-02-06 22:58:35 +0000",
  "in_reply_to_screen_name" : "offisir",
  "in_reply_to_user_id_str" : "383936036",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/D7fcPb31",
      "expanded_url" : "http:\/\/biologicalexceptions.blogspot.de\/2013\/02\/exceptions-give-birth-to-exceptions.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed:+ResearchBloggingBiologyEnglish+(Research+Blogging+-+English+-+Biology",
      "display_url" : "biologicalexceptions.blogspot.de\/2013\/02\/except\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299277529020252160",
  "text" : "Insert a lazy virgin birth joke here, but that\u2019s a pretty good post on parthenogenesis http:\/\/t.co\/D7fcPb31)",
  "id" : 299277529020252160,
  "created_at" : "2013-02-06 22:04:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 90, 99 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/XtA3UDX4",
      "expanded_url" : "http:\/\/j.mp\/XWabRr",
      "display_url" : "j.mp\/XWabRr"
    } ]
  },
  "geo" : { },
  "id_str" : "299274843017338880",
  "text" : "Top 5 reasons why intelligent liberals don\u2019t like nuclear energy http:\/\/t.co\/XtA3UDX4 \/cc @senficon",
  "id" : 299274843017338880,
  "created_at" : "2013-02-06 21:54:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/l4ACj12m",
      "expanded_url" : "http:\/\/j.mp\/XW9tDC",
      "display_url" : "j.mp\/XW9tDC"
    } ]
  },
  "geo" : { },
  "id_str" : "299272703553183744",
  "text" : "In which a sea cucumber is overcome by lust http:\/\/t.co\/l4ACj12m",
  "id" : 299272703553183744,
  "created_at" : "2013-02-06 21:45:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/tU7vlUU0",
      "expanded_url" : "http:\/\/j.mp\/XW8CTr",
      "display_url" : "j.mp\/XW8CTr"
    } ]
  },
  "geo" : { },
  "id_str" : "299270069987459072",
  "text" : "Our love is like\u2026 http:\/\/t.co\/tU7vlUU0",
  "id" : 299270069987459072,
  "created_at" : "2013-02-06 21:35:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299257365528715264",
  "geo" : { },
  "id_str" : "299257575201980416",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall das Feature habe ich mir schon so oft gew\u00FCnscht!",
  "id" : 299257575201980416,
  "in_reply_to_status_id" : 299257365528715264,
  "created_at" : "2013-02-06 20:45:40 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DetritusBlog",
      "screen_name" : "gedankenabfall",
      "indices" : [ 0, 15 ],
      "id_str" : "2175883684",
      "id" : 2175883684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299256731781976064",
  "geo" : { },
  "id_str" : "299257263485509632",
  "in_reply_to_user_id" : 29082973,
  "text" : "@gedankenabfall Dann brauche ich ja nur noch einen Herd mit Magnetr\u00FChrer!",
  "id" : 299257263485509632,
  "in_reply_to_status_id" : 299256731781976064,
  "created_at" : "2013-02-06 20:44:26 +0000",
  "in_reply_to_screen_name" : "ballaschk",
  "in_reply_to_user_id_str" : "29082973",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/BUzgwlvI",
      "expanded_url" : "http:\/\/bangwithnobody.com\/",
      "display_url" : "bangwithnobody.com"
    } ]
  },
  "geo" : { },
  "id_str" : "299154410188189696",
  "text" : "After Facebook &amp; LinkedIn: \"Anonymously find Google+ friends who are down for the night\" http:\/\/t.co\/BUzgwlvI",
  "id" : 299154410188189696,
  "created_at" : "2013-02-06 13:55:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299139574507139072",
  "geo" : { },
  "id_str" : "299139972693372929",
  "in_reply_to_user_id" : 705287821,
  "text" : "@mandibpro Yeah, all the recommendations given in that article are utter nonsense.",
  "id" : 299139972693372929,
  "in_reply_to_status_id" : 299139574507139072,
  "created_at" : "2013-02-06 12:58:21 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/oDzHJA4X",
      "expanded_url" : "http:\/\/tinyurl.com\/avr3zg2",
      "display_url" : "tinyurl.com\/avr3zg2"
    } ]
  },
  "geo" : { },
  "id_str" : "299106529024565248",
  "text" : "Get more girls into science? Easy: \"Cooking \u2013 especially following a recipe \u2013 uses both math and science\" m( http:\/\/t.co\/oDzHJA4X",
  "id" : 299106529024565248,
  "created_at" : "2013-02-06 10:45:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299105670404399105",
  "geo" : { },
  "id_str" : "299106055764447234",
  "in_reply_to_user_id" : 1492631,
  "text" : "@lobot That depends on how much the birds are into tickling ;)",
  "id" : 299106055764447234,
  "in_reply_to_status_id" : 299105670404399105,
  "created_at" : "2013-02-06 10:43:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/IS155PIm",
      "expanded_url" : "http:\/\/tinyurl.com\/ay2pc5k",
      "display_url" : "tinyurl.com\/ay2pc5k"
    } ]
  },
  "geo" : { },
  "id_str" : "299104535572533248",
  "text" : "\"I'm not slacking off! It's research for the bird project we're planning right now!\" http:\/\/t.co\/IS155PIm",
  "id" : 299104535572533248,
  "created_at" : "2013-02-06 10:37:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/bDfYzG7Z",
      "expanded_url" : "http:\/\/tinyurl.com\/a2zunpv",
      "display_url" : "tinyurl.com\/a2zunpv"
    } ]
  },
  "geo" : { },
  "id_str" : "299094166812651520",
  "text" : "\u201CI\u2019ll sleep with you, but I prefer my stories to yours.\u201D - Why culture is chunky and genes are creamy http:\/\/t.co\/bDfYzG7Z",
  "id" : 299094166812651520,
  "created_at" : "2013-02-06 09:56:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/RST2gi6P",
      "expanded_url" : "http:\/\/tinyurl.com\/b6xhmzy",
      "display_url" : "tinyurl.com\/b6xhmzy"
    } ]
  },
  "geo" : { },
  "id_str" : "299092935159476224",
  "text" : "The Cryptofloricon also includes the code for \"told you so!\" http:\/\/t.co\/RST2gi6P",
  "id" : 299092935159476224,
  "created_at" : "2013-02-06 09:51:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/AUxWLsks",
      "expanded_url" : "http:\/\/xkcd.com\/1170\/",
      "display_url" : "xkcd.com\/1170\/"
    } ]
  },
  "geo" : { },
  "id_str" : "299090558834593792",
  "text" : "They'll never know I pushed them off the bridge! http:\/\/t.co\/AUxWLsks",
  "id" : 299090558834593792,
  "created_at" : "2013-02-06 09:42:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299079935421722624",
  "geo" : { },
  "id_str" : "299082588495171584",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog und wieder ist die K\u00E4lte Fusion gescheitert?",
  "id" : 299082588495171584,
  "in_reply_to_status_id" : 299079935421722624,
  "created_at" : "2013-02-06 09:10:20 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "German Psycho",
      "screen_name" : "germanpsycho",
      "indices" : [ 3, 16 ],
      "id_str" : "14972477",
      "id" : 14972477
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/germanpsycho\/status\/299071927765590016\/photo\/1",
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/4EkENruD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCaEVXECYAAGezH.jpg",
      "id_str" : "299071927769784320",
      "id" : 299071927769784320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCaEVXECYAAGezH.jpg",
      "sizes" : [ {
        "h" : 717,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/4EkENruD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299074350932430848",
  "text" : "RT @germanpsycho: Und was ist noch peinlicher als Denglisch? Richtig: Grammatikfehler. http:\/\/t.co\/4EkENruD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/germanpsycho\/status\/299071927765590016\/photo\/1",
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/4EkENruD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BCaEVXECYAAGezH.jpg",
        "id_str" : "299071927769784320",
        "id" : 299071927769784320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCaEVXECYAAGezH.jpg",
        "sizes" : [ {
          "h" : 717,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/4EkENruD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "299071927765590016",
    "text" : "Und was ist noch peinlicher als Denglisch? Richtig: Grammatikfehler. http:\/\/t.co\/4EkENruD",
    "id" : 299071927765590016,
    "created_at" : "2013-02-06 08:27:58 +0000",
    "user" : {
      "name" : "German Psycho",
      "screen_name" : "germanpsycho",
      "protected" : false,
      "id_str" : "14972477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571385493792935936\/tAdzHbtZ_normal.jpeg",
      "id" : 14972477,
      "verified" : false
    }
  },
  "id" : 299074350932430848,
  "created_at" : "2013-02-06 08:37:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/0a0a9nz7",
      "expanded_url" : "http:\/\/j.mp\/14Qgq0h",
      "display_url" : "j.mp\/14Qgq0h"
    } ]
  },
  "geo" : { },
  "id_str" : "298933282941317120",
  "text" : "Medical chocolate uses http:\/\/t.co\/0a0a9nz7",
  "id" : 298933282941317120,
  "created_at" : "2013-02-05 23:17:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/WMRxa5sX",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/catsgonewild",
      "display_url" : "reddit.com\/r\/catsgonewild"
    } ]
  },
  "geo" : { },
  "id_str" : "298930441531060224",
  "text" : "\u00AB\u2026ein Katzen-Reddit mit Menschenbildern und \/r\/gonewild damit Miezi abgelenkt ist.\u00BB \u00ABDu meinst \/r\/catsgonewild?\u00BB http:\/\/t.co\/WMRxa5sX",
  "id" : 298930441531060224,
  "created_at" : "2013-02-05 23:05:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "indices" : [ 3, 14 ],
      "id_str" : "18372260",
      "id" : 18372260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298928651989299200",
  "text" : "RT @grapealope: The reality is that we cannot deidentify DNA, and even if we could it doesn't make sense medically. Transparency is the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FutureMed",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298924880269828097",
    "text" : "The reality is that we cannot deidentify DNA, and even if we could it doesn't make sense medically. Transparency is the key. #FutureMed",
    "id" : 298924880269828097,
    "created_at" : "2013-02-05 22:43:39 +0000",
    "user" : {
      "name" : "Rachel Kalmar",
      "screen_name" : "grapealope",
      "protected" : false,
      "id_str" : "18372260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780881616\/rachelPortraitSq-sm_normal.jpg",
      "id" : 18372260,
      "verified" : false
    }
  },
  "id" : 298928651989299200,
  "created_at" : "2013-02-05 22:58:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298911153113939969",
  "text" : "Gotta love this: \u00ABIf you really want to understand the two-page Form FDA 1572 in astonishing detail, a 134-page book [..] is now available\u00BB",
  "id" : 298911153113939969,
  "created_at" : "2013-02-05 21:49:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/FCijiQCT",
      "expanded_url" : "http:\/\/i.imgur.com\/EgQDavv.jpg",
      "display_url" : "i.imgur.com\/EgQDavv.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "298879868790251520",
  "text" : "\u00ABMy buddy and I collect bones, we use a colony of flesh eating beetles to clean roadkill.\u00BB http:\/\/t.co\/FCijiQCT",
  "id" : 298879868790251520,
  "created_at" : "2013-02-05 19:44:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 0, 8 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298879168152743936",
  "geo" : { },
  "id_str" : "298879324671594496",
  "in_reply_to_user_id" : 32865583,
  "text" : "@raichoo Okay, danke f\u00FCr den Tipp trotzdem ;)",
  "id" : 298879324671594496,
  "in_reply_to_status_id" : 298879168152743936,
  "created_at" : "2013-02-05 19:42:38 +0000",
  "in_reply_to_screen_name" : "raichoo",
  "in_reply_to_user_id_str" : "32865583",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 0, 8 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298878763356258304",
  "geo" : { },
  "id_str" : "298878900187058177",
  "in_reply_to_user_id" : 32865583,
  "text" : "@raichoo Das ist zu 100% das Frittiergut was sich gerade in dem Ding befindet ;)",
  "id" : 298878900187058177,
  "in_reply_to_status_id" : 298878763356258304,
  "created_at" : "2013-02-05 19:40:57 +0000",
  "in_reply_to_screen_name" : "raichoo",
  "in_reply_to_user_id_str" : "32865583",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 0, 8 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298876056125976576",
  "geo" : { },
  "id_str" : "298878398829318144",
  "in_reply_to_user_id" : 32865583,
  "text" : "@raichoo Aber da f\u00E4llt mir auf: Du kannst bestimmt gute Tipps f\u00FCr vegane Rezepte in Verbindung mit dem Ding geben! :)",
  "id" : 298878398829318144,
  "in_reply_to_status_id" : 298876056125976576,
  "created_at" : "2013-02-05 19:38:57 +0000",
  "in_reply_to_screen_name" : "raichoo",
  "in_reply_to_user_id_str" : "32865583",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "cupe",
      "screen_name" : "cupe_cupe",
      "indices" : [ 7, 17 ],
      "id_str" : "143922800",
      "id" : 143922800
    }, {
      "name" : "Julian Finn",
      "screen_name" : "hdsjulian",
      "indices" : [ 18, 28 ],
      "id_str" : "12192142",
      "id" : 12192142
    }, {
      "name" : "Alexander Knoll",
      "screen_name" : "Argent23",
      "indices" : [ 66, 75 ],
      "id_str" : "22828618",
      "id" : 22828618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298877663496527872",
  "geo" : { },
  "id_str" : "298878206721794048",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @cupe_cupe @hdsjulian Ich hab es aus der gelesen-Liste von @Argent23 ;)",
  "id" : 298878206721794048,
  "in_reply_to_status_id" : 298877663496527872,
  "created_at" : "2013-02-05 19:38:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iseefaeces",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298877877481512961",
  "text" : "Somehow the #iseefaeces hashtag wouldn\u2019t trend on Instagram\u2026",
  "id" : 298877877481512961,
  "created_at" : "2013-02-05 19:36:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Timmer",
      "screen_name" : "j_timmer",
      "indices" : [ 3, 12 ],
      "id_str" : "16843817",
      "id" : 16843817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298877429529841664",
  "text" : "RT @j_timmer: OH: \"I found out that if you procrastinate long enough, you can write 60 pages of thesis in just 4 days!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298877358474153985",
    "text" : "OH: \"I found out that if you procrastinate long enough, you can write 60 pages of thesis in just 4 days!\"",
    "id" : 298877358474153985,
    "created_at" : "2013-02-05 19:34:49 +0000",
    "user" : {
      "name" : "John Timmer",
      "screen_name" : "j_timmer",
      "protected" : false,
      "id_str" : "16843817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780830028\/409400_10100143793528780_36914219_47154569_682273646_n_normal.jpg",
      "id" : 16843817,
      "verified" : true
    }
  },
  "id" : 298877429529841664,
  "created_at" : "2013-02-05 19:35:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 0, 8 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298876056125976576",
  "geo" : { },
  "id_str" : "298876201487986688",
  "in_reply_to_user_id" : 32865583,
  "text" : "@raichoo Heissluftfriteusenconnoisseur! ;)",
  "id" : 298876201487986688,
  "in_reply_to_status_id" : 298876056125976576,
  "created_at" : "2013-02-05 19:30:13 +0000",
  "in_reply_to_screen_name" : "raichoo",
  "in_reply_to_user_id_str" : "32865583",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "raichoo",
      "screen_name" : "raichoo",
      "indices" : [ 0, 8 ],
      "id_str" : "32865583",
      "id" : 32865583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298875198323707904",
  "geo" : { },
  "id_str" : "298875388589907968",
  "in_reply_to_user_id" : 32865583,
  "text" : "@raichoo ja, wenn du das daran erkannt hast musst du ein Experte sein :)",
  "id" : 298875388589907968,
  "in_reply_to_status_id" : 298875198323707904,
  "created_at" : "2013-02-05 19:27:00 +0000",
  "in_reply_to_screen_name" : "raichoo",
  "in_reply_to_user_id_str" : "32865583",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "indices" : [ 3, 17 ],
      "id_str" : "458966079",
      "id" : 458966079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298874744307081216",
  "text" : "RT @NeinQuarterly: When in doubt, Umlaut.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298869145737506816",
    "text" : "When in doubt, Umlaut.",
    "id" : 298869145737506816,
    "created_at" : "2013-02-05 19:02:11 +0000",
    "user" : {
      "name" : "Nein.",
      "screen_name" : "NeinQuarterly",
      "protected" : false,
      "id_str" : "458966079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702248569324093441\/5HWfjcOQ_normal.jpg",
      "id" : 458966079,
      "verified" : true
    }
  },
  "id" : 298874744307081216,
  "created_at" : "2013-02-05 19:24:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iseefaces",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/xIlT4HIw",
      "expanded_url" : "http:\/\/instagr.am\/p\/VXGHwHBwm1\/",
      "display_url" : "instagr.am\/p\/VXGHwHBwm1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "298874302906920960",
  "text" : "#iseefaces http:\/\/t.co\/xIlT4HIw",
  "id" : 298874302906920960,
  "created_at" : "2013-02-05 19:22:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298870090370273280",
  "geo" : { },
  "id_str" : "298870273535537153",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 damit k\u00F6nnte ich auch dienen. ;)",
  "id" : 298870273535537153,
  "in_reply_to_status_id" : 298870090370273280,
  "created_at" : "2013-02-05 19:06:40 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298869688815976448",
  "geo" : { },
  "id_str" : "298869817753083904",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 H\u00F6r dir mal ein paar andere Versionen an. Imho gibt es noch bessere. :)",
  "id" : 298869817753083904,
  "in_reply_to_status_id" : 298869688815976448,
  "created_at" : "2013-02-05 19:04:51 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298868493842018304",
  "geo" : { },
  "id_str" : "298869076908986368",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy beer pong might be more appropriate. Tackle the problem from both sides simultaneously!",
  "id" : 298869076908986368,
  "in_reply_to_status_id" : 298868493842018304,
  "created_at" : "2013-02-05 19:01:55 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/tAZgnXBW",
      "expanded_url" : "http:\/\/j.mp\/WO9ZUS",
      "display_url" : "j.mp\/WO9ZUS"
    } ]
  },
  "geo" : { },
  "id_str" : "298865334226661376",
  "text" : "Using the Fitbit-API to power off the fridge if not active? \u00ABI wasn't active, better eat everything before it spoils\u00BB http:\/\/t.co\/tAZgnXBW",
  "id" : 298865334226661376,
  "created_at" : "2013-02-05 18:47:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/v7JnZVoe",
      "expanded_url" : "http:\/\/j.mp\/YRc4Fz",
      "display_url" : "j.mp\/YRc4Fz"
    } ]
  },
  "geo" : { },
  "id_str" : "298842781999325186",
  "text" : "Vor 50 Jahren: Pinguine am Bodensee http:\/\/t.co\/v7JnZVoe",
  "id" : 298842781999325186,
  "created_at" : "2013-02-05 17:17:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 62, 75 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 76, 88 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/P8r3TzAE",
      "expanded_url" : "http:\/\/j.mp\/YRaK5J",
      "display_url" : "j.mp\/YRaK5J"
    } ]
  },
  "geo" : { },
  "id_str" : "298840108403154944",
  "text" : "Of Citizen Science, Ethics, and IRBs http:\/\/t.co\/P8r3TzAE \/cc @philippbayer @helgerausch",
  "id" : 298840108403154944,
  "created_at" : "2013-02-05 17:06:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "setient",
      "screen_name" : "setient",
      "indices" : [ 0, 8 ],
      "id_str" : "15851858",
      "id" : 15851858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298838153148641280",
  "geo" : { },
  "id_str" : "298838899105607681",
  "in_reply_to_user_id" : 15851858,
  "text" : "@setient that\u2019s the #1 reason why I used to wear one of them :)",
  "id" : 298838899105607681,
  "in_reply_to_status_id" : 298838153148641280,
  "created_at" : "2013-02-05 17:02:00 +0000",
  "in_reply_to_screen_name" : "setient",
  "in_reply_to_user_id_str" : "15851858",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043D\u0430\u0441\u0442\u0430\u0441\u0438\u044F \u041F\u0440\u0438\u0432\u043E\u043B\u0436\u043D\u0430\u044F",
      "screen_name" : "Wutbuergerin",
      "indices" : [ 3, 16 ],
      "id_str" : "224452301",
      "id" : 224452301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298838796491956224",
  "text" : "RT @Wutbuergerin: Remember Scientific Match, the dating site that matched immuno markers? British 'cool genes' is reviving the idea: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/ZorfqaNC",
        "expanded_url" : "http:\/\/buff.ly\/WMk0VT",
        "display_url" : "buff.ly\/WMk0VT"
      } ]
    },
    "geo" : { },
    "id_str" : "298838188695375872",
    "text" : "Remember Scientific Match, the dating site that matched immuno markers? British 'cool genes' is reviving the idea: http:\/\/t.co\/ZorfqaNC",
    "id" : 298838188695375872,
    "created_at" : "2013-02-05 16:59:10 +0000",
    "user" : {
      "name" : "Barbara Prainsack",
      "screen_name" : "BPrainsack",
      "protected" : false,
      "id_str" : "201632630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927171665917890561\/w5htgqHc_normal.jpg",
      "id" : 201632630,
      "verified" : false
    }
  },
  "id" : 298838796491956224,
  "created_at" : "2013-02-05 17:01:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298572487510331392",
  "geo" : { },
  "id_str" : "298817979825680385",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer haha, the reference to \u201Eon the beach\u201C is genius :)",
  "id" : 298817979825680385,
  "in_reply_to_status_id" : 298572487510331392,
  "created_at" : "2013-02-05 15:38:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298795079764684802",
  "text" : "Skimming my GO annotations: \"mRNA crap binding complex\"",
  "id" : 298795079764684802,
  "created_at" : "2013-02-05 14:07:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/FPANJQwk",
      "expanded_url" : "http:\/\/imgur.com\/a\/W5icb",
      "display_url" : "imgur.com\/a\/W5icb"
    } ]
  },
  "geo" : { },
  "id_str" : "298790563132633088",
  "text" : "While You Were Sleeping http:\/\/t.co\/FPANJQwk",
  "id" : 298790563132633088,
  "created_at" : "2013-02-05 13:49:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298763621138325504",
  "text" : "LRTs resulting in p-values &gt; 9000. Statistics' way of saying \"go home you're drunk\".",
  "id" : 298763621138325504,
  "created_at" : "2013-02-05 12:02:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/J0lNmJLL",
      "expanded_url" : "http:\/\/www.quickmeme.com\/meme\/3sus2v\/",
      "display_url" : "quickmeme.com\/meme\/3sus2v\/"
    } ]
  },
  "geo" : { },
  "id_str" : "298749416586768384",
  "text" : "The Comments Section http:\/\/t.co\/J0lNmJLL",
  "id" : 298749416586768384,
  "created_at" : "2013-02-05 11:06:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arseniclife",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298745721279115264",
  "text" : "Yet another review which basically says \"tl;dr. reject\"... Can I request the #arseniclife reviewers pls?",
  "id" : 298745721279115264,
  "created_at" : "2013-02-05 10:51:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/hRbX27rG",
      "expanded_url" : "http:\/\/tinyurl.com\/b8cn5hv",
      "display_url" : "tinyurl.com\/b8cn5hv"
    } ]
  },
  "geo" : { },
  "id_str" : "298743193971863552",
  "text" : "Fungal Barcoding: Identifying species within the (Annulo)hypoxylon genera (as visual ID will drive you insane) http:\/\/t.co\/hRbX27rG",
  "id" : 298743193971863552,
  "created_at" : "2013-02-05 10:41:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/NWVbh5pP",
      "expanded_url" : "http:\/\/tinyurl.com\/ap5p4qc",
      "display_url" : "tinyurl.com\/ap5p4qc"
    } ]
  },
  "geo" : { },
  "id_str" : "298728562121404416",
  "text" : "\"Welchen Geschmack hat die eigene Bestechlichkeit? Den nach zu viel gutem Essen [...], Sonne, Alkohol &amp; Schlaf.\" http:\/\/t.co\/NWVbh5pP",
  "id" : 298728562121404416,
  "created_at" : "2013-02-05 09:43:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/v1KgXKXf",
      "expanded_url" : "http:\/\/tinyurl.com\/aor7x6y",
      "display_url" : "tinyurl.com\/aor7x6y"
    } ]
  },
  "geo" : { },
  "id_str" : "298726720876449792",
  "text" : "I'm not too surprised that Robin Dunbar uses sociality as measure for intelligence in the fight cat vs. dog http:\/\/t.co\/v1KgXKXf",
  "id" : 298726720876449792,
  "created_at" : "2013-02-05 09:36:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/VAbR7gOZ",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1557",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298723206347497473",
  "text" : "A disturbance in the force http:\/\/t.co\/VAbR7gOZ",
  "id" : 298723206347497473,
  "created_at" : "2013-02-05 09:22:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wei\u00DF",
      "screen_name" : "pfadintegral",
      "indices" : [ 0, 13 ],
      "id_str" : "102668707",
      "id" : 102668707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298711623445659648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097294168, 8.2832788479 ]
  },
  "id_str" : "298714937080041473",
  "in_reply_to_user_id" : 102668707,
  "text" : "@pfadintegral Grundschulaufsatz",
  "id" : 298714937080041473,
  "in_reply_to_status_id" : 298711623445659648,
  "created_at" : "2013-02-05 08:49:25 +0000",
  "in_reply_to_screen_name" : "pfadintegral",
  "in_reply_to_user_id_str" : "102668707",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 3, 17 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PhysiognomyItWorksNot",
      "indices" : [ 85, 107 ]
    }, {
      "text" : "RichardIII",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/229baBf3",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-england-leicestershire-21328380",
      "display_url" : "bbc.co.uk\/news\/uk-englan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298714787427274753",
  "text" : "RT @zoonpolitikon: \"It doesn't look like the face of a tyrant.\" We are all relieved. #PhysiognomyItWorksNot #RichardIII http:\/\/t.co\/229baBf3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PhysiognomyItWorksNot",
        "indices" : [ 66, 88 ]
      }, {
        "text" : "RichardIII",
        "indices" : [ 89, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/229baBf3",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/uk-england-leicestershire-21328380",
        "display_url" : "bbc.co.uk\/news\/uk-englan\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298709319568982017",
    "text" : "\"It doesn't look like the face of a tyrant.\" We are all relieved. #PhysiognomyItWorksNot #RichardIII http:\/\/t.co\/229baBf3",
    "id" : 298709319568982017,
    "created_at" : "2013-02-05 08:27:06 +0000",
    "user" : {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "protected" : false,
      "id_str" : "13040652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702734921629697\/1TUbd7IS_normal.jpg",
      "id" : 13040652,
      "verified" : false
    }
  },
  "id" : 298714787427274753,
  "created_at" : "2013-02-05 08:48:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "indices" : [ 3, 14 ],
      "id_str" : "14085070",
      "id" : 14085070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/ZnGlykn6",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/0870334336\/ref=tsm_1_fb_lk?tag=hydfbook0e-20&ascsubtag=US-SAGE-1357815742725-RMYXF",
      "display_url" : "amazon.com\/dp\/0870334336\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298586814585913344",
  "text" : "RT @carlzimmer: \"How to Avoid Large Ships.\" Another collection of fine Amazon reviews. http:\/\/t.co\/ZnGlykn6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/ZnGlykn6",
        "expanded_url" : "http:\/\/www.amazon.com\/dp\/0870334336\/ref=tsm_1_fb_lk?tag=hydfbook0e-20&ascsubtag=US-SAGE-1357815742725-RMYXF",
        "display_url" : "amazon.com\/dp\/0870334336\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298585963645501440",
    "text" : "\"How to Avoid Large Ships.\" Another collection of fine Amazon reviews. http:\/\/t.co\/ZnGlykn6",
    "id" : 298585963645501440,
    "created_at" : "2013-02-05 00:16:55 +0000",
    "user" : {
      "name" : "Carl Zimmer",
      "screen_name" : "carlzimmer",
      "protected" : false,
      "id_str" : "14085070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/916034313069715457\/url2G14j_normal.jpg",
      "id" : 14085070,
      "verified" : true
    }
  },
  "id" : 298586814585913344,
  "created_at" : "2013-02-05 00:20:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Johnson",
      "screen_name" : "GeneAPseattle",
      "indices" : [ 3, 17 ],
      "id_str" : "80375074",
      "id" : 80375074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/6mVmnGiR",
      "expanded_url" : "http:\/\/is.gd\/bXJbzn",
      "display_url" : "is.gd\/bXJbzn"
    } ]
  },
  "geo" : { },
  "id_str" : "298585822876286976",
  "text" : "RT @GeneAPseattle: Awesome. \"The 1st beer brewed by print journalists, for print journalists.\" http:\/\/t.co\/6mVmnGiR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/6mVmnGiR",
        "expanded_url" : "http:\/\/is.gd\/bXJbzn",
        "display_url" : "is.gd\/bXJbzn"
      } ]
    },
    "geo" : { },
    "id_str" : "298581637594230784",
    "text" : "Awesome. \"The 1st beer brewed by print journalists, for print journalists.\" http:\/\/t.co\/6mVmnGiR",
    "id" : 298581637594230784,
    "created_at" : "2013-02-04 23:59:44 +0000",
    "user" : {
      "name" : "Gene Johnson",
      "screen_name" : "GeneAPseattle",
      "protected" : false,
      "id_str" : "80375074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456727365\/revelstoke_normal.jpg",
      "id" : 80375074,
      "verified" : false
    }
  },
  "id" : 298585822876286976,
  "created_at" : "2013-02-05 00:16:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298579583085735936",
  "text" : "\u00ABKannst du aufh\u00F6ren mir Lebensweisheiten aus Disney-Filmen andrehen zu wollen? Versuch es doch wenigstens mit Californication.\u00BB",
  "id" : 298579583085735936,
  "created_at" : "2013-02-04 23:51:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/8gJXRAgo",
      "expanded_url" : "http:\/\/i.imgur.com\/r2rwYO8.jpg",
      "display_url" : "i.imgur.com\/r2rwYO8.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "298570277019873280",
  "text" : "\u00ABLove.\u2026 Love never changes\u00BB &lt;3 http:\/\/t.co\/8gJXRAgo",
  "id" : 298570277019873280,
  "created_at" : "2013-02-04 23:14:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298563760589795328",
  "text" : "\u00ABIch vermute Messerwerfer haben mad skills beim Dildo Dart. Man muss doch nur die Rotation auf Distanz berechnen k\u00F6nnen.\u00BB",
  "id" : 298563760589795328,
  "created_at" : "2013-02-04 22:48:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "indices" : [ 3, 17 ],
      "id_str" : "112475924",
      "id" : 112475924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/U8Rh8yOs",
      "expanded_url" : "http:\/\/bit.ly\/Wqr1fi",
      "display_url" : "bit.ly\/Wqr1fi"
    } ]
  },
  "geo" : { },
  "id_str" : "298561860448423936",
  "text" : "RT @JacquelynGill: THIS is what you do when you identify a $3k gender-based wage gap at your institution: http:\/\/t.co\/U8Rh8yOs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/U8Rh8yOs",
        "expanded_url" : "http:\/\/bit.ly\/Wqr1fi",
        "display_url" : "bit.ly\/Wqr1fi"
      } ]
    },
    "geo" : { },
    "id_str" : "298561232305270784",
    "text" : "THIS is what you do when you identify a $3k gender-based wage gap at your institution: http:\/\/t.co\/U8Rh8yOs",
    "id" : 298561232305270784,
    "created_at" : "2013-02-04 22:38:39 +0000",
    "user" : {
      "name" : "Jacquelyn Gill",
      "screen_name" : "JacquelynGill",
      "protected" : false,
      "id_str" : "112475924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816027573343965184\/qUfIq3xY_normal.jpg",
      "id" : 112475924,
      "verified" : true
    }
  },
  "id" : 298561860448423936,
  "created_at" : "2013-02-04 22:41:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZoraMonsterchen",
      "screen_name" : "ZoraMonsterchen",
      "indices" : [ 0, 16 ],
      "id_str" : "2542056559",
      "id" : 2542056559
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 17, 23 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298557364087435265",
  "text" : "@ZoraMonsterchen @Lobot Wovon?",
  "id" : 298557364087435265,
  "created_at" : "2013-02-04 22:23:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/yT6qv07P",
      "expanded_url" : "http:\/\/imgur.com\/r\/funny\/IMRAgen",
      "display_url" : "imgur.com\/r\/funny\/IMRAgen"
    } ]
  },
  "geo" : { },
  "id_str" : "298556246208950272",
  "text" : "The Alpaca-Human species barrier can be crossed after all! http:\/\/t.co\/yT6qv07P",
  "id" : 298556246208950272,
  "created_at" : "2013-02-04 22:18:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Christoph Steltner",
      "screen_name" : "nplhse",
      "indices" : [ 46, 53 ],
      "id_str" : "111716214",
      "id" : 111716214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298554963955691520",
  "geo" : { },
  "id_str" : "298555656397524992",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj @Lobot Im Zweifel verweise ich an Dr. @nplhse und erbitte eine Erkl\u00E4rung. ;)",
  "id" : 298555656397524992,
  "in_reply_to_status_id" : 298554963955691520,
  "created_at" : "2013-02-04 22:16:30 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298554503605649409",
  "geo" : { },
  "id_str" : "298555040073908224",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich bin ja kein Experte, aber ist der Unterschied hier nicht vor allem der Ausl\u00F6ser?",
  "id" : 298555040073908224,
  "in_reply_to_status_id" : 298554503605649409,
  "created_at" : "2013-02-04 22:14:03 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 3, 15 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/XpToy7YT",
      "expanded_url" : "http:\/\/bit.ly\/WKBZvP",
      "display_url" : "bit.ly\/WKBZvP"
    } ]
  },
  "geo" : { },
  "id_str" : "298554174042431489",
  "text" : "RT @bengoldacre: \"Penile Implants among Prisoners\u2014A Cause for Concern?\" Pass the betadine... http:\/\/t.co\/XpToy7YT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/XpToy7YT",
        "expanded_url" : "http:\/\/bit.ly\/WKBZvP",
        "display_url" : "bit.ly\/WKBZvP"
      } ]
    },
    "geo" : { },
    "id_str" : "298553673271885825",
    "text" : "\"Penile Implants among Prisoners\u2014A Cause for Concern?\" Pass the betadine... http:\/\/t.co\/XpToy7YT",
    "id" : 298553673271885825,
    "created_at" : "2013-02-04 22:08:37 +0000",
    "user" : {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "protected" : false,
      "id_str" : "6705042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523118410419286016\/qXTUFTZR_normal.png",
      "id" : 6705042,
      "verified" : true
    }
  },
  "id" : 298554174042431489,
  "created_at" : "2013-02-04 22:10:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/wixBPO8h",
      "expanded_url" : "http:\/\/j.mp\/XGqYJU",
      "display_url" : "j.mp\/XGqYJU"
    } ]
  },
  "geo" : { },
  "id_str" : "298548207288459265",
  "text" : "WTF Forensik \u2013 Suizid durch Fischverzehr http:\/\/t.co\/wixBPO8h",
  "id" : 298548207288459265,
  "created_at" : "2013-02-04 21:46:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298531543293501440",
  "text" : "\u00ABThis is Dylan, isn\u2019t it? You like this one?\u00BB \u2013 \u00ABNo. I only like the seventies Dylan and the post-1990s Dylan\u00BB",
  "id" : 298531543293501440,
  "created_at" : "2013-02-04 20:40:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298527551201095680",
  "geo" : { },
  "id_str" : "298528360890519553",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Serviervorschlag ;)",
  "id" : 298528360890519553,
  "in_reply_to_status_id" : 298527551201095680,
  "created_at" : "2013-02-04 20:28:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298523320847060992",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Thx for The Last Policeman. ~40% in and love it :)",
  "id" : 298523320847060992,
  "created_at" : "2013-02-04 20:08:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "See Arr Oh",
      "screen_name" : "SeeArrOh",
      "indices" : [ 3, 12 ],
      "id_str" : "288402923",
      "id" : 288402923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "postdocalypsenow",
      "indices" : [ 93, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298517676228243456",
  "text" : "RT @SeeArrOh: College Reunion: House? Kids? Cars? \"Um, I'm lead author on a Nature paper...\" #postdocalypsenow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "postdocalypsenow",
        "indices" : [ 79, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298509127494279168",
    "text" : "College Reunion: House? Kids? Cars? \"Um, I'm lead author on a Nature paper...\" #postdocalypsenow",
    "id" : 298509127494279168,
    "created_at" : "2013-02-04 19:11:36 +0000",
    "user" : {
      "name" : "See Arr Oh",
      "screen_name" : "SeeArrOh",
      "protected" : false,
      "id_str" : "288402923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1327220516\/twitter_pic1_normal.jpg",
      "id" : 288402923,
      "verified" : false
    }
  },
  "id" : 298517676228243456,
  "created_at" : "2013-02-04 19:45:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298514941621727232",
  "text" : "\u00ABDie K\u00E4tzchen sind aber s\u00FC\u00DF. Darf ich die haben?\u00BB \u2013 \u00ABNein, die geh\u00F6ren schon irgendwem auf Reddit.\u00BB",
  "id" : 298514941621727232,
  "created_at" : "2013-02-04 19:34:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/uFYPkBGn",
      "expanded_url" : "http:\/\/j.mp\/Wq8fVA",
      "display_url" : "j.mp\/Wq8fVA"
    } ]
  },
  "geo" : { },
  "id_str" : "298514227684077568",
  "text" : "Tree ring history spurs actual climate science debate http:\/\/t.co\/uFYPkBGn",
  "id" : 298514227684077568,
  "created_at" : "2013-02-04 19:31:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298500611530444800",
  "text" : "\u00ABIch schwimme mal schnell \u00FCber die Maaraue\u00BB w\u00E4re wohl treffender gewesen.",
  "id" : 298500611530444800,
  "created_at" : "2013-02-04 18:37:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prof Jeff Jarvis",
      "screen_name" : "ProfJeffJarvis",
      "indices" : [ 3, 18 ],
      "id_str" : "2751062792",
      "id" : 2751062792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298485151392989184",
  "text" : "RT @ProfJeffJarvis: Not a good day for Assad: the iOS 6 jailbreak is out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298482594264264704",
    "text" : "Not a good day for Assad: the iOS 6 jailbreak is out.",
    "id" : 298482594264264704,
    "created_at" : "2013-02-04 17:26:10 +0000",
    "user" : {
      "name" : "#JeSuisForbes30under30",
      "screen_name" : "ProfJeffJarviss",
      "protected" : false,
      "id_str" : "514613499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/883037883455680512\/SNA5PtKb_normal.jpg",
      "id" : 514613499,
      "verified" : false
    }
  },
  "id" : 298485151392989184,
  "created_at" : "2013-02-04 17:36:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/JfUw6QTV",
      "expanded_url" : "http:\/\/i.imgur.com\/CrzBQiU.jpg",
      "display_url" : "i.imgur.com\/CrzBQiU.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "298483599857041409",
  "text" : "Evolution? That\u2019s not how it works! http:\/\/t.co\/JfUw6QTV",
  "id" : 298483599857041409,
  "created_at" : "2013-02-04 17:30:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "indices" : [ 3, 12 ],
      "id_str" : "3453971",
      "id" : 3453971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/5Qij400e",
      "expanded_url" : "http:\/\/signup.bangboss.co",
      "display_url" : "signup.bangboss.co"
    } ]
  },
  "geo" : { },
  "id_str" : "298478971539038208",
  "text" : "RT @blacktar: \"Why Bang With Friends when you can Bang With Bosses &amp; Get Ahead\" http:\/\/t.co\/5Qij400e Of course that just had to happ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/5Qij400e",
        "expanded_url" : "http:\/\/signup.bangboss.co",
        "display_url" : "signup.bangboss.co"
      } ]
    },
    "geo" : { },
    "id_str" : "298478667938557952",
    "text" : "\"Why Bang With Friends when you can Bang With Bosses &amp; Get Ahead\" http:\/\/t.co\/5Qij400e Of course that just had to happen...",
    "id" : 298478667938557952,
    "created_at" : "2013-02-04 17:10:34 +0000",
    "user" : {
      "name" : "Vidar Andersen dot com",
      "screen_name" : "blacktar",
      "protected" : false,
      "id_str" : "3453971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897036682721153024\/sPNcTIBm_normal.jpg",
      "id" : 3453971,
      "verified" : false
    }
  },
  "id" : 298478971539038208,
  "created_at" : "2013-02-04 17:11:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298477195662352385",
  "text" : "Highly doubt that \u00ABThe paper \"2 424 440 TONS PRODUCED IN 2004 IN EUROPE\" is about SNP vg07s29419-2\u00BB Have to adjust our Mendeley-crawling\u2026",
  "id" : 298477195662352385,
  "created_at" : "2013-02-04 17:04:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan O. Perlstein",
      "screen_name" : "eperlste",
      "indices" : [ 3, 12 ],
      "id_str" : "237409428",
      "id" : 237409428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/Wm5PUU4O",
      "expanded_url" : "http:\/\/bit.ly\/WQBu3c",
      "display_url" : "bit.ly\/WQBu3c"
    } ]
  },
  "geo" : { },
  "id_str" : "298476264182915072",
  "text" : "RT @eperlste: Postdocalypse now http:\/\/t.co\/Wm5PUU4O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http:\/\/t.co\/Wm5PUU4O",
        "expanded_url" : "http:\/\/bit.ly\/WQBu3c",
        "display_url" : "bit.ly\/WQBu3c"
      } ]
    },
    "geo" : { },
    "id_str" : "298474055793778688",
    "text" : "Postdocalypse now http:\/\/t.co\/Wm5PUU4O",
    "id" : 298474055793778688,
    "created_at" : "2013-02-04 16:52:14 +0000",
    "user" : {
      "name" : "Ethan O. Perlstein",
      "screen_name" : "eperlste",
      "protected" : false,
      "id_str" : "237409428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911105941373779968\/MS1jXuJJ_normal.jpg",
      "id" : 237409428,
      "verified" : false
    }
  },
  "id" : 298476264182915072,
  "created_at" : "2013-02-04 17:01:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298454662363881472",
  "geo" : { },
  "id_str" : "298456602149793793",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn For a second I really wondered why Canadians would celebrate \"no more penis\"...",
  "id" : 298456602149793793,
  "in_reply_to_status_id" : 298454662363881472,
  "created_at" : "2013-02-04 15:42:53 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http:\/\/t.co\/IhwbMazp",
      "expanded_url" : "http:\/\/i3.kym-cdn.com\/photos\/images\/newsfeed\/000\/275\/076\/a80.jpg",
      "display_url" : "i3.kym-cdn.com\/photos\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298434223902175232",
  "text" : "Hello! http:\/\/t.co\/IhwbMazp",
  "id" : 298434223902175232,
  "created_at" : "2013-02-04 14:13:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/8pV7UZqA",
      "expanded_url" : "http:\/\/tinyurl.com\/ay4grrm",
      "display_url" : "tinyurl.com\/ay4grrm"
    } ]
  },
  "geo" : { },
  "id_str" : "298390277452886016",
  "text" : "Is the age of scientific genius over? http:\/\/t.co\/8pV7UZqA",
  "id" : 298390277452886016,
  "created_at" : "2013-02-04 11:19:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/pfZUpdkb",
      "expanded_url" : "http:\/\/tinyurl.com\/bpns9pq#",
      "display_url" : "tinyurl.com\/bpns9pq#"
    } ]
  },
  "geo" : { },
  "id_str" : "298385170782883840",
  "text" : "\"If guns don\u2019t kill people, then neither does gun control cause genocide (genocidal regimes cause genocide).\" http:\/\/t.co\/pfZUpdkb",
  "id" : 298385170782883840,
  "created_at" : "2013-02-04 10:59:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298382721883992064",
  "geo" : { },
  "id_str" : "298383565270437888",
  "in_reply_to_user_id" : 14700783,
  "text" : "@fischblog Und da soll Forbes noch mal behaupten Professor w\u00E4re der least stressful job!",
  "id" : 298383565270437888,
  "in_reply_to_status_id" : 298382721883992064,
  "created_at" : "2013-02-04 10:52:40 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tori Herridge",
      "screen_name" : "ToriHerridge",
      "indices" : [ 3, 16 ],
      "id_str" : "57076191",
      "id" : 57076191
    }, {
      "name" : "paleogenomics",
      "screen_name" : "paleogenomics",
      "indices" : [ 83, 97 ],
      "id_str" : "1128132072",
      "id" : 1128132072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RichardIII",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298383276106711042",
  "text" : "RT @ToriHerridge: The aDNA community is already sounding some notes of caution: RT @paleogenomics #RichardIII aDNA analysis has many flaws !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "paleogenomics",
        "screen_name" : "paleogenomics",
        "indices" : [ 65, 79 ],
        "id_str" : "1128132072",
        "id" : 1128132072
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RichardIII",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "298380189254168576",
    "geo" : { },
    "id_str" : "298380802557894657",
    "in_reply_to_user_id" : 1128132072,
    "text" : "The aDNA community is already sounding some notes of caution: RT @paleogenomics #RichardIII aDNA analysis has many flaws !",
    "id" : 298380802557894657,
    "in_reply_to_status_id" : 298380189254168576,
    "created_at" : "2013-02-04 10:41:41 +0000",
    "in_reply_to_screen_name" : "paleogenomics",
    "in_reply_to_user_id_str" : "1128132072",
    "user" : {
      "name" : "Tori Herridge",
      "screen_name" : "ToriHerridge",
      "protected" : false,
      "id_str" : "57076191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533848438988099585\/n4wsZJnh_normal.jpeg",
      "id" : 57076191,
      "verified" : false
    }
  },
  "id" : 298383276106711042,
  "created_at" : "2013-02-04 10:51:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Radden Keefe",
      "screen_name" : "praddenkeefe",
      "indices" : [ 80, 93 ],
      "id_str" : "380524610",
      "id" : 380524610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longreads",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/ReUnBXCP",
      "expanded_url" : "http:\/\/tinyurl.com\/cvg8q3b",
      "display_url" : "tinyurl.com\/cvg8q3b"
    } ]
  },
  "geo" : { },
  "id_str" : "298382448650231808",
  "text" : "The story of Amy Bishop, who shot 6 colleagues at a faculty meeting in 2010, by @praddenkeefe #longreads http:\/\/t.co\/ReUnBXCP",
  "id" : 298382448650231808,
  "created_at" : "2013-02-04 10:48:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298370233721303040",
  "geo" : { },
  "id_str" : "298371585163804675",
  "in_reply_to_user_id" : 1492631,
  "text" : "@lobot (though I'm always unsure about how much of that is just sloppy choice of words)",
  "id" : 298371585163804675,
  "in_reply_to_status_id" : 298370233721303040,
  "created_at" : "2013-02-04 10:05:04 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298370233721303040",
  "geo" : { },
  "id_str" : "298371404934553600",
  "in_reply_to_user_id" : 1492631,
  "text" : "@lobot I guess we have worse offenders. It's amazing how many biologists attribute natural selection at least some agency.",
  "id" : 298371404934553600,
  "in_reply_to_status_id" : 298370233721303040,
  "created_at" : "2013-02-04 10:04:21 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/UvFBzkcQ",
      "expanded_url" : "http:\/\/instagr.am\/p\/VTf7qRBwkH\/",
      "display_url" : "instagr.am\/p\/VTf7qRBwkH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "298368180273954816",
  "text" : "\u00ABLet's say these are biological samples, okay?\u00BB http:\/\/t.co\/UvFBzkcQ",
  "id" : 298368180273954816,
  "created_at" : "2013-02-04 09:51:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twirssi.com\" rel=\"nofollow\"\u003ETwirssi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/Jn054E7L",
      "expanded_url" : "http:\/\/tinyurl.com\/cm4cms7",
      "display_url" : "tinyurl.com\/cm4cms7"
    } ]
  },
  "geo" : { },
  "id_str" : "298366858715881473",
  "text" : "Cuckoldry rates in Germany are ~1 percent http:\/\/t.co\/Jn054E7L",
  "id" : 298366858715881473,
  "created_at" : "2013-02-04 09:46:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "indices" : [ 3, 15 ],
      "id_str" : "26616462",
      "id" : 26616462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298212409594769409",
  "text" : "RT @ctitusbrown: They should auction zamboni driving opps.  It looks really satisfying in comparison to my day job, at least in the shor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298212326824349698",
    "text" : "They should auction zamboni driving opps.  It looks really satisfying in comparison to my day job, at least in the short term.",
    "id" : 298212326824349698,
    "created_at" : "2013-02-03 23:32:13 +0000",
    "user" : {
      "name" : "Titus Brown",
      "screen_name" : "ctitusbrown",
      "protected" : false,
      "id_str" : "26616462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662714429742514176\/bwLg2tBG_normal.jpg",
      "id" : 26616462,
      "verified" : false
    }
  },
  "id" : 298212409594769409,
  "created_at" : "2013-02-03 23:32:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "seshupik flekh'es",
      "screen_name" : "FrauFledermaus",
      "indices" : [ 0, 15 ],
      "id_str" : "41335337",
      "id" : 41335337
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 16, 20 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298205397506990080",
  "geo" : { },
  "id_str" : "298206063893819392",
  "in_reply_to_user_id" : 41335337,
  "text" : "@FrauFledermaus @scy das sieht ja auch aus wie Zuckerwatte!",
  "id" : 298206063893819392,
  "in_reply_to_status_id" : 298205397506990080,
  "created_at" : "2013-02-03 23:07:20 +0000",
  "in_reply_to_screen_name" : "FrauFledermaus",
  "in_reply_to_user_id_str" : "41335337",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298205405434232832",
  "geo" : { },
  "id_str" : "298205840610062337",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy ich hab mir die Frage verkniffen. Wurde ja schon \u201E0 books\u201C neben deinem Namen angezeigt!",
  "id" : 298205840610062337,
  "in_reply_to_status_id" : 298205405434232832,
  "created_at" : "2013-02-03 23:06:27 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298205003481501696",
  "text" : "\u00ABOne feature of the usual script for plague: the disease invariably comes from somewhere else.\u00BB",
  "id" : 298205003481501696,
  "created_at" : "2013-02-03 23:03:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 0, 4 ],
      "id_str" : "8308632",
      "id" : 8308632
    }, {
      "name" : "seshupik flekh'es",
      "screen_name" : "FrauFledermaus",
      "indices" : [ 5, 20 ],
      "id_str" : "41335337",
      "id" : 41335337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298203358483857408",
  "geo" : { },
  "id_str" : "298203560468951041",
  "in_reply_to_user_id" : 8308632,
  "text" : "@scy @FrauFledermaus das sind diese Pokemon, oder? ;)",
  "id" : 298203560468951041,
  "in_reply_to_status_id" : 298203358483857408,
  "created_at" : "2013-02-03 22:57:23 +0000",
  "in_reply_to_screen_name" : "scy",
  "in_reply_to_user_id_str" : "8308632",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Must be Minta",
      "screen_name" : "mintaburst",
      "indices" : [ 3, 14 ],
      "id_str" : "25515849",
      "id" : 25515849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/t5i1vbK6",
      "expanded_url" : "http:\/\/www.penispans.com\/page2\/index.html",
      "display_url" : "penispans.com\/page2\/index.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "298201453154164738",
  "text" : "RT @mintaburst: One woman's quest to get the most out of her penis cake pan. An epic tale of triumph and heartbreak... http:\/\/t.co\/t5i1vbK6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/t5i1vbK6",
        "expanded_url" : "http:\/\/www.penispans.com\/page2\/index.html",
        "display_url" : "penispans.com\/page2\/index.ht\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297984641246298113",
    "text" : "One woman's quest to get the most out of her penis cake pan. An epic tale of triumph and heartbreak... http:\/\/t.co\/t5i1vbK6",
    "id" : 297984641246298113,
    "created_at" : "2013-02-03 08:27:29 +0000",
    "user" : {
      "name" : "Must be Minta",
      "screen_name" : "mintaburst",
      "protected" : false,
      "id_str" : "25515849",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804160165931061248\/g_E06ub6_normal.jpg",
      "id" : 25515849,
      "verified" : false
    }
  },
  "id" : 298201453154164738,
  "created_at" : "2013-02-03 22:49:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 14, 18 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298196559290564609",
  "geo" : { },
  "id_str" : "298197327703855104",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @scy +1 daf\u00FCr.",
  "id" : 298197327703855104,
  "in_reply_to_status_id" : 298196559290564609,
  "created_at" : "2013-02-03 22:32:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mo Costandi",
      "screen_name" : "mocost",
      "indices" : [ 3, 10 ],
      "id_str" : "18985501",
      "id" : 18985501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/4d8YQvxe",
      "expanded_url" : "http:\/\/gu.com\/p\/3dgy2\/tw",
      "display_url" : "gu.com\/p\/3dgy2\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "298196254570209280",
  "text" : "RT @mocost: Fearless brain-damaged patients are terrified of suffocation  http:\/\/t.co\/4d8YQvxe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/4d8YQvxe",
        "expanded_url" : "http:\/\/gu.com\/p\/3dgy2\/tw",
        "display_url" : "gu.com\/p\/3dgy2\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "298160599630741504",
    "text" : "Fearless brain-damaged patients are terrified of suffocation  http:\/\/t.co\/4d8YQvxe",
    "id" : 298160599630741504,
    "created_at" : "2013-02-03 20:06:41 +0000",
    "user" : {
      "name" : "Mo Costandi",
      "screen_name" : "mocost",
      "protected" : false,
      "id_str" : "18985501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830037263463698433\/-ijq6uXA_normal.jpg",
      "id" : 18985501,
      "verified" : false
    }
  },
  "id" : 298196254570209280,
  "created_at" : "2013-02-03 22:28:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/Kuxfh7qS",
      "expanded_url" : "http:\/\/j.mp\/YvcuO9",
      "display_url" : "j.mp\/YvcuO9"
    } ]
  },
  "geo" : { },
  "id_str" : "298193970641649667",
  "text" : "The bacteria that live inside hurricanes http:\/\/t.co\/Kuxfh7qS",
  "id" : 298193970641649667,
  "created_at" : "2013-02-03 22:19:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Journal of BS",
      "screen_name" : "AcademicTitles",
      "indices" : [ 3, 18 ],
      "id_str" : "208380906",
      "id" : 208380906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298184010042060800",
  "text" : "RT @AcademicTitles: \"'Look At Me Not Caring About Your Popular Cultural Event': Performative Academic Identity, Twitter, and Super Bowl  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298177165290266624",
    "text" : "\"'Look At Me Not Caring About Your Popular Cultural Event': Performative Academic Identity, Twitter, and Super Bowl Sunday\"",
    "id" : 298177165290266624,
    "created_at" : "2013-02-03 21:12:30 +0000",
    "user" : {
      "name" : "The Journal of BS",
      "screen_name" : "AcademicTitles",
      "protected" : false,
      "id_str" : "208380906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1369359937\/title_normal.jpg",
      "id" : 208380906,
      "verified" : false
    }
  },
  "id" : 298184010042060800,
  "created_at" : "2013-02-03 21:39:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298180794898329602",
  "geo" : { },
  "id_str" : "298180834014412800",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot finally! ;)",
  "id" : 298180834014412800,
  "in_reply_to_status_id" : 298180794898329602,
  "created_at" : "2013-02-03 21:27:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298177763314114560",
  "geo" : { },
  "id_str" : "298180016649420802",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot In Alpakablut baden ist in manchen Kulturen bestimmt ein kr\u00E4ftebringendes Ritual!",
  "id" : 298180016649420802,
  "in_reply_to_status_id" : 298177763314114560,
  "created_at" : "2013-02-03 21:23:50 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298172618123644928",
  "geo" : { },
  "id_str" : "298175986715987968",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot Wenn man den Rasierer falsch ansetzt kann man bestimmt die Carotiden durchschneiden ;)",
  "id" : 298175986715987968,
  "in_reply_to_status_id" : 298172618123644928,
  "created_at" : "2013-02-03 21:07:49 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298152256556134400",
  "text" : "\u00AB'Niedersachsengerechter'? Ist das sowas wie special needs Gerechtigkeit?\u00BB",
  "id" : 298152256556134400,
  "created_at" : "2013-02-03 19:33:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "indices" : [ 3, 11 ],
      "id_str" : "3163591",
      "id" : 3163591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298133265989120000",
  "text" : "RT @gknauss: Live by the gun, die by the gun.\n\nGo to work, die by the gun. Attend school, die by the gun. See a movie, die by the gun.\n\nEtc.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298125885188497409",
    "text" : "Live by the gun, die by the gun.\n\nGo to work, die by the gun. Attend school, die by the gun. See a movie, die by the gun.\n\nEtc.",
    "id" : 298125885188497409,
    "created_at" : "2013-02-03 17:48:44 +0000",
    "user" : {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "protected" : false,
      "id_str" : "3163591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/38137892\/greg-icon-128_normal.gif",
      "id" : 3163591,
      "verified" : false
    }
  },
  "id" : 298133265989120000,
  "created_at" : "2013-02-03 18:18:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Clark",
      "screen_name" : "iameltonjohn",
      "indices" : [ 0, 13 ],
      "id_str" : "1514567630",
      "id" : 1514567630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298109902583365632",
  "geo" : { },
  "id_str" : "298110498308751361",
  "in_reply_to_user_id" : 15661851,
  "text" : "@iameltonjohn \u00ABIt\u2019s like a car wash for cutlery!\u00BB",
  "id" : 298110498308751361,
  "in_reply_to_status_id" : 298109902583365632,
  "created_at" : "2013-02-03 16:47:36 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Butterfield",
      "screen_name" : "MrBButterfield",
      "indices" : [ 3, 18 ],
      "id_str" : "32581388",
      "id" : 32581388
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrBButterfield\/status\/298056756553203712\/photo\/1",
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/yFr2dXNX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCLpCnmCQAIVuP1.jpg",
      "id_str" : "298056756557398018",
      "id" : 298056756557398018,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCLpCnmCQAIVuP1.jpg",
      "sizes" : [ {
        "h" : 1053,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 646
      }, {
        "h" : 1053,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1053,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/yFr2dXNX"
    } ],
    "hashtags" : [ {
      "text" : "superbowl",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298104203979681794",
  "text" : "RT @MrBButterfield: Looking forward to seeing this later! #superbowl http:\/\/t.co\/yFr2dXNX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrBButterfield\/status\/298056756553203712\/photo\/1",
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/yFr2dXNX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BCLpCnmCQAIVuP1.jpg",
        "id_str" : "298056756557398018",
        "id" : 298056756557398018,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCLpCnmCQAIVuP1.jpg",
        "sizes" : [ {
          "h" : 1053,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 646
        }, {
          "h" : 1053,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1053,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/yFr2dXNX"
      } ],
      "hashtags" : [ {
        "text" : "superbowl",
        "indices" : [ 38, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298056756553203712",
    "text" : "Looking forward to seeing this later! #superbowl http:\/\/t.co\/yFr2dXNX",
    "id" : 298056756553203712,
    "created_at" : "2013-02-03 13:14:03 +0000",
    "user" : {
      "name" : "Brian Butterfield",
      "screen_name" : "MrBButterfield",
      "protected" : false,
      "id_str" : "32581388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3673113505\/473a5f6370f3861f3dd0654c0111d143_normal.jpeg",
      "id" : 32581388,
      "verified" : false
    }
  },
  "id" : 298104203979681794,
  "created_at" : "2013-02-03 16:22:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Wall",
      "screen_name" : "m_wall",
      "indices" : [ 3, 10 ],
      "id_str" : "155916643",
      "id" : 155916643
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/m_wall\/status\/298052014124974084\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/3aLuoaMe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCLkuksCQAI-jRx.jpg",
      "id_str" : "298052014133362690",
      "id" : 298052014133362690,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCLkuksCQAI-jRx.jpg",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 662
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 662
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 662
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 662
      } ],
      "display_url" : "pic.twitter.com\/3aLuoaMe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298089628727136256",
  "text" : "RT @m_wall: These spam emails from crappy made-up journals are getting worse - this one's 'pear reviewed' apparently. http:\/\/t.co\/3aLuoaMe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/m_wall\/status\/298052014124974084\/photo\/1",
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/3aLuoaMe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BCLkuksCQAI-jRx.jpg",
        "id_str" : "298052014133362690",
        "id" : 298052014133362690,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCLkuksCQAI-jRx.jpg",
        "sizes" : [ {
          "h" : 660,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 662
        } ],
        "display_url" : "pic.twitter.com\/3aLuoaMe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298052014124974084",
    "text" : "These spam emails from crappy made-up journals are getting worse - this one's 'pear reviewed' apparently. http:\/\/t.co\/3aLuoaMe",
    "id" : 298052014124974084,
    "created_at" : "2013-02-03 12:55:12 +0000",
    "user" : {
      "name" : "Matt Wall",
      "screen_name" : "m_wall",
      "protected" : false,
      "id_str" : "155916643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747018860734341120\/dFrakcfP_normal.jpg",
      "id" : 155916643,
      "verified" : false
    }
  },
  "id" : 298089628727136256,
  "created_at" : "2013-02-03 15:24:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/ell8zYGM",
      "expanded_url" : "http:\/\/j.mp\/11DkP2n",
      "display_url" : "j.mp\/11DkP2n"
    } ]
  },
  "geo" : { },
  "id_str" : "298079705427484672",
  "text" : "I can\u2019t tweet without you: How twitter feeds our inner longing for friendship http:\/\/t.co\/ell8zYGM",
  "id" : 298079705427484672,
  "created_at" : "2013-02-03 14:45:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298065181278343169",
  "text" : "Fun with the Fitbit-API: \u00ABI find your lack of weight disturbing\u00BB",
  "id" : 298065181278343169,
  "created_at" : "2013-02-03 13:47:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 14, 22 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "298038543169757185",
  "geo" : { },
  "id_str" : "298038666369052672",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @heyaudy Okay, works for me. :)",
  "id" : 298038666369052672,
  "in_reply_to_status_id" : 298038543169757185,
  "created_at" : "2013-02-03 12:02:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 52, 60 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297870706312622080",
  "geo" : { },
  "id_str" : "298037903806844929",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Is that today as in Sunday for me and @heyaudy and Monday for you?",
  "id" : 298037903806844929,
  "in_reply_to_status_id" : 297870706312622080,
  "created_at" : "2013-02-03 11:59:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/A6grGyZl",
      "expanded_url" : "http:\/\/imgur.com\/wAyBUaK",
      "display_url" : "imgur.com\/wAyBUaK"
    } ]
  },
  "geo" : { },
  "id_str" : "297841608068571136",
  "text" : "More decoration for my office: \u00ABSnailed it!\u00BB http:\/\/t.co\/A6grGyZl",
  "id" : 297841608068571136,
  "created_at" : "2013-02-02 22:59:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/7iwFoGX6",
      "expanded_url" : "http:\/\/i.imgur.com\/HBZiUek.jpg",
      "display_url" : "i.imgur.com\/HBZiUek.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "297833670570565632",
  "text" : "A clear cut case of fraud! http:\/\/t.co\/7iwFoGX6",
  "id" : 297833670570565632,
  "created_at" : "2013-02-02 22:27:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297824479852232705",
  "geo" : { },
  "id_str" : "297825624914006018",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Bestimmt nicht riskanter als mit dir :)",
  "id" : 297825624914006018,
  "in_reply_to_status_id" : 297824479852232705,
  "created_at" : "2013-02-02 21:55:36 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297820596321017856",
  "text" : "\u00ABDas ist ja auch nur eine Quasi-Wiederholung der zweiten Staffel.\u00BB\u2014\u00ABJa, aber diesmal mit Tim Minchin. Und er ist nackt!\u00BB",
  "id" : 297820596321017856,
  "created_at" : "2013-02-02 21:35:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297810543983599617",
  "text" : "Show, don't tell: \u00ABVorsicht, die Messer sind wieder scharf\u00BB sagen und sich dann selbst in den Finger schneiden.",
  "id" : 297810543983599617,
  "created_at" : "2013-02-02 20:55:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 0, 6 ],
      "id_str" : "89234537",
      "id" : 89234537
    }, {
      "name" : "ChaosTom",
      "screen_name" : "chaostom",
      "indices" : [ 40, 49 ],
      "id_str" : "71142746",
      "id" : 71142746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297802504744357888",
  "geo" : { },
  "id_str" : "297803214030508032",
  "in_reply_to_user_id" : 89234537,
  "text" : "@_Rya_ ah, dann nat\u00FCrlich auch danke an @chaostom :)",
  "id" : 297803214030508032,
  "in_reply_to_status_id" : 297802504744357888,
  "created_at" : "2013-02-02 20:26:33 +0000",
  "in_reply_to_screen_name" : "_Rya_",
  "in_reply_to_user_id_str" : "89234537",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rya",
      "screen_name" : "_Rya_",
      "indices" : [ 107, 113 ],
      "id_str" : "89234537",
      "id" : 89234537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297801672275681282",
  "text" : "Beste Anschaffung in letzter Zeit: Bluetooth-Dingsi um alle iOS-Ger\u00E4te an den Stereo-Amp zu koppeln. Danke @_Rya_ f\u00FCr den Tipp!",
  "id" : 297801672275681282,
  "created_at" : "2013-02-02 20:20:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. David Shiffman",
      "screen_name" : "WhySharksMatter",
      "indices" : [ 3, 19 ],
      "id_str" : "66182591",
      "id" : 66182591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sharks",
      "indices" : [ 49, 56 ]
    }, {
      "text" : "TheMeInMedia",
      "indices" : [ 85, 98 ]
    }, {
      "text" : "Scio13",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297791064092327938",
  "text" : "RT @WhySharksMatter: I try to balance my love of #sharks with my hatred of dolphins. #TheMeInMedia #Scio13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sharks",
        "indices" : [ 28, 35 ]
      }, {
        "text" : "TheMeInMedia",
        "indices" : [ 64, 77 ]
      }, {
        "text" : "Scio13",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297765571104227328",
    "text" : "I try to balance my love of #sharks with my hatred of dolphins. #TheMeInMedia #Scio13",
    "id" : 297765571104227328,
    "created_at" : "2013-02-02 17:56:59 +0000",
    "user" : {
      "name" : "Dr. David Shiffman",
      "screen_name" : "WhySharksMatter",
      "protected" : false,
      "id_str" : "66182591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817814996608552960\/jSwEWyxK_normal.jpg",
      "id" : 66182591,
      "verified" : true
    }
  },
  "id" : 297791064092327938,
  "created_at" : "2013-02-02 19:38:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297784241314488320",
  "geo" : { },
  "id_str" : "297784443958067201",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat an intriguing idea :D",
  "id" : 297784443958067201,
  "in_reply_to_status_id" : 297784241314488320,
  "created_at" : "2013-02-02 19:11:58 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297783577960128516",
  "geo" : { },
  "id_str" : "297783798295314432",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat one could extend the \u201Cwings\u201D and let them reach up to the back!",
  "id" : 297783798295314432,
  "in_reply_to_status_id" : 297783577960128516,
  "created_at" : "2013-02-02 19:09:24 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 0, 12 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297782790731223040",
  "geo" : { },
  "id_str" : "297783081543278593",
  "in_reply_to_user_id" : 16066591,
  "text" : "@herr_schrat centered across the chest, right? ;)",
  "id" : 297783081543278593,
  "in_reply_to_status_id" : 297782790731223040,
  "created_at" : "2013-02-02 19:06:33 +0000",
  "in_reply_to_screen_name" : "herr_schrat",
  "in_reply_to_user_id_str" : "16066591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/297781731677843457\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/P2SQ7evu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCHu6EGCMAEp1Yi.jpg",
      "id_str" : "297781731682037761",
      "id" : 297781731682037761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCHu6EGCMAEp1Yi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/P2SQ7evu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297781731677843457",
  "text" : "As Monsters of Grok wouldn\u2019t build it. Now I\u2019m not sure whether this would be better as a t-shirt or as a tattoo. http:\/\/t.co\/P2SQ7evu",
  "id" : 297781731677843457,
  "created_at" : "2013-02-02 19:01:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/wHAH6yo6",
      "expanded_url" : "http:\/\/instagr.am\/p\/VPJ-ZLBwt0\/",
      "display_url" : "instagr.am\/p\/VPJ-ZLBwt0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "297756837879640064",
  "text" : "Bite me! http:\/\/t.co\/wHAH6yo6",
  "id" : 297756837879640064,
  "created_at" : "2013-02-02 17:22:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "indices" : [ 3, 8 ],
      "id_str" : "1769191",
      "id" : 1769191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/lN0aDHZu",
      "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2013\/02\/when-taking-multiple-husbands-makes-sense\/272726\/",
      "display_url" : "theatlantic.com\/health\/archive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297754396874383360",
  "text" : "RT @mims: Polyandry: way more common than anthropologists thought. http:\/\/t.co\/lN0aDHZu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/lN0aDHZu",
        "expanded_url" : "http:\/\/www.theatlantic.com\/health\/archive\/2013\/02\/when-taking-multiple-husbands-makes-sense\/272726\/",
        "display_url" : "theatlantic.com\/health\/archive\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "297753105834065921",
    "text" : "Polyandry: way more common than anthropologists thought. http:\/\/t.co\/lN0aDHZu",
    "id" : 297753105834065921,
    "created_at" : "2013-02-02 17:07:27 +0000",
    "user" : {
      "name" : "Christopher Mims\uD83E\uDD33",
      "screen_name" : "mims",
      "protected" : false,
      "id_str" : "1769191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805781204381351936\/_P3k7Gmn_normal.jpg",
      "id" : 1769191,
      "verified" : true
    }
  },
  "id" : 297754396874383360,
  "created_at" : "2013-02-02 17:12:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "indices" : [ 3, 16 ],
      "id_str" : "189118361",
      "id" : 189118361
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArsenicLife",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/nOjSFaHb",
      "expanded_url" : "http:\/\/wp.me\/p10Fmj-t5",
      "display_url" : "wp.me\/p10Fmj-t5"
    } ]
  },
  "geo" : { },
  "id_str" : "297752107916877824",
  "text" : "RT @MaliciaRogue: #ArsenicLife reviews leaked http:\/\/t.co\/nOjSFaHb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArsenicLife",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/nOjSFaHb",
        "expanded_url" : "http:\/\/wp.me\/p10Fmj-t5",
        "display_url" : "wp.me\/p10Fmj-t5"
      } ]
    },
    "geo" : { },
    "id_str" : "297750358518816768",
    "text" : "#ArsenicLife reviews leaked http:\/\/t.co\/nOjSFaHb",
    "id" : 297750358518816768,
    "created_at" : "2013-02-02 16:56:32 +0000",
    "user" : {
      "name" : "Rayna",
      "screen_name" : "MaliciaRogue",
      "protected" : false,
      "id_str" : "189118361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/837584473843712000\/2Av32bxZ_normal.jpg",
      "id" : 189118361,
      "verified" : true
    }
  },
  "id" : 297752107916877824,
  "created_at" : "2013-02-02 17:03:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297726288184107009",
  "text" : "\u00ABIst das diese Mandoline von dem Herpes-Toten?\u00BB",
  "id" : 297726288184107009,
  "created_at" : "2013-02-02 15:20:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/TuW4uIPd",
      "expanded_url" : "http:\/\/instagr.am\/p\/VO0hQLBwig\/",
      "display_url" : "instagr.am\/p\/VO0hQLBwig\/"
    } ]
  },
  "geo" : { },
  "id_str" : "297709766401216513",
  "text" : "\u00ABDer Kater ist mein Wappentier!\u00BB\u2014\u00ABDu hast recht, er repr\u00E4sentiert dich hervorragend.\u00BB http:\/\/t.co\/TuW4uIPd",
  "id" : 297709766401216513,
  "created_at" : "2013-02-02 14:15:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/6Ottfatj",
      "expanded_url" : "http:\/\/eduardo.intermeta.com.br\/posts\/2013\/1\/25\/how-to-land-a-plane-if-you-are-not-a-pilot#",
      "display_url" : "eduardo.intermeta.com.br\/posts\/2013\/1\/2\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.011513, 8.28298 ]
  },
  "id_str" : "297691870782423040",
  "text" : "Keep that saved in Instapaper for the next flight: How to land an airplane if you are not a pilot http:\/\/t.co\/6Ottfatj",
  "id" : 297691870782423040,
  "created_at" : "2013-02-02 13:04:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297663262135312384",
  "text" : "\u00ABLaufen wir eigentlich richtig?\u00BB\u2014\u00ABKeine Ahnung, ich folge dir.\u00BB\u2014\u00ABDas ist schlecht, ich laufe n\u00E4mlich dir hinterher.\u00BB",
  "id" : 297663262135312384,
  "created_at" : "2013-02-02 11:10:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/xSCiTbF5",
      "expanded_url" : "http:\/\/j.mp\/X1LZyM",
      "display_url" : "j.mp\/X1LZyM"
    } ]
  },
  "geo" : { },
  "id_str" : "297655855158013952",
  "text" : "Temptation at Work: How browsing reddit might benefit your productivity http:\/\/t.co\/xSCiTbF5",
  "id" : 297655855158013952,
  "created_at" : "2013-02-02 10:41:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/6wmdqzq9",
      "expanded_url" : "http:\/\/m.rollingstone.com\/entry\/view\/id\/35274\/pn\/all\/p\/0\/?KSID=6275e521b662c218b8446404f10a4c9b",
      "display_url" : "m.rollingstone.com\/entry\/view\/id\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297654438414397441",
  "text" : "The NRA vs. America http:\/\/t.co\/6wmdqzq9",
  "id" : 297654438414397441,
  "created_at" : "2013-02-02 10:35:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/Prg7mf7D",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2012\/05\/the-perfect-milk-machine\/256423\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "297642652646658048",
  "text" : "Genomic breeding on \u00ABtoday\u2019s fast paced cattle semen market\u00BB http:\/\/t.co\/Prg7mf7D",
  "id" : 297642652646658048,
  "created_at" : "2013-02-02 09:48:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297629570411134976",
  "geo" : { },
  "id_str" : "297629773855850497",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 notfalls wird noch mal geklettert. Einmal ausbrechen erlaubt auch einmal einbrechen, oder? :)",
  "id" : 297629773855850497,
  "in_reply_to_status_id" : 297629570411134976,
  "created_at" : "2013-02-02 08:57:22 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 0, 10 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297628058687516673",
  "geo" : { },
  "id_str" : "297629479470235649",
  "in_reply_to_user_id" : 17988190,
  "text" : "@sparta644 das ist gut. Wir sollten es jetzt auch zum Bahnhof schaffen ;)",
  "id" : 297629479470235649,
  "in_reply_to_status_id" : 297628058687516673,
  "created_at" : "2013-02-02 08:56:12 +0000",
  "in_reply_to_screen_name" : "sparta644",
  "in_reply_to_user_id_str" : "17988190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297618319752708098",
  "geo" : { },
  "id_str" : "297626996320649216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks, sounds like I might like it :)",
  "id" : 297626996320649216,
  "in_reply_to_status_id" : 297618319752708098,
  "created_at" : "2013-02-02 08:46:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297626899209920512",
  "text" : "Und als Fr\u00FChsport erstmal \u00FCber Z\u00E4une klettern. Mannheim will einen einfach nicht gehen lassen.",
  "id" : 297626899209920512,
  "created_at" : "2013-02-02 08:45:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 19, 28 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297513349120409600",
  "geo" : { },
  "id_str" : "297513607304978434",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma ich glaube @Senficon schl\u00E4ft schon ;)",
  "id" : 297513607304978434,
  "in_reply_to_status_id" : 297513349120409600,
  "created_at" : "2013-02-02 01:15:46 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297511441152503808",
  "text" : "Wenn es nicht kalt w\u00E4re k\u00F6nnte ich dem gro\u00DFen Sozialexperiment \u00ABBetrunkene rennen gegen verschlossene Bahnhofst\u00FCren\u00BB stundenlang zuschauen.",
  "id" : 297511441152503808,
  "created_at" : "2013-02-02 01:07:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297482877883523073",
  "geo" : { },
  "id_str" : "297506716638142464",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma okay, stehen vor der 22-34 am Tor. Was nu?",
  "id" : 297506716638142464,
  "in_reply_to_status_id" : 297482877883523073,
  "created_at" : "2013-02-02 00:48:23 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/JYfinA88",
      "expanded_url" : "http:\/\/instagr.am\/p\/VNTtOnhwn_\/",
      "display_url" : "instagr.am\/p\/VNTtOnhwn_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "297497177197015040",
  "text" : "\u00ABDie Kneipe sieht doch gut aus.\u00BB\u2014\u00ABHast du gesehen wer davor parkt?\u00BB http:\/\/t.co\/JYfinA88",
  "id" : 297497177197015040,
  "created_at" : "2013-02-02 00:10:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297482523074781184",
  "geo" : { },
  "id_str" : "297482733880475649",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma alles klar. Wir kommen vor morgen fr\u00FCh hier ja sowieso nicht weg ;)",
  "id" : 297482733880475649,
  "in_reply_to_status_id" : 297482523074781184,
  "created_at" : "2013-02-01 23:13:05 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297481252787851265",
  "geo" : { },
  "id_str" : "297482421757153280",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma und danach zum RZL.",
  "id" : 297482421757153280,
  "in_reply_to_status_id" : 297481252787851265,
  "created_at" : "2013-02-01 23:11:50 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lukas Martini",
      "screen_name" : "lutoma",
      "indices" : [ 0, 7 ],
      "id_str" : "41419667",
      "id" : 41419667
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 8, 17 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Peter Wenz",
      "screen_name" : "sparta644",
      "indices" : [ 93, 103 ],
      "id_str" : "17988190",
      "id" : 17988190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297481252787851265",
  "geo" : { },
  "id_str" : "297482373585575936",
  "in_reply_to_user_id" : 41419667,
  "text" : "@lutoma @Senficon also wir haben gerade unsere Jacken geholt. Wir wollten jetzt noch mit dem @sparta644 einen Drink einnehmen.",
  "id" : 297482373585575936,
  "in_reply_to_status_id" : 297481252787851265,
  "created_at" : "2013-02-01 23:11:39 +0000",
  "in_reply_to_screen_name" : "lutoma",
  "in_reply_to_user_id_str" : "41419667",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297476765402677249",
  "text" : "Und dann rei\u00DFen sich auf einmal drei sternhagelvolle Dropkick Murphys-Fans darum wer dich heute Nacht mit nach Hause nehmen darf...",
  "id" : 297476765402677249,
  "created_at" : "2013-02-01 22:49:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/w85Jhg8r",
      "expanded_url" : "http:\/\/instagr.am\/p\/VNBkOABwga\/",
      "display_url" : "instagr.am\/p\/VNBkOABwga\/"
    } ]
  },
  "geo" : { },
  "id_str" : "297456942945800193",
  "text" : "\u00ABUnd wie war das Konzert?\u00BB http:\/\/t.co\/w85Jhg8r",
  "id" : 297456942945800193,
  "created_at" : "2013-02-01 21:30:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297433929118515200",
  "geo" : { },
  "id_str" : "297434770202300418",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du hast ja auch die Foursquare-Checkins um zu beweisen das du anwesend warst.",
  "id" : 297434770202300418,
  "in_reply_to_status_id" : 297433929118515200,
  "created_at" : "2013-02-01 20:02:29 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/297430299049066496\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/vtDCQ2T1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCCvR_jCAAA_9Rl.jpg",
      "id_str" : "297430299057455104",
      "id" : 297430299057455104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCCvR_jCAAA_9Rl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/vtDCQ2T1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297434022706040833",
  "text" : "RT @wilbanks: Lesson: when a toddler teaches a monkey the central dogma of molecular biology, everyone has a good time. http:\/\/t.co\/vtDCQ2T1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/297430299049066496\/photo\/1",
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/vtDCQ2T1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BCCvR_jCAAA_9Rl.jpg",
        "id_str" : "297430299057455104",
        "id" : 297430299057455104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCCvR_jCAAA_9Rl.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/vtDCQ2T1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297430299049066496",
    "text" : "Lesson: when a toddler teaches a monkey the central dogma of molecular biology, everyone has a good time. http:\/\/t.co\/vtDCQ2T1",
    "id" : 297430299049066496,
    "created_at" : "2013-02-01 19:44:44 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 297434022706040833,
  "created_at" : "2013-02-01 19:59:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297426036738633730",
  "text" : "\u00ABGibt es 'Assange-wei\u00DF' eigentlich schon als Haarfarbe?\u00BB",
  "id" : 297426036738633730,
  "created_at" : "2013-02-01 19:27:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/f9jvtdYv",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/02\/01\/no-asians-cornering-a-ra.html",
      "display_url" : "boingboing.net\/2013\/02\/01\/no-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.466036, 8.520928 ]
  },
  "id_str" : "297414657503809536",
  "text" : "I accidentally racist: \u00ABNo Asians!\u00BB http:\/\/t.co\/f9jvtdYv",
  "id" : 297414657503809536,
  "created_at" : "2013-02-01 18:42:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297394479491596288",
  "text" : "\u00ABof several 100 people who don't have cancer,most would also report depressing emotions &amp; past traumas: this is called the human condition.\u00BB",
  "id" : 297394479491596288,
  "created_at" : "2013-02-01 17:22:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297390471947362305",
  "geo" : { },
  "id_str" : "297390711475666944",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du hast das falsch verstanden: ich erz\u00E4hle semi-plausible Geschichten mit Daten!",
  "id" : 297390711475666944,
  "in_reply_to_status_id" : 297390471947362305,
  "created_at" : "2013-02-01 17:07:25 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297389035104649216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.8727531433, 8.6298892878 ]
  },
  "id_str" : "297390127796342785",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon du nennst es Wettbewerb, ich nenne es Hypothesentest.",
  "id" : 297390127796342785,
  "in_reply_to_status_id" : 297389035104649216,
  "created_at" : "2013-02-01 17:05:06 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/BeHEO5ob",
      "expanded_url" : "http:\/\/j.mp\/Xsy1pv",
      "display_url" : "j.mp\/Xsy1pv"
    } ]
  },
  "geo" : { },
  "id_str" : "297354171689082880",
  "text" : "Teaching after Tenure http:\/\/t.co\/BeHEO5ob",
  "id" : 297354171689082880,
  "created_at" : "2013-02-01 14:42:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297349758316584960",
  "text" : "RT @climagic: Option Mnemonics: tar xzvf = Xtract Ze Vucking Files [said in thick German accent]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/suso.suso.org\/xulu\/Command_Line_Magic\" rel=\"nofollow\"\u003ECLI Magic poster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297349263636185088",
    "text" : "Option Mnemonics: tar xzvf = Xtract Ze Vucking Files [said in thick German accent]",
    "id" : 297349263636185088,
    "created_at" : "2013-02-01 14:22:43 +0000",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535876218\/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 297349758316584960,
  "created_at" : "2013-02-01 14:24:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 3, 17 ],
      "id_str" : "13040652",
      "id" : 13040652
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linguistics",
      "indices" : [ 89, 101 ]
    }, {
      "text" : "funfact",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297342406972538881",
  "text" : "RT @zoonpolitikon: Did you know? Academics have more than 100 words for procrastination. #linguistics #funfact",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "linguistics",
        "indices" : [ 70, 82 ]
      }, {
        "text" : "funfact",
        "indices" : [ 83, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297341866788155392",
    "text" : "Did you know? Academics have more than 100 words for procrastination. #linguistics #funfact",
    "id" : 297341866788155392,
    "created_at" : "2013-02-01 13:53:20 +0000",
    "user" : {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "protected" : false,
      "id_str" : "13040652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/875702734921629697\/1TUbd7IS_normal.jpg",
      "id" : 13040652,
      "verified" : false
    }
  },
  "id" : 297342406972538881,
  "created_at" : "2013-02-01 13:55:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297339442685960192",
  "text" : "\u00ABUnd schlaf nicht mit fremden Frauen w\u00E4hrend ich unterwegs bin.\u00BB \u2013 \u00ABKannst du versuchen das zu sagen ohne dabei in Gel\u00E4chter auszubrechen?\u00BB",
  "id" : 297339442685960192,
  "created_at" : "2013-02-01 13:43:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/90WIsyBF",
      "expanded_url" : "http:\/\/i.imgur.com\/wXPREnB.jpg",
      "display_url" : "i.imgur.com\/wXPREnB.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "297336873678934017",
  "text" : "\u00ABEnglish doesn\u2019t borrow from other languages\u2026\u00BB http:\/\/t.co\/90WIsyBF",
  "id" : 297336873678934017,
  "created_at" : "2013-02-01 13:33:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297330221600874497",
  "geo" : { },
  "id_str" : "297330313154150400",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 Das beste aus ganzen N\u00FCssen :D",
  "id" : 297330313154150400,
  "in_reply_to_status_id" : 297330221600874497,
  "created_at" : "2013-02-01 13:07:25 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/pPILAaXt",
      "expanded_url" : "http:\/\/imgur.com\/RhqFKjU",
      "display_url" : "imgur.com\/RhqFKjU"
    } ]
  },
  "geo" : { },
  "id_str" : "297329429795962881",
  "text" : "Oh, ein Eichh\u00F6rnchen! http:\/\/t.co\/pPILAaXt",
  "id" : 297329429795962881,
  "created_at" : "2013-02-01 13:03:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/reederapp.com\" rel=\"nofollow\"\u003EReeder\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/aOJdQ9tw",
      "expanded_url" : "http:\/\/j.mp\/14uSrme",
      "display_url" : "j.mp\/14uSrme"
    } ]
  },
  "geo" : { },
  "id_str" : "297328779959869440",
  "text" : "\u00ABthe beagle learned to identify the C. difficile toxin by sniffing people or their samples.\u00BB http:\/\/t.co\/aOJdQ9tw",
  "id" : 297328779959869440,
  "created_at" : "2013-02-01 13:01:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297318247127212032",
  "text" : "\u00ABThe beard says homeless, but the pants say Tenure\u00BB",
  "id" : 297318247127212032,
  "created_at" : "2013-02-01 12:19:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297110162697768962",
  "geo" : { },
  "id_str" : "297290054013952000",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy don't know. But it look like an old capillary\/Sanger machine. ;)",
  "id" : 297290054013952000,
  "in_reply_to_status_id" : 297110162697768962,
  "created_at" : "2013-02-01 10:27:26 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]