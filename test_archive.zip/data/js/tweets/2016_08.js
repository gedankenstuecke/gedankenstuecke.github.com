Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771097949799641088\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9PWFISXqJG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrN9biSWYAATmsJ.jpg",
      "id_str" : "771097873224196096",
      "id" : 771097873224196096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrN9biSWYAATmsJ.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/9PWFISXqJG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081275175543, 8.818441558890257 ]
  },
  "id_str" : "771097949799641088",
  "text" : "Only really started reading \u2018The Tolerance Trap\u2019 and already loving it a lot. https:\/\/t.co\/9PWFISXqJG",
  "id" : 771097949799641088,
  "created_at" : "2016-08-31 21:30:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elio Qoshi",
      "screen_name" : "elioqoshi",
      "indices" : [ 89, 99 ],
      "id_str" : "93434375",
      "id" : 93434375
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771034504572043264\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/eIu90SxZvL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNDuEZXEAIYvGj.jpg",
      "id_str" : "771034419943641090",
      "id" : 771034419943641090,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNDuEZXEAIYvGj.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/eIu90SxZvL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080876989459, 8.818499881754391 ]
  },
  "id_str" : "771034504572043264",
  "text" : "Just because we could: the openSNP logo as magnets. Making the most out of the design of @elioqoshi! https:\/\/t.co\/eIu90SxZvL",
  "id" : 771034504572043264,
  "created_at" : "2016-08-31 17:18:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771033979780726784\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/uHYfVgYAih",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrNDObBXEAAlZ53.jpg",
      "id_str" : "771033876261179392",
      "id" : 771033876261179392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrNDObBXEAAlZ53.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/uHYfVgYAih"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06080876989459, 8.818499881754391 ]
  },
  "id_str" : "771033979780726784",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke heute aus der Post gefischt! Danke! 33c3 ist bislang unklar :) https:\/\/t.co\/uHYfVgYAih",
  "id" : 771033979780726784,
  "created_at" : "2016-08-31 17:16:40 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771022284211556352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401399247892, 8.753337627006484 ]
  },
  "id_str" : "771025049163796480",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc well, I assume hypothetical proteins to be gene prediction artefacts until proven innocent ;)",
  "id" : 771025049163796480,
  "in_reply_to_status_id" : 771022284211556352,
  "created_at" : "2016-08-31 16:41:11 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771018213693984768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1070104539861, 8.735749991618782 ]
  },
  "id_str" : "771021397875384321",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc at the end of the day both are more or less equally useless. ;)",
  "id" : 771021397875384321,
  "in_reply_to_status_id" : 771018213693984768,
  "created_at" : "2016-08-31 16:26:40 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771016441831235584\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Rx3gT3xfmj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrMzXbUXgAQt_Ld.jpg",
      "id_str" : "771016438773678084",
      "id" : 771016438773678084,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrMzXbUXgAQt_Ld.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/Rx3gT3xfmj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771016441831235584",
  "text" : "By now Google is as confused as I am with respect to where \"home\" might be. https:\/\/t.co\/Rx3gT3xfmj",
  "id" : 771016441831235584,
  "created_at" : "2016-08-31 16:06:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/771013591713677312\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/IcJeMnBeDI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CrMwwSMWcAEq25h.jpg",
      "id_str" : "771013567285981185",
      "id" : 771013567285981185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CrMwwSMWcAEq25h.jpg",
      "sizes" : [ {
        "h" : 358,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 490
      } ],
      "display_url" : "pic.twitter.com\/IcJeMnBeDI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771013591713677312",
  "text" : "Let me just quickly finally update my Macbook before leaving the office m) https:\/\/t.co\/IcJeMnBeDI",
  "id" : 771013591713677312,
  "created_at" : "2016-08-31 15:55:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Robinson, PhD",
      "screen_name" : "daniellecrobins",
      "indices" : [ 0, 16 ],
      "id_str" : "383289779",
      "id" : 383289779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "771005367199277056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245975510789, 8.627366403062124 ]
  },
  "id_str" : "771005780418068480",
  "in_reply_to_user_id" : 383289779,
  "text" : "@daniellecrobins aww, that\u2019s a cute one!",
  "id" : 771005780418068480,
  "in_reply_to_status_id" : 771005367199277056,
  "created_at" : "2016-08-31 15:24:37 +0000",
  "in_reply_to_screen_name" : "daniellecrobins",
  "in_reply_to_user_id_str" : "383289779",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/PFV0dpfkFR",
      "expanded_url" : "http:\/\/journals.plos.org\/plosbiology\/article?id=10.1371%2Fjournal.pbio.1002547",
      "display_url" : "journals.plos.org\/plosbiology\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771003592467685376",
  "text" : "On Science: \u00ABa whiff of ancient Egypt with pharaohs controlling access to wisdom can permeate the review process\u00BB https:\/\/t.co\/PFV0dpfkFR",
  "id" : 771003592467685376,
  "created_at" : "2016-08-31 15:15:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/770994843921375236\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/SWrOh9bp0s",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CrMfl16XYAAkl2z.jpg",
      "id_str" : "770994696197988352",
      "id" : 770994696197988352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CrMfl16XYAAkl2z.jpg",
      "sizes" : [ {
        "h" : 204,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/SWrOh9bp0s"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 40, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770994843921375236",
  "text" : "Help, so @Protohedgehog and I can go to #opencon, pretty please? https:\/\/t.co\/ERLbKXkt99 https:\/\/t.co\/SWrOh9bp0s",
  "id" : 770994843921375236,
  "created_at" : "2016-08-31 14:41:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/nCydWi2PwS",
      "expanded_url" : "http:\/\/www.reactiongifs.com\/wp-content\/uploads\/2013\/11\/Colin-Farrell-Shrug-In-Bruges.gif",
      "display_url" : "reactiongifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770993599374843904",
  "text" : "when your list of genes of interest turns out to be made up exclusively of \u201Ehypothetical proteins\u201C\u2026 https:\/\/t.co\/nCydWi2PwS",
  "id" : 770993599374843904,
  "created_at" : "2016-08-31 14:36:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Beth \uD83D\uDC3A",
      "screen_name" : "PhdGeek",
      "indices" : [ 0, 8 ],
      "id_str" : "27841081",
      "id" : 27841081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770985375124914177",
  "geo" : { },
  "id_str" : "770992665831833600",
  "in_reply_to_user_id" : 27841081,
  "text" : "@PhdGeek ouch, sorry to hear that! \uD83D\uDE22",
  "id" : 770992665831833600,
  "in_reply_to_status_id" : 770985375124914177,
  "created_at" : "2016-08-31 14:32:30 +0000",
  "in_reply_to_screen_name" : "PhdGeek",
  "in_reply_to_user_id_str" : "27841081",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/xAJvQdPaMU",
      "expanded_url" : "https:\/\/aeon.co\/essays\/the-language-of-the-cockpit-is-technical-obscure-and-irresistibly-romantic",
      "display_url" : "aeon.co\/essays\/the-lan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770991752228573184",
  "text" : "The parlance of pilots https:\/\/t.co\/xAJvQdPaMU",
  "id" : 770991752228573184,
  "created_at" : "2016-08-31 14:28:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/ruCFCNZUPe",
      "expanded_url" : "https:\/\/twitter.com\/erikpelve\/status\/770939076685987842",
      "display_url" : "twitter.com\/erikpelve\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770978026653884416",
  "text" : "\u201CWho was I to spit in the publishers\u2019 punch bowl at the annual industry party?\u201D \uD83D\uDC96 https:\/\/t.co\/ruCFCNZUPe",
  "id" : 770978026653884416,
  "created_at" : "2016-08-31 13:34:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kriszta Berkes",
      "screen_name" : "KrisztaB",
      "indices" : [ 0, 9 ],
      "id_str" : "922402893411561472",
      "id" : 922402893411561472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770969694568386561",
  "geo" : { },
  "id_str" : "770971561771884544",
  "in_reply_to_user_id" : 19334473,
  "text" : "@Krisztab yeah, I heard the same :(",
  "id" : 770971561771884544,
  "in_reply_to_status_id" : 770969694568386561,
  "created_at" : "2016-08-31 13:08:38 +0000",
  "in_reply_to_screen_name" : "kri_keziush",
  "in_reply_to_user_id_str" : "19334473",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/5BHg3a6BD9",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/8\/30\/12699194\/anthony-weiner-sexts-dick-pics-scandal",
      "display_url" : "vox.com\/2016\/8\/30\/1269\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770960110659264512",
  "text" : "I\u2019m so glad we\u2019re getting think pieces on every possible topic, e.g. \u00ABthe rise of dick pics, explained\u00BB https:\/\/t.co\/5BHg3a6BD9",
  "id" : 770960110659264512,
  "created_at" : "2016-08-31 12:23:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "indices" : [ 3, 15 ],
      "id_str" : "1085971416",
      "id" : 1085971416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/tSd65i7uSv",
      "expanded_url" : "http:\/\/fb.me\/1fyfYlBfk",
      "display_url" : "fb.me\/1fyfYlBfk"
    } ]
  },
  "geo" : { },
  "id_str" : "770959366426095617",
  "text" : "RT @ShiriEisner: Saudi women launch Twitter campaign demanding end to male guardianship https:\/\/t.co\/tSd65i7uSv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/tSd65i7uSv",
        "expanded_url" : "http:\/\/fb.me\/1fyfYlBfk",
        "display_url" : "fb.me\/1fyfYlBfk"
      } ]
    },
    "geo" : { },
    "id_str" : "770926599873130497",
    "text" : "Saudi women launch Twitter campaign demanding end to male guardianship https:\/\/t.co\/tSd65i7uSv",
    "id" : 770926599873130497,
    "created_at" : "2016-08-31 10:09:59 +0000",
    "user" : {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "protected" : false,
      "id_str" : "1085971416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3250409823\/637ea88abd3f514ac6a2384f168672f3_normal.jpeg",
      "id" : 1085971416,
      "verified" : false
    }
  },
  "id" : 770959366426095617,
  "created_at" : "2016-08-31 12:20:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/V5HTKCHcgm",
      "expanded_url" : "http:\/\/www.aljazeera.com\/indepth\/inpictures\/2016\/08\/hong-kong-eyes-rooftop-rebels-160817140813258.html",
      "display_url" : "aljazeera.com\/indepth\/inpict\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770891987616694272",
  "text" : "Hong Kong through the eyes of rooftop rebels https:\/\/t.co\/V5HTKCHcgm",
  "id" : 770891987616694272,
  "created_at" : "2016-08-31 07:52:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 3, 13 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/sOCTzS0srb",
      "expanded_url" : "http:\/\/blogs.sciencemag.org\/pipeline\/archives\/2016\/04\/18\/the-myth-of-ethidium-bromide",
      "display_url" : "blogs.sciencemag.org\/pipeline\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770890343638335489",
  "text" : "RT @razibkhan: 'The Myth of Ethidium Bromide https:\/\/t.co\/sOCTzS0srb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/sOCTzS0srb",
        "expanded_url" : "http:\/\/blogs.sciencemag.org\/pipeline\/archives\/2016\/04\/18\/the-myth-of-ethidium-bromide",
        "display_url" : "blogs.sciencemag.org\/pipeline\/archi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770860065578295296",
    "text" : "'The Myth of Ethidium Bromide https:\/\/t.co\/sOCTzS0srb",
    "id" : 770860065578295296,
    "created_at" : "2016-08-31 05:45:36 +0000",
    "user" : {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "protected" : false,
      "id_str" : "35304791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890083843385958400\/YKPy0Uup_normal.jpg",
      "id" : 35304791,
      "verified" : true
    }
  },
  "id" : 770890343638335489,
  "created_at" : "2016-08-31 07:45:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 9, 21 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770850530692247552",
  "geo" : { },
  "id_str" : "770888702033887233",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @helgerausch nm, saw your second tweet too late \uD83D\uDE02",
  "id" : 770888702033887233,
  "in_reply_to_status_id" : 770850530692247552,
  "created_at" : "2016-08-31 07:39:23 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 9, 21 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/EaLsILnUz9",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr\/blob\/master\/app\/helpers\/application_helper.rb",
      "display_url" : "github.com\/openSNP\/snpr\/b\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "770846690924384257",
  "geo" : { },
  "id_str" : "770888524719611904",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy @helgerausch this should be https:\/\/t.co\/EaLsILnUz9 :)",
  "id" : 770888524719611904,
  "in_reply_to_status_id" : 770846690924384257,
  "created_at" : "2016-08-31 07:38:41 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/2B3nwjPmxa",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "770790366949683200",
  "geo" : { },
  "id_str" : "770886514733621248",
  "in_reply_to_user_id" : 14946149,
  "text" : "@andreasklinger haha, yes. had lots of trouble with the flags for this one https:\/\/t.co\/2B3nwjPmxa :D",
  "id" : 770886514733621248,
  "in_reply_to_status_id" : 770790366949683200,
  "created_at" : "2016-08-31 07:30:42 +0000",
  "in_reply_to_screen_name" : "andreasklinger",
  "in_reply_to_user_id_str" : "14946149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/Fafj2248YM",
      "expanded_url" : "https:\/\/twitter.com\/megtirrell\/status\/770773017588817920",
      "display_url" : "twitter.com\/megtirrell\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.16181929972969, 8.671464733787506 ]
  },
  "id_str" : "770880558473805824",
  "text" : "Might consider rebranding to Thanatos by now. https:\/\/t.co\/Fafj2248YM",
  "id" : 770880558473805824,
  "created_at" : "2016-08-31 07:07:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/hBp1OYMK6W",
      "expanded_url" : "https:\/\/twitter.com\/anitaleirfall\/status\/770680147737468928",
      "display_url" : "twitter.com\/anitaleirfall\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06063350917449, 8.818363057925042 ]
  },
  "id_str" : "770872291458711552",
  "text" : "In rats. https:\/\/t.co\/hBp1OYMK6W",
  "id" : 770872291458711552,
  "created_at" : "2016-08-31 06:34:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770764059654365184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06072941884634, 8.818419514883677 ]
  },
  "id_str" : "770764177413697537",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps I\u2019m not sure how it is these days. Used to be the case at least.",
  "id" : 770764177413697537,
  "in_reply_to_status_id" : 770764059654365184,
  "created_at" : "2016-08-30 23:24:34 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770763768678780931",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084460769785, 8.818614408382045 ]
  },
  "id_str" : "770763945590284288",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps I\u2019ll keep an eye out, always nice to see something of other people\u2019s lives. :)",
  "id" : 770763945590284288,
  "in_reply_to_status_id" : 770763768678780931,
  "created_at" : "2016-08-30 23:23:39 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770762416288370688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06077291840914, 8.818618240433379 ]
  },
  "id_str" : "770763419767148545",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps great to see you there :D",
  "id" : 770763419767148545,
  "in_reply_to_status_id" : 770762416288370688,
  "created_at" : "2016-08-30 23:21:34 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086723453014, 8.818525865970399 ]
  },
  "id_str" : "770761225454116864",
  "text" : "\u00ABRandom Acts of Senseless Violence\u00BB does make a great birthday gift for loved ones, right?",
  "id" : 770761225454116864,
  "created_at" : "2016-08-30 23:12:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 3, 17 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "The DLF",
      "screen_name" : "CLIRDLF",
      "indices" : [ 72, 80 ],
      "id_str" : "188811710",
      "id" : 188811710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/xPRgHGZVK8",
      "expanded_url" : "http:\/\/eepurl.com\/cdr42f",
      "display_url" : "eepurl.com\/cdr42f"
    } ]
  },
  "geo" : { },
  "id_str" : "770760701627490305",
  "text" : "RT @CameronNeylon: FORCE2017 Conference Dates and opportunity to attend @CLIRDLF as part of F11\/DLF exchange: https:\/\/t.co\/xPRgHGZVK8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The DLF",
        "screen_name" : "CLIRDLF",
        "indices" : [ 53, 61 ],
        "id_str" : "188811710",
        "id" : 188811710
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/xPRgHGZVK8",
        "expanded_url" : "http:\/\/eepurl.com\/cdr42f",
        "display_url" : "eepurl.com\/cdr42f"
      } ]
    },
    "geo" : { },
    "id_str" : "770729417094012928",
    "text" : "FORCE2017 Conference Dates and opportunity to attend @CLIRDLF as part of F11\/DLF exchange: https:\/\/t.co\/xPRgHGZVK8",
    "id" : 770729417094012928,
    "created_at" : "2016-08-30 21:06:27 +0000",
    "user" : {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "protected" : false,
      "id_str" : "12984852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1766127492\/image1326973990_normal.png",
      "id" : 12984852,
      "verified" : false
    }
  },
  "id" : 770760701627490305,
  "created_at" : "2016-08-30 23:10:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Rosen",
      "screen_name" : "ScienceJulia",
      "indices" : [ 3, 16 ],
      "id_str" : "562585357",
      "id" : 562585357
    }, {
      "name" : "Sci Curious",
      "screen_name" : "scicurious",
      "indices" : [ 37, 48 ],
      "id_str" : "31443503",
      "id" : 31443503
    }, {
      "name" : "Eureka!Lab",
      "screen_name" : "eureka_labs",
      "indices" : [ 55, 67 ],
      "id_str" : "2168860249",
      "id" : 2168860249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womeninSTEM",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770725333930762240",
  "text" : "RT @ScienceJulia: Female scientists: @scicurious &amp; @eureka_labs need your help capturing the diversity &amp; awesomeness of #womeninSTEM! https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sci Curious",
        "screen_name" : "scicurious",
        "indices" : [ 19, 30 ],
        "id_str" : "31443503",
        "id" : 31443503
      }, {
        "name" : "Eureka!Lab",
        "screen_name" : "eureka_labs",
        "indices" : [ 37, 49 ],
        "id_str" : "2168860249",
        "id" : 2168860249
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womeninSTEM",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/nPVn7RI98c",
        "expanded_url" : "https:\/\/www.sciencenewsforstudents.org\/blog\/eureka-lab\/what-does-scientist-look-you",
        "display_url" : "sciencenewsforstudents.org\/blog\/eureka-la\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770669036896071680",
    "text" : "Female scientists: @scicurious &amp; @eureka_labs need your help capturing the diversity &amp; awesomeness of #womeninSTEM! https:\/\/t.co\/nPVn7RI98c",
    "id" : 770669036896071680,
    "created_at" : "2016-08-30 17:06:31 +0000",
    "user" : {
      "name" : "Julia Rosen",
      "screen_name" : "ScienceJulia",
      "protected" : false,
      "id_str" : "562585357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644222448313856000\/lOvPsbfa_normal.jpg",
      "id" : 562585357,
      "verified" : false
    }
  },
  "id" : 770725333930762240,
  "created_at" : "2016-08-30 20:50:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770658444286189569",
  "geo" : { },
  "id_str" : "770659027831427072",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy I don\u2019t wanna know how many papers based on python2.x are wrong due to the float\/integer conversion\u2026",
  "id" : 770659027831427072,
  "in_reply_to_status_id" : 770658444286189569,
  "created_at" : "2016-08-30 16:26:45 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Hoffman",
      "screen_name" : "michaelhoffman",
      "indices" : [ 0, 15 ],
      "id_str" : "14897792",
      "id" : 14897792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770655538535333888",
  "geo" : { },
  "id_str" : "770655785575743492",
  "in_reply_to_user_id" : 14897792,
  "text" : "@michaelhoffman guess it\u2019s better for them if nobody knows that journals are so 19th\/20th century\u2026",
  "id" : 770655785575743492,
  "in_reply_to_status_id" : 770655538535333888,
  "created_at" : "2016-08-30 16:13:52 +0000",
  "in_reply_to_screen_name" : "michaelhoffman",
  "in_reply_to_user_id_str" : "14897792",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Criminal",
      "screen_name" : "CriminalShow",
      "indices" : [ 87, 100 ],
      "id_str" : "2161078082",
      "id" : 2161078082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/p922WqUMW8",
      "expanded_url" : "http:\/\/thisiscriminal.com\/episode-49-the-editor-8-26-2016\/",
      "display_url" : "thisiscriminal.com\/episode-49-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770655509129158656",
  "text" : "Today\u2019s spontaneous crying while driving &amp; listening to a podcast was presented by @CriminalShow \uD83D\uDE2D\uD83D\uDCDA https:\/\/t.co\/p922WqUMW8",
  "id" : 770655509129158656,
  "created_at" : "2016-08-30 16:12:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770654193082335232",
  "geo" : { },
  "id_str" : "770654347738902528",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Protohedgehog that\u2019s why I told him he\u2019s likely to always have a place to sleep in our place \uD83D\uDE02",
  "id" : 770654347738902528,
  "in_reply_to_status_id" : 770654193082335232,
  "created_at" : "2016-08-30 16:08:09 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/rwnFegIAVI",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/770318744459603968",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770652166637912064",
  "text" : "Berlin folks, please give the poor guy a place to sleep for a while. Otherwise he\u2019ll need to migrate to Frankfurt. \uD83D\uDE02 https:\/\/t.co\/rwnFegIAVI",
  "id" : 770652166637912064,
  "created_at" : "2016-08-30 15:59:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 41, 55 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/770651354016673793\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/tYlzh9NyEd",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CrHnD2vW8AErjY9.jpg",
      "id_str" : "770651064676839425",
      "id" : 770651064676839425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CrHnD2vW8AErjY9.jpg",
      "sizes" : [ {
        "h" : 364,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 854
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 854
      } ],
      "display_url" : "pic.twitter.com\/tYlzh9NyEd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770651354016673793",
  "text" : "Who's 2\/3 done with crowdfunding? Right, @Protohedgehog and I. Please help us get to 1.5k https:\/\/t.co\/ERLbKXkt99 https:\/\/t.co\/tYlzh9NyEd",
  "id" : 770651354016673793,
  "created_at" : "2016-08-30 15:56:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 3, 15 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770627531431182336",
  "text" : "RT @froggleston: Hi people who say that social media has no place in science. This is how the future works now. Get used to it. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/hoYr8QQsfd",
        "expanded_url" : "https:\/\/twitter.com\/bug_gwen\/status\/770608786960678912",
        "display_url" : "twitter.com\/bug_gwen\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770610195370119169",
    "text" : "Hi people who say that social media has no place in science. This is how the future works now. Get used to it. https:\/\/t.co\/hoYr8QQsfd",
    "id" : 770610195370119169,
    "created_at" : "2016-08-30 13:12:42 +0000",
    "user" : {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "protected" : false,
      "id_str" : "53893339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742344707469086720\/UP8kTNU-_normal.jpg",
      "id" : 53893339,
      "verified" : false
    }
  },
  "id" : 770627531431182336,
  "created_at" : "2016-08-30 14:21:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Crusoe",
      "screen_name" : "biocrusoe",
      "indices" : [ 0, 10 ],
      "id_str" : "17645638",
      "id" : 17645638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770528322451300353",
  "geo" : { },
  "id_str" : "770607184048685056",
  "in_reply_to_user_id" : 17645638,
  "text" : "@biocrusoe have fun there! \uD83D\uDE0D",
  "id" : 770607184048685056,
  "in_reply_to_status_id" : 770528322451300353,
  "created_at" : "2016-08-30 13:00:44 +0000",
  "in_reply_to_screen_name" : "biocrusoe",
  "in_reply_to_user_id_str" : "17645638",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "MyData2016",
      "screen_name" : "mydata2016",
      "indices" : [ 10, 21 ],
      "id_str" : "809357342588497921",
      "id" : 809357342588497921
    }, {
      "name" : "PersonalData.IO",
      "screen_name" : "PersonalDataIO",
      "indices" : [ 22, 37 ],
      "id_str" : "736639776821018626",
      "id" : 736639776821018626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770519764628275200",
  "geo" : { },
  "id_str" : "770583591592034304",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @mydata2016 @PersonalDataIO all the best!",
  "id" : 770583591592034304,
  "in_reply_to_status_id" : 770519764628275200,
  "created_at" : "2016-08-30 11:26:59 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Pickrell",
      "screen_name" : "joe_pickrell",
      "indices" : [ 0, 13 ],
      "id_str" : "314758565",
      "id" : 314758565
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 83, 91 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770269194902536193",
  "geo" : { },
  "id_str" : "770579728201834496",
  "in_reply_to_user_id" : 314758565,
  "text" : "@joe_pickrell that looks great, is there a way to get the raw data? :) (and thanks @pjacock for the reminder!)",
  "id" : 770579728201834496,
  "in_reply_to_status_id" : 770269194902536193,
  "created_at" : "2016-08-30 11:11:38 +0000",
  "in_reply_to_screen_name" : "joe_pickrell",
  "in_reply_to_user_id_str" : "314758565",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723141124843, 8.62748993094159 ]
  },
  "id_str" : "770573849075314688",
  "text" : "\u00ABI guess it says something about our relationship that we had to look up \u201Caffectionateness\u201D in a dictionary.\u00BB",
  "id" : 770573849075314688,
  "created_at" : "2016-08-30 10:48:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/h5EIndw067",
      "expanded_url" : "https:\/\/en.m.wikipedia.org\/wiki\/World_Passport",
      "display_url" : "en.m.wikipedia.org\/wiki\/World_Pas\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "770567412508979200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17245717155369, 8.627270880254423 ]
  },
  "id_str" : "770567705405652997",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim https:\/\/t.co\/h5EIndw067",
  "id" : 770567705405652997,
  "in_reply_to_status_id" : 770567412508979200,
  "created_at" : "2016-08-30 10:23:52 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.77084575504788, 8.814241988592608 ]
  },
  "id_str" : "770510271412658176",
  "text" : "Seems the border patrol at the Swiss-German border doesn\u2019t accept the world passport. And I know someone who\u2019ll be late in the office.",
  "id" : 770510271412658176,
  "created_at" : "2016-08-30 06:35:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 3, 14 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 68, 84 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 91, 105 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenCon",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "openscience",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770392720313573376",
  "text" : "RT @rchampieux: Making first day post vacay a bit better by helping @gedankenstuecke &amp; @Protohedgehog\nget to #OpenCon #openscience https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 52, 68 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Jon Tennant",
        "screen_name" : "Protohedgehog",
        "indices" : [ 75, 89 ],
        "id_str" : "352650591",
        "id" : 352650591
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenCon",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "openscience",
        "indices" : [ 106, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/KwXYQsyZ2u",
        "expanded_url" : "https:\/\/igg.me\/at\/opencon\/x",
        "display_url" : "igg.me\/at\/opencon\/x"
      } ]
    },
    "geo" : { },
    "id_str" : "770363422068178945",
    "text" : "Making first day post vacay a bit better by helping @gedankenstuecke &amp; @Protohedgehog\nget to #OpenCon #openscience https:\/\/t.co\/KwXYQsyZ2u",
    "id" : 770363422068178945,
    "created_at" : "2016-08-29 20:52:07 +0000",
    "user" : {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "protected" : false,
      "id_str" : "20653310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77507928\/c016m_normal.jpg",
      "id" : 20653310,
      "verified" : false
    }
  },
  "id" : 770392720313573376,
  "created_at" : "2016-08-29 22:48:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Champieux",
      "screen_name" : "rchampieux",
      "indices" : [ 0, 11 ],
      "id_str" : "20653310",
      "id" : 20653310
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 12, 26 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770363422068178945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35911947140482, 8.587652482866194 ]
  },
  "id_str" : "770392711413239808",
  "in_reply_to_user_id" : 20653310,
  "text" : "@rchampieux @Protohedgehog awesome, thanks so much!",
  "id" : 770392711413239808,
  "in_reply_to_status_id" : 770363422068178945,
  "created_at" : "2016-08-29 22:48:30 +0000",
  "in_reply_to_screen_name" : "rchampieux",
  "in_reply_to_user_id_str" : "20653310",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    }, {
      "name" : "Christian Kliesch",
      "screen_name" : "antipattern",
      "indices" : [ 12, 24 ],
      "id_str" : "21827943",
      "id" : 21827943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770311709408002048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925712543215, 8.587596431546283 ]
  },
  "id_str" : "770332950693052416",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen @antipattern let\u2019s see, might be inside the two year consumer law period. It\u2019s not mine that\u2019s dead.",
  "id" : 770332950693052416,
  "in_reply_to_status_id" : 770311709408002048,
  "created_at" : "2016-08-29 18:51:02 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Kliesch",
      "screen_name" : "antipattern",
      "indices" : [ 0, 12 ],
      "id_str" : "21827943",
      "id" : 21827943
    }, {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 13, 24 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770308667505799168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925673814171, 8.587595806473514 ]
  },
  "id_str" : "770310355889381376",
  "in_reply_to_user_id" : 21827943,
  "text" : "@antipattern @plaetzchen that\u2019s exactly what the Genius did before pronouncing the logicboard fubar.",
  "id" : 770310355889381376,
  "in_reply_to_status_id" : 770308667505799168,
  "created_at" : "2016-08-29 17:21:15 +0000",
  "in_reply_to_screen_name" : "antipattern",
  "in_reply_to_user_id_str" : "21827943",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 42, 53 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Ekq6bgYKsn",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/769614650665205761",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "769614650665205761",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3706261197816, 8.53886453008636 ]
  },
  "id_str" : "770284161424916480",
  "in_reply_to_user_id" : 14286491,
  "text" : "It was\/is a burned logic board after all. @plaetzchen. https:\/\/t.co\/Ekq6bgYKsn",
  "id" : 770284161424916480,
  "in_reply_to_status_id" : 769614650665205761,
  "created_at" : "2016-08-29 15:37:09 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770279342878388224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37494870435927, 8.53899845611985 ]
  },
  "id_str" : "770279477876256773",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock yes, totally \uD83D\uDE2D",
  "id" : 770279477876256773,
  "in_reply_to_status_id" : 770279342878388224,
  "created_at" : "2016-08-29 15:18:33 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770256126470393856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.37494536659899, 8.538959085237169 ]
  },
  "id_str" : "770279021548634112",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock but I had the stubs from BNE to MCO. So I must have went to the US. And how I went back is none of their business?",
  "id" : 770279021548634112,
  "in_reply_to_status_id" : 770256126470393856,
  "created_at" : "2016-08-29 15:16:44 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 22, 33 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 91, 105 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770222409421099008",
  "text" : "Thanks to the awesome @LouWoodley we\u2019re 2\/3 done with our crowdsourcing for #opencon. Help @Protohedgehog and me: https:\/\/t.co\/wmnWHMdnMe",
  "id" : 770222409421099008,
  "created_at" : "2016-08-29 11:31:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/vVDfjqwqcY",
      "expanded_url" : "http:\/\/hummushouse.nl\/",
      "display_url" : "hummushouse.nl"
    } ]
  },
  "in_reply_to_status_id_str" : "770219984530370560",
  "geo" : { },
  "id_str" : "770221216997183488",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima https:\/\/t.co\/vVDfjqwqcY",
  "id" : 770221216997183488,
  "in_reply_to_status_id" : 770219984530370560,
  "created_at" : "2016-08-29 11:27:02 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/FhLZ6WjE6X",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BJsGN7cDuSR\/",
      "display_url" : "instagram.com\/p\/BJsGN7cDuSR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "770204276102729728",
  "text" : "Lunchtime #latergram https:\/\/t.co\/FhLZ6WjE6X",
  "id" : 770204276102729728,
  "created_at" : "2016-08-29 10:19:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769905924924407808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925388362279, 8.587593517362443 ]
  },
  "id_str" : "769979761326170114",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABLooking in the cupboard I fear our dinner will have to be Paella Paneer.\u00BB",
  "id" : 769979761326170114,
  "in_reply_to_status_id" : 769905924924407808,
  "created_at" : "2016-08-28 19:27:35 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 15, 26 ],
      "id_str" : "20342875",
      "id" : 20342875
    }, {
      "name" : "Yvonne Nobis",
      "screen_name" : "yvonnenobis",
      "indices" : [ 27, 39 ],
      "id_str" : "18979543",
      "id" : 18979543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769953502122639361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35928690340712, 8.58784863608682 ]
  },
  "id_str" : "769963435622862848",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @LouWoodley @yvonnenobis great!",
  "id" : 769963435622862848,
  "in_reply_to_status_id" : 769953502122639361,
  "created_at" : "2016-08-28 18:22:42 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.72067953743667, 7.443839795894402 ]
  },
  "id_str" : "769905924924407808",
  "text" : "Eating Naan and Paneer at 2000 m above sea in the Swiss Mountains. Things that happen when supermarkets close at 5pm on Saturdays.",
  "id" : 769905924924407808,
  "created_at" : "2016-08-28 14:34:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "indices" : [ 3, 17 ],
      "id_str" : "48966898",
      "id" : 48966898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/WIFb4Qgfec",
      "expanded_url" : "http:\/\/genomespot.blogspot.no\/2016\/08\/my-personal-thoughts-on-gene-name-errors.html?m=1",
      "display_url" : "genomespot.blogspot.no\/2016\/08\/my-per\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769631521854615553",
  "text" : "RT @lexnederbragt: An author of the \u2018excel gene name conversion\u2019 study start sharing some thoughts https:\/\/t.co\/WIFb4Qgfec",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/WIFb4Qgfec",
        "expanded_url" : "http:\/\/genomespot.blogspot.no\/2016\/08\/my-personal-thoughts-on-gene-name-errors.html?m=1",
        "display_url" : "genomespot.blogspot.no\/2016\/08\/my-per\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769630140330573825",
    "text" : "An author of the \u2018excel gene name conversion\u2019 study start sharing some thoughts https:\/\/t.co\/WIFb4Qgfec",
    "id" : 769630140330573825,
    "created_at" : "2016-08-27 20:18:19 +0000",
    "user" : {
      "name" : "Lex Nederbragt",
      "screen_name" : "lexnederbragt",
      "protected" : false,
      "id_str" : "48966898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099225219\/DSC01628a_normal.jpg",
      "id" : 48966898,
      "verified" : false
    }
  },
  "id" : 769631521854615553,
  "created_at" : "2016-08-27 20:23:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/769619753845551105\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/FJKWVKjyJ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq49FenWYAEz22Y.jpg",
      "id_str" : "769619750653681665",
      "id" : 769619750653681665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq49FenWYAEz22Y.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1187,
        "resize" : "fit",
        "w" : 1583
      }, {
        "h" : 1187,
        "resize" : "fit",
        "w" : 1583
      } ],
      "display_url" : "pic.twitter.com\/FJKWVKjyJ3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.957016, 7.443694 ]
  },
  "id_str" : "769619753845551105",
  "text" : "Accidentally ended up being in a lesbian-gay-trans-queer dance walk today. \uD83D\uDC96\uD83C\uDF08 https:\/\/t.co\/FJKWVKjyJ3",
  "id" : 769619753845551105,
  "created_at" : "2016-08-27 19:37:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769616179614875649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.95702269544188, 7.443705529709079 ]
  },
  "id_str" : "769616312381440001",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen okay, did it more than that already :p",
  "id" : 769616312381440001,
  "in_reply_to_status_id" : 769616179614875649,
  "created_at" : "2016-08-27 19:23:22 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769615311943458816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.95697357261519, 7.443742750541156 ]
  },
  "id_str" : "769616029156859908",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen that\u2019s what I feared. How often should I try the SMC reset before I start to look like an idiot?",
  "id" : 769616029156859908,
  "in_reply_to_status_id" : 769615311943458816,
  "created_at" : "2016-08-27 19:22:14 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769615269920641028",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.95703097646597, 7.443747072899776 ]
  },
  "id_str" : "769615879403429888",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice it\u2019s fully charged :(",
  "id" : 769615879403429888,
  "in_reply_to_status_id" : 769615269920641028,
  "created_at" : "2016-08-27 19:21:39 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769614972427141121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.95703577702713, 7.443647713978383 ]
  },
  "id_str" : "769615188035264512",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen it\u2019s fully charged according to the light. Will try doing it over and over again. If that doesn\u2019t help?",
  "id" : 769615188035264512,
  "in_reply_to_status_id" : 769614972427141121,
  "created_at" : "2016-08-27 19:18:54 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 111, 122 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.95707056792369, 7.4435553422987 ]
  },
  "id_str" : "769614650665205761",
  "text" : "If your Macbook won\u2019t turn on and you already tried resetting the SMD, is there anything else you can try? \/cc @plaetzchen",
  "id" : 769614650665205761,
  "created_at" : "2016-08-27 19:16:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 7, 18 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/22NzPK6sJd",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/769527002164563968",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 46.95178924956321, 7.441580203849417 ]
  },
  "id_str" : "769601059773943809",
  "text" : "Thanks @LouWoodley! https:\/\/t.co\/22NzPK6sJd",
  "id" : 769601059773943809,
  "created_at" : "2016-08-27 18:22:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 32, 48 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Lou Woodley",
      "screen_name" : "LouWoodley",
      "indices" : [ 113, 124 ],
      "id_str" : "20342875",
      "id" : 20342875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769601007630319616",
  "text" : "RT @Protohedgehog: An update to @gedankenstuecke and mine's #opencon crowdfunding campaign thanks to the amazing @LouWoodley! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 13, 29 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Lou Woodley",
        "screen_name" : "LouWoodley",
        "indices" : [ 94, 105 ],
        "id_str" : "20342875",
        "id" : 20342875
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 41, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/zKxpGvpZsl",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/updates",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769527002164563968",
    "text" : "An update to @gedankenstuecke and mine's #opencon crowdfunding campaign thanks to the amazing @LouWoodley! https:\/\/t.co\/zKxpGvpZsl",
    "id" : 769527002164563968,
    "created_at" : "2016-08-27 13:28:29 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 769601007630319616,
  "created_at" : "2016-08-27 18:22:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 49, 65 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769501752508964864",
  "text" : "RT @Protohedgehog: Bored this weekend? Check out @gedankenstuecke and mine's #opencon crowdfunding video! It's...fun.. https:\/\/t.co\/Iug7Hto\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 30, 46 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 58, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/Iug7HtoKTH",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education#\/",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769494513886892032",
    "text" : "Bored this weekend? Check out @gedankenstuecke and mine's #opencon crowdfunding video! It's...fun.. https:\/\/t.co\/Iug7HtoKTH",
    "id" : 769494513886892032,
    "created_at" : "2016-08-27 11:19:23 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 769501752508964864,
  "created_at" : "2016-08-27 11:48:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Wang",
      "screen_name" : "pwang",
      "indices" : [ 0, 6 ],
      "id_str" : "8472272",
      "id" : 8472272
    }, {
      "name" : "Cheng H. Lee",
      "screen_name" : "chenghlee",
      "indices" : [ 7, 17 ],
      "id_str" : "199938696",
      "id" : 199938696
    }, {
      "name" : "Helen Zaltzman",
      "screen_name" : "HelenZaltzman",
      "indices" : [ 28, 42 ],
      "id_str" : "20689378",
      "id" : 20689378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769344947900133376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35909210160187, 8.587884892005546 ]
  },
  "id_str" : "769485552445976576",
  "in_reply_to_user_id" : 8472272,
  "text" : "@pwang @chenghlee basically @helenzaltzman with her last podcast episode!",
  "id" : 769485552445976576,
  "in_reply_to_status_id" : 769344947900133376,
  "created_at" : "2016-08-27 10:43:46 +0000",
  "in_reply_to_screen_name" : "pwang",
  "in_reply_to_user_id_str" : "8472272",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gravid Beast",
      "screen_name" : "gravbeast",
      "indices" : [ 0, 10 ],
      "id_str" : "2246380644",
      "id" : 2246380644
    }, {
      "name" : "Cheng H. Lee",
      "screen_name" : "chenghlee",
      "indices" : [ 11, 21 ],
      "id_str" : "199938696",
      "id" : 199938696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769343152314396673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35909210160187, 8.587884892005546 ]
  },
  "id_str" : "769485148614254592",
  "in_reply_to_user_id" : 2246380644,
  "text" : "@gravbeast @chenghlee yeah, the regular tautonyms are nice too. But as this one is hidden between Latin and Greek it took me so long :D",
  "id" : 769485148614254592,
  "in_reply_to_status_id" : 769343152314396673,
  "created_at" : "2016-08-27 10:42:10 +0000",
  "in_reply_to_screen_name" : "gravbeast",
  "in_reply_to_user_id_str" : "2246380644",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769269709887774720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35924913305308, 8.587588821777524 ]
  },
  "id_str" : "769269942755745792",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy nah, they look nice though. Didn\u2019t know about them!",
  "id" : 769269942755745792,
  "in_reply_to_status_id" : 769269709887774720,
  "created_at" : "2016-08-26 20:27:01 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35926203917639, 8.587601019878873 ]
  },
  "id_str" : "769269486914527232",
  "text" : "I\u2019ve been studying biology for 10 years and just today it dawned on me that the scientific name of brown bears translates to \u201Cbear bear\u201D. \uD83D\uDE02",
  "id" : 769269486914527232,
  "created_at" : "2016-08-26 20:25:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769227254748504064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925162062127, 8.587587137754689 ]
  },
  "id_str" : "769244946662584320",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy we got them from stickermule :)",
  "id" : 769244946662584320,
  "in_reply_to_status_id" : 769227254748504064,
  "created_at" : "2016-08-26 18:47:41 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/769190721408622593\/photo\/1",
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/WFYtvCpsZ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqy24iNXgAAEm87.jpg",
      "id_str" : "769190718745313280",
      "id" : 769190718745313280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqy24iNXgAAEm87.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 2569
      }, {
        "h" : 130,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/WFYtvCpsZ3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.360481, 8.547575 ]
  },
  "id_str" : "769190721408622593",
  "text" : "Close enough! https:\/\/t.co\/WFYtvCpsZ3",
  "id" : 769190721408622593,
  "created_at" : "2016-08-26 15:12:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/GmE7Bfuu1I",
      "expanded_url" : "https:\/\/media1.giphy.com\/media\/3b1JW7LxfsAKs\/200.gif",
      "display_url" : "media1.giphy.com\/media\/3b1JW7Lx\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "769184614178881536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36039548185408, 8.54751231149635 ]
  },
  "id_str" : "769185124793651200",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon certainly feels much longer. https:\/\/t.co\/GmE7Bfuu1I",
  "id" : 769185124793651200,
  "in_reply_to_status_id" : 769184614178881536,
  "created_at" : "2016-08-26 14:49:59 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/769181500063551488\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/abmvWUPxu6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyufxMWEAAF-Au.jpg",
      "id_str" : "769181497177804800",
      "id" : 769181497177804800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyufxMWEAAF-Au.jpg",
      "sizes" : [ {
        "h" : 437,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 2264
      } ],
      "display_url" : "pic.twitter.com\/abmvWUPxu6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36036, 8.547493 ]
  },
  "id_str" : "769181500063551488",
  "text" : "All the advice you need. https:\/\/t.co\/abmvWUPxu6",
  "id" : 769181500063551488,
  "created_at" : "2016-08-26 14:35:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis D. Verde",
      "screen_name" : "LuisDVerde",
      "indices" : [ 0, 11 ],
      "id_str" : "238528404",
      "id" : 238528404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769155543000879104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36055593866186, 8.54736314757163 ]
  },
  "id_str" : "769179138116743168",
  "in_reply_to_user_id" : 238528404,
  "text" : "@LuisDVerde will check that later tonight!",
  "id" : 769179138116743168,
  "in_reply_to_status_id" : 769155543000879104,
  "created_at" : "2016-08-26 14:26:11 +0000",
  "in_reply_to_screen_name" : "LuisDVerde",
  "in_reply_to_user_id_str" : "238528404",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769157678056796160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36061817180636, 8.547414762252798 ]
  },
  "id_str" : "769178677095563264",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye I even have the data but I don\u2019t get why I should provide them with that.",
  "id" : 769178677095563264,
  "in_reply_to_status_id" : 769157678056796160,
  "created_at" : "2016-08-26 14:24:21 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "copyfight",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/MARl4PalQt",
      "expanded_url" : "https:\/\/twitter.com\/Senficon\/status\/769165827396427777",
      "display_url" : "twitter.com\/Senficon\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36059512451249, 8.547528662060994 ]
  },
  "id_str" : "769178293509709824",
  "text" : "WTF?! That\u2019s like going 10 years back in time! #copyfight https:\/\/t.co\/MARl4PalQt",
  "id" : 769178293509709824,
  "created_at" : "2016-08-26 14:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769176950258692096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36053694533713, 8.547446073915504 ]
  },
  "id_str" : "769177194841112576",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko yes, wonder what they need these for. I took two flights to\/from and have all the docs for that. Should be good enough.",
  "id" : 769177194841112576,
  "in_reply_to_status_id" : 769176950258692096,
  "created_at" : "2016-08-26 14:18:28 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/ERLbKXC40H",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36042351334948, 8.547448200617538 ]
  },
  "id_str" : "769175575529263105",
  "text" : "Now is your chance to become backer #42 for our trip to DC! \uD83D\uDE02  https:\/\/t.co\/ERLbKXC40H",
  "id" : 769175575529263105,
  "created_at" : "2016-08-26 14:12:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/mC0UJ0ThUD",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BJkvHILj73t\/",
      "display_url" : "instagram.com\/p\/BJkvHILj73t\/"
    } ]
  },
  "geo" : { },
  "id_str" : "769168302790901761",
  "text" : "Writing with a view. https:\/\/t.co\/mC0UJ0ThUD",
  "id" : 769168302790901761,
  "created_at" : "2016-08-26 13:43:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769154505141256192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.36030525066644, 8.568281577908031 ]
  },
  "id_str" : "769155072337018880",
  "in_reply_to_user_id" : 14286491,
  "text" : "But no problem, because luckily the Uni pays me so well that I can easily miss out on 2\/3 of a monthly salary\u2026",
  "id" : 769155072337018880,
  "in_reply_to_status_id" : 769154505141256192,
  "created_at" : "2016-08-26 12:50:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smbe16",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "bosc2016",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3580320366168, 8.572593396537538 ]
  },
  "id_str" : "769154505141256192",
  "text" : "Next level of uni admin nonsense: won\u2019t reimburse me for flights to #smbe16 unless I show \u2708\uFE0F-tickets for #bosc2016 (which they didn\u2019t pay\u2026)",
  "id" : 769154505141256192,
  "created_at" : "2016-08-26 12:48:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis D. Verde",
      "screen_name" : "LuisDVerde",
      "indices" : [ 0, 11 ],
      "id_str" : "238528404",
      "id" : 238528404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769121999885045764",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35891619391775, 8.588028325500687 ]
  },
  "id_str" : "769145656246231044",
  "in_reply_to_user_id" : 238528404,
  "text" : "@LuisDVerde what do you mean exactly?  :)",
  "id" : 769145656246231044,
  "in_reply_to_status_id" : 769121999885045764,
  "created_at" : "2016-08-26 12:13:09 +0000",
  "in_reply_to_screen_name" : "LuisDVerde",
  "in_reply_to_user_id_str" : "238528404",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/gXJIJCDsOh",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/life-as-a-berserker",
      "display_url" : "smbc-comics.com\/comic\/life-as-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769119798815027203",
  "text" : "\u00ABThere\u2019s a study out this year that suggests frenchmen feel pain.\u00BB https:\/\/t.co\/gXJIJCDsOh",
  "id" : 769119798815027203,
  "created_at" : "2016-08-26 10:30:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769116778186338304",
  "geo" : { },
  "id_str" : "769116930376658944",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot let\u2019s see whether I\u2019ll come down from the mountains on my own.",
  "id" : 769116930376658944,
  "in_reply_to_status_id" : 769116778186338304,
  "created_at" : "2016-08-26 10:19:00 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769115703760789505",
  "geo" : { },
  "id_str" : "769116588687650816",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well, so far I never needed any SAR teams for ending my adventures. :p",
  "id" : 769116588687650816,
  "in_reply_to_status_id" : 769115703760789505,
  "created_at" : "2016-08-26 10:17:38 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/g3YkD8BHxK",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/KB3PhU3DhSUIU\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/KB3PhU3D\u2026"
    }, {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/iVWyhVjOCM",
      "expanded_url" : "https:\/\/twitter.com\/SpotOnLondon\/status\/768470441174466564",
      "display_url" : "twitter.com\/SpotOnLondon\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769116339445305344",
  "text" : "That\u2019s an easy one: Peer Review in 2030 https:\/\/t.co\/g3YkD8BHxK https:\/\/t.co\/iVWyhVjOCM",
  "id" : 769116339445305344,
  "created_at" : "2016-08-26 10:16:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769096796639522817",
  "geo" : { },
  "id_str" : "769114256675569664",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot oh humanity\u2026 \uD83C\uDF0B",
  "id" : 769114256675569664,
  "in_reply_to_status_id" : 769096796639522817,
  "created_at" : "2016-08-26 10:08:22 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "indices" : [ 3, 13 ],
      "id_str" : "274388734",
      "id" : 274388734
    }, {
      "name" : "UCL Computer Science",
      "screen_name" : "uclcs",
      "indices" : [ 27, 33 ],
      "id_str" : "244168999",
      "id" : 244168999
    }, {
      "name" : "Old Emiliano DC",
      "screen_name" : "emilianodc_",
      "indices" : [ 83, 95 ],
      "id_str" : "887604728926019585",
      "id" : 887604728926019585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/gXrik9vYOz",
      "expanded_url" : "https:\/\/www.prism.ucl.ac.uk\/#!\/?project=196",
      "display_url" : "prism.ucl.ac.uk\/#!\/?project=196"
    } ]
  },
  "geo" : { },
  "id_str" : "769111630143774720",
  "text" : "RT @cdessimoz: PhD opening @uclcs on privacy-preserving genomic data sharing, with @emilianodc_ &amp; yrs trly. https:\/\/t.co\/gXrik9vYOz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UCL Computer Science",
        "screen_name" : "uclcs",
        "indices" : [ 12, 18 ],
        "id_str" : "244168999",
        "id" : 244168999
      }, {
        "name" : "Old Emiliano DC",
        "screen_name" : "emilianodc_",
        "indices" : [ 68, 80 ],
        "id_str" : "887604728926019585",
        "id" : 887604728926019585
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/gXrik9vYOz",
        "expanded_url" : "https:\/\/www.prism.ucl.ac.uk\/#!\/?project=196",
        "display_url" : "prism.ucl.ac.uk\/#!\/?project=196"
      } ]
    },
    "geo" : { },
    "id_str" : "769075273019035648",
    "text" : "PhD opening @uclcs on privacy-preserving genomic data sharing, with @emilianodc_ &amp; yrs trly. https:\/\/t.co\/gXrik9vYOz",
    "id" : 769075273019035648,
    "created_at" : "2016-08-26 07:33:28 +0000",
    "user" : {
      "name" : "Christophe Dessimoz",
      "screen_name" : "cdessimoz",
      "protected" : false,
      "id_str" : "274388734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1467970873\/photo_normal.png",
      "id" : 274388734,
      "verified" : false
    }
  },
  "id" : 769111630143774720,
  "created_at" : "2016-08-26 09:57:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769108504254803968",
  "geo" : { },
  "id_str" : "769110079861841920",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski sure, though let me check with my host here, it\u2019ll be her birthday after all :p",
  "id" : 769110079861841920,
  "in_reply_to_status_id" : 769108504254803968,
  "created_at" : "2016-08-26 09:51:47 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769108342040064001",
  "geo" : { },
  "id_str" : "769108423694843904",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski yep, staying till Monday\/Tuesday-ish",
  "id" : 769108423694843904,
  "in_reply_to_status_id" : 769108342040064001,
  "created_at" : "2016-08-26 09:45:12 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769052210022023168",
  "geo" : { },
  "id_str" : "769108061562740736",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski I know so many universities who should take that service\u2026",
  "id" : 769108061562740736,
  "in_reply_to_status_id" : 769052210022023168,
  "created_at" : "2016-08-26 09:43:45 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis D. Verde",
      "screen_name" : "LuisDVerde",
      "indices" : [ 0, 11 ],
      "id_str" : "238528404",
      "id" : 238528404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769096440354312192",
  "geo" : { },
  "id_str" : "769096632755421186",
  "in_reply_to_user_id" : 238528404,
  "text" : "@LuisDVerde I think the Python scripts have been equally hacky at the end, so it\u2019s not a big loss. :D",
  "id" : 769096632755421186,
  "in_reply_to_status_id" : 769096440354312192,
  "created_at" : "2016-08-26 08:58:21 +0000",
  "in_reply_to_screen_name" : "LuisDVerde",
  "in_reply_to_user_id_str" : "238528404",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis D. Verde",
      "screen_name" : "LuisDVerde",
      "indices" : [ 0, 11 ],
      "id_str" : "238528404",
      "id" : 238528404
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 12, 25 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769095140367630336",
  "geo" : { },
  "id_str" : "769096113878081537",
  "in_reply_to_user_id" : 238528404,
  "text" : "@LuisDVerde @royalsociety really well done! Love your R snippets as well! So glad to see that I\u2019m not the only one struggling w\/ unicode",
  "id" : 769096113878081537,
  "in_reply_to_status_id" : 769095140367630336,
  "created_at" : "2016-08-26 08:56:17 +0000",
  "in_reply_to_screen_name" : "LuisDVerde",
  "in_reply_to_user_id_str" : "238528404",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 42, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/lG5qwMngy9",
      "expanded_url" : "https:\/\/twitter.com\/LuisDVerde\/status\/769095140367630336",
      "display_url" : "twitter.com\/LuisDVerde\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769095779034226688",
  "text" : "Wow, that\u2019s awesome! Glad to see that the #scienceisglobal tweet data is useful for other people as well! https:\/\/t.co\/lG5qwMngy9",
  "id" : 769095779034226688,
  "created_at" : "2016-08-26 08:54:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/tQkMRaMTex",
      "expanded_url" : "https:\/\/media3.giphy.com\/media\/8I7a41uPPoFSU\/200.gif",
      "display_url" : "media3.giphy.com\/media\/8I7a41uP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769093833762177024",
  "text" : "\u00ABI think I\u2019m really in love with you now. I even like the weird face you make when brushing your teeth!\u00BB https:\/\/t.co\/tQkMRaMTex",
  "id" : 769093833762177024,
  "created_at" : "2016-08-26 08:47:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michela Vignoli",
      "screen_name" : "iea_ioi",
      "indices" : [ 0, 8 ],
      "id_str" : "1577597316",
      "id" : 1577597316
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769088106356150272",
  "geo" : { },
  "id_str" : "769088292310622208",
  "in_reply_to_user_id" : 1577597316,
  "text" : "@iea_ioi @Protohedgehog Thanks so much for your kind support!",
  "id" : 769088292310622208,
  "in_reply_to_status_id" : 769088106356150272,
  "created_at" : "2016-08-26 08:25:12 +0000",
  "in_reply_to_screen_name" : "iea_ioi",
  "in_reply_to_user_id_str" : "1577597316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Hk0tFHJn4i",
      "expanded_url" : "https:\/\/twitter.com\/DVDGC13\/status\/769074764166098945",
      "display_url" : "twitter.com\/DVDGC13\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769075681829486596",
  "text" : "It\u2019s nice when for once you\u2019re not being show-cased around as a bad example. \uD83D\uDE02 https:\/\/t.co\/Hk0tFHJn4i",
  "id" : 769075681829486596,
  "created_at" : "2016-08-26 07:35:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mechanical turkey",
      "screen_name" : "alicegoldfuss",
      "indices" : [ 3, 17 ],
      "id_str" : "163154809",
      "id" : 163154809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769042563756089344",
  "text" : "RT @alicegoldfuss: LET'S KICK OFF THIS LINUX BIRTHDAY PARTY WITH SOME MUSIC!\nI'll just--hmm\nare the speakers plugged in?\nyes I pushed play\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768822193736200192",
    "text" : "LET'S KICK OFF THIS LINUX BIRTHDAY PARTY WITH SOME MUSIC!\nI'll just--hmm\nare the speakers plugged in?\nyes I pushed play\nI guess...reboot?",
    "id" : 768822193736200192,
    "created_at" : "2016-08-25 14:47:49 +0000",
    "user" : {
      "name" : "mechanical turkey",
      "screen_name" : "alicegoldfuss",
      "protected" : false,
      "id_str" : "163154809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/914596365933584384\/j9BzPOgm_normal.jpg",
      "id" : 163154809,
      "verified" : false
    }
  },
  "id" : 769042563756089344,
  "created_at" : "2016-08-26 05:23:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DVD",
      "screen_name" : "DVDGC13",
      "indices" : [ 0, 8 ],
      "id_str" : "36380741",
      "id" : 36380741
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 9, 18 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 19, 27 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768823196216913921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35814473130494, 8.571446500726577 ]
  },
  "id_str" : "768823531211726848",
  "in_reply_to_user_id" : 36380741,
  "text" : "@DVDGC13 @abbycabs @betatim the secrets were CC-BY all the time. But well hidden in one of the thousand Gitters\/Slacks\/Mattermosts\/Etherpads",
  "id" : 768823531211726848,
  "in_reply_to_status_id" : 768823196216913921,
  "created_at" : "2016-08-25 14:53:08 +0000",
  "in_reply_to_screen_name" : "DVDGC13",
  "in_reply_to_user_id_str" : "36380741",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "DVD",
      "screen_name" : "DVDGC13",
      "indices" : [ 10, 18 ],
      "id_str" : "36380741",
      "id" : 36380741
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 19, 27 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768822630086565888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35803998599989, 8.571796859843362 ]
  },
  "id_str" : "768822922802847744",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @DVDGC13 @betatim is this one of the ancient mozfest rules?",
  "id" : 768822922802847744,
  "in_reply_to_status_id" : 768822630086565888,
  "created_at" : "2016-08-25 14:50:43 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 0, 8 ],
      "id_str" : "18881614",
      "id" : 18881614
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 9, 18 ],
      "id_str" : "395367768",
      "id" : 395367768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768810776891101184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925196576874, 8.587581282110255 ]
  },
  "id_str" : "768813141929197568",
  "in_reply_to_user_id" : 18881614,
  "text" : "@betatim @abbycabs booh! But I will be back in Z\u00FCrich either sun evening or Monday. Will leave town over the WE, but that could work!",
  "id" : 768813141929197568,
  "in_reply_to_status_id" : 768810776891101184,
  "created_at" : "2016-08-25 14:11:51 +0000",
  "in_reply_to_screen_name" : "betatim",
  "in_reply_to_user_id_str" : "18881614",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 10, 18 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768807843382321153",
  "geo" : { },
  "id_str" : "768808291602460672",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @betatim yeah, and guess otherwise it\u2019ll be mozfest. :D",
  "id" : 768808291602460672,
  "in_reply_to_status_id" : 768807843382321153,
  "created_at" : "2016-08-25 13:52:35 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 10, 18 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768807476783374336",
  "geo" : { },
  "id_str" : "768807612322287616",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs @betatim snap, will be in Switzerland until incl. Monday.",
  "id" : 768807612322287616,
  "in_reply_to_status_id" : 768807476783374336,
  "created_at" : "2016-08-25 13:49:53 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 0, 9 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Tim Head",
      "screen_name" : "betatim",
      "indices" : [ 115, 123 ],
      "id_str" : "18881614",
      "id" : 18881614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768806744822804480",
  "geo" : { },
  "id_str" : "768807111233011712",
  "in_reply_to_user_id" : 395367768,
  "text" : "@abbycabs by the way: how long will ya be around in Europe? Seems I\u2019m missing out not only on meeting you but also @betatim!",
  "id" : 768807111233011712,
  "in_reply_to_status_id" : 768806744822804480,
  "created_at" : "2016-08-25 13:47:53 +0000",
  "in_reply_to_screen_name" : "abbycabs",
  "in_reply_to_user_id_str" : "395367768",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 10, 25 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 26, 35 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768805313147437056",
  "text" : "@quominus @EmilyGorcenski @podehaye life goal: making Erd\u0151s look settled down.",
  "id" : 768805313147437056,
  "created_at" : "2016-08-25 13:40:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OBF News",
      "screen_name" : "obf_news",
      "indices" : [ 79, 88 ],
      "id_str" : "20624794",
      "id" : 20624794
    }, {
      "name" : "Abby Cabunoc Mayes",
      "screen_name" : "abbycabs",
      "indices" : [ 95, 104 ],
      "id_str" : "395367768",
      "id" : 395367768
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 105, 120 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/r8i3R2VG1o",
      "expanded_url" : "https:\/\/opensnp.wordpress.com\/2016\/08\/24\/google-summer-of-code-wrap-up\/",
      "display_url" : "opensnp.wordpress.com\/2016\/08\/24\/goo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768801039403347968",
  "text" : "What the Google Summer of Code students did on openSNP. With big shout-outs to @obf_news &amp; @abbycabs\/@MozillaScience https:\/\/t.co\/r8i3R2VG1o",
  "id" : 768801039403347968,
  "created_at" : "2016-08-25 13:23:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/RAjc8Jtjmq",
      "expanded_url" : "https:\/\/twitter.com\/kjhealy\/status\/768438103048593410",
      "display_url" : "twitter.com\/kjhealy\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768800614449111045",
  "text" : "\u00ABUltimately, when someone asks, \u201CWhy haven\u2019t we cured cancer yet?\u201D the answer is \u201CBecause it\u2019s hard\u201D.\u00BB https:\/\/t.co\/RAjc8Jtjmq",
  "id" : 768800614449111045,
  "created_at" : "2016-08-25 13:22:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/6Sf0PFwLAw",
      "expanded_url" : "http:\/\/english.stackexchange.com\/questions\/35006\/how-should-one-say-times-aloud-in-24-hour-notation",
      "display_url" : "english.stackexchange.com\/questions\/3500\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768795087023243265",
  "text" : "\u00ABThere is no reason you cannot say \"fifteen o'clock,\" except when it's not 15:00\u00BB https:\/\/t.co\/6Sf0PFwLAw",
  "id" : 768795087023243265,
  "created_at" : "2016-08-25 13:00:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 16, 25 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 26, 35 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768785348646301696",
  "geo" : { },
  "id_str" : "768786536645136384",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski @quominus @podehaye similar here, think I spend &lt;10 nights at home since end of June.",
  "id" : 768786536645136384,
  "in_reply_to_status_id" : 768785348646301696,
  "created_at" : "2016-08-25 12:26:08 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768784189890162688",
  "geo" : { },
  "id_str" : "768785135764463616",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog that\u2019s what less -S is for on my end. But tastes are different for viewing data. :)",
  "id" : 768785135764463616,
  "in_reply_to_status_id" : 768784189890162688,
  "created_at" : "2016-08-25 12:20:34 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768783441345310721",
  "geo" : { },
  "id_str" : "768784000957706240",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog yes, absolutely not for everyone. But if you already know the CLI it\u2019s one of the best ways imho :)",
  "id" : 768784000957706240,
  "in_reply_to_status_id" : 768783441345310721,
  "created_at" : "2016-08-25 12:16:03 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 10, 25 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 26, 35 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768783697608839168",
  "text" : "@quominus @EmilyGorcenski @podehaye looks like a cargo-cult version of science to me. Trying to imitate the rituals w\/o understanding.",
  "id" : 768783697608839168,
  "created_at" : "2016-08-25 12:14:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/XNLV0gpU7N",
      "expanded_url" : "https:\/\/github.com\/dilshod\/xlsx2csv",
      "display_url" : "github.com\/dilshod\/xlsx2c\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "768782489708011524",
  "geo" : { },
  "id_str" : "768782906500247552",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko and xlsx2csv | csvkit could help :) https:\/\/t.co\/XNLV0gpU7N",
  "id" : 768782906500247552,
  "in_reply_to_status_id" : 768782489708011524,
  "created_at" : "2016-08-25 12:11:42 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768782489708011524",
  "geo" : { },
  "id_str" : "768782676283318272",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko but then you sometimes want all columns but limit your grep to a single one, great for that.",
  "id" : 768782676283318272,
  "in_reply_to_status_id" : 768782489708011524,
  "created_at" : "2016-08-25 12:10:47 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768781347527749632",
  "geo" : { },
  "id_str" : "768781851389485056",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko i love the column-wise grep capabilities.",
  "id" : 768781851389485056,
  "in_reply_to_status_id" : 768781347527749632,
  "created_at" : "2016-08-25 12:07:31 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 0, 14 ],
      "id_str" : "923639552874557440",
      "id" : 923639552874557440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/k5bROOUxQc",
      "expanded_url" : "https:\/\/csvkit.readthedocs.io\/en\/0.9.1\/",
      "display_url" : "csvkit.readthedocs.io\/en\/0.9.1\/"
    } ]
  },
  "in_reply_to_status_id_str" : "768775081610846208",
  "geo" : { },
  "id_str" : "768780212393877504",
  "in_reply_to_user_id" : 20444825,
  "text" : "@genetics_blog https:\/\/t.co\/k5bROOUxQc",
  "id" : 768780212393877504,
  "in_reply_to_status_id" : 768775081610846208,
  "created_at" : "2016-08-25 12:01:00 +0000",
  "in_reply_to_screen_name" : "strnr",
  "in_reply_to_user_id_str" : "20444825",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 7, 23 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768775764422561792",
  "geo" : { },
  "id_str" : "768776030060421121",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @keyboardpipette cheers! \uD83C\uDF7B\uD83D\uDE02",
  "id" : 768776030060421121,
  "in_reply_to_status_id" : 768775764422561792,
  "created_at" : "2016-08-25 11:44:23 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 7, 23 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/wLjvME1XT4",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Breathalyzer",
      "display_url" : "en.wikipedia.org\/wiki\/Breathaly\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "768728879880101888",
  "geo" : { },
  "id_str" : "768773696307748868",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @keyboardpipette i didn\u2019t know that being asthmatic means you should drink and drive! https:\/\/t.co\/wLjvME1XT4",
  "id" : 768773696307748868,
  "in_reply_to_status_id" : 768728879880101888,
  "created_at" : "2016-08-25 11:35:06 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 0, 15 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 16, 25 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 26, 35 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768767003897237505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925638238166, 8.587588777461967 ]
  },
  "id_str" : "768767234747592704",
  "in_reply_to_user_id" : 1483064670,
  "text" : "@EmilyGorcenski @podehaye @quominus I guess the Uni Aarhus will be thrilled to see the affiliation.",
  "id" : 768767234747592704,
  "in_reply_to_status_id" : 768767003897237505,
  "created_at" : "2016-08-25 11:09:26 +0000",
  "in_reply_to_screen_name" : "EmilyGorcenski",
  "in_reply_to_user_id_str" : "1483064670",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 0, 9 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 10, 19 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 20, 35 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/udyIP0uyrM",
      "expanded_url" : "http:\/\/rationalwiki.org\/wiki\/John_Fuerst",
      "display_url" : "rationalwiki.org\/wiki\/John_Fuer\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "768734196361748480",
  "geo" : { },
  "id_str" : "768734489958871040",
  "in_reply_to_user_id" : 2219841242,
  "text" : "@podehaye @quominus @EmilyGorcenski didn\u2019t know him before, but I see https:\/\/t.co\/udyIP0uyrM",
  "id" : 768734489958871040,
  "in_reply_to_status_id" : 768734196361748480,
  "created_at" : "2016-08-25 08:59:19 +0000",
  "in_reply_to_screen_name" : "podehaye",
  "in_reply_to_user_id_str" : "2219841242",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mack eubanks",
      "screen_name" : "quominus",
      "indices" : [ 0, 9 ],
      "id_str" : "817667268096262146",
      "id" : 817667268096262146
    }, {
      "name" : "Paul-Olivier Dehaye",
      "screen_name" : "podehaye",
      "indices" : [ 10, 19 ],
      "id_str" : "2219841242",
      "id" : 2219841242
    }, {
      "name" : "Emily G, Cville.",
      "screen_name" : "EmilyGorcenski",
      "indices" : [ 20, 35 ],
      "id_str" : "1483064670",
      "id" : 1483064670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/31srMkbsCE",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2016\/05\/27\/055681",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768733085852659712",
  "text" : "@quominus @podehaye @EmilyGorcenski did you see this nonsense by one of our fav authors? https:\/\/t.co\/31srMkbsCE",
  "id" : 768733085852659712,
  "created_at" : "2016-08-25 08:53:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/qMoyAXLYva",
      "expanded_url" : "http:\/\/biorxiv.org\/content\/early\/2016\/08\/24\/071282",
      "display_url" : "biorxiv.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768730151140073474",
  "text" : "Oh, the Canu preprint is now on bioRxiv! https:\/\/t.co\/qMoyAXLYva",
  "id" : 768730151140073474,
  "created_at" : "2016-08-25 08:42:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Star Squires",
      "screen_name" : "StarDeSoul",
      "indices" : [ 0, 11 ],
      "id_str" : "261324132",
      "id" : 261324132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768528415863349248",
  "geo" : { },
  "id_str" : "768721033218129920",
  "in_reply_to_user_id" : 261324132,
  "text" : "@StarDeSoul that\u2019s great!",
  "id" : 768721033218129920,
  "in_reply_to_status_id" : 768528415863349248,
  "created_at" : "2016-08-25 08:05:51 +0000",
  "in_reply_to_screen_name" : "StarDeSoul",
  "in_reply_to_user_id_str" : "261324132",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768719872943534080",
  "geo" : { },
  "id_str" : "768720186673364992",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen thanks! \uD83D\uDE0D\uD83C\uDF0E",
  "id" : 768720186673364992,
  "in_reply_to_status_id" : 768719872943534080,
  "created_at" : "2016-08-25 08:02:29 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 17, 31 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/768712076835561472\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/MF4kvdAvmU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqsDjqcWEAAkX08.jpg",
      "id_str" : "768712072620281856",
      "id" : 768712072620281856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqsDjqcWEAAkX08.jpg",
      "sizes" : [ {
        "h" : 473,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/MF4kvdAvmU"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768712076835561472",
  "text" : "Help with flying @Protohedgehog &amp; me to #opencon. Otherwise we will need to go like this. https:\/\/t.co\/ERLbKXkt99 https:\/\/t.co\/MF4kvdAvmU",
  "id" : 768712076835561472,
  "created_at" : "2016-08-25 07:30:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768688508353454080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35923632083645, 8.587631898723124 ]
  },
  "id_str" : "768689126598115328",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon \uD83D\uDC31",
  "id" : 768689126598115328,
  "in_reply_to_status_id" : 768688508353454080,
  "created_at" : "2016-08-25 05:59:03 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/rBTfN8Z30J",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/photo-credit-negatives-bauhaus\/",
      "display_url" : "99percentinvisible.org\/episode\/photo-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 48.663396, 8.962409 ]
  },
  "id_str" : "768472327822667776",
  "text" : "Guess when copyright didn't \"protect\" the artist: when a women would have profited from it\u2026  https:\/\/t.co\/rBTfN8Z30J",
  "id" : 768472327822667776,
  "created_at" : "2016-08-24 15:37:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/xvKbCRJZNv",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/why-do-hackers-love-beards-so-much",
      "display_url" : "atlasobscura.com\/articles\/why-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768425975499649025",
  "text" : "\u00ABthe hormonal playing field has leveled for women as the hairless and the hoodied\u00BB m( https:\/\/t.co\/xvKbCRJZNv",
  "id" : 768425975499649025,
  "created_at" : "2016-08-24 12:33:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/MFRYHuPp74",
      "expanded_url" : "http:\/\/26.media.tumblr.com\/tumblr_m20e611it81qzt4vjo1_500.gif",
      "display_url" : "26.media.tumblr.com\/tumblr_m20e611\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768424092936577024",
  "text" : "Citation hunting\u2026 https:\/\/t.co\/MFRYHuPp74",
  "id" : 768424092936577024,
  "created_at" : "2016-08-24 12:25:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768385679600525312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17234212553328, 8.627522757634008 ]
  },
  "id_str" : "768418195531235328",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I might need those back in that case.",
  "id" : 768418195531235328,
  "in_reply_to_status_id" : 768385679600525312,
  "created_at" : "2016-08-24 12:02:28 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768383369621143552",
  "text" : "TIL: There\u2019s a bioinformatics tool called \u201EHHblits\u201C and it was developed in Germany. m(",
  "id" : 768383369621143552,
  "created_at" : "2016-08-24 09:44:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768230034037436417",
  "text" : "RT @JBYoder: (I may or may not have a mentor who suggests replying to this sort of shit with \u201CThat\u2019s DOCTOR Faggot to you, kid.\u201D) https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/K3M3dU3oDR",
        "expanded_url" : "https:\/\/twitter.com\/e__mendenhall\/status\/768152660478455808",
        "display_url" : "twitter.com\/e__mendenhall\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768177759205982208",
    "text" : "(I may or may not have a mentor who suggests replying to this sort of shit with \u201CThat\u2019s DOCTOR Faggot to you, kid.\u201D) https:\/\/t.co\/K3M3dU3oDR",
    "id" : 768177759205982208,
    "created_at" : "2016-08-23 20:07:04 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 768230034037436417,
  "created_at" : "2016-08-23 23:34:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mendenhall",
      "screen_name" : "e__mendenhall",
      "indices" : [ 3, 17 ],
      "id_str" : "386521020",
      "id" : 386521020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768230021437808640",
  "text" : "RT @e__mendenhall: I don't condone use of that term, &amp; it has no bearing on my ability to teach you genetics @g_ake68. See you Thursday htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/e__mendenhall\/status\/768152660478455808\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/NzoK1ax3at",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqkE3urWEAANEnm.jpg",
        "id_str" : "768150566912528384",
        "id" : 768150566912528384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqkE3urWEAANEnm.jpg",
        "sizes" : [ {
          "h" : 154,
          "resize" : "fit",
          "w" : 603
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 603
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 603
        }, {
          "h" : 154,
          "resize" : "fit",
          "w" : 603
        } ],
        "display_url" : "pic.twitter.com\/NzoK1ax3at"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768152660478455808",
    "text" : "I don't condone use of that term, &amp; it has no bearing on my ability to teach you genetics @g_ake68. See you Thursday https:\/\/t.co\/NzoK1ax3at",
    "id" : 768152660478455808,
    "created_at" : "2016-08-23 18:27:20 +0000",
    "user" : {
      "name" : "Eric Mendenhall",
      "screen_name" : "e__mendenhall",
      "protected" : false,
      "id_str" : "386521020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419293065052819457\/6npbIFMv_normal.jpeg",
      "id" : 386521020,
      "verified" : false
    }
  },
  "id" : 768230021437808640,
  "created_at" : "2016-08-23 23:34:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/6IGp3gAAq1",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BJdxbF7DQBg\/",
      "display_url" : "instagram.com\/p\/BJdxbF7DQBg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "768188224279760897",
  "text" : "\u00ABI fear I might have accidentally built myself a Buddy Holly remembrance necklace\u00BB I'll be big\u2026 https:\/\/t.co\/6IGp3gAAq1",
  "id" : 768188224279760897,
  "created_at" : "2016-08-23 20:48:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/YhlzqNeA5m",
      "expanded_url" : "https:\/\/twitter.com\/wilbanks\/status\/768071008301481988",
      "display_url" : "twitter.com\/wilbanks\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.05378098691598, 8.746378994120844 ]
  },
  "id_str" : "768130055637696514",
  "text" : "To be fair, I do like my content like my bar: open. https:\/\/t.co\/YhlzqNeA5m",
  "id" : 768130055637696514,
  "created_at" : "2016-08-23 16:57:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768112347563122688",
  "text" : "Citing Lynn Margulis to establish Beatrix Potter as a co-founder of lichenology. That\u2019s how you do it, right? \uD83D\uDE0E",
  "id" : 768112347563122688,
  "created_at" : "2016-08-23 15:47:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 3, 13 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 81, 97 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 98, 112 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/n6C0ispRGG",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/1861431",
      "display_url" : "indiegogo.com\/projects\/18614\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768095049494228992",
  "text" : "RT @auremoser: 'Help Bastian + Jon get to OpenCon!' +1 for the Jon\/Con rhyme! cc\/@gedankenstuecke @Protohedgehog https:\/\/t.co\/n6C0ispRGG vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 66, 82 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Jon Tennant",
        "screen_name" : "Protohedgehog",
        "indices" : [ 83, 97 ],
        "id_str" : "352650591",
        "id" : 352650591
      }, {
        "name" : "Indiegogo",
        "screen_name" : "Indiegogo",
        "indices" : [ 126, 136 ],
        "id_str" : "34732474",
        "id" : 34732474
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/n6C0ispRGG",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/1861431",
        "display_url" : "indiegogo.com\/projects\/18614\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768094029837963265",
    "text" : "'Help Bastian + Jon get to OpenCon!' +1 for the Jon\/Con rhyme! cc\/@gedankenstuecke @Protohedgehog https:\/\/t.co\/n6C0ispRGG via @indiegogo",
    "id" : 768094029837963265,
    "created_at" : "2016-08-23 14:34:21 +0000",
    "user" : {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "protected" : false,
      "id_str" : "186529934",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723868643688325122\/AHwUDHy3_normal.jpg",
      "id" : 186529934,
      "verified" : false
    }
  },
  "id" : 768095049494228992,
  "created_at" : "2016-08-23 14:38:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 26, 36 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768094029837963265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17252944571472, 8.627552582848532 ]
  },
  "id_str" : "768095042032508928",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser @Protohedgehog @Indiegogo glad you like it. I feared no one would appreciate it!",
  "id" : 768095042032508928,
  "in_reply_to_status_id" : 768094029837963265,
  "created_at" : "2016-08-23 14:38:23 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 38, 50 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Bz0KCVM3zO",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Tsujigiri",
      "display_url" : "en.wikipedia.org\/wiki\/Tsujigiri"
    } ]
  },
  "geo" : { },
  "id_str" : "768091504015450112",
  "text" : "After knowing what the GH-username of @helgerausch means I\u2019m a tiny bit worried about him making everyone do tests \uD83D\uDE31 https:\/\/t.co\/Bz0KCVM3zO",
  "id" : 768091504015450112,
  "created_at" : "2016-08-23 14:24:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC9A Aure Moser \uD83D\uDC9A",
      "screen_name" : "auremoser",
      "indices" : [ 0, 10 ],
      "id_str" : "186529934",
      "id" : 186529934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768090748499664896",
  "in_reply_to_user_id" : 186529934,
  "text" : "@auremoser thanks for your support! \uD83C\uDF89\uD83C\uDF88",
  "id" : 768090748499664896,
  "created_at" : "2016-08-23 14:21:19 +0000",
  "in_reply_to_screen_name" : "auremoser",
  "in_reply_to_user_id_str" : "186529934",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tess Rinearson",
      "screen_name" : "_tessr",
      "indices" : [ 3, 10 ],
      "id_str" : "107837944",
      "id" : 107837944
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/_tessr\/status\/766483909970231299\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/FuHP6MzCHM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqMZDRgVUAAb75Y.jpg",
      "id_str" : "766483905612435456",
      "id" : 766483905612435456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqMZDRgVUAAb75Y.jpg",
      "sizes" : [ {
        "h" : 328,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/FuHP6MzCHM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768089965704216576",
  "text" : "RT @_tessr: gender in the age of twitter https:\/\/t.co\/FuHP6MzCHM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/_tessr\/status\/766483909970231299\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/FuHP6MzCHM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqMZDRgVUAAb75Y.jpg",
        "id_str" : "766483905612435456",
        "id" : 766483905612435456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqMZDRgVUAAb75Y.jpg",
        "sizes" : [ {
          "h" : 328,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/FuHP6MzCHM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766483909970231299",
    "text" : "gender in the age of twitter https:\/\/t.co\/FuHP6MzCHM",
    "id" : 766483909970231299,
    "created_at" : "2016-08-19 03:56:19 +0000",
    "user" : {
      "name" : "Tess Rinearson",
      "screen_name" : "_tessr",
      "protected" : false,
      "id_str" : "107837944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799412813747798016\/I9UloZ44_normal.jpg",
      "id" : 107837944,
      "verified" : true
    }
  },
  "id" : 768089965704216576,
  "created_at" : "2016-08-23 14:18:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "latergram",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/OuvdLarfuq",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BJdC-G-DH-U\/",
      "display_url" : "instagram.com\/p\/BJdC-G-DH-U\/"
    } ]
  },
  "geo" : { },
  "id_str" : "768086073364840451",
  "text" : "For the Werewolves of London #latergram https:\/\/t.co\/OuvdLarfuq",
  "id" : 768086073364840451,
  "created_at" : "2016-08-23 14:02:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 12, 26 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/767995128317370369\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/NoA60tMej2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqh3f4jWgAQuAVU.jpg",
      "id_str" : "767995126106980356",
      "id" : 767995126106980356,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqh3f4jWgAQuAVU.jpg",
      "sizes" : [ {
        "h" : 566,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 566,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/NoA60tMej2"
    } ],
    "hashtags" : [ {
      "text" : "brexit",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767995128317370369",
  "text" : "Help us, so @Protohedgehog can do his very own #brexit https:\/\/t.co\/wmnWHMdnMe https:\/\/t.co\/NoA60tMej2",
  "id" : 767995128317370369,
  "created_at" : "2016-08-23 08:01:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Star Squires",
      "screen_name" : "StarDeSoul",
      "indices" : [ 0, 11 ],
      "id_str" : "261324132",
      "id" : 261324132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767503616722612224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097637121571, 8.81853260100709 ]
  },
  "id_str" : "767869155366342656",
  "in_reply_to_user_id" : 261324132,
  "text" : "@StarDeSoul thanks so much!",
  "id" : 767869155366342656,
  "in_reply_to_status_id" : 767503616722612224,
  "created_at" : "2016-08-22 23:40:47 +0000",
  "in_reply_to_screen_name" : "StarDeSoul",
  "in_reply_to_user_id_str" : "261324132",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767868566179811329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06097637121571, 8.81853260100709 ]
  },
  "id_str" : "767868948318658560",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey yeah, those are kind of useless, agreed on that.",
  "id" : 767868948318658560,
  "in_reply_to_status_id" : 767868566179811329,
  "created_at" : "2016-08-22 23:39:58 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 0, 9 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767856674879209472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06070825258421, 8.818611369220632 ]
  },
  "id_str" : "767867643357519873",
  "in_reply_to_user_id" : 16029156,
  "text" : "@merenbey because it sucks telling someone they\/their children will suffer because of $funnygenename?",
  "id" : 767867643357519873,
  "in_reply_to_status_id" : 767856674879209472,
  "created_at" : "2016-08-22 23:34:47 +0000",
  "in_reply_to_screen_name" : "merenbey",
  "in_reply_to_user_id_str" : "16029156",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767851353418960896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085055081381, 8.818690764150777 ]
  },
  "id_str" : "767854229897764872",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC thanks! \uD83D\uDE0D\uD83D\uDC96",
  "id" : 767854229897764872,
  "in_reply_to_status_id" : 767851353418960896,
  "created_at" : "2016-08-22 22:41:29 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767850755487363072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086354194036, 8.818474221164037 ]
  },
  "id_str" : "767850976871145472",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC please do videos of the ensuing disaster!",
  "id" : 767850976871145472,
  "in_reply_to_status_id" : 767850755487363072,
  "created_at" : "2016-08-22 22:28:33 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767823984952012800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06069834812222, 8.818377845871073 ]
  },
  "id_str" : "767847384370057216",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC I think you mentioned that once :D",
  "id" : 767847384370057216,
  "in_reply_to_status_id" : 767823984952012800,
  "created_at" : "2016-08-22 22:14:17 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/Kji8MBTVWc",
      "expanded_url" : "http:\/\/67.media.tumblr.com\/tumblr_lpvgy2DEcM1qhon59o1_500.gif",
      "display_url" : "67.media.tumblr.com\/tumblr_lpvgy2D\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "767820448868564992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06079903124965, 8.818585675414639 ]
  },
  "id_str" : "767820642670481408",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC https:\/\/t.co\/Kji8MBTVWc :p",
  "id" : 767820642670481408,
  "in_reply_to_status_id" : 767820448868564992,
  "created_at" : "2016-08-22 20:28:01 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767820059356061696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06058477555759, 8.818334172783377 ]
  },
  "id_str" : "767820250201161728",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yikes, good thing for me it\u2019s more or less exclusively doing solo trips these days.",
  "id" : 767820250201161728,
  "in_reply_to_status_id" : 767820059356061696,
  "created_at" : "2016-08-22 20:26:27 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767816278438543360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076182371366, 8.81845553624185 ]
  },
  "id_str" : "767817473471213568",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC no luck there. I\u2019ll be in SAN for 17-22.",
  "id" : 767817473471213568,
  "in_reply_to_status_id" : 767816278438543360,
  "created_at" : "2016-08-22 20:15:25 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/3o5CjfkrDc",
      "expanded_url" : "https:\/\/twitter.com\/msandstr\/status\/767775782353694720",
      "display_url" : "twitter.com\/msandstr\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084217366283, 8.818557309025291 ]
  },
  "id_str" : "767815701365129219",
  "text" : "That\u2019s hands-down some of the nicest short SF I\u2019ve read lately. \uD83D\uDE0D https:\/\/t.co\/3o5CjfkrDc",
  "id" : 767815701365129219,
  "created_at" : "2016-08-22 20:08:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malin Sandstr\u00F6m",
      "screen_name" : "msandstr",
      "indices" : [ 0, 9 ],
      "id_str" : "23945759",
      "id" : 23945759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767775782353694720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086313068794, 8.818678216197727 ]
  },
  "id_str" : "767815485534732288",
  "in_reply_to_user_id" : 23945759,
  "text" : "@msandstr finally read it and it\u2019s lovely, thanks so much \uD83D\uDC96",
  "id" : 767815485534732288,
  "in_reply_to_status_id" : 767775782353694720,
  "created_at" : "2016-08-22 20:07:31 +0000",
  "in_reply_to_screen_name" : "msandstr",
  "in_reply_to_user_id_str" : "23945759",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767786167546810369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06115674683469, 8.81883491400184 ]
  },
  "id_str" : "767787295701397504",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC when will you be there? I\u2019m going to San Diego mid\/end of September :D",
  "id" : 767787295701397504,
  "in_reply_to_status_id" : 767786167546810369,
  "created_at" : "2016-08-22 18:15:30 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/oZrirdSevg",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/767758800023588864",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06073418507159, 8.818493281964177 ]
  },
  "id_str" : "767770761822076928",
  "text" : "Why am I even bothering to write useful papers if this works too? https:\/\/t.co\/oZrirdSevg",
  "id" : 767770761822076928,
  "created_at" : "2016-08-22 17:09:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06074575919948, 8.818419991291957 ]
  },
  "id_str" : "767770202272591875",
  "text" : "Two days after I praised 4square for finding good places it sends me a notification for a steakhouse despite me being labeled vegetarian\u2026",
  "id" : 767770202272591875,
  "created_at" : "2016-08-22 17:07:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767753999080710144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099143097514, 8.818541746175201 ]
  },
  "id_str" : "767768521514287108",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC uh, where ya heading?",
  "id" : 767768521514287108,
  "in_reply_to_status_id" : 767753999080710144,
  "created_at" : "2016-08-22 17:00:54 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767734669433532417",
  "geo" : { },
  "id_str" : "767734759749484544",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot how did you know that I wanted to do that one next? ;)",
  "id" : 767734759749484544,
  "in_reply_to_status_id" : 767734669433532417,
  "created_at" : "2016-08-22 14:46:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 5, 19 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/767733684615127040\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/X3jQLr9kZ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqeJtzaWIAAg9Vq.jpg",
      "id_str" : "767733681477787648",
      "id" : 767733681477787648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqeJtzaWIAAg9Vq.jpg",
      "sizes" : [ {
        "h" : 359,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 582
      } ],
      "display_url" : "pic.twitter.com\/X3jQLr9kZ6"
    } ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767733684615127040",
  "text" : "Help @Protohedgehog and me start our #opencon foundation for\u2026 https:\/\/t.co\/wmnWHMdnMe https:\/\/t.co\/X3jQLr9kZ6",
  "id" : 767733684615127040,
  "created_at" : "2016-08-22 14:42:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/3c6xcgh60o",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=yVsqId3Kmhg",
      "display_url" : "youtube.com\/watch?v=yVsqId\u2026"
    }, {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/2aTCq6Cyfh",
      "expanded_url" : "https:\/\/twitter.com\/Villavelius\/status\/767676789057589248",
      "display_url" : "twitter.com\/Villavelius\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767732693270466560",
  "text" : "One of my favorite recordings w\/ him: https:\/\/t.co\/3c6xcgh60o https:\/\/t.co\/2aTCq6Cyfh",
  "id" : 767732693270466560,
  "created_at" : "2016-08-22 14:38:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767728292950581248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17254490024551, 8.627589741184924 ]
  },
  "id_str" : "767728377881133056",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog psst! don\u2019t tell them!",
  "id" : 767728377881133056,
  "in_reply_to_status_id" : 767728292950581248,
  "created_at" : "2016-08-22 14:21:23 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/UcchIDWwf7",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/767727075327303682",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767727289513701377",
  "text" : "Tired of us spamming this time and again? We\u2019re too. But we promise we\u2019ll stop once we reach our funding goal. https:\/\/t.co\/UcchIDWwf7",
  "id" : 767727289513701377,
  "created_at" : "2016-08-22 14:17:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172459036696, 8.627370009102416 ]
  },
  "id_str" : "767669876790071296",
  "text" : "Due to popular demand we massively dropped the price of our paywall! https:\/\/t.co\/ERLbKXkt99",
  "id" : 767669876790071296,
  "created_at" : "2016-08-22 10:28:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767630563813490688",
  "geo" : { },
  "id_str" : "767659425394024448",
  "in_reply_to_user_id" : 14286491,
  "text" : "Good thing I never ever clean my desk. Found them. Glad I\u2019m paid for this waste of time. \uD83C\uDFAB",
  "id" : 767659425394024448,
  "in_reply_to_status_id" : 767630563813490688,
  "created_at" : "2016-08-22 09:47:24 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Blommaert \uD83D\uDC69\uD83C\uDFFC\u200D\uD83D\uDD2C",
      "screen_name" : "Julie_B92",
      "indices" : [ 0, 10 ],
      "id_str" : "1385861262",
      "id" : 1385861262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767647992430137344",
  "geo" : { },
  "id_str" : "767648081584283648",
  "in_reply_to_user_id" : 1385861262,
  "text" : "@Julie_B92 who knows. Let\u2019s see what the response is. :)",
  "id" : 767648081584283648,
  "in_reply_to_status_id" : 767647992430137344,
  "created_at" : "2016-08-22 09:02:19 +0000",
  "in_reply_to_screen_name" : "Julie_B92",
  "in_reply_to_user_id_str" : "1385861262",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767643336396140544",
  "geo" : { },
  "id_str" : "767643406440988672",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg who knows?  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 767643406440988672,
  "in_reply_to_status_id" : 767643336396140544,
  "created_at" : "2016-08-22 08:43:44 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andreasdotorg",
      "screen_name" : "andreasdotorg",
      "indices" : [ 0, 14 ],
      "id_str" : "14285735",
      "id" : 14285735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/pa3yJeuMuh",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/University_of_Bologna",
      "display_url" : "en.wikipedia.org\/wiki\/Universit\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "767631077779341312",
  "geo" : { },
  "id_str" : "767631283975577600",
  "in_reply_to_user_id" : 14285735,
  "text" : "@andreasdotorg Im 11. denke ich. https:\/\/t.co\/pa3yJeuMuh",
  "id" : 767631283975577600,
  "in_reply_to_status_id" : 767631077779341312,
  "created_at" : "2016-08-22 07:55:34 +0000",
  "in_reply_to_screen_name" : "andreasdotorg",
  "in_reply_to_user_id_str" : "14285735",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767630936749985792",
  "geo" : { },
  "id_str" : "767631056522579968",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher I have indeed, plus foursquare checkins. And the entry stamps in my passport\u2026",
  "id" : 767631056522579968,
  "in_reply_to_status_id" : 767630936749985792,
  "created_at" : "2016-08-22 07:54:40 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Rauscher",
      "screen_name" : "prauscher",
      "indices" : [ 0, 10 ],
      "id_str" : "74155696",
      "id" : 74155696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767630761251962880",
  "geo" : { },
  "id_str" : "767630822467837952",
  "in_reply_to_user_id" : 74155696,
  "text" : "@prauscher that I actually took those flights I guess?",
  "id" : 767630822467837952,
  "in_reply_to_status_id" : 767630761251962880,
  "created_at" : "2016-08-22 07:53:44 +0000",
  "in_reply_to_screen_name" : "prauscher",
  "in_reply_to_user_id_str" : "74155696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767630563813490688",
  "text" : "University admin, telling me you\u2019d need the originals of the damn boarding pass stubs 1+ month after filing my claims isn\u2019t cool at all. \uD83D\uDD25\uD83D\uDD25\uD83D\uDD25",
  "id" : 767630563813490688,
  "created_at" : "2016-08-22 07:52:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "767434955785986049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46881423786526, -0.4461081333860759 ]
  },
  "id_str" : "767435191254130689",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke oh, thanks. I thought  a one time donation for https:\/\/t.co\/ERLbKXkt99 but that\u2019s even more appreciated!",
  "id" : 767435191254130689,
  "in_reply_to_status_id" : 767434955785986049,
  "created_at" : "2016-08-21 18:56:22 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Tacke",
      "screen_name" : "otacke",
      "indices" : [ 0, 7 ],
      "id_str" : "34880281",
      "id" : 34880281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767433846027587584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.468742557925, -0.4460889741159378 ]
  },
  "id_str" : "767434009500610560",
  "in_reply_to_user_id" : 34880281,
  "text" : "@otacke that is taken care of. But I\u2019ll happily take your money for DC ;)",
  "id" : 767434009500610560,
  "in_reply_to_status_id" : 767433846027587584,
  "created_at" : "2016-08-21 18:51:40 +0000",
  "in_reply_to_screen_name" : "otacke",
  "in_reply_to_user_id_str" : "34880281",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/0iIsdTwNqy",
      "expanded_url" : "https:\/\/www.personalizedhealth2016.ch\/",
      "display_url" : "personalizedhealth2016.ch"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.468954, -0.446019 ]
  },
  "id_str" : "767433344615415808",
  "text" : "Let's do more crowdsourcing: Suppose I had to give a 30 minute talk here. What should the title of said talk be? https:\/\/t.co\/0iIsdTwNqy",
  "id" : 767433344615415808,
  "created_at" : "2016-08-21 18:49:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46859528923775, -0.4468549853018854 ]
  },
  "id_str" : "767430475199700994",
  "text" : "Bored on a Sunday evening and maybe even a bit drunk? Why not drunken crowdfunding instead of drunken Amazon! https:\/\/t.co\/ERLbKXkt99",
  "id" : 767430475199700994,
  "created_at" : "2016-08-21 18:37:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9l\u00E9onore Mayola",
      "screen_name" : "EleonoreMayola",
      "indices" : [ 0, 15 ],
      "id_str" : "502916683",
      "id" : 502916683
    }, {
      "name" : "Fiona Nielsen",
      "screen_name" : "glyn_dk",
      "indices" : [ 16, 24 ],
      "id_str" : "32340834",
      "id" : 32340834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767358201067081728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48144256961243, -0.08386952360716597 ]
  },
  "id_str" : "767372625890910209",
  "in_reply_to_user_id" : 502916683,
  "text" : "@EleonoreMayola @glyn_dk went to Gosh yesterday and I\u2019m pretty sure today my luggage isn\u2019t exactly fitting the carry-on restrictions.",
  "id" : 767372625890910209,
  "in_reply_to_status_id" : 767358201067081728,
  "created_at" : "2016-08-21 14:47:45 +0000",
  "in_reply_to_screen_name" : "EleonoreMayola",
  "in_reply_to_user_id_str" : "502916683",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00C9l\u00E9onore Mayola",
      "screen_name" : "EleonoreMayola",
      "indices" : [ 0, 15 ],
      "id_str" : "502916683",
      "id" : 502916683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767107693467295744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48143499628779, -0.08405573666103562 ]
  },
  "id_str" : "767353234692444160",
  "in_reply_to_user_id" : 502916683,
  "text" : "@EleonoreMayola where did you find those? :)",
  "id" : 767353234692444160,
  "in_reply_to_status_id" : 767107693467295744,
  "created_at" : "2016-08-21 13:30:42 +0000",
  "in_reply_to_screen_name" : "EleonoreMayola",
  "in_reply_to_user_id_str" : "502916683",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Sucksmith",
      "screen_name" : "EdSucksmith",
      "indices" : [ 3, 15 ],
      "id_str" : "1528699742",
      "id" : 1528699742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/1BvL12iWWt",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/766377395360296960",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767294926396788737",
  "text" : "RT @EdSucksmith: Please consider helping these guys reach #opencon to spread their love of open science!.. https:\/\/t.co\/1BvL12iWWt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 41, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/1BvL12iWWt",
        "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/766377395360296960",
        "display_url" : "twitter.com\/Protohedgehog\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766770888930918401",
    "text" : "Please consider helping these guys reach #opencon to spread their love of open science!.. https:\/\/t.co\/1BvL12iWWt",
    "id" : 766770888930918401,
    "created_at" : "2016-08-19 22:56:40 +0000",
    "user" : {
      "name" : "Ed Sucksmith",
      "screen_name" : "EdSucksmith",
      "protected" : false,
      "id_str" : "1528699742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925390621401141248\/5-Hip0oE_normal.jpg",
      "id" : 1528699742,
      "verified" : false
    }
  },
  "id" : 767294926396788737,
  "created_at" : "2016-08-21 09:39:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Nabors",
      "screen_name" : "rachelnabors",
      "indices" : [ 3, 16 ],
      "id_str" : "9550352",
      "id" : 9550352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767106543913463808",
  "text" : "RT @rachelnabors: For those of you new to this debacle, you can read my comics and account of being stuck at the UK border here: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/CCHFkvMUmr",
        "expanded_url" : "https:\/\/medium.com\/@rachelnabors\/wtfuk-73009d5623b4#.kco34bmw8",
        "display_url" : "medium.com\/@rachelnabors\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "766809345136877570",
    "geo" : { },
    "id_str" : "766809832229736448",
    "in_reply_to_user_id" : 9550352,
    "text" : "For those of you new to this debacle, you can read my comics and account of being stuck at the UK border here: https:\/\/t.co\/CCHFkvMUmr",
    "id" : 766809832229736448,
    "in_reply_to_status_id" : 766809345136877570,
    "created_at" : "2016-08-20 01:31:25 +0000",
    "in_reply_to_screen_name" : "rachelnabors",
    "in_reply_to_user_id_str" : "9550352",
    "user" : {
      "name" : "Rachel Nabors",
      "screen_name" : "rachelnabors",
      "protected" : false,
      "id_str" : "9550352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/899039208693669888\/ibha3cYB_normal.jpg",
      "id" : 9550352,
      "verified" : false
    }
  },
  "id" : 767106543913463808,
  "created_at" : "2016-08-20 21:10:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Nabors",
      "screen_name" : "rachelnabors",
      "indices" : [ 3, 16 ],
      "id_str" : "9550352",
      "id" : 9550352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767106522107224064",
  "text" : "RT @rachelnabors: UK Border Office finally got back to me on my complaint. In short: you need a work permit to speak in the UK. NOW they pu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766808673679138816",
    "text" : "UK Border Office finally got back to me on my complaint. In short: you need a work permit to speak in the UK. NOW they put it on their site.",
    "id" : 766808673679138816,
    "created_at" : "2016-08-20 01:26:49 +0000",
    "user" : {
      "name" : "Rachel Nabors",
      "screen_name" : "rachelnabors",
      "protected" : false,
      "id_str" : "9550352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/899039208693669888\/ibha3cYB_normal.jpg",
      "id" : 9550352,
      "verified" : false
    }
  },
  "id" : 767106522107224064,
  "created_at" : "2016-08-20 21:10:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 3, 19 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 25, 39 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766928428352344065",
  "text" : "RT @gedankenstuecke: So, @Protohedgehog and I are looking for a bit of money to get to #opencon, please consider contributing! https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Tennant",
        "screen_name" : "Protohedgehog",
        "indices" : [ 4, 18 ],
        "id_str" : "352650591",
        "id" : 352650591
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 66, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/ERLbKXkt99",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765832746224742400",
    "text" : "So, @Protohedgehog and I are looking for a bit of money to get to #opencon, please consider contributing! https:\/\/t.co\/ERLbKXkt99",
    "id" : 765832746224742400,
    "created_at" : "2016-08-17 08:48:49 +0000",
    "user" : {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "protected" : false,
      "id_str" : "14286491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
      "id" : 14286491,
      "verified" : true
    }
  },
  "id" : 766928428352344065,
  "created_at" : "2016-08-20 09:22:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766891325425934336\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/5tAo7OhyYZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqSLmHxW8AAxuaC.jpg",
      "id_str" : "766891323597189120",
      "id" : 766891323597189120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqSLmHxW8AAxuaC.jpg",
      "sizes" : [ {
        "h" : 1060,
        "resize" : "fit",
        "w" : 1413
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1060,
        "resize" : "fit",
        "w" : 1413
      } ],
      "display_url" : "pic.twitter.com\/5tAo7OhyYZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.480993, -0.083667 ]
  },
  "id_str" : "766891325425934336",
  "text" : "Your fetish is not my fetish\u2026 \uD83D\uDC11 https:\/\/t.co\/5tAo7OhyYZ",
  "id" : 766891325425934336,
  "created_at" : "2016-08-20 06:55:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766764512036945920",
  "text" : "RT @Protohedgehog: 40% of the way there! If anyone is feeling more generous after a few beers tonight, here's a good cause :) https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/DwOxwK7TAL",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766724410845855744",
    "text" : "40% of the way there! If anyone is feeling more generous after a few beers tonight, here's a good cause :) https:\/\/t.co\/DwOxwK7TAL #opencon",
    "id" : 766724410845855744,
    "created_at" : "2016-08-19 19:51:59 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 766764512036945920,
  "created_at" : "2016-08-19 22:31:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766706866806284289\/photo\/1",
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/jCxM1FbebL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPji4AWEAEG4qQ.jpg",
      "id_str" : "766706549872005121",
      "id" : 766706549872005121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPji4AWEAEG4qQ.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/jCxM1FbebL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4814347626311, -0.08390283487914024 ]
  },
  "id_str" : "766706866806284289",
  "text" : "Fuck. https:\/\/t.co\/jCxM1FbebL",
  "id" : 766706866806284289,
  "created_at" : "2016-08-19 18:42:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766694599771422720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4814885581108, -0.08387788844028989 ]
  },
  "id_str" : "766705051997990912",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest get well soon. And let\u2019s see whether it works out! :)",
  "id" : 766705051997990912,
  "in_reply_to_status_id" : 766694599771422720,
  "created_at" : "2016-08-19 18:35:03 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766694135084544000",
  "geo" : { },
  "id_str" : "766694234141458432",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest I\u2019ll be in town until Sunday evening.",
  "id" : 766694234141458432,
  "in_reply_to_status_id" : 766694135084544000,
  "created_at" : "2016-08-19 17:52:04 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766691458787241985",
  "geo" : { },
  "id_str" : "766693910907322368",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest while you\u2019re doing that you\u2019d be facing a sign saying \u201ENO DUMPING!\u201C that I didn\u2019t photograph :D",
  "id" : 766693910907322368,
  "in_reply_to_status_id" : 766691458787241985,
  "created_at" : "2016-08-19 17:50:47 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD5E\uD83E\uDD84\u2728\uD83D\uDC69\u200D\uD83C\uDF3E",
      "screen_name" : "pikelet",
      "indices" : [ 0, 8 ],
      "id_str" : "6000702",
      "id" : 6000702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766494438856065024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49877534999999, -0.08127358999999998 ]
  },
  "id_str" : "766689774979715072",
  "in_reply_to_user_id" : 6000702,
  "text" : "@pikelet awesome, thanks for sharing so much \uD83D\uDE0D",
  "id" : 766689774979715072,
  "in_reply_to_status_id" : 766494438856065024,
  "created_at" : "2016-08-19 17:34:21 +0000",
  "in_reply_to_screen_name" : "pikelet",
  "in_reply_to_user_id_str" : "6000702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766689613826101248\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/5DGxj77R8q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPUIfYWYAAJSz0.jpg",
      "id_str" : "766689603910787072",
      "id" : 766689603910787072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPUIfYWYAAJSz0.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/5DGxj77R8q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49877534999999, -0.08127358999999998 ]
  },
  "id_str" : "766689613826101248",
  "text" : "Totally what you want to stare at you all the time while being in the bathroom. https:\/\/t.co\/5DGxj77R8q",
  "id" : 766689613826101248,
  "created_at" : "2016-08-19 17:33:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 49, 65 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 126, 139 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766689366198607873",
  "text" : "RT @Protohedgehog: Even if you're not supporting @gedankenstuecke &amp; I to get to #opencon, please watch our silly video at @royalsociety htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 30, 46 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "The Royal Society",
        "screen_name" : "royalsociety",
        "indices" : [ 107, 120 ],
        "id_str" : "28567809",
        "id" : 28567809
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 65, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/B0a7kwtRBQ",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=PtCj7Dyw-Hs",
        "display_url" : "youtube.com\/watch?v=PtCj7D\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766666640335466497",
    "text" : "Even if you're not supporting @gedankenstuecke &amp; I to get to #opencon, please watch our silly video at @royalsociety https:\/\/t.co\/B0a7kwtRBQ",
    "id" : 766666640335466497,
    "created_at" : "2016-08-19 16:02:25 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 766689366198607873,
  "created_at" : "2016-08-19 17:32:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 15, 28 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766666640335466497",
  "geo" : { },
  "id_str" : "766672255522922496",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @royalsociety now even with the link to our campaign in the video description! :D",
  "id" : 766672255522922496,
  "in_reply_to_status_id" : 766666640335466497,
  "created_at" : "2016-08-19 16:24:44 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/w21Gg2ReHJ",
      "expanded_url" : "https:\/\/twitter.com\/t_s_institute\/status\/766647492628844544",
      "display_url" : "twitter.com\/t_s_institute\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766647605866758144",
  "text" : "i\u2019d totally do that too! https:\/\/t.co\/w21Gg2ReHJ",
  "id" : 766647605866758144,
  "created_at" : "2016-08-19 14:46:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/viIusKPvqZ",
      "expanded_url" : "http:\/\/www.ukpunchampionship.co.uk\/",
      "display_url" : "ukpunchampionship.co.uk"
    } ]
  },
  "in_reply_to_status_id_str" : "766622675133403136",
  "geo" : { },
  "id_str" : "766626910218625025",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest dammit, there\u2019s something for puntomimes! https:\/\/t.co\/viIusKPvqZ",
  "id" : 766626910218625025,
  "in_reply_to_status_id" : 766622675133403136,
  "created_at" : "2016-08-19 13:24:33 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766617849632788480",
  "geo" : { },
  "id_str" : "766621641883389952",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest isn\u2019t that punting? :p",
  "id" : 766621641883389952,
  "in_reply_to_status_id" : 766617849632788480,
  "created_at" : "2016-08-19 13:03:37 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766617428902248448",
  "geo" : { },
  "id_str" : "766617674537398272",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest I wish competitive punning was a thing as well.",
  "id" : 766617674537398272,
  "in_reply_to_status_id" : 766617428902248448,
  "created_at" : "2016-08-19 12:47:51 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/UAHL7kDfzJ",
      "expanded_url" : "http:\/\/www.urbandictionary.com\/define.php?term=polympics",
      "display_url" : "urbandictionary.com\/define.php?ter\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "766616739916513280",
  "geo" : { },
  "id_str" : "766617035799486464",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest (i should have googled this before replying\u2026) https:\/\/t.co\/UAHL7kDfzJ",
  "id" : 766617035799486464,
  "in_reply_to_status_id" : 766616739916513280,
  "created_at" : "2016-08-19 12:45:19 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766616739916513280",
  "geo" : { },
  "id_str" : "766616893352505345",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest only in the pOlympics.",
  "id" : 766616893352505345,
  "in_reply_to_status_id" : 766616739916513280,
  "created_at" : "2016-08-19 12:44:45 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766614232406319104",
  "geo" : { },
  "id_str" : "766614743415152640",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest sure, if i cuddle, i cuddle to win! \uD83C\uDFC6",
  "id" : 766614743415152640,
  "in_reply_to_status_id" : 766614232406319104,
  "created_at" : "2016-08-19 12:36:12 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "renataaquino",
      "screen_name" : "renataaquino",
      "indices" : [ 0, 13 ],
      "id_str" : "14517051",
      "id" : 14517051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766608092985516032",
  "geo" : { },
  "id_str" : "766608221360558080",
  "in_reply_to_user_id" : 14517051,
  "text" : "@renataaquino thank you so much!",
  "id" : 766608221360558080,
  "in_reply_to_status_id" : 766608092985516032,
  "created_at" : "2016-08-19 12:10:17 +0000",
  "in_reply_to_screen_name" : "renataaquino",
  "in_reply_to_user_id_str" : "14517051",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 32, 46 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766604340371030016",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Thanks for supporting @Protohedgehog and me! :-)",
  "id" : 766604340371030016,
  "created_at" : "2016-08-19 11:54:52 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "indices" : [ 0, 12 ],
      "id_str" : "1085971416",
      "id" : 1085971416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766593047886954496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49999737883575, -0.07818600405995989 ]
  },
  "id_str" : "766600946503876609",
  "in_reply_to_user_id" : 1085971416,
  "text" : "@ShiriEisner around 1\/3 through and I already so often thought \u201Cthat\u2019s exactly what I experience\/feel! I\u2019m not alone with this!\u201D",
  "id" : 766600946503876609,
  "in_reply_to_status_id" : 766593047886954496,
  "created_at" : "2016-08-19 11:41:23 +0000",
  "in_reply_to_screen_name" : "ShiriEisner",
  "in_reply_to_user_id_str" : "1085971416",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/qxG1Zkl64g",
      "expanded_url" : "https:\/\/twitter.com\/Lobot\/status\/766560404302540801",
      "display_url" : "twitter.com\/Lobot\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766595937854689280",
  "text" : "I might have spent something like 15 minutes to watch this gif. \u2708\uFE0F\uD83D\uDC36 https:\/\/t.co\/qxG1Zkl64g",
  "id" : 766595937854689280,
  "created_at" : "2016-08-19 11:21:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766585992039936002",
  "geo" : { },
  "id_str" : "766586108113190912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, lifeline is just hilariously large, fitting for AUS.",
  "id" : 766586108113190912,
  "in_reply_to_status_id" : 766585992039936002,
  "created_at" : "2016-08-19 10:42:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766467714089050113",
  "geo" : { },
  "id_str" : "766584366126497792",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer send pics! :D",
  "id" : 766584366126497792,
  "in_reply_to_status_id" : 766467714089050113,
  "created_at" : "2016-08-19 10:35:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766583655720517632",
  "text" : "\u00ABNot to go all competitive or anything, but my other girlfriend donated more to our crowdfunding campaign.\u00BB https:\/\/t.co\/wmnWHMdnMe",
  "id" : 766583655720517632,
  "created_at" : "2016-08-19 10:32:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/tSvgnx9fEi",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766229313989533696",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "766229313989533696",
  "geo" : { },
  "id_str" : "766560763418775552",
  "in_reply_to_user_id" : 14286491,
  "text" : "It might not raise any money, but I do get a lot of pleasure of re-spamming the spammers. https:\/\/t.co\/tSvgnx9fEi",
  "id" : 766560763418775552,
  "in_reply_to_status_id" : 766229313989533696,
  "created_at" : "2016-08-19 09:01:42 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 15, 23 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Mozilla Science Lab",
      "screen_name" : "MozillaScience",
      "indices" : [ 66, 81 ],
      "id_str" : "1428575976",
      "id" : 1428575976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766554830265397252",
  "geo" : { },
  "id_str" : "766555013690699776",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @tonyR_H we\u2019ll need a bigger advertising campaign. @MozillaScience how about a shout-out for us? \uD83D\uDE07",
  "id" : 766555013690699776,
  "in_reply_to_status_id" : 766554830265397252,
  "created_at" : "2016-08-19 08:38:51 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/B5Yzsd1hO8",
      "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/766449055287222272",
      "display_url" : "twitter.com\/existentialcom\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49665293000741, -0.08185603706976984 ]
  },
  "id_str" : "766545473016508418",
  "text" : "Day 7: nap time.\nDay 8: dead. https:\/\/t.co\/B5Yzsd1hO8",
  "id" : 766545473016508418,
  "created_at" : "2016-08-19 08:00:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766408706531659776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48148415614989, -0.08400318212815001 ]
  },
  "id_str" : "766408908743278592",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest best part: autocorrect wanted to do \u201Cbrain scams\u201D \uD83D\uDE02",
  "id" : 766408908743278592,
  "in_reply_to_status_id" : 766408706531659776,
  "created_at" : "2016-08-18 22:58:17 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766408580941701120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48145905234989, -0.08396931923933697 ]
  },
  "id_str" : "766408797816496128",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest wanna do some brain scans to figure that out?",
  "id" : 766408797816496128,
  "in_reply_to_status_id" : 766408580941701120,
  "created_at" : "2016-08-18 22:57:51 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766408130704138241",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48150360216525, -0.08396923542030525 ]
  },
  "id_str" : "766408593365237761",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest that\u2019s what you get for playing homophobic!",
  "id" : 766408593365237761,
  "in_reply_to_status_id" : 766408130704138241,
  "created_at" : "2016-08-18 22:57:02 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766407608932634625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4814888351388, -0.08392000198318252 ]
  },
  "id_str" : "766408395633098752",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest let\u2019s say I\u2019m no stranger to the fabulous, outrageous bisexual spectacle. \uD83D\uDE0E\uD83C\uDF89\uD83D\uDCA5",
  "id" : 766408395633098752,
  "in_reply_to_status_id" : 766407608932634625,
  "created_at" : "2016-08-18 22:56:15 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766407562652778497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4814888351388, -0.08392000198318252 ]
  },
  "id_str" : "766407644181565440",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest try making me straight!",
  "id" : 766407644181565440,
  "in_reply_to_status_id" : 766407562652778497,
  "created_at" : "2016-08-18 22:53:16 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766407487016894464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48142539900865, -0.08387619629510108 ]
  },
  "id_str" : "766407538631991296",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest it\u2019s magic!",
  "id" : 766407538631991296,
  "in_reply_to_status_id" : 766407487016894464,
  "created_at" : "2016-08-18 22:52:51 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766406863000928257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48147937846508, -0.08392497897155948 ]
  },
  "id_str" : "766407177485578240",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83C\uDF89\uD83D\uDD2E",
  "id" : 766407177485578240,
  "in_reply_to_status_id" : 766406863000928257,
  "created_at" : "2016-08-18 22:51:24 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766406279824871425",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4814867635496, -0.0838538857267015 ]
  },
  "id_str" : "766406505750941696",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest that I remember slightly different!",
  "id" : 766406505750941696,
  "in_reply_to_status_id" : 766406279824871425,
  "created_at" : "2016-08-18 22:48:44 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "indices" : [ 9, 21 ],
      "id_str" : "1085971416",
      "id" : 1085971416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766405873547771905",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4814867635496, -0.0838538857267015 ]
  },
  "id_str" : "766406088329719814",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @ShiriEisner after the last days I\u2019m not too surprised :p",
  "id" : 766406088329719814,
  "in_reply_to_status_id" : 766405873547771905,
  "created_at" : "2016-08-18 22:47:05 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shiri Eisner",
      "screen_name" : "ShiriEisner",
      "indices" : [ 61, 73 ],
      "id_str" : "1085971416",
      "id" : 1085971416
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766402477654704128\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/6xrVUjhUKl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqLO_ZbWcAAjUzm.jpg",
      "id_str" : "766402475159089152",
      "id" : 766402475159089152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqLO_ZbWcAAjUzm.jpg",
      "sizes" : [ {
        "h" : 210,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 2324
      } ],
      "display_url" : "pic.twitter.com\/6xrVUjhUKl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.481372, -0.083873 ]
  },
  "id_str" : "766402477654704128",
  "text" : "Viva la bisexual revolution! Thanks for the awesome writing, @ShiriEisner \uD83D\uDC98 https:\/\/t.co\/6xrVUjhUKl",
  "id" : 766402477654704128,
  "created_at" : "2016-08-18 22:32:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 52, 68 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DwOxwK7TAL",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766389512981323777",
  "text" : "RT @Protohedgehog: If anyone can share this to help @gedankenstuecke &amp; I get to #opencon we'll love you for it! https:\/\/t.co\/DwOxwK7TAL htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 33, 49 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/766377395360296960\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/GlhqWvchwL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqK4DUxWcAAHxT8.jpg",
        "id_str" : "766377253861224448",
        "id" : 766377253861224448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqK4DUxWcAAHxT8.jpg",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 568
        } ],
        "display_url" : "pic.twitter.com\/GlhqWvchwL"
      } ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 65, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/DwOxwK7TAL",
        "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/",
        "display_url" : "indiegogo.com\/projects\/help-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766377395360296960",
    "text" : "If anyone can share this to help @gedankenstuecke &amp; I get to #opencon we'll love you for it! https:\/\/t.co\/DwOxwK7TAL https:\/\/t.co\/GlhqWvchwL",
    "id" : 766377395360296960,
    "created_at" : "2016-08-18 20:53:04 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 766389512981323777,
  "created_at" : "2016-08-18 21:41:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nazeefa",
      "screen_name" : "NazeefaFatima",
      "indices" : [ 0, 14 ],
      "id_str" : "37054704",
      "id" : 37054704
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 15, 29 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766318823700045824",
  "geo" : { },
  "id_str" : "766318974204276736",
  "in_reply_to_user_id" : 37054704,
  "text" : "@NazeefaFatima @Protohedgehog omg, we should offer a perk where we do this dance on video in front of i dunno, washington memorial?",
  "id" : 766318974204276736,
  "in_reply_to_status_id" : 766318823700045824,
  "created_at" : "2016-08-18 17:00:55 +0000",
  "in_reply_to_screen_name" : "NazeefaFatima",
  "in_reply_to_user_id_str" : "37054704",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 57, 71 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766315717750906880\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/r2qVxlPaCN",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CqJ_XLLXEAAYTCK.jpg",
      "id_str" : "766314922720563200",
      "id" : 766314922720563200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CqJ_XLLXEAAYTCK.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/r2qVxlPaCN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/IYK8UcDVBj",
      "expanded_url" : "http:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766315717750906880",
  "text" : "Other crowdfunding projects feel like this? Then support @Protohedgehog &amp; me in doing open*! https:\/\/t.co\/IYK8UcDVBj https:\/\/t.co\/r2qVxlPaCN",
  "id" : 766315717750906880,
  "created_at" : "2016-08-18 16:47:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766306184127213568\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5ancghuIJt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJ3Z8CWgAAfoJc.jpg",
      "id_str" : "766306174102831104",
      "id" : 766306174102831104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJ3Z8CWgAAfoJc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 1278
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 1278
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/5ancghuIJt"
    } ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 20, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/IYK8UcDVBj",
      "expanded_url" : "http:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766306184127213568",
  "text" : "Awesome to see that #scienceisglobal is also true for our transatlantic travel fund-search. https:\/\/t.co\/IYK8UcDVBj https:\/\/t.co\/5ancghuIJt",
  "id" : 766306184127213568,
  "created_at" : "2016-08-18 16:10:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766276885680627712",
  "geo" : { },
  "id_str" : "766301163562102784",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach Ich sag mal Medium. Ich komme morgen an dem Laden vorbei, dann schau ich mal. \uD83D\uDC36\uD83D\uDE0D",
  "id" : 766301163562102784,
  "in_reply_to_status_id" : 766276885680627712,
  "created_at" : "2016-08-18 15:50:09 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766274941276786689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51746146385699, -0.1200254168362543 ]
  },
  "id_str" : "766275301231955968",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach welche gr\u00F6\u00DFe braucht sie denn?",
  "id" : 766275301231955968,
  "in_reply_to_status_id" : 766274941276786689,
  "created_at" : "2016-08-18 14:07:23 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766274411079032832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51618858804136, -0.1194458920509736 ]
  },
  "id_str" : "766274754311512065",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach ruben? :)",
  "id" : 766274754311512065,
  "in_reply_to_status_id" : 766274411079032832,
  "created_at" : "2016-08-18 14:05:12 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766269330673762304\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/bkQtn6UahO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJV5OeW8AAFhvW.jpg",
      "id_str" : "766269328232738816",
      "id" : 766269328232738816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJV5OeW8AAFhvW.jpg",
      "sizes" : [ {
        "h" : 942,
        "resize" : "fit",
        "w" : 1256
      }, {
        "h" : 942,
        "resize" : "fit",
        "w" : 1256
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/bkQtn6UahO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.496538, -0.081883 ]
  },
  "id_str" : "766269330673762304",
  "text" : "\u00ABSorry for running late. I had to check out this collar store!\u00BB https:\/\/t.co\/bkQtn6UahO",
  "id" : 766269330673762304,
  "created_at" : "2016-08-18 13:43:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ah8yZ0deBN",
      "expanded_url" : "http:\/\/sexlettersproject.tumblr.com\/post\/149086738574\/people-should-be-telling-you-this-stuff-nicoles",
      "display_url" : "sexlettersproject.tumblr.com\/post\/149086738\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766256368068268032",
  "text" : "\u00AB14 Things you should know about sex (including a few about relationships)\u00BB https:\/\/t.co\/ah8yZ0deBN",
  "id" : 766256368068268032,
  "created_at" : "2016-08-18 12:52:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 0, 11 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766241894426873856",
  "geo" : { },
  "id_str" : "766241966816432128",
  "in_reply_to_user_id" : 28090494,
  "text" : "@herrurbach \uD83D\uDC96 thanks so much!",
  "id" : 766241966816432128,
  "in_reply_to_status_id" : 766241894426873856,
  "created_at" : "2016-08-18 11:54:55 +0000",
  "in_reply_to_screen_name" : "herrurbach",
  "in_reply_to_user_id_str" : "28090494",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/ynuBlLH1jG",
      "expanded_url" : "http:\/\/38.media.tumblr.com\/tumblr_lk6yzgHxjw1qi9q4ko1_r1_500.gif",
      "display_url" : "38.media.tumblr.com\/tumblr_lk6yzgH\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "766237752325177344",
  "geo" : { },
  "id_str" : "766238315234336768",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot yep, that\u2019s what I\u2019ll do to their money. https:\/\/t.co\/ynuBlLH1jG",
  "id" : 766238315234336768,
  "in_reply_to_status_id" : 766237752325177344,
  "created_at" : "2016-08-18 11:40:25 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766229284516163584",
  "geo" : { },
  "id_str" : "766229820577574912",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin have actually been using it for some days now and it works pretty well for me.",
  "id" : 766229820577574912,
  "in_reply_to_status_id" : 766229284516163584,
  "created_at" : "2016-08-18 11:06:39 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/7q5xEbKPBJ",
      "expanded_url" : "https:\/\/gist.github.com\/gedankenstuecke\/33af41a72099b95cc21c816a0fa0e4f1",
      "display_url" : "gist.github.com\/gedankenstueck\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766229313989533696",
  "text" : "Who said that annoying \u2018conference invites\u2019 have to be a unidirectional scam? Replying with this from now on. https:\/\/t.co\/7q5xEbKPBJ",
  "id" : 766229313989533696,
  "created_at" : "2016-08-18 11:04:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 36, 50 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766225731991048192\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/yvtn8TQouc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqIuPWTXEAAIDpN.jpg",
      "id_str" : "766225727826104320",
      "id" : 766225727826104320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqIuPWTXEAAIDpN.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 486
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/yvtn8TQouc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766225731991048192",
  "text" : "When our crowdfunding is successful @Protohedgehog &amp; I will write a how-to on it. Help now: https:\/\/t.co\/wmnWHMdnMe https:\/\/t.co\/yvtn8TQouc",
  "id" : 766225731991048192,
  "created_at" : "2016-08-18 10:50:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Alejandro Salgado M",
      "screen_name" : "tiempoasm",
      "indices" : [ 37, 47 ],
      "id_str" : "107749539",
      "id" : 107749539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766218810760302592",
  "geo" : { },
  "id_str" : "766223542367256576",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog @SamForbes88 @tiempoasm I\u2019ll just keep making innocent puppy eyes. \uD83D\uDC36\uD83D\uDC40",
  "id" : 766223542367256576,
  "in_reply_to_status_id" : 766218810760302592,
  "created_at" : "2016-08-18 10:41:42 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Alejandro Salgado M",
      "screen_name" : "tiempoasm",
      "indices" : [ 37, 47 ],
      "id_str" : "107749539",
      "id" : 107749539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766216366953201665",
  "geo" : { },
  "id_str" : "766218643634094080",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog @SamForbes88 @tiempoasm yeah, got it \uD83D\uDE02",
  "id" : 766218643634094080,
  "in_reply_to_status_id" : 766216366953201665,
  "created_at" : "2016-08-18 10:22:14 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Alejandro Salgado M",
      "screen_name" : "tiempoasm",
      "indices" : [ 37, 47 ],
      "id_str" : "107749539",
      "id" : 107749539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766214456883965952",
  "geo" : { },
  "id_str" : "766215144665939968",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog @SamForbes88 @tiempoasm so 2017 we\u2019re on? ;)",
  "id" : 766215144665939968,
  "in_reply_to_status_id" : 766214456883965952,
  "created_at" : "2016-08-18 10:08:20 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 15, 23 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/czks0zwmdU",
      "expanded_url" : "https:\/\/opencon.cat\/",
      "display_url" : "opencon.cat"
    } ]
  },
  "in_reply_to_status_id_str" : "766213749632106496",
  "geo" : { },
  "id_str" : "766214210225336321",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @o_guest one year I\u2019ll do both opencon. The one we\u2019re raising now and https:\/\/t.co\/czks0zwmdU",
  "id" : 766214210225336321,
  "in_reply_to_status_id" : 766213749632106496,
  "created_at" : "2016-08-18 10:04:37 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 15, 23 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766211928419074049",
  "geo" : { },
  "id_str" : "766212269780963328",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @o_guest maybe we should do offer a perk for \u201Ea collection of after hours-pictures we took in DC\u201C?",
  "id" : 766212269780963328,
  "in_reply_to_status_id" : 766211928419074049,
  "created_at" : "2016-08-18 09:56:55 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jakob Err",
      "screen_name" : "Jakob_Err",
      "indices" : [ 0, 10 ],
      "id_str" : "490871541",
      "id" : 490871541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766204566765506560",
  "geo" : { },
  "id_str" : "766208659374346240",
  "in_reply_to_user_id" : 490871541,
  "text" : "@Jakob_Err thanks! :-)",
  "id" : 766208659374346240,
  "in_reply_to_status_id" : 766204566765506560,
  "created_at" : "2016-08-18 09:42:34 +0000",
  "in_reply_to_screen_name" : "Jakob_Err",
  "in_reply_to_user_id_str" : "490871541",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766202525817171969",
  "geo" : { },
  "id_str" : "766202985672212480",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog I\u2019ve been dreaming of this tonight!",
  "id" : 766202985672212480,
  "in_reply_to_status_id" : 766202525817171969,
  "created_at" : "2016-08-18 09:20:01 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 22, 36 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766202273617805312\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/jOFBFv2awW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqIY559W8AAyZ50.jpg",
      "id_str" : "766202269696192512",
      "id" : 766202269696192512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqIY559W8AAyZ50.jpg",
      "sizes" : [ {
        "h" : 190,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 256
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 256
      } ],
      "display_url" : "pic.twitter.com\/jOFBFv2awW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766202273617805312",
  "text" : "Congratulations, your @Protohedgehog evolved into Promohedgehog. https:\/\/t.co\/wmnWHMdnMe https:\/\/t.co\/jOFBFv2awW",
  "id" : 766202273617805312,
  "created_at" : "2016-08-18 09:17:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u00FCrgen Geuter",
      "screen_name" : "tante",
      "indices" : [ 0, 6 ],
      "id_str" : "14179278",
      "id" : 14179278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766189464934809601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49937726657428, -0.08127255930047964 ]
  },
  "id_str" : "766189730350370817",
  "in_reply_to_user_id" : 14179278,
  "text" : "@tante yes, I don\u2019t wanna know how much time I\u2019ve wasted in switching in the past!",
  "id" : 766189730350370817,
  "in_reply_to_status_id" : 766189464934809601,
  "created_at" : "2016-08-18 08:27:21 +0000",
  "in_reply_to_screen_name" : "tante",
  "in_reply_to_user_id_str" : "14179278",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49793912502064, -0.0801477337739635 ]
  },
  "id_str" : "766186402451165184",
  "text" : "I\u2019m probably the last person to find out that SwiftKey allows you to have a truly bilingual keyboard that doesn\u2019t require input switching m)",
  "id" : 766186402451165184,
  "created_at" : "2016-08-18 08:14:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "indices" : [ 3, 13 ],
      "id_str" : "35304791",
      "id" : 35304791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/d03BN0u7Ia",
      "expanded_url" : "https:\/\/twitter.com\/stuartpstevens\/status\/766115174654803968",
      "display_url" : "twitter.com\/stuartpstevens\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766179566872330241",
  "text" : "RT @razibkhan: switch to Pandas or Julia https:\/\/t.co\/d03BN0u7Ia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 49 ],
        "url" : "https:\/\/t.co\/d03BN0u7Ia",
        "expanded_url" : "https:\/\/twitter.com\/stuartpstevens\/status\/766115174654803968",
        "display_url" : "twitter.com\/stuartpstevens\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766115282804846592",
    "text" : "switch to Pandas or Julia https:\/\/t.co\/d03BN0u7Ia",
    "id" : 766115282804846592,
    "created_at" : "2016-08-18 03:31:31 +0000",
    "user" : {
      "name" : "Razib Khan",
      "screen_name" : "razibkhan",
      "protected" : false,
      "id_str" : "35304791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/890083843385958400\/YKPy0Uup_normal.jpg",
      "id" : 35304791,
      "verified" : true
    }
  },
  "id" : 766179566872330241,
  "created_at" : "2016-08-18 07:46:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 7, 21 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766178417607860224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49473900445876, -0.08489065803595343 ]
  },
  "id_str" : "766178697523126276",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc @Protohedgehog thanks, and thanks for the support!",
  "id" : 766178697523126276,
  "in_reply_to_status_id" : 766178417607860224,
  "created_at" : "2016-08-18 07:43:31 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766175726441750528\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uc5ua4gnxf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqIAwhZXYAAnzN2.jpg",
      "id_str" : "766175720204886016",
      "id" : 766175720204886016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqIAwhZXYAAnzN2.jpg",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 236
      } ],
      "display_url" : "pic.twitter.com\/uc5ua4gnxf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48491801495935, -0.0832208737262585 ]
  },
  "id_str" : "766175726441750528",
  "text" : "Crowdfunding: first thing one of your partners asks at waking up is \u201Chow are your profits?\u201D https:\/\/t.co\/wmnWHMdnMe https:\/\/t.co\/uc5ua4gnxf",
  "id" : 766175726441750528,
  "created_at" : "2016-08-18 07:31:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/rtuIfWgLLJ",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/766012846350139392",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "766012846350139392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4814879160793, -0.08387664966152242 ]
  },
  "id_str" : "766052669769351168",
  "in_reply_to_user_id" : 14286491,
  "text" : "I\u2019ll leave this here one more time and hope it will be at over 700 when I wake up. \uD83D\uDE4F https:\/\/t.co\/rtuIfWgLLJ",
  "id" : 766052669769351168,
  "in_reply_to_status_id" : 766012846350139392,
  "created_at" : "2016-08-17 23:22:43 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/HVg1fCafnH",
      "expanded_url" : "https:\/\/twitter.com\/Gurdur\/status\/765974035079593984",
      "display_url" : "twitter.com\/Gurdur\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48144889897181, -0.08384817280768164 ]
  },
  "id_str" : "766049109069459456",
  "text" : "Where are those \u2018Drug-fuelled \u201Cchemsex\u201D parties\u2019? I feel you\u2019re letting me down, London! https:\/\/t.co\/HVg1fCafnH",
  "id" : 766049109069459456,
  "created_at" : "2016-08-17 23:08:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Siouxsie Wiles",
      "screen_name" : "SiouxsieW",
      "indices" : [ 15, 25 ],
      "id_str" : "356788303",
      "id" : 356788303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766015892937408516",
  "geo" : { },
  "id_str" : "766016215059984385",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @SiouxsieW thanks for sharing! :-)",
  "id" : 766016215059984385,
  "in_reply_to_status_id" : 766015892937408516,
  "created_at" : "2016-08-17 20:57:52 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766013671734738948",
  "geo" : { },
  "id_str" : "766013722196373504",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog \uD83D\uDE0D sure!",
  "id" : 766013722196373504,
  "in_reply_to_status_id" : 766013671734738948,
  "created_at" : "2016-08-17 20:47:57 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766013480268955650",
  "geo" : { },
  "id_str" : "766013566352850944",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog yes, you\u2019re a good hipster and got over the paywall before it was cool.",
  "id" : 766013566352850944,
  "in_reply_to_status_id" : 766013480268955650,
  "created_at" : "2016-08-17 20:47:20 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766013039988670465",
  "geo" : { },
  "id_str" : "766013309065760768",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks you got the privilege of being the last to pay 38\u20AC for this instead of the increased 40\u20AC!",
  "id" : 766013309065760768,
  "in_reply_to_status_id" : 766013039988670465,
  "created_at" : "2016-08-17 20:46:19 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 28, 42 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/wmnWHMdnMe",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr\/1756182",
      "display_url" : "igg.me\/p\/1861431\/twtr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766012846350139392",
  "text" : "Wow, you folks are awesome. @Protohedgehog and I were briefly out of paywalls. That\u2019s why we added a new one. https:\/\/t.co\/wmnWHMdnMe",
  "id" : 766012846350139392,
  "created_at" : "2016-08-17 20:44:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/FCt1d5yrR6",
      "expanded_url" : "http:\/\/www.michaeleisen.org\/blog\/?p=1925",
      "display_url" : "michaeleisen.org\/blog\/?p=1925"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.505335, -0.132002 ]
  },
  "id_str" : "765962135574876160",
  "text" : "The complete review on what population genetics has to say about Olympic success of West African sprinters https:\/\/t.co\/FCt1d5yrR6",
  "id" : 765962135574876160,
  "created_at" : "2016-08-17 17:22:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 86, 96 ],
      "id_str" : "34732474",
      "id" : 34732474
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 121, 137 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/q7Ew5CvxNz",
      "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr",
      "display_url" : "igg.me\/p\/1861431\/twtr"
    } ]
  },
  "geo" : { },
  "id_str" : "765956194355802113",
  "text" : "RT @o_guest: aaaaalso Help make it happen for Help Bastian and Jon get to OpenCon! on @indiegogo https:\/\/t.co\/q7Ew5CvxNz @gedankenstuecke @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Indiegogo",
        "screen_name" : "Indiegogo",
        "indices" : [ 73, 83 ],
        "id_str" : "34732474",
        "id" : 34732474
      }, {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 108, 124 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Jon Tennant",
        "screen_name" : "Protohedgehog",
        "indices" : [ 125, 139 ],
        "id_str" : "352650591",
        "id" : 352650591
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/q7Ew5CvxNz",
        "expanded_url" : "https:\/\/igg.me\/p\/1861431\/twtr",
        "display_url" : "igg.me\/p\/1861431\/twtr"
      } ]
    },
    "in_reply_to_status_id_str" : "765926156147318784",
    "geo" : { },
    "id_str" : "765926306961915905",
    "in_reply_to_user_id" : 3865005196,
    "text" : "aaaaalso Help make it happen for Help Bastian and Jon get to OpenCon! on @indiegogo https:\/\/t.co\/q7Ew5CvxNz @gedankenstuecke @Protohedgehog",
    "id" : 765926306961915905,
    "in_reply_to_status_id" : 765926156147318784,
    "created_at" : "2016-08-17 15:00:36 +0000",
    "in_reply_to_screen_name" : "o_guest",
    "in_reply_to_user_id_str" : "3865005196",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 765956194355802113,
  "created_at" : "2016-08-17 16:59:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steph\u24D0nie Wright",
      "screen_name" : "shefw",
      "indices" : [ 0, 6 ],
      "id_str" : "48636190",
      "id" : 48636190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765923134989934593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50442039598851, -0.1312839891762764 ]
  },
  "id_str" : "765955299391963136",
  "in_reply_to_user_id" : 48636190,
  "text" : "@shefw thanks so much!",
  "id" : 765955299391963136,
  "in_reply_to_status_id" : 765923134989934593,
  "created_at" : "2016-08-17 16:55:48 +0000",
  "in_reply_to_screen_name" : "shefw",
  "in_reply_to_user_id_str" : "48636190",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bi\u24D0nca Kramer",
      "screen_name" : "MsPhelps",
      "indices" : [ 0, 9 ],
      "id_str" : "22963112",
      "id" : 22963112
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765945844227080192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50779074368279, -0.1330051477515455 ]
  },
  "id_str" : "765949527769673728",
  "in_reply_to_user_id" : 22963112,
  "text" : "@MsPhelps @Protohedgehog thanks so much!",
  "id" : 765949527769673728,
  "in_reply_to_status_id" : 765945844227080192,
  "created_at" : "2016-08-17 16:32:52 +0000",
  "in_reply_to_screen_name" : "MsPhelps",
  "in_reply_to_user_id_str" : "22963112",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 29, 43 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 11, 27 ]
    }, {
      "text" : "opencon",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6lTHLsGBVI",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/2097191#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50612268645862, -0.1315452177779991 ]
  },
  "id_str" : "765932956762374144",
  "text" : "Related to #scienceisglobal: @Protohedgehog and I are looking for kind souls to help us with our airfare to #opencon https:\/\/t.co\/6lTHLsGBVI",
  "id" : 765932956762374144,
  "created_at" : "2016-08-17 15:27:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 35, 48 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 63, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50608273307, -0.1315280131239058 ]
  },
  "id_str" : "765931968118812672",
  "text" : "Just had the nicest meeting at the @royalsociety to chat about #scienceisglobal!",
  "id" : 765931968118812672,
  "created_at" : "2016-08-17 15:23:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765926962342821888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.5063221659991, -0.1326247584075971 ]
  },
  "id_str" : "765931713281294336",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest thanks so much!",
  "id" : 765931713281294336,
  "in_reply_to_status_id" : 765926962342821888,
  "created_at" : "2016-08-17 15:22:05 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Gondol",
      "screen_name" : "jangondol",
      "indices" : [ 0, 10 ],
      "id_str" : "94997082",
      "id" : 94997082
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 11, 25 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765902462511439872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49857942595739, -0.1120856148286328 ]
  },
  "id_str" : "765903210645168129",
  "in_reply_to_user_id" : 94997082,
  "text" : "@jangondol @Protohedgehog thanks for sharing!",
  "id" : 765903210645168129,
  "in_reply_to_status_id" : 765902462511439872,
  "created_at" : "2016-08-17 13:28:49 +0000",
  "in_reply_to_screen_name" : "jangondol",
  "in_reply_to_user_id_str" : "94997082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 7, 15 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49472727355224, -0.09760945131434225 ]
  },
  "id_str" : "765901920993239040",
  "text" : "Thanks @tonyR_H, 7 people already willingly ran into our crowdfunding paywall \uD83D\uDE02 https:\/\/t.co\/ERLbKXkt99",
  "id" : 765901920993239040,
  "created_at" : "2016-08-17 13:23:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765892382395133952",
  "geo" : { },
  "id_str" : "765894985808015361",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @Protohedgehog you better make some time for drinks and don\u2019t bail out last minute like in Paris! \uD83D\uDE02",
  "id" : 765894985808015361,
  "in_reply_to_status_id" : 765892382395133952,
  "created_at" : "2016-08-17 12:56:08 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kostas repanas",
      "screen_name" : "krepanas",
      "indices" : [ 0, 9 ],
      "id_str" : "70570429",
      "id" : 70570429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765891775886229508",
  "in_reply_to_user_id" : 70570429,
  "text" : "@krepanas Thanks so much for the support! :-) \uD83C\uDF89 \uD83D\uDE0D",
  "id" : 765891775886229508,
  "created_at" : "2016-08-17 12:43:23 +0000",
  "in_reply_to_screen_name" : "krepanas",
  "in_reply_to_user_id_str" : "70570429",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sujai Kumar",
      "screen_name" : "sujaik",
      "indices" : [ 0, 7 ],
      "id_str" : "33651124",
      "id" : 33651124
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 8, 22 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765891147222937600",
  "geo" : { },
  "id_str" : "765891569430003712",
  "in_reply_to_user_id" : 33651124,
  "text" : "@sujaik @Protohedgehog thanks, we\u2019ll keep that coming! :-)",
  "id" : 765891569430003712,
  "in_reply_to_status_id" : 765891147222937600,
  "created_at" : "2016-08-17 12:42:34 +0000",
  "in_reply_to_screen_name" : "sujaik",
  "in_reply_to_user_id_str" : "33651124",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765890404512325632",
  "geo" : { },
  "id_str" : "765891483832619008",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @Protohedgehog Thanks so much! \uD83C\uDF89\uD83D\uDC98",
  "id" : 765891483832619008,
  "in_reply_to_status_id" : 765890404512325632,
  "created_at" : "2016-08-17 12:42:13 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 0, 9 ],
      "id_str" : "14245811",
      "id" : 14245811
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lars Juhl Jensen",
      "screen_name" : "larsjuhljensen",
      "indices" : [ 25, 40 ],
      "id_str" : "14962567",
      "id" : 14962567
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 41, 47 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765885640294694912",
  "geo" : { },
  "id_str" : "765885917760462849",
  "in_reply_to_user_id" : 14245811,
  "text" : "@wilbanks @Protohedgehog @larsjuhljensen @Lobot some publisher\u2019s rep. ;)",
  "id" : 765885917760462849,
  "in_reply_to_status_id" : 765885640294694912,
  "created_at" : "2016-08-17 12:20:06 +0000",
  "in_reply_to_screen_name" : "wilbanks",
  "in_reply_to_user_id_str" : "14245811",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lars Juhl Jensen",
      "screen_name" : "larsjuhljensen",
      "indices" : [ 15, 30 ],
      "id_str" : "14962567",
      "id" : 14962567
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 31, 37 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 38, 47 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neverforget",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765881312544686080",
  "geo" : { },
  "id_str" : "765881601251311616",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @larsjuhljensen @Lobot @wilbanks that\u2019s why I add it to the slides. #neverforget :p",
  "id" : 765881601251311616,
  "in_reply_to_status_id" : 765881312544686080,
  "created_at" : "2016-08-17 12:02:57 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Juhl Jensen",
      "screen_name" : "larsjuhljensen",
      "indices" : [ 0, 15 ],
      "id_str" : "14962567",
      "id" : 14962567
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 16, 30 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 31, 37 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 38, 47 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765876424125349889",
  "geo" : { },
  "id_str" : "765876575925657600",
  "in_reply_to_user_id" : 14962567,
  "text" : "@larsjuhljensen @Protohedgehog @Lobot @wilbanks I show a gif of this as the last slide on each of my openSNP presentations. \uD83D\uDC36\uD83D\uDC83",
  "id" : 765876575925657600,
  "in_reply_to_status_id" : 765876424125349889,
  "created_at" : "2016-08-17 11:42:59 +0000",
  "in_reply_to_screen_name" : "larsjuhljensen",
  "in_reply_to_user_id_str" : "14962567",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 7, 21 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765875273493602304",
  "geo" : { },
  "id_str" : "765875370235166720",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Protohedgehog all the steps up Capital Hill.",
  "id" : 765875370235166720,
  "in_reply_to_status_id" : 765875273493602304,
  "created_at" : "2016-08-17 11:38:12 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 3, 9 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 29, 45 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/zh8zuvrgyw",
      "expanded_url" : "http:\/\/puppytoob.com\/wp-content\/uploads\/sites\/3\/2011\/10\/dog-in-plane.jpg",
      "display_url" : "puppytoob.com\/wp-content\/upl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765874744478629888",
  "text" : "RT @Lobot: \"Get a picture of @gedankenstuecke in a dog costume flying a plane\" should totally be a perk https:\/\/t.co\/zh8zuvrgyw https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 18, 34 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/zh8zuvrgyw",
        "expanded_url" : "http:\/\/puppytoob.com\/wp-content\/uploads\/sites\/3\/2011\/10\/dog-in-plane.jpg",
        "display_url" : "puppytoob.com\/wp-content\/upl\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Xs8NaUMLtT",
        "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/765830610904555520",
        "display_url" : "twitter.com\/Protohedgehog\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765874218110160896",
    "text" : "\"Get a picture of @gedankenstuecke in a dog costume flying a plane\" should totally be a perk https:\/\/t.co\/zh8zuvrgyw https:\/\/t.co\/Xs8NaUMLtT",
    "id" : 765874218110160896,
    "created_at" : "2016-08-17 11:33:37 +0000",
    "user" : {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "protected" : false,
      "id_str" : "1492631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783617256173494272\/7QL2FeUx_normal.jpg",
      "id" : 1492631,
      "verified" : false
    }
  },
  "id" : 765874744478629888,
  "created_at" : "2016-08-17 11:35:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 13, 27 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/SOt0iGOSqy",
      "expanded_url" : "http:\/\/i.makeagif.com\/media\/9-12-2015\/OJChso.gif",
      "display_url" : "i.makeagif.com\/media\/9-12-201\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "765874218110160896",
  "geo" : { },
  "id_str" : "765874634747211776",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well, @Protohedgehog and I did think about dressing up in T-Rex costumes. https:\/\/t.co\/SOt0iGOSqy",
  "id" : 765874634747211776,
  "in_reply_to_status_id" : 765874218110160896,
  "created_at" : "2016-08-17 11:35:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/FeawDZUGXH",
      "expanded_url" : "http:\/\/www.newstatesman.com\/politics\/uk\/2016\/08\/many-my-fearful-frustrated-generation-having-it-all-means-opting-out-monogamy",
      "display_url" : "newstatesman.com\/politics\/uk\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765860195188768768",
  "text" : "\u00ABPolyamory is a great many things, but it is not cool. Talking honestly about\u00A0feelings will never be cool.\u00BB https:\/\/t.co\/FeawDZUGXH",
  "id" : 765860195188768768,
  "created_at" : "2016-08-17 10:37:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 30, 46 ],
      "id_str" : "14286491",
      "id" : 14286491
    }, {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 79, 89 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/3yV8fYOCDa",
      "expanded_url" : "https:\/\/igg.me\/at\/opencon\/2097191",
      "display_url" : "igg.me\/at\/opencon\/209\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765858329646235648",
  "text" : "RT @Protohedgehog: We're off! @gedankenstuecke and myself are crowdfunding via @indiegogo to get to #opencon https:\/\/t.co\/3yV8fYOCDa Please\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 11, 27 ],
        "id_str" : "14286491",
        "id" : 14286491
      }, {
        "name" : "Indiegogo",
        "screen_name" : "Indiegogo",
        "indices" : [ 60, 70 ],
        "id_str" : "34732474",
        "id" : 34732474
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 81, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/3yV8fYOCDa",
        "expanded_url" : "https:\/\/igg.me\/at\/opencon\/2097191",
        "display_url" : "igg.me\/at\/opencon\/209\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765830610904555520",
    "text" : "We're off! @gedankenstuecke and myself are crowdfunding via @indiegogo to get to #opencon https:\/\/t.co\/3yV8fYOCDa Please share\/support! :)",
    "id" : 765830610904555520,
    "created_at" : "2016-08-17 08:40:20 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 765858329646235648,
  "created_at" : "2016-08-17 10:30:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Mkd51KDH2a",
      "expanded_url" : "https:\/\/twitter.com\/EikoFried\/status\/764924616448106497",
      "display_url" : "twitter.com\/EikoFried\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765851377700667393",
  "text" : "How to email anyone basically. Especially the part about the action items. https:\/\/t.co\/Mkd51KDH2a",
  "id" : 765851377700667393,
  "created_at" : "2016-08-17 10:02:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Achintya Rao \u2022 \u0C85\u0C9A\u0CBF\u0C82\u0CA4\u0CCD\u0CAF \u0CB0\u0CBE\u0CB5",
      "screen_name" : "RaoOfPhysics",
      "indices" : [ 0, 13 ],
      "id_str" : "67529128",
      "id" : 67529128
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 14, 28 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765841757976354816",
  "geo" : { },
  "id_str" : "765845132851699712",
  "in_reply_to_user_id" : 67529128,
  "text" : "@RaoOfPhysics @Protohedgehog thanks! \uD83D\uDE0D",
  "id" : 765845132851699712,
  "in_reply_to_status_id" : 765841757976354816,
  "created_at" : "2016-08-17 09:38:03 +0000",
  "in_reply_to_screen_name" : "RaoOfPhysics",
  "in_reply_to_user_id_str" : "67529128",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 13, 27 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765844537025630208",
  "geo" : { },
  "id_str" : "765845040182751232",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @Protohedgehog awesome, thanks so much! For once I\u2019m happy you didn\u2019t use sci-hub :P",
  "id" : 765845040182751232,
  "in_reply_to_status_id" : 765844537025630208,
  "created_at" : "2016-08-17 09:37:40 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 68, 82 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/765841934933950464\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/is3bmQgX3n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqDRJ9LWAAAJL1j.jpg",
      "id_str" : "765841905624154112",
      "id" : 765841905624154112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqDRJ9LWAAAJL1j.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/is3bmQgX3n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765841479638147072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49991654888803, -0.07824253384894106 ]
  },
  "id_str" : "765841934933950464",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yes, these two can be yours. And I\u2019ll even put in one from @Protohedgehog ;) https:\/\/t.co\/is3bmQgX3n",
  "id" : 765841934933950464,
  "in_reply_to_status_id" : 765841479638147072,
  "created_at" : "2016-08-17 09:25:20 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather L. Wiencko",
      "screen_name" : "HLWiencko",
      "indices" : [ 0, 10 ],
      "id_str" : "2657942712",
      "id" : 2657942712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765838567708975104",
  "geo" : { },
  "id_str" : "765839148330745856",
  "in_reply_to_user_id" : 2657942712,
  "text" : "@HLWiencko thanks so much!",
  "id" : 765839148330745856,
  "in_reply_to_status_id" : 765838567708975104,
  "created_at" : "2016-08-17 09:14:16 +0000",
  "in_reply_to_screen_name" : "HLWiencko",
  "in_reply_to_user_id_str" : "2657942712",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 0, 10 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765834024896065536",
  "geo" : { },
  "id_str" : "765834680000192512",
  "in_reply_to_user_id" : 734667419055230976,
  "text" : "@l_matthia thanks! \uD83D\uDE0D",
  "id" : 765834680000192512,
  "in_reply_to_status_id" : 765834024896065536,
  "created_at" : "2016-08-17 08:56:30 +0000",
  "in_reply_to_screen_name" : "l_matthia",
  "in_reply_to_user_id_str" : "734667419055230976",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 4, 18 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ERLbKXkt99",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/help-bastian-and-jon-get-to-opencon-science-education\/x\/1756182#\/",
      "display_url" : "indiegogo.com\/projects\/help-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765832746224742400",
  "text" : "So, @Protohedgehog and I are looking for a bit of money to get to #opencon, please consider contributing! https:\/\/t.co\/ERLbKXkt99",
  "id" : 765832746224742400,
  "created_at" : "2016-08-17 08:48:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Bishop",
      "screen_name" : "MandiBPro",
      "indices" : [ 0, 10 ],
      "id_str" : "705287821",
      "id" : 705287821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765720935529873408",
  "geo" : { },
  "id_str" : "765829837281951744",
  "in_reply_to_user_id" : 705287821,
  "text" : "@MandiBPro such a great time!",
  "id" : 765829837281951744,
  "in_reply_to_status_id" : 765720935529873408,
  "created_at" : "2016-08-17 08:37:16 +0000",
  "in_reply_to_screen_name" : "MandiBPro",
  "in_reply_to_user_id_str" : "705287821",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50026087773018, -0.07985978816116827 ]
  },
  "id_str" : "765827912440438784",
  "text" : "Best part about walking to the office: all the \uD83D\uDC36 in the parks!",
  "id" : 765827912440438784,
  "created_at" : "2016-08-17 08:29:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/765439309184962560\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/U9tMndUj1F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp9i_oRXYAAqx3E.jpg",
      "id_str" : "765439306957807616",
      "id" : 765439306957807616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp9i_oRXYAAqx3E.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1703,
        "resize" : "fit",
        "w" : 1277
      }, {
        "h" : 1703,
        "resize" : "fit",
        "w" : 1277
      } ],
      "display_url" : "pic.twitter.com\/U9tMndUj1F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765718293856542720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48147355508566, -0.08387677268256051 ]
  },
  "id_str" : "765809964258619392",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yes! See  https:\/\/t.co\/U9tMndUj1F send me an address and I\u2019ll do a second mail run. I still have two with me :D",
  "id" : 765809964258619392,
  "in_reply_to_status_id" : 765718293856542720,
  "created_at" : "2016-08-17 07:18:18 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/zP7YUcZOxo",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/765564431002656768",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "765564431002656768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48146598776334, -0.08399787192167003 ]
  },
  "id_str" : "765686943858454532",
  "in_reply_to_user_id" : 14286491,
  "text" : "Someone also should do a study into how sentiment analysis horribly fails for people with an interest in BDSM. https:\/\/t.co\/zP7YUcZOxo",
  "id" : 765686943858454532,
  "in_reply_to_status_id" : 765564431002656768,
  "created_at" : "2016-08-16 23:09:27 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clockwork Synergy",
      "screen_name" : "cwsynergy",
      "indices" : [ 0, 10 ],
      "id_str" : "720356180",
      "id" : 720356180
    }, {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 11, 18 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765680672312848384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48150736451873, -0.08388553540325384 ]
  },
  "id_str" : "765686645920268288",
  "in_reply_to_user_id" : 720356180,
  "text" : "@cwsynergy @yaccin awesome, can\u2019t wait for the delivery. :)",
  "id" : 765686645920268288,
  "in_reply_to_status_id" : 765680672312848384,
  "created_at" : "2016-08-16 23:08:16 +0000",
  "in_reply_to_screen_name" : "cwsynergy",
  "in_reply_to_user_id_str" : "720356180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ira Glass",
      "screen_name" : "iraglass",
      "indices" : [ 23, 32 ],
      "id_str" : "14589511",
      "id" : 14589511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50245407820678, -0.07754448611109004 ]
  },
  "id_str" : "765678837858459649",
  "text" : "Thanks for the evening @iraglass, more than well done on the dancing! \uD83D\uDC83",
  "id" : 765678837858459649,
  "created_at" : "2016-08-16 22:37:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/765678164366557184\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/yXQFNVuqjn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqA8O1oXgAEUJqJ.jpg",
      "id_str" : "765678162265210881",
      "id" : 765678162265210881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqA8O1oXgAEUJqJ.jpg",
      "sizes" : [ {
        "h" : 1417,
        "resize" : "fit",
        "w" : 1063
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1417,
        "resize" : "fit",
        "w" : 1063
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/yXQFNVuqjn"
    } ],
    "hashtags" : [ {
      "text" : "brexit",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.505755, -0.075641 ]
  },
  "id_str" : "765678164366557184",
  "text" : "Another thing that's much cheaper post-#brexit https:\/\/t.co\/yXQFNVuqjn",
  "id" : 765678164366557184,
  "created_at" : "2016-08-16 22:34:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "malech maltz",
      "screen_name" : "malech",
      "indices" : [ 19, 26 ],
      "id_str" : "784085846391713793",
      "id" : 784085846391713793
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/765669847564951552\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/5JuuZ5P7Om",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqA0p74WIAAK4_G.jpg",
      "id_str" : "765669831706288128",
      "id" : 765669831706288128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqA0p74WIAAK4_G.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/5JuuZ5P7Om"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50608538661613, -0.1171669046238326 ]
  },
  "id_str" : "765669847564951552",
  "text" : "Look what I found, @malech! https:\/\/t.co\/5JuuZ5P7Om",
  "id" : 765669847564951552,
  "created_at" : "2016-08-16 22:01:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50614359697569, -0.1169966976733319 ]
  },
  "id_str" : "765615048693809152",
  "text" : "Stickers: \u2714\uFE0F\nTAL: proceeding.",
  "id" : 765615048693809152,
  "created_at" : "2016-08-16 18:23:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "not best practice",
      "screen_name" : "moeffju",
      "indices" : [ 0, 8 ],
      "id_str" : "5618832",
      "id" : 5618832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765590017053982720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50615962498244, -0.1166703053493251 ]
  },
  "id_str" : "765614807391297536",
  "in_reply_to_user_id" : 5618832,
  "text" : "@moeffju that\u2019s where I found the one I posted. And that one has all the code and not only excerpts :)",
  "id" : 765614807391297536,
  "in_reply_to_status_id" : 765590017053982720,
  "created_at" : "2016-08-16 18:22:49 +0000",
  "in_reply_to_screen_name" : "moeffju",
  "in_reply_to_user_id_str" : "5618832",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/tVs9XdcANf",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view4\/20141213\/5148512\/fight-to-the-death-o.gif",
      "display_url" : "stream1.gifsoup.com\/view4\/20141213\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "765567212547563520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49969749968789, -0.1069996254248372 ]
  },
  "id_str" : "765575544733831168",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy for a fight to the death? https:\/\/t.co\/tVs9XdcANf",
  "id" : 765575544733831168,
  "in_reply_to_status_id" : 765567212547563520,
  "created_at" : "2016-08-16 15:46:48 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/zP7YUcZOxo",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/765564431002656768",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "765564431002656768",
  "geo" : { },
  "id_str" : "765564539479920640",
  "in_reply_to_user_id" : 14286491,
  "text" : "\u00ABDo you want to be the Android or the iPhone?\u00BB https:\/\/t.co\/zP7YUcZOxo",
  "id" : 765564539479920640,
  "in_reply_to_status_id" : 765564431002656768,
  "created_at" : "2016-08-16 15:03:04 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/F7Lo0mLKeF",
      "expanded_url" : "https:\/\/github.com\/dgrtwo\/dgrtwo.github.com\/blob\/master\/_R\/2016-08-09-trump-tweets.Rmd",
      "display_url" : "github.com\/dgrtwo\/dgrtwo.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765564431002656768",
  "text" : "data-driven relationships: running sentiment analysis on your chat logs with your significant others. https:\/\/t.co\/F7Lo0mLKeF",
  "id" : 765564431002656768,
  "created_at" : "2016-08-16 15:02:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 0, 10 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765543383268032512",
  "geo" : { },
  "id_str" : "765544470951653376",
  "in_reply_to_user_id" : 22839233,
  "text" : "@kaythaney all the best for the new frontiers! \uD83D\uDC96",
  "id" : 765544470951653376,
  "in_reply_to_status_id" : 765543383268032512,
  "created_at" : "2016-08-16 13:43:19 +0000",
  "in_reply_to_screen_name" : "kaythaney",
  "in_reply_to_user_id_str" : "22839233",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765543711321231360",
  "geo" : { },
  "id_str" : "765544125588439040",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot my name Ropen Mars and this is 99% inaccessible data!",
  "id" : 765544125588439040,
  "in_reply_to_status_id" : 765543711321231360,
  "created_at" : "2016-08-16 13:41:57 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/9usn03922j",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BJK98rzjjBZ\/",
      "display_url" : "instagram.com\/p\/BJK98rzjjBZ\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49934, -0.07841 ]
  },
  "id_str" : "765541754779144192",
  "text" : "Having a nice temporary office in walking distance from the temporary home \uD83D\uDC98 @ Worldview Impact https:\/\/t.co\/9usn03922j",
  "id" : 765541754779144192,
  "created_at" : "2016-08-16 13:32:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765536516202434560",
  "geo" : { },
  "id_str" : "765536691050381312",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski fingers crossed. \uD83D\uDC4C",
  "id" : 765536691050381312,
  "in_reply_to_status_id" : 765536516202434560,
  "created_at" : "2016-08-16 13:12:24 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765536330868719616",
  "geo" : { },
  "id_str" : "765536422933696512",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski but i guess at least for now much more energy inefficient than going plant based :)",
  "id" : 765536422933696512,
  "in_reply_to_status_id" : 765536330868719616,
  "created_at" : "2016-08-16 13:11:20 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/k3bC9V62uv",
      "expanded_url" : "http:\/\/www.impossiblefoods.com\/",
      "display_url" : "impossiblefoods.com"
    } ]
  },
  "in_reply_to_status_id_str" : "765534436276445184",
  "geo" : { },
  "id_str" : "765534892084043776",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski did you see https:\/\/t.co\/k3bC9V62uv ?",
  "id" : 765534892084043776,
  "in_reply_to_status_id" : 765534436276445184,
  "created_at" : "2016-08-16 13:05:15 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765533314035908608",
  "geo" : { },
  "id_str" : "765534139877584896",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski sorry, I don\u2019t eat members of any Metazoan phyla I\u2019ve published on. Makes the selection shrink year by year.",
  "id" : 765534139877584896,
  "in_reply_to_status_id" : 765533314035908608,
  "created_at" : "2016-08-16 13:02:16 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/F8Dn9SLLeF",
      "expanded_url" : "https:\/\/twitter.com\/YourWildCity\/status\/765259461900529666",
      "display_url" : "twitter.com\/YourWildCity\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765533101011398657",
  "text" : "Now I want to envision the corresponding gastro-pub! https:\/\/t.co\/F8Dn9SLLeF",
  "id" : 765533101011398657,
  "created_at" : "2016-08-16 12:58:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Scanlan",
      "screen_name" : "JackLScanlan",
      "indices" : [ 0, 13 ],
      "id_str" : "10342612",
      "id" : 10342612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765527102393229312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49783408504663, -0.08013542714016762 ]
  },
  "id_str" : "765527858617937920",
  "in_reply_to_user_id" : 10342612,
  "text" : "@JackLScanlan yes, hope the author will release the scripts for the clean up!",
  "id" : 765527858617937920,
  "in_reply_to_status_id" : 765527102393229312,
  "created_at" : "2016-08-16 12:37:18 +0000",
  "in_reply_to_screen_name" : "JackLScanlan",
  "in_reply_to_user_id_str" : "10342612",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SMBE16",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/RR32BZlux1",
      "expanded_url" : "https:\/\/twitter.com\/PhilippBayer\/status\/765521424115113984",
      "display_url" : "twitter.com\/PhilippBayer\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49783408504663, -0.08013542714016762 ]
  },
  "id_str" : "765527629604720640",
  "text" : "Also a great summary of the #SMBE16 experience! https:\/\/t.co\/RR32BZlux1",
  "id" : 765527629604720640,
  "created_at" : "2016-08-16 12:36:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha Angrist",
      "screen_name" : "MishaAngrist",
      "indices" : [ 0, 13 ],
      "id_str" : "116877838",
      "id" : 116877838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/NdBlcqAdG4",
      "expanded_url" : "https:\/\/media.giphy.com\/media\/ge2382PgqfMT6\/giphy.gif",
      "display_url" : "media.giphy.com\/media\/ge2382Pg\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "765520083326214144",
  "geo" : { },
  "id_str" : "765521071974014976",
  "in_reply_to_user_id" : 116877838,
  "text" : "@MishaAngrist i\u2019ve heard worse comparisons. https:\/\/t.co\/NdBlcqAdG4",
  "id" : 765521071974014976,
  "in_reply_to_status_id" : 765520083326214144,
  "created_at" : "2016-08-16 12:10:20 +0000",
  "in_reply_to_screen_name" : "MishaAngrist",
  "in_reply_to_user_id_str" : "116877838",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luc Henry",
      "screen_name" : "heluc",
      "indices" : [ 0, 6 ],
      "id_str" : "850645992",
      "id" : 850645992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765519712117780480",
  "geo" : { },
  "id_str" : "765519904929882112",
  "in_reply_to_user_id" : 850645992,
  "text" : "@heluc the sad state where you have to VPN-tunnel outside your university to access a paywalled paper?",
  "id" : 765519904929882112,
  "in_reply_to_status_id" : 765519712117780480,
  "created_at" : "2016-08-16 12:05:42 +0000",
  "in_reply_to_screen_name" : "heluc",
  "in_reply_to_user_id_str" : "850645992",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Dn9qkECCvY",
      "expanded_url" : "http:\/\/www.nature.com.sci-hub.bz\/nrg\/journal\/v17\/n9\/abs\/nrg.2016.86.html",
      "display_url" : "nature.com.sci-hub.bz\/nrg\/journal\/v1\u2026"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/mgyKtOWmm2",
      "expanded_url" : "https:\/\/twitter.com\/MishaAngrist\/status\/765517196856528896",
      "display_url" : "twitter.com\/MishaAngrist\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765517784289861632",
  "text" : "And all of a sudden even every patient could read about precision medicine.  \u00AF\\_(\u30C4)_\/\u00AF https:\/\/t.co\/Dn9qkECCvY https:\/\/t.co\/mgyKtOWmm2",
  "id" : 765517784289861632,
  "created_at" : "2016-08-16 11:57:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Rik Smith-Unna \uD83C\uDDF0\uD83C\uDDEA",
      "screen_name" : "blahah404",
      "indices" : [ 0, 10 ],
      "id_str" : "99173786",
      "id" : 99173786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/jVCxqnd3iv",
      "expanded_url" : "http:\/\/99percentinvisible.org\/article\/flip-side-10-stories-behind-99pi-challenge-coin-symbols\/",
      "display_url" : "99percentinvisible.org\/article\/flip-s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "765508592350990336",
  "geo" : { },
  "id_str" : "765509130807279616",
  "in_reply_to_user_id" : 99173786,
  "text" : "@blahah404 the 99 percent invisible challenge coin, c.f. https:\/\/t.co\/jVCxqnd3iv",
  "id" : 765509130807279616,
  "in_reply_to_status_id" : 765508592350990336,
  "created_at" : "2016-08-16 11:22:53 +0000",
  "in_reply_to_screen_name" : "blahah404",
  "in_reply_to_user_id_str" : "99173786",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 70, 86 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openscience",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/nnEIdtlVIO",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
      "display_url" : "patreon.com\/openSNP"
    } ]
  },
  "geo" : { },
  "id_str" : "765503974636154880",
  "text" : "RT @Protohedgehog: Do you care about education and #openscience? Help @gedankenstuecke with his OpenSNP project! https:\/\/t.co\/nnEIdtlVIO #o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 51, 67 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openscience",
        "indices" : [ 32, 44 ]
      }, {
        "text" : "opendata",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/nnEIdtlVIO",
        "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
        "display_url" : "patreon.com\/openSNP"
      } ]
    },
    "geo" : { },
    "id_str" : "765503351371030528",
    "text" : "Do you care about education and #openscience? Help @gedankenstuecke with his OpenSNP project! https:\/\/t.co\/nnEIdtlVIO #opendata",
    "id" : 765503351371030528,
    "created_at" : "2016-08-16 10:59:55 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 765503974636154880,
  "created_at" : "2016-08-16 11:02:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/OprjH129UP",
      "expanded_url" : "https:\/\/www.patreon.com\/openSNP",
      "display_url" : "patreon.com\/openSNP"
    } ]
  },
  "in_reply_to_status_id_str" : "765477964955979776",
  "geo" : { },
  "id_str" : "765478930941870080",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant and depending on how bad you feel I\u2019ll point you to our Patreon page for absolution ;) (j\/k!) https:\/\/t.co\/OprjH129UP",
  "id" : 765478930941870080,
  "in_reply_to_status_id" : 765477964955979776,
  "created_at" : "2016-08-16 09:22:53 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765477964955979776",
  "geo" : { },
  "id_str" : "765478792068497409",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant Well we do make these stickers in order to hand them out to people, so no worries! :-)",
  "id" : 765478792068497409,
  "in_reply_to_status_id" : 765477964955979776,
  "created_at" : "2016-08-16 09:22:20 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/kHcHMteP6W",
      "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/765462848650686464",
      "display_url" : "twitter.com\/SCEdmunds\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765474823992709120",
  "text" : "Time to start working on an \u201Eopenome\u201C. https:\/\/t.co\/kHcHMteP6W",
  "id" : 765474823992709120,
  "created_at" : "2016-08-16 09:06:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bede Constantinides",
      "screen_name" : "beconstant",
      "indices" : [ 0, 11 ],
      "id_str" : "112876914",
      "id" : 112876914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765473780147847168",
  "geo" : { },
  "id_str" : "765473892852965376",
  "in_reply_to_user_id" : 112876914,
  "text" : "@beconstant sure, drop me your address via DM or whatever works for you and I\u2019ll mail some out!",
  "id" : 765473892852965376,
  "in_reply_to_status_id" : 765473780147847168,
  "created_at" : "2016-08-16 09:02:52 +0000",
  "in_reply_to_screen_name" : "beconstant",
  "in_reply_to_user_id_str" : "112876914",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    }, {
      "name" : "Clockwork Synergy",
      "screen_name" : "cwsynergy",
      "indices" : [ 8, 18 ],
      "id_str" : "720356180",
      "id" : 720356180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765465950804119553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49933097867244, -0.08121006503777146 ]
  },
  "id_str" : "765467335041974272",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin @cwsynergy pre-order it is then :p",
  "id" : 765467335041974272,
  "in_reply_to_status_id" : 765465950804119553,
  "created_at" : "2016-08-16 08:36:49 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andreas Klinger \u270C\uFE0F",
      "screen_name" : "andreasklinger",
      "indices" : [ 0, 15 ],
      "id_str" : "14946149",
      "id" : 14946149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765275156222574592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.49039252665964, -0.08462713100023998 ]
  },
  "id_str" : "765452922289258496",
  "in_reply_to_user_id" : 14946149,
  "text" : "@andreasklinger remember when we used to call it Fr\u00FChjahrsputz? ;)",
  "id" : 765452922289258496,
  "in_reply_to_status_id" : 765275156222574592,
  "created_at" : "2016-08-16 07:39:32 +0000",
  "in_reply_to_screen_name" : "andreasklinger",
  "in_reply_to_user_id_str" : "14946149",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765447788096212992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48167795103198, -0.08556982320431852 ]
  },
  "id_str" : "765449763991019520",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer sure why not!",
  "id" : 765449763991019520,
  "in_reply_to_status_id" : 765447788096212992,
  "created_at" : "2016-08-16 07:26:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD5E\uD83E\uDD84\u2728\uD83D\uDC69\u200D\uD83C\uDF3E",
      "screen_name" : "pikelet",
      "indices" : [ 0, 8 ],
      "id_str" : "6000702",
      "id" : 6000702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765126943414943745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4814213430011, -0.08383957786411209 ]
  },
  "id_str" : "765440480939311104",
  "in_reply_to_user_id" : 6000702,
  "text" : "@pikelet awesome, thanks so much!",
  "id" : 765440480939311104,
  "in_reply_to_status_id" : 765126943414943745,
  "created_at" : "2016-08-16 06:50:06 +0000",
  "in_reply_to_screen_name" : "pikelet",
  "in_reply_to_user_id_str" : "6000702",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/765439309184962560\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/U9tMndUj1F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp9i_oRXYAAqx3E.jpg",
      "id_str" : "765439306957807616",
      "id" : 765439306957807616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp9i_oRXYAAqx3E.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1703,
        "resize" : "fit",
        "w" : 1277
      }, {
        "h" : 1703,
        "resize" : "fit",
        "w" : 1277
      } ],
      "display_url" : "pic.twitter.com\/U9tMndUj1F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48149, -0.083998 ]
  },
  "id_str" : "765439309184962560",
  "text" : "Today's plan: sending out stickers and coin checking tons of people at the TAL live event. https:\/\/t.co\/U9tMndUj1F",
  "id" : 765439309184962560,
  "created_at" : "2016-08-16 06:45:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/kfgygdz9C0",
      "expanded_url" : "http:\/\/scholarworks.rit.edu\/cgi\/viewcontent.cgi?article=10331&context=theses",
      "display_url" : "scholarworks.rit.edu\/cgi\/viewconten\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48149, -0.0839 ]
  },
  "id_str" : "765437871524315137",
  "text" : "People start writing their master theses using the data from openSNP \uD83D\uDE0D https:\/\/t.co\/kfgygdz9C0",
  "id" : 765437871524315137,
  "created_at" : "2016-08-16 06:39:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765247409630879744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48142585572482, -0.0838163410403856 ]
  },
  "id_str" : "765330001512263680",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin thanks! but why preorder? \uD83D\uDE31",
  "id" : 765330001512263680,
  "in_reply_to_status_id" : 765247409630879744,
  "created_at" : "2016-08-15 23:31:06 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chai Guy",
      "screen_name" : "yaccin",
      "indices" : [ 0, 7 ],
      "id_str" : "23505101",
      "id" : 23505101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765170545163894785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.50497531988798, -0.08279794827111325 ]
  },
  "id_str" : "765238138839195648",
  "in_reply_to_user_id" : 23505101,
  "text" : "@yaccin do want!",
  "id" : 765238138839195648,
  "in_reply_to_status_id" : 765170545163894785,
  "created_at" : "2016-08-15 17:26:04 +0000",
  "in_reply_to_screen_name" : "yaccin",
  "in_reply_to_user_id_str" : "23505101",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5lwdfEC35w",
      "expanded_url" : "https:\/\/twitter.com\/OBF_BOSC\/status\/765181557665562624",
      "display_url" : "twitter.com\/OBF_BOSC\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765192589238644736",
  "text" : "Personally: doing all the open source-work in my spare time I like weekends. Otherwise have to use up vacation days. https:\/\/t.co\/5lwdfEC35w",
  "id" : 765192589238644736,
  "created_at" : "2016-08-15 14:25:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Nelson",
      "screen_name" : "blueyedgenes",
      "indices" : [ 0, 13 ],
      "id_str" : "760870811494297600",
      "id" : 760870811494297600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765184471926579201",
  "geo" : { },
  "id_str" : "765184641481469953",
  "in_reply_to_user_id" : 760870811494297600,
  "text" : "@blueyedgenes that\u2019s what I started doing. Also for all the taxa names of the fungi &amp; bacteria I have to deal with. ;)",
  "id" : 765184641481469953,
  "in_reply_to_status_id" : 765184471926579201,
  "created_at" : "2016-08-15 13:53:29 +0000",
  "in_reply_to_screen_name" : "blueyedgenes",
  "in_reply_to_user_id_str" : "760870811494297600",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765139319950548992",
  "text" : "One of the biggest issues with writing a paper about lichens in Word: It will sneakily try to spellcheck each \u201Ethallus\u201C into \u201Ephallus\u201C\u2026",
  "id" : 765139319950548992,
  "created_at" : "2016-08-15 10:53:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/p3xFhkvsuF",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/765125181840977920",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765134976555810817",
  "text" : "Let\u2019s say we\u2019re not getting a degree in cinematography any time soon. https:\/\/t.co\/p3xFhkvsuF",
  "id" : 765134976555810817,
  "created_at" : "2016-08-15 10:36:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yell in a War \uD83D\uDE32\uD83D\uDDEF\uFE0F",
      "screen_name" : "jelenawoehr",
      "indices" : [ 3, 15 ],
      "id_str" : "16638708",
      "id" : 16638708
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jelenawoehr\/status\/763907036123836416\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/LejZj2mp3m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpnxNtqUIAAuf9g.jpg",
      "id_str" : "763906829713678336",
      "id" : 763906829713678336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpnxNtqUIAAuf9g.jpg",
      "sizes" : [ {
        "h" : 394,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/LejZj2mp3m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765116094361337856",
  "text" : "RT @jelenawoehr: When they're too young to understand capital letters but old enough to be WOKE AF https:\/\/t.co\/LejZj2mp3m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jelenawoehr\/status\/763907036123836416\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/LejZj2mp3m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpnxNtqUIAAuf9g.jpg",
        "id_str" : "763906829713678336",
        "id" : 763906829713678336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpnxNtqUIAAuf9g.jpg",
        "sizes" : [ {
          "h" : 394,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/LejZj2mp3m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763907036123836416",
    "text" : "When they're too young to understand capital letters but old enough to be WOKE AF https:\/\/t.co\/LejZj2mp3m",
    "id" : 763907036123836416,
    "created_at" : "2016-08-12 01:16:44 +0000",
    "user" : {
      "name" : "Yell in a War \uD83D\uDE32\uD83D\uDDEF\uFE0F",
      "screen_name" : "jelenawoehr",
      "protected" : false,
      "id_str" : "16638708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926685453083820033\/hx6DAyVo_normal.jpg",
      "id" : 16638708,
      "verified" : false
    }
  },
  "id" : 765116094361337856,
  "created_at" : "2016-08-15 09:21:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 27, 41 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765112126436413440",
  "text" : "Just now saw the role that @Protohedgehog assigned to me for our crowdfunding: \u201EChief open data whip\u201C. \uD83D\uDE02",
  "id" : 765112126436413440,
  "created_at" : "2016-08-15 09:05:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 24, 34 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764952920542642176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48139425010755, -0.08415505096628252 ]
  },
  "id_str" : "764953936755322880",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog @l_matthia \uD83D\uDC98\uD83D\uDE0D",
  "id" : 764953936755322880,
  "in_reply_to_status_id" : 764952920542642176,
  "created_at" : "2016-08-14 22:36:45 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 15, 23 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Lisa Matthias",
      "screen_name" : "l_matthia",
      "indices" : [ 24, 34 ],
      "id_str" : "734667419055230976",
      "id" : 734667419055230976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764951452217438208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48140082210558, -0.08379210563043203 ]
  },
  "id_str" : "764951766307893249",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @o_guest @l_matthia dammit, I hoped for good ones. My are hilariously bad as well!",
  "id" : 764951766307893249,
  "in_reply_to_status_id" : 764951452217438208,
  "created_at" : "2016-08-14 22:28:07 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 15, 23 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764950698207408128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48140082210558, -0.08379210563043203 ]
  },
  "id_str" : "764951053334896640",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @o_guest don\u2019t spoil the real reason why we wanna share an airbnb at #opencon! (was already asked whether \u201Cpancakes\u201D is code)",
  "id" : 764951053334896640,
  "in_reply_to_status_id" : 764950698207408128,
  "created_at" : "2016-08-14 22:25:17 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764948135567319040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48140082210558, -0.08379210563043203 ]
  },
  "id_str" : "764950461975756802",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest @Protohedgehog we\u2019re not that close so far :p",
  "id" : 764950461975756802,
  "in_reply_to_status_id" : 764948135567319040,
  "created_at" : "2016-08-14 22:22:56 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Franzi Sattler",
      "screen_name" : "ohyeahfranzi",
      "indices" : [ 15, 28 ],
      "id_str" : "179214664",
      "id" : 179214664
    }, {
      "name" : "Dr Robin G. Andrews",
      "screen_name" : "SquigglyVolcano",
      "indices" : [ 29, 45 ],
      "id_str" : "300467000",
      "id" : 300467000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764921329674031105",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48148631083622, -0.08387809728034605 ]
  },
  "id_str" : "764943309198548992",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @ohyeahfranzi @SquigglyVolcano thanks to you then!",
  "id" : 764943309198548992,
  "in_reply_to_status_id" : 764921329674031105,
  "created_at" : "2016-08-14 21:54:31 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/764917611041882112\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/AL6oGxFlJL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp2IgyhWgAABt2F.jpg",
      "id_str" : "764917608621703168",
      "id" : 764917608621703168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp2IgyhWgAABt2F.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1400,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1400,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/AL6oGxFlJL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764917611041882112",
  "text" : "Found it very hard to resist this one! \uD83D\uDC36\uD83D\uDCF8 https:\/\/t.co\/AL6oGxFlJL",
  "id" : 764917611041882112,
  "created_at" : "2016-08-14 20:12:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764876007576899584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51287946165984, -0.1340520119932631 ]
  },
  "id_str" : "764916863897927680",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog awesome food recommendation mate, we liked it a lot!",
  "id" : 764916863897927680,
  "in_reply_to_status_id" : 764876007576899584,
  "created_at" : "2016-08-14 20:09:26 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764915028415971328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51290511670165, -0.1339759691989043 ]
  },
  "id_str" : "764916848034971648",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps me too! That\u2019s so sweet!",
  "id" : 764916848034971648,
  "in_reply_to_status_id" : 764915028415971328,
  "created_at" : "2016-08-14 20:09:22 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 71, 79 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/764899373155225600\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/XY6q0MKGHg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp137NrWgAAbnnv.jpg",
      "id_str" : "764899370890330112",
      "id" : 764899370890330112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp137NrWgAAbnnv.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1117,
        "resize" : "fit",
        "w" : 1489
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1117,
        "resize" : "fit",
        "w" : 1489
      } ],
      "display_url" : "pic.twitter.com\/XY6q0MKGHg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.512671, -0.139299 ]
  },
  "id_str" : "764899373155225600",
  "text" : "\u00ABI can't pronounce his name either.\u00BB the things you find in old books. @iaravps https:\/\/t.co\/XY6q0MKGHg",
  "id" : 764899373155225600,
  "created_at" : "2016-08-14 18:59:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764875588691759104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51252562446721, -0.1391400312426548 ]
  },
  "id_str" : "764884918673473537",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Protohedgehog hand delivered even!",
  "id" : 764884918673473537,
  "in_reply_to_status_id" : 764875588691759104,
  "created_at" : "2016-08-14 18:02:30 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/78jl2NBSeL",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/764876007576899584",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51271193767688, -0.1392566462748942 ]
  },
  "id_str" : "764884860959948800",
  "text" : "We\u2019re not drunk (yet). https:\/\/t.co\/78jl2NBSeL",
  "id" : 764884860959948800,
  "created_at" : "2016-08-14 18:02:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 10, 24 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/764870087656570881\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/DJBxIxaLXJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp1dRkBW8AARUXM.jpg",
      "id_str" : "764870068031385600",
      "id" : 764870068031385600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp1dRkBW8AARUXM.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/DJBxIxaLXJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764860419009814528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.51076219471037, -0.1339371199282454 ]
  },
  "id_str" : "764870087656570881",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Protohedgehog great. Recording our video for it now! https:\/\/t.co\/DJBxIxaLXJ",
  "id" : 764870087656570881,
  "in_reply_to_status_id" : 764860419009814528,
  "created_at" : "2016-08-14 17:03:34 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 15, 24 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764740829491634176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4812585153165, -0.08388658985503379 ]
  },
  "id_str" : "764765832828289024",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @Senficon great, let me know when you\u2019ll be in town!",
  "id" : 764765832828289024,
  "in_reply_to_status_id" : 764740829491634176,
  "created_at" : "2016-08-14 10:09:17 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Chealsye Bowley",
      "screen_name" : "chealsye",
      "indices" : [ 15, 24 ],
      "id_str" : "39194970",
      "id" : 39194970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764575550203625473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48145059944249, -0.08381515770420365 ]
  },
  "id_str" : "764587157768003584",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @chealsye we could add how opencon Berlin will benefit from us being there!",
  "id" : 764587157768003584,
  "in_reply_to_status_id" : 764575550203625473,
  "created_at" : "2016-08-13 22:19:18 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764565060719181825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48148797428819, -0.0838776321248198 ]
  },
  "id_str" : "764586550248239104",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps @Protohedgehog and totally would support such a patreon!",
  "id" : 764586550248239104,
  "in_reply_to_status_id" : 764565060719181825,
  "created_at" : "2016-08-13 22:16:53 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764565060719181825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48145746450712, -0.0838481213203842 ]
  },
  "id_str" : "764586463266742272",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps @Protohedgehog I\u2019d love for you to join the two of us, if that\u2019s an option for you!",
  "id" : 764586463266742272,
  "in_reply_to_status_id" : 764565060719181825,
  "created_at" : "2016-08-13 22:16:32 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/LK9VO72QVC",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/764530399599091712",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.48147094617018, -0.08383286216808832 ]
  },
  "id_str" : "764549187555954688",
  "text" : "Please do, that would be a great help! https:\/\/t.co\/LK9VO72QVC",
  "id" : 764549187555954688,
  "created_at" : "2016-08-13 19:48:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 3, 17 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 30, 46 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764549073688993792",
  "text" : "RT @Protohedgehog: Myself and @gedankenstuecke are launching a crowdfunding campaign to get to #opencon! Would anyone like to give us feedb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 11, 27 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opencon",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764530399599091712",
    "text" : "Myself and @gedankenstuecke are launching a crowdfunding campaign to get to #opencon! Would anyone like to give us feedback on a draft page?",
    "id" : 764530399599091712,
    "created_at" : "2016-08-13 18:33:46 +0000",
    "user" : {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "protected" : false,
      "id_str" : "352650591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/926545912167583744\/cocrzxXo_normal.jpg",
      "id" : 352650591,
      "verified" : true
    }
  },
  "id" : 764549073688993792,
  "created_at" : "2016-08-13 19:47:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "no",
      "screen_name" : "tbhjuststop",
      "indices" : [ 3, 15 ],
      "id_str" : "1416289596",
      "id" : 1416289596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764454513398939648",
  "text" : "RT @tbhjuststop: do not ever apologize for your dog coming up to me and jumping on me because it is exactly what I wanted",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764320324099899392",
    "text" : "do not ever apologize for your dog coming up to me and jumping on me because it is exactly what I wanted",
    "id" : 764320324099899392,
    "created_at" : "2016-08-13 04:39:00 +0000",
    "user" : {
      "name" : "no",
      "screen_name" : "tbhjuststop",
      "protected" : false,
      "id_str" : "1416289596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687877647100194816\/qWC6tjVX_normal.jpg",
      "id" : 1416289596,
      "verified" : false
    }
  },
  "id" : 764454513398939648,
  "created_at" : "2016-08-13 13:32:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arfon Smith",
      "screen_name" : "arfon",
      "indices" : [ 3, 9 ],
      "id_str" : "617243",
      "id" : 617243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/c36vOsvPlS",
      "expanded_url" : "http:\/\/genomebiology.biomedcentral.com\/articles\/10.1186\/s13059-016-1040-y",
      "display_url" : "genomebiology.biomedcentral.com\/articles\/10.11\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764453753479163904",
  "text" : "RT @arfon: Bravo! Genome Biology requires authors submitting code us an OSI-approved license https:\/\/t.co\/c36vOsvPlS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/c36vOsvPlS",
        "expanded_url" : "http:\/\/genomebiology.biomedcentral.com\/articles\/10.1186\/s13059-016-1040-y",
        "display_url" : "genomebiology.biomedcentral.com\/articles\/10.11\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764133926130421761",
    "text" : "Bravo! Genome Biology requires authors submitting code us an OSI-approved license https:\/\/t.co\/c36vOsvPlS",
    "id" : 764133926130421761,
    "created_at" : "2016-08-12 16:18:19 +0000",
    "user" : {
      "name" : "Arfon Smith",
      "screen_name" : "arfon",
      "protected" : false,
      "id_str" : "617243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636893419286102017\/uec_5Wn-_normal.jpg",
      "id" : 617243,
      "verified" : true
    }
  },
  "id" : 764453753479163904,
  "created_at" : "2016-08-13 13:29:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Effy Vayena",
      "screen_name" : "EffyVayena",
      "indices" : [ 0, 11 ],
      "id_str" : "397518511",
      "id" : 397518511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764441394874314753",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46997196399155, -0.451222362379844 ]
  },
  "id_str" : "764453537841643520",
  "in_reply_to_user_id" : 397518511,
  "text" : "@EffyVayena i want a degree in this!",
  "id" : 764453537841643520,
  "in_reply_to_status_id" : 764441394874314753,
  "created_at" : "2016-08-13 13:28:20 +0000",
  "in_reply_to_screen_name" : "EffyVayena",
  "in_reply_to_user_id_str" : "397518511",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Domingues",
      "screen_name" : "keyboardpipette",
      "indices" : [ 0, 16 ],
      "id_str" : "712172447223717888",
      "id" : 712172447223717888
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 17, 23 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 24, 30 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764443757190275072",
  "geo" : { },
  "id_str" : "764444502522290176",
  "in_reply_to_user_id" : 712172447223717888,
  "text" : "@keyboardpipette @Lobot @sciam that\u2019s the common wisdom that\u2019s rightfully widely accepted. \uD83D\uDC36\uD83D\uDC4C",
  "id" : 764444502522290176,
  "in_reply_to_status_id" : 764443757190275072,
  "created_at" : "2016-08-13 12:52:26 +0000",
  "in_reply_to_screen_name" : "keyboardpipette",
  "in_reply_to_user_id_str" : "712172447223717888",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/TWWIhPwxAZ",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BJC_2s_jGsH\/",
      "display_url" : "instagram.com\/p\/BJC_2s_jGsH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "764420046689099776",
  "text" : "I could spend hours in the arrivals hall. Wait, I do! https:\/\/t.co\/TWWIhPwxAZ",
  "id" : 764420046689099776,
  "created_at" : "2016-08-13 11:15:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764406934053224448",
  "geo" : { },
  "id_str" : "764407349859811328",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe plus: physicists told me that one can easily ignore all dimensions one doesn\u2019t want to bother with :p",
  "id" : 764407349859811328,
  "in_reply_to_status_id" : 764406934053224448,
  "created_at" : "2016-08-13 10:24:48 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764406934053224448",
  "geo" : { },
  "id_str" : "764407049212071936",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe I\u2019ve been waiting to use \u201Etrivial\u201C for years and felt my moment had come!",
  "id" : 764407049212071936,
  "in_reply_to_status_id" : 764406934053224448,
  "created_at" : "2016-08-13 10:23:37 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/chBWLRgacU",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/764395363012845568",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.47008533471895, -0.4512117089931586 ]
  },
  "id_str" : "764396516731740160",
  "text" : "Even if he did, given the size of Switzerland it\u2019s rather trivial. https:\/\/t.co\/chBWLRgacU",
  "id" : 764396516731740160,
  "created_at" : "2016-08-13 09:41:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bradnam",
      "screen_name" : "kbradnam",
      "indices" : [ 0, 9 ],
      "id_str" : "17061155",
      "id" : 17061155
    }, {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 10, 26 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Mick Watson",
      "screen_name" : "BioMickWatson",
      "indices" : [ 27, 41 ],
      "id_str" : "228586748",
      "id" : 228586748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764393337818378240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.46984340834332, -0.4511785032570503 ]
  },
  "id_str" : "764395731256049664",
  "in_reply_to_user_id" : 17061155,
  "text" : "@kbradnam @pathogenomenick @BioMickWatson \u00ABmore coffee, please\u00BB?",
  "id" : 764395731256049664,
  "in_reply_to_status_id" : 764393337818378240,
  "created_at" : "2016-08-13 09:38:38 +0000",
  "in_reply_to_screen_name" : "kbradnam",
  "in_reply_to_user_id_str" : "17061155",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/HCwyujjN2l",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BJCwR76jI-j\/",
      "display_url" : "instagram.com\/p\/BJCwR76jI-j\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4696801869, -0.447700744797 ]
  },
  "id_str" : "764385800360460288",
  "text" : "Dirty \u27A1\uFE0F Clean @ London Heathrow (LHR) https:\/\/t.co\/HCwyujjN2l",
  "id" : 764385800360460288,
  "created_at" : "2016-08-13 08:59:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/1n0T8Tlbkw",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/dog-spies\/the-common-wisdom-about-dog-nipples-is-wrong\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+all-blogs%2Ffeed+%28Blog%3A+Scientific+American+Blogs+Posts%29",
      "display_url" : "blogs.scientificamerican.com\/dog-spies\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764357607444414464",
  "text" : "The Common Wisdom About Dog Nipples Is Wrong https:\/\/t.co\/1n0T8Tlbkw",
  "id" : 764357607444414464,
  "created_at" : "2016-08-13 07:07:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.04764489750143, 8.575741930992384 ]
  },
  "id_str" : "764345509108649984",
  "text" : "Doing FRA \u2708\uFE0F LHR again. Let me know if anyone wants to meet for drinks and talk sciency things over the upcoming week.",
  "id" : 764345509108649984,
  "created_at" : "2016-08-13 06:19:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764218039156011013",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06083875503325, 8.818487942060882 ]
  },
  "id_str" : "764226132161994752",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83C\uDF7A well done! \uD83D\uDE0A",
  "id" : 764226132161994752,
  "in_reply_to_status_id" : 764218039156011013,
  "created_at" : "2016-08-12 22:24:43 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Torsten Seemann",
      "screen_name" : "torstenseemann",
      "indices" : [ 0, 15 ],
      "id_str" : "42558652",
      "id" : 42558652
    }, {
      "name" : "Dr Will \uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08",
      "screen_name" : "steeljawpanda",
      "indices" : [ 16, 30 ],
      "id_str" : "124159546",
      "id" : 124159546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764156673699217409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081604913486, 8.818606446951218 ]
  },
  "id_str" : "764207251297013760",
  "in_reply_to_user_id" : 42558652,
  "text" : "@torstenseemann @steeljawpanda the things that happen when metagenomes assemblers create wrong chimeric contigs.",
  "id" : 764207251297013760,
  "in_reply_to_status_id" : 764156673699217409,
  "created_at" : "2016-08-12 21:09:41 +0000",
  "in_reply_to_screen_name" : "torstenseemann",
  "in_reply_to_user_id_str" : "42558652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764127075125096448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0606163286074, 8.818435422239437 ]
  },
  "id_str" : "764205743839019008",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83C\uDF89\uD83C\uDF89\uD83C\uDF89",
  "id" : 764205743839019008,
  "in_reply_to_status_id" : 764127075125096448,
  "created_at" : "2016-08-12 21:03:42 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/nIcCHefftI",
      "expanded_url" : "https:\/\/twitter.com\/haaretzcom\/status\/764126330149490688",
      "display_url" : "twitter.com\/haaretzcom\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06074106987983, 8.818399728673379 ]
  },
  "id_str" : "764205673441816576",
  "text" : "\u05DB\u05DC \u05D4\u05DB\u05D1\u05D5\u05D3! https:\/\/t.co\/nIcCHefftI",
  "id" : 764205673441816576,
  "created_at" : "2016-08-12 21:03:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott",
      "screen_name" : "sckottie",
      "indices" : [ 0, 9 ],
      "id_str" : "103004948",
      "id" : 103004948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764104652841295872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081661846193, 8.818519776928689 ]
  },
  "id_str" : "764199998284242944",
  "in_reply_to_user_id" : 103004948,
  "text" : "@sckottie a very unique ID across 4 columns?",
  "id" : 764199998284242944,
  "in_reply_to_status_id" : 764104652841295872,
  "created_at" : "2016-08-12 20:40:52 +0000",
  "in_reply_to_screen_name" : "sckottie",
  "in_reply_to_user_id_str" : "103004948",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fake Unicode \u2199",
      "screen_name" : "FakeUnicode",
      "indices" : [ 43, 55 ],
      "id_str" : "2183231114",
      "id" : 2183231114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/sOnbu7FlnW",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/764069231671455744",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "764069231671455744",
  "geo" : { },
  "id_str" : "764072041863536640",
  "in_reply_to_user_id" : 14286491,
  "text" : "Time to start lobbying for a kale emoji w\/ @FakeUnicode. https:\/\/t.co\/sOnbu7FlnW",
  "id" : 764072041863536640,
  "in_reply_to_status_id" : 764069231671455744,
  "created_at" : "2016-08-12 12:12:25 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/BPyv5V5ayi",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/aug\/12\/hispters-handle-unpalatable-truth-avocado-toast",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764069231671455744",
  "text" : "Avocados: communities in Mexico are suffering because of our fetishisation https:\/\/t.co\/BPyv5V5ayi \uD83D\uDE22",
  "id" : 764069231671455744,
  "created_at" : "2016-08-12 12:01:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 0, 16 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "764056441774673920",
  "geo" : { },
  "id_str" : "764056857229070337",
  "in_reply_to_user_id" : 242844365,
  "text" : "@kevinschawinski i don\u2019t think it\u2019s widely done yet, hope to set a trend there.",
  "id" : 764056857229070337,
  "in_reply_to_status_id" : 764056441774673920,
  "created_at" : "2016-08-12 11:12:04 +0000",
  "in_reply_to_screen_name" : "kevinschawinski",
  "in_reply_to_user_id_str" : "242844365",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/kxhcxrEJV7",
      "expanded_url" : "http:\/\/www.sciencedirect.com.sci-hub.bz\/science\/article\/pii\/S0160289616301003",
      "display_url" : "sciencedirect.com.sci-hub.bz\/science\/articl\u2026"
    }, {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/1rruaKhIDa",
      "expanded_url" : "https:\/\/twitter.com\/oanacarja\/status\/764030459000987650",
      "display_url" : "twitter.com\/oanacarja\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764055773601263616",
  "text" : "Very nice, read full text at: https:\/\/t.co\/kxhcxrEJV7 https:\/\/t.co\/1rruaKhIDa",
  "id" : 764055773601263616,
  "created_at" : "2016-08-12 11:07:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/KFyhFu71zk",
      "expanded_url" : "https:\/\/twitter.com\/ProfCaryCooper\/status\/763976612996009984",
      "display_url" : "twitter.com\/ProfCaryCooper\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764052017048330240",
  "text" : "I nearly wish I\u2019d be using out of office-emails now. https:\/\/t.co\/KFyhFu71zk",
  "id" : 764052017048330240,
  "created_at" : "2016-08-12 10:52:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Captain Awkward",
      "screen_name" : "CAwkward",
      "indices" : [ 3, 12 ],
      "id_str" : "292650956",
      "id" : 292650956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763864538554990592",
  "text" : "RT @CAwkward: Having a good laugh at Eugene Spreicher, who went to art school with Georgia O'Keeffe. He kept bugging her to pose for him.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763859603348041728",
    "text" : "Having a good laugh at Eugene Spreicher, who went to art school with Georgia O'Keeffe. He kept bugging her to pose for him.",
    "id" : 763859603348041728,
    "created_at" : "2016-08-11 22:08:15 +0000",
    "user" : {
      "name" : "Captain Awkward",
      "screen_name" : "CAwkward",
      "protected" : false,
      "id_str" : "292650956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1340597637\/Captain_Awkward_normal.jpg",
      "id" : 292650956,
      "verified" : false
    }
  },
  "id" : 763864538554990592,
  "created_at" : "2016-08-11 22:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ujf2dj6bSe",
      "expanded_url" : "https:\/\/twitter.com\/pathogenomenick\/status\/763853800520187905",
      "display_url" : "twitter.com\/pathogenomenic\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06076904623197, 8.818404825924727 ]
  },
  "id_str" : "763855371886817282",
  "text" : "10 minutes to midnight and now I want to head out to find lichens just so I can look at tardigrades m) https:\/\/t.co\/ujf2dj6bSe",
  "id" : 763855371886817282,
  "created_at" : "2016-08-11 21:51:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "indices" : [ 3, 13 ],
      "id_str" : "22839233",
      "id" : 22839233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/STFnoxf5L2",
      "expanded_url" : "https:\/\/medium.com\/@nkkl\/ride-like-a-girl-1d5524e25d3a#.ghw46deql",
      "display_url" : "medium.com\/@nkkl\/ride-lik\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763844186256904192",
  "text" : "RT @kaythaney: \"Ever wanted to know what it\u2019s like to be a woman? Go get your bike.\" https:\/\/t.co\/STFnoxf5L2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/STFnoxf5L2",
        "expanded_url" : "https:\/\/medium.com\/@nkkl\/ride-like-a-girl-1d5524e25d3a#.ghw46deql",
        "display_url" : "medium.com\/@nkkl\/ride-lik\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763723169614159872",
    "text" : "\"Ever wanted to know what it\u2019s like to be a woman? Go get your bike.\" https:\/\/t.co\/STFnoxf5L2",
    "id" : 763723169614159872,
    "created_at" : "2016-08-11 13:06:07 +0000",
    "user" : {
      "name" : "Kaitlin Thaney \uD83D\uDC81\uD83C\uDFFB",
      "screen_name" : "kaythaney",
      "protected" : false,
      "id_str" : "22839233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/932288468029509632\/_I0e0wgc_normal.jpg",
      "id" : 22839233,
      "verified" : false
    }
  },
  "id" : 763844186256904192,
  "created_at" : "2016-08-11 21:07:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/6G0DflnBBq",
      "expanded_url" : "https:\/\/66.media.tumblr.com\/tumblr_med859h6y31qz8ca1o1_500.gif",
      "display_url" : "66.media.tumblr.com\/tumblr_med859h\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "763790675821330433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086169000676, 8.81848583834397 ]
  },
  "id_str" : "763801763820560384",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick wish they had one of these https:\/\/t.co\/6G0DflnBBq",
  "id" : 763801763820560384,
  "in_reply_to_status_id" : 763790675821330433,
  "created_at" : "2016-08-11 18:18:25 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763451051961966592",
  "geo" : { },
  "id_str" : "763690635203313664",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas congrats!",
  "id" : 763690635203313664,
  "in_reply_to_status_id" : 763451051961966592,
  "created_at" : "2016-08-11 10:56:50 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763682897878482945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17181713870843, 8.631496993631231 ]
  },
  "id_str" : "763683902645014528",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot I can bring new ones next week!",
  "id" : 763683902645014528,
  "in_reply_to_status_id" : 763682897878482945,
  "created_at" : "2016-08-11 10:30:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763679783704223744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17179483184313, 8.631335703761708 ]
  },
  "id_str" : "763681599896612864",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot didn\u2019t I bring those last year? :D",
  "id" : 763681599896612864,
  "in_reply_to_status_id" : 763679783704223744,
  "created_at" : "2016-08-11 10:20:56 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/iIy5DrXeJk",
      "expanded_url" : "http:\/\/gizmodo.com\/paul-vos-physics-defying-wand-makes-guitars-sound-entir-1682661353",
      "display_url" : "gizmodo.com\/paul-vos-physi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "763671936727654400",
  "geo" : { },
  "id_str" : "763672867355623424",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot and even weirder https:\/\/t.co\/iIy5DrXeJk",
  "id" : 763672867355623424,
  "in_reply_to_status_id" : 763671936727654400,
  "created_at" : "2016-08-11 09:46:14 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/P2OBN1CVMV",
      "expanded_url" : "https:\/\/m.youtube.com\/watch?v=LpXVLhZBwGM",
      "display_url" : "m.youtube.com\/watch?v=LpXVLh\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "763671415975477248",
  "geo" : { },
  "id_str" : "763671555306029057",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot https:\/\/t.co\/P2OBN1CVMV",
  "id" : 763671555306029057,
  "in_reply_to_status_id" : 763671415975477248,
  "created_at" : "2016-08-11 09:41:01 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763646503432970240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17250917228832, 8.627449206428693 ]
  },
  "id_str" : "763670062519750656",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not sure what I\u2019m more looking forward to!",
  "id" : 763670062519750656,
  "in_reply_to_status_id" : 763646503432970240,
  "created_at" : "2016-08-11 09:35:05 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763621221040852992",
  "geo" : { },
  "id_str" : "763652260652089344",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin \u2026the original author was annoyed\u2026",
  "id" : 763652260652089344,
  "in_reply_to_status_id" : 763621221040852992,
  "created_at" : "2016-08-11 08:24:21 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/T6doCNFq1Y",
      "expanded_url" : "http:\/\/www.thetruthpodcast.com\/story\/2016\/7\/13\/the-making-of-thats-democracy",
      "display_url" : "thetruthpodcast.com\/story\/2016\/7\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763648538773483520",
  "text" : "Listening to the podcast backlog paid off: Finally found out about the short film adaptation of \u00ABThat's Democracy\u00BB. https:\/\/t.co\/T6doCNFq1Y",
  "id" : 763648538773483520,
  "created_at" : "2016-08-11 08:09:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763528875393581056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085042070912, 8.818699094889956 ]
  },
  "id_str" : "763626577238319104",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps that\u2019s two of the nicest labels anyhow \uD83D\uDE0D",
  "id" : 763626577238319104,
  "in_reply_to_status_id" : 763528875393581056,
  "created_at" : "2016-08-11 06:42:18 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763526458434347009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091188192704, 8.818588925561754 ]
  },
  "id_str" : "763527508461510656",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps and you certainly qualify for being a real scientist! I always feel That\u2019s a super weird distinction to make.",
  "id" : 763527508461510656,
  "in_reply_to_status_id" : 763526458434347009,
  "created_at" : "2016-08-11 00:08:38 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763526458434347009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608747596149, 8.818629965234413 ]
  },
  "id_str" : "763526927290368001",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps oh yes, that\u2019s the worst part about the whole comparison!",
  "id" : 763526927290368001,
  "in_reply_to_status_id" : 763526458434347009,
  "created_at" : "2016-08-11 00:06:19 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/SiDLi6oRv2",
      "expanded_url" : "https:\/\/twitter.com\/JBYoder\/status\/763521841726103552",
      "display_url" : "twitter.com\/JBYoder\/status\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.060828972746, 8.818532290853822 ]
  },
  "id_str" : "763524773473312769",
  "text" : "Peer review is so broken, I still have to wade through tons of unrequested pictures of erect bar graphs\u2026 https:\/\/t.co\/SiDLi6oRv2",
  "id" : 763524773473312769,
  "created_at" : "2016-08-10 23:57:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 13, 23 ],
      "id_str" : "267256091",
      "id" : 267256091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763513789916536833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06096428104555, 8.818555846442111 ]
  },
  "id_str" : "763514091969384448",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @_inundata \uD83D\uDE0D btw will be in London starting Saturday. You need to find an excuse to drop by. Don\u2019t forget Baxter.",
  "id" : 763514091969384448,
  "in_reply_to_status_id" : 763513789916536833,
  "created_at" : "2016-08-10 23:15:19 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 13, 23 ],
      "id_str" : "267256091",
      "id" : 267256091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763513457962524672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082546243623, 8.818487163407916 ]
  },
  "id_str" : "763513582835359749",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @_inundata I can manage that.",
  "id" : 763513582835359749,
  "in_reply_to_status_id" : 763513457962524672,
  "created_at" : "2016-08-10 23:13:18 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 0, 12 ],
      "id_str" : "53893339",
      "id" : 53893339
    }, {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 13, 23 ],
      "id_str" : "267256091",
      "id" : 267256091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763512389769756673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06086040758533, 8.818448949613439 ]
  },
  "id_str" : "763512525958836226",
  "in_reply_to_user_id" : 53893339,
  "text" : "@froggleston @_inundata will you be at mozfest again? \uD83D\uDE07",
  "id" : 763512525958836226,
  "in_reply_to_status_id" : 763512389769756673,
  "created_at" : "2016-08-10 23:09:06 +0000",
  "in_reply_to_screen_name" : "froggleston",
  "in_reply_to_user_id_str" : "53893339",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karthik Ram",
      "screen_name" : "_inundata",
      "indices" : [ 0, 10 ],
      "id_str" : "267256091",
      "id" : 267256091
    }, {
      "name" : "Robert Davey",
      "screen_name" : "froggleston",
      "indices" : [ 11, 23 ],
      "id_str" : "53893339",
      "id" : 53893339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "763507918742269952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06088122614888, 8.81859519138174 ]
  },
  "id_str" : "763509391215689728",
  "in_reply_to_user_id" : 267256091,
  "text" : "@_inundata @froggleston where can I sign up?!",
  "id" : 763509391215689728,
  "in_reply_to_status_id" : 763507918742269952,
  "created_at" : "2016-08-10 22:56:38 +0000",
  "in_reply_to_screen_name" : "_inundata",
  "in_reply_to_user_id_str" : "267256091",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/g1UNuDKH6d",
      "expanded_url" : "https:\/\/twitter.com\/ThePracticalDev\/status\/763470048463912960",
      "display_url" : "twitter.com\/ThePracticalDe\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06082509077781, 8.818506552481713 ]
  },
  "id_str" : "763489259835822080",
  "text" : "Reminds me that the minuscule distance between C-SPAN and CPAN isn\u2019t accidental: hellish repetition in both cases. https:\/\/t.co\/g1UNuDKH6d",
  "id" : 763489259835822080,
  "created_at" : "2016-08-10 21:36:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/3XpYAvHBh2",
      "expanded_url" : "https:\/\/twitter.com\/guardian\/status\/763358784207085572",
      "display_url" : "twitter.com\/guardian\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763367601150058496",
  "text" : "Wait for my PhD\u2026 \u00ABSo write. But be patient. After all, Darwin himself took more than two decades to finish his book\u00BB https:\/\/t.co\/3XpYAvHBh2",
  "id" : 763367601150058496,
  "created_at" : "2016-08-10 13:33:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/63w2VpilWY",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Daylight_saving_time",
      "display_url" : "en.wikipedia.org\/wiki\/Daylight_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763328467312250880",
  "text" : "Yesterday I learned: We not only started two world wars, but also the daylight saving time\u2026 https:\/\/t.co\/63w2VpilWY",
  "id" : 763328467312250880,
  "created_at" : "2016-08-10 10:57:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763296298963464192",
  "text" : "\u00ABDo you think someone will ever publish our telegram love messages?\u00BB \u2013 \u00ABHopefully only after doing a \u2018|sort|uniq\u2019 on it!\u00BB",
  "id" : 763296298963464192,
  "created_at" : "2016-08-10 08:49:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/d5cFHJRdQH",
      "expanded_url" : "https:\/\/medium.com\/@drmdhumphries\/how-a-happy-moment-for-neuroscience-is-a-sad-moment-for-science-c4ba00336e9c#.ivfvmhu4g",
      "display_url" : "medium.com\/@drmdhumphries\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762940435161571328",
  "text" : "first fixing science then figuring out \u201Ehow nuclear disarmament can be achieved with a teaspoon and an angry badger\u201C https:\/\/t.co\/d5cFHJRdQH",
  "id" : 762940435161571328,
  "created_at" : "2016-08-09 09:15:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Wcasqv8ej1",
      "expanded_url" : "https:\/\/twitter.com\/lteytelman\/status\/762886648153518081",
      "display_url" : "twitter.com\/lteytelman\/sta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247629348283, 8.627452925808914 ]
  },
  "id_str" : "762925977852907520",
  "text" : "Yes, please. Also: most of the stuff I skim\/read\/cite comes through Twitter by now. Go figure! https:\/\/t.co\/Wcasqv8ej1",
  "id" : 762925977852907520,
  "created_at" : "2016-08-09 08:18:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "citizenscience",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/GlVzzzYhrs",
      "expanded_url" : "https:\/\/twitter.com\/IamCitSci\/status\/762773348875141120",
      "display_url" : "twitter.com\/IamCitSci\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762779162637729794",
  "text" : "I can\u2019t agree enough. Some of the best friends (and the most fun science) I ever made, I made with #citizenscience https:\/\/t.co\/GlVzzzYhrs",
  "id" : 762779162637729794,
  "created_at" : "2016-08-08 22:34:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/TBsZyJSVr4",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/the-linguistic-turf-wars-over-the-singular-they",
      "display_url" : "atlasobscura.com\/articles\/the-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762768258432901120",
  "text" : "The Linguistic Turf Wars Over the Singular 'They' https:\/\/t.co\/TBsZyJSVr4",
  "id" : 762768258432901120,
  "created_at" : "2016-08-08 21:51:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762707864985014272",
  "geo" : { },
  "id_str" : "762709875507994624",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap oh, and thanks for that of course!",
  "id" : 762709875507994624,
  "in_reply_to_status_id" : 762707864985014272,
  "created_at" : "2016-08-08 17:59:39 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762707864985014272",
  "geo" : { },
  "id_str" : "762707964558016512",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap yep, I feel that\u2019s much better! \uD83D\uDC4D",
  "id" : 762707964558016512,
  "in_reply_to_status_id" : 762707864985014272,
  "created_at" : "2016-08-08 17:52:03 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762707147859767297",
  "geo" : { },
  "id_str" : "762707511321497600",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap but agree on the consumer access :-)",
  "id" : 762707511321497600,
  "in_reply_to_status_id" : 762707147859767297,
  "created_at" : "2016-08-08 17:50:15 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762707147859767297",
  "geo" : { },
  "id_str" : "762707477473402881",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap yeah, for me \u201Efree and open\u201C implied something along the lines of open source\/data and that\u2019s what I (unfortune.) can\u2019t see.",
  "id" : 762707477473402881,
  "in_reply_to_status_id" : 762707147859767297,
  "created_at" : "2016-08-08 17:50:07 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762705573792002049",
  "geo" : { },
  "id_str" : "762706639220838401",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap you also can\u2019t really export anything in a useful format besides the raw genetic data.",
  "id" : 762706639220838401,
  "in_reply_to_status_id" : 762705573792002049,
  "created_at" : "2016-08-08 17:46:47 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 0, 13 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762705573792002049",
  "geo" : { },
  "id_str" : "762706562955747328",
  "in_reply_to_user_id" : 16098270,
  "text" : "@matthiasshap their API is super restrictive when it comes to who\u2019s allowed to use it, i.e. not us w\/ openSNP.",
  "id" : 762706562955747328,
  "in_reply_to_status_id" : 762705573792002049,
  "created_at" : "2016-08-08 17:46:29 +0000",
  "in_reply_to_screen_name" : "matthiasshap",
  "in_reply_to_user_id_str" : "16098270",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minaal",
      "screen_name" : "minaal",
      "indices" : [ 0, 7 ],
      "id_str" : "246624621",
      "id" : 246624621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762699301667631106",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11410162788826, 8.753474280246303 ]
  },
  "id_str" : "762703815854452736",
  "in_reply_to_user_id" : 246624621,
  "text" : "@minaal I might already try over the weekend!",
  "id" : 762703815854452736,
  "in_reply_to_status_id" : 762699301667631106,
  "created_at" : "2016-08-08 17:35:34 +0000",
  "in_reply_to_screen_name" : "minaal",
  "in_reply_to_user_id_str" : "246624621",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/0ajqHFaF8H",
      "expanded_url" : "https:\/\/twitter.com\/replicatedtypo\/status\/762635904884281345",
      "display_url" : "twitter.com\/replicatedtypo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17250205003879, 8.627481326337122 ]
  },
  "id_str" : "762641217180037120",
  "text" : "Not believing into too good to be true psychology studies? Sounds more than fair to me. https:\/\/t.co\/0ajqHFaF8H",
  "id" : 762641217180037120,
  "created_at" : "2016-08-08 13:26:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthias Shapiro",
      "screen_name" : "matthiasshap",
      "indices" : [ 107, 120 ],
      "id_str" : "16098270",
      "id" : 16098270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/vYK3nvY0vw",
      "expanded_url" : "https:\/\/medium.com\/@matthiasshap\/the-fda-23andme-how-public-information-became-a-regulated-medical-device-122a0599c0cd#.ey88ifher",
      "display_url" : "medium.com\/@matthiasshap\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762626179107000320",
  "text" : "\u00AB23andMe was coming from a tech culture of [\u2026] making information free &amp; accessible\u00BB Disagree on that, @matthiasshap https:\/\/t.co\/vYK3nvY0vw",
  "id" : 762626179107000320,
  "created_at" : "2016-08-08 12:27:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 3, 11 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinformatics",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762614244248588288",
  "text" : "RT @pjacock: \"Another thing that makes T-Coffee a very average research project is that it\u2026 was originally a bug\" #bioinformatics https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinformatics",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/35s7IM2nQp",
        "expanded_url" : "https:\/\/twitter.com\/EvFlo\/status\/762607293934567424",
        "display_url" : "twitter.com\/EvFlo\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762613048771219456",
    "text" : "\"Another thing that makes T-Coffee a very average research project is that it\u2026 was originally a bug\" #bioinformatics https:\/\/t.co\/35s7IM2nQp",
    "id" : 762613048771219456,
    "created_at" : "2016-08-08 11:34:54 +0000",
    "user" : {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "protected" : false,
      "id_str" : "58756672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/324343873\/peter_cliff_normal.jpg",
      "id" : 58756672,
      "verified" : false
    }
  },
  "id" : 762614244248588288,
  "created_at" : "2016-08-08 11:39:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/l4kEQyIxYu",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/the-market-for-bread",
      "display_url" : "smbc-comics.com\/comic\/the-mark\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762601867184603136",
  "text" : "Jesus, what an asshole. https:\/\/t.co\/l4kEQyIxYu",
  "id" : 762601867184603136,
  "created_at" : "2016-08-08 10:50:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762587267248615424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17320952023872, 8.629344331401725 ]
  },
  "id_str" : "762591198636871680",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch let\u2019s see whether that works out. \uD83D\uDE02",
  "id" : 762591198636871680,
  "in_reply_to_status_id" : 762587267248615424,
  "created_at" : "2016-08-08 10:08:04 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 10, 22 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Qo3cRRP3rk",
      "expanded_url" : "https:\/\/github.com\/openSNP\/snpr",
      "display_url" : "github.com\/openSNP\/snpr"
    } ]
  },
  "geo" : { },
  "id_str" : "762584655480688640",
  "text" : "Thanks to @helgerausch the openSNP repo now also displays the code climate &amp; test coverage \uD83C\uDF89 https:\/\/t.co\/Qo3cRRP3rk",
  "id" : 762584655480688640,
  "created_at" : "2016-08-08 09:42:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762373917105352705",
  "geo" : { },
  "id_str" : "762374093807161345",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick please!",
  "id" : 762374093807161345,
  "in_reply_to_status_id" : 762373917105352705,
  "created_at" : "2016-08-07 19:45:22 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24EA Chris Hartgerink",
      "screen_name" : "chartgerink",
      "indices" : [ 0, 12 ],
      "id_str" : "439273539",
      "id" : 439273539
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 13, 27 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 28, 36 ],
      "id_str" : "44890780",
      "id" : 44890780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762369584729063425",
  "geo" : { },
  "id_str" : "762370949358452737",
  "in_reply_to_user_id" : 439273539,
  "text" : "@chartgerink @Protohedgehog @tonyR_H not yet, but should plan this!",
  "id" : 762370949358452737,
  "in_reply_to_status_id" : 762369584729063425,
  "created_at" : "2016-08-07 19:32:53 +0000",
  "in_reply_to_screen_name" : "chartgerink",
  "in_reply_to_user_id_str" : "439273539",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762366805260263424",
  "geo" : { },
  "id_str" : "762367935180599296",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest \uD83D\uDC4D\uD83D\uDC4D\uD83D\uDC4D",
  "id" : 762367935180599296,
  "in_reply_to_status_id" : 762366805260263424,
  "created_at" : "2016-08-07 19:20:54 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762365157418950656",
  "geo" : { },
  "id_str" : "762366043448901632",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest i don\u2019t even know what to say to that except to fully agree :(",
  "id" : 762366043448901632,
  "in_reply_to_status_id" : 762365157418950656,
  "created_at" : "2016-08-07 19:13:23 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762364066660835328",
  "geo" : { },
  "id_str" : "762364475391565825",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yes \uD83D\uDE22",
  "id" : 762364475391565825,
  "in_reply_to_status_id" : 762364066660835328,
  "created_at" : "2016-08-07 19:07:09 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762363229683286017",
  "geo" : { },
  "id_str" : "762363721356288000",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest the whole \uD83D\uDEBB-dividing is BS, but the genetics twist just adds to the level of absurdity.",
  "id" : 762363721356288000,
  "in_reply_to_status_id" : 762363229683286017,
  "created_at" : "2016-08-07 19:04:09 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 3, 11 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762362179869937668",
  "text" : "RT @o_guest: @gedankenstuecke so 100% yes, also not everybody is XX\/XY.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "762358597712052225",
    "geo" : { },
    "id_str" : "762361836616486913",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke so 100% yes, also not everybody is XX\/XY.",
    "id" : 762361836616486913,
    "in_reply_to_status_id" : 762358597712052225,
    "created_at" : "2016-08-07 18:56:40 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "protected" : false,
      "id_str" : "3865005196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844972791732584453\/mdSj6vOd_normal.jpg",
      "id" : 3865005196,
      "verified" : false
    }
  },
  "id" : 762362179869937668,
  "created_at" : "2016-08-07 18:58:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762361836616486913",
  "geo" : { },
  "id_str" : "762362167173779458",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yes, that\u2019s another big issue which I couldn\u2019t fit in there anymore!",
  "id" : 762362167173779458,
  "in_reply_to_status_id" : 762361836616486913,
  "created_at" : "2016-08-07 18:57:59 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 0, 8 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 9, 18 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762358819296911361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06093157905526, 8.8186689582936 ]
  },
  "id_str" : "762358961119125504",
  "in_reply_to_user_id" : 19210703,
  "text" : "@junaxup @InfinoMe yes, I also struggle with some of the fancy guitar chords. So let\u2019s see how that turns out :-)",
  "id" : 762358961119125504,
  "in_reply_to_status_id" : 762358819296911361,
  "created_at" : "2016-08-07 18:45:14 +0000",
  "in_reply_to_screen_name" : "junaxup",
  "in_reply_to_user_id_str" : "19210703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/FEG9VOpcK3",
      "expanded_url" : "https:\/\/twitter.com\/yianni_a\/status\/762340104040017921",
      "display_url" : "twitter.com\/yianni_a\/statu\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06095449444843, 8.81867039949523 ]
  },
  "id_str" : "762358597712052225",
  "text" : "You also need to know your karyotype, which is completely irrelevant for how you \uD83D\uDCA9\u2026 https:\/\/t.co\/FEG9VOpcK3",
  "id" : 762358597712052225,
  "created_at" : "2016-08-07 18:43:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 0, 8 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 9, 18 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762357596342759424",
  "geo" : { },
  "id_str" : "762357753394425858",
  "in_reply_to_user_id" : 19210703,
  "text" : "@junaxup @InfinoMe I already play the guitar, so getting that one up to some speed should be manageable :)",
  "id" : 762357753394425858,
  "in_reply_to_status_id" : 762357596342759424,
  "created_at" : "2016-08-07 18:40:26 +0000",
  "in_reply_to_screen_name" : "junaxup",
  "in_reply_to_user_id_str" : "19210703",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "infinome",
      "screen_name" : "InfinoMe",
      "indices" : [ 0, 9 ],
      "id_str" : "2362226100",
      "id" : 2362226100
    }, {
      "name" : "Jun Axup",
      "screen_name" : "junaxup",
      "indices" : [ 10, 18 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "bi\u232Cchemies",
      "screen_name" : "biochemies",
      "indices" : [ 19, 30 ],
      "id_str" : "60672072",
      "id" : 60672072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762355863445049344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06099347029818, 8.818731671207415 ]
  },
  "id_str" : "762356907675938816",
  "in_reply_to_user_id" : 2362226100,
  "text" : "@InfinoMe @junaxup @biochemies next time we meet we should jam \uD83D\uDE0A",
  "id" : 762356907675938816,
  "in_reply_to_status_id" : 762355863445049344,
  "created_at" : "2016-08-07 18:37:05 +0000",
  "in_reply_to_screen_name" : "InfinoMe",
  "in_reply_to_user_id_str" : "2362226100",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minaal",
      "screen_name" : "minaal",
      "indices" : [ 73, 80 ],
      "id_str" : "246624621",
      "id" : 246624621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Hh53wLl3he",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/762071342502019072",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "762071342502019072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06072269291622, 8.818715494134294 ]
  },
  "id_str" : "762351744802295808",
  "in_reply_to_user_id" : 14286491,
  "text" : "Now I ordered one for myself. I wonder whether I can stash it inside the @minaal and take it along on my trips. \uD83D\uDE02 https:\/\/t.co\/Hh53wLl3he",
  "id" : 762351744802295808,
  "in_reply_to_status_id" : 762071342502019072,
  "created_at" : "2016-08-07 18:16:34 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/pE2rmCLdfC",
      "expanded_url" : "http:\/\/www.theverge.com\/2016\/8\/3\/12325104\/airbnb-aesthetic-global-minimalism-startup-gentrification",
      "display_url" : "theverge.com\/2016\/8\/3\/12325\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762332742503759872",
  "text" : "The homogenization of spaces, thanks to Airbnb et al. (and all of us, who enable this) https:\/\/t.co\/pE2rmCLdfC",
  "id" : 762332742503759872,
  "created_at" : "2016-08-07 17:01:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/rOVjcWn2gz",
      "expanded_url" : "https:\/\/www.instagram.com\/p\/BI0BMqjj6Nn\/",
      "display_url" : "instagram.com\/p\/BI0BMqjj6Nn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "762311938651066368",
  "text" : "St. Paul (no, not that one) https:\/\/t.co\/rOVjcWn2gz",
  "id" : 762311938651066368,
  "created_at" : "2016-08-07 15:38:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762245445108326400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608067902529, 8.818627714496795 ]
  },
  "id_str" : "762245688717676545",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen \u201CBestrafung\u201D, got it. :p",
  "id" : 762245688717676545,
  "in_reply_to_status_id" : 762245445108326400,
  "created_at" : "2016-08-07 11:15:08 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    }, {
      "name" : "Kevin Schawinski",
      "screen_name" : "kevinschawinski",
      "indices" : [ 15, 31 ],
      "id_str" : "242844365",
      "id" : 242844365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762237044361945088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608067902529, 8.818627714496795 ]
  },
  "id_str" : "762245405241409540",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy @kevinschawinski everything where you have to board a second plane after leaving a 12+ hour flight ;)",
  "id" : 762245405241409540,
  "in_reply_to_status_id" : 762237044361945088,
  "created_at" : "2016-08-07 11:14:01 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Brechler",
      "screen_name" : "plaetzchen",
      "indices" : [ 0, 11 ],
      "id_str" : "14305613",
      "id" : 14305613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762236176363319296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0608067902529, 8.818627714496795 ]
  },
  "id_str" : "762245195069087744",
  "in_reply_to_user_id" : 14305613,
  "text" : "@plaetzchen sich mit essen zu bewerfen ist schon ein Fetisch von euch, oder?",
  "id" : 762245195069087744,
  "in_reply_to_status_id" : 762236176363319296,
  "created_at" : "2016-08-07 11:13:10 +0000",
  "in_reply_to_screen_name" : "plaetzchen",
  "in_reply_to_user_id_str" : "14305613",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 9, 23 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762232262226223104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06102766875579, 8.818805000909038 ]
  },
  "id_str" : "762232335110660096",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H @Protohedgehog \uD83C\uDF89\uD83C\uDF89\uD83D\uDE18",
  "id" : 762232335110660096,
  "in_reply_to_status_id" : 762232262226223104,
  "created_at" : "2016-08-07 10:22:04 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Ross-Hellauer",
      "screen_name" : "tonyR_H",
      "indices" : [ 0, 8 ],
      "id_str" : "44890780",
      "id" : 44890780
    }, {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 12, 26 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762228742538334208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084942729218, 8.818593537443148 ]
  },
  "id_str" : "762230140940189696",
  "in_reply_to_user_id" : 44890780,
  "text" : "@tonyR_H so @Protohedgehog and I can now beg you for travel funds? :p",
  "id" : 762230140940189696,
  "in_reply_to_status_id" : 762228742538334208,
  "created_at" : "2016-08-07 10:13:21 +0000",
  "in_reply_to_screen_name" : "tonyR_H",
  "in_reply_to_user_id_str" : "44890780",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/umPK1LR5jb",
      "expanded_url" : "https:\/\/twitter.com\/Protohedgehog\/status\/762224056561205248",
      "display_url" : "twitter.com\/Protohedgehog\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06107344527609, 8.818800774974001 ]
  },
  "id_str" : "762226067096608768",
  "text" : "If you have money to spare but don\u2019t like Jon: same here, could use some funds for going to #opencon \uD83D\uDE09 https:\/\/t.co\/umPK1LR5jb",
  "id" : 762226067096608768,
  "created_at" : "2016-08-07 09:57:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriel",
      "screen_name" : "7_10_7",
      "indices" : [ 0, 7 ],
      "id_str" : "215970924",
      "id" : 215970924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761667730428743683",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06107344527609, 8.818800774974001 ]
  },
  "id_str" : "762225681346551808",
  "in_reply_to_user_id" : 215970924,
  "text" : "@7_10_7 awesome reply!",
  "id" : 762225681346551808,
  "in_reply_to_status_id" : 761667730428743683,
  "created_at" : "2016-08-07 09:55:38 +0000",
  "in_reply_to_screen_name" : "7_10_7",
  "in_reply_to_user_id_str" : "215970924",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SciHub",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/wOIFG1cpIx",
      "expanded_url" : "https:\/\/twitter.com\/7_10_7\/status\/761667398445379585",
      "display_url" : "twitter.com\/7_10_7\/status\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06107344527609, 8.818800774974001 ]
  },
  "id_str" : "762225585540169728",
  "text" : "See thread for the letter and the reply. In a way good to see how much of an impact #SciHub already has. https:\/\/t.co\/wOIFG1cpIx",
  "id" : 762225585540169728,
  "created_at" : "2016-08-07 09:55:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/762219538352046080\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/DuFdxlSvlw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPyi5lWgAE2ZkF.jpg",
      "id_str" : "762219443342704641",
      "id" : 762219443342704641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPyi5lWgAE2ZkF.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/DuFdxlSvlw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762195460203356160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06085995119115, 8.818543912135604 ]
  },
  "id_str" : "762219538352046080",
  "in_reply_to_user_id" : 14286491,
  "text" : "Of course it needs a tree too. https:\/\/t.co\/DuFdxlSvlw",
  "id" : 762219538352046080,
  "in_reply_to_status_id" : 762195460203356160,
  "created_at" : "2016-08-07 09:31:13 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762215587460308992",
  "text" : "RescueTime classifies the \u201Emicrosoft error reporting\u201C in the category \u201ENews &amp; Opinion\u201C and as being \u201Edistracting\u201C. \uD83D\uDE02",
  "id" : 762215587460308992,
  "created_at" : "2016-08-07 09:15:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/762195460203356160\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/RmBSznm3D9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpPcuwqWgAAAWmJ.jpg",
      "id_str" : "762195457850376192",
      "id" : 762195457850376192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpPcuwqWgAAAWmJ.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 1301
      }, {
        "h" : 976,
        "resize" : "fit",
        "w" : 1301
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/RmBSznm3D9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.060898, 8.818408 ]
  },
  "id_str" : "762195460203356160",
  "text" : "Asimov in 1960 in \"The Wellsprings of Life\". How little has changed. https:\/\/t.co\/RmBSznm3D9",
  "id" : 762195460203356160,
  "created_at" : "2016-08-07 07:55:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06084003066837, 8.81863193281392 ]
  },
  "id_str" : "762071342502019072",
  "text" : "Spend good parts of my afternoon playing a ukulele. One for right-handed people, so upside down, &amp; without even knowing how to play one. \uD83C\uDFB8\uD83D\uDE02",
  "id" : 762071342502019072,
  "created_at" : "2016-08-06 23:42:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    }, {
      "name" : "Penny CS Andrews\uD83D\uDC68\uD83C\uDFFB\u200D\uD83C\uDFA4\uD83C\uDF08\uD83C\uDF84",
      "screen_name" : "pennyb",
      "indices" : [ 15, 22 ],
      "id_str" : "6069772",
      "id" : 6069772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762023558801453060",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06098316055728, 8.818612312906252 ]
  },
  "id_str" : "762025423484125184",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog @pennyb perfect!",
  "id" : 762025423484125184,
  "in_reply_to_status_id" : 762023558801453060,
  "created_at" : "2016-08-06 20:39:53 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762021007695675392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06419066344394, 8.834627531477096 ]
  },
  "id_str" : "762021842840412160",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog sure, let\u2019s discuss after the weekend?",
  "id" : 762021842840412160,
  "in_reply_to_status_id" : 762021007695675392,
  "created_at" : "2016-08-06 20:25:39 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762019637890613251",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06122142503988, 8.680561821352043 ]
  },
  "id_str" : "762019862478749696",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog you pay mine, I pay yours? :p",
  "id" : 762019862478749696,
  "in_reply_to_status_id" : 762019637890613251,
  "created_at" : "2016-08-06 20:17:47 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Tennant",
      "screen_name" : "Protohedgehog",
      "indices" : [ 0, 14 ],
      "id_str" : "352650591",
      "id" : 352650591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762019350857584640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06137509834958, 8.674736861147615 ]
  },
  "id_str" : "762019487667200000",
  "in_reply_to_user_id" : 352650591,
  "text" : "@Protohedgehog sorry, same here! Any ideas where to apply for funds?",
  "id" : 762019487667200000,
  "in_reply_to_status_id" : 762019350857584640,
  "created_at" : "2016-08-06 20:16:18 +0000",
  "in_reply_to_screen_name" : "Protohedgehog",
  "in_reply_to_user_id_str" : "352650591",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opencon",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.97801195834761, 8.328592507176406 ]
  },
  "id_str" : "762014808677949444",
  "text" : "Looks like I might go to #opencon this year!",
  "id" : 762014808677949444,
  "created_at" : "2016-08-06 19:57:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761948864018538496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00083106320924, 8.265915735008473 ]
  },
  "id_str" : "761949015818854401",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps I\u2019m not sure what I find worse. ;)",
  "id" : 761949015818854401,
  "in_reply_to_status_id" : 761948864018538496,
  "created_at" : "2016-08-06 15:36:16 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 0, 8 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761927601212489729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.99771295655177, 8.256202222499391 ]
  },
  "id_str" : "761928310838427648",
  "in_reply_to_user_id" : 173881525,
  "text" : "@iaravps uh, that disapproving? :\/",
  "id" : 761928310838427648,
  "in_reply_to_status_id" : 761927601212489729,
  "created_at" : "2016-08-06 14:13:59 +0000",
  "in_reply_to_screen_name" : "iaravps",
  "in_reply_to_user_id_str" : "173881525",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/uy72IYneRL",
      "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/22926778",
      "display_url" : "goodreads.com\/book\/show\/2292\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.060173, 8.818648 ]
  },
  "id_str" : "761876375850680320",
  "text" : "Nearly made it through \"Skyfaring\" and maybe I just googled for \"how to become a commercial pilot\". \u2708\uFE0F https:\/\/t.co\/uy72IYneRL",
  "id" : 761876375850680320,
  "created_at" : "2016-08-06 10:47:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/v7PVkEJtnI",
      "expanded_url" : "https:\/\/twitter.com\/StuartJRitchie\/status\/761669445941096448",
      "display_url" : "twitter.com\/StuartJRitchie\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06091455467982, 8.818525644027458 ]
  },
  "id_str" : "761814442724225024",
  "text" : "Never noticed but now I can\u2019t unsee it. Explains why I love violin plots so much. https:\/\/t.co\/v7PVkEJtnI",
  "id" : 761814442724225024,
  "created_at" : "2016-08-06 06:41:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761488285482881024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17254615638288, 8.627515076545842 ]
  },
  "id_str" : "761537091398500352",
  "in_reply_to_user_id" : 14286491,
  "text" : "Apparently not, but ggtree can do this. It\u2019s just complete unclear to me how the different margins one specifies relate to another.",
  "id" : 761537091398500352,
  "in_reply_to_status_id" : 761488285482881024,
  "created_at" : "2016-08-05 12:19:25 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17237994851998, 8.627667964098245 ]
  },
  "id_str" : "761488285482881024",
  "text" : "Today one for the R crowd: I got a species tree and want heatmap2 to sort my matrix rows according to it. Is there any way to do this?",
  "id" : 761488285482881024,
  "created_at" : "2016-08-05 09:05:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/2AQnclKqdM",
      "expanded_url" : "https:\/\/github.com\/gedankenstuecke\/porntology",
      "display_url" : "github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "761468863557107712",
  "geo" : { },
  "id_str" : "761469248304713728",
  "in_reply_to_user_id" : 14286491,
  "text" : "~4 years ago I tried mining a bit of the crowd-generated tags given to porn. The data can be found at https:\/\/t.co\/2AQnclKqdM",
  "id" : 761469248304713728,
  "in_reply_to_status_id" : 761468863557107712,
  "created_at" : "2016-08-05 07:49:50 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/TlQ70AlNAj",
      "expanded_url" : "https:\/\/aeon.co\/essays\/micro-targeted-digital-porn-is-changing-human-sexuality",
      "display_url" : "aeon.co\/essays\/micro-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761468863557107712",
  "text" : "On how data of porn consumption can be used for targeted recommendations. https:\/\/t.co\/TlQ70AlNAj",
  "id" : 761468863557107712,
  "created_at" : "2016-08-05 07:48:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/C27ZhO9GRi",
      "expanded_url" : "http:\/\/earthobservatory.nasa.gov\/blogs\/elegantfigures\/2013\/08\/05\/subtleties-of-color-part-1-of-6\/",
      "display_url" : "earthobservatory.nasa.gov\/blogs\/elegantf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761466341186469888",
  "text" : "Read through the subtleties of color over the last few days and it\u2019s amazing if you want to do any data viz. https:\/\/t.co\/C27ZhO9GRi",
  "id" : 761466341186469888,
  "created_at" : "2016-08-05 07:38:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/rer5VuTNyx",
      "expanded_url" : "http:\/\/betterposters.blogspot.com",
      "display_url" : "betterposters.blogspot.com"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/7gJarS050R",
      "expanded_url" : "https:\/\/twitter.com\/shaka_lulu\/status\/761323093134565376",
      "display_url" : "twitter.com\/shaka_lulu\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761334826498752514",
  "text" : "I don\u2019t know. I like the approach of https:\/\/t.co\/rer5VuTNyx much more. (Unless it\u2019s 3D pie charts, then shame away) https:\/\/t.co\/7gJarS050R",
  "id" : 761334826498752514,
  "created_at" : "2016-08-04 22:55:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761093481582374912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00866786667324, 8.281248156753248 ]
  },
  "id_str" : "761313278467473408",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer they went for a Japanese name straight away. Not a big help I guess?",
  "id" : 761313278467473408,
  "in_reply_to_status_id" : 761093481582374912,
  "created_at" : "2016-08-04 21:30:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761229376721653762",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17206902620399, 8.637794377290307 ]
  },
  "id_str" : "761229743182282753",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @kaiblin okay, great! \uD83D\uDC4D",
  "id" : 761229743182282753,
  "in_reply_to_status_id" : 761229376721653762,
  "created_at" : "2016-08-04 15:58:08 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761229008646377472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17095607710087, 8.635970642798242 ]
  },
  "id_str" : "761229293406019584",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @kaiblin I did a reply all to your email I think :-)",
  "id" : 761229293406019584,
  "in_reply_to_status_id" : 761229008646377472,
  "created_at" : "2016-08-04 15:56:21 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761221347603275776",
  "geo" : { },
  "id_str" : "761226353584836608",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @kaiblin ah, thanks for the info. I got mine from ftp:\/\/ftp.ncbi.nlm.nih.gov\/refseq\/release\/plastid\/plastid.1.genomic.gbff.gz",
  "id" : 761226353584836608,
  "in_reply_to_status_id" : 761221347603275776,
  "created_at" : "2016-08-04 15:44:40 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761185287540187136",
  "geo" : { },
  "id_str" : "761187881742372864",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice looks great! \uD83D\uDC4D",
  "id" : 761187881742372864,
  "in_reply_to_status_id" : 761185287540187136,
  "created_at" : "2016-08-04 13:11:47 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761185635147386880",
  "geo" : { },
  "id_str" : "761187567651921920",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock what makes them invalid? (tried to avoid parsing gb as much as possible so far)",
  "id" : 761187567651921920,
  "in_reply_to_status_id" : 761185635147386880,
  "created_at" : "2016-08-04 13:10:32 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761178587718381568",
  "geo" : { },
  "id_str" : "761184303053099008",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock record in gist breaks Biopython, if downloading NC_024258 directly from NCBI nucleotide it works  \u00AF\\_(\u30C4)_\/\u00AF",
  "id" : 761184303053099008,
  "in_reply_to_status_id" : 761178587718381568,
  "created_at" : "2016-08-04 12:57:34 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/xrI11CT3RS",
      "expanded_url" : "https:\/\/gist.github.com\/gedankenstuecke\/d2fdc5ccf8cc86794998dd1008e74e31",
      "display_url" : "gist.github.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "761178587718381568",
  "geo" : { },
  "id_str" : "761184108282253312",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock ok a) gave the wrong ID b) correct ID has the problem when downloaded from FTP-&gt;organelles. https:\/\/t.co\/xrI11CT3RS",
  "id" : 761184108282253312,
  "in_reply_to_status_id" : 761178587718381568,
  "created_at" : "2016-08-04 12:56:48 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761177966990753792",
  "geo" : { },
  "id_str" : "761178119789244417",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock downloaded through entrez?",
  "id" : 761178119789244417,
  "in_reply_to_status_id" : 761177966990753792,
  "created_at" : "2016-08-04 12:33:00 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761118720185896960",
  "geo" : { },
  "id_str" : "761171636892696576",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock somehow related. Can NC_024106 using the biopython genbank parser on your end?",
  "id" : 761171636892696576,
  "in_reply_to_status_id" : 761118720185896960,
  "created_at" : "2016-08-04 12:07:14 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rice",
      "screen_name" : "alanmrice",
      "indices" : [ 0, 10 ],
      "id_str" : "6872082",
      "id" : 6872082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761140356104749056",
  "geo" : { },
  "id_str" : "761170711478231040",
  "in_reply_to_user_id" : 6872082,
  "text" : "@alanmrice is that new avatar in \uD83C\uDDE6\uD83C\uDDFA? \uD83D\uDE0A",
  "id" : 761170711478231040,
  "in_reply_to_status_id" : 761140356104749056,
  "created_at" : "2016-08-04 12:03:34 +0000",
  "in_reply_to_screen_name" : "alanmrice",
  "in_reply_to_user_id_str" : "6872082",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 0, 14 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761138293807452160",
  "geo" : { },
  "id_str" : "761138559201996800",
  "in_reply_to_user_id" : 14177696,
  "text" : "@marcelsalathe well, I should be able to talk about saving a date ;-) (btw. did the stickers make it your way? :-))",
  "id" : 761138559201996800,
  "in_reply_to_status_id" : 761138293807452160,
  "created_at" : "2016-08-04 09:55:48 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Salathe",
      "screen_name" : "marcelsalathe",
      "indices" : [ 27, 41 ],
      "id_str" : "14177696",
      "id" : 14177696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Q7yJsHBtMZ",
      "expanded_url" : "https:\/\/twitter.com\/marcelsalathe\/status\/761121744304246784",
      "display_url" : "twitter.com\/marcelsalathe\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "761121744304246784",
  "geo" : { },
  "id_str" : "761137757704036352",
  "in_reply_to_user_id" : 14177696,
  "text" : "See me talking about\u2026 uhm, @marcelsalathe, what will I talk about? \uD83D\uDE02 https:\/\/t.co\/Q7yJsHBtMZ",
  "id" : 761137757704036352,
  "in_reply_to_status_id" : 761121744304246784,
  "created_at" : "2016-08-04 09:52:37 +0000",
  "in_reply_to_screen_name" : "marcelsalathe",
  "in_reply_to_user_id_str" : "14177696",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/L8Km47hbCr",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=0F6-npXUAnE",
      "display_url" : "youtube.com\/watch?v=0F6-np\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761120826452168705",
  "text" : "Finally got around to listen to Jack &amp; Amanda Palmer \uD83D\uDC96 https:\/\/t.co\/L8Km47hbCr",
  "id" : 761120826452168705,
  "created_at" : "2016-08-04 08:45:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761118720185896960",
  "geo" : { },
  "id_str" : "761118801899327488",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock quick cmd+f doesn\u2019t find any :)",
  "id" : 761118801899327488,
  "in_reply_to_status_id" : 761118720185896960,
  "created_at" : "2016-08-04 08:37:17 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761117780070375424",
  "geo" : { },
  "id_str" : "761117905006178304",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock ftp:\/\/ftp.ncbi.nlm.nih.gov\/refseq\/release\/mitochondrion\/ this one?",
  "id" : 761117905006178304,
  "in_reply_to_status_id" : 761117780070375424,
  "created_at" : "2016-08-04 08:33:44 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761116957844213760",
  "geo" : { },
  "id_str" : "761117203664035840",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @kaiblin oh, thanks",
  "id" : 761117203664035840,
  "in_reply_to_status_id" : 761116957844213760,
  "created_at" : "2016-08-04 08:30:56 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761116980887728128",
  "geo" : { },
  "id_str" : "761117119366832134",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock more interested in completeness of the assembly than chromosome status. don\u2019t care if they finalized to circularity.",
  "id" : 761117119366832134,
  "in_reply_to_status_id" : 761116980887728128,
  "created_at" : "2016-08-04 08:30:36 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761116577685118976",
  "geo" : { },
  "id_str" : "761116681284354050",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock that\u2019s my solution for now. going for \u201Ecomplete\u201C in the description field instead.",
  "id" : 761116681284354050,
  "in_reply_to_status_id" : 761116577685118976,
  "created_at" : "2016-08-04 08:28:52 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761116296977141766",
  "geo" : { },
  "id_str" : "761116504448303104",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock ah, okay. I have the multi-record dump that contains ~6.5 k records.",
  "id" : 761116504448303104,
  "in_reply_to_status_id" : 761116296977141766,
  "created_at" : "2016-08-04 08:28:10 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 0, 8 ],
      "id_str" : "58756672",
      "id" : 58756672
    }, {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 9, 17 ],
      "id_str" : "124202458",
      "id" : 124202458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761115529432096770",
  "geo" : { },
  "id_str" : "761115923574951936",
  "in_reply_to_user_id" : 58756672,
  "text" : "@pjacock @kaiblin XML more work than reasonable: Got a dump of the NCBI organelle DB, looking for complete ones of spec. tax. order.",
  "id" : 761115923574951936,
  "in_reply_to_status_id" : 761115529432096770,
  "created_at" : "2016-08-04 08:25:51 +0000",
  "in_reply_to_screen_name" : "pjacock",
  "in_reply_to_user_id_str" : "58756672",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 0, 8 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Peter Cock",
      "screen_name" : "pjacock",
      "indices" : [ 9, 17 ],
      "id_str" : "58756672",
      "id" : 58756672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761115047108026369",
  "geo" : { },
  "id_str" : "761115178087743488",
  "in_reply_to_user_id" : 124202458,
  "text" : "@kaiblin @pjacock Oh, nice! Lucky me! :-)",
  "id" : 761115178087743488,
  "in_reply_to_status_id" : 761115047108026369,
  "created_at" : "2016-08-04 08:22:53 +0000",
  "in_reply_to_screen_name" : "kaiblin",
  "in_reply_to_user_id_str" : "124202458",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761112978879983616",
  "text" : "Before I go reinventing the wheel: Dear biopythonistas, is there a way to get the \u201Ecircular\/linear\u201C information for genomic genbank records?",
  "id" : 761112978879983616,
  "created_at" : "2016-08-04 08:14:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Jaquith",
      "screen_name" : "markjaquith",
      "indices" : [ 3, 15 ],
      "id_str" : "821042",
      "id" : 821042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761104576187469825",
  "text" : "RT @markjaquith: I affectionately call the zxcvf group of keys on a QWERTY layout \u201Cthe tar pit\u201D.\n\nPlease don\u2019t get this joke. Don\u2019t make me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702925245691330561",
    "text" : "I affectionately call the zxcvf group of keys on a QWERTY layout \u201Cthe tar pit\u201D.\n\nPlease don\u2019t get this joke. Don\u2019t make me sad for you.",
    "id" : 702925245691330561,
    "created_at" : "2016-02-25 18:36:52 +0000",
    "user" : {
      "name" : "Mark Jaquith",
      "screen_name" : "markjaquith",
      "protected" : false,
      "id_str" : "821042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/915215186944020481\/jvNL3H--_normal.jpg",
      "id" : 821042,
      "verified" : false
    }
  },
  "id" : 761104576187469825,
  "created_at" : "2016-08-04 07:40:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Y0tbmu8ZQf",
      "expanded_url" : "https:\/\/twitter.com\/SCEdmunds\/status\/761039467536756736",
      "display_url" : "twitter.com\/SCEdmunds\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761103234106654720",
  "text" : "Never forget the Hypocrite's Oath: Do no harm, unless it will give you another publication. https:\/\/t.co\/Y0tbmu8ZQf",
  "id" : 761103234106654720,
  "created_at" : "2016-08-04 07:35:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "761000163183767553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.06081488274493, 8.818536469065705 ]
  },
  "id_str" : "761090815212957698",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019ll meet a French friend &amp; his Japanese wife, living in Germany, later today. Can ask them how they managed for their child \uD83D\uDE02",
  "id" : 761090815212957698,
  "in_reply_to_status_id" : 761000163183767553,
  "created_at" : "2016-08-04 06:46:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "indices" : [ 3, 11 ],
      "id_str" : "173881525",
      "id" : 173881525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/uJoHQ6lpYX",
      "expanded_url" : "https:\/\/twitter.com\/AskAManager\/status\/760858298660773889",
      "display_url" : "twitter.com\/AskAManager\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760897859415863296",
  "text" : "RT @iaravps: Scary situation, great answer https:\/\/t.co\/uJoHQ6lpYX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/uJoHQ6lpYX",
        "expanded_url" : "https:\/\/twitter.com\/AskAManager\/status\/760858298660773889",
        "display_url" : "twitter.com\/AskAManager\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760875629227151360",
    "text" : "Scary situation, great answer https:\/\/t.co\/uJoHQ6lpYX",
    "id" : 760875629227151360,
    "created_at" : "2016-08-03 16:31:01 +0000",
    "user" : {
      "name" : "Iara VPS",
      "screen_name" : "iaravps",
      "protected" : false,
      "id_str" : "173881525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/927263024678866944\/jbPg0pRm_normal.jpg",
      "id" : 173881525,
      "verified" : false
    }
  },
  "id" : 760897859415863296,
  "created_at" : "2016-08-03 17:59:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0meronNeylon",
      "screen_name" : "CameronNeylon",
      "indices" : [ 0, 14 ],
      "id_str" : "12984852",
      "id" : 12984852
    }, {
      "name" : "Babette Knauer",
      "screen_name" : "BabetteKnauer",
      "indices" : [ 15, 29 ],
      "id_str" : "3175580255",
      "id" : 3175580255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/eJLlQnwCND",
      "expanded_url" : "http:\/\/i.imgur.com\/5staT.jpg",
      "display_url" : "i.imgur.com\/5staT.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "760870341908566016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17158335119003, 8.628012958282483 ]
  },
  "id_str" : "760875547899654144",
  "in_reply_to_user_id" : 12984852,
  "text" : "@CameronNeylon @BabetteKnauer https:\/\/t.co\/eJLlQnwCND",
  "id" : 760875547899654144,
  "in_reply_to_status_id" : 760870341908566016,
  "created_at" : "2016-08-03 16:30:41 +0000",
  "in_reply_to_screen_name" : "CameronNeylon",
  "in_reply_to_user_id_str" : "12984852",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 0, 14 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760838398957522944",
  "geo" : { },
  "id_str" : "760866241464659968",
  "in_reply_to_user_id" : 20635230,
  "text" : "@PenguinGalaxy can we meet in your office next time? :p (speaking of: we\u2019ll be back in town 13th-21st)",
  "id" : 760866241464659968,
  "in_reply_to_status_id" : 760838398957522944,
  "created_at" : "2016-08-03 15:53:42 +0000",
  "in_reply_to_screen_name" : "PenguinGalaxy",
  "in_reply_to_user_id_str" : "20635230",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760862612821254144",
  "geo" : { },
  "id_str" : "760862795571269632",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety these have already been up for months, but it\u2019s a great fit for the campaign :-)",
  "id" : 760862795571269632,
  "in_reply_to_status_id" : 760862612821254144,
  "created_at" : "2016-08-03 15:40:01 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760805179918651392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17241009921316, 8.627599916495322 ]
  },
  "id_str" : "760859842902908929",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer use any Pokemon\u2019s name?",
  "id" : 760859842902908929,
  "in_reply_to_status_id" : 760805179918651392,
  "created_at" : "2016-08-03 15:28:17 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/qoHF8VD5Qo",
      "expanded_url" : "https:\/\/twitter.com\/konradfoerstner\/status\/760771438022451200",
      "display_url" : "twitter.com\/konradfoerstne\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17247393670826, 8.627477812723704 ]
  },
  "id_str" : "760852427297939456",
  "text" : "I\u2019d be super happy if I was one of the authors. https:\/\/t.co\/qoHF8VD5Qo",
  "id" : 760852427297939456,
  "created_at" : "2016-08-03 14:58:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/kGDdMKTPUC",
      "expanded_url" : "https:\/\/aeon.co\/essays\/that-faraway-trip-is-safer-than-you-think",
      "display_url" : "aeon.co\/essays\/that-fa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760851264372609024",
  "text" : "\u00ABIn an angry world, there is an argument to say that travel is more important than ever.\u00BB https:\/\/t.co\/kGDdMKTPUC",
  "id" : 760851264372609024,
  "created_at" : "2016-08-03 14:54:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/760849466962444289\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/kWzWIYSb6b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8Ujo7WgAAd63I.jpg",
      "id_str" : "760849464563236864",
      "id" : 760849464563236864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8Ujo7WgAAd63I.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1448,
        "resize" : "fit",
        "w" : 1448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1448,
        "resize" : "fit",
        "w" : 1448
      } ],
      "display_url" : "pic.twitter.com\/kWzWIYSb6b"
    } ],
    "hashtags" : [ {
      "text" : "scienceisglobal",
      "indices" : [ 25, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172641, 8.62738 ]
  },
  "id_str" : "760849466962444289",
  "text" : "Our labs contribution to #scienceisglobal \uD83C\uDF7A\uD83C\uDF5C https:\/\/t.co\/kWzWIYSb6b",
  "id" : 760849466962444289,
  "created_at" : "2016-08-03 14:47:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/2sUjGfmM2P",
      "expanded_url" : "http:\/\/www.wired.com\/2016\/08\/theranos-chance-clear-name-instead-tried-pivot\/",
      "display_url" : "wired.com\/2016\/08\/theran\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760844629260525568",
  "text" : "The miniLab. As mini as my trust in Theranos ever actually building something that works. https:\/\/t.co\/2sUjGfmM2P",
  "id" : 760844629260525568,
  "created_at" : "2016-08-03 14:27:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Tn4N4K3rNB",
      "expanded_url" : "http:\/\/etetoolkit.org\/",
      "display_url" : "etetoolkit.org"
    } ]
  },
  "geo" : { },
  "id_str" : "760809211697782786",
  "text" : "Playing around with ETE for the first time today and now I wonder: Why haven\u2019t I done this earlier?! https:\/\/t.co\/Tn4N4K3rNB",
  "id" : 760809211697782786,
  "created_at" : "2016-08-03 12:07:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Guest",
      "screen_name" : "o_guest",
      "indices" : [ 0, 8 ],
      "id_str" : "3865005196",
      "id" : 3865005196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760798805625307136",
  "geo" : { },
  "id_str" : "760798924508725249",
  "in_reply_to_user_id" : 3865005196,
  "text" : "@o_guest yes, that\u2019s mentioned in the article :-)",
  "id" : 760798924508725249,
  "in_reply_to_status_id" : 760798805625307136,
  "created_at" : "2016-08-03 11:26:13 +0000",
  "in_reply_to_screen_name" : "o_guest",
  "in_reply_to_user_id_str" : "3865005196",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/pZ1ut2ZbEa",
      "expanded_url" : "http:\/\/www.atlasobscura.com\/articles\/the-strangely-perplexing-problem-of-communicating-numbers-out-loud",
      "display_url" : "atlasobscura.com\/articles\/the-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760791416167686145",
  "text" : "\u00ABOne thing you can always do is just repeat yourself enough times\u00BB Why we don\u2019t have a NATO alphabet for numbers https:\/\/t.co\/pZ1ut2ZbEa",
  "id" : 760791416167686145,
  "created_at" : "2016-08-03 10:56:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin N. Kok",
      "screen_name" : "robinnkok",
      "indices" : [ 0, 10 ],
      "id_str" : "4841450680",
      "id" : 4841450680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760757646156849152",
  "geo" : { },
  "id_str" : "760757850012540929",
  "in_reply_to_user_id" : 4841450680,
  "text" : "@robinnkok we\u2019re pretty uncertain on where or how fast a dead\/alive cat is moving. Or at which position it starts.",
  "id" : 760757850012540929,
  "in_reply_to_status_id" : 760757646156849152,
  "created_at" : "2016-08-03 08:43:00 +0000",
  "in_reply_to_screen_name" : "robinnkok",
  "in_reply_to_user_id_str" : "4841450680",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "indices" : [ 3, 11 ],
      "id_str" : "124202458",
      "id" : 124202458
    }, {
      "name" : "Bastian Greshake Tzovaras",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 13, 29 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/Mok2MZDSJz",
      "expanded_url" : "https:\/\/xkcd.com\/1520\/",
      "display_url" : "xkcd.com\/1520\/"
    } ]
  },
  "geo" : { },
  "id_str" : "760757694861045760",
  "text" : "RT @kaiblin: @gedankenstuecke I still think https:\/\/t.co\/Mok2MZDSJz is the better response than the start index duality... ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bastian Greshake Tzovaras",
        "screen_name" : "gedankenstuecke",
        "indices" : [ 0, 16 ],
        "id_str" : "14286491",
        "id" : 14286491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/Mok2MZDSJz",
        "expanded_url" : "https:\/\/xkcd.com\/1520\/",
        "display_url" : "xkcd.com\/1520\/"
      } ]
    },
    "in_reply_to_status_id_str" : "760750785609211904",
    "geo" : { },
    "id_str" : "760751515774619652",
    "in_reply_to_user_id" : 14286491,
    "text" : "@gedankenstuecke I still think https:\/\/t.co\/Mok2MZDSJz is the better response than the start index duality... ;)",
    "id" : 760751515774619652,
    "in_reply_to_status_id" : 760750785609211904,
    "created_at" : "2016-08-03 08:17:50 +0000",
    "in_reply_to_screen_name" : "gedankenstuecke",
    "in_reply_to_user_id_str" : "14286491",
    "user" : {
      "name" : "Kai Blin",
      "screen_name" : "kaiblin",
      "protected" : false,
      "id_str" : "124202458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629590097\/kai_portrait_normal.jpg",
      "id" : 124202458,
      "verified" : false
    }
  },
  "id" : 760757694861045760,
  "created_at" : "2016-08-03 08:42:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/8r1ht4nbXl",
      "expanded_url" : "https:\/\/twitter.com\/aylwyn_scally\/status\/755006860919508993",
      "display_url" : "twitter.com\/aylwyn_scally\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1123827284278, 8.756830697431417 ]
  },
  "id_str" : "760750785609211904",
  "text" : "Biology decided to learn from Heisenberg and Schr\u00F6dinger, after being accused of only doing stamp collecting. https:\/\/t.co\/8r1ht4nbXl",
  "id" : 760750785609211904,
  "created_at" : "2016-08-03 08:14:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/760744212505788416\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/qvTnGzu55y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co600jPWEAAjjln.jpg",
      "id_str" : "760744201977991168",
      "id" : 760744201977991168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co600jPWEAAjjln.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qvTnGzu55y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/HprqeT9t9f",
      "expanded_url" : "http:\/\/25.media.tumblr.com\/tumblr_mc9qn83AFG1qbxlwho10_r1_250.gif",
      "display_url" : "25.media.tumblr.com\/tumblr_mc9qn83\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10462970952377, 8.764460869864385 ]
  },
  "id_str" : "760744212505788416",
  "text" : "Going into the next round. https:\/\/t.co\/HprqeT9t9f https:\/\/t.co\/qvTnGzu55y",
  "id" : 760744212505788416,
  "created_at" : "2016-08-03 07:48:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. Murat Eren",
      "screen_name" : "merenbey",
      "indices" : [ 69, 78 ],
      "id_str" : "16029156",
      "id" : 16029156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/0gASZ01heh",
      "expanded_url" : "https:\/\/twitter.com\/molecologist\/status\/760558316355399680",
      "display_url" : "twitter.com\/molecologist\/s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.10786006857037, 8.765140558741725 ]
  },
  "id_str" : "760730331507032064",
  "text" : "Yes!  I totally feel that my experience in photography is so useful, @merenbey. https:\/\/t.co\/0gASZ01heh",
  "id" : 760730331507032064,
  "created_at" : "2016-08-03 06:53:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BioinformaticsCampaignPromises",
      "indices" : [ 48, 79 ]
    }, {
      "text" : "ohfuckwait",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11399125209505, 8.753329666668971 ]
  },
  "id_str" : "760586822787399680",
  "text" : "Enough Big Data, we want Small Data Governance! #BioinformaticsCampaignPromises #ohfuckwait",
  "id" : 760586822787399680,
  "created_at" : "2016-08-02 21:23:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/dzjB9brASb",
      "expanded_url" : "https:\/\/twitter.com\/michaelhoffman\/status\/760522490930163713",
      "display_url" : "twitter.com\/michaelhoffman\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.11401427454881, 8.753377745854658 ]
  },
  "id_str" : "760585771179008001",
  "text" : "Weren\u2019t there some posts about stopping sequencing until we\u2019ve analyzed all the data we already generated back when? https:\/\/t.co\/dzjB9brASb",
  "id" : 760585771179008001,
  "created_at" : "2016-08-02 21:19:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/1U9Fmc3aWz",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/760397366679724032",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "760397366679724032",
  "geo" : { },
  "id_str" : "760509020620873729",
  "in_reply_to_user_id" : 14286491,
  "text" : "\uD83D\uDC4D\uD83D\uDC4D\uD83C\uDF89 https:\/\/t.co\/1U9Fmc3aWz",
  "id" : 760509020620873729,
  "in_reply_to_status_id" : 760397366679724032,
  "created_at" : "2016-08-02 16:14:14 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760482137103630336",
  "geo" : { },
  "id_str" : "760483747649228800",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed yes, I too was confused by this at first. :-)",
  "id" : 760483747649228800,
  "in_reply_to_status_id" : 760482137103630336,
  "created_at" : "2016-08-02 14:33:49 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugwump",
      "screen_name" : "ozaed",
      "indices" : [ 0, 6 ],
      "id_str" : "15806521",
      "id" : 15806521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760437686566055936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17251335406097, 8.627424271464102 ]
  },
  "id_str" : "760480684997738496",
  "in_reply_to_user_id" : 15806521,
  "text" : "@ozaed I think your off by 1: last entry is 2016, so expected to be Lower than all of 2015 for now? :)",
  "id" : 760480684997738496,
  "in_reply_to_status_id" : 760437686566055936,
  "created_at" : "2016-08-02 14:21:39 +0000",
  "in_reply_to_screen_name" : "ozaed",
  "in_reply_to_user_id_str" : "15806521",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jUEozQgMyh",
      "expanded_url" : "https:\/\/twitter.com\/torstenseemann\/status\/760385604093825024",
      "display_url" : "twitter.com\/torstenseemann\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760437494206857216",
  "text" : "I like hearing people trying to pronounce Caenorhabditis before going for \u201EC. elegans\u201C, \u201Ea nematode\u201C or \u201Ethis worm\u2026\u201C https:\/\/t.co\/jUEozQgMyh",
  "id" : 760437494206857216,
  "created_at" : "2016-08-02 11:30:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nyborg",
      "screen_name" : "ny_borg",
      "indices" : [ 0, 8 ],
      "id_str" : "570156398",
      "id" : 570156398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760434518176268288",
  "geo" : { },
  "id_str" : "760434692038492160",
  "in_reply_to_user_id" : 570156398,
  "text" : "@ny_borg oh, we\u2019ll be in London at the same time? \uD83D\uDE02",
  "id" : 760434692038492160,
  "in_reply_to_status_id" : 760434518176268288,
  "created_at" : "2016-08-02 11:18:53 +0000",
  "in_reply_to_screen_name" : "ny_borg",
  "in_reply_to_user_id_str" : "570156398",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.17246790713887, 8.627420508882135 ]
  },
  "id_str" : "760429032383143936",
  "text" : "\u00ABNeuroeconomics: one side brings the unrealistic expectations of how humans behave and the other side the \u2018methods\u2019 to prove them right.\u00BB",
  "id" : 760429032383143936,
  "created_at" : "2016-08-02 10:56:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egle Ramanauskaite \u2623",
      "screen_name" : "Seplute",
      "indices" : [ 0, 8 ],
      "id_str" : "188833865",
      "id" : 188833865
    }, {
      "name" : "Alice Sheppard",
      "screen_name" : "PenguinGalaxy",
      "indices" : [ 9, 23 ],
      "id_str" : "20635230",
      "id" : 20635230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760380832179744768",
  "geo" : { },
  "id_str" : "760427950374318081",
  "in_reply_to_user_id" : 188833865,
  "text" : "@Seplute @PenguinGalaxy awesome! :-)",
  "id" : 760427950374318081,
  "in_reply_to_status_id" : 760380832179744768,
  "created_at" : "2016-08-02 10:52:06 +0000",
  "in_reply_to_screen_name" : "Seplute",
  "in_reply_to_user_id_str" : "188833865",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/wni38HSXAL",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/comic\/parenting-game-theory",
      "display_url" : "smbc-comics.com\/comic\/parentin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760408228845019136",
  "text" : "Economics in a nutshell https:\/\/t.co\/wni38HSXAL",
  "id" : 760408228845019136,
  "created_at" : "2016-08-02 09:33:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "This American Life",
      "screen_name" : "ThisAmerLife",
      "indices" : [ 70, 83 ],
      "id_str" : "149180925",
      "id" : 149180925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760397366679724032",
  "text" : "I don\u2019t know anyone who\u2019s, by chance, having two tickets left for the @ThisAmerLife show in London, do I?",
  "id" : 760397366679724032,
  "created_at" : "2016-08-02 08:50:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M\u0430\u0438\u0438\u0443 \u0410\u044F\u044Ds ORCID ID 0000-0002-2552-9168",
      "screen_name" : "RiboGuy",
      "indices" : [ 0, 8 ],
      "id_str" : "546017714",
      "id" : 546017714
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 9, 22 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760323334416441345",
  "geo" : { },
  "id_str" : "760395932315901952",
  "in_reply_to_user_id" : 546017714,
  "text" : "@RiboGuy @royalsociety not fulfilling the 300 researchers in a given country criteria, but see the network in the post for all data. :)",
  "id" : 760395932315901952,
  "in_reply_to_status_id" : 760323334416441345,
  "created_at" : "2016-08-02 08:44:52 +0000",
  "in_reply_to_screen_name" : "RiboGuy",
  "in_reply_to_user_id_str" : "546017714",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hyewon",
      "screen_name" : "wanypie",
      "indices" : [ 0, 8 ],
      "id_str" : "115404620",
      "id" : 115404620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760333166037000192",
  "geo" : { },
  "id_str" : "760395821430996993",
  "in_reply_to_user_id" : 115404620,
  "text" : "@wanypie thanks!",
  "id" : 760395821430996993,
  "in_reply_to_status_id" : 760333166037000192,
  "created_at" : "2016-08-02 08:44:25 +0000",
  "in_reply_to_screen_name" : "wanypie",
  "in_reply_to_user_id_str" : "115404620",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shujun Li",
      "screen_name" : "hooklee75",
      "indices" : [ 0, 10 ],
      "id_str" : "396849909",
      "id" : 396849909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760187605778653185",
  "geo" : { },
  "id_str" : "760202785388388356",
  "in_reply_to_user_id" : 396849909,
  "text" : "@hooklee75 that\u2019s nice, what kind of cybersecurity?",
  "id" : 760202785388388356,
  "in_reply_to_status_id" : 760187605778653185,
  "created_at" : "2016-08-01 19:57:22 +0000",
  "in_reply_to_screen_name" : "hooklee75",
  "in_reply_to_user_id_str" : "396849909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shujun Li",
      "screen_name" : "hooklee75",
      "indices" : [ 0, 10 ],
      "id_str" : "396849909",
      "id" : 396849909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760185025891622916",
  "geo" : { },
  "id_str" : "760185817486790656",
  "in_reply_to_user_id" : 396849909,
  "text" : "@hooklee75 so thanks so much for the recommendation! :-)",
  "id" : 760185817486790656,
  "in_reply_to_status_id" : 760185025891622916,
  "created_at" : "2016-08-01 18:49:57 +0000",
  "in_reply_to_screen_name" : "hooklee75",
  "in_reply_to_user_id_str" : "396849909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shujun Li",
      "screen_name" : "hooklee75",
      "indices" : [ 0, 10 ],
      "id_str" : "396849909",
      "id" : 396849909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760173496756539393",
  "geo" : { },
  "id_str" : "760177937584971776",
  "in_reply_to_user_id" : 396849909,
  "text" : "@hooklee75 (and I will spare you the unfiltered chord diagram. R needs like 10 minutes to render that ;))",
  "id" : 760177937584971776,
  "in_reply_to_status_id" : 760173496756539393,
  "created_at" : "2016-08-01 18:18:38 +0000",
  "in_reply_to_screen_name" : "hooklee75",
  "in_reply_to_user_id_str" : "396849909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shujun Li",
      "screen_name" : "hooklee75",
      "indices" : [ 0, 10 ],
      "id_str" : "396849909",
      "id" : 396849909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760173496756539393",
  "geo" : { },
  "id_str" : "760177790247399424",
  "in_reply_to_user_id" : 396849909,
  "text" : "@hooklee75 I think the filtering was more useful than the switch of plots. But: it definitely is more beautiful than a network of same size.",
  "id" : 760177790247399424,
  "in_reply_to_status_id" : 760173496756539393,
  "created_at" : "2016-08-01 18:18:03 +0000",
  "in_reply_to_screen_name" : "hooklee75",
  "in_reply_to_user_id_str" : "396849909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35925269374654, 8.587667017690986 ]
  },
  "id_str" : "760133615011373056",
  "text" : "\u00ABI can envision a story about you traveling the world, helping people by being unashamed and open. Would make a nice superhero comic.\u00BB",
  "id" : 760133615011373056,
  "created_at" : "2016-08-01 15:22:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760129103953596416",
  "geo" : { },
  "id_str" : "760129253417578496",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety perfect! \uD83D\uDC4D",
  "id" : 760129253417578496,
  "in_reply_to_status_id" : 760129103953596416,
  "created_at" : "2016-08-01 15:05:11 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760126131286765568",
  "geo" : { },
  "id_str" : "760126300820471809",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety great, shall I just drop you a DM then? :)",
  "id" : 760126300820471809,
  "in_reply_to_status_id" : 760126131286765568,
  "created_at" : "2016-08-01 14:53:27 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shujun Li",
      "screen_name" : "hooklee75",
      "indices" : [ 0, 10 ],
      "id_str" : "396849909",
      "id" : 396849909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/2B3nwjPmxa",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "759873831259377664",
  "geo" : { },
  "id_str" : "760125664603365377",
  "in_reply_to_user_id" : 396849909,
  "text" : "@hooklee75 first shot at a chord diagram. https:\/\/t.co\/2B3nwjPmxa",
  "id" : 760125664603365377,
  "in_reply_to_status_id" : 759873831259377664,
  "created_at" : "2016-08-01 14:50:55 +0000",
  "in_reply_to_screen_name" : "hooklee75",
  "in_reply_to_user_id_str" : "396849909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Chadwick",
      "screen_name" : "chadatom",
      "indices" : [ 0, 9 ],
      "id_str" : "1863001507",
      "id" : 1863001507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760121595113435136",
  "geo" : { },
  "id_str" : "760125002192678912",
  "in_reply_to_user_id" : 1863001507,
  "text" : "@chadatom let\u2019s see when I can find the time for that. Takes manual labor.",
  "id" : 760125002192678912,
  "in_reply_to_status_id" : 760121595113435136,
  "created_at" : "2016-08-01 14:48:17 +0000",
  "in_reply_to_screen_name" : "chadatom",
  "in_reply_to_user_id_str" : "1863001507",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Dornan",
      "screen_name" : "bndornan",
      "indices" : [ 0, 9 ],
      "id_str" : "264953942",
      "id" : 264953942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760121559138926593",
  "geo" : { },
  "id_str" : "760121763472764929",
  "in_reply_to_user_id" : 264953942,
  "text" : "@bndornan great, looking forward to see that! :-)",
  "id" : 760121763472764929,
  "in_reply_to_status_id" : 760121559138926593,
  "created_at" : "2016-08-01 14:35:25 +0000",
  "in_reply_to_screen_name" : "bndornan",
  "in_reply_to_user_id_str" : "264953942",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760120077677191168",
  "geo" : { },
  "id_str" : "760120758957907968",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety great, I\u2019ll be in London in two weeks, will happily come by then!",
  "id" : 760120758957907968,
  "in_reply_to_status_id" : 760120077677191168,
  "created_at" : "2016-08-01 14:31:25 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Chadwick",
      "screen_name" : "chadatom",
      "indices" : [ 0, 9 ],
      "id_str" : "1863001507",
      "id" : 1863001507
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 10, 23 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760120015425310720",
  "geo" : { },
  "id_str" : "760120605349994496",
  "in_reply_to_user_id" : 1863001507,
  "text" : "@chadatom @royalsociety the data is public, linked in my blogpost. So everyone can easily do so! :-)",
  "id" : 760120605349994496,
  "in_reply_to_status_id" : 760120015425310720,
  "created_at" : "2016-08-01 14:30:49 +0000",
  "in_reply_to_screen_name" : "chadatom",
  "in_reply_to_user_id_str" : "1863001507",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760118627068698624",
  "geo" : { },
  "id_str" : "760119035858132992",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety damn, is it good enough for me to come over and visit? ;)",
  "id" : 760119035858132992,
  "in_reply_to_status_id" : 760118627068698624,
  "created_at" : "2016-08-01 14:24:35 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Dornan",
      "screen_name" : "bndornan",
      "indices" : [ 0, 9 ],
      "id_str" : "264953942",
      "id" : 264953942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760118300407898112",
  "geo" : { },
  "id_str" : "760118844274970625",
  "in_reply_to_user_id" : 264953942,
  "text" : "@bndornan please let me know if you do something cool with it! Happy to link to it!",
  "id" : 760118844274970625,
  "in_reply_to_status_id" : 760118300407898112,
  "created_at" : "2016-08-01 14:23:49 +0000",
  "in_reply_to_screen_name" : "bndornan",
  "in_reply_to_user_id_str" : "264953942",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760116875162488832",
  "geo" : { },
  "id_str" : "760118178278215680",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety glad you like it. Is this the first step to become a fellow? :p",
  "id" : 760118178278215680,
  "in_reply_to_status_id" : 760116875162488832,
  "created_at" : "2016-08-01 14:21:10 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 0, 13 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/pj1KgfRSch",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/760076610523525120",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "759817174810701824",
  "geo" : { },
  "id_str" : "760107386581450752",
  "in_reply_to_user_id" : 28567809,
  "text" : "@royalsociety https:\/\/t.co\/pj1KgfRSch here you go. :)",
  "id" : 760107386581450752,
  "in_reply_to_status_id" : 759817174810701824,
  "created_at" : "2016-08-01 13:38:17 +0000",
  "in_reply_to_screen_name" : "royalsociety",
  "in_reply_to_user_id_str" : "28567809",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760106026070863872",
  "text" : "\u00ABIf the German education system has taught me anything it is \u201CNever again\u201D for two things: The holocaust and sports.\u00BB",
  "id" : 760106026070863872,
  "created_at" : "2016-08-01 13:32:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Rosemary Mosco",
      "screen_name" : "RosemaryMosco",
      "indices" : [ 7, 21 ],
      "id_str" : "1020952663",
      "id" : 1020952663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760094816512253952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35442617965957, 8.550831710292538 ]
  },
  "id_str" : "760103604636311553",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @RosemaryMosco I don\u2019t follow your rules!",
  "id" : 760103604636311553,
  "in_reply_to_status_id" : 760094816512253952,
  "created_at" : "2016-08-01 13:23:16 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 77, 90 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/760076610523525120\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ryhCjeHH2p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoxVpSPWgAAkXH9.png",
      "id_str" : "760076604877996032",
      "id" : 760076604877996032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoxVpSPWgAAkXH9.png",
      "sizes" : [ {
        "h" : 509,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 587
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 587
      } ],
      "display_url" : "pic.twitter.com\/ryhCjeHH2p"
    } ],
    "hashtags" : [ {
      "text" : "ScienceIsGlobal",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/2B3nwjPmxa",
      "expanded_url" : "http:\/\/ruleofthirds.de\/scienceisglobal\/",
      "display_url" : "ruleofthirds.de\/scienceisgloba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760076610523525120",
  "text" : "Visualizing internat. collaborations among scientists w\/ #ScienceIsGlobal by @royalsociety https:\/\/t.co\/2B3nwjPmxa https:\/\/t.co\/ryhCjeHH2p",
  "id" : 760076610523525120,
  "created_at" : "2016-08-01 11:36:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shujun Li",
      "screen_name" : "hooklee75",
      "indices" : [ 0, 10 ],
      "id_str" : "396849909",
      "id" : 396849909
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 11, 24 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759873831259377664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.35920874525402, 8.58768170865931 ]
  },
  "id_str" : "759883227356069888",
  "in_reply_to_user_id" : 396849909,
  "text" : "@hooklee75 @royalsociety thx!",
  "id" : 759883227356069888,
  "in_reply_to_status_id" : 759873831259377664,
  "created_at" : "2016-07-31 22:47:34 +0000",
  "in_reply_to_screen_name" : "hooklee75",
  "in_reply_to_user_id_str" : "396849909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shujun Li",
      "screen_name" : "hooklee75",
      "indices" : [ 0, 10 ],
      "id_str" : "396849909",
      "id" : 396849909
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 11, 24 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759873030466052096",
  "geo" : { },
  "id_str" : "759873225597841408",
  "in_reply_to_user_id" : 396849909,
  "text" : "@hooklee75 @royalsociety Any recommendations on which tool to use for this? :)",
  "id" : 759873225597841408,
  "in_reply_to_status_id" : 759873030466052096,
  "created_at" : "2016-07-31 22:07:49 +0000",
  "in_reply_to_screen_name" : "hooklee75",
  "in_reply_to_user_id_str" : "396849909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shujun Li",
      "screen_name" : "hooklee75",
      "indices" : [ 0, 10 ],
      "id_str" : "396849909",
      "id" : 396849909
    }, {
      "name" : "The Royal Society",
      "screen_name" : "royalsociety",
      "indices" : [ 11, 24 ],
      "id_str" : "28567809",
      "id" : 28567809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "759854149114527744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.3592094461619, 8.587688685791502 ]
  },
  "id_str" : "759872270877818880",
  "in_reply_to_user_id" : 396849909,
  "text" : "@hooklee75 @royalsociety good idea. I\u2019ll give that a try!",
  "id" : 759872270877818880,
  "in_reply_to_status_id" : 759854149114527744,
  "created_at" : "2016-07-31 22:04:01 +0000",
  "in_reply_to_screen_name" : "hooklee75",
  "in_reply_to_user_id_str" : "396849909",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]