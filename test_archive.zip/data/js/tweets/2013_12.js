Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "418153819588292608",
  "text" : "\u00ABMein Problem beim Suchen ist, dass `Ball Snot\u00B4 offensichtlich ein Synonym f\u00FCr Sperma ist.\u00BB",
  "id" : 418153819588292608,
  "created_at" : "2013-12-31 22:56:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0704574434, 8.2438497176 ]
  },
  "id_str" : "418145192425029632",
  "text" : "\u00ABDas ist einfach dieser Bonner Akzent. Der klingt immer so vulg\u00E4r.\u00BB \u2014 \u00ABVulgar Display of Power!\u00BB",
  "id" : 418145192425029632,
  "created_at" : "2013-12-31 22:22:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003669052, 8.2648382243 ]
  },
  "id_str" : "418100055095386112",
  "text" : "\u00ABBei uns im Haus brennt es gerade irgendwie. Wir sind dann einfach mal gefahren.\u00BB",
  "id" : 418100055095386112,
  "created_at" : "2013-12-31 19:23:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096703474, 8.2830099607 ]
  },
  "id_str" : "418097260325793792",
  "text" : "\u00ABDanke f\u00FCrs Fahren!\u00BB\u2014\u00ABDanke f\u00FCrs fahren lassen. Ich muss dir was sagen: Ich kann nichts sehen und orientiere mich nur per Echolocation.\u00BB",
  "id" : 418097260325793792,
  "created_at" : "2013-12-31 19:12:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418091085349797889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0791121876, 8.2394645302 ]
  },
  "id_str" : "418091233471660033",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy oh, so hopefully I soon have worked along the lines of a world-famous researcher!",
  "id" : 418091233471660033,
  "in_reply_to_status_id" : 418091085349797889,
  "created_at" : "2013-12-31 18:48:12 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418089478667120642",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0755946616, 8.238558092 ]
  },
  "id_str" : "418090434922291200",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy may I ask where you submitted? :)",
  "id" : 418090434922291200,
  "in_reply_to_status_id" : 418089478667120642,
  "created_at" : "2013-12-31 18:45:02 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418087868666757121",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0718803597, 8.2435123049 ]
  },
  "id_str" : "418088051370643456",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente no worries, mehr ist die eine Seite immer noch zu lang um entspannt Eis zu essen.",
  "id" : 418088051370643456,
  "in_reply_to_status_id" : 418087868666757121,
  "created_at" : "2013-12-31 18:35:33 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/Kjlpbgv7D3",
      "expanded_url" : "http:\/\/wwwdelivery.superstock.com\/WI\/223\/1660\/PreviewComp\/SuperStock_1660R-12092.jpg",
      "display_url" : "wwwdelivery.superstock.com\/WI\/223\/1660\/Pr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "418085794860244992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0719468575, 8.2428466436 ]
  },
  "id_str" : "418087414956294144",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente ~ http:\/\/t.co\/Kjlpbgv7D3",
  "id" : 418087414956294144,
  "in_reply_to_status_id" : 418085794860244992,
  "created_at" : "2013-12-31 18:33:02 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418082318507442176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00879047, 8.2827106283 ]
  },
  "id_str" : "418083046391562240",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot pretending to care. Oh wait, that\u2019s so not you.",
  "id" : 418083046391562240,
  "in_reply_to_status_id" : 418082318507442176,
  "created_at" : "2013-12-31 18:15:40 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096665101, 8.2830710976 ]
  },
  "id_str" : "418081014846853120",
  "text" : "Ich sagte: \u00ABIch vertraue dir, nat\u00FCrlich darfst du meinen Bart trimmen.\u00BB Was ich h\u00E4tte sagen sollen: \u00ABNicht bevor du deine Brille aufsetzt!\u00BB",
  "id" : 418081014846853120,
  "created_at" : "2013-12-31 18:07:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/WV9PI0JNuJ",
      "expanded_url" : "https:\/\/medium.com\/matter\/8476df17bddf",
      "display_url" : "medium.com\/matter\/8476df1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418076806294822912",
  "text" : "This is what it\u2019s like to be at war with your body \u00ABHe spent every waking moment imagining freedom from the leg.\u00BB https:\/\/t.co\/WV9PI0JNuJ",
  "id" : 418076806294822912,
  "created_at" : "2013-12-31 17:50:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097811316, 8.2831081934 ]
  },
  "id_str" : "418072753854771201",
  "text" : "\u00ABIch finde zusammengesetzte Worte die mit Bindestrichen und einem O verbunden werden erotisch.\u00BB \u2014 \u00ABAlso sowas wie \u2018Ja-Oh-Ja!\u2019?\u00BB",
  "id" : 418072753854771201,
  "created_at" : "2013-12-31 17:34:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Richardson",
      "screen_name" : "heyaudy",
      "indices" : [ 0, 8 ],
      "id_str" : "14534523",
      "id" : 14534523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418051021202391041",
  "geo" : { },
  "id_str" : "418057412646809601",
  "in_reply_to_user_id" : 14534523,
  "text" : "@heyaudy good luck!",
  "id" : 418057412646809601,
  "in_reply_to_status_id" : 418051021202391041,
  "created_at" : "2013-12-31 16:33:48 +0000",
  "in_reply_to_screen_name" : "heyaudy",
  "in_reply_to_user_id_str" : "14534523",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/418041989540507648\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/6vBTi3Q5DV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc0u-XhCAAARxob.jpg",
      "id_str" : "418041989414649856",
      "id" : 418041989414649856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc0u-XhCAAARxob.jpg",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/6vBTi3Q5DV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/rnsmhkJYNR",
      "expanded_url" : "http:\/\/i.imgur.com\/my9g5Of.gif",
      "display_url" : "i.imgur.com\/my9g5Of.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009671, 8.28307 ]
  },
  "id_str" : "418041989540507648",
  "text" : "Wieso nur immer auf die Eins und die Drei\u2026 http:\/\/t.co\/rnsmhkJYNR http:\/\/t.co\/6vBTi3Q5DV",
  "id" : 418041989540507648,
  "created_at" : "2013-12-31 15:32:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/M1kM0nVjEn",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/artful-amoeba\/2013\/12\/31\/wonderful-things-leaping-fish-spends-entire-life-on-land\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+all-blogs%2Ffeed+%28Blog%3A+Scientific+American+Blogs+Posts%29",
      "display_url" : "blogs.scientificamerican.com\/artful-amoeba\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009687, 8.283093 ]
  },
  "id_str" : "418040863735160832",
  "text" : "Wonderful Things: Leaping Fish Spends Entire Life on Land http:\/\/t.co\/M1kM0nVjEn",
  "id" : 418040863735160832,
  "created_at" : "2013-12-31 15:28:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/H6Ux8XEZOM",
      "expanded_url" : "http:\/\/antisensescienceblog.wordpress.com\/2013\/12\/31\/malbac-improving-the-success-rates-of-ivf\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingBiologyEnglish+%28Research+Blogging+-+English+-+Biology%29",
      "display_url" : "antisensescienceblog.wordpress.com\/2013\/12\/31\/mal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418040596910317568",
  "text" : "MALBAC \u2013 Improving the success rates of IVF http:\/\/t.co\/H6Ux8XEZOM",
  "id" : 418040596910317568,
  "created_at" : "2013-12-31 15:26:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/d7d1Nr1rUF",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/71677121096",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/716771210\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009667, 8.283036 ]
  },
  "id_str" : "418032164811595776",
  "text" : "grad school http:\/\/t.co\/d7d1Nr1rUF",
  "id" : 418032164811595776,
  "created_at" : "2013-12-31 14:53:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/na4MndiOza",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/VmTEBXYo1RQ\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00967, 8.283048 ]
  },
  "id_str" : "418031164247769089",
  "text" : "Using colored beads to remind yourself that you will die\u00A0soon http:\/\/t.co\/na4MndiOza",
  "id" : 418031164247769089,
  "created_at" : "2013-12-31 14:49:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/NIMGnzysPr",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/12\/30\/sweet-ukulele-tribute-to-the-l.html",
      "display_url" : "boingboing.net\/2013\/12\/30\/swe\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009636, 8.283029 ]
  },
  "id_str" : "418030128414064640",
  "text" : "Sweet ukulele tribute to the largest Mersenne Prime http:\/\/t.co\/NIMGnzysPr",
  "id" : 418030128414064640,
  "created_at" : "2013-12-31 14:45:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/jsrwUrWR5O",
      "expanded_url" : "http:\/\/www.newyorker.com\/reporting\/2014\/01\/06\/140106fa_fact_schwartz?currentPage=all",
      "display_url" : "newyorker.com\/reporting\/2014\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684, 8.283082 ]
  },
  "id_str" : "418029844098994176",
  "text" : "Why are we still fighting the drug war? http:\/\/t.co\/jsrwUrWR5O",
  "id" : 418029844098994176,
  "created_at" : "2013-12-31 14:44:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/n0jOpvz2mA",
      "expanded_url" : "http:\/\/copyfight.corante.com\/archives\/2013\/12\/31\/authors_guild_remains_out_of_touch_with_reality.php",
      "display_url" : "copyfight.corante.com\/archives\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "418025037124599808",
  "text" : "RT @wilbanks: If you\u2019re paying dues to the Authors Guild at this point, you might contemplate the sunk cost fallacy. http:\/\/t.co\/n0jOpvz2mA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/n0jOpvz2mA",
        "expanded_url" : "http:\/\/copyfight.corante.com\/archives\/2013\/12\/31\/authors_guild_remains_out_of_touch_with_reality.php",
        "display_url" : "copyfight.corante.com\/archives\/2013\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "418024788737523712",
    "text" : "If you\u2019re paying dues to the Authors Guild at this point, you might contemplate the sunk cost fallacy. http:\/\/t.co\/n0jOpvz2mA",
    "id" : 418024788737523712,
    "created_at" : "2013-12-31 14:24:10 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 418025037124599808,
  "created_at" : "2013-12-31 14:25:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iseefaces",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/32FqiX6MGD",
      "expanded_url" : "http:\/\/instagram.com\/p\/iltUwBBwvA\/",
      "display_url" : "instagram.com\/p\/iltUwBBwvA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "418024336570994688",
  "text" : "\u00ABEntweder da ist ein Gesicht auf dem Nachttisch oder ich sollte mal meine Brille aufsetzen.\u00BB #iseefaces http:\/\/t.co\/32FqiX6MGD",
  "id" : 418024336570994688,
  "created_at" : "2013-12-31 14:22:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "indices" : [ 3, 11 ],
      "id_str" : "19984919",
      "id" : 19984919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/PJfd8A05Oh",
      "expanded_url" : "http:\/\/nblo.gs\/Sr9dZ",
      "display_url" : "nblo.gs\/Sr9dZ"
    } ]
  },
  "geo" : { },
  "id_str" : "418023833128669184",
  "text" : "RT @JBYoder: That\u2019s not a shark: A step-by-step guide for differentiating \u201Cgray things with dorsal fins.\" http:\/\/t.co\/PJfd8A05Oh by @WhySha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. David Shiffman",
        "screen_name" : "WhySharksMatter",
        "indices" : [ 119, 135 ],
        "id_str" : "66182591",
        "id" : 66182591
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/PJfd8A05Oh",
        "expanded_url" : "http:\/\/nblo.gs\/Sr9dZ",
        "display_url" : "nblo.gs\/Sr9dZ"
      } ]
    },
    "geo" : { },
    "id_str" : "418023263894118400",
    "text" : "That\u2019s not a shark: A step-by-step guide for differentiating \u201Cgray things with dorsal fins.\" http:\/\/t.co\/PJfd8A05Oh by @WhySharksMatter",
    "id" : 418023263894118400,
    "created_at" : "2013-12-31 14:18:07 +0000",
    "user" : {
      "name" : "Jeremy Yoder \uD83D\uDD96\uD83C\uDFFB",
      "screen_name" : "JBYoder",
      "protected" : false,
      "id_str" : "19984919",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/870850169759072256\/r0kxCgGs_normal.jpg",
      "id" : 19984919,
      "verified" : true
    }
  },
  "id" : 418023833128669184,
  "created_at" : "2013-12-31 14:20:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Skellett",
      "screen_name" : "Gurdur",
      "indices" : [ 0, 7 ],
      "id_str" : "125928028",
      "id" : 125928028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417996751761453056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096563099, 8.2830758316 ]
  },
  "id_str" : "418022298567077888",
  "in_reply_to_user_id" : 125928028,
  "text" : "@Gurdur you have my sympathies.",
  "id" : 418022298567077888,
  "in_reply_to_status_id" : 417996751761453056,
  "created_at" : "2013-12-31 14:14:17 +0000",
  "in_reply_to_screen_name" : "Gurdur",
  "in_reply_to_user_id_str" : "125928028",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672215733, 8.6860024658 ]
  },
  "id_str" : "417999206562140160",
  "text" : "\u00ABWenn einer von uns beiden Patient Zero f\u00FCr irgendwas wird ist der andere auch dran.\u00BB \u2014 \u00ABUnabh\u00E4ngig vom Infektionsweg, so romantisch.\u00BB",
  "id" : 417999206562140160,
  "created_at" : "2013-12-31 12:42:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417799500334264320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1671767608, 8.6857124604 ]
  },
  "id_str" : "417802540462657537",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn and as insert size is highly variable with RNAseq it\u2019s expected that primer starts move slightly.",
  "id" : 417802540462657537,
  "in_reply_to_status_id" : 417799500334264320,
  "created_at" : "2013-12-30 23:41:02 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417799500334264320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672559359, 8.6859524547 ]
  },
  "id_str" : "417802534297010177",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn well, depends on the fragment\/insert size. If you sheared it small enough you may wind up with +\/- only primer sequence.",
  "id" : 417802534297010177,
  "in_reply_to_status_id" : 417799500334264320,
  "created_at" : "2013-12-30 23:41:01 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417791003404562432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672777838, 8.6860067516 ]
  },
  "id_str" : "417791209982410752",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s cock tease!",
  "id" : 417791209982410752,
  "in_reply_to_status_id" : 417791003404562432,
  "created_at" : "2013-12-30 22:56:01 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417778825284812801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672777838, 8.6860067516 ]
  },
  "id_str" : "417790885502664704",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s \u2026ist deine Schlussfolgerung?",
  "id" : 417790885502664704,
  "in_reply_to_status_id" : 417778825284812801,
  "created_at" : "2013-12-30 22:54:43 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672556345, 8.6860965192 ]
  },
  "id_str" : "417778593650196480",
  "text" : "\u00ABMeine Gedanken sind einfach zu erraten weil ich immer nur 3 habe? Essen, ficken, Twitter.\u00BB \u2014 \u00ABUnd getwittert und gegessen haben wir schon.\u00BB",
  "id" : 417778593650196480,
  "created_at" : "2013-12-30 22:05:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417728143211118592",
  "text" : "\u00ABDaf\u00FCr bin ich ja jetzt Experte.\u00BB \u2014 \u00ABF\u00FCr den Kalten Krieg? Seit du mit mir geschlafen hast, oder was?\u00BB",
  "id" : 417728143211118592,
  "created_at" : "2013-12-30 18:45:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417716232368836608",
  "geo" : { },
  "id_str" : "417716984256933888",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn and now the kmers went from 5\u2019 to 3\u2019 end? Funny. But yes, that might be the primers. As RNAseq inserts can be &lt;70 bp would fit",
  "id" : 417716984256933888,
  "in_reply_to_status_id" : 417716232368836608,
  "created_at" : "2013-12-30 18:01:04 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417709898756276224",
  "text" : "\u00ABWas er dir eigentlich sagen will ist: Du kannst dich geehrt f\u00FChlen das er dich verletzt hat, das macht er nicht mit jedem.\u00BB",
  "id" : 417709898756276224,
  "created_at" : "2013-12-30 17:32:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417698851613450240",
  "geo" : { },
  "id_str" : "417698988905992192",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn then start with 10 right away.",
  "id" : 417698988905992192,
  "in_reply_to_status_id" : 417698851613450240,
  "created_at" : "2013-12-30 16:49:34 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417687567895523329",
  "geo" : { },
  "id_str" : "417697487340974080",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn yes, or even larger but then you need to allow more heap mem in java.",
  "id" : 417697487340974080,
  "in_reply_to_status_id" : 417687567895523329,
  "created_at" : "2013-12-30 16:43:36 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417669713246687232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.167242082, 8.6860154601 ]
  },
  "id_str" : "417682604889223168",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn did you try increasing the kmer-size in fastqc?",
  "id" : 417682604889223168,
  "in_reply_to_status_id" : 417669713246687232,
  "created_at" : "2013-12-30 15:44:27 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417657999969095680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1717008932, 8.6745280287 ]
  },
  "id_str" : "417664046536876032",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn okay, so probably shouldn\u2019t be multiplexed. Still wonder why it\u2019s 6 positions. (Bar coding is usually done using hexamers).",
  "id" : 417664046536876032,
  "in_reply_to_status_id" : 417657999969095680,
  "created_at" : "2013-12-30 14:30:43 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672368681, 8.6860428725 ]
  },
  "id_str" : "417654013958836224",
  "text" : "\u00ABWer kommt aus dem Kalten Krieg?\u00BB \u2014 \u00ABZahlensender. Naja, und du.\u00BB",
  "id" : 417654013958836224,
  "created_at" : "2013-12-30 13:50:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417649470432497664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1673427225, 8.6860665958 ]
  },
  "id_str" : "417649718962192384",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn well lane numbers don\u2019t matter. Do you have a single organism\/species or a mix that was barcoded?",
  "id" : 417649718962192384,
  "in_reply_to_status_id" : 417649470432497664,
  "created_at" : "2013-12-30 13:33:47 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672418677, 8.6859277515 ]
  },
  "id_str" : "417643146202583040",
  "text" : "\u00ABDer Feng Shui-Experte sagt der Sessel soll genau in den Weg, das unterbricht den Energiefluss &amp; h\u00E4lt Leute hier.\u00BB\u2014\u00ABT\u00FCren abschlie\u00DFen auch.\u00BB",
  "id" : 417643146202583040,
  "created_at" : "2013-12-30 13:07:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Ducker",
      "screen_name" : "andrewducker",
      "indices" : [ 3, 16 ],
      "id_str" : "9221622",
      "id" : 9221622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417641999987388416",
  "text" : "RT @andrewducker: Dolphins \u2018deliberately get high\u2019 on puffer fish nerve toxins by carefully chewing and passing them around http:\/\/t.co\/5vP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dlvrit.com\/\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/5vP0p9h0dA",
        "expanded_url" : "http:\/\/ind.pn\/1eQgtRH",
        "display_url" : "ind.pn\/1eQgtRH"
      } ]
    },
    "geo" : { },
    "id_str" : "417620545270595585",
    "text" : "Dolphins \u2018deliberately get high\u2019 on puffer fish nerve toxins by carefully chewing and passing them around http:\/\/t.co\/5vP0p9h0dA",
    "id" : 417620545270595585,
    "created_at" : "2013-12-30 11:37:51 +0000",
    "user" : {
      "name" : "Andrew Ducker",
      "screen_name" : "andrewducker",
      "protected" : false,
      "id_str" : "9221622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512715233370976256\/QfL7JYGT_normal.jpeg",
      "id" : 9221622,
      "verified" : false
    }
  },
  "id" : 417641999987388416,
  "created_at" : "2013-12-30 13:03:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672239438, 8.6858883145 ]
  },
  "id_str" : "417637220406001664",
  "text" : "\u00ABDass ihr Geschwister seid habe ich jetzt verstanden. Aber wieso legt ihr so viel Wert darauf das ihr kein Paar seid?\u00BB",
  "id" : 417637220406001664,
  "created_at" : "2013-12-30 12:44:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 0, 13 ],
      "id_str" : "19084034",
      "id" : 19084034
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 14, 27 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417341995808735233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672344137, 8.6860059285 ]
  },
  "id_str" : "417569658213261312",
  "in_reply_to_user_id" : 19084034,
  "text" : "@ericmjohnson @PhilippBayer thanks, sounds like I will have to read those as well :)",
  "id" : 417569658213261312,
  "in_reply_to_status_id" : 417341995808735233,
  "created_at" : "2013-12-30 08:15:39 +0000",
  "in_reply_to_screen_name" : "ericmjohnson",
  "in_reply_to_user_id_str" : "19084034",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/NRuU4mcavG",
      "expanded_url" : "http:\/\/mindhacks.com\/2013\/12\/29\/the-most-accurate-psychopaths-in-cinema\/",
      "display_url" : "mindhacks.com\/2013\/12\/29\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "417294352931901440",
  "text" : "The most accurate psychopaths in\u00A0cinema http:\/\/t.co\/NRuU4mcavG",
  "id" : 417294352931901440,
  "created_at" : "2013-12-29 14:01:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 74, 87 ],
      "id_str" : "19084034",
      "id" : 19084034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417267873283706880",
  "geo" : { },
  "id_str" : "417269870997172224",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and if you want to get serious about reading Darwin I guess @ericmjohnson can recommend which letters to read as well. ;)",
  "id" : 417269870997172224,
  "in_reply_to_status_id" : 417267873283706880,
  "created_at" : "2013-12-29 12:24:24 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417266124665810944",
  "geo" : { },
  "id_str" : "417267500179804160",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and also grab yourself a copy of The Expression of Emotions in Man and Animals if you haven\u2019t read it ;)",
  "id" : 417267500179804160,
  "in_reply_to_status_id" : 417266124665810944,
  "created_at" : "2013-12-29 12:14:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "herr_schrat",
      "screen_name" : "herr_schrat",
      "indices" : [ 50, 62 ],
      "id_str" : "16066591",
      "id" : 16066591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417266124665810944",
  "geo" : { },
  "id_str" : "417266525662642176",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer only read a German translation that @herr_schrat gifted me, but it\u2019s worth the time. Will have to read the original some day",
  "id" : 417266525662642176,
  "in_reply_to_status_id" : 417266124665810944,
  "created_at" : "2013-12-29 12:11:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417264537390166016",
  "geo" : { },
  "id_str" : "417265460485562368",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, for his time he was pretty progressive on racism &amp; slavery as well. Ever read The Voyage of the Beagle?",
  "id" : 417265460485562368,
  "in_reply_to_status_id" : 417264537390166016,
  "created_at" : "2013-12-29 12:06:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417262632781885440",
  "geo" : { },
  "id_str" : "417263141853343744",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer finding really unknown tetrapods is news. Figuring out that you shouldn\u2019t have been so arrogant to the locals? Not so much.",
  "id" : 417263141853343744,
  "in_reply_to_status_id" : 417262632781885440,
  "created_at" : "2013-12-29 11:57:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417261428588818432",
  "geo" : { },
  "id_str" : "417262158997901312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i was excited for the newly discovered tapir until I saw that they meant new to science, not in general.",
  "id" : 417262158997901312,
  "in_reply_to_status_id" : 417261428588818432,
  "created_at" : "2013-12-29 11:53:45 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417258836332773376",
  "geo" : { },
  "id_str" : "417261233608589312",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that the \u2018duons\u2019 are even mentioned shows that mindless PR bullshit works :(",
  "id" : 417261233608589312,
  "in_reply_to_status_id" : 417258836332773376,
  "created_at" : "2013-12-29 11:50:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417121999081574400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009753597, 8.2829133142 ]
  },
  "id_str" : "417254468267569153",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer uh, I dreamt of your data. Was the run single- or multiplex? :p",
  "id" : 417254468267569153,
  "in_reply_to_status_id" : 417121999081574400,
  "created_at" : "2013-12-29 11:23:12 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417121999081574400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00969572, 8.2831050083 ]
  },
  "id_str" : "417122368625319936",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer not to hate on BGI, but never trust the seq facilities in general. Humans make errors, even there :)",
  "id" : 417122368625319936,
  "in_reply_to_status_id" : 417121999081574400,
  "created_at" : "2013-12-29 02:38:17 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417121800477102080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00969572, 8.2831050083 ]
  },
  "id_str" : "417122070506795008",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer simplest way: run one of the tools mentioned in the post I linked to remove adapter sequences and see whether helps",
  "id" : 417122070506795008,
  "in_reply_to_status_id" : 417121800477102080,
  "created_at" : "2013-12-29 02:37:06 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417120629762949120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00969572, 8.2831050083 ]
  },
  "id_str" : "417121784685924352",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer nevertheless: running fastqc with &gt;kmer-size usually makes it more obvious (-k, works up to ~k 8 w\/o heap problems)",
  "id" : 417121784685924352,
  "in_reply_to_status_id" : 417120629762949120,
  "created_at" : "2013-12-29 02:35:57 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "417120629762949120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965262, 8.283016759 ]
  },
  "id_str" : "417121344879620097",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer which reads are those? Forward or reverse? Already trimmed adapters\/primers?",
  "id" : 417121344879620097,
  "in_reply_to_status_id" : 417120629762949120,
  "created_at" : "2013-12-29 02:34:13 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/smcYEPqiLE",
      "expanded_url" : "http:\/\/pathogenomics.bham.ac.uk\/blog\/2013\/04\/adaptor-trim-or-die-experiences-with-nextera-libraries\/",
      "display_url" : "pathogenomics.bham.ac.uk\/blog\/2013\/04\/a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "417119223752564736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096847364, 8.2830793575 ]
  },
  "id_str" : "417119601982726144",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer if at 3\u2032 end and mostly A\/T-homopolymers: http:\/\/t.co\/smcYEPqiLE",
  "id" : 417119601982726144,
  "in_reply_to_status_id" : 417119223752564736,
  "created_at" : "2013-12-29 02:27:17 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417104647456034816",
  "text" : "\u00ABIch kann mit Menschen befreundet sein ohne mit ihnen ins Bett zu gehen!\u00BB \u2014 \u00ABVor\u00FCbergehend. Fr\u00FCher oder sp\u00E4ter passiert es. Meist fr\u00FCher.\u00BB",
  "id" : 417104647456034816,
  "created_at" : "2013-12-29 01:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096848235, 8.2831678726 ]
  },
  "id_str" : "417102376181694465",
  "text" : "Prokrastination, Level Expert: \u00ABAnmeldung Promotion: overdue 156 days\u00BB",
  "id" : 417102376181694465,
  "created_at" : "2013-12-29 01:18:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/CHiDodIXpU",
      "expanded_url" : "http:\/\/greenfluorescentblog.wordpress.com\/2013\/12\/28\/the-microscopes-light-may-affect-your-experiment\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingBiologyEnglish+%28Research+Blogging+-+English+-+Biology%29",
      "display_url" : "greenfluorescentblog.wordpress.com\/2013\/12\/28\/the\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009663, 8.283102 ]
  },
  "id_str" : "417079943013863424",
  "text" : "The microscope\u2019s light may affect your experiment  http:\/\/t.co\/CHiDodIXpU",
  "id" : 417079943013863424,
  "created_at" : "2013-12-28 23:49:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417028717475815424",
  "text" : "\u00ABDas klingt wie \u2018Onkel Bilbo erz\u00E4hlt vom Fisten\u2019.\u00BB \u2014 \u00ABIch schreib die besten Kinderb\u00FCcher, da passiert wenigstens was!\u00BB",
  "id" : 417028717475815424,
  "created_at" : "2013-12-28 20:26:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417002998972555265",
  "text" : "\u00ABSo, jetzt wo ich die Welt zerst\u00F6rt habe kann ich duschen gehen.\u00BB \u2014 \u00ABUnd am Sonntag ruhst du dann?\u00BB",
  "id" : 417002998972555265,
  "created_at" : "2013-12-28 18:43:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "indices" : [ 3, 12 ],
      "id_str" : "14245811",
      "id" : 14245811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/YOphfAEFZl",
      "expanded_url" : "http:\/\/www.esquire.com\/blogs\/news\/we-broke-the-internet?src=soc_twtr",
      "display_url" : "esquire.com\/blogs\/news\/we-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416983082567487488",
  "text" : "RT @wilbanks: Press \"publish\" or perish. Great piece. http:\/\/t.co\/YOphfAEFZl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/YOphfAEFZl",
        "expanded_url" : "http:\/\/www.esquire.com\/blogs\/news\/we-broke-the-internet?src=soc_twtr",
        "display_url" : "esquire.com\/blogs\/news\/we-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416602752148467712",
    "text" : "Press \"publish\" or perish. Great piece. http:\/\/t.co\/YOphfAEFZl",
    "id" : 416602752148467712,
    "created_at" : "2013-12-27 16:13:30 +0000",
    "user" : {
      "name" : "John Wilbanks",
      "screen_name" : "wilbanks",
      "protected" : false,
      "id_str" : "14245811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/925696899566440448\/BUTdp410_normal.jpg",
      "id" : 14245811,
      "verified" : false
    }
  },
  "id" : 416983082567487488,
  "created_at" : "2013-12-28 17:24:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Bracy",
      "screen_name" : "cbracy",
      "indices" : [ 3, 10 ],
      "id_str" : "6571962",
      "id" : 6571962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Cr1HYtNk5A",
      "expanded_url" : "http:\/\/cbracy.tumblr.com\/post\/71423788182\/on-paul-graham-and-duck-dynasty",
      "display_url" : "cbracy.tumblr.com\/post\/714237881\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416981379730399232",
  "text" : "RT @cbracy: Alright I said all I want to say about Duck Dynasty and Paul Graham here: http:\/\/t.co\/Cr1HYtNk5A Back to vacation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/Cr1HYtNk5A",
        "expanded_url" : "http:\/\/cbracy.tumblr.com\/post\/71423788182\/on-paul-graham-and-duck-dynasty",
        "display_url" : "cbracy.tumblr.com\/post\/714237881\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416977411364773888",
    "text" : "Alright I said all I want to say about Duck Dynasty and Paul Graham here: http:\/\/t.co\/Cr1HYtNk5A Back to vacation.",
    "id" : 416977411364773888,
    "created_at" : "2013-12-28 17:02:16 +0000",
    "user" : {
      "name" : "Catherine Bracy",
      "screen_name" : "cbracy",
      "protected" : false,
      "id_str" : "6571962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734943418359549953\/X6_pDLaS_normal.jpg",
      "id" : 6571962,
      "verified" : false
    }
  },
  "id" : 416981379730399232,
  "created_at" : "2013-12-28 17:18:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416980267983597568",
  "geo" : { },
  "id_str" : "416981027756974080",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn molecular biology, the serial killer\u2019s bootcamp.",
  "id" : 416981027756974080,
  "in_reply_to_status_id" : 416980267983597568,
  "created_at" : "2013-12-28 17:16:38 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416975052072951808",
  "geo" : { },
  "id_str" : "416978493315223552",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn and as you\u2019re doing chloroform\/phenol extraction you\u2019re even better prepared!",
  "id" : 416978493315223552,
  "in_reply_to_status_id" : 416975052072951808,
  "created_at" : "2013-12-28 17:06:34 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416945804117434369",
  "geo" : { },
  "id_str" : "416946613228437504",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer and as always: let me know if you need any additional help. :)",
  "id" : 416946613228437504,
  "in_reply_to_status_id" : 416945804117434369,
  "created_at" : "2013-12-28 14:59:53 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416945804117434369",
  "geo" : { },
  "id_str" : "416946515236892672",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer thanks, I tried my best as I knew that both of my supervisors are no experts with NGS data themselves. ;)",
  "id" : 416946515236892672,
  "in_reply_to_status_id" : 416945804117434369,
  "created_at" : "2013-12-28 14:59:30 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416933744792981504",
  "geo" : { },
  "id_str" : "416935918894075904",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer if you have some details on your Illumina data I could give more advice, eg platform, read length, insert size",
  "id" : 416935918894075904,
  "in_reply_to_status_id" : 416933744792981504,
  "created_at" : "2013-12-28 14:17:24 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 11, 24 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416933744792981504",
  "geo" : { },
  "id_str" : "416934536279523328",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn @PhilippBayer i can email you my Master\u2019s thesis. There I did de novo RNASeq with HiSeq data and it has lots of citations.",
  "id" : 416934536279523328,
  "in_reply_to_status_id" : 416933744792981504,
  "created_at" : "2013-12-28 14:11:54 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/5qh0yUY8PK",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/czpECwuyuuU\/info%3Adoi%2F10.1371%2Fjournal.pone.0084157",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.001149, 8.258693 ]
  },
  "id_str" : "416921184555786240",
  "text" : "Forced Bioinformatics Acronyms, I present: BOBA FRET http:\/\/t.co\/5qh0yUY8PK",
  "id" : 416921184555786240,
  "created_at" : "2013-12-28 13:18:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/6hxNFmrn71",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/LVYXEq1NZJQ\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.002503, 8.255968 ]
  },
  "id_str" : "416920822390194176",
  "text" : "Lol my thesis: Theses distilled to one (snarky)\u00A0sentence &lt;3 http:\/\/t.co\/6hxNFmrn71",
  "id" : 416920822390194176,
  "created_at" : "2013-12-28 13:17:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416915404955471873",
  "geo" : { },
  "id_str" : "416915685114384384",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn what\u2019s the work around when doing ref-based assembly?",
  "id" : 416915685114384384,
  "in_reply_to_status_id" : 416915404955471873,
  "created_at" : "2013-12-28 12:56:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 25, 37 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416914164070617088",
  "geo" : { },
  "id_str" : "416915464041025536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn @helgerausch so I don\u2019t have to feel guilty, great. ;) Btw: no update on the paper so far.",
  "id" : 416915464041025536,
  "in_reply_to_status_id" : 416914164070617088,
  "created_at" : "2013-12-28 12:56:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416914537158156288",
  "geo" : { },
  "id_str" : "416915296688291841",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn the # of chromosomes is freakish, but .8 GBp total genome size seems to be not too unusual?",
  "id" : 416915296688291841,
  "in_reply_to_status_id" : 416914537158156288,
  "created_at" : "2013-12-28 12:55:27 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hadley Freeman",
      "screen_name" : "HadleyFreeman",
      "indices" : [ 3, 17 ],
      "id_str" : "333615851",
      "id" : 333615851
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HadleyFreeman\/status\/416910507920986112\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/zHn1VRngNv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bckp5d3CIAA1v0k.jpg",
      "id_str" : "416910507753218048",
      "id" : 416910507753218048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bckp5d3CIAA1v0k.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      } ],
      "display_url" : "pic.twitter.com\/zHn1VRngNv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416914170261807104",
  "text" : "RT @HadleyFreeman: I shall cite this Iain Banks quote on alternative cancer treatments forever. http:\/\/t.co\/zHn1VRngNv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HadleyFreeman\/status\/416910507920986112\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/zHn1VRngNv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bckp5d3CIAA1v0k.jpg",
        "id_str" : "416910507753218048",
        "id" : 416910507753218048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bckp5d3CIAA1v0k.jpg",
        "sizes" : [ {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        } ],
        "display_url" : "pic.twitter.com\/zHn1VRngNv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "416910507920986112",
    "text" : "I shall cite this Iain Banks quote on alternative cancer treatments forever. http:\/\/t.co\/zHn1VRngNv",
    "id" : 416910507920986112,
    "created_at" : "2013-12-28 12:36:25 +0000",
    "user" : {
      "name" : "Hadley Freeman",
      "screen_name" : "HadleyFreeman",
      "protected" : false,
      "id_str" : "333615851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/912409954300067840\/7noDGFsk_normal.jpg",
      "id" : 333615851,
      "verified" : true
    }
  },
  "id" : 416914170261807104,
  "created_at" : "2013-12-28 12:50:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 74, 86 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416911655616794624",
  "geo" : { },
  "id_str" : "416913984781291520",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn btw did you have a look at the Christmas present @helgerausch made yet? :)",
  "id" : 416913984781291520,
  "in_reply_to_status_id" : 416911655616794624,
  "created_at" : "2013-12-28 12:50:14 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416911655616794624",
  "geo" : { },
  "id_str" : "416912838176014336",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn yes! And I\u2019m surprised by the overall genome size of, not only repeat content! Really should read more on plants!",
  "id" : 416912838176014336,
  "in_reply_to_status_id" : 416911655616794624,
  "created_at" : "2013-12-28 12:45:41 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416910459069923328",
  "geo" : { },
  "id_str" : "416911428193644545",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn uh, i did\u2019t know that exception. And how cute Utricularia is!",
  "id" : 416911428193644545,
  "in_reply_to_status_id" : 416910459069923328,
  "created_at" : "2013-12-28 12:40:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C\u24D0thal G\u24D0rvey",
      "screen_name" : "onetruecathal",
      "indices" : [ 0, 14 ],
      "id_str" : "16066596",
      "id" : 16066596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416908051535634432",
  "geo" : { },
  "id_str" : "416908724394266624",
  "in_reply_to_user_id" : 16066596,
  "text" : "@onetruecathal google books\/ngrams should be pretty easy to use for that. ;)",
  "id" : 416908724394266624,
  "in_reply_to_status_id" : 416908051535634432,
  "created_at" : "2013-12-28 12:29:20 +0000",
  "in_reply_to_screen_name" : "onetruecathal",
  "in_reply_to_user_id_str" : "16066596",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416907320350629888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0011772912, 8.2587225418 ]
  },
  "id_str" : "416907721137733632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn ah, I only remembered that we chatted bout repeat contents while back and wasn\u2019t sure of the organism. :)",
  "id" : 416907721137733632,
  "in_reply_to_status_id" : 416907320350629888,
  "created_at" : "2013-12-28 12:25:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0012209296, 8.2587421742 ]
  },
  "id_str" : "416907083750330368",
  "text" : "Spurious correlations everywhere: \u00ABFrom the early 16th century onwards, in line with the advance of Protestantism and of syphilis [\u2026]\u00BB",
  "id" : 416907083750330368,
  "created_at" : "2013-12-28 12:22:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 14, 24 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416849931433807872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098076184, 8.2830961235 ]
  },
  "id_str" : "416891471628099584",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @eltonjohn iirc the repeat content was the problem in Danio as well. Did you work on gymnosperms?",
  "id" : 416891471628099584,
  "in_reply_to_status_id" : 416849931433807872,
  "created_at" : "2013-12-28 11:20:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416856773639667713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098076184, 8.2830961235 ]
  },
  "id_str" : "416891160255557632",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks! :)",
  "id" : 416891160255557632,
  "in_reply_to_status_id" : 416856773639667713,
  "created_at" : "2013-12-28 11:19:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/rdZhfbGkhC",
      "expanded_url" : "http:\/\/goo.gl\/Kc20aU",
      "display_url" : "goo.gl\/Kc20aU"
    } ]
  },
  "geo" : { },
  "id_str" : "416744131202121728",
  "text" : "On lying: \u00AByou deny yourself the kinds of collisions with reality that are necessary to improve your life\u00BB http:\/\/t.co\/rdZhfbGkhC",
  "id" : 416744131202121728,
  "created_at" : "2013-12-28 01:35:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 3, 18 ],
      "id_str" : "76013938",
      "id" : 76013938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Dc2CEPUSWO",
      "expanded_url" : "http:\/\/s.shr.lc\/1kNT03M",
      "display_url" : "s.shr.lc\/1kNT03M"
    } ]
  },
  "geo" : { },
  "id_str" : "416741909705793536",
  "text" : "RT @john_s_wilkins: New Study Exposes Acupuncture As Pseudoscience - SFGate - http:\/\/t.co\/Dc2CEPUSWO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/Dc2CEPUSWO",
        "expanded_url" : "http:\/\/s.shr.lc\/1kNT03M",
        "display_url" : "s.shr.lc\/1kNT03M"
      } ]
    },
    "geo" : { },
    "id_str" : "416741510508716032",
    "text" : "New Study Exposes Acupuncture As Pseudoscience - SFGate - http:\/\/t.co\/Dc2CEPUSWO",
    "id" : 416741510508716032,
    "created_at" : "2013-12-28 01:24:53 +0000",
    "user" : {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "protected" : false,
      "id_str" : "76013938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852294288838807552\/FZpeLbxA_normal.jpg",
      "id" : 76013938,
      "verified" : false
    }
  },
  "id" : 416741909705793536,
  "created_at" : "2013-12-28 01:26:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 82, 89 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/vS4wdhjJwB",
      "expanded_url" : "http:\/\/skd-online-collection.skd.museum\/de\/contents\/showArtist?id=548321",
      "display_url" : "skd-online-collection.skd.museum\/de\/contents\/sh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416739391256944640",
  "text" : "TIL: Rembrandt did even do porn using etching\/drypoint http:\/\/t.co\/vS4wdhjJwB \/cc @TnaKng",
  "id" : 416739391256944640,
  "created_at" : "2013-12-28 01:16:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Hahnel",
      "screen_name" : "MarkHahnel",
      "indices" : [ 3, 14 ],
      "id_str" : "160877807",
      "id" : 160877807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416735905551228928",
  "text" : "RT @MarkHahnel: Figshare Launches Premium Version with Private Collaborative Spaces and Increased Private Cloud Storage: http:\/\/t.co\/V3RwwZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/V3RwwZyfW1",
        "expanded_url" : "http:\/\/www.selectscience.net\/commPRdetails.aspx?artID=31232",
        "display_url" : "selectscience.net\/commPRdetails.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416319307736313856",
    "text" : "Figshare Launches Premium Version with Private Collaborative Spaces and Increased Private Cloud Storage: http:\/\/t.co\/V3RwwZyfW1",
    "id" : 416319307736313856,
    "created_at" : "2013-12-26 21:27:12 +0000",
    "user" : {
      "name" : "Mark Hahnel",
      "screen_name" : "MarkHahnel",
      "protected" : false,
      "id_str" : "160877807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261577964640\/3227fbfd6b56c7ff4127efd17168c5c1_normal.jpeg",
      "id" : 160877807,
      "verified" : false
    }
  },
  "id" : 416735905551228928,
  "created_at" : "2013-12-28 01:02:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hapax legomenon",
      "screen_name" : "DanielaKayB",
      "indices" : [ 3, 15 ],
      "id_str" : "417320419",
      "id" : 417320419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416735834193526784",
  "text" : "RT @DanielaKayB: Story of my life: If you haven't sniffed packets when you were 13, they'll never accept you as a hacker. http:\/\/t.co\/9K2xr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Monteiro wants @jack fired.",
        "screen_name" : "monteiro",
        "indices" : [ 130, 139 ],
        "id_str" : "2426",
        "id" : 2426
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/9K2xrAwZLY",
        "expanded_url" : "http:\/\/valleywag.gawker.com\/paul-graham-says-women-havent-been-hacking-for-the-pa-1490581236?rev=1388186389",
        "display_url" : "valleywag.gawker.com\/paul-graham-sa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416732610929631232",
    "text" : "Story of my life: If you haven't sniffed packets when you were 13, they'll never accept you as a hacker. http:\/\/t.co\/9K2xrAwZLY \/ @monteiro",
    "id" : 416732610929631232,
    "created_at" : "2013-12-28 00:49:31 +0000",
    "user" : {
      "name" : "hapax legomenon",
      "screen_name" : "DanielaKayB",
      "protected" : false,
      "id_str" : "417320419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/857884787918372864\/IGRVKUh8_normal.jpg",
      "id" : 417320419,
      "verified" : false
    }
  },
  "id" : 416735834193526784,
  "created_at" : "2013-12-28 01:02:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/DWcaovhcwi",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=TbcV3D1TYrc",
      "display_url" : "youtube.com\/watch?v=TbcV3D\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "416723451085615104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "416724768126406657",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj du meinst http:\/\/t.co\/DWcaovhcwi",
  "id" : 416724768126406657,
  "in_reply_to_status_id" : 416723451085615104,
  "created_at" : "2013-12-28 00:18:21 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "416724539834642432",
  "text" : "\u00ABBei der eMail-Benachrichtigung hatte ich auf das Twitterarchiv gehofft, aber es war ein Kot-Foto. Ich bin unsicher was mir das sagen soll\u2026\u00BB",
  "id" : 416724539834642432,
  "created_at" : "2013-12-28 00:17:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/98BleNDvTA",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/12\/27\/replace-bank-chiefs-with-small.html",
      "display_url" : "boingboing.net\/2013\/12\/27\/rep\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "416723719424585728",
  "text" : "Replace bank chiefs with small dogs: Chinese top\u00A0economist http:\/\/t.co\/98BleNDvTA",
  "id" : 416723719424585728,
  "created_at" : "2013-12-28 00:14:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/xoYwcHh74w",
      "expanded_url" : "http:\/\/www.faz.net\/aktuell\/feuilleton\/debatten\/chaos-communication-congress-der-radikalste-blogger-im-ganzen-land-12728769.html",
      "display_url" : "faz.net\/aktuell\/feuill\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "416716732389392384",
  "text" : "TIL: 1 Fefe entspricht also ~1.5 kreuznet oder auch ~2 M\u00E4dchenmannschaften. http:\/\/t.co\/xoYwcHh74w",
  "id" : 416716732389392384,
  "created_at" : "2013-12-27 23:46:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/MLehTNoqfq",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0083355",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965538, 8.2830085717 ]
  },
  "id_str" : "416714960178524160",
  "text" : "Predicting Pedestrian Flow? That\u2019s easy, the slow people will always throw themselves into my trajectory. http:\/\/t.co\/MLehTNoqfq",
  "id" : 416714960178524160,
  "created_at" : "2013-12-27 23:39:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/aRMru14r1D",
      "expanded_url" : "http:\/\/www.antipope.org\/charlie\/blog-static\/2013\/12\/metaphor-for-the-day.html",
      "display_url" : "antipope.org\/charlie\/blog-s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009637, 8.2831 ]
  },
  "id_str" : "416698240269303808",
  "text" : "UNIX religions: \u00ABa new, freely copyable kernel that all the faithful could read with their own eyes.\u00BB http:\/\/t.co\/aRMru14r1D",
  "id" : 416698240269303808,
  "created_at" : "2013-12-27 22:32:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camouflaj",
      "screen_name" : "Camouflaj",
      "indices" : [ 10, 20 ],
      "id_str" : "239454430",
      "id" : 239454430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416696937187135489",
  "text" : "Well done @camouflaj. Usually I\u2019m not the biggest fan of sneaking around in games, but R\u00E9publique is fun.",
  "id" : 416696937187135489,
  "created_at" : "2013-12-27 22:27:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    }, {
      "name" : "uncoolcat",
      "screen_name" : "_uncoolcat",
      "indices" : [ 11, 22 ],
      "id_str" : "2194699074",
      "id" : 2194699074
    }, {
      "name" : "Lia Leuchtturm",
      "screen_name" : "Liamie",
      "indices" : [ 23, 30 ],
      "id_str" : "167780104",
      "id" : 167780104
    }, {
      "name" : "mairegen",
      "screen_name" : "mairegen",
      "indices" : [ 31, 40 ],
      "id_str" : "14284297",
      "id" : 14284297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416648997219352576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096139732, 8.282968024 ]
  },
  "id_str" : "416676225684602881",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente @_uncoolcat @Liamie @mairegen mir wird der Kontext nicht gezeigt. Wenn ich den bekomme versuch ich es gern.",
  "id" : 416676225684602881,
  "in_reply_to_status_id" : 416648997219352576,
  "created_at" : "2013-12-27 21:05:28 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416577260406075393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "416580560556142593",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn (to be fair: similarly there were some tricky bits with Danio iirc, which slowed down doing the ref genome)",
  "id" : 416580560556142593,
  "in_reply_to_status_id" : 416577260406075393,
  "created_at" : "2013-12-27 14:45:19 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 0, 10 ],
      "id_str" : "15661851",
      "id" : 15661851
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 93, 106 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416577260406075393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "416580256687210496",
  "in_reply_to_user_id" : 15661851,
  "text" : "@eltonjohn yeah, though they are pretty large (~20 Gbp) &amp; hard to assembly if I remember @PhilippBayer correctly.",
  "id" : 416580256687210496,
  "in_reply_to_status_id" : 416577260406075393,
  "created_at" : "2013-12-27 14:44:07 +0000",
  "in_reply_to_screen_name" : "eltonjohn",
  "in_reply_to_user_id_str" : "15661851",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416572553193594880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "416573913653858304",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus have to admit my knowledge of Latimeria is pretty limited. Coming from a theoretical point one could think of niche conservatism.",
  "id" : 416573913653858304,
  "in_reply_to_status_id" : 416572553193594880,
  "created_at" : "2013-12-27 14:18:55 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 0, 7 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416567959327612929",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416569665088151552",
  "in_reply_to_user_id" : 21502180,
  "text" : "@yeysus sure there will have been selection pressures working. But morpholog. constancy will require purifying sel. on genes &amp; expressions",
  "id" : 416569665088151552,
  "in_reply_to_status_id" : 416567959327612929,
  "created_at" : "2013-12-27 14:02:02 +0000",
  "in_reply_to_screen_name" : "yeysus",
  "in_reply_to_user_id_str" : "21502180",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus del Valle",
      "screen_name" : "yeysus",
      "indices" : [ 65, 72 ],
      "id_str" : "21502180",
      "id" : 21502180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/DP68RzQWxH",
      "expanded_url" : "http:\/\/shar.es\/OVEkW",
      "display_url" : "shar.es\/OVEkW"
    } ]
  },
  "geo" : { },
  "id_str" : "416566556773322752",
  "text" : "The Top Genomes of 2013 (Danio rerio finally made the list!) \/HT @yeysus http:\/\/t.co\/DP68RzQWxH",
  "id" : 416566556773322752,
  "created_at" : "2013-12-27 13:49:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/YldvsqfkzR",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/ResearchBloggingBiologyEnglish\/~3\/RdkNjJvuKsY\/",
      "display_url" : "feedproxy.google.com\/~r\/ResearchBlo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009645, 8.282987 ]
  },
  "id_str" : "416565024115941376",
  "text" : "Why We Never Find Dinosaur Poo  http:\/\/t.co\/YldvsqfkzR",
  "id" : 416565024115941376,
  "created_at" : "2013-12-27 13:43:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fernanda castano",
      "screen_name" : "ferwen",
      "indices" : [ 3, 10 ],
      "id_str" : "33123688",
      "id" : 33123688
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PLOSONE",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/5VX3I8VTay",
      "expanded_url" : "http:\/\/dx.plos.org\/10.1371\/journal.pone.0084041",
      "display_url" : "dx.plos.org\/10.1371\/journa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416538540647133184",
  "text" : "RT @ferwen: #PLOSONE: First Dinosaurs from Saudi Arabia http:\/\/t.co\/5VX3I8VTay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PLOSONE",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/5VX3I8VTay",
        "expanded_url" : "http:\/\/dx.plos.org\/10.1371\/journal.pone.0084041",
        "display_url" : "dx.plos.org\/10.1371\/journa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "416511662661722112",
    "text" : "#PLOSONE: First Dinosaurs from Saudi Arabia http:\/\/t.co\/5VX3I8VTay",
    "id" : 416511662661722112,
    "created_at" : "2013-12-27 10:11:33 +0000",
    "user" : {
      "name" : "fernanda castano",
      "screen_name" : "ferwen",
      "protected" : false,
      "id_str" : "33123688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/908413180321452033\/JxquZ77e_normal.jpg",
      "id" : 33123688,
      "verified" : false
    }
  },
  "id" : 416538540647133184,
  "created_at" : "2013-12-27 11:58:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096631708, 8.2830484377 ]
  },
  "id_str" : "416529338784550913",
  "text" : "\u00ABcolleagues had started telling him that theory was beyond their understanding: a polite way of saying that he was nuts.\u00BB",
  "id" : 416529338784550913,
  "created_at" : "2013-12-27 11:21:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/kG5fGOw1Ul",
      "expanded_url" : "http:\/\/www.allenpike.com\/2013\/unprofessionalism\/",
      "display_url" : "allenpike.com\/2013\/unprofess\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009699, 8.28313 ]
  },
  "id_str" : "416525935970885632",
  "text" : "Unprofessionalism http:\/\/t.co\/kG5fGOw1Ul",
  "id" : 416525935970885632,
  "created_at" : "2013-12-27 11:08:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/YclpUiTteC",
      "expanded_url" : "http:\/\/i.imgur.com\/tSk60Np.gif",
      "display_url" : "i.imgur.com\/tSk60Np.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416360684684075008",
  "text" : "dog marley http:\/\/t.co\/YclpUiTteC",
  "id" : 416360684684075008,
  "created_at" : "2013-12-27 00:11:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/NXyls9BlCz",
      "expanded_url" : "http:\/\/i.imgur.com\/W84ORcf.jpg",
      "display_url" : "i.imgur.com\/W84ORcf.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "416348525619056640",
  "text" : "And here an example of those paedomorphic facial expressions in dogs http:\/\/t.co\/NXyls9BlCz",
  "id" : 416348525619056640,
  "created_at" : "2013-12-26 23:23:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416345453873995776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416345482982866945",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks! :)",
  "id" : 416345482982866945,
  "in_reply_to_status_id" : 416345453873995776,
  "created_at" : "2013-12-26 23:11:13 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416343925629014016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416344246837592064",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer care to mail me the pdf? my proxy\/vpn-settings are still fubar.",
  "id" : 416344246837592064,
  "in_reply_to_status_id" : 416343925629014016,
  "created_at" : "2013-12-26 23:06:18 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atul Butte",
      "screen_name" : "atulbutte",
      "indices" : [ 3, 13 ],
      "id_str" : "262365030",
      "id" : 262365030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/9mEhly7fqM",
      "expanded_url" : "http:\/\/buff.ly\/IWN49n",
      "display_url" : "buff.ly\/IWN49n"
    } ]
  },
  "geo" : { },
  "id_str" : "416338286165389312",
  "text" : "RT @atulbutte: How to become good at peer review: A guide for young scientists http:\/\/t.co\/9mEhly7fqM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/9mEhly7fqM",
        "expanded_url" : "http:\/\/buff.ly\/IWN49n",
        "display_url" : "buff.ly\/IWN49n"
      } ]
    },
    "geo" : { },
    "id_str" : "412323455858913280",
    "text" : "How to become good at peer review: A guide for young scientists http:\/\/t.co\/9mEhly7fqM",
    "id" : 412323455858913280,
    "created_at" : "2013-12-15 20:49:07 +0000",
    "user" : {
      "name" : "Atul Butte",
      "screen_name" : "atulbutte",
      "protected" : false,
      "id_str" : "262365030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685703528526950400\/C_EwTgXo_normal.jpg",
      "id" : 262365030,
      "verified" : true
    }
  },
  "id" : 416338286165389312,
  "created_at" : "2013-12-26 22:42:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 92, 105 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/A0pq1XHXWJ",
      "expanded_url" : "http:\/\/www.plosgenetics.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pgen.1003896",
      "display_url" : "plosgenetics.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416331498670002176",
  "text" : "Wolbachia Variants Induce Differential Protection to Viruses in Drosophila melanogaster \/cc @PhilippBayer http:\/\/t.co\/A0pq1XHXWJ",
  "id" : 416331498670002176,
  "created_at" : "2013-12-26 22:15:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/8atbLZgI2l",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0082686",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416330635943636994",
  "text" : "Paedomorphic Facial Expressions Give Dogs a Selective Advantage http:\/\/t.co\/8atbLZgI2l",
  "id" : 416330635943636994,
  "created_at" : "2013-12-26 22:12:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0091402727, 8.2815695695 ]
  },
  "id_str" : "416328278270824448",
  "text" : "\u00ABEr hat Absender- und Empf\u00E4nger-Feld vertauscht. Und sich dann gewundert wieso alle seine Bewerbungen unge\u00F6ffnet zur\u00FCckgekommen sind.\u00BB",
  "id" : 416328278270824448,
  "created_at" : "2013-12-26 22:02:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/7Z06CtNRGL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zQj6LxJTEQY",
      "display_url" : "youtube.com\/watch?v=zQj6Lx\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416310440327917569",
  "text" : "The theme of Back to the Future awesomely adapted for fingerstyle guitar. http:\/\/t.co\/7Z06CtNRGL",
  "id" : 416310440327917569,
  "created_at" : "2013-12-26 20:51:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/w1BwDVcFAS",
      "expanded_url" : "http:\/\/i.imgur.com\/QVcCRhF.png",
      "display_url" : "i.imgur.com\/QVcCRhF.png"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416308386536640513",
  "text" : "The way you drink your coffee can tell a lot about you. http:\/\/t.co\/w1BwDVcFAS",
  "id" : 416308386536640513,
  "created_at" : "2013-12-26 20:43:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EV6DzFtA1n",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=G4O_cpqLPZA",
      "display_url" : "youtube.com\/watch?v=G4O_cp\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416306200385712128",
  "text" : "\u00ABAnd I don't mean to tell you that I love you any less. But there's no doubt about it that I liked you better deaf\u00BB http:\/\/t.co\/EV6DzFtA1n",
  "id" : 416306200385712128,
  "created_at" : "2013-12-26 20:35:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096350783, 8.28297405 ]
  },
  "id_str" : "416303919841951744",
  "text" : "Yes, the MIRA manual is &gt;2x as long as The Book of Genesis. But soon my MIRA manifest file can battle The Communist Manifesto length-wise!",
  "id" : 416303919841951744,
  "created_at" : "2013-12-26 20:26:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/wkFxItTrzc",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/zD450DW5Zmo\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.61879, 7.201994 ]
  },
  "id_str" : "416205546048749568",
  "text" : "Not only physicists http:\/\/t.co\/wkFxItTrzc",
  "id" : 416205546048749568,
  "created_at" : "2013-12-26 13:55:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/wz3YzQqhPW",
      "expanded_url" : "http:\/\/www.phdcomics.com\/comics.php?f=1668",
      "display_url" : "phdcomics.com\/comics.php?f=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.618737, 7.201949 ]
  },
  "id_str" : "416199157163229184",
  "text" : "Proof Santa doesn't Exist http:\/\/t.co\/wz3YzQqhPW",
  "id" : 416199157163229184,
  "created_at" : "2013-12-26 13:29:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6184099807, 7.2030713909 ]
  },
  "id_str" : "416197906132373505",
  "text" : "\u00ABSo wie ihr hier alle im Wohnzimmer liegt sieht es voll nach Kommune aus!\u00BB \u2014 \u00ABMehr nach Triage-Station\u2026\u00BB",
  "id" : 416197906132373505,
  "created_at" : "2013-12-26 13:24:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6183109686, 7.2032280294 ]
  },
  "id_str" : "416184597274443776",
  "text" : "\u00ABDu siehst aus wie eine B\u00E4rtierchen.\u00BB \u2014 \u00ABB\u00E4rttierchen!\u00BB",
  "id" : 416184597274443776,
  "created_at" : "2013-12-26 12:31:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6183179945, 7.2032085325 ]
  },
  "id_str" : "416180801781661696",
  "text" : "\u00ABJetzt tritt er f\u00FCr ein halbes Jahr lang in die Kirche ein um kirchlich Heiraten zu k\u00F6nnen.\u00BB \u2014 \u00ABSeelenheil im Probeabo.\u00BB",
  "id" : 416180801781661696,
  "created_at" : "2013-12-26 12:16:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "416171271341473792",
  "text" : "\u00ABLangweiliger als Star Wars zu sein, damit k\u00F6nnte ich ja noch leben. Aber langweiliger als die Mathematik?!\u00BB",
  "id" : 416171271341473792,
  "created_at" : "2013-12-26 11:38:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/zXK4qt0Mq0",
      "expanded_url" : "http:\/\/instagram.com\/p\/iYfQpXhwux\/",
      "display_url" : "instagram.com\/p\/iYfQpXhwux\/"
    } ]
  },
  "geo" : { },
  "id_str" : "416163822295318529",
  "text" : "what year is it?! http:\/\/t.co\/zXK4qt0Mq0",
  "id" : 416163822295318529,
  "created_at" : "2013-12-26 11:09:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6129662941, 7.1961513864 ]
  },
  "id_str" : "416027946126938112",
  "text" : "\u00ABIst das Darwin auf deinem Shirt? Da hab ich mal ne Frage: Woher kommen Fische?\u00BB\u2014\u00ABAlso, das ist\u2026\u00AB\u2014\u00ABFuck, dein Gesicht sagt du bist Biologe\u2026\u00BB",
  "id" : 416027946126938112,
  "created_at" : "2013-12-26 02:09:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Der @KleineMaulwurf",
      "screen_name" : "KleineMaulwurf",
      "indices" : [ 0, 15 ],
      "id_str" : "49373312",
      "id" : 49373312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "416025283523661825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6140822584, 7.1957917462 ]
  },
  "id_str" : "416027192939020288",
  "in_reply_to_user_id" : 49373312,
  "text" : "@KleineMaulwurf best supporting act!",
  "id" : 416027192939020288,
  "in_reply_to_status_id" : 416025283523661825,
  "created_at" : "2013-12-26 02:06:26 +0000",
  "in_reply_to_screen_name" : "KleineMaulwurf",
  "in_reply_to_user_id_str" : "49373312",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6141092237, 7.1959822235 ]
  },
  "id_str" : "416014253502779392",
  "text" : "\u00ABWieso hast du so viele Haare im Gesicht?\u00BB \u2014 \u00ABDamit ich dich besser bet\u00F6ren kann, Mr. Barkeep.\u00BB",
  "id" : 416014253502779392,
  "created_at" : "2013-12-26 01:15:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6140583318, 7.1960036528 ]
  },
  "id_str" : "416011175407927296",
  "text" : "\u00ABDu magst Westernhagen!? H\u00E4tte ich das fr\u00FCher rausgefunden w\u00E4ren wir niemals so lange zusammen gewesen!\u00BB",
  "id" : 416011175407927296,
  "created_at" : "2013-12-26 01:02:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415977616022458368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6125466779, 7.1953192808 ]
  },
  "id_str" : "415978256224239616",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon I wouldn\u2019t dare!",
  "id" : 415978256224239616,
  "in_reply_to_status_id" : 415977616022458368,
  "created_at" : "2013-12-25 22:51:59 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415976805917810688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.612642619, 7.1953954839 ]
  },
  "id_str" : "415976965817241600",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon okay, du meinst also n\u00FCchtern kannst du nicht arbeiten. ;)",
  "id" : 415976965817241600,
  "in_reply_to_status_id" : 415976805917810688,
  "created_at" : "2013-12-25 22:46:51 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415975799393910784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6126349948, 7.1953292124 ]
  },
  "id_str" : "415976612434567168",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon tausche in dem Fall ein Bier gegen einen neuen Output von dir.",
  "id" : 415976612434567168,
  "in_reply_to_status_id" : 415975799393910784,
  "created_at" : "2013-12-25 22:45:27 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415974826546061312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6126429899, 7.1953168287 ]
  },
  "id_str" : "415975247708688384",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon ich brauche die ja weil ich den geplanten Text vergesse, aber ghostwriting klingt auch gut. Hast du ein paar Kostproben?",
  "id" : 415975247708688384,
  "in_reply_to_status_id" : 415974826546061312,
  "created_at" : "2013-12-25 22:40:02 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6126552002, 7.1952988261 ]
  },
  "id_str" : "415974611386630144",
  "text" : "\u00ABEr kann mit seiner Stirnfalte \u00FCbrigens sogar Bleistifte aufheben!\u00BB",
  "id" : 415974611386630144,
  "created_at" : "2013-12-25 22:37:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415974254665281536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6126995626, 7.1953703874 ]
  },
  "id_str" : "415974487604350976",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon in keiner weise, ich muss immer auf die gleichen 2-3 fallback Lines zur\u00FCckgreifen.",
  "id" : 415974487604350976,
  "in_reply_to_status_id" : 415974254665281536,
  "created_at" : "2013-12-25 22:37:00 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415971615596625920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6126573706, 7.1953022838 ]
  },
  "id_str" : "415974085353803776",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon willst du Souffleur spielen?",
  "id" : 415974085353803776,
  "in_reply_to_status_id" : 415971615596625920,
  "created_at" : "2013-12-25 22:35:25 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6126243511, 7.1950853717 ]
  },
  "id_str" : "415969524786421760",
  "text" : "\u00ABHast du mal ein Bl\u00E4ttchen f\u00FCr mich?\u00BB \u2014 \u00ABDu Sau, du willst ins Bettchen mit mir?!\u00BB",
  "id" : 415969524786421760,
  "created_at" : "2013-12-25 22:17:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6126662723, 7.1953086282 ]
  },
  "id_str" : "415966948389048320",
  "text" : "\u00ABIch kann doch nicht ausziehen, das kann ich mir nicht leisten. Wovon soll ich mir dann Schuhe kaufen?!\u00BB",
  "id" : 415966948389048320,
  "created_at" : "2013-12-25 22:07:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6188488835, 7.2017742938 ]
  },
  "id_str" : "415959671095451648",
  "text" : "\u00ABOh, holt ihr mich vom Bahnhof ab um mich vor den Ghetto-Kids zu besch\u00FCtzen?\u00BB \u2014 \u00ABWir sind die Ghetto-Kids!\u00BB",
  "id" : 415959671095451648,
  "created_at" : "2013-12-25 21:38:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    }, {
      "name" : "Creative Commons",
      "screen_name" : "creativecommons",
      "indices" : [ 43, 59 ],
      "id_str" : "17462723",
      "id" : 17462723
    }, {
      "name" : "Lessig",
      "screen_name" : "lessig",
      "indices" : [ 85, 92 ],
      "id_str" : "11388132",
      "id" : 11388132
    }, {
      "name" : "Cory Doctorow",
      "screen_name" : "doctorow",
      "indices" : [ 94, 103 ],
      "id_str" : "2729061",
      "id" : 2729061
    }, {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 105, 117 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415882722784321536",
  "text" : "RT @brainpicker: Always a smile-inducer: A @creativecommons Christmas carol starring @lessig, @doctorow, @kevin2kelly and more http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Creative Commons",
        "screen_name" : "creativecommons",
        "indices" : [ 26, 42 ],
        "id_str" : "17462723",
        "id" : 17462723
      }, {
        "name" : "Lessig",
        "screen_name" : "lessig",
        "indices" : [ 68, 75 ],
        "id_str" : "11388132",
        "id" : 11388132
      }, {
        "name" : "Cory Doctorow",
        "screen_name" : "doctorow",
        "indices" : [ 77, 86 ],
        "id_str" : "2729061",
        "id" : 2729061
      }, {
        "name" : "Kevin Kelly",
        "screen_name" : "kevin2kelly",
        "indices" : [ 88, 100 ],
        "id_str" : "1532061",
        "id" : 1532061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/RfIVG42Q7f",
        "expanded_url" : "http:\/\/j.mp\/1fH5q9K",
        "display_url" : "j.mp\/1fH5q9K"
      } ]
    },
    "geo" : { },
    "id_str" : "415880141668368384",
    "text" : "Always a smile-inducer: A @creativecommons Christmas carol starring @lessig, @doctorow, @kevin2kelly and more http:\/\/t.co\/RfIVG42Q7f",
    "id" : 415880141668368384,
    "created_at" : "2013-12-25 16:22:07 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577255253852065794\/qGnSwsBR_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 415882722784321536,
  "created_at" : "2013-12-25 16:32:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/x5hM4aYvJf",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/1j1nUSZKYrY\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.618809, 7.201967 ]
  },
  "id_str" : "415880818108944384",
  "text" : "What we can learn from dialect\u00A0maps http:\/\/t.co\/x5hM4aYvJf",
  "id" : 415880818108944384,
  "created_at" : "2013-12-25 16:24:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/6trGZlrLs8",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1050",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.618712, 7.201872 ]
  },
  "id_str" : "415879955244134400",
  "text" : "all i want for christmas http:\/\/t.co\/6trGZlrLs8",
  "id" : 415879955244134400,
  "created_at" : "2013-12-25 16:21:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.618814758, 7.2017055956 ]
  },
  "id_str" : "415876303192354816",
  "text" : "\u00ABWir k\u00F6nnen ja Arbeitsteilung machen: Du legst dich in die Badewanne und ich mach uns was zu essen.\u00BB",
  "id" : 415876303192354816,
  "created_at" : "2013-12-25 16:06:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6188202284, 7.2017864717 ]
  },
  "id_str" : "415838455210713088",
  "text" : "\u00ABLeute denen ich vertraue lasse ich gern mit meinem Auto fahren.\u00BB \u2014 \u00ABAber mich l\u00E4sst du nie mit deinem Auto fahren!\u00BB \u2014 \u00ABSiehste?\u00BB",
  "id" : 415838455210713088,
  "created_at" : "2013-12-25 13:36:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6188474251, 7.2017314988 ]
  },
  "id_str" : "415833443432681472",
  "text" : "Wenn die Autokorrektur auf \u2018Luftbett\u2019 lieber \u2018Luftverteidigungsmittel\u2019 machen will.",
  "id" : 415833443432681472,
  "created_at" : "2013-12-25 13:16:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6126314721, 7.1953206008 ]
  },
  "id_str" : "415642706623598592",
  "text" : "\u00ABHallo Mutter, ich habe deinen Namen schon vergessen. Aber ich freue mich sehr dich zu sehen!\u00BB",
  "id" : 415642706623598592,
  "created_at" : "2013-12-25 00:38:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.612643797, 7.1954757962 ]
  },
  "id_str" : "415636731766272000",
  "text" : "\u00ABDie Beziehung mit dir hat mir ja auch jede Chance genommen jemals normal zu werden. Und daf\u00FCr bin ich sehr dankbar.\u00BB",
  "id" : 415636731766272000,
  "created_at" : "2013-12-25 00:14:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6188211488, 7.2017841399 ]
  },
  "id_str" : "415607786064871424",
  "text" : "\u00ABUm 23:00 Uhr muss sie sowieso in die Kirche.\u00BB \u2014 \u00ABUnd wir in die Kneipe.\u00BB \u2014 \u00ABSo hat jeder seine Religion.\u00BB",
  "id" : 415607786064871424,
  "created_at" : "2013-12-24 22:19:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6188099884, 7.201780578 ]
  },
  "id_str" : "415564031878258688",
  "text" : "\u00ABIch finde die Musik super!\u00BB \u2014 \u00ABIch w\u00FCnsche mir Last Christmas zur\u00FCck\u2026\u00BB",
  "id" : 415564031878258688,
  "created_at" : "2013-12-24 19:26:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.618815844, 7.2017672091 ]
  },
  "id_str" : "415524818189312000",
  "text" : "\u00ABErinnerst du dich an das niedliche Kind aus dem Pfadfinderlager? Das was sich immer in die Hose gekackt hat.\u00BB",
  "id" : 415524818189312000,
  "created_at" : "2013-12-24 16:50:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415477734740336640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.6176479933, 7.2028488255 ]
  },
  "id_str" : "415478060776189952",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon all cookies are beautiful",
  "id" : 415478060776189952,
  "in_reply_to_status_id" : 415477734740336640,
  "created_at" : "2013-12-24 13:44:23 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/Mqc8FuBvtH",
      "expanded_url" : "http:\/\/i.imgur.com\/3SpvLvV.jpg",
      "display_url" : "i.imgur.com\/3SpvLvV.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.455062, 6.982076 ]
  },
  "id_str" : "415466556890841088",
  "text" : "Damn, that would have been a way to save my dinosaur cookies too! http:\/\/t.co\/Mqc8FuBvtH",
  "id" : 415466556890841088,
  "created_at" : "2013-12-24 12:58:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415463712305057793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.4296361192, 6.7764816126 ]
  },
  "id_str" : "415464224392220672",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ich dachte an Weihnachten zu schlemmen ist sozial akzeptiert?!",
  "id" : 415464224392220672,
  "in_reply_to_status_id" : 415463712305057793,
  "created_at" : "2013-12-24 12:49:24 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415462624139030528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.429823538, 6.7763915646 ]
  },
  "id_str" : "415463523549216768",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot gibst du es so spezifisch an damit ich ihm nicht versehentlich das  falsche Nasenloch auslecke?",
  "id" : 415463523549216768,
  "in_reply_to_status_id" : 415462624139030528,
  "created_at" : "2013-12-24 12:46:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.3735541214, 6.7771818598 ]
  },
  "id_str" : "415462555910684672",
  "text" : "\u00ABWhen you can\u2019t state your innocence, proclaim your ignorance: this is often the first line of defense when there is a failed forecast.\u00BB",
  "id" : 415462555910684672,
  "created_at" : "2013-12-24 12:42:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415459810927075330",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 51.2111594466, 6.7909390872 ]
  },
  "id_str" : "415460310603296769",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot das links oder das rechts?",
  "id" : 415460310603296769,
  "in_reply_to_status_id" : 415459810927075330,
  "created_at" : "2013-12-24 12:33:51 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415457827365609472",
  "text" : "Mercy Filling: \u00ABIch kann mir keinen besseren Tod w\u00FCnschen als beim Fisting auszubluten.\u00BB",
  "id" : 415457827365609472,
  "created_at" : "2013-12-24 12:23:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/GwoNVnThA0",
      "expanded_url" : "http:\/\/i.imgur.com\/Y48ZlpJ.jpg",
      "display_url" : "i.imgur.com\/Y48ZlpJ.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.939906, 6.961679 ]
  },
  "id_str" : "415457262267023360",
  "text" : "Have your water supply at beard at all times. http:\/\/t.co\/GwoNVnThA0",
  "id" : 415457262267023360,
  "created_at" : "2013-12-24 12:21:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/twIWhnYdmb",
      "expanded_url" : "http:\/\/i.imgur.com\/Ert5moj.jpg",
      "display_url" : "i.imgur.com\/Ert5moj.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.939781, 6.961814 ]
  },
  "id_str" : "415454651228897280",
  "text" : "please mentor me! http:\/\/t.co\/twIWhnYdmb",
  "id" : 415454651228897280,
  "created_at" : "2013-12-24 12:11:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.9251652922, 6.9392550962 ]
  },
  "id_str" : "415451741111742464",
  "text" : "\u00ABViel Spass. Und trink nicht so viel. Zumindest nicht mehr als deine Kinder.\u00BB",
  "id" : 415451741111742464,
  "created_at" : "2013-12-24 11:59:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/9n4NMUi3q5",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=C0y78C91B3U",
      "display_url" : "youtube.com\/watch?v=C0y78C\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415442492449124352",
  "text" : "\u00ABAnd if happiness won\u2019t come to me, hand me the nitrous gas\u00BB Merry Christmas! http:\/\/t.co\/9n4NMUi3q5",
  "id" : 415442492449124352,
  "created_at" : "2013-12-24 11:23:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.2425869548, 7.5989799552 ]
  },
  "id_str" : "415438349143670784",
  "text" : "\u00ABWhen Darwin\u2019s book hit the crowd, it was like Christmas for the ex-Christians.\u00BB",
  "id" : 415438349143670784,
  "created_at" : "2013-12-24 11:06:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415427915711774720",
  "geo" : { },
  "id_str" : "415428355979505664",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 ich werd auch regelm\u00E4ssig geoutet, was so peinlich ist, Herr @PiratSeb666!",
  "id" : 415428355979505664,
  "in_reply_to_status_id" : 415427915711774720,
  "created_at" : "2013-12-24 10:26:53 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415427964235309057",
  "geo" : { },
  "id_str" : "415428206939086848",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me iirc ist m ein Synonym f\u00FCr d.",
  "id" : 415428206939086848,
  "in_reply_to_status_id" : 415427964235309057,
  "created_at" : "2013-12-24 10:26:17 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 0, 7 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415427274759241729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0014965626, 8.2583435979 ]
  },
  "id_str" : "415427825408438272",
  "in_reply_to_user_id" : 18362640,
  "text" : "@Seb666 nice try, aber wir wissen beide das du wegen der Piraten hier rumlungerst. ;)",
  "id" : 415427825408438272,
  "in_reply_to_status_id" : 415427274759241729,
  "created_at" : "2013-12-24 10:24:46 +0000",
  "in_reply_to_screen_name" : "NieMehrPiraten",
  "in_reply_to_user_id_str" : "18362640",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dierk Haasis",
      "screen_name" : "Evo2Me",
      "indices" : [ 0, 7 ],
      "id_str" : "22910316",
      "id" : 22910316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415427232497033216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0014570733, 8.2584410657 ]
  },
  "id_str" : "415427709263966208",
  "in_reply_to_user_id" : 22910316,
  "text" : "@Evo2Me das m, weil das auch Steuerzeichen am Anfang ist: sent direct message to",
  "id" : 415427709263966208,
  "in_reply_to_status_id" : 415427232497033216,
  "created_at" : "2013-12-24 10:24:18 +0000",
  "in_reply_to_screen_name" : "Evo2Me",
  "in_reply_to_user_id_str" : "22910316",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/BSyP1mZ1gf",
      "expanded_url" : "http:\/\/instagram.com\/p\/iTPdpJhwr9\/",
      "display_url" : "instagram.com\/p\/iTPdpJhwr9\/"
    } ]
  },
  "geo" : { },
  "id_str" : "415425396449214464",
  "text" : "didn't know that people here are THAT desperate. http:\/\/t.co\/BSyP1mZ1gf",
  "id" : 415425396449214464,
  "created_at" : "2013-12-24 10:15:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/PySmnsTOAR",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/polyamory\/comments\/1tah3c\/why_is_sex_at_dawn_so_popular_in_the_poly\/",
      "display_url" : "reddit.com\/r\/polyamory\/co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415288149196406784",
  "text" : "On Sex at Dawn: \u00ABjust because a book tells us what we want to hear doesn\u2019t mean that it\u2019s accurate, or good\u00BB  http:\/\/t.co\/PySmnsTOAR",
  "id" : 415288149196406784,
  "created_at" : "2013-12-24 01:09:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "415280768706170881",
  "text" : "\u00ABIf Ernestine Rose associated doubting women with ringlets, Karl Marx connected doubt and beards.\u00BB",
  "id" : 415280768706170881,
  "created_at" : "2013-12-24 00:40:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 3, 15 ],
      "id_str" : "35773039",
      "id" : 35773039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/6FmPAX6T4k",
      "expanded_url" : "http:\/\/theatln.tc\/1cNMUJp",
      "display_url" : "theatln.tc\/1cNMUJp"
    } ]
  },
  "geo" : { },
  "id_str" : "415266255105708032",
  "text" : "RT @TheAtlantic: The new psychogeography of Tempelhof airport, a one-time Nazi landmark in Berlin http:\/\/t.co\/6FmPAX6T4k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/6FmPAX6T4k",
        "expanded_url" : "http:\/\/theatln.tc\/1cNMUJp",
        "display_url" : "theatln.tc\/1cNMUJp"
      } ]
    },
    "geo" : { },
    "id_str" : "415258215119454208",
    "text" : "The new psychogeography of Tempelhof airport, a one-time Nazi landmark in Berlin http:\/\/t.co\/6FmPAX6T4k",
    "id" : 415258215119454208,
    "created_at" : "2013-12-23 23:10:48 +0000",
    "user" : {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "protected" : false,
      "id_str" : "35773039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/880086372564041728\/rZ4SGWbE_normal.jpg",
      "id" : 35773039,
      "verified" : true
    }
  },
  "id" : 415266255105708032,
  "created_at" : "2013-12-23 23:42:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/415263046626340864\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/hGNfcupPZN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcNPil7CEAEPQMH.jpg",
      "id_str" : "415263046362075137",
      "id" : 415263046362075137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcNPil7CEAEPQMH.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hGNfcupPZN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/taR30tUxQk",
      "expanded_url" : "http:\/\/i.imgur.com\/dcY336C.jpg",
      "display_url" : "i.imgur.com\/dcY336C.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "415263046626340864",
  "text" : "How-To: Do a Jabba the Hutt-Cookie http:\/\/t.co\/taR30tUxQk http:\/\/t.co\/hGNfcupPZN",
  "id" : 415263046626340864,
  "created_at" : "2013-12-23 23:30:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "indices" : [ 3, 16 ],
      "id_str" : "19084034",
      "id" : 19084034
    }, {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 100, 115 ],
      "id_str" : "18655567",
      "id" : 18655567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415243363236188161",
  "text" : "RT @ericmjohnson: Never thought I'd see the Boy Scouts supporting gay marriage in Utah. Awesome! MT @stevesilberman: Go, Scouts! http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Silberman",
        "screen_name" : "stevesilberman",
        "indices" : [ 82, 97 ],
        "id_str" : "18655567",
        "id" : 18655567
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/OTtaatcTsN",
        "expanded_url" : "http:\/\/goo.gl\/3t7oNh",
        "display_url" : "goo.gl\/3t7oNh"
      } ]
    },
    "in_reply_to_status_id_str" : "415234063356555264",
    "geo" : { },
    "id_str" : "415235547742089216",
    "in_reply_to_user_id" : 18655567,
    "text" : "Never thought I'd see the Boy Scouts supporting gay marriage in Utah. Awesome! MT @stevesilberman: Go, Scouts! http:\/\/t.co\/OTtaatcTsN",
    "id" : 415235547742089216,
    "in_reply_to_status_id" : 415234063356555264,
    "created_at" : "2013-12-23 21:40:43 +0000",
    "in_reply_to_screen_name" : "stevesilberman",
    "in_reply_to_user_id_str" : "18655567",
    "user" : {
      "name" : "Eric Michael Johnson",
      "screen_name" : "ericmjohnson",
      "protected" : false,
      "id_str" : "19084034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/434953612825858048\/DckRYRye_normal.png",
      "id" : 19084034,
      "verified" : false
    }
  },
  "id" : 415243363236188161,
  "created_at" : "2013-12-23 22:11:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "indices" : [ 3, 8 ],
      "id_str" : "1147751",
      "id" : 1147751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/PVk1yyCCIt",
      "expanded_url" : "http:\/\/motherboard.vice.com\/blog\/dogecoins-founders-believe-in-the-power-of-meme-currencies",
      "display_url" : "motherboard.vice.com\/blog\/dogecoins\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "415242278152990720",
  "text" : "RT @johl: Here's an interview with the founders of Dogecoin: http:\/\/t.co\/PVk1yyCCIt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/PVk1yyCCIt",
        "expanded_url" : "http:\/\/motherboard.vice.com\/blog\/dogecoins-founders-believe-in-the-power-of-meme-currencies",
        "display_url" : "motherboard.vice.com\/blog\/dogecoins\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "415241978524499968",
    "text" : "Here's an interview with the founders of Dogecoin: http:\/\/t.co\/PVk1yyCCIt",
    "id" : 415241978524499968,
    "created_at" : "2013-12-23 22:06:17 +0000",
    "user" : {
      "name" : "Jens Ohlig",
      "screen_name" : "johl",
      "protected" : false,
      "id_str" : "1147751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/876909912185597952\/E61jm8M3_normal.jpg",
      "id" : 1147751,
      "verified" : false
    }
  },
  "id" : 415242278152990720,
  "created_at" : "2013-12-23 22:07:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/4aXCZrKbem",
      "expanded_url" : "http:\/\/rss.sciam.com\/~r\/all-blogs\/feed\/~3\/2t7hHbxqiRM\/",
      "display_url" : "rss.sciam.com\/~r\/all-blogs\/f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009667, 8.282978 ]
  },
  "id_str" : "415223949283590144",
  "text" : "\u00ABplagiarism is a species of dishonesty that can undermine the knowledge-building project of science\u00BB http:\/\/t.co\/4aXCZrKbem",
  "id" : 415223949283590144,
  "created_at" : "2013-12-23 20:54:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/GBEsG2FwLS",
      "expanded_url" : "http:\/\/arstechnica.com\/gadgets\/2013\/12\/should-you-make-a-tech-product-just-for-women-use-this-flowchart\/",
      "display_url" : "arstechnica.com\/gadgets\/2013\/1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009637, 8.282964 ]
  },
  "id_str" : "415222777692839937",
  "text" : "Flowchart: How not to design a \"woman\u2019s\" tech product http:\/\/t.co\/GBEsG2FwLS",
  "id" : 415222777692839937,
  "created_at" : "2013-12-23 20:49:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415216041942609921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0158078702, 8.2739764211 ]
  },
  "id_str" : "415216637772824576",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich riesige Kekse in Ausstellung?",
  "id" : 415216637772824576,
  "in_reply_to_status_id" : 415216041942609921,
  "created_at" : "2013-12-23 20:25:35 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/415212167575531520\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/zu97PQl6kE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcMhRDBCYAAg-aK.jpg",
      "id_str" : "415212167399366656",
      "id" : 415212167399366656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcMhRDBCYAAg-aK.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/zu97PQl6kE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/wPVSOrbPSp",
      "expanded_url" : "http:\/\/i.imgur.com\/R38e62c.jpg",
      "display_url" : "i.imgur.com\/R38e62c.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009625, 8.282948 ]
  },
  "id_str" : "415212167575531520",
  "text" : "Inter-class erotica http:\/\/t.co\/wPVSOrbPSp http:\/\/t.co\/zu97PQl6kE",
  "id" : 415212167575531520,
  "created_at" : "2013-12-23 20:07:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415207390448205824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096855096, 8.2830221091 ]
  },
  "id_str" : "415207893664026624",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich das erkl\u00E4rt wieso du im Senckenberg alles abgeleckt hast. ;)",
  "id" : 415207893664026624,
  "in_reply_to_status_id" : 415207390448205824,
  "created_at" : "2013-12-23 19:50:50 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096176104, 8.282987871 ]
  },
  "id_str" : "415205741717635072",
  "text" : "\u00ABDein Cousin hat dich angerufen um zu fragen wieso sein _was_ so niedlich ist?!\u00BB \u2014 \u00ABNiedrig! Sein R squared!\u00BB",
  "id" : 415205741717635072,
  "created_at" : "2013-12-23 19:42:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415204182384054274",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096176104, 8.282987871 ]
  },
  "id_str" : "415204567295729665",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot da sie frisch aus dem Ofen sind d\u00FCrfte Geschmacksrichtung \u2018Molten Lava\u2019 noch gut hinkommen.",
  "id" : 415204567295729665,
  "in_reply_to_status_id" : 415204182384054274,
  "created_at" : "2013-12-23 19:37:37 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096701995, 8.2830167514 ]
  },
  "id_str" : "415203781295759361",
  "text" : "Mh\u2026 diesmal sehen die Dinosaurier-Kekse so aus als h\u00E4tten sie den Direct Hit eines Asteroiden abbekommen.",
  "id" : 415203781295759361,
  "created_at" : "2013-12-23 19:34:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 62, 71 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096095359, 8.2829489702 ]
  },
  "id_str" : "415190129482170368",
  "text" : "Immer wenn ich Gegenst\u00E4nde in unserer Wohnung suche frage ich @Senficon um sie dann just in der Sekunde zu finden &amp; dumm auszusehen.",
  "id" : 415190129482170368,
  "created_at" : "2013-12-23 18:40:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/Dl4yAaHPpv",
      "expanded_url" : "http:\/\/www.narrative.ly\/man-vs-beast\/where-the-bull-never-dies\/",
      "display_url" : "narrative.ly\/man-vs-beast\/w\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009635, 8.283003 ]
  },
  "id_str" : "415184441133531136",
  "text" : "Where the Bull Never Dies  http:\/\/t.co\/Dl4yAaHPpv",
  "id" : 415184441133531136,
  "created_at" : "2013-12-23 18:17:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/eCoCdh5xgZ",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/t7bk4TeX5w8\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009644, 8.282964 ]
  },
  "id_str" : "415179710789070849",
  "text" : "Mikhail Kalashnikov,\u00A01919-2013 http:\/\/t.co\/eCoCdh5xgZ",
  "id" : 415179710789070849,
  "created_at" : "2013-12-23 17:58:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097287734, 8.454430085 ]
  },
  "id_str" : "415133667774980096",
  "text" : "\u00ABKopf hoch! Du weisst doch: Gib jedem Tag die Chance, der letzte deines Lebens zu sein!\u00BB",
  "id" : 415133667774980096,
  "created_at" : "2013-12-23 14:55:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0151241546, 8.4365018566 ]
  },
  "id_str" : "415104031326236672",
  "text" : "\u00AB[Bruno\u2019s] scientific theses were so outrageous that he began his \u2018On the Infinite Universe\u2019 with a preface that insisted he was not joking\u00BB",
  "id" : 415104031326236672,
  "created_at" : "2013-12-23 12:58:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415100834775834625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0064161327, 8.325919183 ]
  },
  "id_str" : "415100973414371328",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai Berufskrankheit? ;)",
  "id" : 415100973414371328,
  "in_reply_to_status_id" : 415100834775834625,
  "created_at" : "2013-12-23 12:45:58 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "415097668114063360",
  "text" : "Assembly 1 of 3 is finished \\o\/",
  "id" : 415097668114063360,
  "created_at" : "2013-12-23 12:32:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/nrDBk4abaf",
      "expanded_url" : "http:\/\/clanbase.org\/",
      "display_url" : "clanbase.org"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "415096368387330048",
  "text" : "sad to hear that this usability nightmare is over: \u00ABClanBase is no more, we are sorry.\u00BB http:\/\/t.co\/nrDBk4abaf",
  "id" : 415096368387330048,
  "created_at" : "2013-12-23 12:27:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/gT3NqhiUuY",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3214",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "415094903178539008",
  "text" : "i am become death http:\/\/t.co\/gT3NqhiUuY",
  "id" : 415094903178539008,
  "created_at" : "2013-12-23 12:21:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/GQOkrB8tG2",
      "expanded_url" : "http:\/\/onlinelibrary.wiley.com\/doi\/10.1111\/ele.12043\/abstract",
      "display_url" : "onlinelibrary.wiley.com\/doi\/10.1111\/el\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "415093852476014592",
  "text" : "Looks like a nice take on the competitive exclusion principle using a phylogenetic framework http:\/\/t.co\/GQOkrB8tG2",
  "id" : 415093852476014592,
  "created_at" : "2013-12-23 12:17:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/trlS8JPO7N",
      "expanded_url" : "http:\/\/biology.duke.edu\/johnsenlab\/advice.html",
      "display_url" : "biology.duke.edu\/johnsenlab\/adv\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096875167, 8.2830149167 ]
  },
  "id_str" : "415091358324760576",
  "text" : "Advice for potential graduate students: \u00ABAdvisors teach very little, but instead provide a role model\u00BB http:\/\/t.co\/trlS8JPO7N",
  "id" : 415091358324760576,
  "created_at" : "2013-12-23 12:07:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S\u00F6ren Schewe",
      "screen_name" : "Roterhai",
      "indices" : [ 0, 9 ],
      "id_str" : "25101713",
      "id" : 25101713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "415080112716271616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0232595671, 8.288924396 ]
  },
  "id_str" : "415084498641227776",
  "in_reply_to_user_id" : 25101713,
  "text" : "@Roterhai die heute einen Weihnachtsbaum kaufen? ;)",
  "id" : 415084498641227776,
  "in_reply_to_status_id" : 415080112716271616,
  "created_at" : "2013-12-23 11:40:31 +0000",
  "in_reply_to_screen_name" : "Roterhai",
  "in_reply_to_user_id_str" : "25101713",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/aAWA9dQXSv",
      "expanded_url" : "http:\/\/instagram.com\/p\/iQxoxWBwmz\/",
      "display_url" : "instagram.com\/p\/iQxoxWBwmz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "415078333597364224",
  "text" : "Shocked http:\/\/t.co\/aAWA9dQXSv",
  "id" : 415078333597364224,
  "created_at" : "2013-12-23 11:16:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0932768547, 8.2571227709 ]
  },
  "id_str" : "415072942993965056",
  "text" : "\u00ABWegen eurem schei\u00DF Baum k\u00F6nnen wir hier nicht ordentlich fahren. I hope you die!\u00BB \u2014 \u00ABAh, der Weihnachtsgedanke!\u00BB",
  "id" : 415072942993965056,
  "created_at" : "2013-12-23 10:54:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003545123, 8.2650220818 ]
  },
  "id_str" : "414901338783621120",
  "text" : "\u00ABOh, du hast Wicked Game aufgelegt. Das internationale Zeichen f\u00FCr \u2018lass uns ins Bett gehen\u2019.\u00BB\u2014\u00ABAber die harte Version!\u00BB",
  "id" : 414901338783621120,
  "created_at" : "2013-12-22 23:32:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1003556675, 8.265089783 ]
  },
  "id_str" : "414875752279318528",
  "text" : "\u00ABMach das professionell!\u00BB\u2014\u00ABK\u00FCndigung: \u2018Liebe Kollegen, ich habe den Absprung aus der Wissenschaft noch bekommen, ich F\u00E4rbe nun Haare\u2019.\u00BB",
  "id" : 414875752279318528,
  "created_at" : "2013-12-22 21:51:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/mtLvdYHA7l",
      "expanded_url" : "http:\/\/i.imgur.com\/ICGi3D6.jpg",
      "display_url" : "i.imgur.com\/ICGi3D6.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.037634, 8.454509 ]
  },
  "id_str" : "414788765417496576",
  "text" : "it's a long way to go. well I'll carry you, if you'll carry me http:\/\/t.co\/mtLvdYHA7l",
  "id" : 414788765417496576,
  "created_at" : "2013-12-22 16:05:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/cuEwWOm8rg",
      "expanded_url" : "http:\/\/instagram.com\/p\/iOi1J5hwp-\/",
      "display_url" : "instagram.com\/p\/iOi1J5hwp-\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1093257737, 8.6734308805 ]
  },
  "id_str" : "414764298570051584",
  "text" : "Misheard: \u00ABWir haben uns mit Menschen aus ganz Europa verletzt!\u00BB @ European Central Bank - Eurotower http:\/\/t.co\/cuEwWOm8rg",
  "id" : 414764298570051584,
  "created_at" : "2013-12-22 14:28:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1126925279, 8.6766531504 ]
  },
  "id_str" : "414763600948248576",
  "text" : "\u00ABIst das hier die Soli-Demo f\u00FCr die Rote Flora?\u00BB \u2014 \u00AB\u00C4h, die Gras-Sorte sagt mir gar nichts.\u00BB",
  "id" : 414763600948248576,
  "created_at" : "2013-12-22 14:25:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1089681793, 8.6728810736 ]
  },
  "id_str" : "414746342876270592",
  "text" : "\u00ABWir lieben Europa.\u00BB \u2014 \u00BBUnd die Schw\u00E4nze!\u00BB Weshalb man mich niemals als Stand-In f\u00FCr Testdrehs nutzen sollte.",
  "id" : 414746342876270592,
  "created_at" : "2013-12-22 13:16:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1091724838, 8.6740387036 ]
  },
  "id_str" : "414735550613323776",
  "text" : "\u00ABUm 15 Uhr soll hier auch eine Demo zur Cannabis-Legalisierung stattfinden.\u00BB\u2014\u00ABDie Teilnehmer um uns herum reden auch schon nur \u00FCber Essen.\u00BB",
  "id" : 414735550613323776,
  "created_at" : "2013-12-22 12:33:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/VjbLppHC0F",
      "expanded_url" : "http:\/\/feeds.boingboing.net\/~r\/boingboing\/iBag\/~3\/IuU5LrxLomI\/story01.htm",
      "display_url" : "feeds.boingboing.net\/~r\/boingboing\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.004498, 8.350444 ]
  },
  "id_str" : "414716668133527552",
  "text" : "Woman dies ... and her daughter is born four months\u00A0later http:\/\/t.co\/VjbLppHC0F",
  "id" : 414716668133527552,
  "created_at" : "2013-12-22 11:18:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0072998758, 8.2831324782 ]
  },
  "id_str" : "414715282482286592",
  "text" : "\u00ABKann ich dir Vertrauen nicht mit ihr ins Bett zu gehen?\u00BB\u2014\u00ABNein.\u00BB\u2014\u00ABOk, viel Spass!\u00BB",
  "id" : 414715282482286592,
  "created_at" : "2013-12-22 11:13:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barry burton",
      "screen_name" : "barrycburton",
      "indices" : [ 0, 13 ],
      "id_str" : "26374915",
      "id" : 26374915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414573692073435136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009666716, 8.2829720467 ]
  },
  "id_str" : "414575592009650176",
  "in_reply_to_user_id" : 26374915,
  "text" : "@barrycburton grats and good job! :)",
  "id" : 414575592009650176,
  "in_reply_to_status_id" : 414573692073435136,
  "created_at" : "2013-12-22 01:58:18 +0000",
  "in_reply_to_screen_name" : "barrycburton",
  "in_reply_to_user_id_str" : "26374915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096403994, 8.283066703 ]
  },
  "id_str" : "414569245855739904",
  "text" : "\u00ABAber ein Kind ist f\u00FCr min. die ersten 3 Jahre nur Qu\u00E4lerei!\u00BB\u2014\u00ABDaf\u00FCr habe ich mich schon mal entschieden, so lang l\u00E4uft mein Arbeitsvertrag\u00BB",
  "id" : 414569245855739904,
  "created_at" : "2013-12-22 01:33:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/0W7WiKkGUF",
      "expanded_url" : "http:\/\/media.lolwall.co\/c\/2013\/04\/there-s-the-door_264777-600x.jpeg",
      "display_url" : "media.lolwall.co\/c\/2013\/04\/ther\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965572, 8.28307764 ]
  },
  "id_str" : "414538538366275584",
  "text" : "there\u2019s the door! http:\/\/t.co\/0W7WiKkGUF",
  "id" : 414538538366275584,
  "created_at" : "2013-12-21 23:31:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/uFy3Y6RgBc",
      "expanded_url" : "http:\/\/dearviny.blogspot.de\/2013\/12\/complex-relationships-iso-easy-terms.html",
      "display_url" : "dearviny.blogspot.de\/2013\/12\/comple\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009653696, 8.28296378 ]
  },
  "id_str" : "414498837500559360",
  "text" : "On Terminology: \u00ABYeah, I'm taking the whole postmodern harem out to dinner\u00BB http:\/\/t.co\/uFy3Y6RgBc",
  "id" : 414498837500559360,
  "created_at" : "2013-12-21 20:53:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009653696, 8.28296378 ]
  },
  "id_str" : "414495296891400192",
  "text" : "\u00ABIch mag nicht so gerne auf Twitter sagen das ich auf Reddit bin\u2026\u00BB",
  "id" : 414495296891400192,
  "created_at" : "2013-12-21 20:39:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YM3AhG36of",
      "expanded_url" : "http:\/\/www.newstatesman.com\/2013\/12\/why-russell-brand-banned-gitmo",
      "display_url" : "newstatesman.com\/2013\/12\/why-ru\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009653696, 8.28296378 ]
  },
  "id_str" : "414488362792550400",
  "text" : "\u00ABThey\u2019ve banned the rule of law in Guantanamo, it wouldn\u2019t make sense to permit a book on such a contraband concept\u00BB http:\/\/t.co\/YM3AhG36of",
  "id" : 414488362792550400,
  "created_at" : "2013-12-21 20:11:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532867, 8.2829558033 ]
  },
  "id_str" : "414487043428089856",
  "text" : "Weihnachten. Die Zeit in der man dank im CC gesendeter Gru\u00DFkarten bequem soziale Netzwerke erstellen\/aktualisieren kann.",
  "id" : 414487043428089856,
  "created_at" : "2013-12-21 20:06:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Mason",
      "screen_name" : "SteveMasonKBT",
      "indices" : [ 3, 17 ],
      "id_str" : "24688425",
      "id" : 24688425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/IFiYlp0g41",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1lHy-ASLWQM",
      "display_url" : "youtube.com\/watch?v=1lHy-A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414480039905095680",
  "text" : "RT @SteveMasonKBT: If anyone wants to hear the Powerchord being invented, here it is - http:\/\/t.co\/IFiYlp0g41",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/IFiYlp0g41",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1lHy-ASLWQM",
        "display_url" : "youtube.com\/watch?v=1lHy-A\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "414463332448337920",
    "text" : "If anyone wants to hear the Powerchord being invented, here it is - http:\/\/t.co\/IFiYlp0g41",
    "id" : 414463332448337920,
    "created_at" : "2013-12-21 18:32:13 +0000",
    "user" : {
      "name" : "Steve Mason",
      "screen_name" : "SteveMasonKBT",
      "protected" : false,
      "id_str" : "24688425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685084643096301568\/KMTg_X4o_normal.jpg",
      "id" : 24688425,
      "verified" : true
    }
  },
  "id" : 414480039905095680,
  "created_at" : "2013-12-21 19:38:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "414464901285830656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532867, 8.2829558033 ]
  },
  "id_str" : "414465945470795776",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon I should dress up as super hero and correct them using my \u2018Fallacy Man\u2019 alter ego: \u2018Stop! Don\u2019t do false dichotomies!\u2019",
  "id" : 414465945470795776,
  "in_reply_to_status_id" : 414464901285830656,
  "created_at" : "2013-12-21 18:42:36 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096461366, 8.2831416733 ]
  },
  "id_str" : "414464313186062336",
  "text" : "Wenn ich das richtig verstanden habe dann schreit sich das Nachbarspaar gerade an ob Windows 7 oder B\u00F6hse Onkelz schlimmer sind.",
  "id" : 414464313186062336,
  "created_at" : "2013-12-21 18:36:07 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/K44jFfHyQc",
      "expanded_url" : "http:\/\/instagram.com\/p\/iMBpjgBwgI\/",
      "display_url" : "instagram.com\/p\/iMBpjgBwgI\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0140282104, 8.2576776303 ]
  },
  "id_str" : "414409857090211840",
  "text" : "Zen for Beginners @ Zollhafen S\u00FCdmole http:\/\/t.co\/K44jFfHyQc",
  "id" : 414409857090211840,
  "created_at" : "2013-12-21 14:59:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9998431623, 8.2761081109 ]
  },
  "id_str" : "414408303570345984",
  "text" : "\u00ABWar ich eigentlich eine gute Mutter? Oh, wieso schaust du so seltsam?\u00BB \u2014 \u00ABIch versuche nicht in hysterisches Gel\u00E4chter auszubrechen.\u00BB",
  "id" : 414408303570345984,
  "created_at" : "2013-12-21 14:53:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096882273, 8.2832032786 ]
  },
  "id_str" : "414348246988095488",
  "text" : "Meine handwerklichen Skills: 10 min auseinandernehmen, 5 sec um zu merken das die geplante L\u00F6sung nicht funktioniert, 50 min zusammenbauen\u2026",
  "id" : 414348246988095488,
  "created_at" : "2013-12-21 10:54:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096154906, 8.2829020349 ]
  },
  "id_str" : "414333658137628672",
  "text" : "\u00ABGut dich zu treffen. Ich wollte dich herzlich zu meiner Verteidigung einladen. Unter der Bedingung das du keine gemeinen Fragen stellst.\u00BB",
  "id" : 414333658137628672,
  "created_at" : "2013-12-21 09:56:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/AZnvKikhlm",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=OO4ssAB7IYs",
      "display_url" : "youtube.com\/watch?v=OO4ssA\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532867, 8.2829558033 ]
  },
  "id_str" : "414221818359447552",
  "text" : "\u00ABHe won\u2019t let her be, she won\u2019t let him rest, till he learns how to forgive\u00BB http:\/\/t.co\/AZnvKikhlm",
  "id" : 414221818359447552,
  "created_at" : "2013-12-21 02:32:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Koerth-Baker",
      "screen_name" : "maggiekb1",
      "indices" : [ 3, 13 ],
      "id_str" : "26858764",
      "id" : 26858764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414219372048441344",
  "text" : "RT @maggiekb1: The majority of Americans are not offended by use of \"Happy Holidays\" and DO NOT want a hippopotamus for Christmas http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/xXkFwv1rN9",
        "expanded_url" : "http:\/\/www.publicpolicypolling.com\/pdf\/2013\/PPP_Release_National_1219.pdf",
        "display_url" : "publicpolicypolling.com\/pdf\/2013\/PPP_R\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "414206672433737728",
    "text" : "The majority of Americans are not offended by use of \"Happy Holidays\" and DO NOT want a hippopotamus for Christmas http:\/\/t.co\/xXkFwv1rN9",
    "id" : 414206672433737728,
    "created_at" : "2013-12-21 01:32:20 +0000",
    "user" : {
      "name" : "Maggie Koerth-Baker",
      "screen_name" : "maggiekb1",
      "protected" : false,
      "id_str" : "26858764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1460109151\/Twitterphoto_normal.jpg",
      "id" : 26858764,
      "verified" : true
    }
  },
  "id" : 414219372048441344,
  "created_at" : "2013-12-21 02:22:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/eyJGncB3SR",
      "expanded_url" : "http:\/\/i.imgur.com\/c2g15Bm.jpg",
      "display_url" : "i.imgur.com\/c2g15Bm.jpg"
    } ]
  },
  "in_reply_to_status_id_str" : "414208336427380736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532867, 8.2829558033 ]
  },
  "id_str" : "414209946348453888",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon wait until they are old enough! http:\/\/t.co\/eyJGncB3SR",
  "id" : 414209946348453888,
  "in_reply_to_status_id" : 414208336427380736,
  "created_at" : "2013-12-21 01:45:21 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/ZZaf82ZeUZ",
      "expanded_url" : "http:\/\/i.imgur.com\/UkbbiBl.jpg",
      "display_url" : "i.imgur.com\/UkbbiBl.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532867, 8.2829558033 ]
  },
  "id_str" : "414206662476836864",
  "text" : "how-to: look innocent http:\/\/t.co\/ZZaf82ZeUZ",
  "id" : 414206662476836864,
  "created_at" : "2013-12-21 01:32:18 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/hVJIwwT5Sd",
      "expanded_url" : "http:\/\/scienceiscomingtotown.files.wordpress.com\/2012\/06\/dsc02786.png?w=1000&h=",
      "display_url" : "\u2026nceiscomingtotown.files.wordpress.com\/2012\/06\/dsc027\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096644825, 8.282991235 ]
  },
  "id_str" : "414166963733401601",
  "text" : "Damn, and one student even told me he was disappointed that we didn\u2019t have a phylogenetic christmas tree! http:\/\/t.co\/hVJIwwT5Sd",
  "id" : 414166963733401601,
  "created_at" : "2013-12-20 22:54:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5LsQge6ErL",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0084258",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "414154461947625472",
  "text" : "TIL: The development of penile spines and sensory vibrissae is controlled by the same enhancer. http:\/\/t.co\/5LsQge6ErL",
  "id" : 414154461947625472,
  "created_at" : "2013-12-20 22:04:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\/r\/DataIsBeautiful",
      "screen_name" : "DataIsBeautiful",
      "indices" : [ 3, 19 ],
      "id_str" : "1201186872",
      "id" : 1201186872
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dataviz",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/oRfizuTbz9",
      "expanded_url" : "http:\/\/goo.gl\/p2Ddk2",
      "display_url" : "goo.gl\/p2Ddk2"
    } ]
  },
  "geo" : { },
  "id_str" : "414132808383496193",
  "text" : "RT @DataIsBeautiful: French wealth map (200m\u00B2 accuracy, filterable) http:\/\/t.co\/oRfizuTbz9 #dataviz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.reddit.com\/r\/dataisbeautiful\" rel=\"nofollow\"\u003E\/r\/dataisbeautiful tweeter bot\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dataviz",
        "indices" : [ 70, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/oRfizuTbz9",
        "expanded_url" : "http:\/\/goo.gl\/p2Ddk2",
        "display_url" : "goo.gl\/p2Ddk2"
      } ]
    },
    "geo" : { },
    "id_str" : "414131111074480128",
    "text" : "French wealth map (200m\u00B2 accuracy, filterable) http:\/\/t.co\/oRfizuTbz9 #dataviz",
    "id" : 414131111074480128,
    "created_at" : "2013-12-20 20:32:05 +0000",
    "user" : {
      "name" : "\/r\/DataIsBeautiful",
      "screen_name" : "DataIsBeautiful",
      "protected" : false,
      "id_str" : "1201186872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572447924701786112\/FOnkOPJP_normal.png",
      "id" : 1201186872,
      "verified" : false
    }
  },
  "id" : 414132808383496193,
  "created_at" : "2013-12-20 20:38:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 3, 12 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096552149, 8.2830597229 ]
  },
  "id_str" : "414119009576308736",
  "text" : "OH @Senficon: \u00ABIch bin eine harte Verhandlungspartnerin!\u00BB \u2014 \u00ABNein\u2026\u00BB \u2014 \u00ABDoch!\u00BB \u2014 \u00ABOhh\u2026\u00BB",
  "id" : 414119009576308736,
  "created_at" : "2013-12-20 19:44:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0049161821, 8.2896858765 ]
  },
  "id_str" : "414111298117722112",
  "text" : "\u00ABIch h\u00F6re, du hattest also Spass heute Nachmittag. Hast du dir den Bart schon gewaschen?\u00BB",
  "id" : 414111298117722112,
  "created_at" : "2013-12-20 19:13:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1148031964, 8.6826545474 ]
  },
  "id_str" : "414088782594736128",
  "text" : "\u00ABDu schaust so getroffen. War ich zu gemein?\u00BB \u2014 \u00ABIch versuche eigentlich mal wieder verliebt zu schauen.\u00BB",
  "id" : 414088782594736128,
  "created_at" : "2013-12-20 17:43:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/SNGY4R34O2",
      "expanded_url" : "http:\/\/www.talyarkoni.org\/blog\/2013\/12\/19\/whether-or-not-you-should-pursue-a-career-in-science-still-depends-mostly-on-that-thing-that-is-you\/",
      "display_url" : "talyarkoni.org\/blog\/2013\/12\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413945514594279424",
  "text" : "\u00ABwhether or not you should pursue a career in science still depends mostly on that thing that is you\u00BB http:\/\/t.co\/SNGY4R34O2",
  "id" : 413945514594279424,
  "created_at" : "2013-12-20 08:14:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413941982462234624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1719769353, 8.6275561861 ]
  },
  "id_str" : "413942107712524288",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s das war genau meine Antwort :)",
  "id" : 413942107712524288,
  "in_reply_to_status_id" : 413941982462234624,
  "created_at" : "2013-12-20 08:01:03 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723537208, 8.6274600752 ]
  },
  "id_str" : "413941738634752000",
  "text" : "\u00ABIch will ja nicht unsensibel klingen, aber: Wie f\u00FChlt es sich an 6 Monate Arbeit wegwerfen zu m\u00FCssen?\u00BB",
  "id" : 413941738634752000,
  "created_at" : "2013-12-20 07:59:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/4muodXdHgW",
      "expanded_url" : "https:\/\/i.chzbgr.com\/maxW500\/5297090048\/h8B908B38\/",
      "display_url" : "i.chzbgr.com\/maxW500\/529709\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413936714755735553",
  "text" : "Letzte Nacht: https:\/\/t.co\/4muodXdHgW",
  "id" : 413936714755735553,
  "created_at" : "2013-12-20 07:39:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413883701374627840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723022108, 8.6275199242 ]
  },
  "id_str" : "413930010563866624",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer cheers! Looks interesting, though the abstract\u2019s first sentence puzzled me. Mirrors? More like \u2018is one example of\u2019 I\u2019d say ;)",
  "id" : 413930010563866624,
  "in_reply_to_status_id" : 413883701374627840,
  "created_at" : "2013-12-20 07:12:59 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bioinfo",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413844798370746368",
  "text" : "RT @PhilippBayer: Cool: \"Reconstructing mitochondrial genomes directly from genomic next-generation sequencing reads\" #bioinfo http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bioinfo",
        "indices" : [ 100, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/ITwKtjS0nB",
        "expanded_url" : "http:\/\/nar.oxfordjournals.org\/content\/early\/2013\/05\/09\/nar.gkt371.full.pdf+html",
        "display_url" : "nar.oxfordjournals.org\/content\/early\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413843512669380608",
    "text" : "Cool: \"Reconstructing mitochondrial genomes directly from genomic next-generation sequencing reads\" #bioinfo http:\/\/t.co\/ITwKtjS0nB",
    "id" : 413843512669380608,
    "created_at" : "2013-12-20 01:29:16 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 413844798370746368,
  "created_at" : "2013-12-20 01:34:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/VL5xKznxas",
      "expanded_url" : "http:\/\/instagram.com\/p\/iH_Xn6BwsL\/",
      "display_url" : "instagram.com\/p\/iH_Xn6BwsL\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723745458, 8.6276945674 ]
  },
  "id_str" : "413841892913479681",
  "text" : "computer says no @ Biologicum http:\/\/t.co\/VL5xKznxas",
  "id" : 413841892913479681,
  "created_at" : "2013-12-20 01:22:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413830658029395968",
  "text" : "\u00ABWir k\u00F6nnten einen AG-Kalender rausbringen: Sexy Hidden Markov Models.\u00BB \u2013 \u00ABIch mach wohl Mr. August.\u00BB",
  "id" : 413830658029395968,
  "created_at" : "2013-12-20 00:38:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/7VSU15E5oU",
      "expanded_url" : "http:\/\/media2.giphy.com\/media\/MS0fQBmGGMaRy\/giphy.gif",
      "display_url" : "media2.giphy.com\/media\/MS0fQBmG\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413829926047854592",
  "text" : "Raiders of the Lost Adaptor Sequences http:\/\/t.co\/7VSU15E5oU",
  "id" : 413829926047854592,
  "created_at" : "2013-12-20 00:35:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.2134312251, 8.5408902353 ]
  },
  "id_str" : "413753296948838400",
  "text" : "\u00ABWenn alle Vokale zum \u00D6 werden dann hab ich einen im Tee.\u00BB",
  "id" : 413753296948838400,
  "created_at" : "2013-12-19 19:30:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/3rW1egHm4A",
      "expanded_url" : "http:\/\/stream1.gifsoup.com\/view3\/1377906\/staring-llama-o.gif",
      "display_url" : "stream1.gifsoup.com\/view3\/1377906\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "413697006826049537",
  "geo" : { },
  "id_str" : "413699119857680384",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot more like http:\/\/t.co\/3rW1egHm4A",
  "id" : 413699119857680384,
  "in_reply_to_status_id" : 413697006826049537,
  "created_at" : "2013-12-19 15:55:30 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413695600941490178",
  "geo" : { },
  "id_str" : "413696252509843456",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot color me surprised!",
  "id" : 413696252509843456,
  "in_reply_to_status_id" : 413695600941490178,
  "created_at" : "2013-12-19 15:44:07 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/yTsnivIrzx",
      "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/12\/an-ode-to-winamp\/282496\/",
      "display_url" : "theatlantic.com\/technology\/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413694696947343360",
  "text" : "\u00ABWinamp was a key part of what it was like to come of age right at the end of the millennium\u00BB http:\/\/t.co\/yTsnivIrzx",
  "id" : 413694696947343360,
  "created_at" : "2013-12-19 15:37:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413692808524873728",
  "text" : "\u00ABWir haben sogar eine Regenwalddusche im Wohnzimmer. Oder auch 'regelm\u00E4ssiger Wasserschaden im ersten Stock' genannt.\u00BB",
  "id" : 413692808524873728,
  "created_at" : "2013-12-19 15:30:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Xl4GL10MZj",
      "expanded_url" : "http:\/\/instagram.com\/p\/iG2D0BBwsO\/",
      "display_url" : "instagram.com\/p\/iG2D0BBwsO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "413680683761291264",
  "text" : "awarded for offering bug-hunting skills http:\/\/t.co\/Xl4GL10MZj",
  "id" : 413680683761291264,
  "created_at" : "2013-12-19 14:42:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722885417, 8.6276386795 ]
  },
  "id_str" : "413673409219141632",
  "text" : "\u00ABYou should write a book about it: \u2018From bit flipping to table flipping in 10 easy steps\u2019!\u00BB",
  "id" : 413673409219141632,
  "created_at" : "2013-12-19 14:13:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/RbqbJ17dY0",
      "expanded_url" : "http:\/\/i.imgur.com\/WuI5qKo.gif",
      "display_url" : "i.imgur.com\/WuI5qKo.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "413659587695214592",
  "text" : "nice try http:\/\/t.co\/RbqbJ17dY0",
  "id" : 413659587695214592,
  "created_at" : "2013-12-19 13:18:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413600479747129344",
  "text" : "i looked to deep into the void (space) and now all i see are broken reads\u2026",
  "id" : 413600479747129344,
  "created_at" : "2013-12-19 09:23:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/qfQEXcOfiI",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2545",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413598451394297856",
  "text" : "\u00ABthis winter, everyone will get exactly what they wanted for christmas...  and more.\u00BB http:\/\/t.co\/qfQEXcOfiI",
  "id" : 413598451394297856,
  "created_at" : "2013-12-19 09:15:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cAMP \u00D6ther",
      "screen_name" : "CampOther",
      "indices" : [ 0, 10 ],
      "id_str" : "258870463",
      "id" : 258870463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NjrJ71Hnwc",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Platypus#Electrolocation",
      "display_url" : "en.wikipedia.org\/wiki\/Platypus#\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "413472667413409792",
  "geo" : { },
  "id_str" : "413594138165014528",
  "in_reply_to_user_id" : 258870463,
  "text" : "@CampOther they are pretty good hunters, having a kind of doppler radar based on electro- and mechanoreceptors. See http:\/\/t.co\/NjrJ71Hnwc",
  "id" : 413594138165014528,
  "in_reply_to_status_id" : 413472667413409792,
  "created_at" : "2013-12-19 08:58:21 +0000",
  "in_reply_to_screen_name" : "CampOther",
  "in_reply_to_user_id_str" : "258870463",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Jy7eGwnbTo",
      "expanded_url" : "http:\/\/www.nzz.ch\/wissenschaft\/uebersicht\/gene-frei-zum-download-1.18206475",
      "display_url" : "nzz.ch\/wissenschaft\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413589874122309632",
  "text" : "In der NZZ: \u00ABDatenbanken im Internet: Gene frei zum Download\u00BB. Neben dem PGP kommen wir mit openSNP auch zu Wort. http:\/\/t.co\/Jy7eGwnbTo",
  "id" : 413589874122309632,
  "created_at" : "2013-12-19 08:41:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413571411463000064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0393296066, 8.4567157592 ]
  },
  "id_str" : "413572045981888512",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer no problem, if the last revisions are any indicator it should be another 3 months before we hear anything back ;)",
  "id" : 413572045981888512,
  "in_reply_to_status_id" : 413571411463000064,
  "created_at" : "2013-12-19 07:30:34 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413571009984212992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0393296066, 8.4567157592 ]
  },
  "id_str" : "413571236367962112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer certainly not 2013, but I still haven\u2019t given up on 2014 :p",
  "id" : 413571236367962112,
  "in_reply_to_status_id" : 413571009984212992,
  "created_at" : "2013-12-19 07:27:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413569374952251392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0036480459, 8.4040287912 ]
  },
  "id_str" : "413569931578724352",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer will do a follow up on that.",
  "id" : 413569931578724352,
  "in_reply_to_status_id" : 413569374952251392,
  "created_at" : "2013-12-19 07:22:10 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413569374952251392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9961991866, 8.3799438911 ]
  },
  "id_str" : "413569868630589440",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer thanks for reminder, for the openSNP-submission I asked them for how to highlight the \u2018contrib. equally\u2019 but didn\u2019t hear back!",
  "id" : 413569868630589440,
  "in_reply_to_status_id" : 413569374952251392,
  "created_at" : "2013-12-19 07:21:55 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413558526074580992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070494072, 8.2830380409 ]
  },
  "id_str" : "413567376903663616",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer grats!",
  "id" : 413567376903663616,
  "in_reply_to_status_id" : 413558526074580992,
  "created_at" : "2013-12-19 07:12:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/KNmHyWSuXg",
      "expanded_url" : "http:\/\/i.imgur.com\/B2o2ekH.gif",
      "display_url" : "i.imgur.com\/B2o2ekH.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "413442981413535744",
  "text" : "re: summary on progress http:\/\/t.co\/KNmHyWSuXg",
  "id" : 413442981413535744,
  "created_at" : "2013-12-18 22:57:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "413422331059781632",
  "text" : "\u00ABWas?! Als du ein Kind warst gab es gar kein Pok\u00E9mon? Womit habt ihr dann fr\u00FCher gespielt?!\u00BB \u2013 \u00ABMit St\u00F6cken &amp; Steinen. Oh, und Doom!\u00BB",
  "id" : 413422331059781632,
  "created_at" : "2013-12-18 21:35:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tobler Lab",
      "screen_name" : "michitobler",
      "indices" : [ 3, 15 ],
      "id_str" : "47138807",
      "id" : 47138807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swordtails",
      "indices" : [ 32, 43 ]
    }, {
      "text" : "Xiphophorus",
      "indices" : [ 111, 123 ]
    }, {
      "text" : "fishchum",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413419997017686016",
  "text" : "RT @michitobler: Sulfide spring #swordtails, which makes it over 12 lineages of poeciliids in sulfide springs. #Xiphophorus #fishchum http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/michitobler\/status\/413419885889208320\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/mgxlhgd9Bs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbzDMiHCQAAACbW.jpg",
        "id_str" : "413419885893402624",
        "id" : 413419885893402624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbzDMiHCQAAACbW.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 619
        } ],
        "display_url" : "pic.twitter.com\/mgxlhgd9Bs"
      } ],
      "hashtags" : [ {
        "text" : "swordtails",
        "indices" : [ 15, 26 ]
      }, {
        "text" : "Xiphophorus",
        "indices" : [ 94, 106 ]
      }, {
        "text" : "fishchum",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413419885889208320",
    "text" : "Sulfide spring #swordtails, which makes it over 12 lineages of poeciliids in sulfide springs. #Xiphophorus #fishchum http:\/\/t.co\/mgxlhgd9Bs",
    "id" : 413419885889208320,
    "created_at" : "2013-12-18 21:25:56 +0000",
    "user" : {
      "name" : "Tobler Lab",
      "screen_name" : "michitobler",
      "protected" : false,
      "id_str" : "47138807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/874444153295208448\/MxaAI_uk_normal.jpg",
      "id" : 47138807,
      "verified" : false
    }
  },
  "id" : 413419997017686016,
  "created_at" : "2013-12-18 21:26:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Gt1fcYIv80",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=9gZMLcwY5j8",
      "display_url" : "youtube.com\/watch?v=9gZMLc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1031975501, 8.568515311 ]
  },
  "id_str" : "413402091013812226",
  "text" : "\u00ABDon\u2019t let your mind speak louder than your heart\u00BB Problems most people don\u2019t seem to have\u2026 (&lt;3 for the banjo player) http:\/\/t.co\/Gt1fcYIv80",
  "id" : 413402091013812226,
  "created_at" : "2013-12-18 20:15:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.098875184, 8.5475503656 ]
  },
  "id_str" : "413395769358811136",
  "text" : "\u00ABOther dogs bite only their enemies, whereas I bite also my friends in order to save them\u00BB Should have started to read about cynics earlier.",
  "id" : 413395769358811136,
  "created_at" : "2013-12-18 19:50:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413361607700279296",
  "text" : "Am Kaffee verschluckt &amp; beim aushusten quer \u00FCber den Schreibtisch verspritzt. Schon sieht alles hart bearbeitet aus. My work here is done!",
  "id" : 413361607700279296,
  "created_at" : "2013-12-18 17:34:21 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/m2pC8G1OM1",
      "expanded_url" : "http:\/\/i.imgur.com\/cOO8sIy.gif",
      "display_url" : "i.imgur.com\/cOO8sIy.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "413329170253369344",
  "text" : "now: http:\/\/t.co\/m2pC8G1OM1",
  "id" : 413329170253369344,
  "created_at" : "2013-12-18 15:25:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Loman",
      "screen_name" : "pathogenomenick",
      "indices" : [ 0, 16 ],
      "id_str" : "85906238",
      "id" : 85906238
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 17, 30 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 31, 36 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413322962909937664",
  "geo" : { },
  "id_str" : "413323482345111552",
  "in_reply_to_user_id" : 85906238,
  "text" : "@pathogenomenick @PhilippBayer @li5a thanks, that explains a lot and I now even remember having seem that post before m(",
  "id" : 413323482345111552,
  "in_reply_to_status_id" : 413322962909937664,
  "created_at" : "2013-12-18 15:02:52 +0000",
  "in_reply_to_screen_name" : "pathogenomenick",
  "in_reply_to_user_id_str" : "85906238",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 128, 141 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 142, 147 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413321889642053632",
  "text" : "Any MiSeq experts around? What happens if fixed readsize &gt; insertsize? Will it report PCR primers &amp; nts from the void ? \/@PhilippBayer @li5a",
  "id" : 413321889642053632,
  "created_at" : "2013-12-18 14:56:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/SPNhgl1WsK",
      "expanded_url" : "http:\/\/www.bmj.com\/content\/347\/bmj.f7398",
      "display_url" : "bmj.com\/content\/347\/bm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413300424557342720",
  "text" : "Oh, so BMJ now also does quantified self studies! \u00ABBeing right or being happy: pilot study\u00BB http:\/\/t.co\/SPNhgl1WsK",
  "id" : 413300424557342720,
  "created_at" : "2013-12-18 13:31:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/xohUy3g9No",
      "expanded_url" : "http:\/\/www.sciencedirect.com\/science\/article\/pii\/S1383574213000264",
      "display_url" : "sciencedirect.com\/science\/articl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413295895484960768",
  "text" : "How fruit flies came to launch the chromosome theory of heredity http:\/\/t.co\/xohUy3g9No",
  "id" : 413295895484960768,
  "created_at" : "2013-12-18 13:13:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/b1BvD2Vtum",
      "expanded_url" : "http:\/\/i14.photobucket.com\/albums\/a343\/jamayeux\/FuglydogShibaneckfat_zpsf937f93d.jpg",
      "display_url" : "i14.photobucket.com\/albums\/a343\/ja\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "413293893875408896",
  "geo" : { },
  "id_str" : "413294984721203201",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich such fur http:\/\/t.co\/b1BvD2Vtum",
  "id" : 413294984721203201,
  "in_reply_to_status_id" : 413293893875408896,
  "created_at" : "2013-12-18 13:09:37 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/o999YXrN4q",
      "expanded_url" : "http:\/\/images2.wikia.nocookie.net\/__cb20130515034649\/surgeon-simulator-2013\/images\/a\/a6\/Magic_trick.gif",
      "display_url" : "images2.wikia.nocookie.net\/__cb2013051503\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "413290925318615041",
  "geo" : { },
  "id_str" : "413293759355305984",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/o999YXrN4q",
  "id" : 413293759355305984,
  "in_reply_to_status_id" : 413290925318615041,
  "created_at" : "2013-12-18 13:04:45 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/keROhAnSuz",
      "expanded_url" : "https:\/\/i.chzbgr.com\/maxW500\/7841767168\/hBF613B47\/",
      "display_url" : "i.chzbgr.com\/maxW500\/784176\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413292157588348928",
  "text" : "meet sexy dogs near you https:\/\/t.co\/keROhAnSuz",
  "id" : 413292157588348928,
  "created_at" : "2013-12-18 12:58:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722884973, 8.6276515218 ]
  },
  "id_str" : "413285837749895168",
  "text" : "\u00ABHallo, der Pf\u00F6rtner hier. Ihre Sekret\u00E4rin hat gesagt sie k\u00F6nnen Rechner aufmachen ohne sie zu zerst\u00F6ren. K\u00F6nnten sie mal vorbeikommen?\u00BB",
  "id" : 413285837749895168,
  "created_at" : "2013-12-18 12:33:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413278050063622144",
  "geo" : { },
  "id_str" : "413278418281590784",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer great, I'm sold, especially as everything is explained using Wolfman :P",
  "id" : 413278418281590784,
  "in_reply_to_status_id" : 413278050063622144,
  "created_at" : "2013-12-18 12:03:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413276019328438272",
  "geo" : { },
  "id_str" : "413276710331641856",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer awesome, thanks!",
  "id" : 413276710331641856,
  "in_reply_to_status_id" : 413276019328438272,
  "created_at" : "2013-12-18 11:57:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413275616943673346",
  "geo" : { },
  "id_str" : "413275842823716864",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, I found that and saw it's SVN. And ppl here would rather lose all their data than use SVN (who can blame them).",
  "id" : 413275842823716864,
  "in_reply_to_status_id" : 413275616943673346,
  "created_at" : "2013-12-18 11:53:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413275454104010752",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer You're my go-to SWCarpentry-expert: Aware of any materials to teach git?",
  "id" : 413275454104010752,
  "created_at" : "2013-12-18 11:52:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/sYm95GJsxz",
      "expanded_url" : "http:\/\/www.bratton.info\/projects\/talks\/we-need-to-talk-about-ted\/",
      "display_url" : "bratton.info\/projects\/talks\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413259277319405568",
  "text" : "\u00ABI Think TED actually stands for: middlebrow megachurch infotainment.\u00BB http:\/\/t.co\/sYm95GJsxz",
  "id" : 413259277319405568,
  "created_at" : "2013-12-18 10:47:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/ZJGkBns7LJ",
      "expanded_url" : "http:\/\/johnconway.co\/images\/medium\/dinosaur_pet_guide.jpeg",
      "display_url" : "johnconway.co\/images\/medium\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413251103598206976",
  "text" : "Before you carelessly gift a dinosaur this Christmas: The Dinosaur Pet Guide http:\/\/t.co\/ZJGkBns7LJ",
  "id" : 413251103598206976,
  "created_at" : "2013-12-18 10:15:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/RBWf1qgSDG",
      "expanded_url" : "http:\/\/www.fastcocreate.com\/3023094\/science-says-art-will-make-your-kids-better-thinkers-and-nicer-people",
      "display_url" : "fastcocreate.com\/3023094\/scienc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413240815188578304",
  "text" : "Wisst ihr wer noch was mit Kunst gemacht hat?! http:\/\/t.co\/RBWf1qgSDG",
  "id" : 413240815188578304,
  "created_at" : "2013-12-18 09:34:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 0, 10 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413238547152646144",
  "geo" : { },
  "id_str" : "413240043545698304",
  "in_reply_to_user_id" : 14700783,
  "text" : "@Fischblog Treffer, du kennst mich einfach zu gut. ;) Vom Verhalten her k\u00F6nnte man glauben das uns mind-altering parasites infested haben.",
  "id" : 413240043545698304,
  "in_reply_to_status_id" : 413238547152646144,
  "created_at" : "2013-12-18 09:31:18 +0000",
  "in_reply_to_screen_name" : "Fischblog",
  "in_reply_to_user_id_str" : "14700783",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "indices" : [ 3, 16 ],
      "id_str" : "83589523",
      "id" : 83589523
    }, {
      "name" : "Stemettes \uD83D\uDC99 \u2605 # +",
      "screen_name" : "Stemettes",
      "indices" : [ 48, 58 ],
      "id_str" : "989452274",
      "id" : 989452274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413236123667013632",
  "text" : "RT @michelleoyen: It's not all about babies! RT @Stemettes Gender Barriers, Not Families, to Blame for Shortage of Women in STEM http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003ELinkis: turn sharing into growth\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stemettes \uD83D\uDC99 \u2605 # +",
        "screen_name" : "Stemettes",
        "indices" : [ 30, 40 ],
        "id_str" : "989452274",
        "id" : 989452274
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/SwBXgDbcYN",
        "expanded_url" : "http:\/\/ln.is\/buff.ly\/Zc81",
        "display_url" : "ln.is\/buff.ly\/Zc81"
      } ]
    },
    "geo" : { },
    "id_str" : "413235580819226624",
    "text" : "It's not all about babies! RT @Stemettes Gender Barriers, Not Families, to Blame for Shortage of Women in STEM http:\/\/t.co\/SwBXgDbcYN",
    "id" : 413235580819226624,
    "created_at" : "2013-12-18 09:13:34 +0000",
    "user" : {
      "name" : "Michelle Oyen",
      "screen_name" : "michelleoyen",
      "protected" : false,
      "id_str" : "83589523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479579308\/MyPicture_normal.jpg",
      "id" : 83589523,
      "verified" : false
    }
  },
  "id" : 413236123667013632,
  "created_at" : "2013-12-18 09:15:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723085534, 8.6276305591 ]
  },
  "id_str" : "413232747847876608",
  "text" : "Parasit\u00E4re Zoonosen verschenken, was gibt es sch\u00F6neres.",
  "id" : 413232747847876608,
  "created_at" : "2013-12-18 09:02:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724613837, 8.6273773335 ]
  },
  "id_str" : "413224125076094976",
  "text" : "\u00ABIch komm gleich nach zum rauchen. Ich muss gerade noch eine Weihnachtskarte die ich bekommen habe von cDNA in Protein translaten.\u00BB",
  "id" : 413224125076094976,
  "created_at" : "2013-12-18 08:28:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723879338, 8.6276128402 ]
  },
  "id_str" : "413217070609088512",
  "text" : "\u00ABLass mich doch mal vorbei, hab es eilig. Daran sieht man wie wichtig ich bin!\u00BB\u2014\u00ABFalsch, daran sieht man wie schlecht du organisiert bist\u2026\u00BB",
  "id" : 413217070609088512,
  "created_at" : "2013-12-18 08:00:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florian Z-Q",
      "screen_name" : "branleb",
      "indices" : [ 0, 8 ],
      "id_str" : "114220397",
      "id" : 114220397
    }, {
      "name" : "Stephan Urbach",
      "screen_name" : "herrurbach",
      "indices" : [ 9, 20 ],
      "id_str" : "28090494",
      "id" : 28090494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413210853232898048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1344031515, 8.6266236545 ]
  },
  "id_str" : "413211367500681216",
  "in_reply_to_user_id" : 114220397,
  "text" : "@branleb @herrurbach group hugs nicht vor dem ersten Kaffee bitte.",
  "id" : 413211367500681216,
  "in_reply_to_status_id" : 413210853232898048,
  "created_at" : "2013-12-18 07:37:21 +0000",
  "in_reply_to_screen_name" : "branleb",
  "in_reply_to_user_id_str" : "114220397",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096551774, 8.2830027018 ]
  },
  "id_str" : "413116658082140160",
  "text" : "Ice cream induced sugar high after 2am == a painful death in ~4 hours. \\o\/",
  "id" : 413116658082140160,
  "created_at" : "2013-12-18 01:21:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/vyI9kv0neT",
      "expanded_url" : "http:\/\/i.imgur.com\/KheQBqG.gif",
      "display_url" : "i.imgur.com\/KheQBqG.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0098029664, 8.2831183355 ]
  },
  "id_str" : "413115587523788800",
  "text" : "Rubber duck-billed platypus debugging http:\/\/t.co\/vyI9kv0neT",
  "id" : 413115587523788800,
  "created_at" : "2013-12-18 01:16:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "indices" : [ 3, 11 ],
      "id_str" : "300735398",
      "id" : 300735398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413110998867144704",
  "text" : "RT @aatishb: ok I'm clearly having too much fun with Google ngrams because I just learned they allow you to search with wildcards http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/atKPwdkmCu",
        "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/10\/googles-ngram-viewer-goes-wild\/280601\/",
        "display_url" : "theatlantic.com\/technology\/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413084243548327936",
    "text" : "ok I'm clearly having too much fun with Google ngrams because I just learned they allow you to search with wildcards http:\/\/t.co\/atKPwdkmCu",
    "id" : 413084243548327936,
    "created_at" : "2013-12-17 23:12:13 +0000",
    "user" : {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "protected" : false,
      "id_str" : "300735398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000817613002\/3814bf3474aff91370d827c2f4cbdb9b_normal.jpeg",
      "id" : 300735398,
      "verified" : true
    }
  },
  "id" : 413110998867144704,
  "created_at" : "2013-12-18 00:58:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/G6GeKQnkZ2",
      "expanded_url" : "http:\/\/hookedgame.humanities.uva.nl\/",
      "display_url" : "hookedgame.humanities.uva.nl"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "413087617711079424",
  "text" : "Pretty much fun: Hooked. A gamified citizen science project on musical hooks and musical transmission http:\/\/t.co\/G6GeKQnkZ2",
  "id" : 413087617711079424,
  "created_at" : "2013-12-17 23:25:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413014549038526464",
  "text" : "\u00AB\u00DCber sowas redet ihr?\u00BB\u2013\u00ABUnser Dirty Talk besteht aus Diskussionen \u00FCber die Splits von Knorpelfischen, Tetrapoda &amp; weiteren Knochenfischen.\u00BB",
  "id" : 413014549038526464,
  "created_at" : "2013-12-17 18:35:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00FCxin",
      "screen_name" : "foxeen",
      "indices" : [ 0, 7 ],
      "id_str" : "46904555",
      "id" : 46904555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413011440740495361",
  "geo" : { },
  "id_str" : "413012328523628544",
  "in_reply_to_user_id" : 46904555,
  "text" : "@foxeen Ja, total niedlich die Dinger. Das n\u00E4chste mal lasse ich mir den Forschungsgegenstand fr\u00FCher zeigen.",
  "id" : 413012328523628544,
  "in_reply_to_status_id" : 413011440740495361,
  "created_at" : "2013-12-17 18:26:27 +0000",
  "in_reply_to_screen_name" : "foxeen",
  "in_reply_to_user_id_str" : "46904555",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413010499987460096",
  "text" : "Seeing organisms you already have published on for the 1st time is always fun. Today: Chironomids (&amp; also learned about their anal papillae)",
  "id" : 413010499987460096,
  "created_at" : "2013-12-17 18:19:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412983129084014592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1197309028, 8.6570350469 ]
  },
  "id_str" : "412983344574767104",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich und verhindert das ich dich ohrfeige! ;)",
  "id" : 412983344574767104,
  "in_reply_to_status_id" : 412983129084014592,
  "created_at" : "2013-12-17 16:31:16 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 68, 77 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ZSTMWLdxlG",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0082531",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412883450626977792",
  "text" : "Defectors Cannot Be Detected during \u201CSmall Talk\u201D with Strangers \/cc @Senficon http:\/\/t.co\/ZSTMWLdxlG",
  "id" : 412883450626977792,
  "created_at" : "2013-12-17 09:54:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "li5a",
      "screen_name" : "li5a",
      "indices" : [ 0, 5 ],
      "id_str" : "11712822",
      "id" : 11712822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412864159756615681",
  "geo" : { },
  "id_str" : "412865701213253632",
  "in_reply_to_user_id" : 11712822,
  "text" : "@li5a well, they did map, just like millions of reads I don't care about atm but as said: picard can do it.",
  "id" : 412865701213253632,
  "in_reply_to_status_id" : 412864159756615681,
  "created_at" : "2013-12-17 08:43:48 +0000",
  "in_reply_to_screen_name" : "li5a",
  "in_reply_to_user_id_str" : "11712822",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412863265006313473",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nevermind, picard's FilterSamReads can do it good\/fast enough for my use case.",
  "id" : 412863265006313473,
  "created_at" : "2013-12-17 08:34:07 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412856617357410304",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Any idea on what's the best way to export the alignment-data for a given list of mapped reads from a sam\/bam?",
  "id" : 412856617357410304,
  "created_at" : "2013-12-17 08:07:42 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1527745164, 8.6612348272 ]
  },
  "id_str" : "412850031176466432",
  "text" : "\u00ABTo be cynical about even the things dogs love is hollow; to be a true Cynic leaves 1 a few devotions: loyalty, for instance, food, &amp; sleep\u00BB",
  "id" : 412850031176466432,
  "created_at" : "2013-12-17 07:41:32 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/as7d0z6PbD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=JZUC8FXEe2k",
      "display_url" : "youtube.com\/watch?v=JZUC8F\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "412748809811546112",
  "text" : "Safe Travels (Don't Die) http:\/\/t.co\/as7d0z6PbD",
  "id" : 412748809811546112,
  "created_at" : "2013-12-17 00:59:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412746836890234880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "412747234632273920",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer then you have a look at the log files and you are entering the tail -f of tears.",
  "id" : 412747234632273920,
  "in_reply_to_status_id" : 412746836890234880,
  "created_at" : "2013-12-17 00:53:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/cgoNS5fopO",
      "expanded_url" : "http:\/\/i.imgur.com\/mcv8KA9.gif",
      "display_url" : "i.imgur.com\/mcv8KA9.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "412742567353384960",
  "text" : "getting asked to fix some weird perl code. lol, nope. http:\/\/t.co\/cgoNS5fopO",
  "id" : 412742567353384960,
  "created_at" : "2013-12-17 00:34:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(Fred)erick Matsen",
      "screen_name" : "ematsen",
      "indices" : [ 3, 11 ],
      "id_str" : "183661891",
      "id" : 183661891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/S6hxGikHNX",
      "expanded_url" : "http:\/\/sites.google.com\/site\/ninanmluke\/Durbinetal-BiologicalSequenceAnalysi.pdf",
      "display_url" : "sites.google.com\/site\/ninanmluk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412738717024268288",
  "text" : "RT @ematsen: Durbin et al's classic _Biological Sequence Analysis_ on HMMs, etc, is available as PDF: http:\/\/t.co\/S6hxGikHNX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/S6hxGikHNX",
        "expanded_url" : "http:\/\/sites.google.com\/site\/ninanmluke\/Durbinetal-BiologicalSequenceAnalysi.pdf",
        "display_url" : "sites.google.com\/site\/ninanmluk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412732332068442112",
    "text" : "Durbin et al's classic _Biological Sequence Analysis_ on HMMs, etc, is available as PDF: http:\/\/t.co\/S6hxGikHNX",
    "id" : 412732332068442112,
    "created_at" : "2013-12-16 23:53:50 +0000",
    "user" : {
      "name" : "(Fred)erick Matsen",
      "screen_name" : "ematsen",
      "protected" : false,
      "id_str" : "183661891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2362170242\/xkd848pckplo65u9wm72_normal.png",
      "id" : 183661891,
      "verified" : false
    }
  },
  "id" : 412738717024268288,
  "created_at" : "2013-12-17 00:19:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "412736696992956416",
  "text" : "\u00ABMuss dir was schreckliches beichten\u2026 Ich habe den Tisch mit einer Wunderkerze angesengt\u00BB\u2013\u00ABWenn du so startest denk ich immer: \u2018Schwanger\u2019\u2026\u00BB",
  "id" : 412736696992956416,
  "created_at" : "2013-12-17 00:11:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 59, 68 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 69, 82 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/ioeii8FXn7",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0081558",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009654495, 8.283003715 ]
  },
  "id_str" : "412733677647720448",
  "text" : "Morals Matter in Economic Games http:\/\/t.co\/ioeii8FXn7 \/cc @Senficon @PhilippBayer",
  "id" : 412733677647720448,
  "created_at" : "2013-12-16 23:59:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/NVmXGp9mya",
      "expanded_url" : "http:\/\/simplystatistics.org\/2013\/12\/16\/a-summary-of-the-evidence-that-most-published-research-is-false\/",
      "display_url" : "simplystatistics.org\/2013\/12\/16\/a-s\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.167217, 8.686098 ]
  },
  "id_str" : "412686411289362432",
  "text" : "A summary of the evidence that most published research is false http:\/\/t.co\/NVmXGp9mya",
  "id" : 412686411289362432,
  "created_at" : "2013-12-16 20:51:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0685382593, 8.6355037659 ]
  },
  "id_str" : "412664882312794112",
  "text" : "\u00ABIch finde dich schon sehr rational.\u00BB \u2014 \u00ABRationaler als dich?\u00BB \u2014 \u00ABWir wollen ja mal nicht \u00FCberm\u00FCtig werden\u2026\u00BB",
  "id" : 412664882312794112,
  "created_at" : "2013-12-16 19:25:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/spIY6YPH6v",
      "expanded_url" : "http:\/\/www.theatlantic.com\/politics\/archive\/2013\/12\/if-a-drone-strike-hit-an-american-wedding-wed-ground-our-fleet\/282373\/",
      "display_url" : "theatlantic.com\/politics\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412601641204850688",
  "text" : "\u00ABIf a Drone Strike Hit an American Wedding, We'd Ground Our Fleet\u00BB http:\/\/t.co\/spIY6YPH6v",
  "id" : 412601641204850688,
  "created_at" : "2013-12-16 15:14:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Bja1FUXvKU",
      "expanded_url" : "http:\/\/i.imgur.com\/7E6rCye.gif",
      "display_url" : "i.imgur.com\/7E6rCye.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "412596188760657920",
  "text" : "\u00ABUnser Therapie-Hund viel besser als ein Therapie-Delphin. Der w\u00FCrde doch niemals in unser Planschbecken passen!\u00BB http:\/\/t.co\/Bja1FUXvKU",
  "id" : 412596188760657920,
  "created_at" : "2013-12-16 14:52:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u24EAss Mounce",
      "screen_name" : "rmounce",
      "indices" : [ 0, 8 ],
      "id_str" : "222765418",
      "id" : 222765418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412592730020519936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723265873, 8.627630609 ]
  },
  "id_str" : "412592931355500544",
  "in_reply_to_user_id" : 222765418,
  "text" : "@rmounce congrats!",
  "id" : 412592931355500544,
  "in_reply_to_status_id" : 412592730020519936,
  "created_at" : "2013-12-16 14:39:55 +0000",
  "in_reply_to_screen_name" : "rmounce",
  "in_reply_to_user_id_str" : "222765418",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/XHQsC8cp6Y",
      "expanded_url" : "http:\/\/blog.moertel.com\/posts\/2013-12-14-great-old-timey-game-programming-hack.html",
      "display_url" : "blog.moertel.com\/posts\/2013-12-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "412573765243895808",
  "text" : "What ultimately makes programming fun: \u00ABWe replaced this subroutine with a very special manifestation of insanity\u00BB http:\/\/t.co\/XHQsC8cp6Y",
  "id" : 412573765243895808,
  "created_at" : "2013-12-16 13:23:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0423\u0434\u0430\u0447\u0435\u0432a \u0420\u0430\u0434\u0430",
      "screen_name" : "ChirurgeonsAppr",
      "indices" : [ 3, 19 ],
      "id_str" : "2833430423",
      "id" : 2833430423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412550650015539200",
  "text" : "RT @ChirurgeonsAppr: Charles Darwin in letter to friend: \"But I am very poorly today and very stupid and hate everyone and everything.\" htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChirurgeonsAppr\/status\/411849323882631168\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/dqssPBRxoD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbcuxytCUAA4Bls.jpg",
        "id_str" : "411849323886825472",
        "id" : 411849323886825472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbcuxytCUAA4Bls.jpg",
        "sizes" : [ {
          "h" : 262,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 624
        } ],
        "display_url" : "pic.twitter.com\/dqssPBRxoD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411849323882631168",
    "text" : "Charles Darwin in letter to friend: \"But I am very poorly today and very stupid and hate everyone and everything.\" http:\/\/t.co\/dqssPBRxoD",
    "id" : 411849323882631168,
    "created_at" : "2013-12-14 13:25:05 +0000",
    "user" : {
      "name" : "Lindsey Fitzharris",
      "screen_name" : "DrLindseyFitz",
      "protected" : false,
      "id_str" : "229509740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698912111297171456\/Qeu3GBkp_normal.jpg",
      "id" : 229509740,
      "verified" : true
    }
  },
  "id" : 412550650015539200,
  "created_at" : "2013-12-16 11:51:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412540375178285056",
  "geo" : { },
  "id_str" : "412540748777549824",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon should be straightforward with vlc, but we can have a look later. And yes: The course was a pretty good intro iirc.",
  "id" : 412540748777549824,
  "in_reply_to_status_id" : 412540375178285056,
  "created_at" : "2013-12-16 11:12:33 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412537940158337024",
  "geo" : { },
  "id_str" : "412540267103653888",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon how to run the video at 2x or how to understand it at that speed?",
  "id" : 412540267103653888,
  "in_reply_to_status_id" : 412537940158337024,
  "created_at" : "2013-12-16 11:10:38 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412537003373125632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723143007, 8.6276335582 ]
  },
  "id_str" : "412537438704521216",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon is that the one we started watching together?",
  "id" : 412537438704521216,
  "in_reply_to_status_id" : 412537003373125632,
  "created_at" : "2013-12-16 10:59:24 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412535624831234048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.172313206, 8.6277244063 ]
  },
  "id_str" : "412536245940924416",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon in the end you will resort to re-watching A Beautiful Mind :p",
  "id" : 412536245940924416,
  "in_reply_to_status_id" : 412535624831234048,
  "created_at" : "2013-12-16 10:54:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412533551951642624",
  "geo" : { },
  "id_str" : "412535528882331648",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon thought you were reading up on game theory? is this an example of bounded rationality? ;)",
  "id" : 412535528882331648,
  "in_reply_to_status_id" : 412533551951642624,
  "created_at" : "2013-12-16 10:51:49 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 3, 15 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412532231568384000",
  "text" : "RT @helgerausch: \"Object-oriented programming isn't the fundamental particle of computing that some people want it to be\" http:\/\/t.co\/k6lrm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/k6lrmQs20u",
        "expanded_url" : "http:\/\/prog21.dadgum.com\/156.html",
        "display_url" : "prog21.dadgum.com\/156.html"
      } ]
    },
    "geo" : { },
    "id_str" : "412350908207734784",
    "text" : "\"Object-oriented programming isn't the fundamental particle of computing that some people want it to be\" http:\/\/t.co\/k6lrmQs20u",
    "id" : 412350908207734784,
    "created_at" : "2013-12-15 22:38:12 +0000",
    "user" : {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "protected" : false,
      "id_str" : "52747896",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841604882352201729\/O7uP_eHQ_normal.jpg",
      "id" : 52747896,
      "verified" : false
    }
  },
  "id" : 412532231568384000,
  "created_at" : "2013-12-16 10:38:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412526463124918272",
  "text" : "\u00ABDann hat sie ein Foto von uns beiden hochgeladen und verlinkt. Jetzt fragen alle was bei uns geht.\u00BB \u2013 \u00ABVerlinkt, verlobt, verheiratet!\u00BB",
  "id" : 412526463124918272,
  "created_at" : "2013-12-16 10:15:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672548096, 8.6860123857 ]
  },
  "id_str" : "412369827408650240",
  "text" : "\u00ABBrettspiele oder Sex?\u00BB\u2014\u00ABDu perverse Sau, wie kannst du das Fragen? Du wei\u00DFt ich hasse Brettspiele!\u00BB",
  "id" : 412369827408650240,
  "created_at" : "2013-12-15 23:53:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672566054, 8.6860125391 ]
  },
  "id_str" : "412320960780705792",
  "text" : "\u00ABF\u00E4llt dir was ein was als Trollerei zwischen uns begonnen hat &amp; ohne das wir jetzt nicht mehr Leben k\u00F6nnen?\u00BB\u2014\u00ABAu\u00DFer unserer Beziehung?\u00BB",
  "id" : 412320960780705792,
  "created_at" : "2013-12-15 20:39:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "indices" : [ 3, 12 ],
      "id_str" : "1205345400",
      "id" : 1205345400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/CnmSUCw1Nr",
      "expanded_url" : "http:\/\/nyti.ms\/1edLQ8c",
      "display_url" : "nyti.ms\/1edLQ8c"
    } ]
  },
  "geo" : { },
  "id_str" : "412316587371544577",
  "text" : "RT @DanGraur: Leaked! Harvard\u2019s Grading Rubric. \"The B+ grade is reserved for students who have committed assault.\" http:\/\/t.co\/CnmSUCw1Nr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/CnmSUCw1Nr",
        "expanded_url" : "http:\/\/nyti.ms\/1edLQ8c",
        "display_url" : "nyti.ms\/1edLQ8c"
      } ]
    },
    "geo" : { },
    "id_str" : "412281773502910464",
    "text" : "Leaked! Harvard\u2019s Grading Rubric. \"The B+ grade is reserved for students who have committed assault.\" http:\/\/t.co\/CnmSUCw1Nr",
    "id" : 412281773502910464,
    "created_at" : "2013-12-15 18:03:29 +0000",
    "user" : {
      "name" : "Dan (((Graur)))",
      "screen_name" : "DanGraur",
      "protected" : false,
      "id_str" : "1205345400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822591216776835072\/IO7mOPZQ_normal.jpg",
      "id" : 1205345400,
      "verified" : false
    }
  },
  "id" : 412316587371544577,
  "created_at" : "2013-12-15 20:21:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672371278, 8.6860327425 ]
  },
  "id_str" : "412295715436904448",
  "text" : "\u00ABIch mag es wenn du liest und dabei lachst. Au\u00DFer du liest was ich gerade schreibe!\u00BB",
  "id" : 412295715436904448,
  "created_at" : "2013-12-15 18:58:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 38, 48 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/A7gASdzoLQ",
      "expanded_url" : "https:\/\/pasteursquadrant.wordpress.com\/2013\/12\/14\/on-duons-and-cargo-cult-science\/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ResearchBloggingBiologyEnglish+%28Research+Blogging+-+English+-+Biology%29",
      "display_url" : "pasteursquadrant.wordpress.com\/2013\/12\/14\/on-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.167217, 8.686098 ]
  },
  "id_str" : "412253856375275520",
  "text" : "On \u201Cduons\u201D and cargo cult science \/cc @fragmente  https:\/\/t.co\/A7gASdzoLQ",
  "id" : 412253856375275520,
  "created_at" : "2013-12-15 16:12:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/68OukgjEeD",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/WJjcZMsm3lI\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.162582, 8.697281 ]
  },
  "id_str" : "412252243644399616",
  "text" : "The Adventures of Philosophically Inclined Mailman http:\/\/t.co\/68OukgjEeD",
  "id" : 412252243644399616,
  "created_at" : "2013-12-15 16:06:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/DnLHoLrWCt",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/outside\/comments\/1shksk\/im_levelling_faster_and_faster_with_each_level_is\/",
      "display_url" : "reddit.com\/r\/outside\/comm\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.173268, 8.672523 ]
  },
  "id_str" : "412248555559342080",
  "text" : "r\/outside: \u00ABI'm levelling faster and faster with each level. Is this supposed to happen?\u00BB http:\/\/t.co\/DnLHoLrWCt",
  "id" : 412248555559342080,
  "created_at" : "2013-12-15 15:51:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 13, 25 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412194473826086912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1673672814, 8.6860556994 ]
  },
  "id_str" : "412197489593561088",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @helgerausch well in that case we could do another run. ;)",
  "id" : 412197489593561088,
  "in_reply_to_status_id" : 412194473826086912,
  "created_at" : "2013-12-15 12:28:34 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412193807040782336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672942346, 8.6866034584 ]
  },
  "id_str" : "412194123287121920",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch yes, there\u2019s a rake task (or maybe just the rails c way) of running it because it seldom changes.",
  "id" : 412194123287121920,
  "in_reply_to_status_id" : 412193807040782336,
  "created_at" : "2013-12-15 12:15:11 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1671894752, 8.6859934532 ]
  },
  "id_str" : "412166641947262976",
  "text" : "\u00ABNormalerweise bist du ja so lala, aber wenn du blutverschmiert bist kannst du sogar ganz sexy sein.\u00BB",
  "id" : 412166641947262976,
  "created_at" : "2013-12-15 10:25:59 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/VHDm1bNkZx",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/feedarticle\/11109209",
      "display_url" : "theguardian.com\/world\/feedarti\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.166677, 8.686731 ]
  },
  "id_str" : "412006967402856448",
  "text" : "\u00ABfederal judge ruled Friday that key parts of Utah's polygamy laws are unconstitutional\u00BB http:\/\/t.co\/VHDm1bNkZx",
  "id" : 412006967402856448,
  "created_at" : "2013-12-14 23:51:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412004286911246336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672191366, 8.6860068337 ]
  },
  "id_str" : "412005279585533952",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s call it what you like ;)",
  "id" : 412005279585533952,
  "in_reply_to_status_id" : 412004286911246336,
  "created_at" : "2013-12-14 23:44:48 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412003611095617536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672058537, 8.6859803554 ]
  },
  "id_str" : "412004234897661952",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s das ist deine subtile Art dich freiwillig zu melden, right?",
  "id" : 412004234897661952,
  "in_reply_to_status_id" : 412003611095617536,
  "created_at" : "2013-12-14 23:40:38 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "412000833258414080",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1671780923, 8.6861029598 ]
  },
  "id_str" : "412002467405385729",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s zu Versuchszwecken.",
  "id" : 412002467405385729,
  "in_reply_to_status_id" : 412000833258414080,
  "created_at" : "2013-12-14 23:33:37 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672398623, 8.6858589258 ]
  },
  "id_str" : "412000564181221376",
  "text" : "\u00ABWir k\u00F6nnten beide \u2018Suche zus\u00E4tz. Partner, bitte per DM melden\u2019 twittern &amp; schauen wer mehr Anfragen bekommt\u00BB\u2014\u00ABDie bekomme ich ja so schon!\u00BB",
  "id" : 412000564181221376,
  "created_at" : "2013-12-14 23:26:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1672905032, 8.6866817437 ]
  },
  "id_str" : "411949684543209472",
  "text" : "\u00ABGibt es was neues bei Twitter?\u00BB \u2014 \u00ABDie Chinesen sind auf dem Mond gelandet.\u00BB \u2014 \u00ABAlle?! Haben die nichts besseres zu tun?!\u00BB",
  "id" : 411949684543209472,
  "created_at" : "2013-12-14 20:03:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Greiner",
      "screen_name" : "Seb666",
      "indices" : [ 3, 10 ],
      "id_str" : "2365333778",
      "id" : 2365333778
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 72, 81 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "senficast",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/jk8RRTUnnQ",
      "expanded_url" : "http:\/\/seb666.de\/?p=774",
      "display_url" : "seb666.de\/?p=774"
    } ]
  },
  "geo" : { },
  "id_str" : "411894713646858240",
  "text" : "RT @Seb666: Neuer Blog-Post auf seb666.de: Einladung zum #senficast mit @senficon: 15.12. \/ 15:00 Uhr - http:\/\/t.co\/jk8RRTUnnQ http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julia Reda",
        "screen_name" : "Senficon",
        "indices" : [ 60, 69 ],
        "id_str" : "14861745",
        "id" : 14861745
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Seb666\/status\/411888136776876032\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/uwMGQEmRnV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbdSE_PIQAAgL8t.png",
        "id_str" : "411888136575533056",
        "id" : 411888136575533056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbdSE_PIQAAgL8t.png",
        "sizes" : [ {
          "h" : 256,
          "resize" : "fit",
          "w" : 256
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 256
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 256
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 256
        } ],
        "display_url" : "pic.twitter.com\/uwMGQEmRnV"
      } ],
      "hashtags" : [ {
        "text" : "senficast",
        "indices" : [ 45, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/jk8RRTUnnQ",
        "expanded_url" : "http:\/\/seb666.de\/?p=774",
        "display_url" : "seb666.de\/?p=774"
      } ]
    },
    "geo" : { },
    "id_str" : "411888136776876032",
    "text" : "Neuer Blog-Post auf seb666.de: Einladung zum #senficast mit @senficon: 15.12. \/ 15:00 Uhr - http:\/\/t.co\/jk8RRTUnnQ http:\/\/t.co\/uwMGQEmRnV",
    "id" : 411888136776876032,
    "created_at" : "2013-12-14 15:59:18 +0000",
    "user" : {
      "name" : "Nie mehr Piraten!",
      "screen_name" : "NieMehrPiraten",
      "protected" : false,
      "id_str" : "18362640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581158232489623552\/MFck9q5F_normal.png",
      "id" : 18362640,
      "verified" : false
    }
  },
  "id" : 411894713646858240,
  "created_at" : "2013-12-14 16:25:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095455743, 8.2829396 ]
  },
  "id_str" : "411886689507106816",
  "text" : "Baking cookies is best wet lab work. No security officers to tell you not to eat or wear something under your lab coat!",
  "id" : 411886689507106816,
  "created_at" : "2013-12-14 15:53:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/BAb71O8emQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/h6FAZHBwmn\/",
      "display_url" : "instagram.com\/p\/h6FAZHBwmn\/"
    } ]
  },
  "geo" : { },
  "id_str" : "411883963909947392",
  "text" : "So cute! http:\/\/t.co\/BAb71O8emQ",
  "id" : 411883963909947392,
  "created_at" : "2013-12-14 15:42:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411651352704466944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675925, 8.28297492 ]
  },
  "id_str" : "411651540139925504",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, not bad. We cut our losses by 0.2 % :D",
  "id" : 411651540139925504,
  "in_reply_to_status_id" : 411651352704466944,
  "created_at" : "2013-12-14 00:19:09 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411650376064983040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675925, 8.28297492 ]
  },
  "id_str" : "411650769004556288",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer So we turned USD 1000 stuck in one virtual currency into USD 2, stuck in another one? :P",
  "id" : 411650769004556288,
  "in_reply_to_status_id" : 411650376064983040,
  "created_at" : "2013-12-14 00:16:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411650154190483457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675925, 8.28297492 ]
  },
  "id_str" : "411650261862465536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Okay, so how much money did we make? :D",
  "id" : 411650261862465536,
  "in_reply_to_status_id" : 411650154190483457,
  "created_at" : "2013-12-14 00:14:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 122, 135 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/v80T4gm6BQ",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0081100",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675925, 8.28297492 ]
  },
  "id_str" : "411634440570671104",
  "text" : "Predicting Protein-Protein Interaction by the Mirrortree Method: Possibilities and Limitations http:\/\/t.co\/v80T4gm6BQ \/cc @PhilippBayer",
  "id" : 411634440570671104,
  "created_at" : "2013-12-13 23:11:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/ySOzqg2Ifw",
      "expanded_url" : "http:\/\/www.reactiongifs.com\/wp-content\/uploads\/2013\/12\/my-body-is-ready1.gif.pagespeed.ce.PaV3t4yn3r.gif",
      "display_url" : "reactiongifs.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "411629041578307585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675925, 8.28297492 ]
  },
  "id_str" : "411630146144448512",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot http:\/\/t.co\/ySOzqg2Ifw",
  "id" : 411630146144448512,
  "in_reply_to_status_id" : 411629041578307585,
  "created_at" : "2013-12-13 22:54:09 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/5gEOCHMcnc",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/69886288972\/when-they-said-the-average-graduation-time-was-5-5",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/698862889\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "411626062225760257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675925, 8.28297492 ]
  },
  "id_str" : "411628773780750336",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot challenge accepted? ;) http:\/\/t.co\/5gEOCHMcnc",
  "id" : 411628773780750336,
  "in_reply_to_status_id" : 411626062225760257,
  "created_at" : "2013-12-13 22:48:42 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/SErADsXbAc",
      "expanded_url" : "http:\/\/classroomideas.files.wordpress.com\/2010\/02\/picture-5.png",
      "display_url" : "classroomideas.files.wordpress.com\/2010\/02\/pictur\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675925, 8.28297492 ]
  },
  "id_str" : "411625234002087936",
  "text" : "\u00ABBoth --master-bam and --slave-bam parameters are mandatory.\u00BB Oh, GAM-NGS. I see what you did there! http:\/\/t.co\/SErADsXbAc",
  "id" : 411625234002087936,
  "created_at" : "2013-12-13 22:34:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Denker",
      "screen_name" : "Phaidr0s",
      "indices" : [ 0, 9 ],
      "id_str" : "40466433",
      "id" : 40466433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411622802324590592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096675925, 8.28297492 ]
  },
  "id_str" : "411622954041352192",
  "in_reply_to_user_id" : 40466433,
  "text" : "@Phaidr0s Das erkl\u00E4rt zumindest wieso das Login-System der Bibliothek abschmiert wenn ich mich einloggen will.",
  "id" : 411622954041352192,
  "in_reply_to_status_id" : 411622802324590592,
  "created_at" : "2013-12-13 22:25:34 +0000",
  "in_reply_to_screen_name" : "Phaidr0s",
  "in_reply_to_user_id_str" : "40466433",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096371567, 8.2830582767 ]
  },
  "id_str" : "411622563354513408",
  "text" : "Seit eben ist meine Uni-Personal-# == Matrikel-#\u2026 Guess da hat eine DB so eben die eindeutige Zuordnung ihrer Primary Keys verloren\u2026 m(",
  "id" : 411622563354513408,
  "created_at" : "2013-12-13 22:24:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/CbfFkxceP1",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/69898411463\/when-i-attempt-bioinformatics",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/698984114\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096644825, 8.282991235 ]
  },
  "id_str" : "411613262858289152",
  "text" : "Pretty Accurate http:\/\/t.co\/CbfFkxceP1",
  "id" : 411613262858289152,
  "created_at" : "2013-12-13 21:47:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/oBGKxv97bT",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1046",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096644825, 8.282991235 ]
  },
  "id_str" : "411603953902968832",
  "text" : "the things that make life worth living http:\/\/t.co\/oBGKxv97bT",
  "id" : 411603953902968832,
  "created_at" : "2013-12-13 21:10:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Wilkins",
      "screen_name" : "jonfwilkins",
      "indices" : [ 70, 82 ],
      "id_str" : "214099847",
      "id" : 214099847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/mEk4MJSk29",
      "expanded_url" : "http:\/\/ronininstitute.org\/science-nature-and-cell-arent-the-problem-exactly\/749\/",
      "display_url" : "ronininstitute.org\/science-nature\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096653914, 8.2831301029 ]
  },
  "id_str" : "411602808736337920",
  "text" : "\u00ABScience, Nature, and Cell Aren\u2019t the Problem, Exactly\u00BB Great post by @jonfwilkins http:\/\/t.co\/mEk4MJSk29",
  "id" : 411602808736337920,
  "created_at" : "2013-12-13 21:05:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "El Qu\u00F3kka Pasa",
      "screen_name" : "Fischblog",
      "indices" : [ 52, 62 ],
      "id_str" : "14700783",
      "id" : 14700783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/8d9f8sqWIt",
      "expanded_url" : "http:\/\/i.imgur.com\/ULeM8km.png",
      "display_url" : "i.imgur.com\/ULeM8km.png"
    } ]
  },
  "geo" : { },
  "id_str" : "411477540549578752",
  "text" : "Holiday Seasons In The Abyss. I imagine this is how @Fischblog does Christmas decoration http:\/\/t.co\/8d9f8sqWIt",
  "id" : 411477540549578752,
  "created_at" : "2013-12-13 12:47:45 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/zMHa7D9hgr",
      "expanded_url" : "https:\/\/24.media.tumblr.com\/f517d34dfc38fe323a38ccd46ebe85ce\/tumblr_mwqa4nmgNi1rw1wnno1_400.gif",
      "display_url" : "24.media.tumblr.com\/f517d34dfc38fe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411450151673147393",
  "text" : "Finishing the last changes to the openSNP publication to please the reviewers https:\/\/t.co\/zMHa7D9hgr",
  "id" : 411450151673147393,
  "created_at" : "2013-12-13 10:58:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 58, 71 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/fEYBcvdMVJ",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003391",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411441223723806720",
  "text" : "Education in Computational Biology Today and Tomorrow \/cc @PhilippBayer http:\/\/t.co\/fEYBcvdMVJ",
  "id" : 411441223723806720,
  "created_at" : "2013-12-13 10:23:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/dGJwj0Mg6H",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003345",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411438713269272577",
  "text" : "Next-Generation Sequence Assembly: Four Stages of Data Processing and Computational Challenges http:\/\/t.co\/dGJwj0Mg6H",
  "id" : 411438713269272577,
  "created_at" : "2013-12-13 10:13:28 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411435985537208320",
  "geo" : { },
  "id_str" : "411436310679662592",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente \\o\/ War nicht sicher ob das 140 Zeichen Summary zu dense ist.",
  "id" : 411436310679662592,
  "in_reply_to_status_id" : 411435985537208320,
  "created_at" : "2013-12-13 10:03:55 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411435804422987776",
  "text" : "How-To Billy Bragg: \u00ABOh - and before you sing this song, think of something that really angers you.\u00BB",
  "id" : 411435804422987776,
  "created_at" : "2013-12-13 10:01:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411432072088010753",
  "geo" : { },
  "id_str" : "411434534245122049",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente imho: Nett, aber kein Nobel. Codon Usage Bias z.T. durch exon. Transcription Factor Binding Sites die man non-coding schon kannte",
  "id" : 411434534245122049,
  "in_reply_to_status_id" : 411432072088010753,
  "created_at" : "2013-12-13 09:56:51 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frau Fragmente",
      "screen_name" : "fragmente",
      "indices" : [ 0, 10 ],
      "id_str" : "7207642",
      "id" : 7207642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411432072088010753",
  "geo" : { },
  "id_str" : "411433805790994432",
  "in_reply_to_user_id" : 7207642,
  "text" : "@fragmente arg, Press Officer die nicht die Publikation verlinken! Lass mich mal gerade das Paper statt PR \u00FCberfliegen.",
  "id" : 411433805790994432,
  "in_reply_to_status_id" : 411432072088010753,
  "created_at" : "2013-12-13 09:53:58 +0000",
  "in_reply_to_screen_name" : "fragmente",
  "in_reply_to_user_id_str" : "7207642",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411419768357285889",
  "text" : "No joint probability in my dreams, just sex. Kinda makes sense. According to my students I tend to get a lustful look when talking HMMs.",
  "id" : 411419768357285889,
  "created_at" : "2013-12-13 08:58:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096977108, 8.2831113959 ]
  },
  "id_str" : "411306037615267840",
  "text" : "Last night I dreamt of discussing longitudinal waves with half my timeline. I hope we can do joint probability this night.",
  "id" : 411306037615267840,
  "created_at" : "2013-12-13 01:26:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411303349607084032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097335643, 8.2829611749 ]
  },
  "id_str" : "411303829993689088",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer 50:50 for awesome\/train wreck I\u2019d say. :p",
  "id" : 411303829993689088,
  "in_reply_to_status_id" : 411303349607084032,
  "created_at" : "2013-12-13 01:17:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/yLWTuelyVH",
      "expanded_url" : "http:\/\/mikehadlow.blogspot.co.uk\/2013\/12\/are-your-programmers-working-hard-or.html",
      "display_url" : "mikehadlow.blogspot.co.uk\/2013\/12\/are-yo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "411296547025190912",
  "text" : "RT @PhilippBayer: I agree: In programming,\"the appearance of hard work is often an indication of failure\" http:\/\/t.co\/yLWTuelyVH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/yLWTuelyVH",
        "expanded_url" : "http:\/\/mikehadlow.blogspot.co.uk\/2013\/12\/are-your-programmers-working-hard-or.html",
        "display_url" : "mikehadlow.blogspot.co.uk\/2013\/12\/are-yo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "411294334890164225",
    "text" : "I agree: In programming,\"the appearance of hard work is often an indication of failure\" http:\/\/t.co\/yLWTuelyVH",
    "id" : 411294334890164225,
    "created_at" : "2013-12-13 00:39:45 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 411296547025190912,
  "created_at" : "2013-12-13 00:48:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411291623096471552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096481447, 8.2830166848 ]
  },
  "id_str" : "411291980673875968",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer dunno, but translocation one thing they discuss (inversions\/duplications to be more specific). Just skimmed so far.",
  "id" : 411291980673875968,
  "in_reply_to_status_id" : 411291623096471552,
  "created_at" : "2013-12-13 00:30:24 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411287085094408192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968737, 8.2830131467 ]
  },
  "id_str" : "411288692222083072",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, but then it shouldn\u2019t be pop. specific I guess. At least the reason why contigs get misplaced would need to be pop. spec",
  "id" : 411288692222083072,
  "in_reply_to_status_id" : 411287085094408192,
  "created_at" : "2013-12-13 00:17:20 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 85, 98 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/Oj2feXJL9k",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0080754",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968737, 8.2830131467 ]
  },
  "id_str" : "411286750645223424",
  "text" : "Long Range Linkage Disequilibrium across the Human Genome http:\/\/t.co\/Oj2feXJL9k \/cc @PhilippBayer",
  "id" : 411286750645223424,
  "created_at" : "2013-12-13 00:09:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack O'linestyle",
      "screen_name" : "inlinestyle",
      "indices" : [ 3, 15 ],
      "id_str" : "407149407",
      "id" : 407149407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411264484230320128",
  "text" : "RT @InlineStyle: How to read a log:\n1. Tail out the log.\n2. Scroll through it really fast.\n3. If you see any weird shapes, stop and scroll \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411218236336660480",
    "text" : "How to read a log:\n1. Tail out the log.\n2. Scroll through it really fast.\n3. If you see any weird shapes, stop and scroll back to that.",
    "id" : 411218236336660480,
    "created_at" : "2013-12-12 19:37:22 +0000",
    "user" : {
      "name" : "Jack O'linestyle",
      "screen_name" : "inlinestyle",
      "protected" : false,
      "id_str" : "407149407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1628968647\/eightbit-c6ea5ab8-9b49-417e-a7ca-9a7a73a7470f_normal.png",
      "id" : 407149407,
      "verified" : false
    }
  },
  "id" : 411264484230320128,
  "created_at" : "2013-12-12 22:41:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095630247, 8.2831008793 ]
  },
  "id_str" : "411233509748256768",
  "text" : "\u00ABOh, ich brauche unbedingt noch irgendwas f\u00FCrs Schrottwichteln n\u00E4chste Woche!\u00BB\u2014\u00ABHast du deine selbstdesignten Primerpaare nicht noch?\u00BB",
  "id" : 411233509748256768,
  "created_at" : "2013-12-12 20:38:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411179018059546624",
  "geo" : { },
  "id_str" : "411180985414205440",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yeah, at that point you probably stop caring too much about your ROCs :p",
  "id" : 411180985414205440,
  "in_reply_to_status_id" : 411179018059546624,
  "created_at" : "2013-12-12 17:09:20 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411174752204881921",
  "geo" : { },
  "id_str" : "411177618910638080",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC normally I'd just say someone is grumpy because his ROCs turn out bad. But as he has a paper with 48k+ citations I won't ;)",
  "id" : 411177618910638080,
  "in_reply_to_status_id" : 411174752204881921,
  "created_at" : "2013-12-12 16:55:58 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/wqRYgd8Y0C",
      "expanded_url" : "http:\/\/i.imgur.com\/idUVX03.gif",
      "display_url" : "i.imgur.com\/idUVX03.gif"
    } ]
  },
  "in_reply_to_status_id_str" : "411171880914395136",
  "geo" : { },
  "id_str" : "411172284703834113",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon ja, baby steps\u2026 ;) http:\/\/t.co\/wqRYgd8Y0C",
  "id" : 411172284703834113,
  "in_reply_to_status_id" : 411171880914395136,
  "created_at" : "2013-12-12 16:34:46 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411171504895041536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723011851, 8.6276496907 ]
  },
  "id_str" : "411171723200180226",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon weil wir zumindest PEBKAC ausgeschlossen haben. ;)",
  "id" : 411171723200180226,
  "in_reply_to_status_id" : 411171504895041536,
  "created_at" : "2013-12-12 16:32:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411159540730580992",
  "text" : "Die kleinen Freuden: Statt Heureka zu schreien zusammen \u00FCber den Flur h\u00FCpfen und 'Wir sind doch nicht zu dumm!' rufen.",
  "id" : 411159540730580992,
  "created_at" : "2013-12-12 15:44:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "publicationbias",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411148996166434816",
  "text" : "\u00ABIn every paper you read: the ROC curve of their tool dominates all other ROC curves. It's amazing how that can happen!\u00BB #publicationbias",
  "id" : 411148996166434816,
  "created_at" : "2013-12-12 15:02:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723520009, 8.6276050189 ]
  },
  "id_str" : "411141436638502912",
  "text" : "\u00ABUnd dann hat sie wegen des Quietscheb\u00E4llchen Milcheinschuss bekommen!\u00BB\u2014\u00ABUnd du hast dich geopfert und eigenm\u00FCndig abgesaugt?\u00BB",
  "id" : 411141436638502912,
  "created_at" : "2013-12-12 14:32:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1722987508, 8.6276411558 ]
  },
  "id_str" : "411100174782840832",
  "text" : "\u00ABDie Namenspr\u00E4fixe der Gerichte in der Mensa werden auch von mies trainierten Markovketten generiert.\u00BB\u2014\u00ABSSO-Asiatisches Todes-Curry Chicken\u00BB",
  "id" : 411100174782840832,
  "created_at" : "2013-12-12 11:48:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411070564258697216",
  "text" : "\u00ABI know, ich wollte dir eine Mail mit dem Plot schicken, aber es kam Wein dazwischen\u2026\u00BB\u2013\u00ABIch habe wartend &amp; weinend vor der Inbox gesessen!\u00BB",
  "id" : 411070564258697216,
  "created_at" : "2013-12-12 09:50:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 7, 16 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411056931936419840",
  "geo" : { },
  "id_str" : "411057501082120192",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @Senficon likely.",
  "id" : 411057501082120192,
  "in_reply_to_status_id" : 411056931936419840,
  "created_at" : "2013-12-12 08:58:39 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "PLOS",
      "screen_name" : "PLOS",
      "indices" : [ 95, 100 ],
      "id_str" : "12819112",
      "id" : 12819112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411050798395965440",
  "geo" : { },
  "id_str" : "411052765306052608",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer Yay, thanks a lot for taking care of it. As well to the API team of @PLOS for allowing us back in :)",
  "id" : 411052765306052608,
  "in_reply_to_status_id" : 411050798395965440,
  "created_at" : "2013-12-12 08:39:50 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "411039633150341120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1105824347, 8.6860760312 ]
  },
  "id_str" : "411041848724299776",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon sry! Aber hey: Ich glaube es ist nicht deine W\u00E4sche :p",
  "id" : 411041848724299776,
  "in_reply_to_status_id" : 411039633150341120,
  "created_at" : "2013-12-12 07:56:28 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096291677, 8.2832845487 ]
  },
  "id_str" : "411027533992566784",
  "text" : "M\u00FCdigkeitslevel heute morgen: \u00DCber nichts gestolpert aber ohne es zu bemerken in Damenunterw\u00E4sche das Haus verlassen.",
  "id" : 411027533992566784,
  "created_at" : "2013-12-12 06:59:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/vFlBukq5X1",
      "expanded_url" : "http:\/\/i.imgur.com\/dwji9IO.gif",
      "display_url" : "i.imgur.com\/dwji9IO.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968737, 8.2830131467 ]
  },
  "id_str" : "410931940377001984",
  "text" : "just as planned http:\/\/t.co\/vFlBukq5X1",
  "id" : 410931940377001984,
  "created_at" : "2013-12-12 00:39:43 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410912174286987265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968737, 8.2830131467 ]
  },
  "id_str" : "410912282454286337",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon Es ging um \u201Cvom Z\u00FCchter geholt\u201D, nicht aus dem Tierheim!",
  "id" : 410912282454286337,
  "in_reply_to_status_id" : 410912174286987265,
  "created_at" : "2013-12-11 23:21:37 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410903668238450688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968737, 8.2830131467 ]
  },
  "id_str" : "410904027170627584",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot only if I might fight back. (and I may talk about Protostomia\/Deuterostomia in the process!) :p",
  "id" : 410904027170627584,
  "in_reply_to_status_id" : 410903668238450688,
  "created_at" : "2013-12-11 22:48:48 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410902716697702400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968737, 8.2830131467 ]
  },
  "id_str" : "410903466819985409",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot good thing we have gills!",
  "id" : 410903466819985409,
  "in_reply_to_status_id" : 410902716697702400,
  "created_at" : "2013-12-11 22:46:35 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cole",
      "screen_name" : "drchriscole",
      "indices" : [ 0, 12 ],
      "id_str" : "228015307",
      "id" : 228015307
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 75, 87 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 89, 102 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410892634904072192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410893384472342528",
  "in_reply_to_user_id" : 228015307,
  "text" : "@drchriscole thanks, especially SNPs \/w &lt; RsID do it sometimes. Let us (@helgerausch, @PhilippBayer, me) know if something else is amiss. :)",
  "id" : 410893384472342528,
  "in_reply_to_status_id" : 410892634904072192,
  "created_at" : "2013-12-11 22:06:31 +0000",
  "in_reply_to_screen_name" : "drchriscole",
  "in_reply_to_user_id_str" : "228015307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cole",
      "screen_name" : "drchriscole",
      "indices" : [ 0, 12 ],
      "id_str" : "228015307",
      "id" : 228015307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410787211689611264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410886300741697536",
  "in_reply_to_user_id" : 228015307,
  "text" : "@drchriscole and fixed :)",
  "id" : 410886300741697536,
  "in_reply_to_status_id" : 410787211689611264,
  "created_at" : "2013-12-11 21:38:22 +0000",
  "in_reply_to_screen_name" : "drchriscole",
  "in_reply_to_user_id_str" : "228015307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cole",
      "screen_name" : "drchriscole",
      "indices" : [ 0, 12 ],
      "id_str" : "228015307",
      "id" : 228015307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410787211689611264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410884330731606016",
  "in_reply_to_user_id" : 228015307,
  "text" : "@drchriscole thanks for the notice, will remove the wrong publications. :)",
  "id" : 410884330731606016,
  "in_reply_to_status_id" : 410787211689611264,
  "created_at" : "2013-12-11 21:30:32 +0000",
  "in_reply_to_screen_name" : "drchriscole",
  "in_reply_to_user_id_str" : "228015307",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0036507796, 8.2728037665 ]
  },
  "id_str" : "410851583837356032",
  "text" : "\u00ABNa klar ist mein Statistik-Fetisch actionable. Uniform verteilte Ohrfeigen!\u00BB \u2014 \u00ABR A Fisher ist das Safeword?\u00BB",
  "id" : 410851583837356032,
  "created_at" : "2013-12-11 19:20:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1708119084, 8.6233608238 ]
  },
  "id_str" : "410828559897608192",
  "text" : "\u00ABIch habe gerade das Cluster wieder mit 120k Jobs befeuert. Und jetzt muss ich schnell gehen, bevor der Admin das in seinen Mails liest.\u00BB",
  "id" : 410828559897608192,
  "created_at" : "2013-12-11 17:48:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410792310696194048",
  "text" : "\u00ABQuotas f\u00FCr Homedirectories? Wird hier jetzt der Faschismus des 21. Jahrhunderts eingef\u00FChrt?!\u00BB",
  "id" : 410792310696194048,
  "created_at" : "2013-12-11 15:24:53 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410773980061396992",
  "geo" : { },
  "id_str" : "410788075363528705",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer nope, nice!",
  "id" : 410788075363528705,
  "in_reply_to_status_id" : 410773980061396992,
  "created_at" : "2013-12-11 15:08:03 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/8j9Je81H7j",
      "expanded_url" : "http:\/\/i.imgur.com\/SCNLyPY.gif",
      "display_url" : "i.imgur.com\/SCNLyPY.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "410724551069138944",
  "text" : "The image that forms in my mind when someone says 'it is time to disrupt X' http:\/\/t.co\/8j9Je81H7j",
  "id" : 410724551069138944,
  "created_at" : "2013-12-11 10:55:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Jason H. Moore, PhD",
      "screen_name" : "moorejh",
      "indices" : [ 14, 22 ],
      "id_str" : "15496407",
      "id" : 15496407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410721766873378816",
  "geo" : { },
  "id_str" : "410722113960435712",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @moorejh Ah, the unused opportunities == \"not enough ppl are using it yet\". Agree on that!",
  "id" : 410722113960435712,
  "in_reply_to_status_id" : 410721766873378816,
  "created_at" : "2013-12-11 10:45:57 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Jason H. Moore, PhD",
      "screen_name" : "moorejh",
      "indices" : [ 14, 22 ],
      "id_str" : "15496407",
      "id" : 15496407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410721142417002496",
  "geo" : { },
  "id_str" : "410721509133402112",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @moorejh what are you missing, do you have an example? :)",
  "id" : 410721509133402112,
  "in_reply_to_status_id" : 410721142417002496,
  "created_at" : "2013-12-11 10:43:33 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410718020940480512",
  "geo" : { },
  "id_str" : "410718386939654144",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well, I stopped counting how many job offers and research opportunities came due to Twitter. ;)",
  "id" : 410718386939654144,
  "in_reply_to_status_id" : 410718020940480512,
  "created_at" : "2013-12-11 10:31:08 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410717617138053122",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1725060484, 8.6322218185 ]
  },
  "id_str" : "410717861045628928",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer that\u2019s what happens when reading your feeds before checking the important twitter lists :p",
  "id" : 410717861045628928,
  "in_reply_to_status_id" : 410717617138053122,
  "created_at" : "2013-12-11 10:29:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SIVe8W22T8",
      "expanded_url" : "http:\/\/www.icelandreview.com\/icelandreview\/daily_news\/Herring_Unmoved_by_Rolling_Stones_0_404616.news.aspx",
      "display_url" : "icelandreview.com\/icelandreview\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410716988445437952",
  "text" : "\u00ABHerring in Iceland unmoved when researchers attempted to scare them out of the fjord by playing The Rolling Stones\u00BB http:\/\/t.co\/SIVe8W22T8",
  "id" : 410716988445437952,
  "created_at" : "2013-12-11 10:25:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410714149279510528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.177072992, 8.6259389761 ]
  },
  "id_str" : "410715097771036672",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich keine falsche Zur\u00FCckhaltung bitte ;)",
  "id" : 410715097771036672,
  "in_reply_to_status_id" : 410714149279510528,
  "created_at" : "2013-12-11 10:18:04 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.177072992, 8.6259389761 ]
  },
  "id_str" : "410715036358025216",
  "text" : "\u00ABDer Bart riecht so b\u00E4rtig!\u00BB \u2014 \u00ABIch glaube du meinst blutig.\u00BB",
  "id" : 410715036358025216,
  "created_at" : "2013-12-11 10:17:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410712866330005504",
  "geo" : { },
  "id_str" : "410713469969637376",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Mein Homefolder wiegt &gt;1 TB und hat nicht f\u00FCr die Top5 gereicht. Du liegst also um mehr als eine 10er-Potenz daneben ;)",
  "id" : 410713469969637376,
  "in_reply_to_status_id" : 410712866330005504,
  "created_at" : "2013-12-11 10:11:36 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410706517331939328",
  "text" : "Knapp an der frisch gek\u00FCrten 'Top 5 der Speicherplatzkiller' vorbeigeschlittert. Wasche meine H\u00E4nde also in Unschuld. \\o\/",
  "id" : 410706517331939328,
  "created_at" : "2013-12-11 09:43:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 115, 128 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/bHeyoQgecc",
      "expanded_url" : "http:\/\/www.plosmedicine.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pmed.1001562",
      "display_url" : "plosmedicine.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410704192844480512",
  "text" : "Data Sharing in a Humanitarian Organization: The Experience of M\u00E9decins Sans Fronti\u00E8res http:\/\/t.co\/bHeyoQgecc \/cc @PhilippBayer",
  "id" : 410704192844480512,
  "created_at" : "2013-12-11 09:34:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/xSxmId25o1",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0081984",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410700271904247809",
  "text" : "To Control False Positives in Gene-Gene Interaction Analysis: Two Novel Conditional Entropy-Based Approaches http:\/\/t.co\/xSxmId25o1",
  "id" : 410700271904247809,
  "created_at" : "2013-12-11 09:19:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathrin Passig",
      "screen_name" : "kathrinpassig",
      "indices" : [ 21, 35 ],
      "id_str" : "14547663",
      "id" : 14547663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MPnmNqCJIs",
      "expanded_url" : "http:\/\/sz-magazin.sueddeutsche.de\/texte\/anzeigen\/41273",
      "display_url" : "sz-magazin.sueddeutsche.de\/texte\/anzeigen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410694513242284032",
  "text" : "Mein Wille geschehe: @kathrinpassig \u00FCber Wolfgang Herrndorf und die Frage, wie man leben muss und sterben darf http:\/\/t.co\/MPnmNqCJIs",
  "id" : 410694513242284032,
  "created_at" : "2013-12-11 08:56:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/cFHZQcNwNa",
      "expanded_url" : "http:\/\/i.imgur.com\/2q3gVmg.jpg",
      "display_url" : "i.imgur.com\/2q3gVmg.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "410688167063203840",
  "text" : "Not even once http:\/\/t.co\/cFHZQcNwNa",
  "id" : 410688167063203840,
  "created_at" : "2013-12-11 08:31:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096588922, 8.2830195581 ]
  },
  "id_str" : "410542762455740416",
  "text" : "Romantik 101: \u00ABIch liebe dich viel mehr als irgendeine gew\u00F6hnliche Gummiente\u00BB\u2014\u00ABIch liebe dich auch viel mehr als eine beliebige Studentin\u00BB",
  "id" : 410542762455740416,
  "created_at" : "2013-12-10 22:53:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410532384598007808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096904049, 8.2830215781 ]
  },
  "id_str" : "410532751209926657",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot ja, weil sie so schrecklich ungewaschen war!",
  "id" : 410532751209926657,
  "in_reply_to_status_id" : 410532384598007808,
  "created_at" : "2013-12-10 22:13:29 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/tYQHiy6g1a",
      "expanded_url" : "http:\/\/i.imgur.com\/ow6JiiU.gif",
      "display_url" : "i.imgur.com\/ow6JiiU.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410528813739933697",
  "text" : "how much did i drink last night?! http:\/\/t.co\/tYQHiy6g1a",
  "id" : 410528813739933697,
  "created_at" : "2013-12-10 21:57:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "indices" : [ 3, 19 ],
      "id_str" : "15150453",
      "id" : 15150453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/uh3s7fpw41",
      "expanded_url" : "http:\/\/sfist.com\/2013\/12\/10\/we_are_all_this_rat_stuck_on_a_bart.php",
      "display_url" : "sfist.com\/2013\/12\/10\/we_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410525317426864128",
  "text" : "RT @AndreaKuszewski: !!! We Are All This Rat Stuck On A BART Escalator http:\/\/t.co\/uh3s7fpw41 via @",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/uh3s7fpw41",
        "expanded_url" : "http:\/\/sfist.com\/2013\/12\/10\/we_are_all_this_rat_stuck_on_a_bart.php",
        "display_url" : "sfist.com\/2013\/12\/10\/we_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "410524575252754432",
    "text" : "!!! We Are All This Rat Stuck On A BART Escalator http:\/\/t.co\/uh3s7fpw41 via @",
    "id" : 410524575252754432,
    "created_at" : "2013-12-10 21:41:00 +0000",
    "user" : {
      "name" : "Andrea Kuszewski \uD83E\uDDE0",
      "screen_name" : "AndreaKuszewski",
      "protected" : false,
      "id_str" : "15150453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/879595697800060928\/-tdsZ4nM_normal.jpg",
      "id" : 15150453,
      "verified" : true
    }
  },
  "id" : 410525317426864128,
  "created_at" : "2013-12-10 21:43:57 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/0J2aX051LM",
      "expanded_url" : "http:\/\/media.tumblr.com\/tumblr_mbr537LFxQ1r0cmjy.gif",
      "display_url" : "media.tumblr.com\/tumblr_mbr537L\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "410517879608840192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410518587540242432",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon http:\/\/t.co\/0J2aX051LM",
  "id" : 410518587540242432,
  "in_reply_to_status_id" : 410517879608840192,
  "created_at" : "2013-12-10 21:17:12 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/aFlFbmwDOf",
      "expanded_url" : "http:\/\/gifrific.com\/wp-content\/uploads\/2012\/04\/LeBron-James-Smallest-Violin-Gif.gif",
      "display_url" : "gifrific.com\/wp-content\/upl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "410517346647015424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410517635961741312",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon http:\/\/t.co\/aFlFbmwDOf",
  "id" : 410517635961741312,
  "in_reply_to_status_id" : 410517346647015424,
  "created_at" : "2013-12-10 21:13:26 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/xVPT9anydV",
      "expanded_url" : "http:\/\/i.imgur.com\/ZMpw7QN.gif",
      "display_url" : "i.imgur.com\/ZMpw7QN.gif"
    }, {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/ZQmryituDf",
      "expanded_url" : "http:\/\/www.pbh2.com\/wordpress\/wp-content\/uploads\/2012\/08\/funniest-dog-gifs-jump.gif",
      "display_url" : "pbh2.com\/wordpress\/wp-c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410517183769640960",
  "text" : "finally getting my jobs up &amp; running: http:\/\/t.co\/xVPT9anydV finding out that all cluster nodes crashed a day later: http:\/\/t.co\/ZQmryituDf",
  "id" : 410517183769640960,
  "created_at" : "2013-12-10 21:11:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410513623392718848",
  "text" : "\u00ABIch fand das sehr skandal\u00F6s, dass sie dich an meinen Geburtstag erinnern musste\u2026 Wann war deiner noch mal?\u00BB",
  "id" : 410513623392718848,
  "created_at" : "2013-12-10 20:57:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/6mm82tswZp",
      "expanded_url" : "http:\/\/www.theguardian.com\/technology\/2013\/dec\/09\/internet-surveillance-spying",
      "display_url" : "theguardian.com\/technology\/201\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00964095, 8.282996388 ]
  },
  "id_str" : "410497289137172480",
  "text" : "\u00AB[W]e have finally attained Peak Indifference to Surveillance\u00BB http:\/\/t.co\/6mm82tswZp",
  "id" : 410497289137172480,
  "created_at" : "2013-12-10 19:52:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/UPMizcABUU",
      "expanded_url" : "http:\/\/instagram.com\/p\/hwKwkAhwiQ\/",
      "display_url" : "instagram.com\/p\/hwKwkAhwiQ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "410489809371955200",
  "text" : "Sometimes it pays off to read terrible first drafts. http:\/\/t.co\/UPMizcABUU",
  "id" : 410489809371955200,
  "created_at" : "2013-12-10 19:22:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/KshlyAAcKH",
      "expanded_url" : "http:\/\/what-if.xkcd.com\/75\/",
      "display_url" : "what-if.xkcd.com\/75\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9856285325, 8.3731179031 ]
  },
  "id_str" : "410484862991499264",
  "text" : "The real reason why polyamory needed technological advances to get off the ground http:\/\/t.co\/KshlyAAcKH",
  "id" : 410484862991499264,
  "created_at" : "2013-12-10 19:03:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1175170099, 8.6815164583 ]
  },
  "id_str" : "410475911252045824",
  "text" : "\u00ABDu bist verlobt! Ich wusste nicht das du romantisch bist.\u00BB\u2014\u00ABNaja, meine Freundin musste mich an den Geburtstag meiner Verlobten erinnern\u2026\u00BB",
  "id" : 410475911252045824,
  "created_at" : "2013-12-10 18:27:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410473742792261632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1167396514, 8.6817881665 ]
  },
  "id_str" : "410474077930156032",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC that would probably just get substituted to awk ;)",
  "id" : 410474077930156032,
  "in_reply_to_status_id" : 410473742792261632,
  "created_at" : "2013-12-10 18:20:21 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410471563410935810",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1167075276, 8.6797823636 ]
  },
  "id_str" : "410472223322165248",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC have to watch it doesn\u2019t happen vice versa. Otherwise students might take it the wrong way if offer to \u2018show them sed tomorrow\u2019",
  "id" : 410472223322165248,
  "in_reply_to_status_id" : 410471563410935810,
  "created_at" : "2013-12-10 18:12:58 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1091396426, 8.6771521893 ]
  },
  "id_str" : "410465504495947776",
  "text" : "Nerd-Credibility &gt; 9000: My phone starts to autocorrect \u2018sex\u2019 to \u2018sed\u2019\u2026",
  "id" : 410465504495947776,
  "created_at" : "2013-12-10 17:46:17 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410377801150124032",
  "text" : "The second stackoverflow &amp; Biostar close I will probably have to return to the wetlab\/fieldwork\u2026",
  "id" : 410377801150124032,
  "created_at" : "2013-12-10 11:57:46 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/VNzo192ngm",
      "expanded_url" : "http:\/\/www.theweedblog.com\/cannabis-may-prevent-erectile-dysfunction-caused-by-high-cholesterol\/",
      "display_url" : "theweedblog.com\/cannabis-may-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410376497161981952",
  "text" : "\u00ABCannabis May Prevent Erectile Dysfunction Caused By High Cholesterol\u00BB Unfortunately the munchies will &gt; cholesterol\u2026 http:\/\/t.co\/VNzo192ngm",
  "id" : 410376497161981952,
  "created_at" : "2013-12-10 11:52:36 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410364755627368448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723279073, 8.6276466715 ]
  },
  "id_str" : "410365361385910272",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer you know the 1% rule of bioinformatics: 90% time spent trying to compile, 9% actual runtime, 1% finding out claims are bogus",
  "id" : 410365361385910272,
  "in_reply_to_status_id" : 410364755627368448,
  "created_at" : "2013-12-10 11:08:21 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410364099118120960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1726735502, 8.6275122979 ]
  },
  "id_str" : "410364764578406400",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer nope, it\u2019s not poolseq, single individual.",
  "id" : 410364764578406400,
  "in_reply_to_status_id" : 410364099118120960,
  "created_at" : "2013-12-10 11:05:58 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410363828312879104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723237921, 8.6276136113 ]
  },
  "id_str" : "410364616385265664",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer but no worries, already found a couple of tools that claim to do it. Just thought I maybe could save time for test driving. :)",
  "id" : 410364616385265664,
  "in_reply_to_status_id" : 410363828312879104,
  "created_at" : "2013-12-10 11:05:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410363828312879104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723463428, 8.6275589335 ]
  },
  "id_str" : "410364388080898048",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer don\u2019t have those at hand, only paired-end with \u2014&gt;&lt;\u2014 orientation and &lt;700bp insert size.",
  "id" : 410364388080898048,
  "in_reply_to_status_id" : 410363828312879104,
  "created_at" : "2013-12-10 11:04:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410362125781987328",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer Do you have any experience using transcripts - generated by RNAseq - for genome scaffolding? If so: any tool recommendations?",
  "id" : 410362125781987328,
  "created_at" : "2013-12-10 10:55:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1724122576, 8.6274759077 ]
  },
  "id_str" : "410353838328401920",
  "text" : "Beste Begr\u00FC\u00DFung von Leuten die Mittags erst im B\u00FCro erscheinen: \u00ABNa, wie kommst du mit dem gelangweilt rumsitzen voran?\u00BB",
  "id" : 410353838328401920,
  "created_at" : "2013-12-10 10:22:33 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/1n6LkxBzDo",
      "expanded_url" : "http:\/\/www.vice.com\/read\/bucharest-webcam-studios-america-outsourcing-sex-trade",
      "display_url" : "vice.com\/read\/bucharest\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410336348411674624",
  "text" : "\u00ABI Spent a Month Living in a Romanian Sexcam Studio\u00BB http:\/\/t.co\/1n6LkxBzDo",
  "id" : 410336348411674624,
  "created_at" : "2013-12-10 09:13:03 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/wpDwD1Ma6i",
      "expanded_url" : "http:\/\/svpow.com\/2013\/12\/06\/elsevier-is-taking-down-papers-from-academia-edu\/",
      "display_url" : "svpow.com\/2013\/12\/06\/els\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410324739417059328",
  "text" : "Elsevier is taking down papers from Academia(.edu) http:\/\/t.co\/wpDwD1Ma6i",
  "id" : 410324739417059328,
  "created_at" : "2013-12-10 08:26:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acid\u0FC8 \u1515\u1548\u1587\u1571\u15EF\u1602 \u1515\u1573\u157C\u15DD\u1602\u1571\u1587",
      "screen_name" : "acid23",
      "indices" : [ 0, 7 ],
      "id_str" : "35535998",
      "id" : 35535998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410300295789690880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0037957402, 8.3687046915 ]
  },
  "id_str" : "410300667736358912",
  "in_reply_to_user_id" : 35535998,
  "text" : "@acid23 Kaffee kochen w\u00E4r mir lieber ;)",
  "id" : 410300667736358912,
  "in_reply_to_status_id" : 410300295789690880,
  "created_at" : "2013-12-10 06:51:16 +0000",
  "in_reply_to_screen_name" : "acid23",
  "in_reply_to_user_id_str" : "35535998",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410300193524170752",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0037957402, 8.3687046915 ]
  },
  "id_str" : "410300428224823296",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj check und check.",
  "id" : 410300428224823296,
  "in_reply_to_status_id" : 410300193524170752,
  "created_at" : "2013-12-10 06:50:19 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410299540886286336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0044816441, 8.3508186588 ]
  },
  "id_str" : "410300007976534016",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj es war an. :3",
  "id" : 410300007976534016,
  "in_reply_to_status_id" : 410299540886286336,
  "created_at" : "2013-12-10 06:48:39 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0060506107, 8.2838102251 ]
  },
  "id_str" : "410299097577709568",
  "text" : "Aufstehen. \u00DCber den Kater stolpern. \u00DCber den im Flur verendeten Roomba stolpern. \u00DCber die Katze stolpern. \u00DCber die eigenen F\u00FC\u00DFe stolpern\u2026",
  "id" : 410299097577709568,
  "created_at" : "2013-12-10 06:45:02 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "indices" : [ 3, 18 ],
      "id_str" : "76013938",
      "id" : 76013938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/WcOhaMPDZ7",
      "expanded_url" : "http:\/\/s.shr.lc\/1jFXxom",
      "display_url" : "s.shr.lc\/1jFXxom"
    } ]
  },
  "geo" : { },
  "id_str" : "410204369406418944",
  "text" : "RT @john_s_wilkins: Why ecologists might want to read more philosophy of science | Dynamic Ecology - http:\/\/t.co\/WcOhaMPDZ7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/WcOhaMPDZ7",
        "expanded_url" : "http:\/\/s.shr.lc\/1jFXxom",
        "display_url" : "s.shr.lc\/1jFXxom"
      } ]
    },
    "geo" : { },
    "id_str" : "410202799776202753",
    "text" : "Why ecologists might want to read more philosophy of science | Dynamic Ecology - http:\/\/t.co\/WcOhaMPDZ7",
    "id" : 410202799776202753,
    "created_at" : "2013-12-10 00:22:23 +0000",
    "user" : {
      "name" : "John S. Wilkins",
      "screen_name" : "john_s_wilkins",
      "protected" : false,
      "id_str" : "76013938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/852294288838807552\/FZpeLbxA_normal.jpg",
      "id" : 76013938,
      "verified" : false
    }
  },
  "id" : 410204369406418944,
  "created_at" : "2013-12-10 00:28:37 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 14, 23 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410192813993652224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096934201, 8.2831700511 ]
  },
  "id_str" : "410193034664763392",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @SuicideC the perks of using a tablet over a dedicated ebook-reader :)",
  "id" : 410193034664763392,
  "in_reply_to_status_id" : 410192813993652224,
  "created_at" : "2013-12-09 23:43:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 14, 23 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410192311809622016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096934201, 8.2831700511 ]
  },
  "id_str" : "410192453468454912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @SuicideC speak for yourself! The first 20 pages were fun so far :)",
  "id" : 410192453468454912,
  "in_reply_to_status_id" : 410192311809622016,
  "created_at" : "2013-12-09 23:41:16 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 14, 23 ],
      "id_str" : "78977466",
      "id" : 78977466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410191735159939073",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096934201, 8.2831700511 ]
  },
  "id_str" : "410192011288125440",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @SuicideC actually I\u2019m finishing the night with \u2018how learning works\u2019 ;)",
  "id" : 410192011288125440,
  "in_reply_to_status_id" : 410191735159939073,
  "created_at" : "2013-12-09 23:39:31 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/oB88BTQsy4",
      "expanded_url" : "http:\/\/i.imgur.com\/CxpnQzO.jpg",
      "display_url" : "i.imgur.com\/CxpnQzO.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968763, 8.28301916 ]
  },
  "id_str" : "410180598113001472",
  "text" : "\u00B1 how I look like in a lab coat http:\/\/t.co\/oB88BTQsy4",
  "id" : 410180598113001472,
  "created_at" : "2013-12-09 22:54:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410156328351305728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096590072, 8.2829848118 ]
  },
  "id_str" : "410158655049580545",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt @Senficon immerhin werden so alle Leute rausgefiltert die Hunde doof finden?",
  "id" : 410158655049580545,
  "in_reply_to_status_id" : 410156328351305728,
  "created_at" : "2013-12-09 21:26:58 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "antiprodukt",
      "screen_name" : "antiprodukt",
      "indices" : [ 0, 12 ],
      "id_str" : "149089037",
      "id" : 149089037
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410155715911614464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096600092, 8.283144665 ]
  },
  "id_str" : "410156260374622209",
  "in_reply_to_user_id" : 149089037,
  "text" : "@antiprodukt @Senficon Sorry, ich hatte immer nur Augen f\u00FCr den Hund :3",
  "id" : 410156260374622209,
  "in_reply_to_status_id" : 410155715911614464,
  "created_at" : "2013-12-09 21:17:27 +0000",
  "in_reply_to_screen_name" : "antiprodukt",
  "in_reply_to_user_id_str" : "149089037",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410154527355318273",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968763, 8.28301916 ]
  },
  "id_str" : "410155309798531073",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon pff, ich werd schon seit Jahren von niemandem mehr angegraben der mir nicht vorher gefolgt ist (und wenn es literally war\u2026)",
  "id" : 410155309798531073,
  "in_reply_to_status_id" : 410154527355318273,
  "created_at" : "2013-12-09 21:13:40 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "inhale exhale repeat",
      "screen_name" : "C_Holler",
      "indices" : [ 10, 19 ],
      "id_str" : "65671142",
      "id" : 65671142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410153616864194560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968763, 8.28301916 ]
  },
  "id_str" : "410154180893241344",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @C_Holler offensichtlich falle ich sehr einfach f\u00FCr die \u00ABHallo sagen, gefolgt von awkward-silence\u00BB-Nummer.",
  "id" : 410154180893241344,
  "in_reply_to_status_id" : 410153616864194560,
  "created_at" : "2013-12-09 21:09:11 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "inhale exhale repeat",
      "screen_name" : "C_Holler",
      "indices" : [ 10, 19 ],
      "id_str" : "65671142",
      "id" : 65671142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410152351954374656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410153139523043330",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @C_Holler Was sie sagt. Mit genau der Masche hat sie mich damals abgeschleppt!",
  "id" : 410153139523043330,
  "in_reply_to_status_id" : 410152351954374656,
  "created_at" : "2013-12-09 21:05:03 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/W2Ss4w8zNy",
      "expanded_url" : "http:\/\/s3.amazonaws.com\/barkpost-assets\/50+GIFs\/35.gif",
      "display_url" : "s3.amazonaws.com\/barkpost-asset\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "410149636007923713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410152640614780928",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @PhilippBayer I offer my best source of motivation: dog gifs! once you\u2019ve finished you can go out &amp; party! http:\/\/t.co\/W2Ss4w8zNy",
  "id" : 410152640614780928,
  "in_reply_to_status_id" : 410149636007923713,
  "created_at" : "2013-12-09 21:03:04 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410151030459207681",
  "text" : "Ich kenne genau 2 Gruppen die eMails mit \u00ABpriority: urgent\u00BB versenden: Spammer &amp; die Piratenpartei.",
  "id" : 410151030459207681,
  "created_at" : "2013-12-09 20:56:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/dEGEHQEyMN",
      "expanded_url" : "http:\/\/massgenomics.org\/2013\/12\/fda-genetic-right-to-know.html",
      "display_url" : "massgenomics.org\/2013\/12\/fda-ge\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410150042277011456",
  "text" : "The FDA, 23andMe, and Genetic Right to Know http:\/\/t.co\/dEGEHQEyMN",
  "id" : 410150042277011456,
  "created_at" : "2013-12-09 20:52:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ON5YiPTxwH",
      "expanded_url" : "http:\/\/whatshouldwecallgradschool.tumblr.com\/post\/69504349025\/if-i-could-mark-more-honestly",
      "display_url" : "whatshouldwecallgradschool.tumblr.com\/post\/695043490\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "410147739406573568",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410148556600004608",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @PhilippBayer best of luck with the grading. Highly relevant: http:\/\/t.co\/ON5YiPTxwH ;)",
  "id" : 410148556600004608,
  "in_reply_to_status_id" : 410147739406573568,
  "created_at" : "2013-12-09 20:46:50 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/QjpoOpU9yk",
      "expanded_url" : "http:\/\/gettinggeneticsdone.blogspot.de\/2013\/12\/biostar-cheat-sheet-zero-one-based-genomic-coordinate-systems.html",
      "display_url" : "gettinggeneticsdone.blogspot.de\/2013\/12\/biosta\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410147833694912513",
  "text" : "On the #1 error source in bioinformatics: \u00ABCheat sheet for one-based vs zero-based coordinate systems\u00BB http:\/\/t.co\/QjpoOpU9yk",
  "id" : 410147833694912513,
  "created_at" : "2013-12-09 20:43:58 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410145825788923904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410146975376769024",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @PhilippBayer that\u2019s a feeling I mostly get while reading the first drafts of theses.",
  "id" : 410146975376769024,
  "in_reply_to_status_id" : 410145825788923904,
  "created_at" : "2013-12-09 20:40:33 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410144306800775168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410144904854396928",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @PhilippBayer and grading is also superb source of smug superiority ;)",
  "id" : 410144904854396928,
  "in_reply_to_status_id" : 410144306800775168,
  "created_at" : "2013-12-09 20:32:20 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410142746096058369",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009650118, 8.283074046 ]
  },
  "id_str" : "410143059092176896",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @PhilippBayer if you like the feeling of being superior I can recommend reading it and give you an ebook copy. Otherwise skip it.",
  "id" : 410143059092176896,
  "in_reply_to_status_id" : 410142746096058369,
  "created_at" : "2013-12-09 20:25:00 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/f9sa9C5tZm",
      "expanded_url" : "https:\/\/www.goodreads.com\/review\/show\/780705248",
      "display_url" : "goodreads.com\/review\/show\/78\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "410140756980948992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009555648, 8.282958928 ]
  },
  "id_str" : "410141305097187328",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @PhilippBayer yeah, that\u2019s rare for me as well. I even made it through this awful thing https:\/\/t.co\/f9sa9C5tZm",
  "id" : 410141305097187328,
  "in_reply_to_status_id" : 410140756980948992,
  "created_at" : "2013-12-09 20:18:01 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 75, 88 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410140312921575424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009555648, 8.282958928 ]
  },
  "id_str" : "410141012670300160",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC yes the mandatory reading impression (and the 1\/5 star review by @PhilippBayer) me me interested in it.",
  "id" : 410141012670300160,
  "in_reply_to_status_id" : 410140312921575424,
  "created_at" : "2013-12-09 20:16:52 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suicideC",
      "screen_name" : "SuicideC",
      "indices" : [ 0, 9 ],
      "id_str" : "78977466",
      "id" : 78977466
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 10, 23 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "410139286596366336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009555648, 8.282958928 ]
  },
  "id_str" : "410139480931442688",
  "in_reply_to_user_id" : 78977466,
  "text" : "@SuicideC @PhilippBayer yeah, 70% of the book read and then couldn\u2019t stand it any longer. Did you like it?",
  "id" : 410139480931442688,
  "in_reply_to_status_id" : 410139286596366336,
  "created_at" : "2013-12-09 20:10:46 +0000",
  "in_reply_to_screen_name" : "SuicideC",
  "in_reply_to_user_id_str" : "78977466",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 126, 139 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0069335306, 8.3340273856 ]
  },
  "id_str" : "410125157202927617",
  "text" : "\u2018Stranger in a Strange Land\u2019 won, made it to the 70% mark but I\u2019m not willing to lose two more hours of my life finishing it\u2026 @PhilippBayer",
  "id" : 410125157202927617,
  "created_at" : "2013-12-09 19:13:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/vrD1hFwYzj",
      "expanded_url" : "http:\/\/i.imgur.com\/OzOHezJ.jpg",
      "display_url" : "i.imgur.com\/OzOHezJ.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "410099953311043584",
  "text" : "cutest Christmas decoration ever http:\/\/t.co\/vrD1hFwYzj",
  "id" : 410099953311043584,
  "created_at" : "2013-12-09 17:33:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410095200241864704",
  "text" : "\u00ABHast du den Sysadmin gesehen?\u00BB \u2013 \u00ABNein, aber wenn er hier vorbeikommt stelle ich ihm ein Bein. Dann weiss er ja zu wem er soll.\u00BB",
  "id" : 410095200241864704,
  "created_at" : "2013-12-09 17:14:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410077670005673984",
  "text" : "fun: passing your FASTQs through different tools and after a couple of passes the read naming scheme explodes all over the place\u2026",
  "id" : 410077670005673984,
  "created_at" : "2013-12-09 16:05:10 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/aIAXvvcZiq",
      "expanded_url" : "http:\/\/blogs.plos.org\/scied\/2013\/12\/09\/teaching-entomology\/",
      "display_url" : "blogs.plos.org\/scied\/2013\/12\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410072885718294528",
  "text" : "Teaching entomology in a world afraid of bugs http:\/\/t.co\/aIAXvvcZiq",
  "id" : 410072885718294528,
  "created_at" : "2013-12-09 15:46:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2BRSJ1aWgE",
      "expanded_url" : "http:\/\/i.imgur.com\/3POyupA.gif",
      "display_url" : "i.imgur.com\/3POyupA.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "410041189128077313",
  "text" : "I wish MacOS would replace the beach ball with this gif instead. Waiting would be so much fun http:\/\/t.co\/2BRSJ1aWgE",
  "id" : 410041189128077313,
  "created_at" : "2013-12-09 13:40:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Qu3AKorAhw",
      "expanded_url" : "http:\/\/i.imgur.com\/AY1eqFi.gif",
      "display_url" : "i.imgur.com\/AY1eqFi.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "410035388846067712",
  "text" : "typical Monday morning in the office http:\/\/t.co\/Qu3AKorAhw",
  "id" : 410035388846067712,
  "created_at" : "2013-12-09 13:17:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723677428, 8.6275770779 ]
  },
  "id_str" : "410018200999723008",
  "text" : "\u00ABWir haben f\u00FCr 2 Wochen einen Gast der hier ist um Bioinformatik zu lernen. Wenn er also traurig schaut puschelt ihn &amp; fragt was los ist.\u00BB",
  "id" : 410018200999723008,
  "created_at" : "2013-12-09 12:08:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723804665, 8.6275808054 ]
  },
  "id_str" : "409997982101434368",
  "text" : "Motto des Tages so weit: \u2018How extremely stupid not to have thought of that!\u2019",
  "id" : 409997982101434368,
  "created_at" : "2013-12-09 10:48:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409846032894144512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096842173, 8.2830184353 ]
  },
  "id_str" : "409846359190429696",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my pleasure. Finally reading \u2018sperm competition\u2019 did pay off :p",
  "id" : 409846359190429696,
  "in_reply_to_status_id" : 409846032894144512,
  "created_at" : "2013-12-09 00:46:01 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409844283424772096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096842173, 8.2830184353 ]
  },
  "id_str" : "409844607019913216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer phew ok, I was really puzzled on how that change would play out after reading the first half :D",
  "id" : 409844607019913216,
  "in_reply_to_status_id" : 409844283424772096,
  "created_at" : "2013-12-09 00:39:03 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409842897249259520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009684216, 8.2830184461 ]
  },
  "id_str" : "409843262833557504",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, wondered about that for a while. I think your review stated polyandry. Sure you didn\u2019t mean polygyny?",
  "id" : 409843262833557504,
  "in_reply_to_status_id" : 409842897249259520,
  "created_at" : "2013-12-09 00:33:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409841174946381825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009665609, 8.2831065193 ]
  },
  "id_str" : "409842022254923776",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer i could see how a 13yo would love a book where the first half basically consists of naked female servants doing pool parties.",
  "id" : 409842022254923776,
  "in_reply_to_status_id" : 409841174946381825,
  "created_at" : "2013-12-09 00:28:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409841174946381825",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009665609, 8.2831065193 ]
  },
  "id_str" : "409841600958062593",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer my uneducated guess would be that mostly males are doing those lists and have fond memories of reading it as adolescents?",
  "id" : 409841600958062593,
  "in_reply_to_status_id" : 409841174946381825,
  "created_at" : "2013-12-09 00:27:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409840440678961152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0094846637, 8.2829548046 ]
  },
  "id_str" : "409840767977652225",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer though there was enough rampant sexism in the first 50% to make me cringe a lot.",
  "id" : 409840767977652225,
  "in_reply_to_status_id" : 409840440678961152,
  "created_at" : "2013-12-09 00:23:48 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409839625100722176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096818669, 8.2831982774 ]
  },
  "id_str" : "409840334869635072",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer btw I\u2019m disappointed, just crossed the 50% mark of Stranger and still no lecturing!",
  "id" : 409840334869635072,
  "in_reply_to_status_id" : 409839625100722176,
  "created_at" : "2013-12-09 00:22:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009676414, 8.283185418 ]
  },
  "id_str" : "409832405290070016",
  "text" : "\u00ABKannst du bitte aufh\u00F6ren mir Piraten andrehen zu wollen? Du hast jetzt genug OkStupid gespielt!\u00BB",
  "id" : 409832405290070016,
  "created_at" : "2013-12-08 23:50:34 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409829971830374400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009676414, 8.283185418 ]
  },
  "id_str" : "409830647721910272",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer wow, so that was actually pretty close :D",
  "id" : 409830647721910272,
  "in_reply_to_status_id" : 409829971830374400,
  "created_at" : "2013-12-08 23:43:35 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409827747557429248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009676414, 8.283185418 ]
  },
  "id_str" : "409829505231253504",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer \u00ABX days of usage without going insane\u00BB",
  "id" : 409829505231253504,
  "in_reply_to_status_id" : 409827747557429248,
  "created_at" : "2013-12-08 23:39:02 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096303823, 8.2829927815 ]
  },
  "id_str" : "409796153254117376",
  "text" : "\u00ABDu behandelst mich viel weniger schlecht als deine anderen Partner? Tolle Aussage, macht mich das Primary?\u00BB",
  "id" : 409796153254117376,
  "created_at" : "2013-12-08 21:26:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ethan O. Perlstein",
      "screen_name" : "eperlste",
      "indices" : [ 3, 12 ],
      "id_str" : "237409428",
      "id" : 237409428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409765054020853762",
  "text" : "RT @eperlste: The real tragedy of the academic job market is that it reduces smart, data-driven people to crossing their fingers and hoping\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409758452131442688",
    "text" : "The real tragedy of the academic job market is that it reduces smart, data-driven people to crossing their fingers and hoping for the best.",
    "id" : 409758452131442688,
    "created_at" : "2013-12-08 18:56:42 +0000",
    "user" : {
      "name" : "Ethan O. Perlstein",
      "screen_name" : "eperlste",
      "protected" : false,
      "id_str" : "237409428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/911105941373779968\/MS1jXuJJ_normal.jpg",
      "id" : 237409428,
      "verified" : false
    }
  },
  "id" : 409765054020853762,
  "created_at" : "2013-12-08 19:22:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "indices" : [ 3, 15 ],
      "id_str" : "16629477",
      "id" : 16629477
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 88, 96 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/kXicnxHc7M",
      "expanded_url" : "http:\/\/www.yourgeneticgenealogist.com\/2013\/12\/23andme-releases-sample-of-their-new-v4.html",
      "display_url" : "yourgeneticgenealogist.com\/2013\/12\/23andm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409711345635196928",
  "text" : "RT @dgmacarthur: There's also some justifiable concern in the genealogy community about @23andMe's new chip: http:\/\/t.co\/kXicnxHc7M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "23andMe",
        "screen_name" : "23andMe",
        "indices" : [ 71, 79 ],
        "id_str" : "14738561",
        "id" : 14738561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/kXicnxHc7M",
        "expanded_url" : "http:\/\/www.yourgeneticgenealogist.com\/2013\/12\/23andme-releases-sample-of-their-new-v4.html",
        "display_url" : "yourgeneticgenealogist.com\/2013\/12\/23andm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "409553362729046016",
    "text" : "There's also some justifiable concern in the genealogy community about @23andMe's new chip: http:\/\/t.co\/kXicnxHc7M",
    "id" : 409553362729046016,
    "created_at" : "2013-12-08 05:21:45 +0000",
    "user" : {
      "name" : "Daniel MacArthur",
      "screen_name" : "dgmacarthur",
      "protected" : false,
      "id_str" : "16629477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856238606507180033\/GWLCCqUC_normal.jpg",
      "id" : 16629477,
      "verified" : false
    }
  },
  "id" : 409711345635196928,
  "created_at" : "2013-12-08 15:49:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonas",
      "screen_name" : "lsanoj",
      "indices" : [ 0, 7 ],
      "id_str" : "18918915",
      "id" : 18918915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409695600373170176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 49.9980856899, 8.2679075982 ]
  },
  "id_str" : "409696895289020416",
  "in_reply_to_user_id" : 18918915,
  "text" : "@lsanoj selber horsten?",
  "id" : 409696895289020416,
  "in_reply_to_status_id" : 409695600373170176,
  "created_at" : "2013-12-08 14:52:06 +0000",
  "in_reply_to_screen_name" : "lsanoj",
  "in_reply_to_user_id_str" : "18918915",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 68, 81 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/VzofV7H8vb",
      "expanded_url" : "http:\/\/www.soundofdrowning.com\/Fred_Hates_Us_All.html",
      "display_url" : "soundofdrowning.com\/Fred_Hates_Us_\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096577467, 8.28298578 ]
  },
  "id_str" : "409671499407429632",
  "text" : "Fred Hates Us All: A Basset In The Abyss http:\/\/t.co\/VzofV7H8vb \/cc @PhilippBayer",
  "id" : 409671499407429632,
  "created_at" : "2013-12-08 13:11:11 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00960464, 8.283014665 ]
  },
  "id_str" : "409657669465960448",
  "text" : "Sometimes get the impression that some SNP callers perform worse than coin flips\u2026 Which would kinda impress me\u2026 (well, not rly thx 2 HWE)",
  "id" : 409657669465960448,
  "created_at" : "2013-12-08 12:16:14 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 3, 12 ],
      "id_str" : "31936449",
      "id" : 31936449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/3QabmS6tAt",
      "expanded_url" : "http:\/\/wp.me\/pRx4V-nl",
      "display_url" : "wp.me\/pRx4V-nl"
    } ]
  },
  "geo" : { },
  "id_str" : "409633286533955584",
  "text" : "RT @lpachter: In memory of Emile Zuckerkandl (1922-2013) \nhttp:\/\/t.co\/3QabmS6tAt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/3QabmS6tAt",
        "expanded_url" : "http:\/\/wp.me\/pRx4V-nl",
        "display_url" : "wp.me\/pRx4V-nl"
      } ]
    },
    "geo" : { },
    "id_str" : "409603681785372672",
    "text" : "In memory of Emile Zuckerkandl (1922-2013) \nhttp:\/\/t.co\/3QabmS6tAt",
    "id" : 409603681785372672,
    "created_at" : "2013-12-08 08:41:42 +0000",
    "user" : {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "protected" : false,
      "id_str" : "31936449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/861688064258719744\/p8MVi-zW_normal.jpg",
      "id" : 31936449,
      "verified" : false
    }
  },
  "id" : 409633286533955584,
  "created_at" : "2013-12-08 10:39:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/q5ERicuHoo",
      "expanded_url" : "https:\/\/trac.adium.im\/ticket\/16365",
      "display_url" : "trac.adium.im\/ticket\/16365"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096685207, 8.2831495162 ]
  },
  "id_str" : "409499026799988736",
  "text" : "Found out what\u2019s wrong on my machine. But: update didn\u2019t fix it &amp; I still have no clue why it started in 1st place\u2026 https:\/\/t.co\/q5ERicuHoo",
  "id" : 409499026799988736,
  "created_at" : "2013-12-08 01:45:50 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/409458139147563008\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Zq6wPckoRs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba6wAgxIYAAFmW0.png",
      "id_str" : "409458138979786752",
      "id" : 409458138979786752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba6wAgxIYAAFmW0.png",
      "sizes" : [ {
        "h" : 102,
        "resize" : "fit",
        "w" : 105
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 105
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 105
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 105
      }, {
        "h" : 102,
        "resize" : "crop",
        "w" : 102
      } ],
      "display_url" : "pic.twitter.com\/Zq6wPckoRs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096634025, 8.2831127025 ]
  },
  "id_str" : "409458139147563008",
  "text" : "Zeilenumbr\u00FCche from Hell http:\/\/t.co\/Zq6wPckoRs",
  "id" : 409458139147563008,
  "created_at" : "2013-12-07 23:03:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/AqjXfwQLjn",
      "expanded_url" : "http:\/\/instagram.com\/p\/hoyDKuBwv5\/",
      "display_url" : "instagram.com\/p\/hoyDKuBwv5\/"
    } ]
  },
  "geo" : { },
  "id_str" : "409450092597608448",
  "text" : "\u00ABImmer wenn ich den Teig ausrolle teilt sich Pangaea in Gondwana und Laurasia!\u00BB http:\/\/t.co\/AqjXfwQLjn",
  "id" : 409450092597608448,
  "created_at" : "2013-12-07 22:31:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 53, 66 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/1lEyMDCJm5",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/plosone\/PLoSONE\/~3\/_k3cTBee0bE\/info%3Adoi%2F10.1371%2Fjournal.pone.0080511",
      "display_url" : "feedproxy.google.com\/~r\/plosone\/PLo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00969, 8.283188 ]
  },
  "id_str" : "409378540032114688",
  "text" : "Bayesian Centroid Estimation for Motif Discovery \/cc @PhilippBayer  http:\/\/t.co\/1lEyMDCJm5",
  "id" : 409378540032114688,
  "created_at" : "2013-12-07 17:47:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/KTHV2Nv9eC",
      "expanded_url" : "http:\/\/99percentinvisible.org\/episode\/diy-space-suits\/",
      "display_url" : "99percentinvisible.org\/episode\/diy-sp\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009658, 8.283113 ]
  },
  "id_str" : "409377830477520896",
  "text" : "DIY Space Suits: \u00ABIt would be so embarrassing to get killed in it. So I will make it work.\u00BB &lt;3 http:\/\/t.co\/KTHV2Nv9eC",
  "id" : 409377830477520896,
  "created_at" : "2013-12-07 17:44:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/rlUQHkRYcj",
      "expanded_url" : "http:\/\/feedproxy.google.com\/~r\/smbc-comics\/PvLb\/~3\/gNixPKaSzb0\/index.php",
      "display_url" : "feedproxy.google.com\/~r\/smbc-comics\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009582, 8.28309 ]
  },
  "id_str" : "409357851115937792",
  "text" : "This makes dating biologists much more appealing to me http:\/\/t.co\/rlUQHkRYcj",
  "id" : 409357851115937792,
  "created_at" : "2013-12-07 16:24:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Jb6xpxqNvk",
      "expanded_url" : "http:\/\/www.radiolab.org\/story\/ice-cold-case\/",
      "display_url" : "radiolab.org\/story\/ice-cold\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009641349, 8.283020741 ]
  },
  "id_str" : "409354616271564800",
  "text" : "Where palynologists can end up: \u00ABThey snaked some fancy equipment up [\u00D6tzi\u2019s] butt and started rooting around\u2026\u00BB http:\/\/t.co\/Jb6xpxqNvk",
  "id" : 409354616271564800,
  "created_at" : "2013-12-07 16:12:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409347863475654656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096403255, 8.2830205464 ]
  },
  "id_str" : "409352060145270785",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch damn, why do you have to live so far away? :p",
  "id" : 409352060145270785,
  "in_reply_to_status_id" : 409347863475654656,
  "created_at" : "2013-12-07 16:01:51 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096137449, 8.2830115329 ]
  },
  "id_str" : "409346143425159168",
  "text" : "Not sure how i did it: accessing Mac OS keychain\/trying to manage certificates seems to completely crash SSL stack. Only reboot helps o_O",
  "id" : 409346143425159168,
  "created_at" : "2013-12-07 15:38:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralf Reski \uD83C\uDDE9\uD83C\uDDEA\uD83C\uDDEA\uD83C\uDDFA",
      "screen_name" : "ReskiLab",
      "indices" : [ 0, 9 ],
      "id_str" : "79478121",
      "id" : 79478121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409308488326991872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0010953489, 8.2587963071 ]
  },
  "id_str" : "409318625196400640",
  "in_reply_to_user_id" : 79478121,
  "text" : "@ReskiLab lass mich doch noch etwas tr\u00E4umen ;)",
  "id" : 409318625196400640,
  "in_reply_to_status_id" : 409308488326991872,
  "created_at" : "2013-12-07 13:48:59 +0000",
  "in_reply_to_screen_name" : "ReskiLab",
  "in_reply_to_user_id_str" : "79478121",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409307368628170752",
  "text" : "\u00ABProfessor werden zu wollen um nackt im B\u00FCro sitzen zu k\u00F6nnen w\u00E4hrend man \u2018Wissenschaftsfreiheit!\u2019 schreit ist ein valides Lebensziel.\u00BB",
  "id" : 409307368628170752,
  "created_at" : "2013-12-07 13:04:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 7, 14 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409287973960556544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097121485, 8.2828751765 ]
  },
  "id_str" : "409291710796402688",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @TnaKng machst du dich wieder \u00FCber meine Augenprobleme lustig?",
  "id" : 409291710796402688,
  "in_reply_to_status_id" : 409287973960556544,
  "created_at" : "2013-12-07 12:02:02 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409291355266252800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097121485, 8.2828751765 ]
  },
  "id_str" : "409291455648522240",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thanks a lot :)",
  "id" : 409291455648522240,
  "in_reply_to_status_id" : 409291355266252800,
  "created_at" : "2013-12-07 12:01:01 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409291076550553600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097121485, 8.2828751765 ]
  },
  "id_str" : "409291394642374657",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer but your solution sounds good to me :)",
  "id" : 409291394642374657,
  "in_reply_to_status_id" : 409291076550553600,
  "created_at" : "2013-12-07 12:00:47 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409291076550553600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097121485, 8.2828751765 ]
  },
  "id_str" : "409291322353520640",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer okay, I think the problem was that it failed on our first machine for more arcane reasons and was thus added.",
  "id" : 409291322353520640,
  "in_reply_to_status_id" : 409291076550553600,
  "created_at" : "2013-12-07 12:00:30 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 0, 12 ],
      "id_str" : "52747896",
      "id" : 52747896
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 13, 26 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409288249988104192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009515644, 8.282933081 ]
  },
  "id_str" : "409288465751474176",
  "in_reply_to_user_id" : 52747896,
  "text" : "@helgerausch @PhilippBayer thanks for the notice. What to do instead? (Besides adding a sleep?)",
  "id" : 409288465751474176,
  "in_reply_to_status_id" : 409288249988104192,
  "created_at" : "2013-12-07 11:49:09 +0000",
  "in_reply_to_screen_name" : "helgerausch",
  "in_reply_to_user_id_str" : "52747896",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    }, {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 8, 14 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409287165651066880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009639257, 8.2826461591 ]
  },
  "id_str" : "409287457612783616",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng @lobot also bei uns zumindest :p",
  "id" : 409287457612783616,
  "in_reply_to_status_id" : 409287165651066880,
  "created_at" : "2013-12-07 11:45:08 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409279657763028992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009630494, 8.283057066 ]
  },
  "id_str" : "409280498939469824",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng leider nur die 8. :p",
  "id" : 409280498939469824,
  "in_reply_to_status_id" : 409279657763028992,
  "created_at" : "2013-12-07 11:17:29 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 0, 7 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409276034333159424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096922339, 8.2830562353 ]
  },
  "id_str" : "409279277709131776",
  "in_reply_to_user_id" : 339564605,
  "text" : "@TnaKng ich starte mal: es sollte ein Video sein, damit man sieht wie mies ich im einlochen bin.",
  "id" : 409279277709131776,
  "in_reply_to_status_id" : 409276034333159424,
  "created_at" : "2013-12-07 11:12:38 +0000",
  "in_reply_to_screen_name" : "trotzdemda",
  "in_reply_to_user_id_str" : "339564605",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409120963335176192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096399899, 8.2830149705 ]
  },
  "id_str" : "409121261093396480",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode die Scout-Ausbildung war mehr auf Effizienz als auf Sch\u00F6nheit. ;)",
  "id" : 409121261093396480,
  "in_reply_to_status_id" : 409120963335176192,
  "created_at" : "2013-12-07 00:44:44 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096399899, 8.2830149705 ]
  },
  "id_str" : "409120739795947520",
  "text" : "\u00ABDadurch, dass Knoten an einem angewendet werden wird man ja nicht zum Pfadfinder.\u00BB",
  "id" : 409120739795947520,
  "created_at" : "2013-12-07 00:42:40 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/uhfYNzIMVa",
      "expanded_url" : "http:\/\/i1276.photobucket.com\/albums\/y462\/staffpicks\/Animated_GIFs\/2qdy5o0.gif",
      "display_url" : "i1276.photobucket.com\/albums\/y462\/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009687835, 8.283019365 ]
  },
  "id_str" : "409105645628325888",
  "text" : "yay, results! http:\/\/t.co\/uhfYNzIMVa",
  "id" : 409105645628325888,
  "created_at" : "2013-12-06 23:42:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLOS Blogs",
      "screen_name" : "PLOSBlogs",
      "indices" : [ 3, 13 ],
      "id_str" : "184931891",
      "id" : 184931891
    }, {
      "name" : "Tamsin Edwards",
      "screen_name" : "flimsin",
      "indices" : [ 128, 136 ],
      "id_str" : "92241457",
      "id" : 92241457
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scicomm",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409088985957662720",
  "text" : "RT @plosblogs: Being aware that journalists often don't have statistical training - 9 lessons for #scicomm &amp; #climatechange @flimsin http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tamsin Edwards",
        "screen_name" : "flimsin",
        "indices" : [ 113, 121 ],
        "id_str" : "92241457",
        "id" : 92241457
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scicomm",
        "indices" : [ 83, 91 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/9u1Y1c3Wgg",
        "expanded_url" : "http:\/\/plos.io\/IHIEDb",
        "display_url" : "plos.io\/IHIEDb"
      } ]
    },
    "geo" : { },
    "id_str" : "409087400640389120",
    "text" : "Being aware that journalists often don't have statistical training - 9 lessons for #scicomm &amp; #climatechange @flimsin http:\/\/t.co\/9u1Y1c3Wgg",
    "id" : 409087400640389120,
    "created_at" : "2013-12-06 22:30:11 +0000",
    "user" : {
      "name" : "PLOS Blogs",
      "screen_name" : "PLOSBlogs",
      "protected" : false,
      "id_str" : "184931891",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2436219018\/x047acnubvb1fvmp3h9p_normal.jpeg",
      "id" : 184931891,
      "verified" : false
    }
  },
  "id" : 409088985957662720,
  "created_at" : "2013-12-06 22:36:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009687835, 8.283019365 ]
  },
  "id_str" : "409086816005128192",
  "text" : "\u2018Calling\u2019 genotypes on diploid chromosomes with only a single read\u2026 Sounds legit\u2026",
  "id" : 409086816005128192,
  "created_at" : "2013-12-06 22:27:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096296675, 8.28299471 ]
  },
  "id_str" : "409084038516076544",
  "text" : "\u00ABHab ich dir mit der Frage die Stimmung versaut?\u00BB \u2013 \u00ABSchon okay, ich werde morgen einfach per M\u00FCnzwurf entscheiden wen ich verlasse.\u00BB",
  "id" : 409084038516076544,
  "created_at" : "2013-12-06 22:16:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/PuJMN0nmHo",
      "expanded_url" : "http:\/\/i.imgur.com\/2NIHBsy.jpg",
      "display_url" : "i.imgur.com\/2NIHBsy.jpg"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096296675, 8.28299471 ]
  },
  "id_str" : "409081530485846016",
  "text" : "growth chart http:\/\/t.co\/PuJMN0nmHo",
  "id" : 409081530485846016,
  "created_at" : "2013-12-06 22:06:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1028206772, 8.5706963365 ]
  },
  "id_str" : "409070718539022336",
  "text" : "\u00ABNow, I get perfect scores on all my tests. I just wish I knew what the formulas did. I honestly have no idea.\u00BB Just like my formal math edu",
  "id" : 409070718539022336,
  "created_at" : "2013-12-06 21:23:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1043917879, 8.7275396534 ]
  },
  "id_str" : "409065081373462528",
  "text" : "\u00ABIch bin die Anal-Fisting-Prinzessin. Das ist ein Titel auf den ich sehr stolz bin!\u00BB",
  "id" : 409065081373462528,
  "created_at" : "2013-12-06 21:01:30 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WELT Wissen",
      "screen_name" : "WELT_Wissen",
      "indices" : [ 10, 22 ],
      "id_str" : "52711521",
      "id" : 52711521
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 96, 109 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/XtbMQLFdle",
      "expanded_url" : "http:\/\/ow.ly\/rvXRD",
      "display_url" : "ow.ly\/rvXRD"
    } ]
  },
  "geo" : { },
  "id_str" : "409035279748841473",
  "text" : "Huch, die @WELT_Wissen erw\u00E4hnt uns mit openSNP am Rande eines Artikels \u00FCber FDA .\/. 23andMe \/cc @PhilippBayer http:\/\/t.co\/XtbMQLFdle",
  "id" : 409035279748841473,
  "created_at" : "2013-12-06 19:03:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene-Talk.de",
      "screen_name" : "Gene_Talk",
      "indices" : [ 0, 10 ],
      "id_str" : "1130798947",
      "id" : 1130798947
    }, {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 11, 21 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408962284946337792",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.103911358, 8.6901461294 ]
  },
  "id_str" : "409034116211175425",
  "in_reply_to_user_id" : 1130798947,
  "text" : "@Gene_Talk @Jon_Slate sequencing seems to be more accurate if the read depth is high enough. Otherwise it\u2019s easy to miss 2nd allele.",
  "id" : 409034116211175425,
  "in_reply_to_status_id" : 408962284946337792,
  "created_at" : "2013-12-06 18:58:27 +0000",
  "in_reply_to_screen_name" : "Gene_Talk",
  "in_reply_to_user_id_str" : "1130798947",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 55, 68 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/1tLtFMN40J",
      "expanded_url" : "http:\/\/www.ploscompbiol.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pcbi.1003381",
      "display_url" : "ploscompbiol.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408897216342794241",
  "text" : "Extrapolating Weak Selection in Evolutionary Games \/cc @PhilippBayer http:\/\/t.co\/1tLtFMN40J",
  "id" : 408897216342794241,
  "created_at" : "2013-12-06 09:54:27 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/yLVfoLaKxS",
      "expanded_url" : "http:\/\/kingjamesprogramming.tumblr.com\/",
      "display_url" : "kingjamesprogramming.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "408890790178324480",
  "text" : "\u00ABAnd these three men, Noah, Daniel, and Job were in it, and all the abominations that be done in (log n) steps.\u00BB http:\/\/t.co\/yLVfoLaKxS",
  "id" : 408890790178324480,
  "created_at" : "2013-12-06 09:28:55 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Lobig",
      "screen_name" : "Tom_ofB",
      "indices" : [ 0, 8 ],
      "id_str" : "1687715076",
      "id" : 1687715076
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 9, 18 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 19, 32 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408858622014525440",
  "geo" : { },
  "id_str" : "408888139667632129",
  "in_reply_to_user_id" : 1687715076,
  "text" : "@Tom_ofB @Senficon @PhilippBayer I somewhat doubt that there's a sufficient sample size. ;)",
  "id" : 408888139667632129,
  "in_reply_to_status_id" : 408858622014525440,
  "created_at" : "2013-12-06 09:18:23 +0000",
  "in_reply_to_screen_name" : "Tom_ofB",
  "in_reply_to_user_id_str" : "1687715076",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/TwYdujth1Y",
      "expanded_url" : "http:\/\/i.imgur.com\/8JAvbGO.gif",
      "display_url" : "i.imgur.com\/8JAvbGO.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "408887992703401984",
  "text" : "Ohai! http:\/\/t.co\/TwYdujth1Y",
  "id" : 408887992703401984,
  "created_at" : "2013-12-06 09:17:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408853304513277953",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070845448, 8.2832393758 ]
  },
  "id_str" : "408854765112942592",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so inflation &gt; mining speed? ;)",
  "id" : 408854765112942592,
  "in_reply_to_status_id" : 408853304513277953,
  "created_at" : "2013-12-06 07:05:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408844063522041856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009649325, 8.2830382082 ]
  },
  "id_str" : "408847071513673728",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer and how many BTC so far? ;)",
  "id" : 408847071513673728,
  "in_reply_to_status_id" : 408844063522041856,
  "created_at" : "2013-12-06 06:35:12 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408817701222506496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096598106, 8.2830372825 ]
  },
  "id_str" : "408843440232091648",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer indeed!",
  "id" : 408843440232091648,
  "in_reply_to_status_id" : 408817701222506496,
  "created_at" : "2013-12-06 06:20:46 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408745934185852929",
  "text" : "RT @PhilippBayer: \"Because you are currently reading The Art of R Programming, a few recommendations in Non Fiction: True Norwegian Black M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408741495731019776",
    "text" : "\"Because you are currently reading The Art of R Programming, a few recommendations in Non Fiction: True Norwegian Black Metal\" \nlove it.",
    "id" : 408741495731019776,
    "created_at" : "2013-12-05 23:35:41 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 408745934185852929,
  "created_at" : "2013-12-05 23:53:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 0, 10 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408745381993119744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096131178, 8.2830130005 ]
  },
  "id_str" : "408745565657501696",
  "in_reply_to_user_id" : 15494684,
  "text" : "@zeitweise danke, ich bem\u00FCh mich :)",
  "id" : 408745565657501696,
  "in_reply_to_status_id" : 408745381993119744,
  "created_at" : "2013-12-05 23:51:51 +0000",
  "in_reply_to_screen_name" : "zeitweise",
  "in_reply_to_user_id_str" : "15494684",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@zeitweise",
      "screen_name" : "zeitweise",
      "indices" : [ 0, 10 ],
      "id_str" : "15494684",
      "id" : 15494684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408633908301795328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096602262, 8.2830367722 ]
  },
  "id_str" : "408737768861597698",
  "in_reply_to_user_id" : 15494684,
  "text" : "@zeitweise well played. Gute Nacht :)",
  "id" : 408737768861597698,
  "in_reply_to_status_id" : 408633908301795328,
  "created_at" : "2013-12-05 23:20:52 +0000",
  "in_reply_to_screen_name" : "zeitweise",
  "in_reply_to_user_id_str" : "15494684",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/InM2FrBDm8",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/dog-spies\/2013\/12\/04\/dog-farts-part-1-what-are-dog-farts-made-of\/",
      "display_url" : "blogs.scientificamerican.com\/dog-spies\/2013\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965963, 8.283039095 ]
  },
  "id_str" : "408696230362226688",
  "text" : "How-To: Collect Dog Farts http:\/\/t.co\/InM2FrBDm8",
  "id" : 408696230362226688,
  "created_at" : "2013-12-05 20:35:49 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00965963, 8.283039095 ]
  },
  "id_str" : "408693026148843520",
  "text" : "\u00ABSchau mal, da ist unser Wombat auf dem Parteitag.\u00BB \u2013 \u00ABDu hast unser Wombat ungefragt mitgenommen? Und f\u00FCr politische Zwecke missbraucht?!\u00BB",
  "id" : 408693026148843520,
  "created_at" : "2013-12-05 20:23:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408685960067424256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.00968784, 8.283019375 ]
  },
  "id_str" : "408686413547601922",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Ja, ich erinner mich ganz dunkel daran. :)",
  "id" : 408686413547601922,
  "in_reply_to_status_id" : 408685960067424256,
  "created_at" : "2013-12-05 19:56:48 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/X6lEgCwgWe",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=mEHhdL5LC_M",
      "display_url" : "youtube.com\/watch?v=mEHhdL\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "408682141212344320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618767, 8.2830778233 ]
  },
  "id_str" : "408682481152704512",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Erinnert mich die ganze Zeit schon an http:\/\/t.co\/X6lEgCwgWe ;)",
  "id" : 408682481152704512,
  "in_reply_to_status_id" : 408682141212344320,
  "created_at" : "2013-12-05 19:41:11 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheConstructor",
      "screen_name" : "TheConstructor",
      "indices" : [ 0, 15 ],
      "id_str" : "14362840",
      "id" : 14362840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408679019937144832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096618767, 8.2830778233 ]
  },
  "id_str" : "408679751566753792",
  "in_reply_to_user_id" : 14362840,
  "text" : "@TheConstructor Ja, 2 ist auch besonders, denn so viele Pole haben wir. Und: \u2019Pole\u2019 ist schon ziemlich nah an \u2018Poly\u2019! ;)",
  "id" : 408679751566753792,
  "in_reply_to_status_id" : 408679019937144832,
  "created_at" : "2013-12-05 19:30:20 +0000",
  "in_reply_to_screen_name" : "TheConstructor",
  "in_reply_to_user_id_str" : "14362840",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408674669550923776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096974933, 8.28304489 ]
  },
  "id_str" : "408675550648340480",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode danach: \u00ABevolution follows a spiral, repeating a cyclic pattern that const. brings us back to the same place at a higher level\u00BB m(",
  "id" : 408675550648340480,
  "in_reply_to_status_id" : 408674669550923776,
  "created_at" : "2013-12-05 19:13:38 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "punycode",
      "screen_name" : "punycode",
      "indices" : [ 0, 9 ],
      "id_str" : "14328131",
      "id" : 14328131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408672929883230208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096405533, 8.2830200467 ]
  },
  "id_str" : "408674211860066304",
  "in_reply_to_user_id" : 14328131,
  "text" : "@punycode i doubt someone could fuck me hard enough to forget the BS I just read\u2026 see last tweet\u2026",
  "id" : 408674211860066304,
  "in_reply_to_status_id" : 408672929883230208,
  "created_at" : "2013-12-05 19:08:19 +0000",
  "in_reply_to_screen_name" : "punycode",
  "in_reply_to_user_id_str" : "14328131",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/sU3cPxEs4U",
      "expanded_url" : "http:\/\/amzn.com\/k\/EmW7yTLKSA-O9X67hQRRDA",
      "display_url" : "amzn.com\/k\/EmW7yTLKSA-O\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408674106545295360",
  "text" : "No! 5 is the magical number! Because there are 5 fingers on each hand! m( http:\/\/t.co\/sU3cPxEs4U One male, one female seems to be suf...",
  "id" : 408674106545295360,
  "created_at" : "2013-12-05 19:07:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096405533, 8.2830200467 ]
  },
  "id_str" : "408672555055468544",
  "text" : "\u00ABPolyamory in Myth, Archetypes and Human Evolution\u00BB Just reading that chapter title makes me long for a stiff drink\u2026",
  "id" : 408672555055468544,
  "created_at" : "2013-12-05 19:01:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1693150623, 8.622482355 ]
  },
  "id_str" : "408638250849697792",
  "text" : "\u00ABAlter, du klaust Sterilium im Krankenhaus?\u00BB \u2014 \u00ABDas kann man nicht klauen! Das ist frei f\u00FCr alle da!\u00BB",
  "id" : 408638250849697792,
  "created_at" : "2013-12-05 16:45:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/YfTwKoDIRE",
      "expanded_url" : "http:\/\/instagram.com\/p\/hi7MhJBwqe\/",
      "display_url" : "instagram.com\/p\/hi7MhJBwqe\/"
    } ]
  },
  "geo" : { },
  "id_str" : "408625511662100480",
  "text" : "Symbolbild: Arbeitsmoral http:\/\/t.co\/YfTwKoDIRE",
  "id" : 408625511662100480,
  "created_at" : "2013-12-05 15:54:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/6E5EBqTu6w",
      "expanded_url" : "http:\/\/www.salon.com\/2013\/12\/03\/how_do_i_become_a_male_porn_star\/",
      "display_url" : "salon.com\/2013\/12\/03\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408624027536596992",
  "text" : "\u201CHow do I become a male porn star?\u201D http:\/\/t.co\/6E5EBqTu6w",
  "id" : 408624027536596992,
  "created_at" : "2013-12-05 15:48:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Db38C5cCbz",
      "expanded_url" : "http:\/\/www.theatlantic.com\/education\/archive\/2013\/12\/the-evolution-of-the-college-library\/282023\/",
      "display_url" : "theatlantic.com\/education\/arch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408614237922017282",
  "text" : "Bookporn: The Evolution of the College Library http:\/\/t.co\/Db38C5cCbz",
  "id" : 408614237922017282,
  "created_at" : "2013-12-05 15:10:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408612479263334400",
  "geo" : { },
  "id_str" : "408613146648002560",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich Bei dem Vorschaubild musste ich ja zuerst an sinnlos im weltraum denken ;)",
  "id" : 408613146648002560,
  "in_reply_to_status_id" : 408612479263334400,
  "created_at" : "2013-12-05 15:05:40 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/0CyJvs5BsS",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3196",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408611800523878401",
  "text" : "Affirmative! http:\/\/t.co\/0CyJvs5BsS",
  "id" : 408611800523878401,
  "created_at" : "2013-12-05 15:00:19 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/X1JLsH4Sic",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=3wxmRAPTkSc",
      "display_url" : "youtube.com\/watch?v=3wxmRA\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "408606862679240704",
  "geo" : { },
  "id_str" : "408610334388133888",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich http:\/\/t.co\/X1JLsH4Sic",
  "id" : 408610334388133888,
  "in_reply_to_status_id" : 408606862679240704,
  "created_at" : "2013-12-05 14:54:30 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/uFK2Q2ItjM",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/culture\/books\/bookprizes\/10433486\/Bad-Sex-Award-2013-The-shortlist-in-full.html",
      "display_url" : "telegraph.co.uk\/culture\/books\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408599725869256705",
  "text" : "Woody Guthrie made the shortlist of the Bad Sex Awards 2013 http:\/\/t.co\/uFK2Q2ItjM",
  "id" : 408599725869256705,
  "created_at" : "2013-12-05 14:12:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/j6ME1EDEWW",
      "expanded_url" : "http:\/\/io9.com\/giant-african-slug-facials-are-all-the-rage-in-russia-1476759494",
      "display_url" : "io9.com\/giant-african-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408594880667987968",
  "text" : "\u00ABthe way the snails grasp your face with their giant underbellies massages the skin and eliminates wrinkles\u00BB http:\/\/t.co\/j6ME1EDEWW",
  "id" : 408594880667987968,
  "created_at" : "2013-12-05 13:53:05 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408587838427373568",
  "text" : "\u00ABIhr Atem riecht so gut nach Hundefutter!\u00BB \u2013 \u00ABIch weiss, ihr habt euch vermisst\u2026 Soll ich euch ein bisschen alleine lassen?\u00BB",
  "id" : 408587838427373568,
  "created_at" : "2013-12-05 13:25:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408571963804626944",
  "text" : "My most frequent Google query for the last month: 'c elegans'. Maybe one day I'll learn to spell 'Caenorhabditis'.",
  "id" : 408571963804626944,
  "created_at" : "2013-12-05 12:22:01 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408555626554728448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1743376405, 8.6284353307 ]
  },
  "id_str" : "408557252900298752",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas sure, I can do it. :)",
  "id" : 408557252900298752,
  "in_reply_to_status_id" : 408555626554728448,
  "created_at" : "2013-12-05 11:23:34 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Corpas",
      "screen_name" : "manuelcorpas",
      "indices" : [ 0, 13 ],
      "id_str" : "111020569",
      "id" : 111020569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/qmjryxKnZO",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/407484354634338304",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "408524992406880256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723242971, 8.6270968895 ]
  },
  "id_str" : "408530474077020160",
  "in_reply_to_user_id" : 111020569,
  "text" : "@manuelcorpas did you compare your exomes to the chip data since then? eg https:\/\/t.co\/qmjryxKnZO",
  "id" : 408530474077020160,
  "in_reply_to_status_id" : 408524992406880256,
  "created_at" : "2013-12-05 09:37:09 +0000",
  "in_reply_to_screen_name" : "manuelcorpas",
  "in_reply_to_user_id_str" : "111020569",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408522976359743488",
  "text" : "\u00ABWieso steht da ein riesiger Sack Kartoffeln in meinem B\u00FCro!?\u00BB \u2013 \u00ABDas sind keine Kartoffeln, das sind Waln\u00FCsse.\u00BB \u2013 \u00ABAchso, na dann\u2026\u00BB",
  "id" : 408522976359743488,
  "created_at" : "2013-12-05 09:07:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408512446958022656",
  "text" : "Henceforth I shall use \u00ABTRANSPORTATION OF THE WAGEBOUND UNTO THE NEXUS OF PERPETUAL QUOTIDIAN ENSLAVEMENT\u00BB",
  "id" : 408512446958022656,
  "created_at" : "2013-12-05 08:25:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 92, 105 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/CDmz8ixToy",
      "expanded_url" : "http:\/\/www.invisibleoranges.com\/2013\/11\/death-metal-english\/",
      "display_url" : "invisibleoranges.com\/2013\/11\/death-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408512128941694976",
  "text" : "\u00ABMy favorite thing about Death Metal English is that it isn\u2019t subject matter-specific.\u00BB \/cc @PhilippBayer http:\/\/t.co\/CDmz8ixToy",
  "id" : 408512128941694976,
  "created_at" : "2013-12-05 08:24:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/9QUfsMm9zN",
      "expanded_url" : "http:\/\/www.asofterworld.com\/index.php?id=1042",
      "display_url" : "asofterworld.com\/index.php?id=1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408509651982876673",
  "text" : "i say we unionize http:\/\/t.co\/9QUfsMm9zN",
  "id" : 408509651982876673,
  "created_at" : "2013-12-05 08:14:25 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408393562980507648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096457576, 8.2830269573 ]
  },
  "id_str" : "408393750977998848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer (and should be quite a bit faster compared to blasting against nr\/nt) :p",
  "id" : 408393750977998848,
  "in_reply_to_status_id" : 408393562980507648,
  "created_at" : "2013-12-05 00:33:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408392723238879232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096457576, 8.2830269573 ]
  },
  "id_str" : "408393306927030272",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so the simple mapping should work as de facto clustering methinks.",
  "id" : 408393306927030272,
  "in_reply_to_status_id" : 408392723238879232,
  "created_at" : "2013-12-05 00:32:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408392723238879232",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096444399, 8.2830303429 ]
  },
  "id_str" : "408393197661208576",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I played around with MEGAN and that seems to work quite reasonable. But we only have 2 organisms of interest (+contamination).",
  "id" : 408393197661208576,
  "in_reply_to_status_id" : 408392723238879232,
  "created_at" : "2013-12-05 00:31:40 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408391464754761729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096860389, 8.2831062656 ]
  },
  "id_str" : "408392472768020480",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well and remove everything that maps to known bacteria yada yada. ;)",
  "id" : 408392472768020480,
  "in_reply_to_status_id" : 408391464754761729,
  "created_at" : "2013-12-05 00:28:47 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408391324253958144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096860389, 8.2831062656 ]
  },
  "id_str" : "408392276545921024",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer so: map metagenome A\/B against draft of A. Remove mapped reads from MG. Treat non-mapping reads as putative B.",
  "id" : 408392276545921024,
  "in_reply_to_status_id" : 408391324253958144,
  "created_at" : "2013-12-05 00:28:00 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408391324253958144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096860389, 8.2831062656 ]
  },
  "id_str" : "408391990892855296",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer for that I would need to have ref data for both organisms in metagenome run. So far I have only ref data for one species.",
  "id" : 408391990892855296,
  "in_reply_to_status_id" : 408391324253958144,
  "created_at" : "2013-12-05 00:26:52 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408390414723330048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096860389, 8.2831062656 ]
  },
  "id_str" : "408391534384791553",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer plus the other organisms in the metagenome run are even from another kingdom, so have a safe evolutionary distance to assume",
  "id" : 408391534384791553,
  "in_reply_to_status_id" : 408390414723330048,
  "created_at" : "2013-12-05 00:25:04 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408390414723330048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096525608, 8.2830232499 ]
  },
  "id_str" : "408391119563915264",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I might add those 5% to re-run the ref-assembly. But mostly it\u2019s to get rid of the 5% from the metagenome data.",
  "id" : 408391119563915264,
  "in_reply_to_status_id" : 408390414723330048,
  "created_at" : "2013-12-05 00:23:25 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408390414723330048",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096357158, 8.2830217741 ]
  },
  "id_str" : "408390923316629504",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer well I only have one \u2018clean\u2019 ref assembly and a metagenome run that contains only ~5% reads of my ref species.",
  "id" : 408390923316629504,
  "in_reply_to_status_id" : 408390414723330048,
  "created_at" : "2013-12-05 00:22:38 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408389846332231681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096357158, 8.2830217741 ]
  },
  "id_str" : "408390126457610240",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer same species or at least same genus, no one knows for sure right now. I did the ref de novo assembly as well.",
  "id" : 408390126457610240,
  "in_reply_to_status_id" : 408389846332231681,
  "created_at" : "2013-12-05 00:19:28 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408388854949761024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096357158, 8.2830217741 ]
  },
  "id_str" : "408389670805209088",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if just single mate maps I\u2019ll just assume that my ref is incomplete. :p",
  "id" : 408389670805209088,
  "in_reply_to_status_id" : 408388854949761024,
  "created_at" : "2013-12-05 00:17:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408388854949761024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096357158, 8.2830217741 ]
  },
  "id_str" : "408389352264585216",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer if both reads get ident pos that would be good enough. So I can easily create two sets \u2018mapped with &gt;=1 read\u2019 &amp; \u2018unmapped\u2019",
  "id" : 408389352264585216,
  "in_reply_to_status_id" : 408388854949761024,
  "created_at" : "2013-12-05 00:16:23 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408388281743572992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096357158, 8.2830217741 ]
  },
  "id_str" : "408388520638955520",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer okay, that would make it easy. Will give it a try tomorrow. Wanna sort out meta genome reads to improve de novo ass.",
  "id" : 408388520638955520,
  "in_reply_to_status_id" : 408388281743572992,
  "created_at" : "2013-12-05 00:13:05 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408387756562210816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096357158, 8.2830217741 ]
  },
  "id_str" : "408388128869982208",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yes, would like to have a fastq of all read pairs that mapped to a reference with at least a single mate.",
  "id" : 408388128869982208,
  "in_reply_to_status_id" : 408387756562210816,
  "created_at" : "2013-12-05 00:11:32 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408386598934290433",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096367786, 8.2830215756 ]
  },
  "id_str" : "408387584541605889",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer yeah, bowtie2. Now the catch: it\u2019s paired end, so what happens if only one mate maps? :)",
  "id" : 408387584541605889,
  "in_reply_to_status_id" : 408386598934290433,
  "created_at" : "2013-12-05 00:09:22 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408382777277427713",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096405533, 8.2830200467 ]
  },
  "id_str" : "408383117591052288",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer ah, good to see you talking shop! Have you ever used samtools to extract only mapped\/unmapped reads from a (SB)AM file?",
  "id" : 408383117591052288,
  "in_reply_to_status_id" : 408382777277427713,
  "created_at" : "2013-12-04 23:51:37 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina alt",
      "screen_name" : "tnakng",
      "indices" : [ 43, 50 ],
      "id_str" : "709415983870558208",
      "id" : 709415983870558208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/eT50PtsFJu",
      "expanded_url" : "http:\/\/instagram.com\/p\/hhLhjtBwlV\/",
      "display_url" : "instagram.com\/p\/hhLhjtBwlV\/"
    } ]
  },
  "geo" : { },
  "id_str" : "408380296456044544",
  "text" : "Was passiert wenn man mit  der Familie von @TnaKng unterwegs ist. (Symbolfoto) http:\/\/t.co\/eT50PtsFJu",
  "id" : 408380296456044544,
  "created_at" : "2013-12-04 23:40:24 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096532656, 8.2831143122 ]
  },
  "id_str" : "408359533917253632",
  "text" : "1 observer has commented that polyamory doesn\u2019t help with that dimension of intelligence that tells you that the plural of anecdote != data\u2026",
  "id" : 408359533917253632,
  "created_at" : "2013-12-04 22:17:54 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0097215627, 8.2830688708 ]
  },
  "id_str" : "408359038976794624",
  "text" : "\u00ABNumerous observers have commented that polyamorous people tend to be far above the norms on many dimensions of intelligence\u00BB ffs! m(",
  "id" : 408359038976794624,
  "created_at" : "2013-12-04 22:15:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009615574, 8.2830076855 ]
  },
  "id_str" : "408343753993519104",
  "text" : "\u00ABWenn du die Hand nicht mehr \u00F6ffnen kannst wird es bei der Arbeit zu Fragen f\u00FChren.\u00BB\u2014\u00ABIch sag es ist ein Schweigefuchs mit angelegten Ohren\u00BB",
  "id" : 408343753993519104,
  "created_at" : "2013-12-04 21:15:12 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408287499190935552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1380958377, 8.6706208891 ]
  },
  "id_str" : "408289075079413760",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich die sind auch total gesund!",
  "id" : 408289075079413760,
  "in_reply_to_status_id" : 408287499190935552,
  "created_at" : "2013-12-04 17:37:55 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408285717333164032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1633537932, 8.646428839 ]
  },
  "id_str" : "408287004758376448",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich und wo kommt jetzt der Fruchttiger ins Spiel? ;)",
  "id" : 408287004758376448,
  "in_reply_to_status_id" : 408285717333164032,
  "created_at" : "2013-12-04 17:29:42 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 7, 16 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408284694870900736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1693504369, 8.622474595 ]
  },
  "id_str" : "408285181532196864",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot @JP_Stich bei YT gibt es auch How-Tos f\u00FCr Pimp My Pain.",
  "id" : 408285181532196864,
  "in_reply_to_status_id" : 408284694870900736,
  "created_at" : "2013-12-04 17:22:27 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/9xkDHK7opw",
      "expanded_url" : "http:\/\/picard.sourceforge.net\/explain-flags.html",
      "display_url" : "picard.sourceforge.net\/explain-flags.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408258707852492800",
  "text" : "Uh, lazy me appreciates: Explain SAM flags in plain English http:\/\/t.co\/9xkDHK7opw",
  "id" : 408258707852492800,
  "created_at" : "2013-12-04 15:37:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408255685093113857",
  "geo" : { },
  "id_str" : "408255931051302912",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot well, that's what you get for editing. \"i think you mean\u2026\"",
  "id" : 408255931051302912,
  "in_reply_to_status_id" : 408255685093113857,
  "created_at" : "2013-12-04 15:26:13 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408251795639513089",
  "geo" : { },
  "id_str" : "408253179986333697",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot not a linguist, but I don't mean ginger clad in a piece of human?",
  "id" : 408253179986333697,
  "in_reply_to_status_id" : 408251795639513089,
  "created_at" : "2013-12-04 15:15:17 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/8xQI7E92eJ",
      "expanded_url" : "http:\/\/www.qwantz.com\/index.php?comic=2536",
      "display_url" : "qwantz.com\/index.php?comi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "408248595322654720",
  "geo" : { },
  "id_str" : "408250632819048448",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot i find such conversations happen much better naked! http:\/\/t.co\/8xQI7E92eJ",
  "id" : 408250632819048448,
  "in_reply_to_status_id" : 408248595322654720,
  "created_at" : "2013-12-04 15:05:10 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Msy3OR0wFI",
      "expanded_url" : "http:\/\/www.smbc-comics.com\/index.php?db=comics&id=3195",
      "display_url" : "smbc-comics.com\/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408246767147163648",
  "text" : "your words mean nothing http:\/\/t.co\/Msy3OR0wFI",
  "id" : 408246767147163648,
  "created_at" : "2013-12-04 14:49:48 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723134581, 8.627639487 ]
  },
  "id_str" : "408243218284032001",
  "text" : "\u00ABVorsicht auf dem Flur! Ich bin mir noch nicht ganz sicher ob ich die Drohne richtig zusammengebaut habe und ob die Rotoren diesmal halten!\u00BB",
  "id" : 408243218284032001,
  "created_at" : "2013-12-04 14:35:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408237035741122560",
  "text" : "Die gesuchten Daten befinden sich nat\u00FCrlich im deskriptiv benannten Ordner 'x86_64'\u2026",
  "id" : 408237035741122560,
  "created_at" : "2013-12-04 14:11:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408236481916854273",
  "text" : "Studenten immer erz\u00E4hlen wie wichtig Data Management ist &amp; dann eine halbe Stunde lang verzweifelt mit find &amp; grep auf Genomjagd gehen\u2026 m(",
  "id" : 408236481916854273,
  "created_at" : "2013-12-04 14:08:56 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/F4IkrcjP8O",
      "expanded_url" : "http:\/\/i.imgur.com\/sAwiP.gif",
      "display_url" : "i.imgur.com\/sAwiP.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "408227348626931712",
  "text" : "Nomnomnom! http:\/\/t.co\/F4IkrcjP8O",
  "id" : 408227348626931712,
  "created_at" : "2013-12-04 13:32:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 10, 19 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408210163976658944",
  "geo" : { },
  "id_str" : "408211386968190976",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @thorgnyr @Gilles_PPDE \u00ABWhat we've got here is failure to communicate.\u00BB",
  "id" : 408211386968190976,
  "in_reply_to_status_id" : 408210163976658944,
  "created_at" : "2013-12-04 12:29:13 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 23, 32 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408208773606830080",
  "geo" : { },
  "id_str" : "408209875114553344",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr @Gilles_PPDE @Senficon feel it's my duty to post \u00ABMrs. Robinson, you're trying to seduce me. Aren't you?\u00BB before some1 else does.",
  "id" : 408209875114553344,
  "in_reply_to_status_id" : 408208773606830080,
  "created_at" : "2013-12-04 12:23:13 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/jXmqmVQrEC",
      "expanded_url" : "http:\/\/mathwithbaddrawings.com\/2013\/12\/02\/headlines-from-a-mathematically-literate-world\/",
      "display_url" : "mathwithbaddrawings.com\/2013\/12\/02\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408164150330658816",
  "text" : "Headlines from a Mathematically Literate World http:\/\/t.co\/jXmqmVQrEC",
  "id" : 408164150330658816,
  "created_at" : "2013-12-04 09:21:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/BA7IZzE3tt",
      "expanded_url" : "http:\/\/boingboing.net\/2013\/12\/03\/howto-commit-reverse-racism.html",
      "display_url" : "boingboing.net\/2013\/12\/03\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408162045217886210",
  "text" : "HOWTO commit reverse racism http:\/\/t.co\/BA7IZzE3tt",
  "id" : 408162045217886210,
  "created_at" : "2013-12-04 09:13:09 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/6TR05FDRlW",
      "expanded_url" : "http:\/\/alwaysavoidalliteration.blogspot.de\/2013\/07\/did-bots-in-quake-3-learn-pacifism.html",
      "display_url" : "alwaysavoidalliteration.blogspot.de\/2013\/07\/did-bo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "408153601630953472",
  "geo" : { },
  "id_str" : "408154069249708032",
  "in_reply_to_user_id" : 568173206,
  "text" : "@Gilles_PPDE @Senficon nope http:\/\/t.co\/6TR05FDRlW :)",
  "id" : 408154069249708032,
  "in_reply_to_status_id" : 408153601630953472,
  "created_at" : "2013-12-04 08:41:27 +0000",
  "in_reply_to_screen_name" : "Gilles_EU",
  "in_reply_to_user_id_str" : "568173206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408151719517122560",
  "geo" : { },
  "id_str" : "408152579533570048",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Gilles_PPDE describe your sex life with a movie quote: \u00ABA strange game. The only winning move is not to play\u00BB :p",
  "id" : 408152579533570048,
  "in_reply_to_status_id" : 408151719517122560,
  "created_at" : "2013-12-04 08:35:32 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408151079613128704",
  "geo" : { },
  "id_str" : "408151336744546304",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon @Gilles_PPDE I'll now interpret the bedside nerf guns as a simple precursor-game, right?",
  "id" : 408151336744546304,
  "in_reply_to_status_id" : 408151079613128704,
  "created_at" : "2013-12-04 08:30:36 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 13, 22 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408150243260104704",
  "geo" : { },
  "id_str" : "408150492888317952",
  "in_reply_to_user_id" : 568173206,
  "text" : "@Gilles_PPDE @Senficon In Verbindung mit ICBM launch codes? Pl\u00F6tzlich f\u00FChle ich mich so vanilla!",
  "id" : 408150492888317952,
  "in_reply_to_status_id" : 408150243260104704,
  "created_at" : "2013-12-04 08:27:15 +0000",
  "in_reply_to_screen_name" : "Gilles_EU",
  "in_reply_to_user_id_str" : "568173206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 0, 9 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408144372933603328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727562268, 8.6275300832 ]
  },
  "id_str" : "408144637514510336",
  "in_reply_to_user_id" : 14861745,
  "text" : "@Senficon dazu sagtest du \u2018dann muss ich dich halt non-verbal vom neuen Vorstand \u00FCberzeugen\u2019. Was hast du getr\u00E4umt? Piraten-Kriege von 2013?",
  "id" : 408144637514510336,
  "in_reply_to_status_id" : 408144372933603328,
  "created_at" : "2013-12-04 08:03:59 +0000",
  "in_reply_to_screen_name" : "Senficon",
  "in_reply_to_user_id_str" : "14861745",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1727517973, 8.6275341044 ]
  },
  "id_str" : "408144164849975296",
  "text" : "So putzig wie @Senficon im Schlaf ICBM launch codes ausplaudert!",
  "id" : 408144164849975296,
  "created_at" : "2013-12-04 08:02:06 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/GFH94qZdGU",
      "expanded_url" : "http:\/\/m.pnas.org\/content\/early\/2013\/11\/27\/1318624110.short?view=short&uritype=cgi",
      "display_url" : "m.pnas.org\/content\/early\/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.016635, 8.426571 ]
  },
  "id_str" : "408127244155224064",
  "text" : "Male oral contraceptives \u2014 the cold fusion equivalent of biology. Only for societal not scientific reasons\u2026 http:\/\/t.co\/GFH94qZdGU",
  "id" : 408127244155224064,
  "created_at" : "2013-12-04 06:54:52 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Jeramia Ory",
      "screen_name" : "DrLabRatOry",
      "indices" : [ 14, 26 ],
      "id_str" : "12285052",
      "id" : 12285052
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 27, 39 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408049853386588160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0070621922, 8.283241081 ]
  },
  "id_str" : "408123684214566912",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @DrLabRatOry @helgerausch having slept over it we might not even need a landing page, could display directly next to DL link.",
  "id" : 408123684214566912,
  "in_reply_to_status_id" : 408049853386588160,
  "created_at" : "2013-12-04 06:40:43 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeramia Ory",
      "screen_name" : "DrLabRatOry",
      "indices" : [ 0, 12 ],
      "id_str" : "12285052",
      "id" : 12285052
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 72, 85 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 124, 136 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408030413375176704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096930825, 8.2830447408 ]
  },
  "id_str" : "408034180199882753",
  "in_reply_to_user_id" : 12285052,
  "text" : "@DrLabRatOry that\u2019s good to hear. We\u2019re no UI designers (well, at least @PhilippBayer and I aren\u2019t, don\u2019t want to speak for @helgerausch) ;)",
  "id" : 408034180199882753,
  "in_reply_to_status_id" : 408030413375176704,
  "created_at" : "2013-12-04 00:45:04 +0000",
  "in_reply_to_screen_name" : "DrLabRatOry",
  "in_reply_to_user_id_str" : "12285052",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeramia Ory",
      "screen_name" : "DrLabRatOry",
      "indices" : [ 0, 12 ],
      "id_str" : "12285052",
      "id" : 12285052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408030230478336000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096895733, 8.2831761 ]
  },
  "id_str" : "408032995652927488",
  "in_reply_to_user_id" : 12285052,
  "text" : "@DrLabRatOry we\u2019re always looking for user feedback, that\u2019s why I asked. I\u2019m sure we didn\u2019t think about pro\/cons of having landing page. :)",
  "id" : 408032995652927488,
  "in_reply_to_status_id" : 408030230478336000,
  "created_at" : "2013-12-04 00:40:21 +0000",
  "in_reply_to_screen_name" : "DrLabRatOry",
  "in_reply_to_user_id_str" : "12285052",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408020342813126658",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096974733, 8.2830447833 ]
  },
  "id_str" : "408020992678977536",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer I\u2019d guess they will go for a thunderdome with the next VC. :D",
  "id" : 408020992678977536,
  "in_reply_to_status_id" : 408020342813126658,
  "created_at" : "2013-12-03 23:52:39 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Yb1WnR2WEA",
      "expanded_url" : "http:\/\/valleywag.gawker.com\/airbnbs-office-has-a-replica-of-the-dr-strangelove-wa-1475788543",
      "display_url" : "valleywag.gawker.com\/airbnbs-office\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096974733, 8.2830447833 ]
  },
  "id_str" : "408020140702584833",
  "text" : "And all of a sudden my own workspace feels boring: Airbnb's New Office Has a Replica of the Dr. Strangelove War Room http:\/\/t.co\/Yb1WnR2WEA",
  "id" : 408020140702584833,
  "created_at" : "2013-12-03 23:49:16 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 0, 6 ],
      "id_str" : "1492631",
      "id" : 1492631
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 57, 66 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Tim Weber",
      "screen_name" : "scy",
      "indices" : [ 72, 76 ],
      "id_str" : "8308632",
      "id" : 8308632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "408017620680458240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096974733, 8.2830447833 ]
  },
  "id_str" : "408017725764943872",
  "in_reply_to_user_id" : 1492631,
  "text" : "@Lobot naja, die Farbe l\u00E4uft auch langsam aus. Da m\u00FCssen @Senficon oder @scy mal ran. ;)",
  "id" : 408017725764943872,
  "in_reply_to_status_id" : 408017620680458240,
  "created_at" : "2013-12-03 23:39:41 +0000",
  "in_reply_to_screen_name" : "Lobot",
  "in_reply_to_user_id_str" : "1492631",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/jfnc1ioG3J",
      "expanded_url" : "http:\/\/i.imgur.com\/qtLoN9I.gif",
      "display_url" : "i.imgur.com\/qtLoN9I.gif"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096974733, 8.2830447833 ]
  },
  "id_str" : "408011122290458624",
  "text" : "just-world fallacy reinforced http:\/\/t.co\/jfnc1ioG3J",
  "id" : 408011122290458624,
  "created_at" : "2013-12-03 23:13:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 3, 16 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/baq5eBhq4Y",
      "expanded_url" : "http:\/\/www.nature.com\/news\/2011\/110309\/full\/news.2011.148.html?WT.mc_id=FBK_NatureNews",
      "display_url" : "nature.com\/news\/2011\/1103\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408004523744301057",
  "text" : "RT @PhilippBayer: Human evolution: \"How the penis lost its spikes\" http:\/\/t.co\/baq5eBhq4Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/baq5eBhq4Y",
        "expanded_url" : "http:\/\/www.nature.com\/news\/2011\/110309\/full\/news.2011.148.html?WT.mc_id=FBK_NatureNews",
        "display_url" : "nature.com\/news\/2011\/1103\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408004108138717184",
    "text" : "Human evolution: \"How the penis lost its spikes\" http:\/\/t.co\/baq5eBhq4Y",
    "id" : 408004108138717184,
    "created_at" : "2013-12-03 22:45:34 +0000",
    "user" : {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "protected" : false,
      "id_str" : "121777206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2013711027\/IMG_1088_normal.png",
      "id" : 121777206,
      "verified" : false
    }
  },
  "id" : 408004523744301057,
  "created_at" : "2013-12-03 22:47:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali",
      "screen_name" : "zoonpolitikon",
      "indices" : [ 0, 14 ],
      "id_str" : "13040652",
      "id" : 13040652
    }, {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 15, 28 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 29, 38 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 39, 51 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407998193268293633",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096849, 8.2831869667 ]
  },
  "id_str" : "407999709882896384",
  "in_reply_to_user_id" : 13040652,
  "text" : "@zoonpolitikon @PhilippBayer @Senficon @helgerausch well, the reviewers certainly care. That\u2019s why the paper has been in review for &gt; 1 year",
  "id" : 407999709882896384,
  "in_reply_to_status_id" : 407998193268293633,
  "created_at" : "2013-12-03 22:28:05 +0000",
  "in_reply_to_screen_name" : "zoonpolitikon",
  "in_reply_to_user_id_str" : "13040652",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407997666857975808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096849, 8.2831869667 ]
  },
  "id_str" : "407997798177832960",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon @helgerausch that\u2019s rewriting 2-3 sentences. The ethics stuff might require a tad more research.",
  "id" : 407997798177832960,
  "in_reply_to_status_id" : 407997666857975808,
  "created_at" : "2013-12-03 22:20:29 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 0, 13 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 14, 23 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 24, 36 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407992139373502464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096849, 8.2831869667 ]
  },
  "id_str" : "407992414696398848",
  "in_reply_to_user_id" : 121777206,
  "text" : "@PhilippBayer @Senficon @helgerausch the comments re:SNPedia API are simple. There\u2019s an API for articles, not for raw data. :)",
  "id" : 407992414696398848,
  "in_reply_to_status_id" : 407992139373502464,
  "created_at" : "2013-12-03 21:59:06 +0000",
  "in_reply_to_screen_name" : "PhilippBayer",
  "in_reply_to_user_id_str" : "121777206",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeramia Ory",
      "screen_name" : "DrLabRatOry",
      "indices" : [ 0, 12 ],
      "id_str" : "12285052",
      "id" : 12285052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407611588964020224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096849, 8.2831869667 ]
  },
  "id_str" : "407992243803668480",
  "in_reply_to_user_id" : 12285052,
  "text" : "@DrLabRatOry whops, did it create a problem for you and do you think we should add a confirmation?",
  "id" : 407992243803668480,
  "in_reply_to_status_id" : 407611588964020224,
  "created_at" : "2013-12-03 21:58:25 +0000",
  "in_reply_to_screen_name" : "DrLabRatOry",
  "in_reply_to_user_id_str" : "12285052",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lore Frost",
      "screen_name" : "Lobot",
      "indices" : [ 40, 46 ],
      "id_str" : "1492631",
      "id" : 1492631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0022778319, 8.2643762441 ]
  },
  "id_str" : "407947992847892482",
  "text" : "\u00ABWenn du heute nicht als Farbmarker f\u00FCr @Lobot dienst dann kannst du mir als Naturwissenschaftler gleich wenigstens alles erkl\u00E4ren.\u00BB",
  "id" : 407947992847892482,
  "created_at" : "2013-12-03 19:02:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/u1QrF35T6x",
      "expanded_url" : "http:\/\/i.imgur.com\/BpsOkd8.gif",
      "display_url" : "i.imgur.com\/BpsOkd8.gif"
    } ]
  },
  "geo" : { },
  "id_str" : "407912615415783424",
  "text" : "time to go http:\/\/t.co\/u1QrF35T6x",
  "id" : 407912615415783424,
  "created_at" : "2013-12-03 16:42:00 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/3CGwZTf4yw",
      "expanded_url" : "http:\/\/aeon.co\/magazine\/nature-and-cosmos\/why-its-time-to-lay-the-selfish-gene-to-rest\/",
      "display_url" : "aeon.co\/magazine\/natur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407905260221386752",
  "text" : "\u00ABThe selfish gene is one of the most successful science metaphors ever invented. Unfortunately, it\u2019s wrong\u00BB http:\/\/t.co\/3CGwZTf4yw",
  "id" : 407905260221386752,
  "created_at" : "2013-12-03 16:12:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 111, 124 ],
      "id_str" : "121777206",
      "id" : 121777206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/CNLqI253CA",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info:doi\/10.1371\/journal.pone.0077056",
      "display_url" : "plosone.org\/article\/info:d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407895267992555520",
  "text" : "\u00ABWe present evidence of a massive [language] die-off caused by the digital divide.\u00BB http:\/\/t.co\/CNLqI253CA \/cc @PhilippBayer",
  "id" : 407895267992555520,
  "created_at" : "2013-12-03 15:33:04 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407891278714511360",
  "text" : "\u00ABWie siehst du denn aus? Hatte dein Bart-Trimm-Roboter heute morgen einen Knick in der Optik?\u00BB",
  "id" : 407891278714511360,
  "created_at" : "2013-12-03 15:17:13 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407878510070337537",
  "text" : "\u00ABDie meinten wir sollen eine 20-min\u00FCtige Sequenz vorstellen, ich war total verwirrt!\u00BB\u2013\u00ABA\u2026T\u2026G\u2026, h\u00E4ngt total von der Lesegeschwindigkeit ab.\u00BB",
  "id" : 407878510070337537,
  "created_at" : "2013-12-03 14:26:29 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/svrxIRiVpw",
      "expanded_url" : "http:\/\/www.polygon.com\/features\/2013\/12\/2\/5143856\/no-girls-allowed",
      "display_url" : "polygon.com\/features\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407874675012677632",
  "text" : "No girls allowed \u2013 Unraveling the story behind the stereotype of video games being for boys http:\/\/t.co\/svrxIRiVpw",
  "id" : 407874675012677632,
  "created_at" : "2013-12-03 14:11:15 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/YC3KT4qjII",
      "expanded_url" : "http:\/\/blogs.scientificamerican.com\/thoughtful-animal\/2013\/11\/21\/does-your-dog-love-you-back\/",
      "display_url" : "blogs.scientificamerican.com\/thoughtful-ani\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407867478362947584",
  "text" : "\u00ABYou can not simply love a dog so much that it will be forced to love you back.\u00BB http:\/\/t.co\/YC3KT4qjII",
  "id" : 407867478362947584,
  "created_at" : "2013-12-03 13:42:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/bX7WN9UQ4P",
      "expanded_url" : "http:\/\/neuroecology.wordpress.com\/2013\/12\/02\/learning-to-see-through-semantics\/",
      "display_url" : "neuroecology.wordpress.com\/2013\/12\/02\/lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407864330089017344",
  "text" : "Learning to see through semantics http:\/\/t.co\/bX7WN9UQ4P",
  "id" : 407864330089017344,
  "created_at" : "2013-12-03 13:30:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/MSOaPxITqy",
      "expanded_url" : "http:\/\/i.imgur.com\/CWFTYoV.png",
      "display_url" : "i.imgur.com\/CWFTYoV.png"
    } ]
  },
  "geo" : { },
  "id_str" : "407856930065891328",
  "text" : "You just need to change your frame of mind! http:\/\/t.co\/MSOaPxITqy",
  "id" : 407856930065891328,
  "created_at" : "2013-12-03 13:00:44 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philipp Bayer\uD83C\uDF08",
      "screen_name" : "PhilippBayer",
      "indices" : [ 103, 116 ],
      "id_str" : "121777206",
      "id" : 121777206
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 117, 126 ],
      "id_str" : "14861745",
      "id" : 14861745
    }, {
      "name" : "Helge Rausch \uD83E\uDD59",
      "screen_name" : "helgerausch",
      "indices" : [ 127, 139 ],
      "id_str" : "52747896",
      "id" : 52747896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407855658101272576",
  "text" : "\u00AByour manuscript will be suitable for publication after you address the 2 minor points below\u00BB Min Rev \/@PhilippBayer @Senficon @helgerausch",
  "id" : 407855658101272576,
  "created_at" : "2013-12-03 12:55:41 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/fwRnGOC5id",
      "expanded_url" : "http:\/\/stackoverflow.com\/a\/6445794",
      "display_url" : "stackoverflow.com\/a\/6445794"
    } ]
  },
  "geo" : { },
  "id_str" : "407839221680861185",
  "text" : "\u00ABSomewhere there is a Hotel Manager explaining the problem of disappearing towels [\u2026] using a memory leak analogy\u00BB http:\/\/t.co\/fwRnGOC5id",
  "id" : 407839221680861185,
  "created_at" : "2013-12-03 11:50:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095799985, 8.2829789456 ]
  },
  "id_str" : "407807253375614976",
  "text" : "undo others as you would have them undo you",
  "id" : 407807253375614976,
  "created_at" : "2013-12-03 09:43:20 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407805689743302656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095799985, 8.2829789456 ]
  },
  "id_str" : "407806695461892096",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon n\u00E4chstes mal. :)",
  "id" : 407806695461892096,
  "in_reply_to_status_id" : 407805689743302656,
  "created_at" : "2013-12-03 09:41:07 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095530433, 8.2829680941 ]
  },
  "id_str" : "407804815998484480",
  "text" : "\u00ABIch hab Katzenpr\u00FCfer verstanden.\u00BB \u2014 \u00ABMacht bei der Internetpartei ja auch Sinn.\u00BB",
  "id" : 407804815998484480,
  "created_at" : "2013-12-03 09:33:39 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 10, 19 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407802896022249472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096324366, 8.2830428146 ]
  },
  "id_str" : "407803064259977216",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich @Senficon yup, wenn es welche gibt komm ich aber gern mit. :)",
  "id" : 407803064259977216,
  "in_reply_to_status_id" : 407802896022249472,
  "created_at" : "2013-12-03 09:26:41 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    }, {
      "name" : "Julia Reda",
      "screen_name" : "Senficon",
      "indices" : [ 42, 51 ],
      "id_str" : "14861745",
      "id" : 14861745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407801983597547520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096182319, 8.2830153654 ]
  },
  "id_str" : "407802676517535744",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich hast du Tickets reserviert? Als @Senficon und ich letztes mal hin wollten war an Abendkasse gar nicht zu denken.",
  "id" : 407802676517535744,
  "in_reply_to_status_id" : 407801983597547520,
  "created_at" : "2013-12-03 09:25:09 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Paul Stich \u274C",
      "screen_name" : "JP_Stich",
      "indices" : [ 0, 9 ],
      "id_str" : "371189071",
      "id" : 371189071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407791953431252992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.009687462, 8.283002585 ]
  },
  "id_str" : "407799582249463808",
  "in_reply_to_user_id" : 371189071,
  "text" : "@JP_Stich klar, wann\/wo?",
  "id" : 407799582249463808,
  "in_reply_to_status_id" : 407791953431252992,
  "created_at" : "2013-12-03 09:12:51 +0000",
  "in_reply_to_screen_name" : "JP_Stich",
  "in_reply_to_user_id_str" : "371189071",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407544415079526400",
  "geo" : { },
  "id_str" : "407545771957829632",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime guess that depends on the coverage pattern seen in the exome data. Unfortunately right now I don't have the reads to check.",
  "id" : 407545771957829632,
  "in_reply_to_status_id" : 407544415079526400,
  "created_at" : "2013-12-02 16:24:18 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407541766527516672",
  "geo" : { },
  "id_str" : "407542468125540352",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime isn't that at least partially offset by the low cov. sites where I'm actually heterozygous but only ref allele observed?",
  "id" : 407542468125540352,
  "in_reply_to_status_id" : 407541766527516672,
  "created_at" : "2013-12-02 16:11:10 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Price Ball",
      "screen_name" : "madprime",
      "indices" : [ 0, 9 ],
      "id_str" : "71557700",
      "id" : 71557700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/sDVJ7pLESE",
      "expanded_url" : "https:\/\/twitter.com\/gedankenstuecke\/status\/407484354634338304",
      "display_url" : "twitter.com\/gedankenstueck\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "407539519408177152",
  "geo" : { },
  "id_str" : "407540185232986113",
  "in_reply_to_user_id" : 71557700,
  "text" : "@madprime yes, though it appears to be largely a problem due to the exome filtering created by low coverage SNPs https:\/\/t.co\/sDVJ7pLESE",
  "id" : 407540185232986113,
  "in_reply_to_status_id" : 407539519408177152,
  "created_at" : "2013-12-02 16:02:06 +0000",
  "in_reply_to_screen_name" : "madprime",
  "in_reply_to_user_id_str" : "71557700",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Gw7rE6qL55",
      "expanded_url" : "http:\/\/www.plosone.org\/article\/info%3Adoi%2F10.1371%2Fjournal.pone.0082435",
      "display_url" : "plosone.org\/article\/info%3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407496277295771648",
  "text" : "Misread that as \u00ABFun-Dependent Gene Networks in Acute Ethanol Sensitivity\u00BB http:\/\/t.co\/Gw7rE6qL55",
  "id" : 407496277295771648,
  "created_at" : "2013-12-02 13:07:38 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407486458484625409",
  "geo" : { },
  "id_str" : "407494739051573248",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate absolutely, though for that set of SNPs I'd guess that exome seq is more accurate (coverage of 40x+ w\/ even allele distribution)",
  "id" : 407494739051573248,
  "in_reply_to_status_id" : 407486458484625409,
  "created_at" : "2013-12-02 13:01:31 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407482765378990081",
  "geo" : { },
  "id_str" : "407484354634338304",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate ignoring all SNPs in the exome data with coverage &lt;= 5 brings % of non-concordant SNPs down to ~0.2% (50\/21914).",
  "id" : 407484354634338304,
  "in_reply_to_status_id" : 407482765378990081,
  "created_at" : "2013-12-02 12:20:15 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407482765378990081",
  "geo" : { },
  "id_str" : "407483471326507008",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate 23andMe gives no details on quality control for final genotype calls afaik. But my exome VCF contains the data.",
  "id" : 407483471326507008,
  "in_reply_to_status_id" : 407482765378990081,
  "created_at" : "2013-12-02 12:16:44 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 45, 55 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407478383077888000",
  "text" : "Skimming the read depth I have to agree with @Jon_Slate. Most non-concordant SNPs have coverage &lt; 10 for exome. Wonder why got called at all",
  "id" : 407478383077888000,
  "created_at" : "2013-12-02 11:56:31 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Gene-Talk.de",
      "screen_name" : "Gene_Talk",
      "indices" : [ 11, 21 ],
      "id_str" : "1130798947",
      "id" : 1130798947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407476191570841600",
  "geo" : { },
  "id_str" : "407476871148748801",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate @Gene_Talk correct me if I'm wrong, but I suspect that exome SNP chips only target known vars. compared to de novo mut. in seq?",
  "id" : 407476871148748801,
  "in_reply_to_status_id" : 407476191570841600,
  "created_at" : "2013-12-02 11:50:31 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407476587802529792",
  "text" : "Interesting: Of those 510 non-concordant SNPs in my data 473 are homozygous in the exome data while heterozygous in 23andMe data set.",
  "id" : 407476587802529792,
  "created_at" : "2013-12-02 11:49:23 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Slate",
      "screen_name" : "Jon_Slate",
      "indices" : [ 0, 10 ],
      "id_str" : "1545031921",
      "id" : 1545031921
    }, {
      "name" : "Gene-Talk.de",
      "screen_name" : "Gene_Talk",
      "indices" : [ 34, 44 ],
      "id_str" : "1130798947",
      "id" : 1130798947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407466363293163520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723182992, 8.6276287941 ]
  },
  "id_str" : "407467473475493888",
  "in_reply_to_user_id" : 1545031921,
  "text" : "@Jon_Slate it\u2019s from a sequencer. @Gene_Talk can give you the details of the exome sequencing. No idea what\u2019s more robust.",
  "id" : 407467473475493888,
  "in_reply_to_status_id" : 407466363293163520,
  "created_at" : "2013-12-02 11:13:10 +0000",
  "in_reply_to_screen_name" : "Jon_Slate",
  "in_reply_to_user_id_str" : "1545031921",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03B8ourkni\u02D0r\u0325",
      "screen_name" : "thorgnyr",
      "indices" : [ 0, 9 ],
      "id_str" : "38015980",
      "id" : 38015980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "407461366011019264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723686709, 8.6275843386 ]
  },
  "id_str" : "407462823707824131",
  "in_reply_to_user_id" : 38015980,
  "text" : "@thorgnyr it\u2019s an error estimate, though it doesn\u2019t tell which method gave the \u2018wrong\u2019 results.",
  "id" : 407462823707824131,
  "in_reply_to_status_id" : 407461366011019264,
  "created_at" : "2013-12-02 10:54:42 +0000",
  "in_reply_to_screen_name" : "thorgnyr",
  "in_reply_to_user_id_str" : "38015980",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407460831081680896",
  "text" : "Quick test on my data: Of the 24,809 diploid SNPs found in my exome sequencing data &amp; my 23andMe genotype data 510 (~2%) differ.",
  "id" : 407460831081680896,
  "created_at" : "2013-12-02 10:46:47 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lior Pachter",
      "screen_name" : "lpachter",
      "indices" : [ 5, 14 ],
      "id_str" : "31936449",
      "id" : 31936449
    }, {
      "name" : "samantha based clark",
      "screen_name" : "eltonjohn",
      "indices" : [ 61, 71 ],
      "id_str" : "15661851",
      "id" : 15661851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Hjf9fsdBS2",
      "expanded_url" : "http:\/\/liorpachter.wordpress.com\/2013\/11\/30\/23andme-genotypes-are-all-wrong\/",
      "display_url" : "liorpachter.wordpress.com\/2013\/11\/30\/23a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407448143890886656",
  "text" : "Yay: @lpachter uses data from openSNP (i.e. the genotypes of @eltonjohn) to discuss errors in 23andMe data http:\/\/t.co\/Hjf9fsdBS2",
  "id" : 407448143890886656,
  "created_at" : "2013-12-02 09:56:22 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/J8MVsuNnlg",
      "expanded_url" : "http:\/\/www.salon.com\/2013\/11\/30\/spare_us_your_monogamy_speech_partner\/",
      "display_url" : "salon.com\/2013\/11\/30\/spa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407446253249638400",
  "text" : "\u00ABYour view of your own moral superiority is not going to make someone else\u2019s relationship better or worse\u00BB http:\/\/t.co\/J8MVsuNnlg",
  "id" : 407446253249638400,
  "created_at" : "2013-12-02 09:48:51 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/3dIriKuYrK",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=PhKmA7ar2D0",
      "display_url" : "youtube.com\/watch?v=PhKmA7\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.1723195404, 8.6276283089 ]
  },
  "id_str" : "407437629744226304",
  "text" : "how can I talk of life and warmth?\ni\u2019ve got a voice like a gutter in a toxic storm http:\/\/t.co\/3dIriKuYrK",
  "id" : 407437629744226304,
  "created_at" : "2013-12-02 09:14:35 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "indices" : [ 3, 15 ],
      "id_str" : "13766492",
      "id" : 13766492
    }, {
      "name" : "John Timmer",
      "screen_name" : "j_timmer",
      "indices" : [ 25, 34 ],
      "id_str" : "16843817",
      "id" : 16843817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/HnD1rjwokE",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/sciencetech\/article-2515969\/Humans-evolved-female-chimpanzee-mated-pig-Extraordinary-claim-American-geneticist.html",
      "display_url" : "dailymail.co.uk\/sciencetech\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407270995238854656",
  "text" : "RT @AkshatRathi: WTF. RT @j_timmer: I cannot believe the Daily Mail ran this: http:\/\/t.co\/HnD1rjwokE It's not controversial; it's simply wr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Timmer",
        "screen_name" : "j_timmer",
        "indices" : [ 8, 17 ],
        "id_str" : "16843817",
        "id" : 16843817
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/HnD1rjwokE",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/sciencetech\/article-2515969\/Humans-evolved-female-chimpanzee-mated-pig-Extraordinary-claim-American-geneticist.html",
        "display_url" : "dailymail.co.uk\/sciencetech\/ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "407268592946655232",
    "text" : "WTF. RT @j_timmer: I cannot believe the Daily Mail ran this: http:\/\/t.co\/HnD1rjwokE It's not controversial; it's simply wrong.",
    "id" : 407268592946655232,
    "created_at" : "2013-12-01 22:02:53 +0000",
    "user" : {
      "name" : "Akshat Rathi",
      "screen_name" : "AkshatRathi",
      "protected" : false,
      "id_str" : "13766492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/867091696508653568\/s5mhR4ru_normal.jpg",
      "id" : 13766492,
      "verified" : true
    }
  },
  "id" : 407270995238854656,
  "created_at" : "2013-12-01 22:12:26 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/oLi93VZxxJ",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/American_Service-Members'_Protection_Act",
      "display_url" : "en.wikipedia.org\/wiki\/American_\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0096727386, 8.28313593 ]
  },
  "id_str" : "407225622575210496",
  "text" : "TIL about: The Hague Invasion Act http:\/\/t.co\/oLi93VZxxJ",
  "id" : 407225622575210496,
  "created_at" : "2013-12-01 19:12:08 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 50.0095949793, 8.2828414876 ]
  },
  "id_str" : "407177192716914688",
  "text" : "\u00ABKein Fieber messen: Im Hort d\u00FCrfen wir nichts in K\u00F6rper\u00F6ffnungen schieben.\u00BB\u2014\u00ABHat sich noch nicht in allen kath Einrichtungen durchgesetzt\u2026\u00BB",
  "id" : 407177192716914688,
  "created_at" : "2013-12-01 15:59:42 +0000",
  "user" : {
    "name" : "Bastian Greshake Tzovaras",
    "screen_name" : "gedankenstuecke",
    "protected" : false,
    "id_str" : "14286491",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631139597750280192\/XqPERhRA_normal.jpg",
    "id" : 14286491,
    "verified" : true
  }
} ]